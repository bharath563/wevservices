package org.tiaa.cmts_rs.helper;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;

import org.tiaa.cmts_rs.domain.NigoTask;
import org.tiaa.cmts_rs.domain.TaskSearch;

@Component
public class TaskSearchHelper {
	static org.apache.log4j.Logger LOG = Logger.getLogger(TaskSearchHelper.class);

	public List<NigoTask> nigosearch(TaskSearch taskSearch, List<NigoTask> taskList) {
		List<NigoTask> resTaskList = new ArrayList<NigoTask>();
		for (NigoTask nigoTask : taskList) {
			resTaskList.add(nigoTask);
		}
		return resTaskList;
	}

}
