package org.tiaa.cmts_rs.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;

import org.tiaa.cmts_rs.constant.CommonConstants;
import org.tiaa.cmts_rs.delegate.CaseManagementDelegate;

public class AppConfig {

	@Autowired
	@Qualifier("expagAdapter")
	private CaseManagementDelegate expagDelegate;

	@Autowired
	@Qualifier("icmAdapter")
	private CaseManagementDelegate icmDelegate;

	private static Logger LOG = Logger.getLogger(AppConfig.class);

	private static Map<String, String> appPropsMap = new HashMap<String, String>();

	public AppConfig() {
		Properties prop = new Properties();
		InputStream input = null;
		try {
			input = AppConfig.class.getResourceAsStream("/org/tiaa/cmts_rs/app.properties");
			prop.load(input);
			for (final String name : prop.stringPropertyNames()) {
				appPropsMap.put(name, prop.getProperty(name));
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public static String getProperty(String key) {
		return appPropsMap.get(key);
	}

	public static int getIntProperty(String key) {
		String value = appPropsMap.get(key);
		try {
			return Integer.parseInt(value);
		} catch (NumberFormatException e) {
			LOG.error("Error in Number Format: " + e.getMessage());
			throw e;
		}
	}

	@Bean
	public Map<String, CaseManagementDelegate> appConfigs() {

		Map<String, CaseManagementDelegate> appConfigs = new HashMap<String, CaseManagementDelegate>();

		String uwapps = AppConfig.getProperty("bpmapps");
		String[] apps = uwapps.split(",");
		LOG.debug(" nigo taskSearch apps:" + apps);
		for (String appName : apps) {
			if (CommonConstants.APP_EXPAG.equalsIgnoreCase(appName)) {
				appConfigs.put(appName, expagDelegate);
			} else if (CommonConstants.APP_ICM.equalsIgnoreCase(appName)) {
				appConfigs.put(appName, icmDelegate);
			}

		}
		return appConfigs;
	}

}
