package org.tiaa.cmts_rs.controller;

import java.net.UnknownHostException;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import org.tiaa.cmts_rs.domain.PingResponse;
import org.tiaa.cmts_rs.domain.ResponseList;
import org.tiaa.cmts_rs.domain.TaskSearch;
import org.tiaa.cmts_rs.impl.CMTSRestServiceImpl;

@Controller
public class NigoResource {

	static Logger LOG = Logger.getLogger(NigoResource.class);

	@Autowired
	private CMTSRestServiceImpl cmtsRestServiceImpl;

	@RequestMapping(value = "/ping", method = RequestMethod.GET)
	public @ResponseBody PingResponse ping(HttpServletRequest request) throws UnknownHostException {

		LOG.debug("Entered ping request method");
		return cmtsRestServiceImpl.ping(request);

	}

	@RequestMapping(value = "/nigotasksearch", method = RequestMethod.POST)
	public @ResponseBody ResponseList serachNigoTasks(@RequestBody TaskSearch taskSearch, HttpServletRequest request)
			throws Exception {
		LOG.info("Start " + taskSearch.getUid());
		return cmtsRestServiceImpl.doTaskSearch(taskSearch);
	}

}
