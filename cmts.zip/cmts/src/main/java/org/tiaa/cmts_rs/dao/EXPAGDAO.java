package org.tiaa.cmts_rs.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.cmts_rs.constant.CommonConstants;
import org.tiaa.cmts_rs.domain.NigoTask;
import org.tiaa.cmts_rs.domain.TaskSearch;

@Component
public class EXPAGDAO {

	static Logger LOG = Logger.getLogger(EXPAGDAO.class);
	@Autowired
	private DataSource expagDataSource;

	@SuppressWarnings("unused")
	public List<NigoTask> getExpagSearchResults(TaskSearch taskSearch) throws SQLException {
		List<NigoTask> taskList = new ArrayList<NigoTask>();

		Connection con = null;
		CallableStatement call = null;
		ResultSet rs = null;
		try {
			List<String> reqpins = taskSearch.getPins();
			con = this.expagDataSource.getConnection();

			call = con.prepareCall("BEGIN PIMITEK.MYDESKTOP_NIGO_SEARCH(?,?,?,?); END;");
			call.setString(1, taskSearch.getTaskStatus());
			call.setInt(2, Integer.parseInt(taskSearch.getDays()));
			call.registerOutParameter(3, oracle.jdbc.OracleTypes.NUMBER);// total
																			// count
			call.registerOutParameter(4, oracle.jdbc.OracleTypes.CURSOR);// search_recordset
			LOG.info("Start of EXPAG SP Call for " + taskSearch.getUid());
			call.execute();
			LOG.info("End of EXPAG SP Call for " + taskSearch.getUid());
			int resultcount = call.getInt(3);
			rs = (ResultSet) call.getObject(4);
			long i = System.currentTimeMillis();
			LOG.info("Start of EXPAG consolidating data for PINS " + taskSearch.getUid());
			if (rs != null) {
				while (rs.next()) {
					if (reqpins.contains(rs.getString("pin").trim())) {
						NigoTask task = new NigoTask();
						if (rs.getString("pktid") != null) {
							task.setProcessId(rs.getString("pktid").trim());
						}
						if (rs.getString("tskid") != null) {
							task.setTaskId(rs.getString("tskid").trim());
						}
						if (rs.getString("tasktype") != null) {
							task.setTaskType(rs.getString("tasktype").trim());
						}
						if (rs.getString("department") != null) {
							task.setDepartment(rs.getString("department").trim());
						}
						if (rs.getString("DPTLNGNAME") != null) {
							task.setDepartmentDescription(rs.getString("DPTLNGNAME").trim());
						}
						if (rs.getString("taskdescription") != null) {
							task.setTaskName(rs.getString("taskdescription").trim());
						}

						if (rs.getString("ASSIGNEDTO") != null) {
							task.setAssignedTo(rs.getString("ASSIGNEDTO").trim());
						}

						if (rs.getString("pin") != null) {
							task.setPin(rs.getString("pin").trim());
						}
						if (rs.getTimestamp("created") != null) {
							task.setTaskCreatedDate(
									CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs.getTimestamp("created")));
						}
						if (rs.getTimestamp("RECEIVED") != null) {
							task.setTaskReceivedDate(
									CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs.getTimestamp("RECEIVED")));
						}
						if (rs.getTimestamp("lastupdated") != null) {
							task.setTaskLastUpdatedDate(
									CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs.getTimestamp("lastupdated")));
						}
						if (rs.getTimestamp("COMPLETED") != null) {
							task.setTaskCompletedDate(
									CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs.getTimestamp("COMPLETED")));
						}

						if (rs.getString("status") != null) {
							task.setStatus(rs.getString("status").trim());

						}
						task.setAppName(CommonConstants.APP_EXPAG);
						taskList.add(task);
					}
				}
			}
			LOG.info("End of EXPAG consolidating data for PINS " + taskSearch.getUid() + " : "
					+ (System.currentTimeMillis() - i));
		} catch (SQLException e) {
			LOG.error("Exception in sqlPackageSearch " + e.getMessage());
			throw e;
		} finally {
			if (call != null) {
				call.close();
			}
			if (con != null) {
				con.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return taskList;
	}

}
