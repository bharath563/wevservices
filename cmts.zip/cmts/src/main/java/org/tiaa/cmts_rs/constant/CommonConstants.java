package org.tiaa.cmts_rs.constant;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

public interface CommonConstants {

	public static final String APP_EXPAG = "EXPAG";
	public static final String APP_ICM = "ICM";

	public static final DateFormat DF_MM_dd_yyyy_hh_mm_ss_a = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
	public static final String MMDDYYYY12HR = "MM/dd/yyyy hh:mm:ss.SSS a";

}
