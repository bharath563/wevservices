package org.tiaa.cmts_rs.impl;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.tomcat.jdbc.pool.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import org.tiaa.cmts_rs.constant.CommonConstants;
import org.tiaa.cmts_rs.delegate.CaseManagementDelegate;
import org.tiaa.cmts_rs.domain.Components;
import org.tiaa.cmts_rs.domain.NigoTask;
import org.tiaa.cmts_rs.domain.PingResponse;
import org.tiaa.cmts_rs.domain.ResponseList;
import org.tiaa.cmts_rs.domain.TaskSearch;

@Component
public class CMTSRestServiceImpl {

	static Logger LOG = Logger.getLogger(CMTSRestServiceImpl.class);

	@Autowired
	@Qualifier("expagAdapter")
	private CaseManagementDelegate expagDelegate;

	@Autowired
	@Qualifier("icmAdapter")
	private CaseManagementDelegate icmDelegate;

	@Autowired
	private DataSource expagDataSource;

	@Autowired
	private DataSource cmRepotingDataSource;

	@javax.annotation.Resource(name = "appConfigs")
	private HashMap<String, CaseManagementDelegate> appConfigs;

	public HashMap<String, CaseManagementDelegate> getAppConfigs() {
		return appConfigs;
	}

	public void setAppConfigs(HashMap<String, CaseManagementDelegate> appConfigs) {
		this.appConfigs = appConfigs;
	}

	public ResponseList doTaskSearch(TaskSearch taskSearch) throws InterruptedException, ExecutionException {
		LOG.info("Initiating " + taskSearch.getUid() + " : " + taskSearch.getTaskStatus() + " for PINS : "
				+ Arrays.toString(taskSearch.getPins().toArray()));
		ResponseList responseList = new ResponseList();

		HashMap<String, CaseManagementDelegate> configApps = getAppConfigs();
		List<Callable<List<NigoTask>>> searchCases = new ArrayList<Callable<List<NigoTask>>>();

		List<String> bpmPlatforms = taskSearch.getAppNames();
		if (bpmPlatforms != null) {
			for (String bpmPlatform : bpmPlatforms) {
				Callable<List<NigoTask>> searchInvoker = new SearchInvoker(configApps.get(bpmPlatform.toLowerCase()),
						taskSearch);
				searchCases.add(searchInvoker);

			}
		} else {
			Collection<CaseManagementDelegate> caseManagementDelegateList = configApps.values();

			if (caseManagementDelegateList != null) {
				for (CaseManagementDelegate cmDelegate : caseManagementDelegateList) {
					SearchInvoker searchInvoker = new SearchInvoker(cmDelegate, taskSearch);
					searchCases.add(searchInvoker);
				}
			}

		}

		List<Future<List<NigoTask>>> results = null;
		List<NigoTask> combinedSearchResult = new ArrayList<NigoTask>();
		ExecutorService executor = Executors.newFixedThreadPool(searchCases.size());
		try {
			results = executor.invokeAll(searchCases);
			for (Future<List<NigoTask>> future : results) {
				List<NigoTask> resultList = null;
				try {
					resultList = future.get();
				} catch (CancellationException e) {
					LOG.error("CancellationException: " + future.toString()
							+ " didnot return results within configured time");
				}
				if ((resultList != null) && (!resultList.isEmpty())) {
					combinedSearchResult.addAll(resultList);
				}
			}
		} catch (InterruptedException e) {
			LOG.error("InterruptedException: " + e.getMessage());
			throw e;
		} catch (NullPointerException e) {
			LOG.error("NullPointerException: " + e.getMessage());
			throw e;
		} finally {
			if (executor != null) {
				executor.shutdown();
			}
		}
		// combinedSearchResult = taskSearchHelper.nigosearch(taskSearch,
		// combinedSearchResult);
		responseList.setStart(1);
		responseList.setEnd(combinedSearchResult.size());
		responseList.setTotalRecords(combinedSearchResult.size());
		responseList.setResults(combinedSearchResult);
		LOG.info("End of " + taskSearch.getUid());
		return responseList;
	}

	private class SearchInvoker implements Callable<List<NigoTask>> {
		private CaseManagementDelegate caseManagementDelegate;
		private TaskSearch taskSearch;

		public SearchInvoker(CaseManagementDelegate caseManagementDelegate, TaskSearch taskSearch) {
			this.caseManagementDelegate = caseManagementDelegate;
			this.taskSearch = taskSearch;
		}

		@Override
		public List<NigoTask> call() throws Exception {
			LOG.debug("Invoking search for appName:" + caseManagementDelegate.toString());
			List<NigoTask> taskList = caseManagementDelegate.doTaskSearch(taskSearch);
			return taskList;

		}
	}

	public PingResponse ping(HttpServletRequest request) throws UnknownHostException {
		DateFormat dateFormat = new SimpleDateFormat(CommonConstants.MMDDYYYY12HR);
		boolean healthFlag = true;
		PingResponse pingResponse = new PingResponse();
		InetAddress ip = InetAddress.getLocalHost();
		pingResponse.setService(request.getContextPath().substring(1));
		pingResponse.setPingDateTime(dateFormat.format(new Date()));
		pingResponse.setIpaddress(ip.getHostAddress());
		pingResponse.setHostName(ip.getHostName());
		Components components = new Components();
		try {
			cmRepotingDataSource.getConnection();
		} catch (Exception e) {
			healthFlag = false;
			components.setVcase_ds(e.getMessage());
		}

		try {
			expagDataSource.getConnection();
		} catch (Exception e) {
			healthFlag = false;
			components.setExpag_ds(e.getMessage());
		}

		if (healthFlag) {
			pingResponse.setHealthCheck("SUCCESS");
		} else {
			pingResponse.setHealthCheck("FAILURE");
		}

		pingResponse.setComponents(components);
		return pingResponse;
	}
}
