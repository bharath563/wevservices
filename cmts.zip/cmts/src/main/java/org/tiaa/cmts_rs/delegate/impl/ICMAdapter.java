package org.tiaa.cmts_rs.delegate.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Repository;

import org.tiaa.cmts_rs.delegate.CaseManagementDelegate;
import org.tiaa.cmts_rs.domain.NigoTask;
import org.tiaa.cmts_rs.domain.TaskSearch;
import org.tiaa.cmts_rs.impl.SchedulerImpl;

@Repository(value = "icmAdapter")
@Configuration
@EnableCaching
public class ICMAdapter implements CaseManagementDelegate {

	static Logger LOG = Logger.getLogger(ICMAdapter.class);

	@Autowired
	private SchedulerImpl schedulerImpl;

	@Bean
	public CacheManager cacheManager() {
		return new ConcurrentMapCacheManager("directory");
	}

	@Override
	public List<NigoTask> doTaskSearch(TaskSearch taskSearch) {

		List<NigoTask> resTaskList = new ArrayList<NigoTask>();
		List<NigoTask> taskList = null;
		List<String> reqpins = taskSearch.getPins();

		if (taskSearch.getPins() != null) {
			try {
				// taskList = this.icmDAO.getICMSearchResults(taskSearch);

				// SimpleCacheManager cacheManager = new SimpleCacheManager();
				// cacheManager.setCaches(Arrays.asList(new
				// ConcurrentMapCache("directory")));
				// cacheManager.getCache("directory"));
				LOG.info("executing icmadapter calling Cache to return NIGO tasks:" + taskSearch.getUid());
				if (taskSearch.getTaskStatus().equalsIgnoreCase("Open")) {
					taskList = schedulerImpl.getOpenTasks();
				} else if (taskSearch.getTaskStatus().equalsIgnoreCase("Closed")) {
					taskList = schedulerImpl.getClosedTasks();
				}

				for (NigoTask nigoTask : taskList) {
					if (reqpins.contains(nigoTask.getPin())) {
						resTaskList.add(nigoTask);
					}
				}
				LOG.info("Completed constructing ICM response for :" + taskSearch.getUid());
			} catch (Exception e) {
				LOG.error(e.getMessage());
			}
		}
		return resTaskList;
	}

}
