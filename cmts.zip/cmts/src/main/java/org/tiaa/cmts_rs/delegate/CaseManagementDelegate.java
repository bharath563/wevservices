package org.tiaa.cmts_rs.delegate;

import java.util.List;

import org.tiaa.cmts_rs.domain.NigoTask;
import org.tiaa.cmts_rs.domain.TaskSearch;

public interface CaseManagementDelegate {

	List<NigoTask> doTaskSearch(TaskSearch taskSearch);

}
