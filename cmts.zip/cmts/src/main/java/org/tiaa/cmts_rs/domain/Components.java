package org.tiaa.cmts_rs.domain;

public class Components {
	private String vcase_ds = "SUCCESS";
	private String expag_ds = "SUCCESS";

	public String getVcase_ds() {
		return vcase_ds;
	}

	public void setVcase_ds(String vcase_ds) {
		this.vcase_ds = vcase_ds;
	}

	public String getExpag_ds() {
		return expag_ds;
	}

	public void setExpag_ds(String expag_ds) {
		this.expag_ds = expag_ds;
	}

}
