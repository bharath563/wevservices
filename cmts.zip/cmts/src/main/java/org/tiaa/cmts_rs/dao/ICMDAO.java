package org.tiaa.cmts_rs.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.cmts_rs.constant.CommonConstants;
import org.tiaa.cmts_rs.domain.NigoTask;
import org.tiaa.cmts_rs.domain.TaskSearch;

@Component
public class ICMDAO {

	static Logger LOG = Logger.getLogger(ICMDAO.class);

	@Autowired
	private DataSource cmRepotingDataSource;

	public List<NigoTask> getICMSearchResults(TaskSearch taskSearch) throws Exception {
		Connection con = null;
		CallableStatement call = null;
		ResultSet rs = null;

		List<NigoTask> taskList = new ArrayList<NigoTask>();
		try {
			// Start calculating the received date time stamp using no of days
			// from UI input

			List<String> reqpins = taskSearch.getPins();
			int noOfDays = Integer.parseInt(taskSearch.getDays());
			Calendar c = new GregorianCalendar();
			c.add(Calendar.DATE, -noOfDays);
			Date d = c.getTime();
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy hh.mm.ss.SS a");
			// 16-MAR-17 01.55.00.000000000 PM
			// String receivedDateStr = sdf.format(d);
			con = this.cmRepotingDataSource.getConnection();
			call = con.prepareCall("BEGIN CMREPORTING.NIGODESKTOPCASEMANAGER(?,?,?); END;");
			call.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);// search_recordset
			call.setString(2, taskSearch.getTaskStatus());
			call.setString(3, sdf.format(d));
			LOG.info("Start of ICM DB call for " + taskSearch.getUid());
			call.execute();
			LOG.info("End of ICM DB call for " + taskSearch.getUid());
			rs = (ResultSet) call.getObject(1);
			long conStartTime = System.currentTimeMillis();
			if (rs != null) {
				while (rs.next()) {
					if (reqpins.contains(rs.getString("TID").trim())) {
						NigoTask task = new NigoTask();
						String sol_name = null;
						String tsk_display_name = null;
						if (rs.getString("Case_Id") != null) {
							task.setProcessId(rs.getString("Case_Id").trim());
						}
						if (rs.getString("Solution_Name") != null) {
							sol_name = rs.getString("Solution_Name").trim();
							task.setDepartment(sol_name);
						}
						if (rs.getString("Solution_Name") != null) {
							task.setDepartmentDescription(rs.getString("Solution_Name").trim());
						}
						if (rs.getString("TID") != null) {
							task.setPin(rs.getString("TID").trim());
						}

						if (rs.getString("CASE_TYPE_NAME") != null) {
							task.setRequestType(rs.getString("CASE_TYPE_NAME").trim());
						}

						if (rs.getString("Task_Id") != null) {
							task.setTaskId(rs.getString("Task_Id").trim());
						}
						if (rs.getString("Request_Id") != null) {
							task.setRequestId(rs.getString("Request_Id").trim());
						}

						if (rs.getTimestamp("REQ_RECEIVED_TS") != null) {

							task.setCaseReceivedDate(CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a
									.format(rs.getTimestamp("REQ_RECEIVED_TS")));
						}
						if (rs.getTimestamp("CASE_STARTED_TS") != null) {

							task.setCaseCreatedDate(CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a
									.format(rs.getTimestamp("CASE_STARTED_TS")));
						}

						if (rs.getTimestamp("CASE_COMPLETED_TS") != null) {

							task.setCaseCompletedDate(CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a
									.format(rs.getTimestamp("CASE_COMPLETED_TS")));
						}

						if (rs.getString("Task_Display_Name") != null) {
							tsk_display_name = rs.getString("Task_Display_Name").trim();
							task.setTaskName(rs.getString("Task_Display_Name").trim());
						}
						if (rs.getTimestamp("Task_Started_Ts") != null) {
							task.setTaskCreatedDate(CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a
									.format(rs.getTimestamp("Task_Started_Ts")));
						}
						if (rs.getTimestamp("Task_Completed_Ts") != null) {
							task.setTaskCompletedDate(CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a
									.format(rs.getTimestamp("Task_Completed_Ts")));
						}
						if (((sol_name.equalsIgnoreCase("Payout Operations")
								&& tsk_display_name.equalsIgnoreCase("Awaiting Customer Clarification"))
								|| sol_name.equalsIgnoreCase("Brokerage Operations")
								|| sol_name.equalsIgnoreCase("Participant Onboarding Operations"))
								&& (rs.getString("MORCH_ID") != null)) {
							task.setOrchestrationId(rs.getString("MORCH_ID").trim());
						} else {
							task.setOrchestrationId(rs.getString("ORDER_NUM").trim());
						}
						if (taskSearch.getTaskStatus().equalsIgnoreCase("Open")) {
							if (rs.getString("ASSIGNED_TO") != null) {
								task.setAssignedTo(rs.getString("ASSIGNED_TO").trim());
							}
						}
						if (rs.getString("STATUS_NAME") != null) {
							String icmtskStatus = rs.getString("STATUS_NAME").trim();
							if (taskSearch.getTaskStatus().equalsIgnoreCase("Open")
									&& (rs.getTimestamp("SUSPENDED_AT_TS") != null)
									&& (rs.getTimestamp("RESUMED_AT_TS") == null)) {
								icmtskStatus = "Pended";
							}
							task.setStatus(icmtskStatus);
						}

						task.setAppName(CommonConstants.APP_ICM);
						taskList.add(task);
					}
				}
			}
			LOG.info("Time taken to create ICM Response for " + taskSearch.getUid() + " : "
					+ (System.currentTimeMillis() - conStartTime));

		} catch (SQLException e) {
			LOG.error("Exception in sqlPackageSearch " + e.getMessage());
			throw e;
		} catch (Exception e) {
			LOG.error("Exception in ICMDAO while constructing response : " + e.getMessage());
			throw e;
		} finally {
			if (call != null) {
				call.close();
			}
			if (con != null) {
				con.close();
			}
			if (rs != null) {
				rs.close();
			}
		}
		return taskList;
	}
}
