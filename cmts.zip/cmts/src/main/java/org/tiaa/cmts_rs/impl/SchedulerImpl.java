package org.tiaa.cmts_rs.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import org.tiaa.cmts_rs.constant.CommonConstants;
import org.tiaa.cmts_rs.domain.NigoTask;

@Component
@EnableScheduling
public class SchedulerImpl {

	@Autowired
	private DataSource cmRepotingDataSource;

	@Autowired
	private DataSource expagDataSource;

	static Logger LOG = Logger.getLogger(SchedulerImpl.class);

	List<NigoTask> openTaskList = new ArrayList<NigoTask>();
	List<NigoTask> closedTaskList = new ArrayList<NigoTask>();

	List<NigoTask> openExpagTaskList = new ArrayList<NigoTask>();
	List<NigoTask> closedExpagTaskList = new ArrayList<NigoTask>();

	int openNoOfDays = 360; // 60
	int closedNoOfDays = 180; // 30
	String openTaskStatus = "Open";
	String closedTaskStatus = "Closed";

	@Scheduled(fixedRate = 1800000)
	public void run() throws Exception {
		LOG.info("Scheduler will execute every 30 mins. Current time is :: " + new Date());
		// Declaring DB Connections, CallableStatements and Result sets for both
		// ICM and EXPAG
		Connection con = null;
		CallableStatement call = null;
		ResultSet rs = null;
		Connection con2 = null;
		CallableStatement call2 = null;
		ResultSet rs2 = null;
		Connection expagCon1 = null;
		CallableStatement expagCall1 = null;
		ResultSet expagOpenRS = null;
		Connection expagCon2 = null;
		CallableStatement expagCall2 = null;
		ResultSet expagClosedRS = null;

		List<NigoTask> openTaskListScheduler = null;
		List<NigoTask> closedTaskListScheduler = null;
		List<NigoTask> expagClosedTaskListScheduler = null;
		List<NigoTask> expagOpenTaskListScheduler = null;

		// ICM Open Tasks Retrieval
		try {
			openTaskListScheduler = new ArrayList<NigoTask>();
			Calendar c = new GregorianCalendar();
			c.add(Calendar.DATE, -openNoOfDays);
			Date d = c.getTime();
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy hh.mm.ss.SS a");
			// 16-MAR-17 01.55.00.000000000 PM
			// String receivedDateStr = sdf.format(d);

			con = this.cmRepotingDataSource.getConnection();
			call = con.prepareCall("BEGIN CMREPORTING.NIGODESKTOPCASEMANAGER(?,?,?); END;");
			call.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);// search_recordset
			call.setString(2, openTaskStatus);
			call.setString(3, sdf.format(d));
			call.execute();
			rs = (ResultSet) call.getObject(1);
			while (rs.next()) {
				NigoTask task = new NigoTask();
				String sol_name = null;
				String tsk_display_name = null;
				if (rs.getString("Case_Id") != null) {
					task.setProcessId(rs.getString("Case_Id").trim());
				}
				if (rs.getString("Solution_Name") != null) {
					sol_name = rs.getString("Solution_Name").trim();
					task.setDepartment(sol_name);
				}
				if (rs.getString("Solution_Name") != null) {
					task.setDepartmentDescription(rs.getString("Solution_Name").trim());
				}
				if (rs.getString("Tid") != null) {
					task.setPin(rs.getString("Tid").trim());
				}

				if (rs.getString("Case_Type_Name") != null) {
					task.setRequestType(rs.getString("Case_Type_Name").trim());
				}
				if (rs.getString("Task_Id") != null) {
					task.setTaskId(rs.getString("Task_Id").trim());
				}
				if (rs.getString("Request_Id") != null) {
					task.setRequestId(rs.getString("Request_Id").trim());
				}
				if (rs.getTimestamp("Req_Received_Ts") != null) {
					task.setCaseReceivedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs.getTimestamp("Req_Received_Ts")));
				}
				if (rs.getTimestamp("Case_Started_Ts") != null) {
					task.setCaseCreatedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs.getTimestamp("Case_Started_Ts")));
				}
				if (rs.getTimestamp("Case_Completed_Ts") != null) {
					task.setCaseCompletedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs.getTimestamp("Case_Completed_Ts")));
				}
				if (rs.getString("Task_Display_Name") != null) {
					tsk_display_name = rs.getString("Task_Display_Name").trim();
					task.setTaskName(rs.getString("Task_Display_Name").trim());
				}
				if (rs.getTimestamp("Task_Started_Ts") != null) {
					task.setTaskCreatedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs.getTimestamp("Task_Started_Ts")));
				}
				if (rs.getTimestamp("Task_Completed_Ts") != null) {
					task.setTaskCompletedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs.getTimestamp("Task_Completed_Ts")));
				}
				if (((sol_name.equalsIgnoreCase("Payout Operations")
						&& tsk_display_name.equalsIgnoreCase("Awaiting Customer Clarification"))
						|| sol_name.equalsIgnoreCase("Brokerage Operations")
						|| sol_name.equalsIgnoreCase("Participant Onboarding Operations"))
						&& (rs.getString("Morch_Id") != null)) {
					task.setOrchestrationId(rs.getString("Morch_Id").trim());
				} else {
					if (rs.getString("ORDER_NUM") != null) {
						task.setOrchestrationId(rs.getString("ORDER_NUM").trim());
					}
				}
				if (openTaskStatus.equalsIgnoreCase("Open")) {
					if (rs.getString("Assigned_To") != null) {
						task.setAssignedTo(rs.getString("Assigned_To").trim());
					}
				}
				if (rs.getString("Status_Name") != null) {
					String icmtskStatus = rs.getString("Status_Name").trim();
					if (openTaskStatus.equalsIgnoreCase("Open") && (rs.getTimestamp("SUSPENDED_AT_TS") != null)
							&& (rs.getTimestamp("RESUMED_AT_TS") == null)) {
						icmtskStatus = "Pended";
					}
					task.setStatus(icmtskStatus);
				}

				task.setAppName(CommonConstants.APP_ICM);
				openTaskListScheduler.add(task);

			}

			setOpenTasks(openTaskListScheduler);
			LOG.info("ICM opentaskList size when scheduler is invoked:" + openTaskListScheduler.size());

		} catch (

		SQLException e) {
			LOG.error("ICM Exception in sqlPackageSearch " + e.getMessage());
			throw e;
		} catch (Exception e) {
			LOG.error("ICM Exception in OPen Tasks ICMDAO while constructing response : " + e.getMessage());
			throw e;
		} finally {
			if (call != null) {
				call.close();
			}
			if (con != null) {
				con.close();
			}
			if (rs != null) {
				rs.close();
			}
		}

		// ICM Closed Tasks Retrieval
		try {
			closedTaskListScheduler = new ArrayList<NigoTask>();

			Calendar c2 = new GregorianCalendar();
			c2.add(Calendar.DATE, -closedNoOfDays);
			Date d2 = c2.getTime();
			SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MMM-yy hh.mm.ss.SS a");
			// 16-MAR-17 01.55.00.000000000 PM //
			con2 = this.cmRepotingDataSource.getConnection();
			call2 = con2.prepareCall("BEGIN CMREPORTING.NIGODESKTOPCASEMANAGER(?,?,?); END;");
			call2.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
			// search_recordset
			call2.setString(2, closedTaskStatus);
			call2.setString(3, sdf2.format(d2));
			call2.execute();
			rs2 = (ResultSet) call2.getObject(1);
			while (rs2.next()) {
				NigoTask task = new NigoTask();
				String sol_name = null;
				String tsk_display_name = null;
				if (rs2.getString("Case_Id") != null) {
					task.setProcessId(rs2.getString("Case_Id").trim());
				}
				if (rs2.getString("Solution_Name") != null) {
					sol_name = rs2.getString("Solution_Name").trim();
					task.setDepartment(sol_name);
				}
				if (rs2.getString("Solution_Name") != null) {
					task.setDepartmentDescription(rs2.getString("Solution_Name").trim());
				}
				if (rs2.getString("Tid") != null) {
					task.setPin(rs2.getString("Tid").trim());
				}

				if (rs2.getString("Case_Type_Name") != null) {
					task.setRequestType(rs2.getString("Case_Type_Name").trim());
				}
				if (rs2.getString("Task_Id") != null) {
					task.setTaskId(rs2.getString("Task_Id").trim());
				}
				if (rs2.getString("Request_Id") != null) {
					task.setRequestId(rs2.getString("Request_Id").trim());
				}
				if (rs2.getTimestamp("Req_Received_Ts") != null) {
					task.setCaseReceivedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs2.getTimestamp("Req_Received_Ts")));
				}
				if (rs2.getTimestamp("Case_Started_Ts") != null) {
					task.setCaseCreatedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs2.getTimestamp("Case_Started_Ts")));
				}
				if (rs2.getTimestamp("Case_Completed_Ts") != null) {
					task.setCaseCompletedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs2.getTimestamp("Case_Completed_Ts")));
				}
				if (rs2.getString("Task_Display_Name") != null) {
					tsk_display_name = rs2.getString("Task_Display_Name").trim();
					task.setTaskName(rs2.getString("Task_Display_Name").trim());
				}
				if (rs2.getTimestamp("Task_Started_Ts") != null) {
					task.setTaskCreatedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs2.getTimestamp("Task_Started_Ts")));
				}
				if (rs2.getTimestamp("Task_Completed_Ts") != null) {
					task.setTaskCompletedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(rs2.getTimestamp("Task_Completed_Ts")));
				}
				if (((sol_name.equalsIgnoreCase("Payout Operations")
						&& tsk_display_name.equalsIgnoreCase("Awaiting Customer Clarification"))
						|| sol_name.equalsIgnoreCase("Brokerage Operations")
						|| sol_name.equalsIgnoreCase("Participant Onboarding Operations"))
						&& (rs2.getString("Morch_Id") != null)) {
					task.setOrchestrationId(rs2.getString("Morch_Id").trim());
				} else {
					if (rs2.getString("ORDER_NUM") != null) {
						task.setOrchestrationId(rs2.getString("ORDER_NUM").trim());
					}
				}

				if (rs2.getString("Status_Name") != null) {
					task.setStatus(rs2.getString("Status_Name"));
				}

				task.setAppName(CommonConstants.APP_ICM);
				closedTaskListScheduler.add(task);

			}
			setClosedTasks(closedTaskListScheduler);
			LOG.info("ICM closedtaskList size when scheduler is invoked:" + closedTaskListScheduler.size());
		} catch (SQLException e) {
			LOG.error("Exception in sqlPackageSearch " + e.getMessage());
			throw e;
		} catch (Exception e) {
			LOG.error("Exception in Closed Tasks ICMDAO while constructing response : " + e.getMessage());
			throw e;
		} finally {
			if (call2 != null) {
				call2.close();
			}
			if (con2 != null) {
				con2.close();
			}
			if (rs2 != null) {
				rs2.close();
			}
		}

		// EXPAG Open Tasks Retrieval
		try {
			expagOpenTaskListScheduler = new ArrayList<NigoTask>();

			LOG.info("EXPAG Scheduler getting connection for Open tasks : " + new Date());

			expagCon1 = this.expagDataSource.getConnection();

			expagCall1 = expagCon1.prepareCall("BEGIN PIMITEK.MYDESKTOP_NIGO_SEARCH(?,?,?,?); END;");
			expagCall1.setString(1, openTaskStatus);
			expagCall1.setInt(2, openNoOfDays);
			expagCall1.registerOutParameter(3, oracle.jdbc.OracleTypes.NUMBER);// total
																				// count
			expagCall1.registerOutParameter(4, oracle.jdbc.OracleTypes.CURSOR);// search_recordset
			expagCall1.execute();
			int resultcount = expagCall1.getInt(3);
			expagOpenRS = (ResultSet) expagCall1.getObject(4);
			LOG.info("EXPAG Scheduler Result Set Retrieved for Open Tasks: " + new Date());
			while (expagOpenRS.next()) {
				LOG.info("EXPAG Scheduler Result Set Looping for Open Tasks: " + new Date());
				NigoTask task = new NigoTask();
				if (expagOpenRS.getString("pktid") != null) {
					task.setProcessId(expagOpenRS.getString("pktid").trim());
				}
				if (expagOpenRS.getString("tskid") != null) {
					task.setTaskId(expagOpenRS.getString("tskid").trim());
				}
				if (expagOpenRS.getString("tasktype") != null) {
					task.setTaskType(expagOpenRS.getString("tasktype").trim());
				}
				if (expagOpenRS.getString("department") != null) {
					task.setDepartment(expagOpenRS.getString("department").trim());
				}
				if (expagOpenRS.getString("DPTLNGNAME") != null) {
					task.setDepartmentDescription(expagOpenRS.getString("DPTLNGNAME").trim());
				}
				if (expagOpenRS.getString("taskdescription") != null) {
					task.setTaskName(expagOpenRS.getString("taskdescription").trim());
				}

				if (expagOpenRS.getString("ASSIGNEDTO") != null) {
					task.setAssignedTo(expagOpenRS.getString("ASSIGNEDTO").trim());
				}

				if (expagOpenRS.getString("pin") != null) {
					task.setPin(expagOpenRS.getString("pin").trim());
				}
				if (expagOpenRS.getTimestamp("created") != null) {
					task.setTaskCreatedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(expagOpenRS.getTimestamp("created")));
				}
				if (expagOpenRS.getTimestamp("RECEIVED") != null) {
					task.setTaskReceivedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(expagOpenRS.getTimestamp("RECEIVED")));
				}
				if (expagOpenRS.getTimestamp("lastupdated") != null) {
					task.setTaskLastUpdatedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(expagOpenRS.getTimestamp("lastupdated")));
				}
				if (expagOpenRS.getTimestamp("COMPLETED") != null) {
					task.setTaskCompletedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(expagOpenRS.getTimestamp("COMPLETED")));
				}

				if (expagOpenRS.getString("status") != null) {
					task.setStatus(expagOpenRS.getString("status").trim());

				}
				task.setAppName(CommonConstants.APP_EXPAG);
				expagOpenTaskListScheduler.add(task);
			}
			setOpenEXPAGTasks(expagOpenTaskListScheduler);
			LOG.info("OpentaskList size when ExpagScheduler is invoked:" + expagOpenTaskListScheduler.size());

		} catch (SQLException e) {
			LOG.error("Exception in Open expag sqlPackageSearch " + e.getMessage());
			throw e;
		} catch (Exception e) {
			LOG.error("Exception in Open Expag Tasks while constructing response : " + e.getMessage());
			throw e;
		} finally {
			if (expagCall1 != null) {
				expagCall1.close();
			}
			if (expagCon1 != null) {
				expagCon1.close();
			}
			if (expagOpenRS != null) {
				expagOpenRS.close();
			}
		}

		// EXPAG Closed Tasks Retrieval
		try {
			expagClosedTaskListScheduler = new ArrayList<NigoTask>();
			LOG.info("EXPAG Scheduler getting connection for closed tasks : " + new Date());
			expagCon2 = this.expagDataSource.getConnection();
			expagCall2 = expagCon2.prepareCall("BEGIN PIMITEK.MYDESKTOP_NIGO_SEARCH(?,?,?,?); END;");
			expagCall2.setString(1, closedTaskStatus);
			expagCall2.setInt(2, closedNoOfDays);
			expagCall2.registerOutParameter(3, oracle.jdbc.OracleTypes.NUMBER);// total
																				// count
			expagCall2.registerOutParameter(4, oracle.jdbc.OracleTypes.CURSOR);// search_recordset
			expagCall2.execute();
			int resultcount = expagCall2.getInt(3);
			expagClosedRS = (ResultSet) expagCall2.getObject(4);
			LOG.info("EXPAG Scheduler Result Set retrieved for Closed Tasks: " + new Date());
			while (expagClosedRS.next()) {
				LOG.info("EXPAG Scheduler Result Set Looping for Closed Tasks: " + new Date());
				NigoTask task = new NigoTask();
				if (expagClosedRS.getString("pktid") != null) {
					task.setProcessId(expagClosedRS.getString("pktid").trim());
				}
				if (expagClosedRS.getString("tskid") != null) {
					task.setTaskId(expagClosedRS.getString("tskid").trim());
				}
				if (expagClosedRS.getString("tasktype") != null) {
					task.setTaskType(expagClosedRS.getString("tasktype").trim());
				}
				if (expagClosedRS.getString("department") != null) {
					task.setDepartment(expagClosedRS.getString("department").trim());
				}
				if (expagClosedRS.getString("DPTLNGNAME") != null) {
					task.setDepartmentDescription(expagClosedRS.getString("DPTLNGNAME").trim());
				}
				if (expagClosedRS.getString("taskdescription") != null) {
					task.setTaskName(expagClosedRS.getString("taskdescription").trim());
				}

				if (expagClosedRS.getString("ASSIGNEDTO") != null) {
					task.setAssignedTo(expagClosedRS.getString("ASSIGNEDTO").trim());
				}

				if (expagClosedRS.getString("pin") != null) {
					task.setPin(expagClosedRS.getString("pin").trim());
				}
				if (expagClosedRS.getTimestamp("created") != null) {
					task.setTaskCreatedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(expagClosedRS.getTimestamp("created")));
				}
				if (expagClosedRS.getTimestamp("RECEIVED") != null) {
					task.setTaskReceivedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(expagClosedRS.getTimestamp("RECEIVED")));
				}
				if (expagClosedRS.getTimestamp("lastupdated") != null) {
					task.setTaskLastUpdatedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(expagClosedRS.getTimestamp("lastupdated")));
				}
				if (expagClosedRS.getTimestamp("COMPLETED") != null) {
					task.setTaskCompletedDate(
							CommonConstants.DF_MM_dd_yyyy_hh_mm_ss_a.format(expagClosedRS.getTimestamp("COMPLETED")));
				}

				if (expagClosedRS.getString("status") != null) {
					task.setStatus(expagClosedRS.getString("status").trim());

				}
				task.setAppName(CommonConstants.APP_EXPAG);
				expagClosedTaskListScheduler.add(task);
			}

			setClosedEXPAGTasks(expagClosedTaskListScheduler);
			LOG.info("ClosedtaskList size when ExpagScheduler is invoked:" + expagClosedTaskListScheduler.size());

		} catch (SQLException e) {
			LOG.error("Exception in closed expag sqlPackageSearch " + e.getMessage());
			throw e;
		} catch (Exception e) {
			LOG.error("Exception in EXPAG Closed Tasks while constructing response : " + e.getMessage());
			throw e;
		} finally {
			if (expagCall2 != null) {
				expagCall2.close();
			}
			if (expagCon2 != null) {
				expagCon2.close();
			}
			if (expagClosedRS != null) {
				expagClosedRS.close();
			}
		}

	}

	@CacheEvict(value = "opentasks", beforeInvocation = true)
	@CachePut(value = "opentasks")
	private void setOpenTasks(List<NigoTask> taskList) {
		this.openTaskList = taskList;

	}

	@Cacheable("opentasks")
	public List<NigoTask> getOpenTasks() {
		return openTaskList;
	}

	@CacheEvict(value = "closedtasks", beforeInvocation = true)
	@CachePut(value = "closedtasks")
	private void setClosedTasks(List<NigoTask> taskList2) {
		this.closedTaskList = taskList2;

	}

	@Cacheable("closedtasks")
	public List<NigoTask> getClosedTasks() {
		return closedTaskList;
	}

	@CacheEvict(value = "openexpagtasks", beforeInvocation = true)
	@CachePut(value = "openexpagtasks")
	private void setOpenEXPAGTasks(List<NigoTask> taskList3) {
		this.openExpagTaskList = taskList3;

	}

	@Cacheable("openexpagtasks")
	public List<NigoTask> getOpenEXPAGTasks() {
		return openExpagTaskList;
	}

	@CacheEvict(value = "closedexpagtasks", beforeInvocation = true)
	@CachePut(value = "closedexpagtasks")
	private void setClosedEXPAGTasks(List<NigoTask> taskList4) {
		this.closedExpagTaskList = taskList4;

	}

	@Cacheable("closedexpagtasks")
	public List<NigoTask> getClosedEXPAGTasks() {
		return closedExpagTaskList;
	}

	@Bean
	public CacheManager cacheManager() {
		CacheManager cm = new ConcurrentMapCacheManager("opentasks", "closedtasks", "openexpagtasks",
				"closedexpagtasks");
		return cm;
	}
}