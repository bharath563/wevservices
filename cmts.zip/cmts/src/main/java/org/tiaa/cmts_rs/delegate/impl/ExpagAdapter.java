package org.tiaa.cmts_rs.delegate.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Repository;

import org.tiaa.cmts_rs.delegate.CaseManagementDelegate;
import org.tiaa.cmts_rs.domain.NigoTask;
import org.tiaa.cmts_rs.domain.TaskSearch;
import org.tiaa.cmts_rs.impl.SchedulerImpl;

@Repository(value = "expagAdapter")
public class ExpagAdapter implements CaseManagementDelegate {

	static Logger LOG = Logger.getLogger(ExpagAdapter.class);

	@Autowired
	private SchedulerImpl schedulerImpl;

	@Bean
	public CacheManager cacheManager() {
		return new ConcurrentMapCacheManager("directory");
	}

	@Override
	public List<NigoTask> doTaskSearch(TaskSearch taskSearch) {
		List<NigoTask> resTaskList = new ArrayList<NigoTask>();
		List<NigoTask> taskList = null;
		List<String> reqpins = taskSearch.getPins();

		if (taskSearch.getPins() != null) {
			try {
				// taskList = this.expagDAO.getExpagSearchResults(taskSearch);

				LOG.info("executing ExpagAdapter calling Cache to return NIGO tasks:");
				if (taskSearch.getTaskStatus().equalsIgnoreCase("Open")) {
					taskList = schedulerImpl.getOpenEXPAGTasks();
					LOG.info("open EXPAG tasklist size :" + taskList.size() + taskSearch.getUid());
				} else if (taskSearch.getTaskStatus().equalsIgnoreCase("Closed")) {
					taskList = schedulerImpl.getClosedEXPAGTasks();
					LOG.info("closed EXPAG tasklist size:" + taskList.size() + taskSearch.getUid());
				}

				for (NigoTask nigoTask : taskList) {
					if (reqpins.contains(nigoTask.getPin())) {
						resTaskList.add(nigoTask);
					}
				}
				LOG.info("Completed constructing EXPAG response for :" + taskSearch.getUid());
			} catch (Exception e) {
				LOG.error(e.getMessage());
			}
		}
		return resTaskList;
	}

}
