package org.tiaa.cmts_rs.domain;

import java.util.HashMap;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

import org.tiaa.cmts_rs.constant.CommonConstants;

@JsonSerialize(include = Inclusion.NON_NULL)
public class NigoTask {

	private String processId;
	private String requestType;
	private String taskId;
	private String taskType;
	private String taskName;
	private String department;
	private String departmentDescription;
	private String caseCreatedDate;
	private String caseCompletedDate;
	private String caseModifiedDate;
	private String caseReceivedDate;
	private String requestId;
	private String taskLastUpdatedDate;
	private String taskReceivedDate;
	private String status;
	private String taskCreatedDate;
	private String taskCompletedDate;
	private String slaDetail;
	private String AssignedTo;
	private String orchestrationId;
	private String pin;
	private String appName;
	private int totalRecords;
	private HashMap<String, Object> processIdentifiers;
	private HashMap<String, Object> taskDetails;
	private String solution;

	@JsonIgnore
	public String getCaseReceivedDate() {
		return caseReceivedDate;
	}

	@JsonIgnore
	public void setCaseReceivedDate(String caseReceivedDate) {
		this.caseReceivedDate = caseReceivedDate;
	}

	@JsonIgnore
	public String getCaseCreatedDate() {
		return caseCreatedDate;
	}

	@JsonIgnore
	public void setCaseCreatedDate(String caseCreatedDate) {
		this.caseCreatedDate = caseCreatedDate;
	}

	@JsonIgnore
	public String getCaseCompletedDate() {
		return caseCompletedDate;
	}

	@JsonIgnore
	public void setCaseCompletedDate(String caseCompletedDate) {
		this.caseCompletedDate = caseCompletedDate;
	}

	@JsonIgnore
	public String getTaskReceivedDate() {

		return taskReceivedDate;
	}

	@JsonIgnore
	public void setTaskReceivedDate(String taskReceivedDate) {
		this.taskReceivedDate = taskReceivedDate;
	}

	@JsonIgnore
	public String getStatus() {
		return status;
	}

	@JsonIgnore
	public void setStatus(String caseStatus) {
		this.status = caseStatus;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	@JsonIgnore
	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}

	@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
	public HashMap<String, Object> getProcessIdentifiers() {
		if ((processIdentifiers == null) && !getAppName().equalsIgnoreCase(CommonConstants.APP_EXPAG)) {
			processIdentifiers = new HashMap<String, Object>();
			processIdentifiers.put("requestId", getRequestId());
			processIdentifiers.put("orchestrationId", getOrchestrationId());
			processIdentifiers.put("caseCreatedDate", getCaseCreatedDate());
			processIdentifiers.put("caseCompletedDate", getCaseCompletedDate());
			processIdentifiers.put("caseReceivedDate", getCaseReceivedDate());
			processIdentifiers.put("caseModifiedDate", getCaseModifiedDate());
			// processIdentifiers.put("requestType", getRequestType());
		}
		return processIdentifiers;
	}

	public void setProcessdentifiers(HashMap<String, Object> processIdentifiers) {
		this.processIdentifiers = processIdentifiers;
	}

	@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
	public HashMap<String, Object> getTaskDetails() {
		if (taskDetails == null) {
			taskDetails = new HashMap<String, Object>();
			taskDetails.put("taskId", getTaskId());
			taskDetails.put("taskName", getTaskName());
			taskDetails.put("taskType", getTaskType());
			taskDetails.put("taskCreatedDate", getTaskCreatedDate());
			taskDetails.put("taskCompletedDate", getTaskCompletedDate());
			taskDetails.put("taskLastUpdatedDate", getTaskLastUpdatedDate());
			taskDetails.put("taskReceivedDate", getTaskReceivedDate());
			taskDetails.put("assignedTo", getAssignedTo());
			taskDetails.put("slaDetail", getSlaDetail());
			taskDetails.put("status", getStatus());
		}
		return taskDetails;
	}

	public void setTaskDetails(HashMap<String, Object> taskDetails) {
		this.taskDetails = taskDetails;
	}

	@JsonIgnore
	public int getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	@JsonIgnore
	public String getTaskId() {
		return taskId;
	}

	@JsonIgnore
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	@JsonIgnore
	public String getTaskType() {
		return taskType;
	}

	@JsonIgnore
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	@JsonIgnore
	public String getTaskName() {
		return taskName;
	}

	@JsonIgnore
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDepartmentDescription() {
		return departmentDescription;
	}

	public void setDepartmentDescription(String departmentDescription) {
		this.departmentDescription = departmentDescription;
	}

	@JsonIgnore
	public String getSlaDetail() {
		return slaDetail;
	}

	@JsonIgnore
	public void setSlaDetail(String slaDetail) {
		this.slaDetail = slaDetail;
	}

	@JsonIgnore
	public String getAssignedTo() {
		return AssignedTo;
	}

	@JsonIgnore
	public void setAssignedTo(String assignedTo) {
		AssignedTo = assignedTo;
	}

	@JsonIgnore
	public String getOrchestrationId() {
		return orchestrationId;
	}

	@JsonIgnore
	public void setOrchestrationId(String orchestrationId) {
		this.orchestrationId = orchestrationId;
	}

	@JsonIgnore
	public String getRequestId() {
		return requestId;
	}

	@JsonIgnore
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	@JsonIgnore
	public String getTaskCreatedDate() {
		return taskCreatedDate;
	}

	@JsonIgnore
	public void setTaskCreatedDate(String taskCreatedDate) {
		this.taskCreatedDate = taskCreatedDate;
	}

	@JsonIgnore
	public String getTaskLastUpdatedDate() {
		return taskLastUpdatedDate;
	}

	@JsonIgnore
	public void setTaskLastUpdatedDate(String taskLastUpdatedDate) {
		this.taskLastUpdatedDate = taskLastUpdatedDate;
	}

	@JsonIgnore
	public String getTaskCompletedDate() {
		return taskCompletedDate;
	}

	@JsonIgnore
	public void setTaskCompletedDate(String taskCompletedDate) {
		this.taskCompletedDate = taskCompletedDate;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	@JsonIgnore
	public String getCaseModifiedDate() {
		return caseModifiedDate;
	}

	@JsonIgnore
	public void setCaseModifiedDate(String caseModifiedDate) {
		this.caseModifiedDate = caseModifiedDate;
	}

}
