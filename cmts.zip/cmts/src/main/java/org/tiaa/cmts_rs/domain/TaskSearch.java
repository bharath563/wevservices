package org.tiaa.cmts_rs.domain;

import java.util.List;
import java.util.UUID;

public class TaskSearch {
	private List<String> pins;

	private List<String> appNames;

	private String taskStatus;

	private String days;

	private String uid = "NIGO Task Search :" + UUID.randomUUID().hashCode();

	public List<String> getPins() {
		return pins;
	}

	public void setPins(List<String> pins) {
		this.pins = pins;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public String getDays() {
		return days;
	}

	public void setDays(String string) {
		this.days = string;
	}

	public List<String> getAppNames() {
		return appNames;
	}

	public void setAppNames(List<String> appNames) {
		this.appNames = appNames;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

}