package org.tiaa.cmts_rs.nigo;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.junit.Before;
import org.junit.Test;

import org.springframework.context.support.FileSystemXmlApplicationContext;

import org.tiaa.cmts_rs.domain.ResponseList;
import org.tiaa.cmts_rs.domain.TaskSearch;
import org.tiaa.cmts_rs.impl.CMTSRestServiceImpl;

public class NigoSearchTestCase {

	CMTSRestServiceImpl target;

	@Before
	public void setUp() throws Exception {
		FileSystemXmlApplicationContext context = new FileSystemXmlApplicationContext(
				"src/main/webapp/WEB-INF/applicationContext.xml");
		target = context.getBean(CMTSRestServiceImpl.class);
	}

	@Test
	public void testNigoTaskSearch() throws InterruptedException, ExecutionException {
		TaskSearch taskSearch = new TaskSearch();
		List<String> appNames = new ArrayList<String>();
		List<String> pins = new ArrayList<String>();
		pins.add("6319834");
		pins.add("1231699");
		appNames.add("expag");
		// appNames.add("icm");

		taskSearch.setTaskStatus("Open");
		taskSearch.setDays("60");
		taskSearch.setPins(pins);
		taskSearch.setAppNames(appNames);
		ResponseList responseList = null;
		responseList = target.doTaskSearch(taskSearch);
		System.out.println(responseList);
	}
}
