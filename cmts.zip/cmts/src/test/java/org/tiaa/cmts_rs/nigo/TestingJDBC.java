package org.tiaa.cmts_rs.nigo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

public class TestingJDBC {

	public static void main(String args[]) {
		// Creating the connection
		String url = "jdbc:oracle:thin:@dentsd3dlpx03-scan.test.tiaa-cref.org:1522:NEXPAG20";
		String user = "cmsuser";
		String pass = "atdnsm00";
		Connection expagCon1 = null;
		CallableStatement expagCall1 = null;
		ResultSet expagOpenRS = null;

		// Entering the data
		Connection con = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String dbURL = "jdbc:oracle:thin:@(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=@dentsd3dlpx03-scan.test.tiaa-cref.org)(PORT=1522)))(CONNECT_DATA=(SERVICE_NAME=NEXPAG20)))";
			expagCon1 = DriverManager.getConnection(dbURL, user, pass);
			expagCall1 = expagCon1.prepareCall("BEGIN PIMITEK.MYDESKTOP_NIGO_SEARCH(?,?,?,?); END;");
			expagCall1.setString(1, "Closed");
			expagCall1.setInt(2, 180);
			expagCall1.registerOutParameter(3, oracle.jdbc.OracleTypes.NUMBER);
			expagCall1.registerOutParameter(4, oracle.jdbc.OracleTypes.CURSOR);
			expagCall1.execute();
			int resultcount = expagCall1.getInt(3);
			expagOpenRS = (ResultSet) expagCall1.getObject(4);
			while (expagOpenRS.next()) {
				System.out.println(expagOpenRS.getString("pktid"));
			}

			expagCon1.close();
		} catch (Exception ex) {
			System.err.println(ex);
		}
	}

}
