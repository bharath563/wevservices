package org.tiaa.business.process.serializer;

import junit.framework.Assert;

import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Documents;

@RunWith(MockitoJUnitRunner.class)
public class DocumentSerializerTest {

	DocumentSerializer serializer = new DocumentSerializer();
	Documents documents = new Documents();

	private static final String EMPTY_OBJECT = "[]";
	private static final String POPULATED_OBJECT = "[{\"DocId\":\"id\",\"DocName\":\"docName\",\"DocDesc\":\"docDesc\",\"DocType\":\"docType\"}]";

	@Before
	public void before() {

		Document document = new Document();
		document.setDocID("id");
		document.setDocName("docName");
		document.setDocTyp("docType");
		document.setDocDesc("docDesc");

		this.documents.getDocument().add(document);
	}

	@Test
	public void serializeWithNullValue() {
		Assert.assertEquals(EMPTY_OBJECT, this.serializer.serialize(null));
	}

	@Test
	public void serializeWithEmptyObject() {
		String serializedString = this.serializer.serialize(new Documents());
		Assert.assertNotNull(serializedString);
		Assert.assertEquals(EMPTY_OBJECT, serializedString);
	}

	/*
	 * @Test public void serializeWithValidObject() { String serializedString =
	 * this.serializer.serialize(this.documents);
	 * Assert.assertNotNull(serializedString);
	 * Assert.assertEquals(POPULATED_OBJECT, serializedString); }
	 */
	@Test
	public void deSerializeWithNullValue() {
		Documents response = this.serializer.deSerialize(null);
		Assert.assertNotNull(response);
		Assert.assertEquals(0, response.getDocument().size());
	}

	@Test
	public void deSerializeWithEmptyString() {
		Documents response = this.serializer.deSerialize(EMPTY_OBJECT);
		Assert.assertNotNull(response);
		Assert.assertEquals(0, response.getDocument().size());
	}

	@Test
	public void deSerializeWithValidObject() {
		Documents response = this.serializer.deSerialize(POPULATED_OBJECT);
		Assert.assertNotNull(response);
		Assert.assertEquals(1, response.getDocument().size());

		Assert.assertEquals("id", response.getDocument().get(0).getDocID());
		Assert.assertEquals("docName", response.getDocument().get(0)
				.getDocName());
		Assert.assertEquals("docType", response.getDocument().get(0)
				.getDocTyp());
		Assert.assertEquals("docDesc", response.getDocument().get(0)
				.getDocDesc());
	}

}
