package org.tiaa.business.process.converters;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.datatype.DatatypeConfigurationException;

import junit.framework.Assert;

import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.business.process.util.DateUtil;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.NameValue;

@RunWith(MockitoJUnitRunner.class)
public class NameValueToActivitiVariableConverterTest {

	NameValueToActivitiVariableConverter converter = new NameValueToActivitiVariableConverter();
	NameValue source = new NameValue();

	@Before
	public void before() throws DatatypeConfigurationException {

		this.source.setName("Name");
	}

	@Test
	public void testConverterWithNullValue() {
		Assert.assertNull(this.converter.convert(null));
	}

	@Test
	public void testConverterWithBooleanValue() {
		this.source.setBooleanValue(Boolean.TRUE);
		ActivitiVariable response = this.converter.convert(this.source);
		Assert.assertNotNull(response);
		Assert.assertEquals("Name", response.getName());
		Assert.assertEquals("Boolean", response.getType());
		Assert.assertEquals("true", response.getValue());
	}

	@Test
	public void testConverterWithStringValue() {
		this.source.setValue("StringValue");
		ActivitiVariable response = this.converter.convert(this.source);
		Assert.assertNotNull(response);
		Assert.assertEquals("Name", response.getName());
		Assert.assertEquals("String", response.getType());
		Assert.assertEquals("StringValue", response.getValue());
	}

	@Test
	public void testConverterWithDecimalValue() {
		this.source.setDecimalValue(new BigDecimal("20.3"));
		ActivitiVariable response = this.converter.convert(this.source);
		Assert.assertNotNull(response);
		Assert.assertEquals("Name", response.getName());
		Assert.assertEquals("Decimal", response.getType());
		Assert.assertEquals("20.3", response.getValue());
	}

	@Test
	public void testConverterWithIntegerValue() {
		this.source.setNumValue(new BigInteger("15"));
		ActivitiVariable response = this.converter.convert(this.source);
		Assert.assertNotNull(response);
		Assert.assertEquals("Name", response.getName());
		Assert.assertEquals("Integer", response.getType());
		Assert.assertEquals("15", response.getValue());
	}

	@Test
	public void testConverterWithDateValue() {
		Date currentDate = new Date();
		this.source.setDateValue(DateUtil.convertStringToDate(currentDate));
		ActivitiVariable response = this.converter.convert(this.source);
		Assert.assertNotNull(response);
		Assert.assertEquals("Name", response.getName());
		Assert.assertEquals("Date", response.getType());
		Assert.assertEquals(new SimpleDateFormat(DateUtil.DATE_FORMAT_PATTERN)
				.format(currentDate), response.getValue());
	}
}
