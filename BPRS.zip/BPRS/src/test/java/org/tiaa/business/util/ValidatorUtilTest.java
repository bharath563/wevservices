package org.tiaa.business.util;

import junit.framework.Assert;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.util.ValidatorUtil;
import org.tiaa.business.process.validator.CommentValidator;
import org.tiaa.business.process.validator.DocumentValidator;
import org.tiaa.business.process.validator.ProcessRequestValidator;
import org.tiaa.business.process.validator.PropertiesValidator;
import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.esb.case_management_common_types.types.Properties;
import org.tiaa.esb.case_management_rs_v2_0.types.ProcessRequest;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;

@RunWith(MockitoJUnitRunner.class)
public class ValidatorUtilTest {

	ValidatorUtil util = new ValidatorUtil();

	@Mock
	CommentValidator commentValidator;

	@Mock
	DocumentValidator documentValidator;

	@Mock
	ProcessRequestValidator processRequestValidator;

	@Mock
	PropertiesValidator propertiesValidator;

	@Before
	public void before() {
		// this.util.getObjectValidators().add(this.commentValidator);
		this.util.getObjectValidators().add(new CommentValidator());
		this.util.getObjectValidators().add(this.documentValidator);
		this.util.getObjectValidators().add(this.processRequestValidator);
		this.util.getObjectValidators().add(this.propertiesValidator);

		Mockito.doNothing().when(this.commentValidator)
				.validate(Mockito.any(Comment.class));

		Mockito.doNothing().when(this.documentValidator)
				.validate(Mockito.any(Document.class));

		Mockito.doNothing().when(this.processRequestValidator)
				.validate(Mockito.any(ProcessRequest.class));

		Mockito.doNothing().when(this.propertiesValidator)
				.validate(Mockito.any(Properties.class));

	}

	@Test(expected = BadRequestException.class)
	public void testValidatePathParamsWithNull() {
		this.util.validatePathParams((String) null);
	}

	@Test(expected = BadRequestException.class)
	public void testValidatePathParamsWithEmptyString() {
		this.util.validatePathParams("");
	}

	@Test(expected = BadRequestException.class)
	public void testValidatePathParamsWithNonNumericValue() {
		this.util.validatePathParams("abc");
	}

	@Test(expected = BadRequestException.class)
	public void testValidatePathParamsArrayWithOneNull() {
		this.util.validatePathParams(new String[] { "123", null });
	}

	@Test(expected = BadRequestException.class)
	public void testValidatePathParamsArrayWithOneNonNumeric() {
		this.util.validatePathParams(new String[] { "123", "abc" });
	}

	@Test
	public void testValidatePathParamsWithValidValue() {
		this.util.validatePathParams("5123");
		Assert.assertTrue("No Exception thrown", true);
	}

	@Test
	public void testValidatePathParamsWithValidArrayValue() {
		this.util.validatePathParams(new String[] { "5123", "2132" });
		Assert.assertTrue("No Exception thrown", true);
	}

	@Test(expected = BadRequestException.class)
	public void testValidateWithNullValue() {
		this.util.validate(null);
	}

	@Test(expected = BadRequestException.class)
	public void testValidateInvokingCorrectValidatorThrowsException() {
		this.util.validate(new Comment());
	}

	@Test
	public void testValidateInvokingCorrectValidator() {
		Comment comment = new Comment();
		comment.setMessage("Message");
		comment.setType("Type");
		this.util.validate(comment);
	}

}
