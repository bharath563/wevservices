package org.tiaa.business.process.converters;

import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import junit.framework.Assert;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.business.process.util.SerializerUtil;
import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComment;

@RunWith(MockitoJUnitRunner.class)
public class ActivitiCommentToCommentConverterTest {

	ActivitiCommentToCommentConverter converter = new ActivitiCommentToCommentConverter();
	ActivitiComment source = new ActivitiComment();
	Comment comment = new Comment();

	XMLGregorianCalendar instance = null;

	@Mock
	SerializerUtil serializerUtil;

	@Before
	public void before() throws DatatypeConfigurationException {

		this.instance = DatatypeFactory.newInstance().newXMLGregorianCalendar(
				new GregorianCalendar());

		this.source.setTaskId("taskId");
		this.source.setCreateDate(this.instance);
		this.source.setMessage("SomeMessage");
		this.source.setProcessInstanceId("pid");
		Whitebox.setInternalState(this.converter, "serializerUtil",
				this.serializerUtil);

		Mockito.when(
				this.serializerUtil.deSerialize(Mockito.anyString(),
						Mockito.anyObject())).thenReturn(this.comment);
	}

	@Test
	public void testConverterWithNullValue() {
		Assert.assertNull(this.converter.convert(null));
	}

	@Test
	public void testConverterWithValidObject() {
		Comment response = this.converter.convert(this.source);
		Assert.assertNotNull(response);
		Assert.assertEquals("taskId", response.getId());
		Assert.assertEquals("pid", response.getProcessId());
		Assert.assertEquals(this.instance, response.getCreateDate());
		Assert.assertEquals(this.instance, response.getCreateTime());
	}

}
