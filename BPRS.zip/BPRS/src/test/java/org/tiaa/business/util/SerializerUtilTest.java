package org.tiaa.business.util;

import java.util.ArrayList;
import java.util.List;

import junit.framework.Assert;

import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.business.process.serializer.CommentSerializer;
import org.tiaa.business.process.serializer.DocumentSerializer;
import org.tiaa.business.process.serializer.ObjectSerializer;
import org.tiaa.business.process.util.SerializerUtil;
import org.tiaa.esb.case_management_common_types.types.Comment;

@RunWith(MockitoJUnitRunner.class)
public class SerializerUtilTest {

	SerializerUtil util = new SerializerUtil();
	private final static String EMPTY_STR = "[{}]";

	@Before
	public void before() {
		@SuppressWarnings("rawtypes")
		List<ObjectSerializer> serializers = new ArrayList<ObjectSerializer>();
		serializers.add(new CommentSerializer());
		serializers.add(new DocumentSerializer());
		Whitebox.setInternalState(this.util, "objectSerializers", serializers);
	}

	@Test
	public void testSerializeWithNull() {
		String serializedString = this.util.serialize(null);
		Assert.assertNull(serializedString);
	}

	@Test
	public void testSerializeWithEmptyObject() {
		String serializedString = this.util.serialize(new Comment());
		Assert.assertNotNull(serializedString);
		Assert.assertEquals(EMPTY_STR, serializedString);
	}

	@Test
	public void testDeSerializeWithNull() {
		Comment comment = this.util.deSerialize(null, Comment.class);
		Assert.assertNull(comment);
	}

	@Test
	public void testDeSerializeWithEmptyObject() {
		Comment comment = this.util.deSerialize(EMPTY_STR, Comment.class);
		Assert.assertNotNull(comment);
		Assert.assertNull(comment.getMessage());
		Assert.assertNull(comment.getDesc());
	}
}
