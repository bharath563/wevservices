/**
 * 
 */
package org.tiaa.business.process.resource;

import junit.framework.Assert;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.business.process.resource.util.ResourceUtil;
import org.tiaa.business.process.service.es.ESSearchService;
import org.tiaa.business.process.service.wrapper.TaskService;
import org.tiaa.esb.case_management_common_types.types.SearchRequest;
import org.tiaa.esb.case_management_rs_v2_0.types.ESBResponseStatusType;
import org.tiaa.esb.case_management_rs_v2_0.types.SearchResponse;


/**
 * @author polara
 *
 */

@RunWith(MockitoJUnitRunner.class)
public class SearchResourceTest {

	@Mock
	TaskService taskService;

	@Mock
	ESSearchService esSearchService;

	@Mock
	ResourceUtil resourceUtil;

	SearchResource resource = new SearchResource();
	SearchRequest searchRequest = new SearchRequest();
	ESBResponseStatusType okStatus = new ESBResponseStatusType();


	@Before
	public void before(){
		Mockito.when(this.resourceUtil.getCreatedStatus()).thenReturn(this.okStatus);
		Whitebox.setInternalState(this.resource, "taskService", this.taskService);
		Whitebox.setInternalState(this.resource, "esSearchService", this.esSearchService);
	}

	@Test
	public void testQueryForTasks(){

		SearchResponse response = this.resource.queryForTasks("admina", "basicAuth", "Asssigned");
		Mockito.verify(this.taskService, Mockito.times(1)).queryTasksByUser("admina","Asssigned",
				"basicAuth");
		Assert.assertNotNull(response);
	}

	/*@Test
	public void testProcessByVariable(){
		SearchRequest request = new SearchRequest();
		SearchResponse response =this.resource.processByVariable("userId", "basicAuth", request);
		Mockito.verify(this.esSearchService, Mockito.times(1)).queryESByVariable(request,"basicAuth","userId");
		Assert.assertNotNull(response);

	}*/


}
