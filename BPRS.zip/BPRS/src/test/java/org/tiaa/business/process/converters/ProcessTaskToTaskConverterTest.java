package org.tiaa.business.process.converters;

import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import junit.framework.Assert;

import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.esb.case_management_common_types.types.Task;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTask;

@RunWith(MockitoJUnitRunner.class)
public class ProcessTaskToTaskConverterTest {

	ProcessTaskToTaskConverter converter = new ProcessTaskToTaskConverter();
	ProcessTask source = new ProcessTask();

	XMLGregorianCalendar instance = null;

	@Before
	public void before() throws DatatypeConfigurationException {

		this.instance = DatatypeFactory.newInstance().newXMLGregorianCalendar(
				new GregorianCalendar());

		this.source.setTaskId("taskId");
		this.source.setTaskName("taskName");
		this.source.setCreateDate(this.instance);
		this.source.setDueDate(this.instance);
		this.source.setDepartment("department");
		this.source.setTaskStatus("OPEN");
	}

	@Test
	public void testConverterWithNullValue() {
		Assert.assertNull(this.converter.convert(null));
	}

	@Test
	public void testConverterWithValidObject() {
		Task response = this.converter.convert(this.source);
		Assert.assertNotNull(response);
		Assert.assertEquals("taskId", response.getID());
		Assert.assertEquals("taskName", response.getName());
		Assert.assertEquals("department", response.getDepartment());
		Assert.assertEquals(this.instance, response.getCreateDate());
		Assert.assertEquals(this.instance, response.getCreateTime());
		Assert.assertNotNull(response.getSLADetail());
		Assert.assertEquals(this.instance, response.getSLADetail().getDueDate());

		Assert.assertNotNull(response.getStatusHistory());
		Assert.assertEquals("OPEN", response.getStatusHistory().getSts().get(0)
				.getSts());

	}

	@Test
	public void testConverterWithSomeNullValues() {
		this.source.setAssignee(null);
		this.source.setDueDate(null);
		this.source.setTaskStatus(null);
		Task response = this.converter.convert(this.source);

		Assert.assertNotNull(response);
		Assert.assertNull(response.getAssignedTo());
		Assert.assertNull(response.getSLADetail());
		Assert.assertNull(response.getStatusHistory());

	}
}
