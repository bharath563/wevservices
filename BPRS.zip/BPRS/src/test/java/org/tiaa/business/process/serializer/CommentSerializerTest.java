package org.tiaa.business.process.serializer;

import junit.framework.Assert;

import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.esb.case_management_common_types.types.Comment;

@RunWith(MockitoJUnitRunner.class)
public class CommentSerializerTest {

	CommentSerializer serializer = new CommentSerializer();
	Comment comment = new Comment();

	private static final String EMPTY_OBJECT = "[{}]";
	private static final String POPULATED_OBJECT = "[{\"Desc\":\"Desc\",\"Type\":\"Type\",\"Message\":\"Message\"}]";

	@Before
	public void before() {
		this.comment.setMessage("Message");
		this.comment.setType("Type");
		this.comment.setDesc("Desc");
	}

	@Test
	public void serializeWithNullValue() {
		Assert.assertEquals("null", this.serializer.serialize(null));
	}

	@Test
	public void serializeWithEmptyObject() {
		String serializedString = this.serializer.serialize(new Comment());
		Assert.assertNotNull(serializedString);
		Assert.assertEquals(EMPTY_OBJECT, serializedString);
	}

	/*
	 * @Test public void serializeWithValidObject() { String serializedString =
	 * this.serializer.serialize(this.comment);
	 * Assert.assertNotNull(serializedString);
	 * Assert.assertEquals(POPULATED_OBJECT, serializedString); }
	 */
	@Test
	public void deSerializeWithNullValue() {
		Assert.assertNull(this.serializer.deSerialize(null));
	}

	@Test
	public void deSerializeWithEmptyString() {
		Comment response = this.serializer.deSerialize(EMPTY_OBJECT);
		Assert.assertNotNull(response);
		Assert.assertNull(response.getMessage());
		Assert.assertNull(response.getType());
		Assert.assertNull(response.getDesc());
	}

	@Test
	public void deSerializeWithValidObject() {
		Comment response = this.serializer.deSerialize(POPULATED_OBJECT);
		Assert.assertNotNull(response);
		Assert.assertEquals("Message", response.getMessage());
		Assert.assertEquals("Type", response.getType());
		Assert.assertEquals("Desc", response.getDesc());
	}

}
