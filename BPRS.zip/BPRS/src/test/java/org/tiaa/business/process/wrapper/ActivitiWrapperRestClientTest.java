package org.tiaa.business.process.wrapper;

import java.util.HashMap;
import java.util.Map;

import junit.framework.Assert;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.tiaa.business.process.rest.template.TIAARestResponse;
import org.tiaa.business.process.rest.template.TIAARestTemplate;
import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.service.exception.BusinessProcessApplicationException;
import org.tiaa.business.process.service.exception.NotFoundException;
import org.tiaa.business.process.service.exception.NotPermittedException;
import org.tiaa.business.process.service.exception.UnAuthorizedException;
import org.tiaa.business.process.wrapper.client.ActivitiWrapperRestClient;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComment;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComments;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstances;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTask;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTasks;

@RunWith(MockitoJUnitRunner.class)
@SuppressWarnings("unchecked")
public class ActivitiWrapperRestClientTest {

	ActivitiWrapperRestClient client = new ActivitiWrapperRestClient();

	@Mock
	TIAARestTemplate activitiRestClient;

	@Mock
	ObjectMapper objectMapper;

	TIAARestResponse<Object> response = new TIAARestResponse<Object>(200, "Body");

	Map<String, String> errorMap = new HashMap<String, String>();

	@Before
	public void before() {
		Whitebox.setInternalState(this.client, "activitiRestClient", this.activitiRestClient);

		Whitebox.setInternalState(this.client, "objectMapper", this.objectMapper);

		Mockito.when(
				this.activitiRestClient.get(Mockito.anyString(), Mockito.anyMap(),
						Mockito.anyObject())).thenReturn(this.response);

		Mockito.when(
				this.activitiRestClient.put(Mockito.anyString(), Mockito.any(), Mockito.anyMap(),
						Mockito.anyObject())).thenReturn(this.response);

		Mockito.when(
				this.activitiRestClient.post(Mockito.anyString(), Mockito.any(),
						Mockito.anyMap(), Mockito.anyObject())).thenReturn(this.response);

	}

	@Test
	public void testGetProcessById() throws Exception {

		ProcessInstance process = new ProcessInstance();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ProcessInstance>) Mockito.any(Class.class))).thenReturn(process);

		ProcessInstance response = this.client.getProcessById("100", "userId", null, false,
				false);

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).get(
				Mockito.eq("/process/100?isHistoryEnabled=false&lock=false"), Mockito.anyMap(),
				Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(process, response);
	}

	@Test
	public void testUpdateProcess() throws Exception {

		ProcessInstance process = new ProcessInstance();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ProcessInstance>) Mockito.any(Class.class))).thenReturn(process);

		this.client.updateProcess("100", null, "update", "userId", "basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).put(
				Mockito.eq("/process/100?action=update"), Mockito.any(), Mockito.anyMap(),
				Mockito.eq(String.class));

		Assert.assertNotNull(this.response);
		// Assert.assertEquals(process, response);
	}

	@Test
	public void testUpdateTask() throws Exception {

		ProcessTask task = new ProcessTask();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ProcessTask>) Mockito.any(Class.class))).thenReturn(task);

		ProcessTask response = this.client.updateTask("100", "200", null, "userId",
				"basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).put(
				Mockito.eq("/process/100/task/200"), Mockito.any(), Mockito.anyMap(),
				Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(task, response);
	}

	@Test
	public void testAddProcessDocument() throws Exception {

		ActivitiVariable doc = new ActivitiVariable();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ActivitiVariable>) Mockito.any(Class.class))).thenReturn(doc);

		ActivitiVariable response = this.client.addProcessDocument("100", null, "userId",
				"basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).post(
				Mockito.eq("/process/100/document"), Mockito.any(), Mockito.anyMap(),
				Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(doc, response);
	}

	@Test
	public void testStartProcess() throws Exception {

		ProcessInstance process = new ProcessInstance();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ProcessInstance>) Mockito.any(Class.class))).thenReturn(process);

		ProcessInstance response = this.client.startProcess(null, "userId", "basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).post(
				Mockito.eq("/process/"), Mockito.any(), Mockito.anyMap(),
				Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(process, response);
	}

	@Test
	public void testAddProcessComment() throws Exception {

		ActivitiComment comment = new ActivitiComment();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ActivitiComment>) Mockito.any(Class.class))).thenReturn(comment);

		ActivitiComment response = this.client.addProcessComment("100", null, "userId",
				"basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).post(
				Mockito.eq("/process/100/comment"), Mockito.any(), Mockito.anyMap(),
				Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(comment, response);
	}

	@Test
	public void testAddTaskComment() throws Exception {

		ActivitiComment comment = new ActivitiComment();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ActivitiComment>) Mockito.any(Class.class))).thenReturn(comment);

		ActivitiComment response = this.client.addTaskComment("100", "200", null, "userId",
				"basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).post(
				Mockito.eq("/process/100/task/200/comment"), Mockito.any(), Mockito.anyMap(),
				Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(comment, response);
	}

	@Test
	public void testGetProcessComment() throws Exception {

		ActivitiComments comment = new ActivitiComments();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ActivitiComments>) Mockito.any(Class.class))).thenReturn(comment);

		ActivitiComments response = this.client.getProcessComments("100", "userId",
				"basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).get(
				Mockito.eq("/process/100/comments"), Mockito.anyMap(), Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(comment, response);
	}

	@Test
	public void testGetTaskComment() throws Exception {

		ActivitiComments comment = new ActivitiComments();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ActivitiComments>) Mockito.any(Class.class))).thenReturn(comment);

		ActivitiComments response = this.client.getTaskComments("100", "200", "userId",
				"basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).get(
				Mockito.eq("/process/100/task/200/comments"), Mockito.anyMap(),
				Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(comment, response);
	}

	@Test
	public void testGetProcessTasks() throws Exception {

		ProcessTasks tasks = new ProcessTasks();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ProcessTasks>) Mockito.any(Class.class))).thenReturn(tasks);

		ProcessTasks response = this.client.getProcessTasks("100", "userId", "basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).get(
				Mockito.eq("/process/100/tasks"), Mockito.anyMap(), Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(tasks, response);
	}

	@Test
	public void testGetProcessTaskById() throws Exception {

		ProcessTask task = new ProcessTask();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ProcessTask>) Mockito.any(Class.class))).thenReturn(task);

		ProcessTask response = this.client.getTaskById("100", "200", "userId", "basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).get(
				Mockito.eq("/process/100/task/200"), Mockito.anyMap(), Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(task, response);
	}

	@Test
	public void testClaimTask() throws Exception {

		ProcessTask task = new ProcessTask();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ProcessTask>) Mockito.any(Class.class))).thenReturn(task);

		ProcessTask response = this.client.claimTask("100", "200", "userId", "basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).put(
				Mockito.eq("/process/100/task/200/claim"), Mockito.any(), Mockito.anyMap(),
				Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(task, response);
	}

	@Test
	public void testCompleteTask() throws Exception {

		ProcessTask task = new ProcessTask();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ProcessTask>) Mockito.any(Class.class))).thenReturn(task);

		ProcessTask response = this.client.completeTask("100", "200", null, "userId",
				"basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).put(
				Mockito.eq("/process/100/task/200/complete"), Mockito.any(), Mockito.anyMap(),
				Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(task, response);
	}

	@Test
	public void testSignalProcessTask() throws Exception {
		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ProcessInstance>) Mockito.any(Class.class))).thenReturn(
				new ProcessInstance());

		this.client.signalProcessTask(null, "userId", "basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).post(Mockito.eq("/signal"),
				Mockito.any(), Mockito.anyMap(), Mockito.eq(String.class));
	}

	@Test
	public void testQueryProcessTasksByUserIdInAssignedBucket() throws Exception {

		ProcessInstances processes = new ProcessInstances();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ProcessInstances>) Mockito.any(Class.class))).thenReturn(processes);

		ProcessInstances response = this.client.queryProcessTasksByUserId("userId",
				"assigned", "basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).get(
				Mockito.eq("/query/tasks?type=assigned"), Mockito.anyMap(),
				Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(processes, response);
	}

	@Test
	public void testQueryProcessTasksByUserIdInQueuedBucket() throws Exception {

		ProcessInstances processes = new ProcessInstances();

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<ProcessInstances>) Mockito.any(Class.class))).thenReturn(processes);

		ProcessInstances response = this.client.queryProcessTasksByUserId("userId", "queued",
				"basicAuth");

		Mockito.verify(this.activitiRestClient, Mockito.times(1)).get(
				Mockito.eq("/query/tasks?type=queued"), Mockito.anyMap(),
				Mockito.eq(String.class));

		Assert.assertNotNull(response);
		Assert.assertEquals(processes, response);
	}

	@Test(expected = BadRequestException.class)
	public void testGetProcessByIdReturn400() throws Exception {
		setErrorMocks(400);
		this.client.getProcessById("100", "userId", null, false, false);
	}

	@Test(expected = UnAuthorizedException.class)
	public void testGetProcessByIdReturn401() throws Exception {
		setErrorMocks(401);
		this.client.getProcessById("100", "userId", null, false, false);
	}

	@Test(expected = NotFoundException.class)
	public void testGetProcessByIdReturn404() throws Exception {
		setErrorMocks(404);
		this.client.getProcessById("100", "userId", null, false, false);
	}

	@Test(expected = NotPermittedException.class)
	public void testGetProcessByIdReturn409() throws Exception {
		setErrorMocks(409);
		this.client.getProcessById("100", "userId", null, false, false);
	}

	@Test(expected = BusinessProcessApplicationException.class)
	public void testGetProcessByIdReturn500() throws Exception {
		setErrorMocks(500);
		this.client.getProcessById("100", "userId", null, false, false);
	}

	@SuppressWarnings("rawtypes")
	private void setErrorMocks(int statusCode) throws Exception {
		TIAARestResponse<Object> errorResponse = new TIAARestResponse<Object>(statusCode,
				"{message:\"ErrorMessage\"");

		Mockito.when(
				this.objectMapper.readValue(Mockito.anyString(),
						(Class<Map>) Mockito.any(Class.class))).thenReturn(this.errorMap);

		Mockito.when(
				this.activitiRestClient.get(Mockito.anyString(), Mockito.anyMap(),
						Mockito.anyObject())).thenReturn(errorResponse);

	}
}
