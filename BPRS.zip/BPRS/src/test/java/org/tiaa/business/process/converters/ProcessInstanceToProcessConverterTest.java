package org.tiaa.business.process.converters;

import javax.xml.datatype.DatatypeConfigurationException;

import junit.framework.Assert;

import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.esb.case_management_common_types.types.Process;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance;

@RunWith(MockitoJUnitRunner.class)
public class ProcessInstanceToProcessConverterTest {

	ProcessInstanceToProcessConverter converter = new ProcessInstanceToProcessConverter();
	ProcessInstance source = new ProcessInstance();

	@Before
	public void before() throws DatatypeConfigurationException {

		this.source.setProcessInstanceId("pid");
		this.source.setBusinessKey("bkey");
		this.source.setStatus("OPEN");
	}

	@Test
	public void testConverterWithNullValue() {
		Assert.assertNull(this.converter.convert(null));
	}

	@Test
	public void testConverterWithValidObject() {
		Process response = this.converter.convert(this.source);
		Assert.assertNotNull(response);
		Assert.assertEquals("bkey", response.getBusinessKey());
		Assert.assertEquals("pid", response.getProcessId());
		Assert.assertNotNull(response.getStatusHistory());
		Assert.assertEquals("OPEN", response.getStatusHistory().getSts().get(0)
				.getSts());
	}
}
