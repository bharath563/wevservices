package org.tiaa.business.process.resource;

import junit.framework.Assert;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.business.process.resource.util.ResourceUtil;
import org.tiaa.business.process.service.wrapper.ProcessService;
import org.tiaa.business.process.util.ValidatorUtil;
import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.esb.case_management_common_types.types.Process;
import org.tiaa.esb.case_management_common_types.types.Properties;
import org.tiaa.esb.case_management_common_types.types.Tasks;
import org.tiaa.esb.case_management_rs_v2_0.types.DocumentRequest;
import org.tiaa.esb.case_management_rs_v2_0.types.DocumentResponse;
import org.tiaa.esb.case_management_rs_v2_0.types.ESBResponseStatusType;
import org.tiaa.esb.case_management_rs_v2_0.types.ProcessRequest;
import org.tiaa.esb.case_management_rs_v2_0.types.ProcessResponse;
import org.tiaa.esb.case_management_rs_v2_0.types.TasksResponse;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.List;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.NameValue;

@RunWith(MockitoJUnitRunner.class)
public class ProcessResourceTest {

	@Mock
	ProcessService processService;

	@Mock
	ValidatorUtil validatorUtil;

	@Mock
	ResourceUtil resourceUtil;

	ProcessResource resource = new ProcessResource();
	ESBResponseStatusType okStatus = new ESBResponseStatusType();
	org.tiaa.esb.case_management_common_types.types.Process process = new org.tiaa.esb.case_management_common_types.types.Process();

	@Before
	public void before() {

		this.process.setProcessId("100");
		this.process.setAppName("NXTGENDELEGATEFRAMEWORK");

		Mockito.doNothing().when(this.validatorUtil).validate(Mockito.any());
		Mockito.when(this.resourceUtil.getCreatedStatus()).thenReturn(this.okStatus);
		Whitebox.setInternalState(this.resource, "validatorUtil", this.validatorUtil);
		Whitebox.setInternalState(this.resource, "processService", this.processService);
		Whitebox.setInternalState(this.resource, "resourceUtil", this.resourceUtil);
	}

	@Test
	public void testStartProcess() throws Exception {
		ProcessRequest request = new ProcessRequest();
		ProcessResponse response = this.resource.startProcess("userId", "basicAuth", request);
		Mockito.verify(this.validatorUtil, Mockito.times(1)).validate(request);
		Mockito.verify(this.processService, Mockito.times(1)).startProcess(null, "userId",
				"basicAuth");
		Assert.assertNotNull(response);
		Assert.assertEquals(this.okStatus, response.getResponseStatus());
	}

	@Test
	public void testGetProcess() throws Exception {
		Mockito.when(this.processService.getProcessById("100", "userId", null, false, false))
				.thenReturn(this.process);

		ProcessResponse response = this.resource.getProcess("userId", null, "100", "false");
		Mockito.verify(this.processService, Mockito.times(1)).getProcessById("100", "userId",
				null, false, false);
		Assert.assertNotNull(response);
		Assert.assertEquals(this.process, response.getProcess());
	}


	@Test
	public void testUpdateProcess() throws Exception {
		Properties props = new Properties();
		NameValue nv = new NameValue();
		nv.setName("milestone");
		nv.setValue("Re-Test");

		props.getProperty().add(nv);
		ProcessRequest processRequest = new ProcessRequest();
		Process p = new Process();
		p.setProcessProperties(props);
		List action = new List();
		action.getItem().add("Update");
		p.setAction(action);
		processRequest.setProcess(p);

		ProcessResponse response = this.resource.updateProcess("userId", "basicAuth", "1133911",
				processRequest);
		Mockito.verify(this.validatorUtil, Mockito.times(1)).validatePathParams("1133911");
		Mockito.verify(this.validatorUtil, Mockito.times(1)).validate(props);
		Mockito.verify(this.processService, Mockito.times(1)).updateProcess("1133911", props,
				"Update", "userId", "basicAuth");
		Assert.assertNotNull(response);
	}
	
	
	
	@Test
	public void testUnlockProcess() throws Exception {
		Properties props = new Properties();

		ProcessRequest processRequest = new ProcessRequest();
		Process p = new Process();
		p.setProcessProperties(props);
		List action = new List();
		action.getItem().add("Unlock");
	    p.setAction(action);
		processRequest.setProcess(p);

		ProcessResponse response = this.resource.updateProcess("userId", "basicAuth", "1133911",
				processRequest);
		Mockito.verify(this.validatorUtil, Mockito.times(1)).validatePathParams("1133911");

		Mockito.verify(this.processService, Mockito.times(1)).updateProcess("1133911", props,
				"Unlock", "userId", "basicAuth");
		Assert.assertNotNull(response);
	}
	

	// @Test
	/*
	 * public void testGetProcessDocuments() throws Exception { Mockito.when(
	 * this.processService.getProcessDocuments("100", "userId",
	 * "basicAuth")).thenReturn(null);
	 * Documents response = this.resource.getProcessDocuments("userId",
	 * "basicAuth", "100"); Mockito.verify(this.validatorUtil, Mockito.times(1))
	 * .validatePathParams("100");
	 * Mockito.verify(this.processService, Mockito.times(1))
	 * .getProcessDocuments("100", "userId", "basicAuth");
	 * Assert.assertNull(response); }
	 */

	// @Test
	/*
	 * public void testGetProcessDocument() throws Exception { Mockito.when(
	 * this.processService.getProcessDocument("100", "docId", "userId",
	 * "basicAuth")).thenReturn(null);
	 * DocumentResponse response = this.resource.getProcessDocument("userId",
	 * "basicAuth", "100", "docId");
	 * Mockito.verify(this.processService, Mockito.times(1))
	 * .getProcessDocument("100", "docId", "userId", "basicAuth");
	 * Assert.assertNotNull(response); }
	 */

	// @Test
	/*
	 * public void testAddProcessDocument() throws Exception { Document document
	 * = new Document();
	 * Mockito.when( this.processService.addProcessDocument("100", null,
	 * "userId", "basicAuth")).thenReturn(document);
	 * DocumentResponse response = this.resource.addProcessDocument("userId",
	 * "basicAuth", "100", new DocumentRequest());
	 * Mockito.verify(this.validatorUtil, Mockito.times(1)).validate(null);
	 * Mockito.verify(this.processService, Mockito.times(1))
	 * .addProcessDocument("100", null, "userId", "basicAuth");
	 * Assert.assertNotNull(response); Assert.assertEquals(document,
	 * response.getDocument()); }
	 */

/*
	@Test
	public void testGetProcessComments() throws Exception {
		Comments comments = new Comments();
		Mockito.when(this.processService.getProcessComments("100", "userId", "basicAuth"))
				.thenReturn(comments);

		CommentsResponse response = this.resource.getProcessComments("userId", "basicAuth",
				"100");

		Mockito.verify(this.processService, Mockito.times(1)).getProcessComments("100",
				"userId", "basicAuth");
		Assert.assertNotNull(response);
		// Assert.assertEquals(comments, response);
	}*/

	@Test
	public void testAddProcessComment() throws Exception {
		Comment comment = new Comment();

		Mockito.when(
				this.processService.addProcessComment("100", comment, "userId", "basicAuth"))
				.thenReturn(comment);

		Comment response = this.resource.addProcessComments("userId", "basicAuth", "100",
				comment);
		Mockito.verify(this.validatorUtil, Mockito.times(1)).validatePathParams("100");
		Mockito.verify(this.validatorUtil, Mockito.times(1)).validate(comment);

		Mockito.verify(this.processService, Mockito.times(1)).addProcessComment("100",
				comment, "userId", "basicAuth");
		Assert.assertNotNull(response);
		Assert.assertEquals(comment, response);
	}

	@Test
	public void testGetProcessTasks() throws Exception {
		Tasks tasks = new Tasks();
		Mockito.when(this.processService.getProcessTasks("100", "userId", "basicAuth"))
				.thenReturn(tasks);

		TasksResponse response = this.resource.getProcessTasks("userId", "basicAuth", "100");

		Mockito.verify(this.processService, Mockito.times(1)).getProcessTasks("100",
				"userId", "basicAuth");
		Mockito.verify(this.validatorUtil, Mockito.times(1)).validatePathParams("100");

		Assert.assertNotNull(response);
		// Assert.assertEquals(tasks, response);
	}

	@Test
	public void testGetProcessHistory() throws Exception {
		org.tiaa.esb.case_management_common_types.types.Process process = new org.tiaa.esb.case_management_common_types.types.Process();
		Mockito.when(this.processService.getProcessHistory("100", "userId", "basicAuth"))
				.thenReturn(process);

		ProcessResponse response = this.resource.getProcessHistory("userId", "basicAuth",
				"100");

		Mockito.verify(this.processService, Mockito.times(1)).getProcessHistory("100",
				"userId", "basicAuth");
		Mockito.verify(this.validatorUtil, Mockito.times(1)).validatePathParams("100");

		Assert.assertNotNull(response);
		Assert.assertEquals(process, response.getProcess());
	}

	@Test
	public void testUpdateProcessDocument() throws Exception {
		Document document = new Document();

		Mockito.when(
				this.processService.updateProcessDocument("100", "docId", null, "userId",
						"basicAuth")).thenReturn(document);

		DocumentResponse response = this.resource.updateProcessDocument("userId",
				"basicAuth", "100", "docId", new DocumentRequest());
		Mockito.verify(this.validatorUtil, Mockito.times(1)).validate(null);

		Mockito.verify(this.processService, Mockito.times(1)).updateProcessDocument("100",
				"docId", null, "userId", "basicAuth");
		Assert.assertNotNull(response);
		Assert.assertEquals(document, response.getDocument());
	}

}
