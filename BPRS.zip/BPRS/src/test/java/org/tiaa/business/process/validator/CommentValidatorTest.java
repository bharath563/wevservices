package org.tiaa.business.process.validator;

import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.esb.case_management_common_types.types.Comment;

@RunWith(MockitoJUnitRunner.class)
public class CommentValidatorTest {

	CommentValidator validator = new CommentValidator();
	Comment comment = new Comment();

	@Before
	public void before() {
		// Set mandatory elements
		this.comment.setMessage("Message");
		this.comment.setType("Type");
	}

	@Test(expected = BadRequestException.class)
	public void testNullComment() {
		this.validator.validate(null);
	}

	@Test(expected = BadRequestException.class)
	public void testCommentWithNoMessage() {
		this.comment.setMessage(null);
		this.validator.validate(this.comment);
	}

	@Test(expected = BadRequestException.class)
	public void testCommentWithNoType() {
		this.comment.setType(null);
		this.validator.validate(this.comment);
	}

	@Test
	public void testValidComment() {
		this.validator.validate(this.comment);
	}
}
