package org.tiaa.business.process.converters;

import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import junit.framework.Assert;

import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.business.process.service.comparator.EventComparator;
import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.esb.case_management_common_types.types.Comments;
import org.tiaa.esb.case_management_common_types.types.Event;
import org.tiaa.esb.case_management_common_types.types.EventType;
import org.tiaa.esb.case_management_common_types.types.History;
import org.tiaa.esb.case_management_common_types.types.Process;
import org.tiaa.esb.case_management_common_types.types.Task;
import org.tiaa.esb.case_management_common_types.types.Tasks;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document.DocOriginator;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Documents;

@RunWith(MockitoJUnitRunner.class)
public class ProcessToHistoryConverterTest {

	ProcessToHistoryConverter converter = new ProcessToHistoryConverter();
	Process source = new Process();

	XMLGregorianCalendar instance = null;

	@Before
	public void before() throws DatatypeConfigurationException {
		Whitebox.setInternalState(this.converter, "eventComparator",
				new EventComparator());
		this.instance = DatatypeFactory.newInstance().newXMLGregorianCalendar(
				new GregorianCalendar());
		this.source.setDocuments(getDocuments());
		this.source.setComments(getComments());
		this.source.setTasks(getTasks());

	}

	private Tasks getTasks() {
		Tasks tasks = new Tasks();
		Task task = new Task();
		task.setName("TaskName");
		task.setDescription("TaskDesc");
		task.setAssignedTo("admina");
		task.setCreateDate(this.instance);
		tasks.getTask().add(task);
		return tasks;
	}

	private Comments getComments() {
		Comments comments = new Comments();
		Comment comment = new Comment();
		comment.setDesc("CommentDesc");
		comment.setCreateOper("admina");
		comment.setMessage("CommentMessage");
		comment.setCreateDate(this.instance);
		comments.getComment().add(comment);
		return comments;
	}

	private Documents getDocuments() {
		Documents documents = new Documents();
		Document document = new Document();
		document.setDocTitle("DocTitle");
		document.setDocCreateDateTime(this.instance);
		document.setDocDesc("DocDesc");
		DocOriginator originator = new DocOriginator();
		originator.setDocOrigName("admina");
		document.setDocOriginator(originator);
		documents.getDocument().add(document);
		return documents;
	}

	@Test
	public void testConverterWithNullValue() {
		Assert.assertNull(this.converter.convert(null));
	}

	@Test
	public void testConverterWithEmptyObject() {
		this.source.setTasks(null);
		this.source.setComments(null);
		this.source.setDocuments(null);
		History response = this.converter.convert(this.source);
		Assert.assertNotNull(response);
		Assert.assertEquals(0, response.getEvent().size());
	}

	@Test
	public void testConverterWithValidObject() {
		History response = this.converter.convert(this.source);
		Assert.assertNotNull(response);
		Assert.assertEquals(3, response.getEvent().size());

		// Comment Validate
		Event commentEvent = response.getEvent().get(0);
		Assert.assertNotNull(commentEvent);
		Assert.assertEquals(EventType.COMMENT, commentEvent.getEventType());
		Assert.assertEquals("CommentMessage", commentEvent.getTitle());
		Assert.assertEquals("admina", commentEvent.getCreatedBy());
		Assert.assertEquals(this.instance, commentEvent.getCreateDateTime());
		Assert.assertEquals("CommentDesc", commentEvent.getDescription());

		// Document Validate
		Event documentEvent = response.getEvent().get(1);
		Assert.assertNotNull(documentEvent);
		Assert.assertEquals(EventType.DOCUMENT, documentEvent.getEventType());
		Assert.assertEquals("DocTitle", documentEvent.getTitle());
		Assert.assertEquals("admina", documentEvent.getCreatedBy());
		Assert.assertEquals(this.instance, documentEvent.getCreateDateTime());
		Assert.assertEquals("DocDesc", documentEvent.getDescription());

		// Task Validate
		Event taskEvent = response.getEvent().get(2);
		Assert.assertNotNull(taskEvent);
		Assert.assertEquals(EventType.TASK, taskEvent.getEventType());
		Assert.assertEquals("TaskName", taskEvent.getTitle());
		Assert.assertEquals("admina", taskEvent.getCreatedBy());
		Assert.assertEquals(this.instance, taskEvent.getCreateDateTime());
		Assert.assertEquals("TaskDesc", taskEvent.getDescription());

	}

	@Test
	public void testConverterWithSomeNullValues() {
		this.source.getDocuments().getDocument().get(0).setDocOriginator(null);
		History response = this.converter.convert(this.source);

		Assert.assertNotNull(response);
		Assert.assertEquals(3, response.getEvent().size());
		Event documentEvent = response.getEvent().get(1);
		Assert.assertNotNull(documentEvent);
		Assert.assertEquals(EventType.DOCUMENT, documentEvent.getEventType());
		Assert.assertNull(documentEvent.getCreatedBy());
	}
}
