package org.tiaa.business.process.validator;

import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.internal.util.reflection.Whitebox;
import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.esb.case_management_common_types.types.Comments;
import org.tiaa.esb.case_management_common_types.types.Properties;
import org.tiaa.esb.case_management_rs_v2_0.types.ProcessRequest;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Documents;

@RunWith(MockitoJUnitRunner.class)
public class ProcessRequestValidatorTest {

	ProcessRequestValidator validator = new ProcessRequestValidator();
	ProcessRequest processRequest = new ProcessRequest();

	@Mock
	CommentValidator commentValidator;

	@Mock
	DocumentValidator documentValidator;

	@Mock
	PropertiesValidator propertiesValidator;

	@Before
	public void before() { // Set mandatory elements
		org.tiaa.esb.case_management_common_types.types.Process process = new org.tiaa.esb.case_management_common_types.types.Process();
		process.setProcessType("ProcessType");
		this.processRequest.setProcess(process);

		Whitebox.setInternalState(this.validator, "commentValidator",
				this.commentValidator);

		Whitebox.setInternalState(this.validator, "documentValidator",
				this.documentValidator);

		Whitebox.setInternalState(this.validator, "propertiesValidator",
				this.propertiesValidator);

		Mockito.doNothing().when(this.commentValidator).validate(Mockito.any());
		Mockito.doNothing().when(this.documentValidator)
		.validate(Mockito.any());
		Mockito.doNothing().when(this.propertiesValidator)
		.validate(Mockito.any());

	}

	@Test(expected = BadRequestException.class)
	public void testNullProcessRequest() {
		this.validator.validate(null);
	}

	@Test(expected = BadRequestException.class)
	public void testNullProcess() {
		this.validator.validate(new ProcessRequest());
	}

	@Test(expected = BadRequestException.class)
	public void testProcessWithNoProcessOrMessageType() {
		this.processRequest.getProcess().setProcessType(null);
		this.validator.validate(this.processRequest);
	}

	@Test
	public void testValidProcessWithNoCommentsDocumentsProperties() {
		this.validator.validate(this.processRequest);
	}

	@Test
	public void testValidProcessWithCommentsDocumentsProperties() {
		Properties props = new Properties();
		this.processRequest.getProcess().setProcessProperties(props);

		Comments comments = new Comments();
		Comment comment = new Comment();
		comments.getComment().add(comment);
		this.processRequest.getProcess().setComments(comments);

		Document document = new Document();
		this.processRequest.getProcess().setDocuments(new Documents());
		this.processRequest.getProcess().getDocuments().getDocument()
		.add(document);

		this.validator.validate(this.processRequest);
		Mockito.verify(this.commentValidator, Mockito.times(1)).validate(
				comment);

		Mockito.verify(this.documentValidator, Mockito.times(1)).validate(
				document);

		Mockito.verify(this.propertiesValidator, Mockito.times(1)).validate(
				props);

	}

}
