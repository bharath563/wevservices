package org.tiaa.business.process.converters;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.datatype.DatatypeConfigurationException;

import junit.framework.Assert;

import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.NameValue;

@RunWith(MockitoJUnitRunner.class)
public class ActivitiVariableToNameValueConverterTest {

	ActivitiVariableToNameValueConverter converter = new ActivitiVariableToNameValueConverter();
	ActivitiVariable source = new ActivitiVariable();

	@Before
	public void before() throws DatatypeConfigurationException {
		this.source.setName("Name");
	}

	@Test
	public void testConverterWithNullValue() {
		Assert.assertNull(this.converter.convert(null));
	}

	@Test
	public void testConverterWithBooleanValue() {
		this.source.setValue("true");
		this.source.setType("Boolean");
		NameValue response = this.converter.convert(this.source);

		Assert.assertNotNull(response);
		Assert.assertEquals("Name", response.getName());
		Assert.assertNotNull(response.isBooleanValue());
		Assert.assertTrue(response.isBooleanValue());
	}

	@Test
	public void testConverterWithDateValue() throws ParseException {

		String someDate = "02.10.2017";
		SimpleDateFormat sdf = new SimpleDateFormat("MM.dd.yyyy");
		Date date = sdf.parse(someDate);

		this.source.setValue(String.valueOf(date.getTime()));
		this.source.setType("Date");
		NameValue response = this.converter.convert(this.source);

		Assert.assertNotNull(response);
		Assert.assertEquals("Name", response.getName());
		Assert.assertNotNull(response.getDateValue());
		Assert.assertEquals(2017, response.getDateValue().getYear());
		Assert.assertEquals(02, response.getDateValue().getMonth());
	}

	@Test
	public void testConverterWithStringValue() {
		this.source.setValue("StringValue");
		this.source.setType("String");
		NameValue response = this.converter.convert(this.source);

		Assert.assertNotNull(response);
		Assert.assertEquals("Name", response.getName());
		Assert.assertNotNull(response.getValue());
		Assert.assertEquals("StringValue", response.getValue());
	}

	@Test
	public void testConverterWithDecimalValue() {
		this.source.setValue("20.3");
		this.source.setType("Decimal");
		NameValue response = this.converter.convert(this.source);

		Assert.assertNotNull(response);
		Assert.assertEquals("Name", response.getName());
		Assert.assertNotNull(response.getDecimalValue());
		Assert.assertEquals(new BigDecimal("20.3"), response.getDecimalValue());
	}

	@Test
	public void testConverterWithIntegerValue() {
		this.source.setValue("18");
		this.source.setType("Integer");
		NameValue response = this.converter.convert(this.source);

		Assert.assertNotNull(response);
		Assert.assertEquals("Name", response.getName());
		Assert.assertNotNull(response.getNumValue());
		Assert.assertEquals(new BigInteger("18"), response.getNumValue());
	}

}
