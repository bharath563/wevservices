package org.tiaa.business.process.validator;

import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.esb.case_management_common_types.types.Properties;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.NameValue;

@RunWith(MockitoJUnitRunner.class)
public class PropertiesValidatorTest {

	PropertiesValidator validator = new PropertiesValidator();
	Properties properties = new Properties();

	@Before
	public void before() {
		// Set mandatory elements

		NameValue nv1 = new NameValue();
		nv1.setName("Name1");
		nv1.setValue("Value1");

		NameValue nv2 = new NameValue();
		nv2.setName("Name2");
		nv2.setValue("Value2");

		this.properties.getProperty().add(nv1);
		this.properties.getProperty().add(nv2);
	}

	@Test(expected = BadRequestException.class)
	public void testNullProperties() {
		this.validator.validate(null);
	}

	@Test(expected = BadRequestException.class)
	public void testEmptyProperties() {
		this.validator.validate(new Properties());
	}

	@Test(expected = BadRequestException.class)
	public void testPropertiesWithNoName() {
		this.properties.getProperty().get(0).setName(null);
		this.validator.validate(this.properties);
	}

	@Test(expected = BadRequestException.class)
	public void testPropertiesWithDuplicateName() {
		this.properties.getProperty().get(0).setName("Name1");
		this.properties.getProperty().get(1).setName("Name1");
		this.validator.validate(this.properties);
	}

	@Test
	public void testValidProperties() {
		this.validator.validate(this.properties);
	}
}
