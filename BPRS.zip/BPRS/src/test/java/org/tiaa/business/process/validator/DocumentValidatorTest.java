package org.tiaa.business.process.validator;

import org.mockito.runners.MockitoJUnitRunner;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;

@RunWith(MockitoJUnitRunner.class)
public class DocumentValidatorTest {

	DocumentValidator validator = new DocumentValidator();
	Document document = new Document();

	@Before
	public void before() {
		// Set mandatory elements
		this.document.setDocID("docId");
		this.document.setDocSts("docSts");
		this.document.setDocIDTyp("1");
		this.document.setFrmtTyp("FrmtTyp");
		this.document.setDocBizUnit("DocBizUnit");
		this.document.setDocVrsn(2);
		this.document.setMimeTyp("mime");
	}

	@Test(expected = BadRequestException.class)
	public void testNullDocument() {
		this.validator.validate(null);
	}

	@Test(expected = BadRequestException.class)
	public void testDocumentWithNoDocId() {
		this.document.setDocID(null);
		this.validator.validate(this.document);
	}

	@Test(expected = BadRequestException.class)
	public void testDocumentWithNoDocSts() {
		this.document.setDocSts(null);
		this.validator.validate(this.document);
	}

	@Test(expected = BadRequestException.class)
	public void testDocumentWithNoDocIDTyp() {
		this.document.setDocIDTyp(null);
		this.validator.validate(this.document);
	}

	@Test(expected = BadRequestException.class)
	public void testDocumentWithNoFrmtTyp() {
		this.document.setFrmtTyp(null);
		this.validator.validate(this.document);
	}

	@Test(expected = BadRequestException.class)
	public void testDocumentWithNoDocBizUnit() {
		this.document.setDocBizUnit(null);
		this.validator.validate(this.document);
	}

	@Test(expected = BadRequestException.class)
	public void testDocumentWithNoDocVrsn() {
		this.document.setDocVrsn(null);
		this.validator.validate(this.document);
	}

	@Test(expected = BadRequestException.class)
	public void testDocumentWithNoMimeTyp() {
		this.document.setMimeTyp(null);
		this.validator.validate(this.document);
	}

	@Test
	public void testValidDocument() {
		this.validator.validate(this.document);
	}
}
