grant select on "ACTIVITIAPP"."NXTGEN_ASYNC_MESSAGE" to actapp_readonly;
grant select on "ACTIVITIAPP"."NXTGEN_ASYNC_SEQUENCE" to actapp_readonly;
grant select on "NXTGENAPP"."CTH_BPM_PROCESS_INIT" to nxtgenapp_readonly;
grant select on "NXTGENAPP"."CTH_BPM_INIT_SEQUENCE" to nxtgenapp_readonly;

grant select,insert,delete,update on "NXTGENAPP"."CTH_BPM_PROCESS_INIT" to nxtgenapp_readwrite;
grant select,insert,delete,update on "ACTIVITIAPP"."NXTGEN_ASYNC_MESSAGE" to actapp_readwrite;