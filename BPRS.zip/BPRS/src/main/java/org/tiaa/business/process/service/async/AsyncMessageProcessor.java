package org.tiaa.business.process.service.async;

public interface AsyncMessageProcessor {

	public boolean isEventTypeProcessable(String eventType);

	public String getMessageMetaData(final String data);

	public void processMessage(String data);
}
