package org.tiaa.business.process.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CTH_BPM_PROCESS_INIT")
public class CTHBpmProcessInit {
	
	@Id
	@SequenceGenerator(name = "cthBpmInitSequence", sequenceName = "CTH_BPM_INIT_SEQUENCE", allocationSize=1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cthBpmInitSequence")
	@Column(name = "CTHBPMID")
	private Long cthBpmId;
	
	@Column(name = "CTHPROCESSTYPE")
	private String cthProcessType;

	@Column(name = "CTHREQUESTTYPE")
	private String cthRequestType;

	@Column(name = "CTHEVENTTYPE")
	private String cthEventName;

	@Column(name = "BPMPROCESSDEFKEY")
	private String bpmProcessDefKey;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_DATE")
	private Date createDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_DATE")
	private Date updateDate;
	
	@Column(name = "USERID")
	private Long userId;

	
	/**
	 * @return the createTs
	 */
	public Date getCreateTs() {
		return createDate;
	}

	/**
	 * @param createTs the createTs to set
	 */
	public void setCreateTs(Date createTs) {
		this.createDate = createTs;
	}

	/**
	 * @return the updateTs
	 */
	public Date getUpdateTs() {
		return updateDate;
	}

	/**
	 * @param updateTs the updateTs to set
	 */
	public void setUpdateTs(Date updateTs) {
		this.updateDate = updateTs;
	}

	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	/**
	 * @return the cthBpmId
	 */
	public Long getCthBpmId() {
		return cthBpmId;
	}

	/**
	 * @param cthBpmId the cthBpmId to set
	 */
	public void setCthBpmId(Long cthBpmId) {
		this.cthBpmId = cthBpmId;
	}

	/**
	 * @return the cthProcessType
	 */
	public String getCthProcessType() {
		return cthProcessType;
	}

	/**
	 * @param cthProcessType the cthProcessType to set
	 */
	public void setCthProcessType(String cthProcessType) {
		this.cthProcessType = cthProcessType;
	}

	/**
	 * @return the cthRequestType
	 */
	public String getCthRequestType() {
		return cthRequestType;
	}

	/**
	 * @param cthRequestType the cthRequestType to set
	 */
	public void setCthRequestType(String cthRequestType) {
		this.cthRequestType = cthRequestType;
	}

	/**
	 * @return the cthEventName
	 */
	public String getCthEventName() {
		return cthEventName;
	}

	/**
	 * @param cthEventName the cthEventName to set
	 */
	public void setCthEventName(String cthEventName) {
		this.cthEventName = cthEventName;
	}

	/**
	 * @return the bpmProcessDefKey
	 */
	public String getBpmProcessDefKey() {
		return bpmProcessDefKey;
	}

	/**
	 * @param bpmProcessDefKey the bpmProcessDefKey to set
	 */
	public void setBpmProcessDefKey(String bpmProcessDefKey) {
		this.bpmProcessDefKey = bpmProcessDefKey;
	}
	
}
