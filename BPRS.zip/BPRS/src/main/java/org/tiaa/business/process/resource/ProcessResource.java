package org.tiaa.business.process.resource;

import static org.tiaa.business.process.util.Constants.*;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import org.tiaa.business.process.resource.util.ResourceUtil;
import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.service.wrapper.ProcessService;
import org.tiaa.business.process.util.ValidatorUtil;
import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.esb.case_management_common_types.types.Comments;
import org.tiaa.esb.case_management_common_types.types.Process;
import org.tiaa.esb.case_management_common_types.types.Properties;
import org.tiaa.esb.case_management_common_types.types.Tasks;
import org.tiaa.esb.case_management_rs_v2_0.types.CommentsResponse;
import org.tiaa.esb.case_management_rs_v2_0.types.DocumentRequest;
import org.tiaa.esb.case_management_rs_v2_0.types.DocumentResponse;
import org.tiaa.esb.case_management_rs_v2_0.types.DocumentsResponse;
import org.tiaa.esb.case_management_rs_v2_0.types.ProcessRequest;
import org.tiaa.esb.case_management_rs_v2_0.types.ProcessResponse;
import org.tiaa.esb.case_management_rs_v2_0.types.Signal;
import org.tiaa.esb.case_management_rs_v2_0.types.TasksResponse;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Documents;

/**
 * Process Resource
 *
 * @author subashr
 *
 */
@RestController
@ResponseStatus(HttpStatus.OK)
public class ProcessResource {

	@Autowired
	ProcessService processService;

	@Autowired
	ValidatorUtil validatorUtil;

	@Autowired
	ResourceUtil resourceUtil;

	@RequestMapping(value = { "/process" }, method = RequestMethod.POST, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE }, consumes = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	@ResponseStatus(HttpStatus.CREATED)
	public ProcessResponse startProcess(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@RequestBody ProcessRequest processRequest) {

		this.validatorUtil.validate(processRequest);
		Process process = processRequest.getProcess();

		Process processFromWrapper = this.processService.startProcess(process,
				userId, basicAuth);

		ProcessResponse processResponse = new ProcessResponse();
		processResponse.setProcess(processFromWrapper);
		processResponse.setResponseStatus(this.resourceUtil.getCreatedStatus());

		return processResponse;
	}

	@RequestMapping(value = { "/process/{processId}" }, method = RequestMethod.GET, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public ProcessResponse getProcess(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@QueryParam("lock") String lock) {
		Process process = this.processService.getProcessById(processId, userId,
				basicAuth, false, Boolean.valueOf(lock));
		ProcessResponse processResponse = new ProcessResponse();
		processResponse.setProcess(process);
		processResponse.setResponseStatus(this.resourceUtil.getOkStatus());

		return processResponse;
	}

	@RequestMapping(value = { "/process/{processId}" }, method = RequestMethod.PUT, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE }, consumes = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public ProcessResponse updateProcess(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@RequestBody ProcessRequest processRequest) {

		this.validatorUtil.validatePathParams(processId);

		Process process = processRequest.getProcess();

		if ((process == null) || (process.getAction() == null)
				|| (process.getAction().getItem().size() == 0)) {
			throw new BadRequestException("Action in Request cannot be NULL");
		}

		String action = process.getAction().getItem().get(0);

		if (!("unlock".equalsIgnoreCase(action) || "update"
				.equalsIgnoreCase(action))) {
			throw new BadRequestException(
					"Only Unlock and Update Action are supported");
		}

		Properties props = process.getProcessProperties();

		if (props != null) {
			this.validatorUtil.validate(props);
		}

		this.processService.updateProcess(processId, props, action, userId,
				basicAuth);

		ProcessResponse processResponse = new ProcessResponse();
		processResponse.setResponseStatus(this.resourceUtil.getOkStatus());

		return processResponse;
	}

	@RequestMapping(value = { "/process/{processId}/documents" }, method = RequestMethod.GET, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public DocumentsResponse getProcessDocuments(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId) {

		this.validatorUtil.validatePathParams(processId);
		DocumentsResponse resp = new DocumentsResponse();
		Documents docs = new Documents(); 
		resp.setDocs(docs);
		/*Documents docs = this.processService.getProcessDocuments(processId,
				userId, basicAuth);
		resp.setDocs(docs);*/
		return resp;
	}

	@RequestMapping(value = { "/process/{processId}/document/{documentId}" }, method = RequestMethod.GET, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public DocumentResponse getProcessDocument(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@PathVariable("documentId") String documentId) {
		this.validatorUtil.validatePathParams(new String[] { processId,
				documentId });

     /*	Document doc = this.processService.getProcessDocument(processId,
				documentId, userId, basicAuth);

		DocumentResponse response = new DocumentResponse();
		response.setDocument(doc);
		response.setResponseStatus(this.resourceUtil.getOkStatus());
		*/
		DocumentResponse response = new DocumentResponse();
		Document doc = new Document();
		response.setDocument(doc);
		return response;
	}

	@RequestMapping(value = { "/process/{processId}/document" }, method = RequestMethod.POST, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE }, consumes = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	@ResponseStatus(HttpStatus.CREATED)
	public DocumentResponse addProcessDocument(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@RequestBody DocumentRequest documentRequest) {
		this.validatorUtil.validate(documentRequest.getDocument());
		Document doc = this.processService.addProcessDocument(processId,
				documentRequest.getDocument(), userId, basicAuth);

		DocumentResponse response = new DocumentResponse();
		response.setDocument(doc);
		response.setResponseStatus(this.resourceUtil.getCreatedStatus());
		return response;
	}

	@RequestMapping(value = { "/process/{processId}/comments" }, method = RequestMethod.GET, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public CommentsResponse getProcessComments(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId) {

		this.validatorUtil.validatePathParams(processId);

		/*Comments comments = this.processService.getProcessComments(processId,
				userId, basicAuth);
		CommentsResponse commentResp = new CommentsResponse();
		commentResp.setComments(comments);
		 */
		CommentsResponse commentResp = new CommentsResponse();
		Comments comments = new Comments();
		commentResp.setComments(comments);
		return commentResp;
	}

	@RequestMapping(value = { "/process/{processId}/comment" }, method = RequestMethod.POST, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE }, consumes = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	@ResponseStatus(HttpStatus.CREATED)
	public Comment addProcessComments(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@RequestBody Comment comment) {

		this.validatorUtil.validatePathParams(processId);
		this.validatorUtil.validate(comment);
		Comment commentResponse = this.processService.addProcessComment(
				processId, comment, userId, basicAuth);
		return commentResponse;
	}

	@RequestMapping(value = { "/process/{processId}/tasks" }, method = RequestMethod.GET, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	@ResponseBody
	public TasksResponse getProcessTasks(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId) {
		this.validatorUtil.validatePathParams(processId);

		Tasks tasks = this.processService.getProcessTasks(processId, userId,
				basicAuth);

		TasksResponse taskResp = new TasksResponse();
		taskResp.setTasks(tasks);
		return taskResp;

	}

	@RequestMapping(value = { "/process/{processId}/history" }, method = RequestMethod.GET, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public ProcessResponse getProcessHistory(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId) {

		this.validatorUtil.validatePathParams(processId);

		ProcessResponse processResponse = new ProcessResponse();
		processResponse.setProcess(this.processService.getProcessHistory(
				processId, userId, basicAuth));
		return processResponse;
	}

	@RequestMapping(value = { "/process/{processId}/document/{documentId}" }, method = RequestMethod.PUT, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE }, consumes = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	@ResponseStatus(HttpStatus.OK)
	public DocumentResponse updateProcessDocument(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@PathVariable("documentId") String documentId,
			@RequestBody DocumentRequest documentRequest) {

		this.validatorUtil.validate(documentRequest.getDocument());
		Document doc = this.processService.updateProcessDocument(processId,
				documentId, documentRequest.getDocument(), userId, basicAuth);

		DocumentResponse response = new DocumentResponse();
		response.setDocument(doc);
		response.setResponseStatus(this.resourceUtil.getCreatedStatus());
		return response;
	}

	@RequestMapping(value = { "/process/{processId}/message" }, method = RequestMethod.POST, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE }, consumes = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	@ResponseStatus(HttpStatus.CREATED)
	public ProcessResponse signalMessage(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@RequestBody Signal signalRequest) {

		this.validatorUtil.validate(signalRequest);

		Process process = this.processService.signalMessage(processId,
				signalRequest.getMessageName(),
				signalRequest.getSignalProperties(), userId, basicAuth);

		ProcessResponse processResponse = new ProcessResponse();
		processResponse.setProcess(process);
		processResponse.setResponseStatus(this.resourceUtil.getOkStatus());

		return processResponse;
	}

}
