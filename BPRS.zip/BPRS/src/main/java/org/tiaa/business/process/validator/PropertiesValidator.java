package org.tiaa.business.process.validator;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.esb.case_management_common_types.types.Properties;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.NameValue;

/**
 *
 * @author subashr
 *
 */
@Component
public class PropertiesValidator implements ObjectValidator<Properties> {

	private static final int VAR_STR_MAX_SIZE = 100000;

	@Override
	public void validate(Properties obj) {

		if ((obj == null) || (obj.getProperty().isEmpty())) {
			throw new BadRequestException("Properties cannot be NULL");
		}

		Set<String> keySet = new HashSet<String>();

		for (NameValue nvPair : obj.getProperty()) {

			String name = nvPair.getDesc() != null ? nvPair.getDesc() : nvPair.getName();
			if (StringUtils.isBlank(name)) {
				throw new BadRequestException("Property Name Cannot be NULL");
			}

			if (!keySet.add(name)) {
				throw new BadRequestException("Property with Name '" + name + "' is duplicated");
			}

			if ((nvPair.getValue() != null) && (nvPair.getValue().length() >= VAR_STR_MAX_SIZE)) {
				throw new BadRequestException("Max Length cannot exceed " + VAR_STR_MAX_SIZE
						+ " for property '" + name + "'");
			}
		}
	}
}
