package org.tiaa.business.process.validator;

/**
 *
 * @author subashr
 *
 * @param <T>
 */
public interface ObjectValidator<T> {
	public void validate(T obj);
}
