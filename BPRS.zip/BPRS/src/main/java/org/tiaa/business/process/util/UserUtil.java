package org.tiaa.business.process.util;

import org.apache.commons.codec.binary.Base64;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class UserUtil {

	// Activiti Wrapper Properties
	@Value("${activiti.wrapper.userName}")
	private String activitiWrapperUserName;

	@Value("${activiti.wrapper.password}")
	private String activitiWrapperPassword;

	public String generateWrapperBasicAuth() {
		return "Basic "
				+ Base64.encodeBase64String((this.activitiWrapperUserName + ":" + CryptUtility
						.decrypt(this.activitiWrapperPassword)).getBytes());
	}
}
