package org.tiaa.business.process.util;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.service.exception.BusinessProcessApplicationException;
import org.tiaa.business.process.validator.ObjectValidator;

/**
 *
 * @author subashr
 *
 */
@Component
@SuppressWarnings({ "unchecked", "rawtypes" })
public class ValidatorUtil {

	private static final String TYPE_NAME_PREFIX = "class ";

	@Autowired
	private List<ObjectValidator> objectValidators;

	public void validate(final Object obj) {
		if (obj == null) {
			throw new BadRequestException("Null input request obtained.");
		}
		ObjectValidator validator = getValidator(obj.getClass()
				.getCanonicalName());
		validator.validate(obj);
		return;
	}

	public void validatePathParams(final String pathParam) {
		validatePathParams(new String[] { pathParam });
	}

	public void validatePathParams(final String[] pathParams) {
		for (String queryParam : pathParams) {
			if (!StringUtils.isNumeric(queryParam)) {
				throw new BadRequestException(
						"Invalid Path Param. Only Numeric values are accepted!!");
			}
		}
	}

	private ObjectValidator getValidator(final String className) {

		for (ObjectValidator c : this.objectValidators) {
			Type[] type = c.getClass().getGenericInterfaces();
			if (type[0] instanceof ParameterizedType) {
				ParameterizedType parameterizedType = (ParameterizedType) type[0];
				Type[] typeArguments = parameterizedType
						.getActualTypeArguments();

				// TODO: to revisit again with jdk1.7.
				// typeArguments[0].getType() doesnt work
				// with jdk8
				String strClassname = typeArguments[0].toString();
				if (strClassname.startsWith(TYPE_NAME_PREFIX)) {
					strClassname = strClassname.substring(TYPE_NAME_PREFIX
							.length());
				}
				if (className.equalsIgnoreCase(strClassname)) {
					return c;
				}
			}
		}
		throw new BusinessProcessApplicationException("No Validator found for class:" + className);
	}

	public List<ObjectValidator> getObjectValidators() {
		if (this.objectValidators == null) {
			this.objectValidators = new ArrayList<ObjectValidator>();
		}
		return this.objectValidators;
	}
}