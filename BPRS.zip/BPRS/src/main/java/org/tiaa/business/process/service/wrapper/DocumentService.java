package org.tiaa.business.process.service.wrapper;

import java.io.StringWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.log4j.Logger;
import org.apache.ws.security.message.token.UsernameToken;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.http.converter.xml.MarshallingHttpMessageConverter;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.service.exception.BusinessProcessApplicationException;
import org.tiaa.business.process.util.Constants;
import org.tiaa.business.process.util.CryptUtility;
import org.tiaa.business.process.util.GuidUtility;
import org.tiaa.business.process.util.MimeTypeHelper;
import org.tiaa.esb.federated_document_rs_v1_0.types.Artifact;
import org.tiaa.esb.federated_document_rs_v1_0.types.Attachment;
import org.tiaa.esb.federated_document_rs_v1_0.types.DocTypeOverride;
import org.tiaa.esb.federated_document_rs_v1_0.types.DocumentDetails;
import org.tiaa.esb.federated_document_rs_v1_0.types.Metadata;
import org.tiaa.esb.federated_document_rs_v1_0.types.ObjectFactory;
import org.tiaa.esb.federated_document_rs_v1_0.types.StoreDocumentsRequest;
import org.tiaa.esb.federated_document_rs_v1_0.types.StoreDocumentsResponse;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;

/**
 * This is a Document Service class which has operations to interact with FDRS
 * 
 * @author pamdama
 *
 */
@Service
public class DocumentService {
	
	private static final Logger LOGGER = Logger.getLogger(DocumentService.class);
	
	private static final String FEDERATED_DOCUMENT = "vnd.tiaa.federated-document-rs-v1.0+xml";

	private static final String CONTENT_TYPE_XML = "application/vnd.tiaa.federated-document-rs-v1.0+xml";
	private static final String XML_FORM_NAME = "file1";

	public static final String UPLOAD_DOCUMENT_TITLE = "DocumentTitle";
	public static final String UPLOAD_PIN = "PIN";
	public static final String UPLOAD_PLAN_NUMBER = "PlanNumber";
	public static final String UPLOAD_CLIENT_ID = "Client_ID";
	public static final String UPLOAD_MIME_TYPE = "MimeType";
	public static final String UPLOAD_DRI = "DocumentRequestID";
	public static final String UPLOAD_ORCH_ID = "Orchestration_ID";
	public static final String UPLOAD_PLAN_ID = "Plan_ID";
	public static final String UPLOAD_FILE_NAME = "Filename";
	public static final String UPLOAD_DOCUMENT_DESCRIPTION = "Document_Description";
	public static final String UPLOAD_BUSINESS_DATE = "Business_Date";
	public static final String UPLOAD_CUSTOMER_NUMBER = "Customer_Number";
	public static final String FDRS_URL =  "/federated-document-rs-v1/documents?business-unit-code={BIZ_UNIT}&doc-code={DOC_CODE}&version={VER}&id-type={DOC_TYPE_ID}";

	private static final String COLON = ":";
	
	Jaxb2Marshaller jaxb2Marshaller;

	@Value("${esb.int5.url}")
	private String mobiusServiceUrl;
	
	@Value("${bpm.mobiusService.consumer}")
	private String tiaaConsumer;
	
	@Value("${bpm.mobiusService.userRef}")
	private String tiaaUserRef;
	
	@Value("${bpm.mobiusService.pwd}")
	private String tiaaPwd;
	
	@Autowired
	RestTemplate restTemplate;
	

	public String storeDocInMobius(Document document) {

		restTemplate.setMessageConverters(createMessageConverters());

		Map<String, String> documentDataMap = createDocData(document);
		HttpEntity<MultiValueMap<String, Object>> request = null;

		try {
			request = createRequestEntity(documentDataMap,readDocContent(document), document);
		} catch (JAXBException e) {
			throw new BadRequestException("Error Creating Request Entities for FDRS", e);
		}
		StringBuilder url = new StringBuilder();
		url.append(mobiusServiceUrl).append(FDRS_URL);
		LOGGER.info("FDRS Service URL - "+url.toString());
		ResponseEntity<StoreDocumentsResponse> response = restTemplate.exchange(url.toString(), HttpMethod.POST,	request, StoreDocumentsResponse.class, createUrlVariableMap(document));
		StoreDocumentsResponse storeDocumentResponse = response.getBody();
		String status = storeDocumentResponse.getResponseStatus().getStatus();
		LOGGER.info("Completed document " +document.getDocName() + " archival to Mobius with Status - "+status);
		
		if ("SUCCESS".equals(status)) {
			LOGGER.info("Document UPLOAD_DRI - "+documentDataMap.get(UPLOAD_DRI));
			return documentDataMap.get(UPLOAD_DRI);
		}
		String responseXml = null;
		try {
			responseXml = marshal(storeDocumentResponse);
			LOGGER.info("Response XML from Mobius - " + responseXml);
			throw new BusinessProcessApplicationException("Unsuccessfull Document Archival .Federated-document-rs-v1 returned status: " + status + ", response xml: " + responseXml);

		} catch (JAXBException e) {
			LOGGER.error(e);
			throw new BusinessProcessApplicationException("Error Marshalling response from Mobius");
		}
	}

	private Map<String, String> createDocData(Document document) {

		Map<String, String> documentDataMap = new HashMap<String, String>();
		documentDataMap.put(UPLOAD_PLAN_NUMBER, document.getPlanNum());
		documentDataMap.put(UPLOAD_MIME_TYPE, document.getMimeTyp());
		documentDataMap.put(UPLOAD_DOCUMENT_TITLE, document.getDocTitle());
		documentDataMap.put(UPLOAD_FILE_NAME, document.getDocName());
		documentDataMap.put(UPLOAD_BUSINESS_DATE, currentDate());

		return documentDataMap;
	}

	private String currentDate() {
		return new SimpleDateFormat("yyyyMMdd").format(new Date());
	}

	private Resource readDocContent(Document document) {
		byte[] bFile = document.getDocContent();
		Resource inputStream = new ByteArrayResource(bFile);
		return inputStream;

	}

	private Map<String, String> createUrlVariableMap(Document document) {
		Map<String, String> urlVariables = new HashMap<String, String>();
		urlVariables.put("BIZ_UNIT", document.getDocBizUnit());
		urlVariables.put("DOC_CODE", document.getDocTemplateCd());
		urlVariables.put("VER", String.valueOf(document.getDocVrsn()));
		urlVariables.put("DOC_TYPE_ID", document.getDocIDTyp());
		return urlVariables;
	}

	private HttpEntity<MultiValueMap<String, Object>> createRequestEntity(Map<String, String> documentDataMap, Resource inputStream, Document document)throws JAXBException {
		MultiValueMap<String, Object> multipartMap = new LinkedMultiValueMap<String, Object>();
		addMultiParts(multipartMap, documentDataMap, inputStream, document);
		// using http entity for part to specify part content type
		return new HttpEntity<MultiValueMap<String, Object>>(multipartMap,createHttpHeader());
	}

	private void addMultiParts(MultiValueMap<String, Object> multipartMap,	Map<String, String> documentDataMap, Resource inputStream,Document document)	throws JAXBException {
		String documentTitle = documentDataMap.get(UPLOAD_DOCUMENT_TITLE);
		multipartMap.add(XML_FORM_NAME, createXMLPart(documentDataMap,document));
		multipartMap.add(documentTitle,	createFilePart(documentDataMap, inputStream));
	}

	private HttpEntity<Resource> createFilePart(final Map<String, String> documentDataMap, Resource resource) {
		HttpHeaders fileHeaders = new HttpHeaders();
		fileHeaders.add("Content-type", documentDataMap.get(UPLOAD_MIME_TYPE));
		return new HttpEntity<Resource>(resource, fileHeaders);
	}

	private HttpHeaders createHttpHeader() {
		HttpHeaders reqheaders = new HttpHeaders();
		setHeaders(reqheaders);
		reqheaders.setContentType(MediaType.MULTIPART_FORM_DATA);
		reqheaders.set("Accept", CONTENT_TYPE_XML);
		reqheaders.setAccept(Collections.singletonList(MediaType.valueOf(CONTENT_TYPE_XML)));
		return reqheaders;
	}

	public void setHeaders(HttpHeaders headers) {
		String guid = new GuidUtility().toString();

		headers.set(Constants.TIAA_GUID, guid);
		headers.set(Constants.TIAA_CORRELATION_ID, guid);
		LOGGER.info("FDRS document archival call for GUID - "+guid);
		headers.set(Constants.TIAA_PARTNER_ID, "");
		headers.set(Constants.TIAA_CONSUMER, tiaaConsumer);
		headers.set(Constants.TIAA_USER_REF, tiaaUserRef);
		headers.set(Constants.TIAA_SENDER_MACHINE, getHostNameInternal());
		final String currentTimestamp = currentTimestamp();
		headers.set(Constants.TIAA_TIMESTAMP, currentTimestamp);
		headers.set(Constants.TIAA_DIGEST, UsernameToken.doPasswordDigest("",currentTimestamp, CryptUtility.decrypt(tiaaPwd)));
	}

	private String getHostNameInternal() {
		try {
			return InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			LOGGER.error(e);
		}
		return null;
	}

	private String currentTimestamp() {
		TimeZone gmtTimeZone = TimeZone.getTimeZone("GMT");
		return DatatypeConverter.printDateTime(GregorianCalendar.getInstance(gmtTimeZone));
	}

	private HttpEntity<String> createXMLPart(Map<String, String> documentDataMap,Document document)
			throws JAXBException {
		// Add xml entity
		HttpHeaders xmlFileHeaders = new HttpHeaders();
		xmlFileHeaders.add("Content-type", CONTENT_TYPE_XML);
		StoreDocumentsRequest request = createStoreDocumentsRequest(documentDataMap,document);
		String xml = marshal(request);
		return new HttpEntity<String>(xml, xmlFileHeaders);
	}

	private String marshal(Object request) throws JAXBException {
		JAXBContext jaxbContext = jaxb2Marshaller.getJaxbContext();
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		jaxbMarshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
		StringWriter sw = new StringWriter();
		jaxbMarshaller.marshal(request, sw);
		return sw.toString();
	}

	private StoreDocumentsRequest createStoreDocumentsRequest(Map<String, String> documentDataMap,Document document) {
		String pin = documentDataMap.get(UPLOAD_PIN);
		String clientId = documentDataMap.get(UPLOAD_CLIENT_ID);
		String dri = computeDRI(pin, clientId,document);
		documentDataMap.put(UPLOAD_DRI, dri);

		DocTypeOverride docTypeOverride = new DocTypeOverride();
		docTypeOverride.setBusinessUnitCode(document.getDocBizUnit());
		docTypeOverride.setDocCode(document.getDocTemplateCd());
		docTypeOverride.setDocumentTypeId(document.getDocIDTyp());
		docTypeOverride.setVersion(String.valueOf(document.getDocVrsn()));

		DocumentDetails documentDetails = new DocumentDetails();
		documentDetails
				.setFileAssociation(getExtensionFromMimeType(documentDataMap));
		addMetadata(documentDataMap, documentDetails);

		Artifact artifact = new Artifact();
		artifact.setDocTypeOverride(docTypeOverride);
		artifact.setDocumentDetails(documentDetails);

		String fileName = documentDataMap.get(UPLOAD_DOCUMENT_TITLE);
		artifact.setName(fileName);

		Attachment attachment = new Attachment();
		attachment.setArtifact(artifact);

		StoreDocumentsRequest request = new StoreDocumentsRequest();
		request.getAttachments().add(attachment);
		return request;
	}

	private String nullSafe(String str) {
		return str == null ? "" : str;
	}

	private void addMetaData(String name, String value,	List<Metadata> metadataList) {
		Metadata metadata = new Metadata();
		metadata.setName(name);
		metadata.setValue(value);
		metadataList.add(metadata);
	}

	private void addMetadata(Map<String, String> documentDataMap,
			DocumentDetails documentDetails) {
		List<Metadata> metadataList = documentDetails.getMetadata();
		
		String dri = documentDataMap.get(UPLOAD_DRI);
		addMetaData("Document_Request_ID", dri, metadataList);
		
		String orchId = documentDataMap.get(UPLOAD_ORCH_ID);
		addMetaData("Orchestration_ID", nullSafe(orchId), metadataList);
		
		String clientId = documentDataMap.get(UPLOAD_CLIENT_ID);
		addMetaData("Client_ID", nullSafe(clientId), metadataList);
		
		String customerNumber = documentDataMap.get(UPLOAD_CUSTOMER_NUMBER);
		addMetaData("Customer_Number", customerNumber, metadataList);
		
		String planNumber = documentDataMap.get(UPLOAD_PLAN_NUMBER);
		addMetaData("Plan_ID", nullSafe(planNumber), metadataList);
		
		String fileName = documentDataMap.get(UPLOAD_FILE_NAME);
		addMetaData("Filename", fileName, metadataList);
		
		String description = documentDataMap.get(UPLOAD_DOCUMENT_TITLE);
		addMetaData("Document_Description", description, metadataList);
		
		String businesDate = documentDataMap.get(UPLOAD_BUSINESS_DATE);
		addMetaData("Business_Date", businesDate, metadataList);
	}

	// convert mime type to file suffix.
	private String getExtensionFromMimeType(Map<String, String> documentDataMap) {
		String mimeType = documentDataMap.get(UPLOAD_MIME_TYPE);
		String extensionFromMimeType = MimeTypeHelper.getExtensionFromMimeType(mimeType);
		return extensionFromMimeType;
	}

	private String computeDRI(String pin, String clientId, Document document) {
		String universalId = (pin != null) ? pin : clientId;
		String universalIDAppender = pad('0', universalId, 13);
		universalIDAppender = universalIDAppender.substring(Math.max(0,
				universalIDAppender.length() - 13));
		
		SimpleDateFormat dformat = new SimpleDateFormat("yyyyMMddHHmmss");
		dformat.setTimeZone(TimeZone.getTimeZone("UTC"));
		String now = dformat.format(new Date());
		
		return new StringBuilder().append(document.getDocIDTyp()).append(COLON).append(now).append(universalIDAppender).toString();
	}

	private final String pad(final char paddingChar, final String aString,
			final int padLimit) {
		if (aString == null) {
			/*
			 * pad('0', null, 6) becomes "000000"
			 */
			return pad(paddingChar, "", padLimit); //$NON-NLS-1$
		}
		final int slength = aString.length();
		if (padLimit > slength) {
			/*
			 * pad('0', "1234", 6) becomes "001234"
			 */
			final int padding = padLimit - slength;
			final char[] t = new char[padLimit];
			Arrays.fill(t, 0, padding, paddingChar);
			System.arraycopy(aString.toCharArray(), 0, t, padding, slength);
			return String.valueOf(t);
		}
		return aString;
	}

	private List<HttpMessageConverter<?>> createMessageConverters() {
		jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setClassesToBeBound(ObjectFactory.class,StoreDocumentsResponse.class);

		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		FederatedDocumentMarshallingHttpMessageConverter mhmc = new FederatedDocumentMarshallingHttpMessageConverter(
				jaxb2Marshaller);
		mhmc.setSupportedMediaTypes(Arrays.asList(
				new org.springframework.http.MediaType("application",FEDERATED_DOCUMENT),
				org.springframework.http.MediaType.APPLICATION_XML,
				org.springframework.http.MediaType.TEXT_XML,
				org.springframework.http.MediaType.TEXT_HTML,
				org.springframework.http.MediaType.APPLICATION_OCTET_STREAM));

		messageConverters.add(mhmc);
		FormHttpMessageConverter fmc = new FormHttpMessageConverter();
		fmc.addPartConverter(new Jaxb2RootElementHttpMessageConverter());
		messageConverters.add(fmc);
		return messageConverters;
	}

	public class FederatedDocumentMarshallingHttpMessageConverter extends
			MarshallingHttpMessageConverter {

		public FederatedDocumentMarshallingHttpMessageConverter(
				org.springframework.oxm.Marshaller marshaller) {
			super(marshaller);
		}

		@Override
		public boolean canRead(Class<?> clazz, MediaType mediaType) {
			return canRead(mediaType);
		}

		@Override
		protected boolean canRead(MediaType mediaType) {
			if (mediaType == null) {
				return false;
			}
			String type = mediaType.getType();
			if ("application/vnd.tiaa.federated-document-rs-v1.0+xml;profile=federated-document-rs-v1.0.xsd"
					.equals(type)) {
				return true;
			}
			if (MediaType.APPLICATION_XML.getType().equals(type)) {
				return true;
			}
			return false;
		}
	}

}
