package org.tiaa.business.process.resource;

import static org.tiaa.business.process.util.Constants.*;

import javax.ws.rs.QueryParam;

import org.elasticsearch.common.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import org.tiaa.business.process.service.config.ConfigService;
import org.tiaa.business.process.util.Constants;
import org.tiaa.esb.case_management_common_types.types.ConfigItems;
import org.tiaa.esb.case_management_rs_v2_0.types.ConfigItemsResponse;

/**
 * This is the controller class for all the Config Operations
 * @author pamdama
 *
 */
@RestController
@ResponseStatus(HttpStatus.OK)
public class ConfigResource {
	
	@Autowired
	ConfigService configService;
	
	@RequestMapping(value = { "/config" }, method = RequestMethod.GET, produces = {JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public ConfigItemsResponse getSearchConfigs(@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@QueryParam("property") String property) {

		ConfigItemsResponse response = new ConfigItemsResponse();
		ConfigItems configItems = null;

		if(Constants.CONFIG_BUSINESSAREA.equals(property)){
			configItems  = configService.getBusinessAreas(basicAuth);
		} 
		else if(Constants.CONFIG_IDENTIFIER.equals(property)){
			configItems  = configService.getSearchIdentifiers(basicAuth);
		}
		else if(StringUtils.isNotEmpty(property)){
			configItems  = configService.getSearchAdditionalIdentifiers(basicAuth,property.toUpperCase());
		} 
		
		response.setConfigItems(configItems);
		
		return response;
	}
}
