package org.tiaa.business.process.converters;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.util.DateUtil;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.NameValue;

/**
 * Converter class to convert Object Model NameValue to Activiti Variable
 *
 * @author subashr
 *
 */
@Component
public class NameValueToActivitiVariableConverter implements
Converter<NameValue, ActivitiVariable> {

	@Override
	public ActivitiVariable convert(NameValue source) {

		if (source == null) {
			return null;
		}

		ActivitiVariable activitiVariable = new ActivitiVariable();
		activitiVariable.setName(source.getDesc() != null ? source.getDesc() : source
				.getName());

		String value = null;
		String type = null;

		if (source.isBooleanValue() != null) {
			value = source.isBooleanValue().toString();
			type = "Boolean";
		}
		else if (source.getDateValue() != null) {
			value = DateUtil.convertDateToString(source.getDateValue());
			type = "Date";
		}
		else if (source.getDecimalValue() != null) {
			value = String.valueOf(source.getDecimalValue());
			type = "Decimal";
		}
		else if (source.getNumValue() != null) {
			value = source.getNumValue().toString();
			type = "Integer";
		}
		else {
			value = source.getValue();
			type = "String";
		}

		activitiVariable.setValue(value);
		activitiVariable.setType(type);

		return activitiVariable;
	}
}
