package org.tiaa.business.process.filter.log;

import org.apache.commons.lang3.StringUtils;

public class RequestResponseLogger {

	private String requestURI;
	private String requestMethod;
	private String requestBody;
	private int responseStatusCode;
	private String responseBody;
	private long startTime;

	public RequestResponseLogger(String requestURI, String requestMethod,
			String requestBody) {
		this.requestURI = requestURI;
		this.requestMethod = requestMethod;
		this.requestBody = requestBody;
		this.startTime = System.currentTimeMillis();
	}

	public void setResponseBody(String responseBody) {
		this.responseBody = responseBody;
	}

	public void setResponseStatusCode(int responseStatusCode) {
		this.responseStatusCode = responseStatusCode;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Request URI: " + this.requestURI);
		sb.append(" Request Method: " + this.requestMethod);
		sb.append(" Response Status: " + this.responseStatusCode);
		sb.append(" Time Taken(ms): "
				+ (System.currentTimeMillis() - this.startTime));
		sb.append(" Request Body: "
				+ (this.requestBody != null ? StringUtils
						.trimToEmpty(this.requestBody.replace("\n", "")) : ""));
		sb.append(" Response Body: "
				+ (this.responseBody != null ? StringUtils
						.trimToEmpty(this.responseBody.replace("\n", "")) : ""));
		return sb.toString();
	}

}
