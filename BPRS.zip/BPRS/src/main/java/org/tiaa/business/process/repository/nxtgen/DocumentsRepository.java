package org.tiaa.business.process.repository.nxtgen;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import org.tiaa.business.process.entities.ProcessDocuments;

/**
 * @author polara
 *
 */
@Repository
public interface DocumentsRepository extends
CrudRepository<ProcessDocuments, Long> {

	ProcessDocuments findByProcessInstanceId(String processInstId);
}
