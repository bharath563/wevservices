package org.tiaa.business.process.service.deploy;

import java.util.HashMap;
import java.util.Map;

public class AppProcessModel {

	private String appName;
	private String appId;

	private Map<String, String> processModels = new HashMap<String, String>();

	public String getAppName() {
		return this.appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppId() {
		return this.appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public Map<String, String> getProcessModels() {
		return this.processModels;
	}
}