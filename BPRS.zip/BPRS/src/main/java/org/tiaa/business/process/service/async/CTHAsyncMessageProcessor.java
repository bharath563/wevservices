package org.tiaa.business.process.service.async;

import static org.tiaa.business.process.util.Constants.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.google.gson.GsonBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.es.ESSearchService;
import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.service.wrapper.ProcessService;
import org.tiaa.business.process.util.Constants;
import org.tiaa.business.process.util.UserUtil;
import org.tiaa.business.process.util.ValidatorUtil;
import org.tiaa.business.process.util.XMLUtil;
import org.tiaa.esb.case_management_common_types.types.Properties;
import org.tiaa.esb.case_management_common_types.types.SearchRequest;
import org.tiaa.esb.case_management_rs_v2_0.types.SearchResponse;
import org.tiaa.esb.transaction_event_rs_v1_0.types.EventRequest;
import org.tiaa.esb.transaction_event_rs_v1_0.types.EventType;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.NameValue;

@Component
public class CTHAsyncMessageProcessor implements AsyncMessageProcessor {

	private static final Logger LOGGER = Logger.getLogger(CTHAsyncMessageProcessor.class);

	@Autowired
	@Lazy
	ProcessService processService;

	@Autowired
	@Lazy
	XMLUtil xmlUtil;

	@Autowired
	@Lazy
	ValidatorUtil validatorUtil;

	@Autowired
	@Lazy
	UserUtil userUtil;

	@Value("${queue.activiti.userName}")
	private String queueuActivitiUserName;

	@Autowired
	ESSearchService esSearchService;

	@Autowired
	JdbcTemplate jdbcTemplate;

	private static final String GET_PROCESS_DEF_SQL = "SELECT BPMPROCESSDEFKEY FROM CTH_BPM_PROCESS_INIT WHERE CTHPROCESSTYPE = ? AND CTHREQUESTTYPE = ? AND CTHEVENTNAME = ?";

	@Override
	public void processMessage(String data) {

		// 1. to get EventRequest object. From it get processType,requestType
		// and eventName
		EventRequest eventRequest = this.xmlUtil.unMarshall(data, EventRequest.class);
		EventType event = eventRequest.getEvent();

		// 2 : validate the EventRequest object
		this.validatorUtil.validate(eventRequest);

		// 3. Identify if it's a CREATE/UPDATE request
		String eventName = event.getEventName();
		String requestType = event.getRequestType();
		String processType = event.getProcessType();
		String orchestId = event.getOrchestrationId();

		// A create request
		if (eventName.contains(Constants.CTH_CREATE_REQUEST)) {

			// Get the ProcessDefinition from the database
			List<String> cthProcess = this.jdbcTemplate.query(GET_PROCESS_DEF_SQL,
					new Object[] { processType, requestType, eventName }, new RowMapper<String>() {
						@Override
						public String mapRow(ResultSet rs, int rowNum) throws SQLException {

							String cthBpmProc = rs.getString("BPMPROCESSDEFKEY");
							LOGGER.info("BPMPROCESSDEFKEY - " + cthBpmProc);
							return cthBpmProc;
						}
					});

			if ((cthProcess == null) || (cthProcess.size() == 0)) {
				LOGGER.error("No ProcessDefintion found in database for processType - "
						+ processType + ", EventName - " + eventName + ", RequestType - "
						+ requestType);
				throw new BadRequestException(
						"Invalid CTH Create Event Request. No ProcessDefintion found in database for processType - "
								+ processType
								+ ", EventName - "
								+ eventName
								+ ", RequestType - "
								+ requestType);
			}

			for (String cthProcessDef : cthProcess) {
				if (StringUtils.isEmpty(cthProcessDef)) {
					LOGGER
							.error("Invalid Data, ProcessDefinition from database is null for requestType - "
									+ requestType
									+ " , processType - "
									+ processType
									+ ", eventName -"
									+ eventName);
					throw new BadRequestException(
							"Invalid Data, ProcessDefinition from database is null for requestType - "
									+ requestType + " , processType - " + processType + ", eventName -"
									+ eventName);
				}
				org.tiaa.esb.case_management_common_types.types.Process process = new org.tiaa.esb.case_management_common_types.types.Process();
				process.setProcessType(cthProcessDef);

				// Set Variables
				Properties props = new Properties();
				NameValue cthVar = new NameValue();
				cthVar.setName(Constants.ACT_FW_CTHEVENT_PAYLOAD);
				cthVar.setValue(data);
				props.getProperty().add(cthVar);
				process.setProcessProperties(props);
				this.processService.startProcess(process, this.queueuActivitiUserName,
						this.userUtil.generateWrapperBasicAuth());

			}
		}
		// An update request
		else if (eventName.contains(Constants.CTH_UPDATE_REQUEST)) {

			// "ACT_FW_CTHEVENT_CORR_ID - variable name
			// variable value - processType+Orchestrationid+RequestType
			StringBuilder buildCorrelation = new StringBuilder();
			// value to be ProcessType_RequestType_Orchestrationid
			buildCorrelation.append(processType).append("_").append(requestType).append("_")
					.append(orchestId);
			String correlationId = buildCorrelation.toString();

			// Make an ES search for the variable
			SearchRequest searchReq = new SearchRequest();
			Properties props = new Properties();

			NameValue nmVal = new NameValue();
			nmVal.setName(Constants.ACT_FW_CTHEVENT_CORR_ID);
			nmVal.setValue(correlationId);
			props.getProperty().add(nmVal);

			searchReq.setProperties(props);
			SearchResponse srchResp = this.esSearchService.queryESByVariable(searchReq,
					this.userUtil.generateWrapperBasicAuth(), null);

			if ((srchResp == null) || (srchResp.getProcesses().getProcess() == null)
					|| (srchResp.getProcesses().getProcess().size() == 0)) {
				LOGGER
						.error("Elastic Search Response is null or no processes found with the variable search criteria - "
								+ correlationId);
				throw new BadRequestException(
						"Elastic Search Response is null or no processes found with the variable search criteria - "
								+ correlationId);
			}

			List<org.tiaa.esb.case_management_common_types.types.Process> processes = srchResp
					.getProcesses().getProcess();
			List<String> processInstanceIds = new ArrayList<String>();

			for (org.tiaa.esb.case_management_common_types.types.Process proc : processes) {
				processInstanceIds.add(proc.getProcessId());
			}

			// invoke CTHUpdate request
			this.processService.updateCTHEvent(processInstanceIds, eventName, data,
					this.queueuActivitiUserName, this.userUtil.generateWrapperBasicAuth());
		}

	}

	@Override
	public boolean isEventTypeProcessable(String eventType) {
		return CTH_REQUEST_QUEUE_EVENT.equalsIgnoreCase(eventType);
	}

	@Override
	public String getMessageMetaData(String data) {
		EventRequest eventRequest = this.xmlUtil.unMarshall(data, EventRequest.class);
		EventType event = eventRequest.getEvent();

		// 3. Identify if it's a CREATE/UPDATE request
		String eventName = event.getEventName();
		String requestType = event.getRequestType();
		String processType = event.getProcessType();
		String orchestId = event.getOrchestrationId();

		Map<String, String> metaData = new HashMap<String, String>();
		metaData.put("eventName", eventName);
		metaData.put("requestType", requestType);
		metaData.put("processType", processType);
		metaData.put("orchestId", orchestId);

		return new GsonBuilder().create().toJson(metaData);
	}

}
