/**
 * 
 */
package org.tiaa.business.process.service.es;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

/**
 * @author polara
 * This class maps input property with elastic search identifiers
 *
 */
@Component
public class SearchIdentifierMapper {
	
	public Map<String,String> searchIdentifierMapper = new HashMap<String,String>();
    
    public SearchIdentifierMapper () {
          searchIdentifierMapper.put("PLAN", "LegalPlanId");
          
    }
    
    public String getMappedValue(final String identifier) {
          if (searchIdentifierMapper.containsKey(identifier.toUpperCase())) {
                 return searchIdentifierMapper.get(identifier.toUpperCase());
          }
          return identifier;
    }


}
