package org.tiaa.business.process.service.exception;

/**
 *
 * @author subashr
 *
 */
public class BusinessProcessApplicationException extends BusinessProcessBaseException{

	private static final long serialVersionUID = 1L;

	public BusinessProcessApplicationException(String message) {
		super(message);
	}

	public BusinessProcessApplicationException(String message, Throwable cause) {
		super(message, cause);
	}
}
