package org.tiaa.business.process.service.exception.handler;

import org.apache.log4j.Logger;

import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageConversionException;
import org.springframework.web.HttpMediaTypeException;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.UnsatisfiedServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import org.tiaa.business.process.service.exception.BadGatewayException;
import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.service.exception.BusinessProcessApplicationException;
import org.tiaa.business.process.service.exception.NotFoundException;
import org.tiaa.business.process.service.exception.NotPermittedException;
import org.tiaa.business.process.service.exception.UnAuthorizedException;
import org.tiaa.esb.case_management_rs_v2_0.types.ESBMessage;
import org.tiaa.esb.case_management_rs_v2_0.types.ESBMessages;
import org.tiaa.esb.case_management_rs_v2_0.types.ESBResponseStatusType;
import org.tiaa.esb.case_management_rs_v2_0.types.ProcessResponse;

/**
 * Spring REST Exception Handler class
 *
 * @author subashr
 *
 */
@ControllerAdvice
public class RestExceptionHandler {

	private static final Logger LOGGER = Logger
			.getLogger(RestExceptionHandler.class);

	private static final String UNAUTHORIZED_MESSAGE_KEY = "GENERAL.ERROR.UNAUTHORIZED";
	private static final String NOT_FOUND_MESSAGE_KEY = "GENERAL.ERROR.NOT-FOUND";
	private static final String METHOD_UNSUPPORTED_MESSAGE_KEY = "GENERAL.ERROR.METHOD-UNSUPPORTED";
	private static final String BAD_REQUEST_MESSAGE_KEY = "GENERAL.ERROR.BAD-REQUEST";
	private static final String NOT_PERMITTED_MESSAGE_KEY = "GENERAL.ERROR.NOT-PERMITTED";
	private static final String INTERNAL_SERVER_ERROR_MESSAGE_KEY = "GENERAL.ERROR.INTERNAL-SERVER_ERROR";
	private static final String MEDIA_UNSUPPORTED_MESSAGE_KEY = "GENERAL.ERROR.MEDIA-UNSUPPORTED";

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler({ NotFoundException.class })
	@ResponseBody
	public ProcessResponse handleNotFound(NotFoundException e) {
		return createESBMessageFromException(404, e, NOT_FOUND_MESSAGE_KEY);
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler({ BadRequestException.class,
			ServletRequestBindingException.class,
			HttpMessageConversionException.class,
		MissingServletRequestParameterException.class,
		UnsatisfiedServletRequestParameterException.class })
	@ResponseBody
	public ProcessResponse handleBadRequest(Exception e) {
		return createESBMessageFromException(400, e, BAD_REQUEST_MESSAGE_KEY);
	}

	@ResponseStatus(HttpStatus.UNSUPPORTED_MEDIA_TYPE)
	@ExceptionHandler({ HttpMediaTypeNotSupportedException.class,
			HttpMediaTypeNotAcceptableException.class,
		HttpMediaTypeException.class })
	@ResponseBody
	public ProcessResponse handleHttpMessageNotSupported(HttpMediaTypeException e) {
		return createESBMessageFromException(415, e,
				MEDIA_UNSUPPORTED_MESSAGE_KEY);
	}

	@ResponseStatus(HttpStatus.UNAUTHORIZED)
	@ExceptionHandler({ UnAuthorizedException.class })
	@ResponseBody
	public ProcessResponse handleUnAuthorized(UnAuthorizedException e) {
		return createESBMessageFromException(401, e, UNAUTHORIZED_MESSAGE_KEY);
	}

	@ResponseStatus(HttpStatus.BAD_GATEWAY)
	@ExceptionHandler({ BadGatewayException.class })
	@ResponseBody
	public ProcessResponse handleBadGateWay(BadGatewayException e) {
		return createESBMessageFromException(503, e, UNAUTHORIZED_MESSAGE_KEY);
	}

	@ResponseStatus(HttpStatus.CONFLICT)
	@ExceptionHandler({ NotPermittedException.class })
	@ResponseBody
	public ProcessResponse handleBadGateWay(NotPermittedException e) {
		return createESBMessageFromException(409, e, NOT_PERMITTED_MESSAGE_KEY);
	}

	@ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
	@ExceptionHandler({ HttpRequestMethodNotSupportedException.class })
	@ResponseBody
	public ProcessResponse handleHttpMethodNotSupported(
			HttpRequestMethodNotSupportedException e) {
		return createESBMessageFromException(405, e,
				METHOD_UNSUPPORTED_MESSAGE_KEY);
	}

	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler({ BusinessProcessApplicationException.class,
		Exception.class })
	@ResponseBody
	public ProcessResponse handleApplicationException(Exception e) {

		return createESBMessageFromException(500, e,
				INTERNAL_SERVER_ERROR_MESSAGE_KEY);
	}

	private ProcessResponse createESBMessageFromException(int statusCode,
			Exception exception, String type) {

		LOGGER.error(
				"StatusCode:" + statusCode + "  Message: "
						+ exception.getMessage(), exception);

		ProcessResponse response = new ProcessResponse();
		ESBResponseStatusType message = new ESBResponseStatusType();
		ESBMessages esbMessages = new ESBMessages();
		message.setStatus(String.valueOf(statusCode));
		message.setStatusText(String.valueOf(statusCode));
		message.setMessages(esbMessages);
		
		ESBMessage esbMessage = new ESBMessage();
		esbMessage.setCode(String.valueOf(statusCode));
		esbMessage.setText(exception.getMessage());
		esbMessage.setType(type);
		
		esbMessages.getMessage().add(esbMessage);
		response.setResponseStatus(message);	

		return response;
	}

}	
