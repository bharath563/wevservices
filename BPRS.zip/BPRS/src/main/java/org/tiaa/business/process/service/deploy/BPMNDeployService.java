package org.tiaa.business.process.service.deploy;

import java.io.IOException;
import java.io.StringReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.util.Constants;
import org.tiaa.business.process.wrapper.client.ActivitiAppRestClient;
import org.tiaa.business.process.wrapper.client.ActivitiWrapperRestClient;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.AppProcessMapping;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.AppProcessMappings;

@Component
public class BPMNDeployService {

	private static final Logger LOGGER = Logger
			.getLogger(BPMNDeployService.class);

	@Autowired
	ActivitiAppRestClient activitiAppRestClient;

	@Autowired
	ActivitiWrapperRestClient activitiWrapperRestClient;

	private static final String BPMN_ZIP_PATH = "dist/config/bpmn/diagrams/";

	public String deployBPMN(MultipartFile file, String basicAuth) {

		// Read Zip File and load into a Map
		Map<String, String> zipEntries = readZipFile(file);

		String deploymentDescriptor = zipEntries
				.get(Constants.DEPLOYMENT_DESCRIPTOR_NAME);

		if (deploymentDescriptor == null) {
			throw new BadRequestException(
					"There are no Deployment Descriptor in attached zip file..");
		}

		// Read Dep.Desc XML and populate models
		List<BPMNAppModel> bpmnModels = populateBPMNModels(zipEntries);

		// Make a REST call to get all Apps and Process Definitions
		List<AppProcessModel> appProcessModels = this.activitiAppRestClient
				.getAllAppsAndProcessModels(basicAuth);

		if (bpmnModels.isEmpty()) {
			return "No BPMN available for deployment!!";
		}

		// Run validation to check if Models and Apps are configured correctly
		validateAndPopulateBPMNModels(bpmnModels, zipEntries, basicAuth,
				appProcessModels);

		// Deploy process models either import or update version
		invokeDeployment(bpmnModels, basicAuth);

		// Map Process Models with App and Publish it
		this.activitiWrapperRestClient.updateApp(basicAuth,
				generateAppPublishRecord(bpmnModels));
		return "Deployment Successfull";
	}

	private AppProcessMappings generateAppPublishRecord(
			List<BPMNAppModel> bpmnModels) {

		Map<String, Set<String>> appProcessSet = new HashMap<String, Set<String>>();

		for (BPMNAppModel bpmnAppModel : bpmnModels) {
			String appId = bpmnAppModel.getAppId();

			if (!appProcessSet.containsKey(appId)) {
				appProcessSet.put(appId, new HashSet<String>());
			}

			appProcessSet.get(appId).add(
					Long.toString(bpmnAppModel.getBpmnNewProcessId()));
		}

		AppProcessMappings appProcessMappings = new AppProcessMappings();

		for (String appId : appProcessSet.keySet()) {
			AppProcessMapping appProcessMapping = new AppProcessMapping();
			appProcessMapping.setAppId(appId);
			for (String processId : appProcessSet.get(appId)) {
				appProcessMapping.getProcessId().add(processId);
			}
			appProcessMappings.getAppProcessMappings().add(appProcessMapping);
		}

		return appProcessMappings;
	}

	private void invokeDeployment(List<BPMNAppModel> bpmnModels,
			final String basicAuth) {
		for (BPMNAppModel bpmnModel : bpmnModels) {
			Long newProcessId = this.activitiAppRestClient.deployBPMNModel(
					bpmnModel, basicAuth);
			bpmnModel.setBpmnNewProcessId(newProcessId);
		}
	}

	private void validateAndPopulateBPMNModels(List<BPMNAppModel> bpmnModels,
			Map<String, String> zipEntries, final String basicAuth,
			List<AppProcessModel> appProcessModels) {

		List<String> bpmnKeys = new ArrayList<String>();

		for (BPMNAppModel bpmnModel : bpmnModels) {
			LOGGER.info("******* BPMN Model " + bpmnModel.getAppName()
					+ ":::::::::" + bpmnModel.getBpmnProcessIdentifier()
					+ ":::::::::::" + bpmnModel.getBpmnFileName());
			if (StringUtils.isBlank(bpmnModel.getAppName())
					|| StringUtils.isBlank(bpmnModel.getBpmnFileName())
					|| StringUtils
							.isBlank(bpmnModel.getBpmnProcessIdentifier())) {
				throw new BadRequestException(
						"Malformed Deployment Descriptor. For "
								+ bpmnModel.getAppName()
								+ " App Definition Either App Name,BPMN FileName or Process Id is missing");
			}

			// Check if process identifier are duplicated
			String bpmnProcessIdentifier = bpmnModel.getBpmnProcessIdentifier();
			if (bpmnKeys.contains(bpmnProcessIdentifier)) {
				throw new BadRequestException("Process Identifier "
						+ bpmnModel.getBpmnProcessIdentifier()
						+ " is duplicated within this model.");
			} else {
				bpmnKeys.add(bpmnProcessIdentifier);
			}

			// check if file name ends other than bpmn or bpmn20.xml
			if (!(bpmnModel.getBpmnFileName().endsWith(".bpmn") || bpmnModel
					.getBpmnFileName().endsWith(".bpmn20.xml"))) {
				throw new BadRequestException(
						"File Name should end with either .bpmn or .bpmn20.xml "
								+ ". Failing file Name :"
								+ bpmnModel.getBpmnFileName());
			}

			AppProcessModel appProcessModel = getAppModel(appProcessModels,
					bpmnModel.getAppName());

			if (appProcessModel == null) {
				throw new BadRequestException(
						"App Name "
								+ bpmnModel.getAppName()
								+ " is either not valid or not deployed for deployment user");
			}

			String bpmnZipPath = BPMN_ZIP_PATH + bpmnModel.getBpmnFileName();

			if (!zipEntries.containsKey(bpmnZipPath)) {
				throw new BadRequestException("File "
						+ bpmnModel.getBpmnFileName()
						+ " Not Found in Zip File in mentioned path"
						+ bpmnZipPath);
			}

			String appId = appProcessModel.getAppId();
			bpmnModel.setAppId(appId);
			bpmnModel.setBpmnFileContents(zipEntries.get(bpmnZipPath));

			Map<String, String> processModelsForThisApp = appProcessModel
					.getProcessModels();
			if ((processModelsForThisApp != null)
					&& processModelsForThisApp.keySet().contains(
							bpmnModel.getBpmnProcessIdentifier())) {
				bpmnModel.setBpmnProcessExists(true);
				bpmnModel.setBpmnProcessId(processModelsForThisApp
						.get(bpmnModel.getBpmnProcessIdentifier()));
			} else {
				bpmnModel.setBpmnProcessExists(false);
			}

		}
	}

	private AppProcessModel getAppModel(
			final List<AppProcessModel> appProcessModels, final String appName) {
		for (AppProcessModel appProcessModel : appProcessModels) {
			if (appProcessModel.getAppName().equalsIgnoreCase(appName)) {
				return appProcessModel;
			}
		}
		return null;
	}

	private List<BPMNAppModel> populateBPMNModels(Map<String, String> zipEntries) {

		String deploymentDescriptor = zipEntries
				.get(Constants.DEPLOYMENT_DESCRIPTOR_NAME);

		LOGGER.info("Trying to Read Deployment Desciptor and Populate Models!!!");
		List<BPMNAppModel> bpmnAppModels = new ArrayList<BPMNAppModel>();

		try {
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(new InputSource(new StringReader(
					deploymentDescriptor)));

			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("AppDefinition");

			for (int i = 0; i < nList.getLength(); i++) {
				Node node = nList.item(i);

				if (node.getNodeType() == Node.ELEMENT_NODE) {
					Element element = (Element) node;
					String appName = element.getAttribute("name");

					NodeList bpmnFilesList = element
							.getElementsByTagName("BPMNFiles");

					for (int j = 0; j < bpmnFilesList.getLength(); j++) {
						Node bpmnNode = bpmnFilesList.item(j);
						if (bpmnNode.getNodeType() == Node.ELEMENT_NODE) {
							Element bpmnElement = (Element) bpmnNode;
							NodeList bpmnFileList = bpmnElement
									.getElementsByTagName("BPMNFile");
							for (int k = 0; k < bpmnFileList.getLength(); k++) {
								Node bpmnFileNode = bpmnFileList.item(k);
								if (bpmnFileNode.getNodeType() == Node.ELEMENT_NODE) {
									Element bpmnFileElement = (Element) bpmnFileNode;
									BPMNAppModel bpmnAppModel = new BPMNAppModel();
									bpmnAppModel.setAppName(appName);
									bpmnAppModel
											.setBpmnProcessIdentifier(bpmnFileElement
													.getAttribute("name"));
									bpmnAppModel
											.setBpmnFileName(bpmnFileElement
													.getTextContent());
									bpmnAppModels.add(bpmnAppModel);
								}
							}
						}
					}

				}
			}
		} catch (Exception e) {
			LOGGER.error(
					"Error Parsing Deployment Descriptor." + e.getMessage(), e);
			throw new BadRequestException(
					"Error Parsing Deployment Descriptor", e);
		}
		return bpmnAppModels;
	}

	private Map<String, String> readZipFile(MultipartFile file) {

		LOGGER.info("Trying to read Zip File...");
		ZipInputStream zipInputStream = null;
		Map<String, String> map = new HashMap<String, String>();

		try {
			zipInputStream = new ZipInputStream(file.getInputStream());
			ZipEntry zipEntry = zipInputStream.getNextEntry();

			while (zipEntry != null) {

				String zipEntryName = zipEntry.getName();
				if (zipEntryName.endsWith(Constants.DEPLOYMENT_DESCRIPTOR_NAME)
						|| zipEntryName.endsWith("bpmn")
						|| zipEntryName.endsWith("bpmn20.xml")) {
					String content = IOUtils.toString(zipInputStream,
							Charset.defaultCharset());
					map.put(zipEntryName
							.endsWith(Constants.DEPLOYMENT_DESCRIPTOR_NAME) ? Constants.DEPLOYMENT_DESCRIPTOR_NAME
									: zipEntryName, content);
				}
				zipEntry = zipInputStream.getNextEntry();
			}
		} catch (Exception e) {
			LOGGER.error("Exception while reading zip file.", e);
			throw new BadRequestException("Attached Zip File is Corrupted.", e);
		} finally {
			try {
				if (zipInputStream != null) {
					zipInputStream.closeEntry();
				}
			} catch (IOException e) {
				// Do Nothing
				LOGGER.error("Error closing Zip Stream. ");
			}
			IOUtils.closeQuietly(zipInputStream);
		}
		LOGGER.info("Following files are read from zip file. " + map.keySet());

		return map;
	}

}
