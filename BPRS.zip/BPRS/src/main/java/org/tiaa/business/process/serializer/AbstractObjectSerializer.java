package org.tiaa.business.process.serializer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import org.springframework.stereotype.Component;

/**
 *
 * Abstract classes for Serializer implementations
 *
 * @author subashr
 *
 */
@Component
public abstract class AbstractObjectSerializer<T> implements
ObjectSerializer<T> {

	@Override
	public String serialize(T obj) {
		List<Map<String, String>> mapValues = convertObjectToMap(obj);
		return new GsonBuilder().create().toJson(mapValues);
	}

	@Override
	public T deSerialize(String data) {
		List<Map<String, String>> mapValues = new GsonBuilder().create()
				.fromJson(data, new TypeToken<List<Map<String, String>>>() {
				}.getType());
		return convertMapToObject(mapValues);
	}

	protected abstract List<Map<String, String>> convertObjectToMap(T obj);

	protected abstract T convertMapToObject(List<Map<String, String>> mapValues);

	protected List<Map<String, String>> encapsulateMapIntoList(
			final Map<String, String> map) {
		List<Map<String, String>> listOfMaps = new ArrayList<Map<String, String>>();

		if (map == null) {
			return listOfMaps;
		}

		listOfMaps.add(map);
		return listOfMaps;
	}
}
