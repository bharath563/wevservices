package org.tiaa.business.process.service.exception;

/**
 *
 * @author subashr
 *
 */
public class UnAuthorizedException extends BusinessProcessBaseException{

	private static final long serialVersionUID = 1L;

	public UnAuthorizedException(String message) {
		super(message);
	}

	public UnAuthorizedException(String message, Throwable cause) {
		super(message, cause);
	}
}
