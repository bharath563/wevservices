package org.tiaa.business.process.resource;

import static org.tiaa.business.process.util.Constants.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import org.tiaa.business.process.resource.util.ResourceUtil;
import org.tiaa.business.process.service.wrapper.ProcessService;
import org.tiaa.esb.case_management_common_types.types.Process;
import org.tiaa.esb.case_management_rs_v2_0.types.ProcessResponse;
import org.tiaa.esb.case_management_rs_v2_0.types.Signal;

@RestController
@ResponseStatus(HttpStatus.OK)
public class SignalResource {

	@Autowired
	ProcessService processService;

	@Autowired
	ResourceUtil resourceUtil;

	@RequestMapping(value = { "/signal" }, method = RequestMethod.POST, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public ProcessResponse signalResource(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@RequestBody Signal signalRequest) {
		Process process = this.processService.signalTask(signalRequest, userId,
				basicAuth);

		ProcessResponse processResponse = new ProcessResponse();
		processResponse.setProcess(process);
		processResponse.setResponseStatus(this.resourceUtil.getOkStatus());

		return processResponse;
	}

}
