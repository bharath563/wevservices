package org.tiaa.business.process.configuration;

import javax.naming.NamingException;
import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.hibernate.ejb.HibernatePersistence;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jndi.JndiTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaDialect;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.support.TransactionTemplate;

import org.tiaa.business.process.service.exception.BusinessProcessApplicationException;

/**
 * @author polara
 *
 */
@Configuration
@EnableJpaRepositories(value = "org.tiaa.business.process.repository.nxtgen", entityManagerFactoryRef = "nxtGenEntityManagerFactory", transactionManagerRef = "nxtGenTransactionManager")
@EnableTransactionManagement
@EnableScheduling
public class NxtGenDatabaseConfiguration {

	private static final Logger LOGGER = Logger
			.getLogger(NxtGenDatabaseConfiguration.class);

	@Value("${db.nxtgenapp.jndi.name}")
	public String nxtGenAppJndiName;

	@Bean
	public EntityManagerFactory nxtGenEntityManagerFactory() {
		LocalContainerEntityManagerFactoryBean entityManager = new LocalContainerEntityManagerFactoryBean();
		entityManager.setPersistenceProvider(new HibernatePersistence());
		entityManager.setPersistenceUnitName("nxtGenBprsPersistenceUnit");
		entityManager.setDataSource(nxtGenDataSource());
		entityManager.setJpaDialect(new HibernateJpaDialect());
		entityManager.setJpaVendorAdapter(jpaAdapter());

		/*
		 * Properties jpaProperties = new Properties();
		 * jpaProperties.put("hibernate.cache.use_second_level_cache", false);
		 * jpaProperties.put("hibernate.current_session_context_class",
		 * "thread"); entityManager.setJpaProperties(jpaProperties);
		 */

		entityManager.setPackagesToScan("org.tiaa.business.process.entities");
		entityManager.afterPropertiesSet();
		return entityManager.getObject();
	}

	@Bean
	public JpaVendorAdapter jpaAdapter() {
		HibernateJpaVendorAdapter jpaAdapter = new HibernateJpaVendorAdapter();
		jpaAdapter.setShowSql(false);
		jpaAdapter
		.setDatabasePlatform("org.hibernate.dialect.Oracle10gDialect");
		return jpaAdapter;
	}

	@Bean
	public JpaTransactionManager nxtGenTransactionManager() {
		JpaTransactionManager jpaTransactionManager = new JpaTransactionManager();
		jpaTransactionManager
		.setEntityManagerFactory(nxtGenEntityManagerFactory());
		jpaTransactionManager.afterPropertiesSet();
		return jpaTransactionManager;
	}

	@Bean
	public TransactionTemplate nxtGentransactionTemplate() {
		TransactionTemplate transTemplate = new TransactionTemplate(
				nxtGenTransactionManager());
		transTemplate
		.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
		transTemplate.afterPropertiesSet();
		return transTemplate;
	}

	@Bean(destroyMethod = "")
	public DataSource nxtGenDataSource() {
		LOGGER.info("DB JNDI Name :" + this.nxtGenAppJndiName);
		DataSource dataSource = null;
		JndiTemplate jndi = new JndiTemplate();
		try {
			dataSource = (DataSource) jndi.lookup("java:comp/env/"
					+ this.nxtGenAppJndiName);
		} catch (NamingException e) {
			LOGGER.error("Exception while lookup" + e.getMessage(), e);
			throw new BusinessProcessApplicationException("Exception while lookup" + e.getMessage(), e);
		}
		return dataSource;
	}

	/*
	 * @Bean public JdbcTemplate jdbcTemplate() { JdbcTemplate jdbcTemplate =
	 * new JdbcTemplate(this.nxtGenDataSource()); return jdbcTemplate; }
	 */
}
