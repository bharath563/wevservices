package org.tiaa.business.process.resource;

import static org.tiaa.business.process.util.Constants.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import org.tiaa.business.process.util.UserUtil;
import org.tiaa.business.process.wrapper.client.ActivitiWrapperRestClient;

/**
 * Search Resource class
 *
 * @author subashr
 *
 */
@RestController
@ResponseStatus(HttpStatus.OK)
public class PingResource {

	@Autowired
	ActivitiWrapperRestClient restClient;

	@Autowired
	UserUtil userUtil;

	@RequestMapping(value = { "/ping" }, method = RequestMethod.GET, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public String ping() {
		return this.restClient.ping(this.userUtil.generateWrapperBasicAuth());
	}

}
