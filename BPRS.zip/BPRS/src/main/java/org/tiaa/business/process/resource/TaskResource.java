package org.tiaa.business.process.resource;

import static org.tiaa.business.process.util.Constants.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import org.tiaa.business.process.resource.util.ResourceUtil;
import org.tiaa.business.process.service.wrapper.TaskService;
import org.tiaa.business.process.util.ValidatorUtil;
import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.esb.case_management_common_types.types.Properties;
import org.tiaa.esb.case_management_common_types.types.Task;
import org.tiaa.esb.case_management_rs_v2_0.types.CommentsResponse;
import org.tiaa.esb.case_management_rs_v2_0.types.TaskResponse;

/**
 * Task Resource
 *
 * @author subashr
 *
 */
@RestController
@ResponseStatus(HttpStatus.OK)
public class TaskResource {

	@Autowired
	TaskService taskService;

	@Autowired
	ValidatorUtil validatorUtil;

	@Autowired
	ResourceUtil resourceUtil;

	@RequestMapping(value = { "/process/{processId}/task/{taskId}" }, method = RequestMethod.GET, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public TaskResponse getTask(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@PathVariable("taskId") String taskId) {
		this.validatorUtil
				.validatePathParams(new String[] { processId, taskId });

		Task task = this.taskService.getTaskById(processId, taskId, userId,
				basicAuth);

		return createTaskResponse(task);
	}

	@RequestMapping(value = { "/process/{processId}/task/{taskId}" }, method = RequestMethod.PUT, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE }, consumes = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public TaskResponse updateTask(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@PathVariable("taskId") String taskId,
			@RequestBody Properties taskProperties) {

		this.validatorUtil
				.validatePathParams(new String[] { processId, taskId });
		this.validatorUtil.validate(taskProperties);
		Task task = this.taskService.updateTask(processId, taskId,
				taskProperties, userId, basicAuth);

		return createTaskResponse(task);
	}

	@RequestMapping(value = { "/process/{processId}/task/{taskId}/comments" }, method = RequestMethod.GET, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public CommentsResponse getTaskComments(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@PathVariable("taskId") String taskId) {
		this.validatorUtil
				.validatePathParams(new String[] { processId, taskId });
	
		/*
		Comments comments = this.taskService.getTaskComments(processId, taskId,
				userId, basicAuth);
		CommentsResponse commentsResp = new CommentsResponse();
		commentsResp.setComments(comments);*/
		CommentsResponse commentsResp = new CommentsResponse();

		return commentsResp;
	}

	@RequestMapping(value = { "/process/{processId}/task/{taskId}/comment" }, method = RequestMethod.POST, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE }, consumes = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	@ResponseStatus(HttpStatus.CREATED)
	public Comment addTaskComment(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@PathVariable("taskId") String taskId,
			@RequestBody Comment taskComment) {
		this.validatorUtil
				.validatePathParams(new String[] { processId, taskId });

		Comment comment = this.taskService.addTaskComment(processId, taskId,
				taskComment, userId, basicAuth);
		return comment;
	}

	@RequestMapping(value = { "/process/{processId}/task/{taskId}/claim" }, method = RequestMethod.PUT, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE }, consumes = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public TaskResponse claimTask(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@PathVariable("taskId") String taskId) {
		this.validatorUtil
				.validatePathParams(new String[] { processId, taskId });

		Task task = this.taskService.claimTask(processId, taskId, userId,
				basicAuth);
		return createTaskResponse(task);
	}

	@RequestMapping(value = { "/process/{processId}/task/{taskId}/unclaim" }, method = RequestMethod.PUT, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE }, consumes = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public TaskResponse unclaimTask(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@PathVariable("taskId") String taskId) {
		this.validatorUtil
				.validatePathParams(new String[] { processId, taskId });

		Task task = this.taskService.unclaimTask(processId, taskId, userId,
				basicAuth);
		return createTaskResponse(task);
	}

	@RequestMapping(value = { "/process/{processId}/task/{taskId}/complete" }, method = RequestMethod.PUT, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE }, consumes = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public TaskResponse completeTask(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@PathVariable("processId") String processId,
			@PathVariable("taskId") String taskId,
			@RequestBody Properties taskProperties) {
		this.validatorUtil
				.validatePathParams(new String[] { processId, taskId });

		// Validate properties only when available
		if (!taskProperties.getProperty().isEmpty()) {
			this.validatorUtil.validate(taskProperties);
		}

		Task task = this.taskService.completeTask(processId, taskId,
				taskProperties, userId, basicAuth);
		return createTaskResponse(task);
	}

	private TaskResponse createTaskResponse(final Task task) {
		TaskResponse taskResponse = new TaskResponse();
		taskResponse.setTask(task);
		taskResponse.setResponseStatus(this.resourceUtil.getOkStatus());
		return taskResponse;
	}

}
