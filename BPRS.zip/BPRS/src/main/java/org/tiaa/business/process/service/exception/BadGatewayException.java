package org.tiaa.business.process.service.exception;

/**
 *
 * @author subashr
 *
 */
public class BadGatewayException extends BusinessProcessBaseException {

	private static final long serialVersionUID = 1L;

	public BadGatewayException(String message) {
		super(message);
	}

	public BadGatewayException(String message, Throwable cause) {
		super(message, cause);
	}
}
