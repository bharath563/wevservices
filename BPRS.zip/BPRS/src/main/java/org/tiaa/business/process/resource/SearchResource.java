package org.tiaa.business.process.resource;

import static org.tiaa.business.process.util.Constants.*;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import org.tiaa.business.process.service.es.ESSearchService;
import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.service.wrapper.TaskService;
import org.tiaa.esb.case_management_common_types.types.Processes;
import org.tiaa.esb.case_management_common_types.types.SearchRequest;
import org.tiaa.esb.case_management_rs_v2_0.types.SearchResponse;

/**
 * Search Resource class
 *
 * @author subashr
 *
 */
@RestController
@ResponseStatus(HttpStatus.OK)
public class SearchResource {
	
	@Autowired
	TaskService taskService;

	@Autowired
	ESSearchService esSearchService;

	@RequestMapping(value = { "/query/tasks" }, method = RequestMethod.GET, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public SearchResponse queryForTasks(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@QueryParam("type") String type) {

		SearchResponse response = new SearchResponse();
		Processes processes = this.taskService.queryTasksByUser(userId, type,
				basicAuth);
		response.setProcesses(processes);
		return response;
	}

	@RequestMapping(value = { "/query/process" }, method = RequestMethod.POST, produces = {
			JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public SearchResponse processByVariable(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@RequestBody SearchRequest searchRequest) {

		if (!isSearchRequestValid(searchRequest)) {
			throw new BadRequestException(
					"Search Request is not valid. Atleast One NameValue with Name "
							+ "and either Value, BooleanValue, NumValue or DecimalValue should be present");
		}

		return this.esSearchService.queryESByVariable(searchRequest, basicAuth,userId);
	}

	private boolean isSearchRequestValid(SearchRequest searchRequest) {
		if (searchRequest == null) {
			return false;
		}
		return true;
	}
	
}
