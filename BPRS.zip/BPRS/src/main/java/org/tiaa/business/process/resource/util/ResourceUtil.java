package org.tiaa.business.process.resource.util;

import org.springframework.stereotype.Component;

import org.tiaa.esb.case_management_rs_v2_0.types.ESBResponseStatusType;

/**
 * Class having utility methods needed for Resources
 *
 * @author subashr
 *
 */
@Component
public class ResourceUtil {

	public ESBResponseStatusType getOkStatus() {
		return getStatus(200);
	}

	public ESBResponseStatusType getCreatedStatus() {
		return getStatus(201);
	}

	public ESBResponseStatusType getStatus(int statusCode) {
		ESBResponseStatusType status = new ESBResponseStatusType();
		status.setStatus(String.valueOf(statusCode));
		return status;
	}

}
