package org.tiaa.business.process.serializer;

/**
 * Interface for Object Serializers
 * 
 * @author subashr
 *
 * @param <T>
 */
public interface ObjectSerializer<T> {

	public String serialize(T obj);

	public T deSerialize(String str);
}
