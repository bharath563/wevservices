package org.tiaa.business.process.service.wrapper;

import org.springframework.stereotype.Service;

import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.esb.case_management_common_types.types.Processes;
import org.tiaa.esb.case_management_common_types.types.Properties;
import org.tiaa.esb.case_management_common_types.types.Task;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstances;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTask;

/**
 *
 * @author subashr
 *
 */
@Service
public class TaskService extends BaseServiceWrapper {

	
	public Task getTaskById(String processId, String taskId, String userId,
			final String basicAuth) {

		ProcessTask processTask = this.activitiWrapperRestClient.getTaskById(
				processId, taskId, userId, basicAuth);

		return createTaskFromProcessTask(processTask);
	}

	public Task updateTask(String processId, String taskId,
			Properties taskProperties, String userId, final String basicAuth) {

		ProcessTask processTask = this.activitiWrapperRestClient.updateTask(
				processId, taskId,
				createActivitiVariablesFromProperties(taskProperties), userId,
				basicAuth);

		return createTaskFromProcessTask(processTask);
	}

	public Comment addTaskComment(String processId, String taskId,
			Comment taskComment, String userId, final String basicAuth) {

		this.activitiWrapperRestClient.getTaskById(processId, taskId, userId,
				basicAuth);
		createComments(processId, taskId, userId, taskComment);
		
		return taskComment;
	}
	
	public Task claimTask(String processId, String taskId, String userId,
			final String basicAuth) {

		ProcessTask task = this.activitiWrapperRestClient.claimTask(processId,
				taskId, userId, basicAuth);

		return createTaskFromProcessTask(task);
	}

	public Task unclaimTask(String processId, String taskId, String userId,
			final String basicAuth) {

		ProcessTask task = this.activitiWrapperRestClient.unclaimTask(
				processId, taskId, userId, basicAuth);

		return createTaskFromProcessTask(task);
	}

	public Task completeTask(String processId, String taskId,
			Properties taskProperties, String userId, final String basicAuth) {

		ProcessTask task = this.activitiWrapperRestClient.completeTask(
				processId, taskId,
				createActivitiVariablesFromProperties(taskProperties), userId,
				basicAuth);

		return createTaskFromProcessTask(task);
	}
	
	public Processes queryTasksByUser(String userId, String type,
			final String basicAuth) {

		ProcessInstances processInstances = this.activitiWrapperRestClient
				.queryProcessTasksByUserId(userId, type, basicAuth);

		Processes processes = new Processes();

		for (ProcessInstance processInstance : processInstances
				.getProcessInstance()) {
			processes.getProcess().add(
					createProcessFromProcessInstance(processInstance, true));
		}

		return processes;
	}

}