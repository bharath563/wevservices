package org.tiaa.business.process.validator;

import org.apache.commons.lang3.StringUtils;

import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;

/**
 *
 * @author subashr
 *
 */
@Component
public class DocumentValidator implements ObjectValidator<Document> {

	@Override
	public void validate(Document obj) {

		if (obj == null) {
			throw new BadRequestException("Document object cannot be NULL");
		}

		if (StringUtils.isBlank(obj.getDocID())) {
			throw new BadRequestException("Document ID cannot be empty");
		}
		// Document following fields are mandatort: "required" : ["status",
		// "idType", "id", "formatType", "mimeType", "business_unit",
		// "doc_code", "version"]
		else if (StringUtils.isBlank(obj.getDocSts())) {
			throw new BadRequestException("Document Status cannot be empty");
		} else if (obj.getDocIDTyp() == null) {
			throw new BadRequestException("Document IDType cannot be empty");
		} else if (StringUtils.isBlank(obj.getFrmtTyp())) {
			throw new BadRequestException("Document formatType cannot be empty");
		} else if (StringUtils.isBlank(obj.getMimeTyp())) {
			throw new BadRequestException("Document mimeType cannot be empty");
		} else if (StringUtils.isBlank(obj.getDocBizUnit())) {
			throw new BadRequestException("Document BizUnit cannot be empty");
		} else if (obj.getDocVrsn() == null) {
			throw new BadRequestException("Document Version cannot be empty");
		}
	}
}
