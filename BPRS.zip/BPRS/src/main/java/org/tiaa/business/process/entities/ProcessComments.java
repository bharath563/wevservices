package org.tiaa.business.process.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import static org.tiaa.business.process.util.Constants.*;

/**
 * @author polara
 *
 */
@Entity
@Table(name = "PROCESS_COMMENTS")
public class ProcessComments {
	

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "comments_id_seq")
	@SequenceGenerator(name = "comments_id_seq", sequenceName = "PROCESS_COMMENTS_SEQ", allocationSize = 1)
	private Long id;

	@Column(name = "PROC_INST_ID")
	private String processInstanceId;

	@Column(name = "TASK_ID")
	private String taskId;

	@Column(name = "COMMENTS_TEXT")
	private String commentsText;

	@Column(name = "COMMENTS_CLOB")
	private String commentsClob;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	private Date createTime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_UPDATED_TIME")
	private Date lastUpdatedTime;

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getProcessInstanceId() {
		return processInstanceId;
	}

	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

	public String getTaskId() {
		return this.taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getCommentsText() {
		return this.commentsText;
	}

	public void setCommentsText(String commentsText) {
		this.commentsText = commentsText;
	}

	public String getCommentsClob() {
		return this.commentsClob;
	}

	public void setCommentsClob(String commentsClob) {
		this.commentsClob = commentsClob;
	}

	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getLastUpdatedTime() {
		return this.lastUpdatedTime;
	}

	public void setLastUpdatedTime(Date lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}

	public String getComments() {
		if (this.getCommentsText() != null) {
			return this.getCommentsText();
		} else {
			return this.getCommentsClob();
		}
	}

	public void setComments(String comments) {
		if (comments.length() > MAX_LENGTH) {
			this.setCommentsText(null);
			this.setCommentsClob(comments);
		} else {
			this.setCommentsText(comments);
			this.setCommentsClob(null);

		}
	}
}
