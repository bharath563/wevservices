package org.tiaa.business.process.service.comparator;

import java.io.Serializable;
import java.util.Comparator;

import org.springframework.stereotype.Component;

import org.tiaa.esb.case_management_common_types.types.Event;

@Component
public class EventComparator implements Comparator<Event>, Serializable {

	private static final long serialVersionUID = 1L;

	@Override
	public int compare(Event o1, Event o2) {
		if ((o2.getCreateDateTime() == null)
				&& (o1.getCreateDateTime() == null)) {
			return 0;
		} else if ((o2.getCreateDateTime() == null)
				&& (o1.getCreateDateTime() != null)) {
			return -1;
		} else if ((o2.getCreateDateTime() != null)
				&& (o1.getCreateDateTime() == null)) {
			return 1;
		} else {
			return o2.getCreateDateTime().compare(o1.getCreateDateTime());
		}
	}

}
