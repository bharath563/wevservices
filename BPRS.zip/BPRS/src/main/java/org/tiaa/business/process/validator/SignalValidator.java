package org.tiaa.business.process.validator;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.uuid.CorrelationUUIDGenerator;
import org.tiaa.esb.case_management_rs_v2_0.types.Signal;

/**
 *
 * @author subashr
 *
 */
@Component
public class SignalValidator implements ObjectValidator<Signal> {

	private static final Logger logger = Logger.getLogger(SignalValidator.class);

	@Autowired
	PropertiesValidator propertiesValidator;

	@Autowired
	CorrelationUUIDGenerator correlationUUIDGenerator;

	@Override
	public void validate(Signal obj) {

		if (obj == null) {
			throw new BadRequestException("Signal object cannot be NULL");
		}

		// TODO Something bad about this condition. failing with NPE. Need to check.
		/*
		 * if ((StringUtils.isBlank(obj.getCorrelationId())
		 * && StringUtils.isBlank(obj.getMessageName()) && ((obj
		 * .getMessageVariable() == null) || StringUtils.isBlank(obj
		 * .getMessageVariable().getMessageName())))
		 * || StringUtils.isBlank(obj.getMessageVariable()
		 * .getVariableName())
		 * || StringUtils.isBlank(obj.getMessageVariable()
		 * .getVariableValue())) {
		 * throw new BadRequestException(
		 * "One of Correlation Id or Message Name or Message Variable should be passed!!");
		 * }
		 */
		try {
			if (obj.getCorrelationId() != null) {
				this.correlationUUIDGenerator.decodeCorrelationID(obj.getCorrelationId());
			}
		}
		catch (Exception e) {
			logger.error("Error decoding CorrelationID ", e);
			throw new BadRequestException("Invalid Correlation Id.");
		}

		if (obj.getSignalProperties() != null) {
			this.propertiesValidator.validate(obj.getSignalProperties());
		}
	}
}
