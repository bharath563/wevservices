package org.tiaa.business.process.validator;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.esb.case_management_common_types.types.Process;
import org.tiaa.esb.case_management_rs_v2_0.types.ProcessRequest;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;

/**
 *
 * @author subashr
 *
 */
@Component
public class ProcessRequestValidator implements ObjectValidator<ProcessRequest> {

	@Autowired
	CommentValidator commentValidator;

	@Autowired
	DocumentValidator documentValidator;

	@Autowired
	PropertiesValidator propertiesValidator;

	@Override
	public void validate(ProcessRequest obj) {
		if ((obj == null) || (obj.getProcess() == null)) {
			throw new BadRequestException(
					"ProcessRequest/Processes object cannot be NULL");
		}

		Process process = obj.getProcess();

		if (StringUtils.isBlank(process.getProcessType())
				&& StringUtils.isBlank(process.getMessageName())) {
			throw new BadRequestException(
					"Expecting Process Type or Message Name for creating a Process");
		}

		if (process.getProcessProperties() != null) {
			this.propertiesValidator.validate(process.getProcessProperties());
		}

		if (process.getComments() != null) {
			for (Comment comment : process.getComments().getComment()) {
				this.commentValidator.validate(comment);
			}
		}

		if (process.getDocuments() != null) {
			for (Document document : process.getDocuments().getDocument()) {
				this.documentValidator.validate(document);
			}
		}
	}
}
