package org.tiaa.business.process.service.exception;

/**
 *
 * @author subashr
 *
 */
public class NotPermittedException extends BusinessProcessBaseException{

	private static final long serialVersionUID = 1L;

	public NotPermittedException(String message) {
		super(message);
	}

	public NotPermittedException(String message, Throwable cause) {
		super(message, cause);
	}
}
