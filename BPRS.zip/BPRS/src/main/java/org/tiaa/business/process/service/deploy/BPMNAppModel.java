package org.tiaa.business.process.service.deploy;

public class BPMNAppModel {

	private String appName;
	private String appId;

	private String bpmnFileName;
	private String bpmnProcessIdentifier;
	private String bpmnProcessId;
	private boolean bpmnProcessExists = false;
	private String bpmnFileContents;

	private long bpmnNewProcessId;

	public String getAppName() {
		return this.appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getBpmnFileName() {
		return this.bpmnFileName;
	}

	public void setBpmnFileName(String bpmnFileName) {
		this.bpmnFileName = bpmnFileName;
	}

	public String getBpmnProcessIdentifier() {
		return this.bpmnProcessIdentifier;
	}

	public void setBpmnProcessIdentifier(String bpmnProcessIdentifier) {
		this.bpmnProcessIdentifier = bpmnProcessIdentifier;
	}

	public String getBpmnFileContents() {
		return this.bpmnFileContents;
	}

	public void setBpmnFileContents(String bpmnFileContents) {
		this.bpmnFileContents = bpmnFileContents;
	}

	public String getAppId() {
		return this.appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getBpmnProcessId() {
		return this.bpmnProcessId;
	}

	public void setBpmnProcessId(String bpmnProcessId) {
		this.bpmnProcessId = bpmnProcessId;
	}

	public boolean isBpmnProcessExists() {
		return this.bpmnProcessExists;
	}

	public void setBpmnProcessExists(boolean bpmnProcessExists) {
		this.bpmnProcessExists = bpmnProcessExists;
	}

	public long getBpmnNewProcessId() {
		return this.bpmnNewProcessId;
	}

	public void setBpmnNewProcessId(long bpmnNewProcessId) {
		this.bpmnNewProcessId = bpmnNewProcessId;
	}
}
