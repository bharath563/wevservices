package org.tiaa.business.process.service.async;

import static org.tiaa.business.process.util.Constants.*;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.integration.transformer.Transformer;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.service.wrapper.ProcessService;
import org.tiaa.business.process.util.Constants;
import org.tiaa.business.process.util.UserUtil;
import org.tiaa.business.process.util.ValidatorUtil;
import org.tiaa.esb.case_management_common_types.types.Process;
import org.tiaa.esb.case_management_common_types.types.Properties;
import org.tiaa.esb.case_management_rs_v2_0.types.Signal;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.NameValue;

@Component
public class EmailMessageProcessor implements AsyncMessageProcessor {

	private static final Logger LOGGER = Logger
			.getLogger(EmailMessageProcessor.class);

	@Autowired
	Transformer transformer;

	@Autowired
	@Lazy
	ProcessService processService;

	@Value("${queue.activiti.userName}")
	private String queueuActivitiUserName;

	@Autowired
	@Lazy
	UserUtil userUtil;

	@Autowired
	@Lazy
	ValidatorUtil validatorUtil;

	private static final String MESSAGE_NAME = "messageName";

	private static final String REFERENCE = "reference";

	private static final String DELIMITER_COLON = ":";

	@Override
	public boolean isEventTypeProcessable(String eventType) {
		return EMAIL_EVENT.equalsIgnoreCase(eventType);
	}

	@Override
	public void processMessage(String data) {

		LOGGER.info("Email Data to be processed - " + data);
		// Retrieve subject and content from the data.
		Map<String, String> mapValues = new GsonBuilder().create().fromJson(
				data, new TypeToken<Map<String, String>>() {
				}.getType());

		String subject = mapValues.get(Constants.EMAIL_SUBJECT);
		String messageContent = mapValues.get(Constants.EMAIL_CONTENT);

		LOGGER.info("Subject From EmailMessage - " + subject);
		LOGGER.debug("Content from EmailMessage - " + messageContent);

		// 1. If subject contains a messageName, it is assumed to be a
		// startProcess request.
		if (subject.contains(MESSAGE_NAME)) {
			startProcessByMessage(subject, messageContent);
		}
		// 2. If subject contains a reference, it is assumed to be a correlation
		// request.
		else if (subject.contains(REFERENCE)) {
			signalTask(subject, messageContent);
		} else {
			LOGGER.error("Invalid Email received for processing with subject - "
					+ subject);
			throw new BadRequestException("Invalid Email Message received -"
					+ subject);
		}
	}

	/**
	 * This method starts the Business process by message
	 *
	 * @param subject
	 * @param content
	 */
	private void startProcessByMessage(String subject, String content) {

		LOGGER.debug("startProcessByMessage START with subject - " + subject);

		try {
			// Assuming subject will be like "messageName:emailListener"
			// delimit and get the messageName
			String[] msgSubj = subject.split(DELIMITER_COLON);
			LOGGER.info("MessageName from the Email - " + msgSubj[1]);

			// check if messageName is valid
			if (StringUtils.isBlank(msgSubj[1]) || (msgSubj.length == 0)) {
				LOGGER.error("Invalid StartProcess Request, messageName is null  "
						+ subject);
				throw new BadRequestException(
						"Invalid StartProcess Request, messageName is null  "
								+ subject);
			}

			Process process = new Process();
			process.setMessageName(msgSubj[1]);

			Properties properties = createProperties(content);
			if (properties != null) {
				LOGGER.info("Created ProcessProperties "
						+ properties.getProperty().size());
				process.setProcessProperties(properties);
			}

			this.processService.startProcess(process,
					this.queueuActivitiUserName,
					this.userUtil.generateWrapperBasicAuth());

			LOGGER.debug("startProcessByMessage END");
		} catch (Exception e) {
			LOGGER.error("Error consuming request message:" + e.getMessage(), e);
		}
	}

	/**
	 * This method will start the signalTask
	 *
	 * @param subject
	 * @param content
	 */
	private void signalTask(String subject, String content) {

		LOGGER.debug("signalTask START with subject - " + subject);

		// Assuming subject will be like "messageName:emailListener"
		// delimit and get the messageName
		String[] msgSubj = subject.split(DELIMITER_COLON);
		LOGGER.info("Co-relationId from the Email - " + msgSubj[1]);

		// Check if CorrelationId is valid
		if (StringUtils.isBlank(msgSubj[1]) || (msgSubj.length == 0)) {
			LOGGER.error("Invalid Signal Request, has no CorrelationId  "
					+ subject);
			throw new BadRequestException(
					"Invalid Signal Request, has no CorrelationId  " + subject);
		}

		Signal signalRequest = new Signal();
		signalRequest.setCorrelationId(msgSubj[1]);

		Properties properties = createProperties(content);
		if (properties != null) {
			LOGGER.info("Created SignalProperties "
					+ properties.getProperty().size());
			signalRequest.setSignalProperties(properties);
		}

		this.validatorUtil.validate(signalRequest);
		this.processService.signalTask(signalRequest,
				this.queueuActivitiUserName,
				this.userUtil.generateWrapperBasicAuth());

		LOGGER.debug("signalTask END");

	}

	/**
	 * This method creates the properties
	 *
	 * @param content
	 * @return
	 */
	private Properties createProperties(String content) {

		Properties properties = null;
		if (StringUtils.isNotBlank(content)) {

			properties = new Properties();
			String variableName = Constants.ACTIVITI_EMAIL_MSG_VARIABLE;

			LOGGER.debug("Variable Name - " + variableName);
			LOGGER.debug("Variable Value - " + content);
			// Set variables into the process
			NameValue value = new NameValue();
			value.setName(variableName);
			value.setValue(content);
			properties.getProperty().add(value);

		} else {
			LOGGER.info("No Properties found to be created ");
		}

		return properties;
	}

	@Override
	public String getMessageMetaData(String data) {
		return data;
	}
}
