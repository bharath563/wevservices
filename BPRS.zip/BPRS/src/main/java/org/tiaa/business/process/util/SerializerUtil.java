package org.tiaa.business.process.util;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.serializer.ObjectSerializer;
import org.tiaa.business.process.service.exception.BusinessProcessApplicationException;

/**
 *
 * @author subashr
 *
 */
@Component
@SuppressWarnings({ "unchecked", "rawtypes" })
public class SerializerUtil {

	private static final String TYPE_NAME_PREFIX = "class ";

	@Autowired
	private List<ObjectSerializer> objectSerializers;

	public String serialize(final Object obj) {

		if (obj == null) {
			return null;
		}

		ObjectSerializer serializer = getSerializer(obj.getClass()
				.getCanonicalName());
		return serializer.serialize(obj);
	}

	public <T extends Object> T deSerialize(final String data,
			final Class<T> clazz) {

		if ((data == null) || (clazz == null)) {
			return null;
		}

		ObjectSerializer serializer = getSerializer(clazz.getCanonicalName());
		return (T) serializer.deSerialize(data);
	}

	private ObjectSerializer getSerializer(final String className) {

		for (ObjectSerializer c : this.objectSerializers) {
			Type type = c.getClass().getGenericSuperclass();
			if (type instanceof ParameterizedType) {
				ParameterizedType parameterizedType = (ParameterizedType) type;
				Type[] typeArguments = parameterizedType
						.getActualTypeArguments();
				// TODO: to revisit again with jdk1.7.
				// typeArguments[0].getType() doesnt work
				// with jdk8
				String strClassname = typeArguments[0].toString();
				if (strClassname.startsWith(TYPE_NAME_PREFIX)) {
					strClassname = strClassname.substring(TYPE_NAME_PREFIX
							.length());
				}
				if (className.equalsIgnoreCase(strClassname)) {
					return c;
				}
			}
		}
		throw new BusinessProcessApplicationException("No Serializer found for class:" + className);
	}
}