package org.tiaa.business.process.configuration;

import org.elasticsearch.client.transport.TransportClient;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.queue.listener.QueueManager;

@Component
public class ContextShutdownListener implements
ApplicationListener<ContextClosedEvent> {

	private static final Logger LOGGER = Logger.getLogger(ContextShutdownListener.class);

	@Autowired
	QueueManager queueManager;

	@Value("${bpm.req.inbound.queue}")
	private String requestQueueName;

	@Value("${bpm.resp.inbound.queue}")
	private String correlationQueueName;
	
	@Value("${bpm.cth.req.inbound.queue}")
	private String requestCTHQueueName;

	@Override
	public void onApplicationEvent(ContextClosedEvent event) {
		LOGGER.info("Starting Shutdown of ElasticSearch Transport Client");
		ApplicationContext context = event.getApplicationContext();

		context.getBean(TransportClient.class).close();

		LOGGER.info("Starting Shutdown of Request , Correlation and CTHEvent Queue Listeners");
		this.queueManager.manageQueue(this.requestQueueName, false);
		this.queueManager.manageQueue(this.correlationQueueName, false);
		this.queueManager.manageQueue(this.requestCTHQueueName, false);
	}

}
