package org.tiaa.business.process.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import org.tiaa.business.process.entities.AsyncMessage;

@Repository
public interface AsyncMessageRepository extends
JpaRepository<AsyncMessage, Long> {

	@Query("from AsyncMessage event where event.processed = 'N' and event.lockOwner is null and event.lockTime is null and event.retryCount < 3 and (event.lastUpdateDate is null or event.lastUpdateDate < :errorTimeLimit) order by event.messageId asc")
	public List<AsyncMessage> findLockableEventsOrderByMessageId(
			@Param("errorTimeLimit") Date errorTimeLimit, Pageable paramPageable);

	@Modifying
	@Query("update AsyncMessage event set event.lockOwner=:lockOwner, event.lockTime=:lockTime where event.messageId >= :messageIdLowerBound and event.messageId < :messageIdUpperBound and event.processed='N' and event.retryCount < 3 and event.lockOwner is null and event.lockTime is null and (event.lastUpdateDate is null or event.lastUpdateDate < :errorTimeLimit)")
	public int lockBlockOfEvents(@Param("lockOwner") String lockOwner,
			@Param("lockTime") Date lockTime,
			@Param("messageIdLowerBound") Long messageIdLowerBound,
			@Param("messageIdUpperBound") Long messageIdUpperBound,
			@Param("errorTimeLimit") Date errorTimeLimit);

	@Query("from AsyncMessage event where event.lockOwner = :lockOwner and event.messageId >= :messageIdLowerBound and event.messageId < :messageIdUpperBound and event.processed = 'N' order by event.messageId asc")
	public List<AsyncMessage> findLockedEvents(
			@Param("lockOwner") String paramString,
			@Param("messageIdLowerBound") Long messageIdLowerBound,
			@Param("messageIdUpperBound") Long messageIdUpperBound);

	@Modifying
	@Query("update AsyncMessage event set event.lockOwner = :lockOwner, event.lockTime = :lockTime where event.processed = 'N' and event.lockTime is not null and event.lockTime < :lockTimeLimit and event.retryCount < 3 ")
	public abstract int lockExpiredEvents(@Param("lockOwner") String lockOwner,
			@Param("lockTime") Date lockTime,
			@Param("lockTimeLimit") Date lockTimeLimit);

	@Query("from AsyncMessage event where event.lockOwner = :lockOwner and event.processed = 'N' and event.lockTime is not null")
	public abstract List<AsyncMessage> findExpiredLockedEvents(
			@Param("lockOwner") String paramString);

	@Modifying
	@Query("update AsyncMessage event set event.lockOwner = null, event.lockTime=null, event.processed= 'Y',event.lastUpdateDate=:lastUpdateDate where event.messageId = :messageId")
	public abstract int markEventAsProcessed(
			@Param("messageId") Long messageId,
			@Param("lastUpdateDate") Date lastUpdateDate);

	@Modifying
	@Query("update AsyncMessage event set event.lockOwner = null, event.lockTime=null, event.processed= 'N' , event.retryCount = event.retryCount+1,event.exceptionMetaData= :errorMetaData,event.exceptionMessage= :errorMessage,event.lastUpdateDate=:lastUpdateDate  where event.messageId = :messageId")
	public abstract int markEventAsFailed(@Param("messageId") Long messageId,
			@Param("errorMessage") String errorMessage,
			@Param("errorMetaData") String errorMetaData,
			@Param("lastUpdateDate") Date lastUpdateDate);
}
