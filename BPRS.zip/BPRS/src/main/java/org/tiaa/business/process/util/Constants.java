package org.tiaa.business.process.util;

import java.util.Arrays;
import java.util.List;

/**
 *
 * @author subashr
 *
 */
public final class Constants {

	public static final String JSON_CONTENT_TYPE = "application/json";
	public static final String XML_CONTENT_TYPE = "application/xml";

	public static final String TIAA_LOGGED_IN_USER_HEADER = "tiaa_user";
	public static final String BASIC_AUTH_HEADER = "Authorization";

	public static final String APPLICATION_NAME = "ACTIVITI";
	public static final String USER_TASK_TYPE = "User";

	public static final String DOCUMENT_VARIABLE_NAME = "activiti_Internal_Document";
	public static final String LOCK_VARIABLE_NAME = "activiti_Internal_LockVariable";
	public static final List<String> VARIABLE_EXLCUSION_LIST = Arrays.asList(new String[] {
			DOCUMENT_VARIABLE_NAME.toLowerCase(), LOCK_VARIABLE_NAME.toLowerCase() });

	public static final String REQUEST_QUEUE_EVENT = "REQUEST_QUEUE_EVENT";
	public static final String CORRELATION_QUEUE_EVENT = "CORRELATION_QUEUE_EVENT";
	public static final String EMAIL_EVENT = "EMAIL_EVENT";
	public static final String CTH_REQUEST_QUEUE_EVENT = "CTH_REQUEST_QUEUE_EVENT";
	public static final String MULTIPART_FORM_DATA = "multipart/form-data";
	public static final String DEPLOYMENT_DESCRIPTOR_NAME = "BPMNDeploymentDescriptor.xml";

	public static final String MAIL_CONTENT_TYPE = "mail_contentType";

	public static final String MAIL_SUBJECT = "mail_subject";

	public static final String KEY_IMAP_SOCKETFACTORY_CLASS = "mail.imap.socketFactory.class";

	public static final String KEY_IMAP_SOCKETFACTORY_FALLBACK = "mail.imap.socketFactory.fallback";

	public static final String KEY_IMAP_PROTOCOL = "mail.store.protocol";

	public static final String KEY_IMAP_DEBUG = "mail.debug";

	public static final String KEY_IMAP_SMTP_AUTH = "mail.smtp.auth";

	public static final String KEY_IMAP_SMTP_PORT = "mail.smtp.port";

	public static final String FOLDER_INBOX = "inbox";

	public static final String COLON = ":";

	public static final String DOUBLESLASH = "//";

	public static final String KEY_AT = "@";

	public static final String SLASH = "/";

	public static final String ACTIVITI_EMAIL_MSG_VARIABLE = "EmailMsgVariable";

	public static final String SOCKET_FACTORY = "javax.net.ssl.SSLSocketFactory";

	public static final boolean SOCKET_FACTORY_FALLBACK = false;

	public static final String EMAIL_PROTOCOL_IMAP = "imaps";

	public static final String EMAIL_SUBJECT = "EmailSubject";

	public static final String EMAIL_CONTENT = "EmailContent";

	public static final String CTH_CREATE_REQUEST = "CREATE_REQUEST";

	public static final String CTH_UPDATE_REQUEST = "UPDATE_REQUEST";

	public static final String ACT_FW_CTHEVENT_CORR_ID = "ACT_FW_CTHEVENT_CORR_ID";

	public static final String ACT_FW_CTHEVENT_PAYLOAD = "ACT_FW_CTHEVENT_PAYLOAD";

	/*
	 * public static final String BIZ_UNIT = "PENSION";
	 * public static final String DOC_CODE = "INST_DOCS";
	 * public static final String VERSION = "2";
	 * public static final int DOC_VERSION = 2;
	 */
	public static final String TIAA_GUID = "tiaa-guid";

	public static final String TIAA_CORRELATION_ID = "tiaa-correlation-id";

	public static final String TIAA_PARTNER_ID = "tiaa-partner-id";

	public static final String TIAA_CONSUMER = "tiaa-consumer";

	public static final String TIAA_USER_REF = "tiaa-user-ref";

	public static final String TIAA_SENDER_MACHINE = "tiaa-sender-machine";

	public static final String TIAA_TIMESTAMP = "tiaa-timestamp";

	public static final String TIAA_DIGEST = "tiaa-digest";

	public static final String TASK_HUMAN = "Human";

	public static final String TASK_SYSTEM = "System";
	
	public static final String CONFIG_BUSINESSAREA = "Department";
	
	public static final String CONFIG_IDENTIFIER = "Identifiers";
	
	public static final String ITEM_BA_DESCRIPTION = "WorkflowBusinessAreas";
	
	public static final String ITEM_IDENFITIFER_DESCRIPTION = "WorkflowSearchIdentifier";
	
	public static final int MAX_LENGTH = 3995;
	
	public static final String DEPARTMENT_TNG = "TNG Eased";
	
	public static final String VARIABLE_OFFERSTATE = "offerState";
	
	public static final String STATUS_OPEN = "Open";
	
	public static final String STATUS_COMPLETED = "Completed";
	
	private Constants() {
		// Intentionally left blank
	}
}
