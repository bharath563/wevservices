package org.tiaa.business.process.bean;

import java.io.Serializable;

/**
 * @author pamdama
 *
 */
public class SearchIdentifier implements Serializable {

	private static final long serialVersionUID = -8943172377224918506L;
	
	private String shortDescription;
	
	private String longDescription;
	
	private String fieldNumber;
	
	private String fieldName;
	
	private String fieldSize;
	
	private String fieldType;
	
	private String fieldEntryType;
	
	private String fieldRequired;
	

	/**
	 * @return the shortDescription
	 */
	public String getShortDescription() {
		return shortDescription;
	}

	/**
	 * @param shortDescription the shortDescription to set
	 */
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	/**
	 * @return the longDescription
	 */
	public String getLongDescription() {
		return longDescription;
	}

	/**
	 * @param longDescription the longDescription to set
	 */
	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	/**
	 * @return the fieldNumber
	 */
	public String getFieldNumber() {
		return fieldNumber;
	}

	/**
	 * @param fieldNumber the fieldNumber to set
	 */
	public void setFieldNumber(String fieldNumber) {
		this.fieldNumber = fieldNumber;
	}

	/**
	 * @return the fieldName
	 */
	public String getFieldName() {
		return fieldName;
	}

	/**
	 * @param fieldName the fieldName to set
	 */
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	/**
	 * @return the fieldSize
	 */
	public String getFieldSize() {
		return fieldSize;
	}

	/**
	 * @param fieldSize the fieldSize to set
	 */
	public void setFieldSize(String fieldSize) {
		this.fieldSize = fieldSize;
	}

	/**
	 * @return the fieldType
	 */
	public String getFieldType() {
		return fieldType;
	}

	/**
	 * @param fieldType the fieldType to set
	 */
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	/**
	 * @return the fieldEntryType
	 */
	public String getFieldEntryType() {
		return fieldEntryType;
	}

	/**
	 * @param fieldEntryType the fieldEntryType to set
	 */
	public void setFieldEntryType(String fieldEntryType) {
		this.fieldEntryType = fieldEntryType;
	}

	/**
	 * @return the fieldRequired
	 */
	public String getFieldRequired() {
		return fieldRequired;
	}

	/**
	 * @param fieldRequired the fieldRequired to set
	 */
	public void setFieldRequired(String fieldRequired) {
		this.fieldRequired = fieldRequired;
	}
	

	
}
