package org.tiaa.business.process.email;

import java.util.HashMap;
import java.util.Map;

import org.jsoup.Jsoup;

import org.apache.log4j.Logger;

import com.google.gson.GsonBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.transformer.Transformer;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.service.wrapper.AsyncService;
import org.tiaa.business.process.util.Constants;

@MessageEndpoint
public class EmailListener {

	private static final Logger LOGGER = Logger.getLogger(EmailListener.class);

	@Autowired
	AsyncService asyncService;
	
	@Autowired
	Transformer transformer;
	
	@ServiceActivator(inputChannel="emailChannel")
	public void handleMessage(Message<?> message) throws Exception {

		LOGGER.debug("handleMessage() START ");
		LOGGER.info("Received Message in " + Constants.EMAIL_EVENT + " with Message "	+ message);
		
		message = this.transformer.transform(message);
		MessageHeaders headers = message.getHeaders();
		LOGGER.info("Message Headers - "+headers);

		String messageContent = (String) message.getPayload();

		messageContent = Jsoup.parse(messageContent).text();
		LOGGER.info("Email Content - "+messageContent);

		String subject = (String) headers.get(Constants.MAIL_SUBJECT);
		if(subject == null){
			LOGGER.error("Invalid Email Message received with no subject  " + message);
			throw new BadRequestException("Invalid Email Message received with no subject "+ message);
		}
		
		Map messageValues = new HashMap();
		messageValues.put(Constants.EMAIL_SUBJECT, subject);
		messageValues.put(Constants.EMAIL_CONTENT, messageContent);
		
		String data = new GsonBuilder().create().toJson(messageValues);
		
		this.asyncService.addAsyncMessage(Constants.EMAIL_EVENT,data);
		
		LOGGER.debug("handleMessage() END ");
	}

	
}
