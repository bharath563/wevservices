package org.tiaa.business.process.converters;

import static org.tiaa.business.process.util.Constants.*;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.esb.case_management_common_types.types.Process;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Status;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Statuses;

/**
 * Converter class to convert Wrapper Process Instance to Object Model Process
 *
 * @author subashr
 *
 */
@Component
public class ProcessInstanceToProcessConverter implements
		Converter<ProcessInstance, Process> {

	@Override
	public Process convert(ProcessInstance source) {

		if (source == null) {
			return null;
		}

		Process process = new Process();
		process.setAppName(APPLICATION_NAME);
		process.setProcessId(source.getProcessInstanceId());
		process.setBusinessKey(source.getBusinessKey());
		process.setStatusHistory(getProcessStatus(source.getStatus()));

		// Not Populated Values
		process.setAction(null);
		process.setLockedBy(null);
		process.setLockInd(null);
		process.setProcessEngine(null);
		process.setProcessType(null);
		process.setRelatedTasks(null);
		process.setSLADetail(null);

		return process;
	}

	private Statuses getProcessStatus(final String strStatus) {
		Statuses statuses = new Statuses();
		Status status = new Status();
		statuses.getSts().add(status);
		status.setSts(strStatus);
		return statuses;
	}

}
