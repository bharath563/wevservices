package org.tiaa.business.process.converters;

import java.util.Collections;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.comparator.EventComparator;
import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.esb.case_management_common_types.types.Event;
import org.tiaa.esb.case_management_common_types.types.EventType;
import org.tiaa.esb.case_management_common_types.types.History;
import org.tiaa.esb.case_management_common_types.types.Process;
import org.tiaa.esb.case_management_common_types.types.Task;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;

/**
 * Converter class to convert Wrapper Process Instance to Object Model Process
 *
 * @author subashr
 *
 */
@Component
public class ProcessToHistoryConverter implements Converter<Process, History> {

	@Autowired
	EventComparator eventComparator;

	@Override
	public History convert(Process source) {

		if (source == null) {
			return null;
		}

		History history = new History();
		populateCommentEvents(history, source);
		populateDocumentEvents(history, source);
		populateTaskEvents(history, source);

		Collections.sort(history.getEvent(), this.eventComparator);

		return history;
	}

	private void populateDocumentEvents(History history, Process source) {
		if (source.getDocuments() == null) {
			return;
		}

		for (Document document : source.getDocuments().getDocument()) {
			Event event = new Event();
			event.setEventType(EventType.DOCUMENT);
			event.setProcessId(source.getProcessId());
			event.setTitle(document.getDocTitle());
			event.setCreateDateTime(document.getDocCreateDateTime());
			if (document.getDocOriginator() != null) {
				event.setCreatedBy(document.getDocOriginator().getDocOrigName());
			}

			event.setDescription(document.getDocDesc());
			history.getEvent().add(event);
		}
	}

	private void populateCommentEvents(History history, Process source) {
		if (source.getComments() == null) {
			return;
		}

		for (Comment comment : source.getComments().getComment()) {
			Event event = new Event();
			event.setEventType(EventType.COMMENT);
			event.setProcessId(source.getProcessId());
			event.setTitle(comment.getMessage());
			event.setCreateDateTime(comment.getCreateDate());
			event.setCreatedBy(comment.getCreateOper());
			event.setDescription(comment.getDesc());

			history.getEvent().add(event);
		}
	}

	private void populateTaskEvents(History history, Process source) {
		if (source.getTasks() == null) {
			return;
		}

		for (Task task : source.getTasks().getTask()) {
			Event event = new Event();
			event.setEventType(EventType.TASK);
			event.setProcessId(source.getProcessId());
			event.setTitle(task.getName());
			event.setCreateDateTime(task.getCreateDate());
			event.setCreatedBy(task.getAssignedTo());
			event.setDescription(task.getDescription());

			history.getEvent().add(event);
		}
	}
}
