package org.tiaa.business.process.service.es;

import static org.tiaa.business.process.util.Constants.*;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.elasticsearch.action.get.GetResponse;
import org.elasticsearch.action.search.SearchRequestBuilder;
import org.elasticsearch.action.search.SearchType;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.aggregations.AggregationBuilders;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.elasticsearch.search.aggregations.metrics.tophits.TopHits;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.config.ConfigRepositoryService;
import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.service.exception.BusinessProcessApplicationException;
import org.tiaa.business.process.wrapper.client.ActivitiWrapperRestClient;
import org.tiaa.esb.case_management_common_types.types.DateType;
import org.tiaa.esb.case_management_common_types.types.Process;
import org.tiaa.esb.case_management_common_types.types.Processes;
import org.tiaa.esb.case_management_common_types.types.Properties;
import org.tiaa.esb.case_management_common_types.types.SearchRequest;
import org.tiaa.esb.case_management_rs_v2_0.types.SearchResponse;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.NameValue;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Status;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Statuses;

@Component
public class ESSearchService {

	private static final Logger LOGGER = Logger
			.getLogger(ESSearchService.class);

	@Value("${es.index.name}")
	public String indexName;

	@Autowired
	TransportClient transportClient;

	@Autowired
	public ActivitiWrapperRestClient activitiWrapperRestClient;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Autowired
	ConfigRepositoryService configRepositoryService;
	
	@Autowired
	SearchIdentifierMapper searchIdentifierMapper;

	private static final String GET_PROCDEFINITION_SQL = "SELECT proc.PROCESS_NAME as processName FROM NXTGENAPP.CMF_PM_PROCESS proc INNER JOIN NXTGENAPP.CMF_PM_BUSINESSAREA_PROCESS_X baproc"
			+ " on proc.PROCESS_CODE = baproc.PROCESS_CODE INNER JOIN NXTGENAPP.CMF_PM_BUSINESSAREA ba on ba.BA_CODE = baproc.BA_CODE where ba.BA_NAME =:baName and ba.ACTIVE='Y' order by proc.PROCESS_NAME";

	public static final String TASK_TYPE = "TaskType";
	public static final String TASK_STATUS = "TaskStatus";
	public static final String DEPARTMENT = "department";
	public static final String ASSIGNED_TO = "assignedTo";	

	public static final String VARIABLE_TYPE = "variables";
	public static final String PROCESS_INSTANCE_ID = "processInstanceId";

	public List<String> getProcessMatchingVariable(final String variableName,
			final String variableValue, final String basicAuth,
			final String userId) {

		// Make an ES search for the variable
		SearchRequest searchReq = new SearchRequest();
		Properties props = new Properties();

		NameValue nmVal = new NameValue();
		nmVal.setName(variableName);
		nmVal.setValue(variableValue);
		props.getProperty().add(nmVal);

		searchReq.setProperties(props);
		SearchResponse srchResp = queryESByVariable(searchReq, basicAuth,
				userId);

		if ((srchResp == null)
				|| (srchResp.getProcesses().getProcess() == null)
				|| (srchResp.getProcesses().getProcess().size() == 0)) {
			LOGGER.error("Elastic Search Response is null or no processes found with the variable search criteria. Variable Name - "
					+ variableName + " Variable Value " + variableValue);
			throw new BadRequestException(
					"Elastic Search Response is null or no processes found with the variable search criteria. Variable Name - "
							+ variableName + " Variable Value " + variableValue);
		}

		List<org.tiaa.esb.case_management_common_types.types.Process> processes = srchResp
				.getProcesses().getProcess();
		List<String> processInstanceIds = new ArrayList<String>();

		for (org.tiaa.esb.case_management_common_types.types.Process proc : processes) {
			processInstanceIds.add(proc.getProcessId());
		}

		return processInstanceIds;
	}

	public SearchResponse queryESByVariable(SearchRequest sr,
			final String basicAuth, final String userId) {

		// Validate if the user has access to this system. This is done by
		// calling Wrapper Ping service. Since ping doesn't do any process level
		// checks this will be a faster alternative rather than implementing any
		// authentication checks.
		this.activitiWrapperRestClient.ping(basicAuth);

		SearchResponse sresp = new SearchResponse();
		Processes processes = new Processes();
		Properties properties = new Properties();

		if (StringUtils.isNotBlank(sr.getTaskId())) {
			processes.getProcess().add(
					queryAllDataforProcess(sr.getTaskId(), sr.getDepartment()));
			sresp.setProcesses(processes);
			return sresp;
		}

		if (StringUtils.isNotBlank(sr.getTaskType())) {

			NameValue nv = new NameValue();
			nv.setName(TASK_TYPE);
			nv.setValue(sr.getTaskType());
			properties.getProperty().add(nv);
			sr.setProperties(properties);
		}
		
		if (StringUtils.isNotBlank(sr.getAssignedTo())) {

			NameValue nv = new NameValue();
			nv.setName(ASSIGNED_TO);
			nv.setValue(sr.getAssignedTo());
			properties.getProperty().add(nv);
			sr.setProperties(properties);
		}

		List<String> procDefNames = new ArrayList<String>();
		boolean ifDeptExists = false;
		if (StringUtils.isNotEmpty(sr.getDepartment())) {

			String baName = sr.getDepartment();
			procDefNames = this.jdbcTemplate.query(GET_PROCDEFINITION_SQL,
					new Object[] { baName }, new RowMapper<String>() {
						@Override
						public String mapRow(ResultSet rs, int rowNum)
								throws SQLException {
							return rs.getString("processName");

						}
					});

			if (procDefNames.size() == 0) {
				sresp.setProcesses(processes);
				return sresp;
			}
			ifDeptExists = true;
		}
		// Get Process-Department mappings from database
		Map<String, String> procDeptNames = configRepositoryService
				.getProcessDepartmentNames();

		BoolQueryBuilder boolQuery = new BoolQueryBuilder();
		boolean onlyDeptCheck = false;

		// Only when department is passed with no FilterType search criteria.
		if (sr.getProperties() != null) {
			
			for (NameValue nv : sr.getProperties().getProperty()) {
				BoolQueryBuilder andClauseQuery = new BoolQueryBuilder();
				if (nv.getValue() != null) {
					andClauseQuery.must(QueryBuilders.matchQuery(
							"_exact_string_value", nv.getValue()));
				} else if (nv.getNumValue() != null) {
					andClauseQuery.must(QueryBuilders.matchQuery("longValue",
							nv.getNumValue()));
				} else if (nv.getDecimalValue() != null) {
					andClauseQuery.must(QueryBuilders.matchQuery("doubleValue",
							nv.getDecimalValue()));
				} else if (nv.getDateValue() != null) {
					andClauseQuery.must(QueryBuilders
							.matchQuery("_exact_string_value", nv
									.getDateValue().toString()));
				} else if (nv.isBooleanValue() != null) {
					andClauseQuery.must(QueryBuilders.matchQuery(
							"booleanValue", nv.isBooleanValue()));
				}

				// Remove the space's in between the variable name
				String varName = nv.getName();
				varName = varName.replaceAll("\\s+", "");
				String mappedValue=searchIdentifierMapper.getMappedValue(varName);
				varName=mappedValue;				
				andClauseQuery.must(QueryBuilders.matchQuery("name", varName));

				if (ifDeptExists) {
					LOGGER.debug("Adding processDefinitions to the query - "
							+ procDefNames);
					andClauseQuery.must(QueryBuilders.termsQuery(
							"processDefinitionKey", procDefNames));
				}
				boolQuery.should(andClauseQuery);
			}
		} 
		else if (ifDeptExists && sr.getFilterType() == null) {// Only when department is passed with no FilterType search criteria.
			// when no properties, but have a department
			BoolQueryBuilder andClauseQuery = new BoolQueryBuilder();
			LOGGER.debug("Adding processDefinitions to the query - "
					+ procDefNames);
			andClauseQuery.must(QueryBuilders.matchQuery(
					"processDefinitionKey", procDefNames));
			boolQuery.should(andClauseQuery);
			onlyDeptCheck = true;
		}
		
		if (sr.getFilterType() != null) {

			if ((sr.getStartDate() == null) || (sr.getEndDate() == null)) {
				LOGGER.error("StartDate and EndDate are missing in searchRequest");
				throw new BadRequestException(
						"StartDate and EndDate are required in searchRequest");
			}
			
			// Created Date should always be accompanied by a property
			if (sr.getFilterType().equals(DateType.CREATED_DATE) && (sr.getProperties() == null || sr.getProperties().getProperty().isEmpty())) {
				LOGGER.error("CreatedDate alone isn't a valid search criteria. Need a property along with the create date for valid search");
				throw new BadRequestException(
						"CreatedDate alone isn't a valid search criteria. Need a property along with the create date for valid search");
			}
			
			BoolQueryBuilder andClauseQuery = new BoolQueryBuilder();
			boolean dateChk = false;
			if (!sr.getFilterType().equals(DateType.CREATED_DATE) ){
				andClauseQuery.must(QueryBuilders.rangeQuery("dateValue")
						.gt(toEpoch(sr.getStartDate()))
						.lt(toEpoch(sr.getEndDate())).includeLower(true)
						.includeUpper(true));
				andClauseQuery.must(QueryBuilders.matchQuery("name", sr
						.getFilterType().value()));
				dateChk = true;
			} 
			
			if (ifDeptExists) {
				LOGGER.debug("Adding processDefinitions to the query - "
						+ procDefNames);
				andClauseQuery.must(QueryBuilders.termsQuery(
						"processDefinitionKey", procDefNames));
			}
			if(dateChk || ifDeptExists){
				boolQuery.should(andClauseQuery);
			}
			
		}

		SearchRequestBuilder bldr = this.transportClient
				.prepareSearch(this.indexName)
				.setTypes(VARIABLE_TYPE)
				.addAggregation(
						AggregationBuilders
								.terms("agg_name")
								.field(PROCESS_INSTANCE_ID)
								.size(250)
								// .field("Id")
								.subAggregation(
										AggregationBuilders
												.topHits("documents").setSize(
														1000)))
				.setSearchType(SearchType.DFS_QUERY_THEN_FETCH)
				.setQuery(boolQuery).setFrom(0).setSize(250).setExplain(true);

		LOGGER.debug("boolQuery :::" + bldr);
		org.elasticsearch.action.search.SearchResponse response = bldr
				.execute().actionGet();

		Terms aggNameAggregation = response.getAggregations().get("agg_name");

		int bucketCnt = 0;
		if (sr.getProperties() != null) {
			bucketCnt = sr.getProperties().getProperty().size();
			if (sr.getFilterType() != null && !sr.getFilterType().equals(DateType.CREATED_DATE)) {
				bucketCnt++;
			}
		} else if (sr.getFilterType() != null || procDefNames != null
				&& procDefNames.size() > 0) {
			bucketCnt++;
		}

		for (Terms.Bucket bucket : aggNameAggregation.getBuckets()) {

			TopHits topHits = bucket.getAggregations().get("documents");
			SearchHit[] searchHits = topHits.getHits().getHits();
			int length = searchHits.length;

			// Get Department value for the processDefinitionKey
			String department = "";
			for (int i = 0; i < length; i++) {
				Map<String, Object> mp = searchHits[i].sourceAsMap();
				String processDefName = String.valueOf(mp.get("processDefinitionKey"));
				department = procDeptNames.get(processDefName);
			}

			if (bucketCnt == length || onlyDeptCheck) {
					queryForProcesses(bucket.getKey(), department,sr.getTaskStatus(),processes,sr);
			}
		}
		sresp.setProcesses(processes);
		return sresp;
	}
	
	private void queryForProcesses(String procId, String department,Status sts, Processes processes, SearchRequest sr){
		
		Process process= queryAllDataforProcess(procId,department);
		GetResponse resp = this.transportClient.prepareGet(this.indexName,"process-instances",procId).execute().actionGet();
	
		process.setStatusHistory(getProcessStatus(resp));

		
		String procStatus=process.getStatusHistory().getSts().get(0).getSts();
		String statusInReq=sts!=null?sts.getSts():null;
		
		if(sr.getFilterType() != null && sr.getFilterType().equals(DateType.CREATED_DATE)){
			XMLGregorianCalendar createTm = toDate(Long.parseLong(resp.getSourceAsMap().get("createTime").toString()));
			XMLGregorianCalendar modifiedStDt = sr.getStartDate();
			modifiedStDt.setTime(0, 0, 0);
			
			XMLGregorianCalendar modifiedEndDt = sr.getEndDate();
			modifiedEndDt.setTime(23, 59,59);
			
			if(!(createTm.compare(modifiedStDt) >= 0 && createTm.compare(modifiedEndDt) <= 0)){
				return;				
			}
		}
		
		if(sts!=null){
		  if(procStatus.equalsIgnoreCase(statusInReq)) {
				processes.getProcess().add(process);
		  }
		}else{
			processes.getProcess().add(process);
		}
		
	}

	@SuppressWarnings("rawtypes")
	public Process queryAllDataforProcess(String processId, String department) {
		Process process = new Process();
		Properties p = new Properties();
		org.elasticsearch.action.search.SearchResponse response = this.transportClient
				.prepareSearch(this.indexName)
				.setTypes(VARIABLE_TYPE)
				.setSearchType(SearchType.DFS_QUERY_THEN_FETCH)
				.setQuery(
						QueryBuilders
								.matchQuery(PROCESS_INSTANCE_ID, processId))
				.setFrom(0).setSize(250).setExplain(true).execute().actionGet();

		SearchHit[] searchHits = response.getHits().getHits();
		int length = searchHits.length;
		process.setProcessId(processId);
		process.setAppName(APPLICATION_NAME);

		for (int i = 0; i < length; i++) {
			Map mp = searchHits[i].sourceAsMap();

			String variableName = String.valueOf(mp.get("name"));
			String variableType = String.valueOf(mp.get("variableType"));

			if ((variableName != null)
					&& VARIABLE_EXLCUSION_LIST.contains(variableName
							.toLowerCase())) {
				continue;
			}

			NameValue nv = new NameValue();
			nv.setName(variableName);
			nv.setDesc(variableName);

			if ("String".equalsIgnoreCase(variableType)) {
				nv.setValue(mp.get("stringValue") != null ? mp.get(
						"stringValue").toString() : null);
			} else if ("boolean".equalsIgnoreCase(variableType)) {
				nv.setBooleanValue(mp.get("booleanValue") != null ? Boolean
						.valueOf(mp.get("booleanValue").toString()) : null);
			} else if ("integer".equalsIgnoreCase(variableType)) {
				nv.setNumValue(mp.get("longValue") != null ? new BigInteger(mp
						.get("longValue").toString()) : null);
			} else if ("double".equalsIgnoreCase(variableType)) {
				nv.setDecimalValue(mp.get("doubleValue") != null ? new BigDecimal(
						mp.get("doubleValue").toString()) : null);
			} else if ("date".equalsIgnoreCase(variableType)) {
				nv.setDateValue(toDate(Long.parseLong(mp.get("dateValue")
						.toString())));
			}
			p.getProperty().add(nv);
		}

		// create department variable
		NameValue nv = new NameValue();
		nv.setName(DEPARTMENT);
		nv.setDesc(DEPARTMENT);
		nv.setValue(department);
		p.getProperty().add(nv);

		process.setProcessProperties(p);
		
		return process;
	}

	
	private Statuses getProcessStatus(final GetResponse response) {
			
		String strStatus = "";
		Map<String,Object> map = response.getSourceAsMap();
		if (map.get("endTime") != null){
			strStatus = "COMPLETED";
		}else{
			strStatus = "OPEN";
		} 
		
		Statuses statuses = new Statuses();
		Status status = new Status();
		statuses.getSts().add(status);
		status.setSts(strStatus);
		return statuses;
	}

	public long toEpoch(XMLGregorianCalendar xmlGregorianCalendar) {
		return xmlGregorianCalendar.toGregorianCalendar().getTimeInMillis();
	}

	private XMLGregorianCalendar toDate(long time) {
		Date date = new Date(time);
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(date);
		XMLGregorianCalendar date2 = null;
		try {
			date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		} catch (DatatypeConfigurationException e) {
			e.printStackTrace();
			LOGGER.error("Error converting date", e);
			throw new BusinessProcessApplicationException(e.getMessage());
		}
		return date2;
	}

}
