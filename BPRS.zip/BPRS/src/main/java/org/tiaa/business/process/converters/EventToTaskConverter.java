package org.tiaa.business.process.converters;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.util.Constants;
import org.tiaa.esb.case_management_common_types.types.Task;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Status;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Statuses;

@Component
public class EventToTaskConverter implements
		Converter<org.tiaa.pvm.activiti_wrapper_v1_0.types.Event, Task> {

	@Override
	public Task convert(org.tiaa.pvm.activiti_wrapper_v1_0.types.Event source) {

		  if (source == null) {
		   return null;
		  }
		  String completedBy=null;
		  Task task = new Task();
		  task.setName(source.getTitle());  
		  task.setType("userTask".equals(source.getEventType())||"tngReceiveTask".equals(source.getEventType()) ? Constants.TASK_HUMAN
		    : Constants.TASK_SYSTEM);
		  task.setStatusHistory(new Statuses());
		
		  completedBy = "tngReceiveTask".equalsIgnoreCase(source.getEventType()) ? source.getCreatedBy() : Constants.TASK_SYSTEM;
		
		  task.getStatusHistory()
		  	.getSts()
		  .add(
		      createStatusObject("Started", source.getCreateDateTime(),
		        completedBy));
		  
		  if (source.getEndDateTime() != null) {
			  completedBy = "userTask".equalsIgnoreCase(source.getEventType()) ? source.getCreatedBy() : Constants.TASK_SYSTEM;
			  task.getStatusHistory().getSts().add(createStatusObject("Completed", source.getEndDateTime(), completedBy));
		  }
		  
		  task.setCreateDate(source.getCreateDateTime());
		  task.setCreateTime(source.getCreateDateTime());
		  task.setCompleteDate(source.getEndDateTime());
		  task.setCompleteTime(source.getEndDateTime());
		  task.setAssignedTo(source.getCreatedBy());
		  return task;
		 }
	
	private Status createStatusObject(final String status,
			final XMLGregorianCalendar effDate, final String completedBy) {
		Status statusObj = new Status();
		statusObj.setSts(status);
		statusObj.setEffDate(effDate);
		statusObj.setCmplmtBy(completedBy);

		return statusObj;
	}

}
