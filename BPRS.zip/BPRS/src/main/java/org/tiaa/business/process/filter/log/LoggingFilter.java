package org.tiaa.business.process.filter.log;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

/**
 *
 * @author subashr
 *
 */
public class LoggingFilter implements Filter {

	private static final Logger LOGGER = Logger.getLogger(LoggingFilter.class);

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// Do nothing. 
	}

	@Override
	public void doFilter(ServletRequest servletRequest,
			ServletResponse servletResponse, FilterChain filterChain)
					throws IOException, ServletException {

		String url = ((HttpServletRequest) servletRequest).getRequestURI();

		// if Ping or BPMN Deploy dont log the request
		if (url.endsWith("/ping") || url.endsWith("/admin/bpmn/deploy")) {
			filterChain.doFilter(servletRequest, servletResponse);
			return;
		}

		BufferedRequestWrapper bufferedRequest = new BufferedRequestWrapper(
				(HttpServletRequest) servletRequest);

		RequestResponseLogger requestResponseLogger = new RequestResponseLogger(
				bufferedRequest.getRequestURI(), bufferedRequest.getMethod(),
				new String(bufferedRequest.getBuffer()));

		final HttpServletResponse response = (HttpServletResponse) servletResponse;

		final ByteArrayPrintWriter pw = new ByteArrayPrintWriter();
		BufferedStatusAwareServletResponse wrappedResponse = new BufferedStatusAwareServletResponse(
				response, pw);
		filterChain.doFilter(bufferedRequest, wrappedResponse);

		byte[] bytes = pw.toByteArray();
		response.getOutputStream().write(bytes);
		requestResponseLogger.setResponseBody(new String(bytes));
		requestResponseLogger.setResponseStatusCode(wrappedResponse
				.getHttpStatus());

		LOGGER.info("************** REST Call:" + requestResponseLogger);
	}

	@Override
	public void destroy() {
		// Do nothing. 
	}
}
