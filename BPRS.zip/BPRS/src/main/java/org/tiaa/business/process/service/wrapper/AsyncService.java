package org.tiaa.business.process.service.wrapper;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import org.tiaa.business.process.entities.AsyncMessage;
import org.tiaa.business.process.repository.AsyncMessageRepository;
import org.tiaa.business.process.service.async.AsyncMessageProcessor;

@Service
public class AsyncService {

	private static final Logger LOGGER = Logger.getLogger(AsyncService.class);
	private static final int EXCEPTION_COLUMN_LENGTH = 3500;

	@Autowired
	protected AsyncMessageRepository repo;

	@Autowired
	TransactionTemplate transactionTemplate;

	// Activiti AsyncExecutor
	@Value("${bprs.asyncexecutor.enabled}")
	private String bprsAsyncExecutorEnabled;

	@Autowired
	private List<AsyncMessageProcessor> messageProcessors;

	private long currentStartMessageId;
	private String systemUUID = UUID.randomUUID().toString();
	private static final long MAX_LOCK_TIME = 900000L;
	private static final long ERROR_RETRY_TIME = 300000L;
	private static final int BLOCK_SIZE = 10;

	@Scheduled(initialDelay = 30000, fixedDelayString = "${bprs.asyncexecutor.delay}")
	public void executeEventProcessing() {

		// Check if processing is enabled
		if (!"true".equalsIgnoreCase(this.bprsAsyncExecutorEnabled)) {
			return;
		}

		long newStartMesageId = findFirstLockableEvent();
		while (newStartMesageId != -1) {
			this.currentStartMessageId = newStartMesageId;
			internalExecuteProcessing();
			newStartMesageId = findFirstLockableEvent();
		}
	}

	@Scheduled(initialDelay = 30000, fixedDelayString = "${bprs.asyncexecutor.expired.delay}")
	public void expiredEventProcessing() {

		if (!"true".equalsIgnoreCase(this.bprsAsyncExecutorEnabled)) {
			return;
		}

		// Find expired events and execute them
		try {
			processExpiredEvents();
		} catch (Exception e) {
			LOGGER.error("Exception during processing of expired events!", e);
		}
	}

	public Long addAsyncMessage(final String type, final String message) {
		AsyncMessage asyncMessage = this.transactionTemplate
				.execute(new TransactionCallback<AsyncMessage>() {
					@Override
					public AsyncMessage doInTransaction(TransactionStatus status) {
						return AsyncService.this.repo
								.saveAndFlush(new AsyncMessage(type, message));
					}
				});
		return asyncMessage.getMessageId();
	}

	private void internalExecuteProcessing() {
		int nrOfLockedEvents = lockBlockOfEvents();

		if (nrOfLockedEvents > 0) {
			LOGGER.info("Locked " + nrOfLockedEvents + " events to process");
			processLockedEvents();
		}
	}

	private long findFirstLockableEvent() {
		return this.transactionTemplate
				.execute(new TransactionCallback<Long>() {
					@Override
					public Long doInTransaction(TransactionStatus status) {
						List<AsyncMessage> lockableEvents = AsyncService.this.repo.findLockableEventsOrderByMessageId(
								new Date(new Date().getTime()
										- AsyncService.ERROR_RETRY_TIME),
										new PageRequest(0, 1));
						if ((lockableEvents != null)
								&& (lockableEvents.size() > 0)) {
							return lockableEvents.get(0).getMessageId();
						}
						return -1L;
					}
				});
	}

	private int lockBlockOfEvents() {
		return this.transactionTemplate
				.execute(new TransactionCallback<Integer>() {
					@Override
					public Integer doInTransaction(TransactionStatus status) {
						return AsyncService.this.repo.lockBlockOfEvents(
								AsyncService.this.systemUUID, new Date(),
								AsyncService.this.currentStartMessageId,
								AsyncService.this.currentStartMessageId + BLOCK_SIZE,
								new Date(new Date().getTime()
										- AsyncService.ERROR_RETRY_TIME));
					}
				});
	}

	private int claimExpiredEvents() {
		return this.transactionTemplate
				.execute(new TransactionCallback<Integer>() {

					@Override
					public Integer doInTransaction(TransactionStatus status) {
						return AsyncService.this.repo.lockExpiredEvents(
								AsyncService.this.systemUUID + "_expired",
								new Date(), new Date(new Date().getTime()
										- AsyncService.MAX_LOCK_TIME));
					}

				});
	}

	private List<AsyncMessage> findExpiredEvents() {
		return this.transactionTemplate
				.execute(new TransactionCallback<List<AsyncMessage>>() {
					@Override
					public List<AsyncMessage> doInTransaction(
							TransactionStatus status) {
						return AsyncService.this.repo
								.findExpiredLockedEvents(AsyncService.this.systemUUID
										+ "_expired");
					}
				});
	}

	private int markEventAsProcessed(final Long messageId) {
		return this.transactionTemplate
				.execute(new TransactionCallback<Integer>() {
					@Override
					public Integer doInTransaction(TransactionStatus status) {
						return AsyncService.this.repo.markEventAsProcessed(
								messageId, new Date());
					}
				});
	}

	private int markEventAsFailed(final Long messageId,
			final String errorMessage, final String metaData) {
		LOGGER.debug("**************************** MetaData Length is ::"
				+ metaData.length() + ":::: ErrorMessage Length :"
				+ errorMessage.length());
		return this.transactionTemplate
				.execute(new TransactionCallback<Integer>() {
					@Override
					public Integer doInTransaction(TransactionStatus status) {
						return AsyncService.this.repo.markEventAsFailed(
								messageId, errorMessage, metaData, new Date());
					}
				});
	}

	/**
	 * Processes the block of locked events (uses same query as
	 * {@link #lockBlockOfEvents()}.
	 */
	private List<Long> processLockedEvents() {

		// Fetch row set
		List<AsyncMessage> events = this.transactionTemplate
				.execute(new TransactionCallback<List<AsyncMessage>>() {
					@Override
					public List<AsyncMessage> doInTransaction(
							TransactionStatus status) {
						return AsyncService.this.repo.findLockedEvents(
								AsyncService.this.systemUUID,
								AsyncService.this.currentStartMessageId,
								AsyncService.this.currentStartMessageId + BLOCK_SIZE);
					}
				});

		// Process each event
		return processEvents(events);
	}

	private void processExpiredEvents() {

		// Locks the expired events to this processor
		claimExpiredEvents();

		// Process expired event again, one by one
		List<AsyncMessage> events = findExpiredEvents();
		processEvents(events);
	}

	private AsyncMessageProcessor getAsyncMessageProcessor(final String type) {
		for (AsyncMessageProcessor processor : this.messageProcessors) {
			if (processor.isEventTypeProcessable(type)) {
				return processor;
			}
		}
		return null;
	}

	private List<Long> processEvents(List<AsyncMessage> events) {
		List<Long> handledMessageIds = new ArrayList<Long>();

		for (AsyncMessage event : events) {
			final long messageId = event.getMessageId();
			final String type = event.getMessageType();

			// Get the processor for the given type
			final AsyncMessageProcessor eventProcessor = getAsyncMessageProcessor(type);

			try {
				if (eventProcessor != null) {
					eventProcessor.processMessage(event.getData());
				} else {
					LOGGER.error("No Event Processor found for event type "
							+ type + " . Message Id:" + messageId);
				}

				markEventAsProcessed(messageId);
			} catch (Exception e) {
				LOGGER.error("Exception while processing event " + messageId
						+ " . Reason - " + e.getMessage(), e);

				String metaData = "";
				try {
					metaData = eventProcessor.getMessageMetaData(event
							.getData());
				} catch (Exception eMeta) {
					// do nothing.
				}

				// Check for MetaData length.
				if (metaData.length() > EXCEPTION_COLUMN_LENGTH) {
					metaData = metaData.substring(0, EXCEPTION_COLUMN_LENGTH);
				}

				String errorMessage = event.getExceptionMessage() == null ? ""
						: event.getExceptionMessage();
				if (errorMessage != null) {
					errorMessage = errorMessage + "\n" + e.getMessage() + "\n";
				}

				// Check for Error Message length.
				if (errorMessage.length() > EXCEPTION_COLUMN_LENGTH) {
					errorMessage = errorMessage.substring(0,
							EXCEPTION_COLUMN_LENGTH);
				}

				markEventAsFailed(messageId, errorMessage, metaData);
			}

			handledMessageIds.add(messageId);
		}

		if (!handledMessageIds.isEmpty()) {
			LOGGER.info("Processed " + handledMessageIds.size() + " events");
		}

		return handledMessageIds;
	}
}