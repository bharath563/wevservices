package org.tiaa.business.process.filter.log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.ServletOutputStream;

public class ByteArrayServletStream extends ServletOutputStream {
	ByteArrayOutputStream baos;

	ByteArrayServletStream(ByteArrayOutputStream baos) {
		this.baos = baos;
	}

	@Override
	public void write(int param) throws IOException {
		this.baos.write(param);
	}

}
