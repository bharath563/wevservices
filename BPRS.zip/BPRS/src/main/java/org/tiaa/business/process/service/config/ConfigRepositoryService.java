package org.tiaa.business.process.service.config;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component
public class ConfigRepositoryService {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private Map<String, String> processDefDeptCache = new ConcurrentHashMap<String, String>(100);

	private static final String PROCDEF_DEPT_QUERY = "SELECT proc.PROCESS_NAME as processName,  ba.BA_NAME "
			+ "FROM NXTGENAPP.CMF_PM_PROCESS proc INNER JOIN NXTGENAPP.CMF_PM_BUSINESSAREA_PROCESS_X baproc  on proc.PROCESS_CODE = baproc.PROCESS_CODE "
			+ "INNER JOIN NXTGENAPP.CMF_PM_BUSINESSAREA ba on ba.BA_CODE = baproc.BA_CODE  order by proc.PROCESS_NAME";


	public Map<String, String> getProcessDepartmentNames() {

		List<Map<String, String>> resultList = this.jdbcTemplate.query(PROCDEF_DEPT_QUERY, new MapRowMapper());

		for (Map<String, String> map : resultList) {
			processDefDeptCache.put(map.keySet().iterator().next(), map.values()
					.iterator().next());
		}
		return processDefDeptCache;
	}

    class MapRowMapper implements RowMapper<Map<String, String>> {

		@Override
		public Map<String, String> mapRow(ResultSet rs, int rowNum)
				throws SQLException {
			Map<String, String> map = new HashMap<String, String>();
			map.put(rs.getString(1), rs.getString(2));
			return map;
		}

	}

}
