package org.tiaa.business.process.filter.log;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class BufferedRequestWrapper extends HttpServletRequestWrapper {
	ByteArrayInputStream bais;

	ByteArrayOutputStream baos;

	BufferedServletInputStream bsis;

	byte[] buffer;

	public BufferedRequestWrapper(HttpServletRequest req) throws IOException {
		super(req);
		InputStream is = req.getInputStream();
		this.baos = new ByteArrayOutputStream();
		byte[] buf = new byte[1024];
		int letti;
		while ((letti = is.read(buf)) > 0) {
			this.baos.write(buf, 0, letti);
		}
		this.buffer = this.baos.toByteArray();
	}

	@Override
	public ServletInputStream getInputStream() {
		try {
			this.bais = new ByteArrayInputStream(this.buffer);
			this.bsis = new BufferedServletInputStream(this.bais);
		} catch (Exception ex) {
			// do nothing
			ex.printStackTrace();
		}

		return this.bsis;
	}

	public byte[] getBuffer() {
		return this.buffer;
	}

}
