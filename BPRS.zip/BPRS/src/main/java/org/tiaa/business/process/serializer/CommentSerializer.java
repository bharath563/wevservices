package org.tiaa.business.process.serializer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import org.tiaa.esb.case_management_common_types.types.Comment;

/**
 * Serializer implementation for Object Model Comment Class
 *
 * @author subashr
 *
 */
@Component
public class CommentSerializer extends AbstractObjectSerializer<Comment> {

	@Override
	protected List<Map<String, String>> convertObjectToMap(Comment obj) {

		Map<String, String> mapValues = new HashMap<String, String>();

		if (obj == null) {
			return null;
		}

		mapValues.put("Message", obj.getMessage());
		mapValues.put("Desc", obj.getDesc());
		mapValues.put("Type", obj.getType());
		return encapsulateMapIntoList(mapValues);
	}

	@Override
	protected Comment convertMapToObject(List<Map<String, String>> mapValues) {

		if ((mapValues == null) || mapValues.isEmpty()) {
			return null;
		}

		Map<String, String> commentMap = mapValues.get(0);

		Comment obj = new Comment();
		obj.setMessage(commentMap.get("Message"));
		obj.setDesc(commentMap.get("Desc"));
		obj.setType(commentMap.get("Type"));
		return obj;
	}

}
