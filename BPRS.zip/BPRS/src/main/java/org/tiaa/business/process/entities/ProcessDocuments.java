package org.tiaa.business.process.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


import static org.tiaa.business.process.util.Constants.*;

/**
 * @author polara
 *
 */
@Entity
@Table(name = "PROCESS_DOCUMENTS")
public class ProcessDocuments {


	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "documents_id_seq")
	@SequenceGenerator(name = "documents_id_seq", sequenceName = "PROCESS_DOCUMENTS_SEQ", allocationSize = 1)
	private Long id;

	@Column(name = "PROC_INST_ID")
	private String processInstanceId;

	@Column(name = "DOC_TEXT")
	private String docText;

	@Column(name = "DOC_CLOB")
	@Lob
	private String docClob;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	private Date createTime;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_UPDATED_TIME")
	private Date lastUpdatedTime;

	public String getProcessInstanceId() {
		return processInstanceId;
	}

	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getLastUpdatedTime() {
		return this.lastUpdatedTime;
	}

	public void setLastUpdatedTime(Date lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDocText() {
		return this.docText;
	}

	public void setDocText(String docText) {
		this.docText = docText;
	}

	public String getDocClob() {
		return this.docClob;
	}

	public void setDocClob(String docClob) {
		this.docClob = docClob;
	}

	public String getDocuments() {
		if (this.getDocText() != null) {
			return this.getDocText();
		} else {
			return this.getDocClob();
		}
	}

	public void setDocuments(String documents) {
		if (documents.length() > MAX_LENGTH) {
			this.setDocText(null);
			this.setDocClob(documents);
		} else {
			this.setDocClob(null);
			this.setDocText(documents);
		}
	}
}
