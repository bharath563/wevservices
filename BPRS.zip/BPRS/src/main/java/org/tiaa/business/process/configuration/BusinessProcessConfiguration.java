package org.tiaa.business.process.configuration;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import javax.jms.ConnectionFactory;

import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.ibm.mq.jms.MQQueueConnectionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.ConversionServiceFactoryBean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2CollectionHttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.core.MessageSource;
import org.springframework.integration.mail.ImapMailReceiver;
import org.springframework.integration.mail.MailReceiver;
import org.springframework.integration.mail.MailReceivingMessageSource;
import org.springframework.integration.mail.transformer.MailToStringTransformer;
import org.springframework.integration.transformer.Transformer;
import org.springframework.jms.connection.JmsTransactionManager;
import org.springframework.jms.connection.TransactionAwareConnectionFactoryProxy;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.listener.adapter.MessageListenerAdapter;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.jndi.JndiTemplate;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import org.tiaa.business.process.email.EmailListener;
import org.tiaa.business.process.queue.listener.QueueListener;
import org.tiaa.business.process.rest.template.TIAARestTemplate;
import org.tiaa.business.process.service.exception.BusinessProcessApplicationException;
import org.tiaa.business.process.util.Constants;
import org.tiaa.business.process.util.CryptUtility;
import org.tiaa.business.process.util.DateUtil;
import org.tiaa.business.process.uuid.CorrelationUUIDGenerator;
import org.tiaa.business.process.wrapper.client.RestResponseErrorHandler;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Clob;

/**
 * Configuration Class for PVM
 *
 * @author subashr
 *
 *
 */
@Configuration
@EnableWebMvc
@ComponentScan("org.tiaa.business.process")
@SuppressWarnings("rawtypes")
@EnableIntegration
@PropertySources({
@PropertySource(value = "classpath:BusinessProcessConfig.properties", ignoreResourceNotFound = false),
@PropertySource(value = "classpath:BusinessProcessConfigEnvironment.properties", ignoreResourceNotFound = false) })
public class BusinessProcessConfiguration extends WebMvcConfigurerAdapter {

	private static final Logger LOGGER = Logger.getLogger(BusinessProcessConfiguration.class);

	// Activiti Wrapper Properties
	@Value("${activiti.wrapper.URL}")
	private String activitiWrapperURL;

	@Value("${activiti.wrapper.maxConnections}")
	private String activitiWrapperMaxConnections;

	// JNDI Properties
	@Value("${queue.01A.jndi.name}")
	public String jndi01AName;

	@Value("${queue.01B.jndi.name}")
	public String jndi01BName;

	@Value("${queue.02A.jndi.name}")
	public String jndi02AName;

	@Value("${queue.02B.jndi.name}")
	public String jndi02BName;

	@Value("${bpm.resp.inbound.queue.alias}")
	public String correlationQueueName;

	@Value("${bpm.resp.inbound.concurrentconsumers}")
	public String correlationQueueConsumers;

	@Value("${bpm.resp.inbound.timeout}")
	public String correlationQueueTimeOut;

	@Value("${bpm.req.inbound.queue.alias}")
	public String requestQueueName;

	@Value("${bpm.req.inbound.concurrentconsumers}")
	public String requestQueueConsumers;

	@Value("${bpm.req.inbound.timeout}")
	public String requestQueueTimeOut;

	@Value("${es.cluster.name}")
	private String clusterName;

	@Value("${es.hostnamesandport}")
	private String hostNamesAndPort;

	@Value("${mail.smtp.port}")
	private String smtpPort;

	@Value("${mail.id}")
	private String emailId;

	@Value("${mail.pwd}")
	private String emailPwd;

	@Value("${mail.account.name}")
	private String emailAccount;

	@Value("${mail.account.port}")
	private String emailAccountPort;
	
	@Value("${bpm.cth.req.inbound.queue.alias}")
	public String requestCTHQueueName;

	@Value("${bpm.cth.req.inbound.concurrentconsumers}")
	public String requestCTHQueueConsumers;

	@Value("${bpm.cth.req.inbound.timeout}")
	public String requestCTHQueueTimeOut;
	

	@Autowired
	List<Converter> converters;

	@Autowired
	EmailListener emailListener;

	private static final long MAX_FILEUPLOAD_SIZE = 104857600L;
	
	@Bean
	public QueueListener requestQueueListener() {
		QueueListener requestQueueListener = new QueueListener();
		requestQueueListener.setType(Constants.REQUEST_QUEUE_EVENT);
		return requestQueueListener;
	}

	@Bean
	public QueueListener correlationQueueListener() {
		QueueListener requestQueueListener = new QueueListener();
		requestQueueListener.setType(Constants.CORRELATION_QUEUE_EVENT);
		return requestQueueListener;
	}

	@Override
	public void configureMessageConverters(List<HttpMessageConverter<?>> converters) {

		// http
		HttpMessageConverter converter = new StringHttpMessageConverter();
		converters.add(converter);
		LOGGER.info("HttpMessageConverter added");

		// string
		converter = new FormHttpMessageConverter();
		converters.add(converter);
		LOGGER.info("FormHttpMessageConverter added");

		// json
		converter = new MappingJackson2HttpMessageConverter(objectMapper());
		converters.add(converter);
		LOGGER.info("MappingJackson2HttpMessageConverter added");

		// Jaxb
		converter = new Jaxb2RootElementHttpMessageConverter();
		converters.add(converter);
		LOGGER.info("Jaxb2RootElementHttpMessageConverter added");

		converter = new Jaxb2CollectionHttpMessageConverter();
		converters.add(converter);
		LOGGER.info("Jaxb2RootElementHttpMessageConverter added");

		converter = new MappingJackson2XmlHttpMessageConverter(xmlMapper());
		converters.add(converter);
		LOGGER.info("MappingJackson2XmlHttpMessageConverter added");
	}

	@Bean
	public XmlMapper xmlMapper() {
		JacksonXmlModule jaxModule = new JacksonXmlModule();
		jaxModule.setDefaultUseWrapper(false);
		XmlMapper xmlMapper = new XmlMapper(jaxModule);
		xmlMapper.addMixIn(Clob.class, Mixin.class);
		xmlMapper.setSerializationInclusion(Include.NON_NULL);
		xmlMapper.setDateFormat(new SimpleDateFormat(
				DateUtil.DATE_FORMAT_PATTERN));
		xmlMapper.setPropertyNamingStrategy(PropertyNamingStrategy.PASCAL_CASE_TO_CAMEL_CASE);
		return xmlMapper;
	}

	@Bean
	public ConversionService conversionService() {
		ConversionServiceFactoryBean factory = new ConversionServiceFactoryBean();
		Set<Converter> converterSet = new HashSet<Converter>();

		for (Converter converter : this.converters) {
			converterSet.add(converter);
		}

		factory.setConverters(converterSet);
		factory.afterPropertiesSet();
		return factory.getObject();
	}

	@Bean
	public TIAARestTemplate tiaaActivitiWrapperClient() {
		LOGGER.info("Creating Rest Client for Activiti Wrapper.");

		TIAARestTemplate restTemplate = new TIAARestTemplate();
		restTemplate.setBasicAuth(false);
		restTemplate.setMaxTotalConnections(Integer
				.parseInt(this.activitiWrapperMaxConnections));
		restTemplate.setBaseUrl(this.activitiWrapperURL
				+ "/tiaa-activiti-rs-v1");
		restTemplate.setErrorHandler(new RestResponseErrorHandler());

		restTemplate.afterPropertiesSet();

		return restTemplate;
	}

	@Bean
	public TIAARestTemplate activitiAppWrapperClient() {
		LOGGER.info("Creating Rest Client for Activiti Wrapper.");

		TIAARestTemplate restTemplate = new TIAARestTemplate();
		restTemplate.setBasicAuth(false);
		restTemplate.setMaxTotalConnections(10);
		restTemplate.setBaseUrl(this.activitiWrapperURL);
		restTemplate.setErrorHandler(new RestResponseErrorHandler());
		restTemplate.afterPropertiesSet();

		return restTemplate;
	}

	@Bean
	public ObjectMapper objectMapper() {
		return new ObjectMapper().setSerializationInclusion(Include.NON_NULL);
	}

	// ES Settings
	@Bean
	public TransportClient transportClient() {
		LOGGER.info(" Starting Elastic Cluster Connection. Cluster Name:"
				+ this.clusterName);
		Settings settings = ImmutableSettings.settingsBuilder()
				.put("cluster.name", this.clusterName).build();

		TransportClient tclient = new TransportClient(settings);

		StringTokenizer st = new StringTokenizer(this.hostNamesAndPort, ";");

		while (st.hasMoreElements()) {
			String hostPort = st.nextElement().toString();
			LOGGER.info("Host>>>>>>>>>>>>>>>>>>>" + hostPort.split(":")[0]
					+ "Port:  " + hostPort.split(":")[1]);
			tclient.addTransportAddress(new InetSocketTransportAddress(hostPort
					.split(":")[0], Integer.parseInt(hostPort.split(":")[1])));
		}
		return tclient;

	}

	@Bean
	public JndiTemplate jndiTemplate() {
		LOGGER.info("Creating JNDI Template Object for Queue Connections");
		Properties properties = new Properties();
		properties.put("java.naming.factory.initial",
				"com.sun.jndi.fscontext.RefFSContextFactory");

		URL bindingsUrl = this.getClass().getClassLoader()
				.getResource("./mqhotel/.bindings");

		if (bindingsUrl == null) {
			throw new BusinessProcessApplicationException(
					"Could not locate .bindings file from classpath ./mqhotel/.bindings");
		}

		String path = bindingsUrl.getPath();
		path = "file://" + path.substring(0, path.lastIndexOf("/"));

		properties.put("java.naming.provider.url", path);
		JndiTemplate template = new JndiTemplate();
		template.setEnvironment(properties);
		return template;
	}

	@Bean
	public TransactionAwareConnectionFactoryProxy jndi01ACachingConnectionFactoryProxy() {
		return jndiCachingConnectionFactoryProxy(this.jndi01AName);
	}

	@Bean
	public TransactionAwareConnectionFactoryProxy jndi01BCachingConnectionFactoryProxy() {
		return jndiCachingConnectionFactoryProxy(this.jndi01BName);
	}

	@Bean
	public TransactionAwareConnectionFactoryProxy jndi02ACachingConnectionFactoryProxy() {
		return jndiCachingConnectionFactoryProxy(this.jndi02AName);
	}

	@Bean
	public TransactionAwareConnectionFactoryProxy jndi02BCachingConnectionFactoryProxy() {
		return jndiCachingConnectionFactoryProxy(this.jndi02BName);
	}

	private TransactionAwareConnectionFactoryProxy jndiCachingConnectionFactoryProxy(
			final String jndiName) {
		JndiObjectFactoryBean jndiFactorybean = new JndiObjectFactoryBean();
		jndiFactorybean.setJndiTemplate(jndiTemplate());
		jndiFactorybean.setJndiName(jndiName);

		try {
			jndiFactorybean.afterPropertiesSet();
		} catch (Exception e) {
			throw new BusinessProcessApplicationException(
					"Error Creating Bean jndiCachingConnectionFactory Proxy", e);
		}

		MQQueueConnectionFactory factory = (MQQueueConnectionFactory) jndiFactorybean
				.getObject();
		ConnectionFactory cf = factory;

		return new TransactionAwareConnectionFactoryProxy(cf);
	}

	@Bean
	public JmsTransactionManager jms01ATransactionManager() {
		return jmsTransactionManager(jndi01ACachingConnectionFactoryProxy());
	}

	@Bean
	public JmsTransactionManager jms02ATransactionManager() {
		return jmsTransactionManager(jndi02ACachingConnectionFactoryProxy());
	}

	@Bean
	public JmsTransactionManager jms01BTransactionManager() {
		return jmsTransactionManager(jndi01BCachingConnectionFactoryProxy());
	}

	@Bean
	public JmsTransactionManager jms02BTransactionManager() {
		return jmsTransactionManager(jndi02BCachingConnectionFactoryProxy());
	}

	private JmsTransactionManager jmsTransactionManager(
			TransactionAwareConnectionFactoryProxy proxy) {
		JmsTransactionManager manager = new JmsTransactionManager();
		manager.setConnectionFactory(proxy);
		return manager;
	}

	@Bean
	public DefaultMessageListenerContainer correlation01AQueueMessageListener() {
		return correlationQueueMessageListener(
				jndi01ACachingConnectionFactoryProxy(),
				jms01ATransactionManager());
	}

	@Bean
	public DefaultMessageListenerContainer correlation02AQueueMessageListener() {
		return correlationQueueMessageListener(
				jndi02ACachingConnectionFactoryProxy(),
				jms02ATransactionManager());
	}

	@Bean
	public DefaultMessageListenerContainer correlation01BQueueMessageListener() {
		return correlationQueueMessageListener(
				jndi01BCachingConnectionFactoryProxy(),
				jms01BTransactionManager());
	}

	@Bean
	public DefaultMessageListenerContainer correlation02BQueueMessageListener() {
		return correlationQueueMessageListener(
				jndi02BCachingConnectionFactoryProxy(),
				jms02BTransactionManager());
	}

	@Bean
	public DefaultMessageListenerContainer request01AQueueMessageListener() {
		return requestQueueMessageListener(
				jndi01ACachingConnectionFactoryProxy(),
				jms01ATransactionManager());
	}

	@Bean
	public DefaultMessageListenerContainer request02AQueueMessageListener() {
		return requestQueueMessageListener(
				jndi02ACachingConnectionFactoryProxy(),
				jms02ATransactionManager());
	}

	@Bean
	public DefaultMessageListenerContainer request01BQueueMessageListener() {
		return requestQueueMessageListener(
				jndi01BCachingConnectionFactoryProxy(),
				jms01BTransactionManager());
	}

	@Bean
	public DefaultMessageListenerContainer request02BQueueMessageListener() {
		return requestQueueMessageListener(
				jndi02BCachingConnectionFactoryProxy(),
				jms02BTransactionManager());
	}

	private DefaultMessageListenerContainer requestQueueMessageListener(
			TransactionAwareConnectionFactoryProxy proxy,
			JmsTransactionManager jmsTransactionManager) {
		DefaultMessageListenerContainer defaultMessageListenerContainer = new DebugJMSMessageListener();

		defaultMessageListenerContainer.setConnectionFactory(proxy);
		defaultMessageListenerContainer
				.setDestinationName(this.requestQueueName);
		defaultMessageListenerContainer
				.setMessageListener(requestQueueMessageReceiver());
		defaultMessageListenerContainer.setSessionTransacted(true);
		defaultMessageListenerContainer.setConcurrentConsumers(Integer
				.parseInt(this.requestQueueConsumers));
		defaultMessageListenerContainer.setMaxConcurrentConsumers(Integer
				.parseInt(this.requestQueueConsumers));
		defaultMessageListenerContainer.setReceiveTimeout(Integer
				.parseInt(this.requestQueueTimeOut));
		defaultMessageListenerContainer
				.setTransactionManager(jmsTransactionManager);

		defaultMessageListenerContainer.setAutoStartup(false);
		return defaultMessageListenerContainer;
	}

	@Bean
	public CorrelationUUIDGenerator correlationUUIDGenerator() {
		return new CorrelationUUIDGenerator();
	}

	@Bean
	public MessageListenerAdapter correlationQueueMessageReceiver() {
		MessageListenerAdapter listenerAdapter = new MessageListenerAdapter(
				correlationQueueListener());
		return listenerAdapter;
	}

	@Bean
	public MessageListenerAdapter requestQueueMessageReceiver() {
		MessageListenerAdapter listenerAdapter = new MessageListenerAdapter(
				requestQueueListener());
		return listenerAdapter;
	}

	/**
	 * This is needed to make property resolving work on annotations ... (see
	 * http
	 * ://stackoverflow.com/questions/11925952/custom-spring-property-source-
	 * does-not-resolve-placeholders-in-value)
	 *
	 */
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	@Bean
	public Properties properties() {

		Properties javaMailProperties = new Properties();

		javaMailProperties.put(Constants.KEY_IMAP_SOCKETFACTORY_CLASS,
				Constants.SOCKET_FACTORY);
		javaMailProperties.put(Constants.KEY_IMAP_SOCKETFACTORY_FALLBACK,
				Constants.SOCKET_FACTORY_FALLBACK);
		javaMailProperties.put(Constants.KEY_IMAP_PROTOCOL,
				Constants.EMAIL_PROTOCOL_IMAP);
		javaMailProperties.put(Constants.KEY_IMAP_DEBUG, true);
		javaMailProperties.put(Constants.KEY_IMAP_SMTP_AUTH, false);
		javaMailProperties.put(Constants.KEY_IMAP_SMTP_PORT, this.smtpPort);

		return javaMailProperties;
	}

	@Bean()
	public DirectChannel emailChannel() {
		return new DirectChannel();
	}

	@Bean
	public MailReceiver mailReceiver() {
		// url -
		// imaps://mailid:pwd@outlook-CHA.ad.tiaa-cref.ORG:993/inbox
		StringBuilder url = new StringBuilder();
		url.append(Constants.EMAIL_PROTOCOL_IMAP).append(Constants.COLON)
				.append(Constants.DOUBLESLASH)
				.append(this.emailId)
				.append(Constants.COLON)
				.append(CryptUtility.decrypt(this.emailPwd))
				// .append(Constants.COLON).append(this.emailPwd)
				.append(Constants.KEY_AT).append(this.emailAccount)
				.append(Constants.COLON).append(this.emailAccountPort)
				.append(Constants.SLASH).append(Constants.FOLDER_INBOX);
		LOGGER.info("Starting MailReceiver " + System.currentTimeMillis());
		ImapMailReceiver imapMailReceiver = new ImapMailReceiver(url.toString());
		imapMailReceiver.setJavaMailProperties(properties());
		imapMailReceiver.setShouldDeleteMessages(false);
		imapMailReceiver.setShouldMarkMessagesAsRead(true);
		LOGGER.info("MailReceiver started " + System.currentTimeMillis());
		return imapMailReceiver;
	}

	@Bean
	@org.springframework.integration.annotation.Transformer(inputChannel = "emailChannel", outputChannel = "emailChannel")
	public Transformer transformer() {
		return new MailToStringTransformer();
	}

	@Bean
	@InboundChannelAdapter(value = "emailChannel", poller = @Poller(fixedDelay = "${mail.poller.delay}"), autoStartup = "${mail.imap.reciever.enabled}")
	// If used this, it polls at the given interval only, it wont read any new
	// messages as soon as they come in.
	public MessageSource<Object> mailMessageSource() {
		MailReceivingMessageSource mailReceivingMessageSource = new MailReceivingMessageSource(
				this.mailReceiver());
		return mailReceivingMessageSource;
	}

	@Bean
	public QueueListener requestCTHQueueListener() {
		QueueListener cthQueueListener = new QueueListener();
		cthQueueListener.setType(Constants.CTH_REQUEST_QUEUE_EVENT);
		return cthQueueListener;
	}

	@Bean
	public DefaultMessageListenerContainer requestCTH01AQueueMessageListener() {
		return requestCTHMessageListener(
				jndi01ACachingConnectionFactoryProxy(),
				jms01ATransactionManager());
	}

	@Bean
	public DefaultMessageListenerContainer requestCTH01BQueueMessageListener() {
		return requestCTHMessageListener(
				jndi01BCachingConnectionFactoryProxy(),
				jms01BTransactionManager());
	}

	@Bean
	public DefaultMessageListenerContainer requestCTH02AQueueMessageListener() {
		return requestCTHMessageListener(
				jndi02ACachingConnectionFactoryProxy(),
				jms02ATransactionManager());
	}

	@Bean
	public DefaultMessageListenerContainer requestCTH02BQueueMessageListener() {
		return requestCTHMessageListener(
				jndi02BCachingConnectionFactoryProxy(),
				jms02BTransactionManager());
	}

	@Bean
	public MessageListenerAdapter cthQueueMessageReceiver() {
		MessageListenerAdapter listenerAdapter = new MessageListenerAdapter(
				requestCTHQueueListener());
		return listenerAdapter;
	}

	private DefaultMessageListenerContainer requestCTHMessageListener(
			TransactionAwareConnectionFactoryProxy proxy,
			JmsTransactionManager jmsTransactionManager) {
		DefaultMessageListenerContainer defaultMessageListenerContainer = new DebugJMSMessageListener();

		defaultMessageListenerContainer.setConnectionFactory(proxy);
		defaultMessageListenerContainer
				.setDestinationName(this.requestCTHQueueName);
		defaultMessageListenerContainer
				.setMessageListener(cthQueueMessageReceiver());
		defaultMessageListenerContainer.setSessionTransacted(true);
		defaultMessageListenerContainer.setConcurrentConsumers(Integer
				.parseInt(this.requestCTHQueueConsumers));
		defaultMessageListenerContainer.setMaxConcurrentConsumers(Integer
				.parseInt(this.requestCTHQueueConsumers));
		defaultMessageListenerContainer.setReceiveTimeout(Integer
				.parseInt(this.requestCTHQueueTimeOut));
		defaultMessageListenerContainer
				.setTransactionManager(jmsTransactionManager);

		defaultMessageListenerContainer.setAutoStartup(false);
		return defaultMessageListenerContainer;
	}

	private DefaultMessageListenerContainer correlationQueueMessageListener(
			TransactionAwareConnectionFactoryProxy proxy,
			JmsTransactionManager jmsTransactionManager) {
		DefaultMessageListenerContainer defaultMessageListenerContainer = new DebugJMSMessageListener();

		defaultMessageListenerContainer.setConnectionFactory(proxy);
		defaultMessageListenerContainer
				.setDestinationName(this.correlationQueueName);
		defaultMessageListenerContainer
				.setMessageListener(correlationQueueMessageReceiver());
		defaultMessageListenerContainer.setSessionTransacted(true);
		defaultMessageListenerContainer.setConcurrentConsumers(Integer
				.parseInt(this.correlationQueueConsumers));
		defaultMessageListenerContainer.setMaxConcurrentConsumers(Integer
				.parseInt(this.correlationQueueConsumers));
		defaultMessageListenerContainer.setReceiveTimeout(Integer
				.parseInt(this.correlationQueueTimeOut));
		defaultMessageListenerContainer
				.setTransactionManager(jmsTransactionManager);

		defaultMessageListenerContainer.setAutoStartup(false);
		return defaultMessageListenerContainer;
	}

	@Bean
	public MultipartResolver multipartResolver() {
		CommonsMultipartResolver multipart = new CommonsMultipartResolver();
		multipart.setMaxUploadSize(MAX_FILEUPLOAD_SIZE);
		return multipart;
	}
	
	@Bean
	public RestTemplate restTemplate() {
		LOGGER.info("Creating Rest Client for FDRS Service.");
		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setErrorHandler(new RestResponseErrorHandler());
		
		return restTemplate;
	}

}
