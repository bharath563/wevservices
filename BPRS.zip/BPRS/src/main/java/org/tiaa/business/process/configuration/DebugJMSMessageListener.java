package org.tiaa.business.process.configuration;

import org.springframework.jms.listener.DefaultMessageListenerContainer;

public class DebugJMSMessageListener extends DefaultMessageListenerContainer {

	@Override
	protected void handleListenerSetupFailure(Throwable ex,
			boolean alreadyRecovered) {
		this.logger.error(
				"***************Error Listening to queue.Printing extra logs.",
				ex);
		super.handleListenerSetupFailure(ex, alreadyRecovered);

	}
}
