package org.tiaa.business.process.configuration;

import java.util.List;

import org.w3c.dom.Element;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlCData;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;

public abstract class Mixin {
	@JacksonXmlCData
	@JacksonXmlText
	List<Element> any;
}
