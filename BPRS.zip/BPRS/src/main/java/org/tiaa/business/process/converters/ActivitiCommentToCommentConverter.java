package org.tiaa.business.process.converters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.util.SerializerUtil;
import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComment;

/**
 * Converter class to convert Activiti Comment to Object Model Comment
 * 
 * @author subashr
 *
 */
@Component
public class ActivitiCommentToCommentConverter implements
		Converter<ActivitiComment, Comment> {

	@Autowired
	SerializerUtil serializerUtil;

	@Override
	public Comment convert(ActivitiComment source) {

		if (source == null) {
			return null;
		}

		Comment pvmComment = this.serializerUtil.deSerialize(
				source.getMessage(), Comment.class);

		pvmComment.setCreateDate(source.getCreateDate());
		pvmComment.setCreateTime(source.getCreateDate());
		pvmComment.setProcessId(source.getProcessInstanceId());
		pvmComment.setId(source.getTaskId());

		if (source.getCreatedBy() != null) {
			pvmComment.setCreateOper(source.getCreatedBy().getUserId());
		}

		return pvmComment;
	}
}
