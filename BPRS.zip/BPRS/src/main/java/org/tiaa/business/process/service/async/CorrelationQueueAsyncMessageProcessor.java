package org.tiaa.business.process.service.async;

import static org.tiaa.business.process.util.Constants.*;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.wrapper.ProcessService;
import org.tiaa.business.process.util.UserUtil;
import org.tiaa.business.process.util.ValidatorUtil;
import org.tiaa.business.process.util.XMLUtil;
import org.tiaa.business.process.uuid.CorrelationUUIDGenerator;
import org.tiaa.esb.case_management_rs_v2_0.types.Signal;

@Component
public class CorrelationQueueAsyncMessageProcessor implements
		AsyncMessageProcessor {

	private static final Logger LOGGER = Logger
			.getLogger(CorrelationQueueAsyncMessageProcessor.class);

	@Autowired
	@Lazy
	ProcessService processService;

	@Autowired
	@Lazy
	XMLUtil xmlUtil;

	@Autowired
	@Lazy
	ValidatorUtil validatorUtil;

	@Autowired
	@Lazy
	UserUtil userUtil;

	@Value("${queue.activiti.userName}")
	private String queueuActivitiUserName;

	@Override
	public void processMessage(String data) {
		Signal signalRequest = this.xmlUtil.unMarshall(data, Signal.class);

		this.validatorUtil.validate(signalRequest);

		if (signalRequest.getCorrelationId() != null) {

			LOGGER.info("Processing Correlation Queue Message to Signal based on CorrelationId. ");
			this.processService.signalTask(signalRequest,
					this.queueuActivitiUserName,
					this.userUtil.generateWrapperBasicAuth());
		} else {
			LOGGER.info("Processing Correlation Queue Message to Signal based on Message Name. ");
			this.processService.signalMessage(signalRequest,
					this.queueuActivitiUserName,
					this.userUtil.generateWrapperBasicAuth());
		}

	}

	@Override
	public boolean isEventTypeProcessable(String eventType) {
		return CORRELATION_QUEUE_EVENT.equalsIgnoreCase(eventType);
	}

	@Override
	public String getMessageMetaData(String data) {
		Signal signalRequest = this.xmlUtil.unMarshall(data, Signal.class);
		String metaData = "";
		if (signalRequest.getCorrelationId() != null) {
			metaData = "ProcessInstance:"
					+ new CorrelationUUIDGenerator()
			.decodeCorrelationID(signalRequest
					.getCorrelationId())[0];
		}
		return metaData;
	}
}
