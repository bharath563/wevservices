package org.tiaa.business.process.converters;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.elasticsearch.common.lang3.StringUtils;

import org.apache.log4j.Logger;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.exception.BusinessProcessApplicationException;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.List;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.NameValue;

/**
 * Converter class to convert Activiti Variable to Object Model NameValue
 *
 * @author subashr
 *
 */
@Component
public class ActivitiVariableToNameValueConverter implements
Converter<ActivitiVariable, NameValue> {

	private static final Logger LOGGER = Logger.getLogger(ActivitiVariableToNameValueConverter.class);

	@Override
	public NameValue convert(ActivitiVariable source) {

		if (source == null) {
			return null;
		}

		NameValue nvPair = new NameValue();
		nvPair.setName(source.getName());
		nvPair.setDesc(source.getName());

		String value = source.getValue();

		if ("Boolean".equalsIgnoreCase(source.getType())) {
			nvPair.setBooleanValue(Boolean.valueOf(value));
		}
		else if ("Date".equalsIgnoreCase(source.getType())) {
			nvPair.setDateValue(toDate(Long.parseLong(value)));
		}
		else if ("Decimal".equalsIgnoreCase(source.getType())) {
			nvPair.setDecimalValue(BigDecimal.valueOf(Double.valueOf(value)));
		}
		else if ("Integer".equalsIgnoreCase(source.getType())) {
			nvPair.setNumValue(BigInteger.valueOf(Long.parseLong(value)));
		}
		else if ("LIST".equalsIgnoreCase(source.getType())) {
			nvPair.setValueList(getListValues(source.getValue()));
		}
		else {
			nvPair.setValue(source.getValue());
		}

		return nvPair;
	}

	private List getListValues(final String value) {

		if (StringUtils.isBlank(value)) {
			return null;
		}

		List list = new List();
		list.getItem().addAll(Arrays.asList(value.split(",")));
		return list;
	}

	private XMLGregorianCalendar toDate(long time) {
		Date date = new Date(time);
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(date);
		XMLGregorianCalendar date2 = null;
		try {
			date2 = DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
		}
		catch (DatatypeConfigurationException e) {
			LOGGER.error("Error converting time to date. Message " + e.getMessage());
			throw new BusinessProcessApplicationException(e.getMessage());
		}
		return date2;
	}
}
