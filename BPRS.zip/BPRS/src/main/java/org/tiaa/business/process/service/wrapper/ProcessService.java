package org.tiaa.business.process.service.wrapper;

import static org.tiaa.business.process.util.Constants.*;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.tiaa.business.process.entities.ProcessComments;
import org.tiaa.business.process.entities.ProcessDocuments;
import org.tiaa.business.process.repository.nxtgen.CommentsRepository;
import org.tiaa.business.process.repository.nxtgen.DocumentsRepository;
import org.tiaa.business.process.service.es.ESSearchService;
import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.service.exception.NotFoundException;
import org.tiaa.business.process.util.Constants;
import org.tiaa.business.process.uuid.CorrelationUUIDGenerator;
import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.esb.case_management_common_types.types.Comments;
import org.tiaa.esb.case_management_common_types.types.Process;
import org.tiaa.esb.case_management_common_types.types.Properties;
import org.tiaa.esb.case_management_common_types.types.Task;
import org.tiaa.esb.case_management_common_types.types.Tasks;
import org.tiaa.esb.case_management_rs_v2_0.types.MessageVariable;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComments;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariables;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.CTHEvent;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.Event;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTasks;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.Signal;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Documents;

/**
 * Service implementation for Process Resource
 *
 * @author subashr
 *
 */
@Service
public class ProcessService extends BaseServiceWrapper {

	private static final Logger LOGGER = Logger.getLogger(ProcessService.class);

	@Autowired
	CorrelationUUIDGenerator correlationUUIDGenerator;

	@Autowired
	ESSearchService esSearchService;

	@Autowired
	DocumentsRepository documentsRepository;

	@Autowired
	CommentsRepository commentsRepository;

	public Process getProcessById(final String processId, final String userId,
			final String basicAuth, boolean miscDetails, boolean lock) {
		ProcessInstance processInstance = this.activitiWrapperRestClient.getProcessById(
				processId, userId, basicAuth, miscDetails, lock);

		return createProcessFromProcessInstance(processInstance, miscDetails);
	}

	public Process getProcessHistory(final String processId, final String userId,
			final String basicAuth) {

		ProcessInstance processInst = this.activitiWrapperRestClient.getProcessHistory(
				processId, userId, basicAuth);
		Process process = createProcessHistory(processInst);
		return process;
	}

	private Process createProcessHistory(ProcessInstance processInst) {

		Process process = new Process();
		Tasks tasks = new Tasks();
		if (processInst != null) {
			if ((processInst.getEvents() != null)
					&& (processInst.getEvents().getEvents() != null)) {
				LOGGER.info("No. of Historic Event for processInstance - " + processInst
						+ " are " + processInst.getEvents().getEvents().size());

				for (Event procInsEvent : processInst.getEvents().getEvents()) {
					Task task = this.conversionService.convert(procInsEvent, Task.class);
					tasks.getTask().add(task);
				}
			}
		}
		process.setProcessId(processInst.getProcessInstanceId());
		process.setTasks(tasks);
		return process;
	}

	public void updateProcess(final String processId, Properties processProperties,
			final String action, final String userId, final String basicAuth) {
		this.activitiWrapperRestClient.updateProcess(processId,
				createActivitiVariablesFromProperties(processProperties), action, userId,
				basicAuth);
	}

	public Document getProcessDocument(final String processId,
			final String documentId, final String userId, final String basicAuth) {

		Documents documents = getProcessDocuments(processId, userId, basicAuth);
		if (documents != null) {
			for (Document document : documents.getDocument()) {
				if (documentId.equalsIgnoreCase(document.getDocID())) {
					return document;
				}
			}
		}

		throw new NotFoundException("Document with id " + documentId
				+ " Not found for Process " + processId);
	}

	public Document addProcessDocument(final String processId,
			final Document document, final String userId, final String basicAuth) {

		this.activitiWrapperRestClient
				.getProcessById(processId, userId, basicAuth, false, false);
		ProcessDocuments processDocuments = this.documentsRepository
				.findByProcessInstanceId(processId);
		if (processDocuments == null) {
			processDocuments = new ProcessDocuments();
			processDocuments.setProcessInstanceId(processId);
			processDocuments.setCreateTime(new Date());
		}
		String docStr = processDocuments.getDocuments();
		Documents documents = this.serializerUtil.deSerialize(docStr, Documents.class);

		if (documents != null) {
			LOGGER.info("No. of existing documents found for ProcessId - "
					+ processId + " are " + documents.getDocument().size());
			for (Document exisDocument : documents.getDocument()) {
				if (exisDocument.getDocID().equalsIgnoreCase(document.getDocID())) {
					throw new BadRequestException("Document with ID " + document.getDocID()
							+ " already exists.");
				}
			}
		}
		else {
			documents = new Documents();
		}

		documents.getDocument().add(document);

		docStr = this.serializerUtil.serialize(documents);
		processDocuments.setDocuments(docStr);
		processDocuments.setLastUpdatedTime(new Date(System.currentTimeMillis()));
		this.documentsRepository.save(processDocuments);
		return document;
	}

	public Comments getProcessComments(String processId, String userId,
			final String basicAuth) {
		
		this.activitiWrapperRestClient
				.getProcessById(processId, userId, basicAuth, false, false);

		ProcessComments processComments = this.commentsRepository.findByProcessInstanceId(processId);

		String cStr = processComments!=null?processComments.getComments():null;
		Comments comments = this.serializerUtil.deSerialize(cStr, Comments.class);

		return comments;
	}

	public Documents getProcessDocuments(String processId, String userId,
			final String basicAuth) {
	
		this.activitiWrapperRestClient
				.getProcessById(processId, userId, basicAuth, false, false);

		ProcessDocuments docvar = this.documentsRepository.findByProcessInstanceId(processId);
		String docStr = docvar != null ? docvar.getDocuments() : null;
		Documents docs = this.serializerUtil.deSerialize(docStr, Documents.class);

		return docs;

	}

	public Comment addProcessComment(String processId, Comment comment,
			String userId, final String basicAuth) {

		this.activitiWrapperRestClient
				.getProcessById(processId, userId, basicAuth, false, false);
		createComments(processId, null, userId, comment);
		return comment;

	}

	public Process startProcess(Process process, String userId, final String basicAuth) {
		ProcessInstance processInstanceRequest = getProcessInstanceFromProcess(process);
		ProcessInstance processInstanceResponse = this.activitiWrapperRestClient
				.startProcess(processInstanceRequest, userId, basicAuth);

		return createProcessFromProcessInstance(processInstanceResponse, false);
	}

	private ProcessInstance getProcessInstanceFromProcess(final Process process) {
		ProcessInstance processInstance = new ProcessInstance();
		processInstance.setBusinessKey(process.getBusinessKey());
		processInstance.setMessageName(process.getMessageName());
		processInstance.setProcessName(process.getProcessType());
		processInstance.setVariables(new ActivitiVariables());

		if (process.getProcessProperties() != null) {
			processInstance.setVariables(createActivitiVariablesFromProperties(process
					.getProcessProperties()));
		}

		if (process.getDocuments() != null) {
			processInstance.getVariables().getVariable()
			.add(createDocumentVariable(process.getDocuments()));
		}

		if (process.getComments() != null) {
			ActivitiComments actComments = new ActivitiComments();
			for (Comment comment : process.getComments().getComment()) {
				actComments.getComment().add(createActivitiCommmentFromComment(comment));
			}
			processInstance.setComments(actComments);
		}

		return processInstance;
	}

	private ActivitiVariable createDocumentVariable(final Documents documents) {
		String serializedDocumentString = this.serializerUtil.serialize(documents);
		ActivitiVariable docVariable = new ActivitiVariable();
		docVariable.setName(DOCUMENT_VARIABLE_NAME);
		docVariable.setValue(serializedDocumentString);
		docVariable.setType("String");

		return docVariable;
	}

	public Tasks getProcessTasks(String processId, String userId, final String basicAuth) {

		ProcessTasks processTasks = this.activitiWrapperRestClient.getProcessTasks(processId,
				userId, basicAuth);

		return createTasksFromProcessTasks(processTasks);
	}

	public Process signalTask(
			final org.tiaa.esb.case_management_rs_v2_0.types.Signal request, String userId,
			final String basicAuth) {

		Signal activitiSignal = null;
		try {
			String[] decodedValues = this.correlationUUIDGenerator.decodeCorrelationID(request
					.getCorrelationId());
			activitiSignal = new Signal();
			activitiSignal.setProcessInstanceId(decodedValues[0]);
			activitiSignal.setWaitTaskId(decodedValues[1]);
			activitiSignal.setVariables(createActivitiVariablesFromProperties(request
					.getSignalProperties()));
		}
		catch (IllegalArgumentException e) {
			throw new BadRequestException("Invalid GUID", e);
		}

		ProcessInstance processInstance = this.activitiWrapperRestClient.signalProcessTask(
				activitiSignal, userId, basicAuth);
		return createProcessFromProcessInstance(processInstance, false);

	}

	public Process signalMessage(
			final org.tiaa.esb.case_management_rs_v2_0.types.Signal request, String userId,
			final String basicAuth) {

		MessageVariable variable = request.getMessageVariable();

		if ((variable == null) || StringUtils.isBlank(variable.getMessageName())
				|| StringUtils.isBlank(variable.getVariableName())
				|| StringUtils.isBlank(variable.getVariableValue())) {
			throw new BadRequestException(
					"To Signal Message Message Name, Variable Name & Variable Value should be passed!!");
		}

		List<String> processIds = this.esSearchService.getProcessMatchingVariable(
				variable.getVariableName(), variable.getVariableValue(), basicAuth,userId);

		if (processIds.size() != 1) {
			throw new BadRequestException(
					"More than 1 Process Found with Search Criteria. Variable Name "
							+ variable.getVariableName() + " Variable Value "
							+ variable.getVariableValue());
		}

		return signalMessage(processIds.get(0), variable.getMessageName(),
				request.getSignalProperties(), userId, basicAuth);
	}

	public Process signalMessage(final String processId, String messageName,
			Properties signalProperties, String userId, final String basicAuth) {

		if (StringUtils.isBlank(messageName)) {
			throw new BadRequestException("Message name cannot be NULL!!");
		}

		Signal signalMessage = new Signal();
		signalMessage.setProcessInstanceId(processId);
		signalMessage.setWaitTaskId(messageName);
		signalMessage.setVariables(createActivitiVariablesFromProperties(signalProperties));

		ProcessInstance processInstance = this.activitiWrapperRestClient.signalMessage(
				signalMessage, userId, basicAuth);
		return createProcessFromProcessInstance(processInstance, false);
	}

	public Document updateProcessDocument(final String processId, final String documentId,
			final Document document, final String userId, final String basicAuth) {

		// Document ID's in the request Document and requestURL should be the
		// same
		if ((documentId != null) && (document.getDocID() != null)
				&& !(documentId.equalsIgnoreCase(document.getDocID()))) {
			LOGGER.error("Invalid Update Request. Please send valid DocumentId");
			throw new BadRequestException(
					"Invalid Update Request. Please send valid DocumentId");
		}

		Documents documents = getProcessDocuments(processId, userId, basicAuth);
		if ((documents == null) || (documents.getDocument().isEmpty())) {
			LOGGER.info("No existing documents found for processId - " + processId);
			throw new BadRequestException(
					"No existing documents found for ProccessInstanceId - " + processId);
		}
		boolean docFound = false;
		for (Document exisDocument : documents.getDocument()) {
			if (exisDocument.getDocID().equalsIgnoreCase(documentId)) {
				BeanUtils.copyProperties(document, exisDocument);
				ActivitiVariable documentVariable = createDocumentVariable(documents);
				LOGGER.info("Updating documentVariable  :" + documentVariable.getName()
						+ "  with Value " + documentVariable.getValue());
				this.activitiWrapperRestClient.addProcessDocument(processId, documentVariable,
						userId, basicAuth);
				docFound = true;
			}
		}
		if (!docFound) {
			LOGGER.error("Document with DocId " + documentId
					+ " not found for ProccessInstanceId " + processId);
			throw new NotFoundException("Document with DocId - " + documentId
					+ " not found for ProccessInstanceId " + processId);
		}
		return document;
	}

	public Process updateCTHEvent(List<String> processIds, String messageName, String data,
			String userId, String basicAuth) {

		CTHEvent event = new CTHEvent();

		event.getProcessInstanceIds().addAll(processIds);
		event.setMessageName(messageName);

		event.setVariables(new ActivitiVariables());
		ActivitiVariable variable = new ActivitiVariable();
		variable.setName(Constants.ACT_FW_CTHEVENT_PAYLOAD);
		variable.setValue(data);
		event.getVariables().getVariable().add(variable);

		ProcessInstance processInstance = this.activitiWrapperRestClient.updateCTHEvent(
				event, userId, basicAuth);
		return createProcessFromProcessInstance(processInstance, false);

	}

}
