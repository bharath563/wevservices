package org.tiaa.business.process.wrapper.client;

import static org.tiaa.business.process.util.Constants.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.rest.template.TIAARestResponse;
import org.tiaa.business.process.rest.template.TIAARestTemplate;
import org.tiaa.business.process.service.deploy.AppProcessModel;
import org.tiaa.business.process.service.deploy.BPMNAppModel;
import org.tiaa.business.process.service.exception.BusinessProcessApplicationException;

@Component
public class ActivitiAppRestClient {

	private static final Logger LOGGER = Logger
			.getLogger(ActivitiAppRestClient.class);

	@Autowired
	@Qualifier("activitiAppWrapperClient")
	TIAARestTemplate activitiRestClient;

	@Autowired
	ObjectMapper objectMapper;

	public Long deployBPMNModel(final BPMNAppModel bpmnModel,
			final String basicAuth) {
		String url = "/process-models/import";

		if (bpmnModel.isBpmnProcessExists()) {
			url = "/models/" + bpmnModel.getBpmnProcessId() + "/newversion";
		}

		Map<String, String> headers = populateStandardHeaders(basicAuth, false);

		TIAARestResponse<String> response = this.activitiRestClient
				.postMultiPartFile(url, "file",
						bpmnModel.getBpmnFileContents(),
						bpmnModel.getBpmnFileName(), headers);

		LOGGER.info("Response StatusCode - " + response.getStatusCode()
				+ " Response Body" + response.getBody());

		if (response.getStatusCode() != 200) {
			throw new BusinessProcessApplicationException(
					"Error Importing BPMN Contents for Process "
							+ bpmnModel.getBpmnProcessIdentifier()
							+ " . Status Code: " + response.getStatusCode());
		}

		try {
			JsonNode root = this.objectMapper.readTree(response.getBody());
			return root.get("id").asLong();
		} catch (Exception e) {
			LOGGER.error("Error Parsing JSON Response.", e);
			throw new BusinessProcessApplicationException(
					"Error Parsing JSON Response.", e);
		}
	}

	public List<AppProcessModel> getAllAppsAndProcessModels(
			final String basicAuth) {
		List<AppProcessModel> appProcessModels = new ArrayList<AppProcessModel>();
		TIAARestResponse<String> response = this.activitiRestClient.get(
				"/models?filter=myApps&modelType=3&sort=modifiedDesc",
				populateStandardHeaders(basicAuth, true), String.class);

		if (response.getStatusCode() != 200) {
			throw new BusinessProcessApplicationException(
					"Get Call For App Model Failed with Status Code "
							+ response.getStatusCode());
		}

		try {
			JsonNode root = this.objectMapper.readTree(response.getBody());
			JsonNode dataNode = root.path("data");
			Iterator<JsonNode> iter = dataNode.iterator();
			while (iter.hasNext()) {
				JsonNode node = iter.next();

				AppProcessModel appProcessModel = new AppProcessModel();
				String appId = node.get("id").asText();
				String appName = node.get("name").asText();

				appProcessModel.setAppId(appId);
				appProcessModel.setAppName(appName);

				JsonNode modelsNode = node.get("appDefinition").path("models");
				Iterator<JsonNode> modelIter = modelsNode.iterator();

				while (modelIter.hasNext()) {
					JsonNode modelNode = modelIter.next();
					appProcessModel.getProcessModels().put(
							modelNode.get("name").asText(),
							modelNode.get("id").asText());
				}

				appProcessModels.add(appProcessModel);
			}
		} catch (Exception e) {
			LOGGER.error("Error Parsing JSon Response in Get Apps Call", e);
			throw new BusinessProcessApplicationException(
					"Error Parsing JSon Response in Get Apps Call", e);
		}

		return appProcessModels;
	}

	private Map<String, String> populateStandardHeaders(final String basicAuth,
			final boolean isContentTypeNeeded) {
		Map<String, String> headersMap = new HashMap<String, String>();

		if (isContentTypeNeeded) {
			headersMap.put("Content-Type", JSON_CONTENT_TYPE);
		}

		headersMap.put("Accept", JSON_CONTENT_TYPE);
		headersMap.put(BASIC_AUTH_HEADER, basicAuth);

		return headersMap;
	}

}
