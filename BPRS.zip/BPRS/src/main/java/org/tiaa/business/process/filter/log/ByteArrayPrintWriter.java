package org.tiaa.business.process.filter.log;

import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;

import javax.servlet.ServletOutputStream;

public class ByteArrayPrintWriter {
	private ByteArrayOutputStream baos = new ByteArrayOutputStream();

	private PrintWriter pw = new PrintWriter(this.baos);

	private ServletOutputStream sos = new ByteArrayServletStream(this.baos);

	public PrintWriter getWriter() {
		return this.pw;
	}

	public ServletOutputStream getStream() {
		return this.sos;
	}

	byte[] toByteArray() {
		return this.baos.toByteArray();
	}

}
