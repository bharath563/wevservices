package org.tiaa.business.process.service.async;

import static org.tiaa.business.process.util.Constants.*;

import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.service.wrapper.DocumentService;
import org.tiaa.business.process.service.wrapper.ProcessService;
import org.tiaa.business.process.util.UserUtil;
import org.tiaa.business.process.util.XMLUtil;
import org.tiaa.esb.case_management_common_types.types.Process;
import org.tiaa.esb.case_management_rs_v2_0.types.ProcessRequest;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;

@Component
public class RequestQueueAsyncMessageProcessor implements AsyncMessageProcessor {

	private static final Logger LOGGER = Logger.getLogger(RequestQueueAsyncMessageProcessor.class);

	@Autowired
	@Lazy
	ProcessService processService;

	@Autowired
	@Lazy
	XMLUtil xmlUtil;

	@Autowired
	@Lazy
	UserUtil userUtil;

	@Value("${queue.activiti.userName}")
	private String queueuActivitiUserName;

	@Autowired
	@Lazy
	DocumentService documentService;

	@Override
	public void processMessage(String data) {
		Process process = getProcess(data);

		if (process == null) {
			LOGGER.error("Process is null for RequestQueueAsyncMessageProcessor to process further.");
			throw new BadRequestException(
					"Process is null for RequestQueueAsyncMessageProcessor to process further.");
		}

		// 1. If the process has document content, then store it in Mobius and
		// send document metadata as process variable
		if (process.getDocuments() != null && process.getDocuments().getDocument() != null) {
			List<org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document> docs = process.getDocuments().getDocument();
			if (docs != null) {
				LOGGER.info("Document Size - "+docs.size());
				for (Document document : docs) {
					LOGGER.info("document  - "+document);
					if (document != null && (document.getDocContent() != null && document.getDocContent().length > 0 )) {
						LOGGER.info("Received Document Content to send to Mobius with DocName - "+document.getDocName());
						String dri = documentService.storeDocInMobius(document);
						document.setDocBizUnit(document.getDocBizUnit());
						document.setDocID(dri);
						document.setDocIDTyp("DRI");
						String mimeType = document.getMimeTyp();
						if (null != mimeType) {
							mimeType = mimeType.trim();
						}
						document.setMimeTyp(mimeType);
					}else{
						LOGGER.info("No document content found to be sent for archival to FDRS ");
					}
				}
			}
		}else{
			LOGGER.info("No Documents found to be sent to Mobius for Process - "+process.getProcessType());
		}
		this.processService.startProcess(process, this.queueuActivitiUserName,this.userUtil.generateWrapperBasicAuth());
	}

	private Process getProcess(final String data) {
		ProcessRequest request = this.xmlUtil.unMarshall(data,ProcessRequest.class);
		return request.getProcess();
	}

	@Override
	public boolean isEventTypeProcessable(String eventType) {
		return REQUEST_QUEUE_EVENT.equalsIgnoreCase(eventType);
	}

	@Override
	public String getMessageMetaData(final String data) {
		Process process = getProcess(data);
		String metaData = "";

		if (process.getProcessType() != null) {
			metaData = "ProcessKey:" + process.getProcessType();
		} else if (process.getMessageName() != null) {
			metaData = "Message:" + process.getMessageName();
		}
		return metaData;
	}
}
