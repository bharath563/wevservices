package org.tiaa.business.process.repository.nxtgen;

import org.springframework.data.repository.CrudRepository;

import org.tiaa.business.process.entities.ProcessComments;

/**
 * @author polara
 *
 */
public interface CommentsRepository extends
		CrudRepository<ProcessComments, Long> {

	ProcessComments findByProcessInstanceId(String processInstId);

	ProcessComments findByProcessInstanceIdAndTaskId(String processInstId,
			String taskId);
}
