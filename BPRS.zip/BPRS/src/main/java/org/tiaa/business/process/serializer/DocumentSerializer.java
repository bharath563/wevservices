package org.tiaa.business.process.serializer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;

import org.tiaa.business.process.util.DateUtil;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.BCCEmail;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.CCEmail;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Document;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Documents;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.EmailAttributes;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.FromEmail;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.ToEmail;

/**
 * This is a Serializer class converting from Object to Map and vice-versa for
 * Object Model Documents
 *
 * @author subashr
 *
 */
@Component
public class DocumentSerializer extends AbstractObjectSerializer<Documents> {

	public static final Logger LOGGER = Logger.getLogger(DocumentSerializer.class);

	private static final String DOC_ID = "DocId";
	private static final String DOC_NAME = "DocName";
	private static final String DOC_TYPE = "DocType";
	private static final String DOC_VERSION = "DocVrsn";
	private static final String DOC_DESC = "DocDesc";
	private static final String DOC_XTNSN = "DocXtnsn";
	private static final String DOC_DIRECTION = "DocDirection";
	private static final String DOC_CREATEDATE = "DocCreateDateTime";
	private static final String DOC_TITLE = "DocTitle";
	private static final String SENT_DTTM = "SentDTTM";
	private static final String RECVD_DTTM = "RecvdDTTM";
	private static final String DOC_ARCHIVEDATE = "DocArchiveDate";
	private static final String DOC_BIZDATE = "DocBizDate";
	private static final String MIME_TYPE = "MimeTyp";
	private static final String FRMT_TYPE = "FrmtTyp";
	private static final String DOC_BU = "DocBizUnit";
	private static final String DOC_CATEGORY = "DocCategory";
	private static final String DOC_STORSYS = "DocStorgSyst";
	private static final String DOC_STATUS = "DocSts";
	private static final String DOC_TEMPLATECODE = "DocTemplateCd";
	private static final String DOC_IDTYPE = "DocIDTyp";
	private static final String DOC_URL = "DocURL";
	private static final String EMAIL_BCC = "BccEmail";
	private static final String EMAIL_FROM = "FromEmail";
	private static final String EMAIL_TO = "ToEmail";
	private static final String EMAIL_CC = "CCEmail";
	private static final String EMAIL_CONTENT = "EmailContent";
	private static final String EMAIL_PRIORITY = "EmailPriority";
	private static final String EMAIL_SUBJECT = "EmailSubject";

	@Override
	protected List<Map<String, String>> convertObjectToMap(Documents docs) {
		List<Map<String, String>> values = new ArrayList<Map<String, String>>();

		if ((docs == null) || (docs.getDocument() == null)) {
			return values;
		}

		for (Document document : docs.getDocument()) {

			Map<String, String> mapValues = new HashMap<String, String>();
			mapValues.put(DOC_ID, document.getDocID());
			mapValues.put(DOC_NAME, document.getDocName());
			mapValues.put(DOC_TYPE, document.getDocTyp());

			if (document.getDocVrsn() != null) {
				mapValues.put(DOC_VERSION, String.valueOf(document.getDocVrsn()));
			}

			mapValues.put(DOC_DESC, document.getDocDesc());
			mapValues.put(DOC_XTNSN, document.getDocXtnsn());
			mapValues.put(DOC_DIRECTION, document.getDocDirection());
			if (document.getDocCreateDateTime() != null) {
				mapValues.put(DOC_CREATEDATE, DateUtil
						.convertDateToString(document.getDocCreateDateTime()));
			}
			mapValues.put(DOC_TITLE, document.getDocTitle());
			if (document.getSentDTTM() != null) {
				mapValues.put(SENT_DTTM,
						DateUtil.convertDateToString(document.getSentDTTM()));
			}
			if (document.getRecvdDTTM() != null) {
				mapValues.put(RECVD_DTTM,
						DateUtil.convertDateToString(document.getRecvdDTTM()));
			}
			if (document.getDocArchiveDate() != null) {
				mapValues.put(DOC_ARCHIVEDATE,
						DateUtil.convertDateToString(document.getRecvdDTTM()));
			}
			if (document.getDocBizDate() != null) {
				mapValues.put(DOC_BIZDATE,
						DateUtil.convertDateToString(document.getDocBizDate()));
			}
			mapValues.put(MIME_TYPE, document.getMimeTyp());
			mapValues.put(FRMT_TYPE, document.getFrmtTyp());
			mapValues.put(DOC_BU, document.getDocBizUnit());
			mapValues.put(DOC_CATEGORY, document.getDocCategory());
			mapValues.put(DOC_STORSYS, document.getDocStorgSyst());
			mapValues.put(DOC_STATUS, document.getDocSts());
			mapValues.put(DOC_TEMPLATECODE, document.getDocTemplateCd());
			mapValues.put(DOC_URL, document.getDocURL());

			if (document.getDocIDTyp() != null) {
				mapValues.put(DOC_IDTYPE, String.valueOf(document.getDocIDTyp()));
			}

			EmailAttributes emailAttr = document.getEmailAttributes();

			if (emailAttr != null) {

				if ((emailAttr.getBCCEmail() != null)
						&& (emailAttr.getBCCEmail().getEmail() != null)) {
					mapValues.put(EMAIL_BCC, setEmails(emailAttr.getBCCEmail()
							.getEmail()));
				}

				if ((emailAttr.getFromEmail() != null)
						&& (emailAttr.getFromEmail().getEmail() != null)) {
					mapValues.put(EMAIL_FROM, setEmails(emailAttr.getFromEmail()
							.getEmail()));
				}

				if ((emailAttr.getToEmail() != null)
						&& (emailAttr.getToEmail().getEmail() != null)) {
					mapValues.put(EMAIL_TO, setEmails(emailAttr.getToEmail()
							.getEmail()));
				}

				if ((emailAttr.getCCEmail() != null)
						&& (emailAttr.getCCEmail().getEmail() != null)) {
					mapValues.put(EMAIL_CC, setEmails(emailAttr.getCCEmail()
							.getEmail()));
				}
				mapValues.put(EMAIL_CONTENT, (String) emailAttr.getCntnt());
				mapValues.put(EMAIL_PRIORITY, emailAttr.getPri());
				mapValues.put(EMAIL_SUBJECT, emailAttr.getSubj());
			}

			values.add(mapValues);
		}

		return values;
	}

	/**
	 * This is a private method creates a comma separated email list
	 *
	 * @param emailsList
	 * @return
	 */
	private String setEmails(List<String> emailsList) {
		StringBuilder namesList = new StringBuilder();

		if (emailsList != null) {
			int i = 1;
			// create a comma separated fromEmails String and store in the map.
			for (String email : emailsList) {
				namesList.append(email);
				if (i != emailsList.size()) {
					namesList.append(",");
				}
			}
		}
		return namesList.toString();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.activiti.extension.bean.AbstractObjectSerializer#convertMapToObject
	 * (java.util.List)
	 */
	@Override
	protected Documents convertMapToObject(List<Map<String, String>> mapValues) {

		LOGGER.debug("Document Values is ::::::::" + mapValues);

		Documents docs = new Documents();

		if ((mapValues == null) || mapValues.isEmpty()) {
			return docs;
		}

		List<Document> docList = new ArrayList<Document>();

		for (Map<String, String> docMap : mapValues) {

			Document document = new Document();

			document.setDocBizDate(DateUtil.convertStringToDate(docMap
					.get(DOC_BIZDATE)));
			document.setDocCategory(docMap.get(DOC_CATEGORY));
			document.setDocStorgSyst(docMap.get(DOC_STORSYS));
			document.setDocSts(docMap.get(DOC_STATUS));
			document.setDocTemplateCd(docMap.get(DOC_TEMPLATECODE));
			document.setDocArchiveDate(DateUtil.convertStringToDate(docMap
					.get(DOC_ARCHIVEDATE)));
			document.setDocID(docMap.get(DOC_ID));
			document.setDocName(docMap.get(DOC_NAME));
			document.setDocTyp(docMap.get(DOC_TYPE));
			document.setDocDesc(docMap.get(DOC_DESC));
			document.setDocXtnsn(docMap.get(DOC_XTNSN));
			document.setDocURL(docMap.get(DOC_URL));
			document.setDocDirection(docMap.get(DOC_DIRECTION));
			document.setDocBizUnit(docMap.get(DOC_BU));

			LOGGER.info("Before createDateTime - "+docMap.get(DOC_CREATEDATE));
			document.setDocCreateDateTime(DateUtil.convertStringToDate(docMap
					.get(DOC_CREATEDATE)));
			document.setDocTitle(docMap.get(DOC_TITLE));
			document.setSentDTTM(DateUtil.convertStringToDate(docMap
					.get(SENT_DTTM)));
			document.setRecvdDTTM(DateUtil.convertStringToDate(docMap
					.get(RECVD_DTTM)));
			document.setMimeTyp(docMap.get(MIME_TYPE));
			document.setFrmtTyp(docMap.get(FRMT_TYPE));

			if (docMap.get(DOC_IDTYPE) != null) {
				document.setDocIDTyp(docMap.get(DOC_IDTYPE));
			}

			if (docMap.get(DOC_VERSION) != null) {
				document.setDocVrsn(Integer.valueOf(docMap.get(DOC_VERSION)));
			}

			// Email Attributes
			EmailAttributes emailAttr = new EmailAttributes();
			BCCEmail bcEmail = new BCCEmail();
			bcEmail.getEmail().addAll(createEmailList(docMap.get(EMAIL_BCC)));
			emailAttr.setBCCEmail(bcEmail);

			CCEmail ccemail = new CCEmail();
			ccemail.getEmail().addAll(createEmailList(docMap.get(EMAIL_CC)));
			emailAttr.setCCEmail(ccemail);

			emailAttr.setCntnt(docMap.get(EMAIL_CONTENT));

			FromEmail frmEmail = new FromEmail();
			frmEmail.getEmail().addAll(createEmailList(docMap.get(EMAIL_FROM)));
			emailAttr.setFromEmail(frmEmail);

			emailAttr.setPri(docMap.get(EMAIL_PRIORITY));
			emailAttr.setSubj(docMap.get(EMAIL_SUBJECT));

			ToEmail toEmail = new ToEmail();
			toEmail.getEmail().addAll(createEmailList(docMap.get(toEmail)));
			emailAttr.setToEmail(toEmail);
			document.setEmailAttributes(emailAttr);

			
			LOGGER.info("document createDateTime - "+document.getDocCreateDateTime());
			docList.add(document);
		}
		docs.getDocument().addAll(docList);
		return docs;
	}

	/**
	 * @param email
	 * @return
	 */
	private List<String> createEmailList(String email) {

		List<String> mails = new ArrayList<String>();
		if (email != null) {
			String[] emailsList = email.split(",");
			mails = Arrays.asList(emailsList);
		}
		return mails;
	}

}
