package org.tiaa.business.process.validator;

import org.apache.commons.lang3.StringUtils;

import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.esb.case_management_common_types.types.Comment;

/**
 *
 * @author subashr
 *
 */
@Component
public class CommentValidator implements ObjectValidator<Comment> {

	@Override
	public void validate(Comment obj) {

		if (obj == null) {
			throw new BadRequestException("Comment object cannot be NULL");
		}

		if (StringUtils.isBlank(obj.getMessage())) {
			throw new BadRequestException("Comment message cannot be NULL");
		}

		if (StringUtils.isBlank(obj.getType())) {
			throw new BadRequestException("Comment type cannot be NULL");
		}
	}
}
