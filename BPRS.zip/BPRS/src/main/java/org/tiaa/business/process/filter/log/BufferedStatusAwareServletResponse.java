package org.tiaa.business.process.filter.log;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;

public class BufferedStatusAwareServletResponse extends
HttpServletResponseWrapper {

	private int httpStatus = 200;
	ByteArrayPrintWriter pw;

	public BufferedStatusAwareServletResponse(HttpServletResponse response,
			ByteArrayPrintWriter pw) {
		super(response);
		this.pw = pw;
	}

	@Override
	public PrintWriter getWriter() {
		return this.pw.getWriter();
	}

	@Override
	public ServletOutputStream getOutputStream() {
		return this.pw.getStream();
	}

	public int getHttpStatus() {
		return this.httpStatus;
	}

	@Override
	public void sendError(int sc) throws IOException {
		this.httpStatus = sc;
		super.sendError(sc);
	}

	@Override
	public void sendError(int sc, String msg) throws IOException {
		this.httpStatus = sc;
		super.sendError(sc, msg);
	}

	@Override
	public void setStatus(int sc) {
		this.httpStatus = sc;
		super.setStatus(sc);
	}

	@Override
	public void setStatus(int sc, String sm) {
		this.httpStatus = sc;
		super.setStatus(sc, sm);
	}

}
