package org.tiaa.business.process.configuration;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.queue.listener.QueueManager;

@Component
public class ContextRegisterListener implements
ApplicationListener<ContextRefreshedEvent> {

	private static final Logger LOGGER = Logger
			.getLogger(ContextRegisterListener.class);

	@Value("${bpm.req.inbound.queue.enabled}")
	private String requestQueueuEnabled;

	@Value("${bpm.resp.inbound.queue.enabled}")
	private String correlationQueueuEnabled;
	
	@Value("${bpm.cth.req.inbound.queue.enabled}")
	private String cthQueueuEnabled;

	@Autowired
	QueueManager queueManager;

	@Value("${bpm.req.inbound.queue}")
	private String requestQueueName;

	@Value("${bpm.resp.inbound.queue}")
	private String correlationQueueName;
	
	@Value("${bpm.cth.req.inbound.queue}")
	private String requestCTHQueueName;
	

	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		if (Boolean.valueOf(this.requestQueueuEnabled)) {
			LOGGER.info("Starting Request Queueu Listeners");
			this.queueManager.manageQueue(this.requestQueueName, true);
		}

		if (Boolean.valueOf(this.correlationQueueuEnabled)) {
			LOGGER.info("Starting Response Queueu Listeners");
			this.queueManager.manageQueue(this.correlationQueueName, true);
		}
		
		if (Boolean.valueOf(this.cthQueueuEnabled)) {
			LOGGER.info("Starting CTH Queueu Listeners");
			this.queueManager.manageQueue(this.requestCTHQueueName, true);
		}
	}
}
