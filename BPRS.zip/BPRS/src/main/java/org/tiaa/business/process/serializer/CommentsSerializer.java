package org.tiaa.business.process.serializer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.esb.case_management_common_types.types.Comments;

/**
 * @author polara
 *
 */
@Component
public class CommentsSerializer extends AbstractObjectSerializer<Comments> {

	@Override
	protected List<Map<String, String>> convertObjectToMap(Comments comments) {

		List<Map<String, String>> values = new ArrayList<Map<String, String>>();
		if ((comments == null) || (comments.getComment() == null)) {
			return values;
		}

		for (Comment comment : comments.getComment()) {
			Map<String, String> mapValues = new HashMap<String, String>();
			mapValues.put("Message", comment.getMessage());
			mapValues.put("Desc", comment.getDesc());
			mapValues.put("Type", comment.getType());
			values.add(mapValues);
		}

		return values;
	}

	@Override
	protected Comments convertMapToObject(List<Map<String, String>> mapValues) {

		if ((mapValues == null) || mapValues.isEmpty()) {
			return null;
		}
		Comments comments = new Comments();
		List<Comment> commentsList = new ArrayList<Comment>();

		for (Map<String, String> commentMap : mapValues) {

			Comment obj = new Comment();
			obj.setMessage(commentMap.get("Message"));
			obj.setDesc(commentMap.get("Desc"));
			obj.setType(commentMap.get("Type"));
			commentsList.add(obj);
		}
		comments.getComment().addAll(commentsList);
		return comments;
	}

}
