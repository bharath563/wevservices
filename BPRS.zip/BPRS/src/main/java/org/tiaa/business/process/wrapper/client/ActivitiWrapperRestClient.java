package org.tiaa.business.process.wrapper.client;

import static org.tiaa.business.process.util.Constants.*;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.rest.template.TIAARestResponse;
import org.tiaa.business.process.rest.template.TIAARestTemplate;
import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.service.exception.BusinessProcessApplicationException;
import org.tiaa.business.process.service.exception.NotFoundException;
import org.tiaa.business.process.service.exception.NotPermittedException;
import org.tiaa.business.process.service.exception.UnAuthorizedException;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComment;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComments;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariables;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.AppProcessMappings;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.CTHEvent;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstances;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTask;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTasks;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.Signal;

/**
 * Rest Client class to invoke Activiti Wrapper REST API
 *
 * @author subashr
 *
 */
@Component
public class ActivitiWrapperRestClient {

	private static final Logger LOGGER = Logger.getLogger(ActivitiWrapperRestClient.class);

	private static final String PROCESS_BASE_URL = "/process/";
	private static final String TASK_BASE_URL = "/task/";
	private static final String TASK_SEARCH_BASE_URL = "/query/tasks";
	private static final String SIGNAL_BASE_URL = "/signal";
	private static final String MESSAGE_BASE_URL = "/message";
	private static final String COMMENTS = "/comments";
	private static final String UPDATE_CTH_BASE_URL = "/cthEvent";
	private static final String HISTORY_TASKS = "/history";
	private static final String PROCESS_DEFINITION_URL = "/processdefinitions/";

	@Autowired
	@Qualifier("tiaaActivitiWrapperClient")
	TIAARestTemplate activitiRestClient;

	@Autowired
	ObjectMapper objectMapper;

	public ProcessInstance getProcessById(final String processId,
			final String userId, final String basicAuth,
			final boolean miscDetails, final boolean lock) {
		String url = PROCESS_BASE_URL + processId + "?isHistoryEnabled="
				+ miscDetails + "&lock=" + lock;

		TIAARestResponse<String> response = this.activitiRestClient.get(url,
				populateStandardHeaders(userId, basicAuth), String.class);

		return parseResponse(response, ProcessInstance.class);
	}

	public void updateProcess(final String processId,
			final ActivitiVariables variables, final String action,
			final String userId, final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + "?action=" + action;

		TIAARestResponse<String> response = this.activitiRestClient.put(url,
				variables, populateStandardHeaders(userId, basicAuth),
				String.class);
		parseResponse(response, String.class);

	}

	public String ping(final String basicAuth) {
		TIAARestResponse<String> response = this.activitiRestClient
				.get("/ping", populateStandardHeaders(null, basicAuth),
						String.class);

		if (response.getStatusCode() == 401) {
			throw new UnAuthorizedException("Bad credentials");
		} else if (response.getStatusCode() != 200) {
			throw new NotFoundException("Activiti App is not running!!");
		}

		return response.getBody();
	}

	public ProcessTask updateTask(final String processId, final String taskId,
			final ActivitiVariables variables, final String userId,
			final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + TASK_BASE_URL + taskId;

		TIAARestResponse<String> response = this.activitiRestClient.put(url,
				variables, populateStandardHeaders(userId, basicAuth),
				String.class);

		return parseResponse(response, ProcessTask.class);
	}

	public ActivitiVariable addProcessDocument(final String processId,
			final ActivitiVariable docVariable, final String userId,
			final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + "/document";

		TIAARestResponse<String> response = this.activitiRestClient.post(url,
				docVariable, populateStandardHeaders(userId, basicAuth),
				String.class);

		return parseResponse(response, ActivitiVariable.class);
	}

	public ProcessInstance startProcess(final ProcessInstance processInstance,
			final String userId, final String basicAuth) {

		TIAARestResponse<String> response = this.activitiRestClient.post(
				PROCESS_BASE_URL, processInstance,
				populateStandardHeaders(userId, basicAuth), String.class);

		return parseResponse(response, ProcessInstance.class);
	}

	public ActivitiComments getProcessComments(final String processId,
			final String userId, final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + COMMENTS;
		TIAARestResponse<String> response = this.activitiRestClient.get(url,
				populateStandardHeaders(userId, basicAuth), String.class);

		return parseResponse(response, ActivitiComments.class);
	}

	public ActivitiComment addProcessComment(final String processId,
			final ActivitiComment comment, final String userId,
			final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + "/comment";
		TIAARestResponse<String> response = this.activitiRestClient.post(url,
				comment, populateStandardHeaders(userId, basicAuth),
				String.class);

		return parseResponse(response, ActivitiComment.class);
	}

	public ActivitiComment addTaskComment(final String processId,
			final String taskId, final ActivitiComment comment,
			final String userId, final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + TASK_BASE_URL + taskId
				+ "/comment";
		TIAARestResponse<String> response = this.activitiRestClient.post(url,
				comment, populateStandardHeaders(userId, basicAuth),
				String.class);

		return parseResponse(response, ActivitiComment.class);
	}

	public ProcessTasks getProcessTasks(final String processId,
			final String userId, final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + "/tasks";
		TIAARestResponse<String> response = this.activitiRestClient.get(url,
				populateStandardHeaders(userId, basicAuth), String.class);

		return parseResponse(response, ProcessTasks.class);
	}

	public ProcessInstance getProcessHistory(final String processId,
			final String userId, final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + HISTORY_TASKS;
		TIAARestResponse<String> response = this.activitiRestClient.get(url,
				populateStandardHeaders(userId, basicAuth), String.class);

		return parseResponse(response, ProcessInstance.class);
	}

	public ProcessTask getTaskById(final String processId, final String taskId,
			final String userId, final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + TASK_BASE_URL + taskId;
		TIAARestResponse<String> response = this.activitiRestClient.get(url,
				populateStandardHeaders(userId, basicAuth), String.class);

		return parseResponse(response, ProcessTask.class);
	}

	public ProcessTask claimTask(final String processId, final String taskId,
			final String userId, final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + TASK_BASE_URL + taskId
				+ "/claim";
		TIAARestResponse<String> response = this.activitiRestClient.put(url,
				null, populateStandardHeaders(userId, basicAuth), String.class);

		return parseResponse(response, ProcessTask.class);
	}

	public ProcessTask unclaimTask(final String processId, final String taskId,
			final String userId, final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + TASK_BASE_URL + taskId
				+ "/unclaim";
		TIAARestResponse<String> response = this.activitiRestClient.put(url,
				null, populateStandardHeaders(userId, basicAuth), String.class);

		return parseResponse(response, ProcessTask.class);
	}

	public ProcessTask completeTask(final String processId,
			final String taskId, final ActivitiVariables variables,
			final String userId, final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + TASK_BASE_URL + taskId
				+ "/complete";
		TIAARestResponse<String> response = this.activitiRestClient.put(url,
				variables, populateStandardHeaders(userId, basicAuth),
				String.class);

		return parseResponse(response, ProcessTask.class);
	}

	public ActivitiComments getTaskComments(final String processId,
			final String taskId, final String userId, final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + TASK_BASE_URL + taskId
				+ COMMENTS;
		TIAARestResponse<String> response = this.activitiRestClient.get(url,
				populateStandardHeaders(userId, basicAuth), String.class);

		return parseResponse(response, ActivitiComments.class);
	}

	public ProcessInstances queryProcessTasksByUserId(final String userId,
			final String type, final String basicAuth) {

		String url = TASK_SEARCH_BASE_URL
				+ (type == null ? "" : ("?type=" + type));
		TIAARestResponse<String> response = this.activitiRestClient.get(url,
				populateStandardHeaders(userId, basicAuth), String.class);

		return parseResponse(response, ProcessInstances.class);
	}

	public ProcessInstance signalProcessTask(final Signal signal,
			final String userId, final String basicAuth) {
		TIAARestResponse<String> response = this.activitiRestClient.post(
				SIGNAL_BASE_URL, signal,
				populateStandardHeaders(userId, basicAuth), String.class);

		return parseResponse(response, ProcessInstance.class);
	}

	public ProcessInstance signalMessage(final Signal signal,
			final String userId, final String basicAuth) {
		TIAARestResponse<String> response = this.activitiRestClient.post(
				MESSAGE_BASE_URL, signal,
				populateStandardHeaders(userId, basicAuth), String.class);

		return parseResponse(response, ProcessInstance.class);
	}

	public ActivitiVariable getProcessDocuments(final String processId,
			final String userId, final String basicAuth) {
		String url = PROCESS_BASE_URL + processId + "/documents";
		TIAARestResponse<String> response = this.activitiRestClient.get(url,
				populateStandardHeaders(userId, basicAuth), String.class);

		LOGGER.info("Response StatusCode - " + response.getStatusCode()
				+ " Response Body" + response.getBody());
		ActivitiVariable docVar = null;
		if (response.getBody() != null) {
			docVar = parseResponse(response, ActivitiVariable.class);
		}
		return docVar;

	}

	@SuppressWarnings("rawtypes")
	private <T> T parseResponse(final TIAARestResponse<String> response,
			Class<T> clazzz) {

		int statusCode = response.getStatusCode();
		String responseBody = response.getBody();

		// Check if statusCode is greater than 400,
		// to include Client & Server Error

		if (statusCode >= 400) {

			String errorMessage = "";

			if (responseBody.contains("\"message\"")) {
				Map errorMap = readJson(responseBody, Map.class);
				errorMessage = (String) errorMap.get("message");
			} else {
				errorMessage = responseBody;
			}

			if (statusCode == 400) {
				throw new BadRequestException(errorMessage);
			} else if (statusCode == 404) {
				throw new NotFoundException(errorMessage);
			} else if (statusCode == 401) {
				throw new UnAuthorizedException(errorMessage);
			} else if (statusCode == 409) {
				throw new NotPermittedException(errorMessage);
			} else {
				throw new BusinessProcessApplicationException(errorMessage);
			}
		}

		if (org.apache.commons.lang3.StringUtils.isBlank(responseBody)) {
			return null;
		}

		return readJson(responseBody, clazzz);
	}

	private <T> T readJson(String message, Class<T> clazzz) {

		if (message == null) {
			return null;
		}

		try {
			return this.objectMapper.readValue(message, clazzz);
		} catch (Exception e) {
			LOGGER.error("Exception while Converting JSON object. Message "
					+ e.getMessage());
			throw new BusinessProcessApplicationException(
					"Exception while Converting JSON object", e);
		}
	}

	private Map<String, String> populateStandardHeaders(final String userId,
			final String basicAuth) {
		Map<String, String> headersMap = new HashMap<String, String>();

		if (userId != null) {
			headersMap.put(TIAA_LOGGED_IN_USER_HEADER, userId);
		}
		headersMap.put("Content-Type", JSON_CONTENT_TYPE);
		headersMap.put("Accept", JSON_CONTENT_TYPE);
		headersMap.put(BASIC_AUTH_HEADER, basicAuth);

		return headersMap;
	}

	public ProcessInstance updateCTHEvent(final CTHEvent event,
			final String userId, final String basicAuth) {

		TIAARestResponse<String> response = this.activitiRestClient.put(
				UPDATE_CTH_BASE_URL, event,
				populateStandardHeaders(userId, basicAuth), String.class);

		return parseResponse(response, ProcessInstance.class);
	}

	public void updateApp(final String basicAuth,
			final AppProcessMappings appProcessMappings) {

		Map<String, String> headers = populateStandardHeaders(null, basicAuth);
		TIAARestResponse<String> response = this.activitiRestClient.post(
				"/app/deploy", appProcessMappings, headers, String.class);

		if (response.getStatusCode() != 200) {
			LOGGER.error("Mapping Process To App Failed with Status Code: "
					+ response.getStatusCode() + " . Message :"
					+ response.getBody());
			throw new BusinessProcessApplicationException(
					"Mapping Process To App Failed with Status Code: "
							+ response.getStatusCode() + " . Message :"
							+ response.getBody());
		}
	}
	
	public ProcessInstances getProcessDefinitions(final ProcessInstances processInstances,
			final String userId, final String basicAuth) {

		TIAARestResponse<String> response = this.activitiRestClient.post(PROCESS_DEFINITION_URL, processInstances,populateStandardHeaders(userId, basicAuth), String.class);
		return parseResponse(response, ProcessInstances.class);
	}
	
	
}
