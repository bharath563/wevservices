package org.tiaa.business.process.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "NXTGEN_ASYNC_MESSAGE")
public class AsyncMessage {
	@Id
	@SequenceGenerator(name = "asyncSequence", sequenceName = "NXTGEN_ASYNC_SEQUENCE", allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "asyncSequence")
	@Column(name = "MESSAGE_ID")
	private Long messageId;

	@Column(name = "MESSAGE_TYPE")
	private String messageType;

	@Column(name = "DATA")
	@Lob
	private String data;

	@Column(name = "EXCEPTION_METADATA")
	private String exceptionMetaData;

	@Column(name = "EXCEPTION_MESSAGE")
	private String exceptionMessage;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_DATE")
	private Date createDate;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_UPDATE_DATE")
	private Date lastUpdateDate;

	@Column(name = "LOCK_OWNER")
	private String lockOwner;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LOCK_TIME")
	private Date lockTime;

	@Column(name = "PROCESSED")
	private String processed;

	@Column(name = "RETRY_COUNT")
	private Integer retryCount;

	public AsyncMessage() {
		// Do nothing. Just to add support because we have arg constructor
	}

	public AsyncMessage(final String type, final String message) {
		this.processed = "N";
		this.data = message;
		this.messageType = type;
		this.retryCount = 0;
		this.createDate = new Date();
	}

	public Long getMessageId() {
		return this.messageId;
	}

	public void setMessageId(Long messageId) {
		this.messageId = messageId;
	}

	public String getMessageType() {
		return this.messageType;
	}

	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}

	public String getData() {
		return this.data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getLockOwner() {
		return this.lockOwner;
	}

	public void setLockOwner(String lockOwner) {
		this.lockOwner = lockOwner;
	}

	public Date getLockTime() {
		return this.lockTime;
	}

	public void setLockTime(Date lockTime) {
		this.lockTime = lockTime;
	}

	public String getProcessed() {
		return this.processed;
	}

	public void setProcessed(String processed) {
		this.processed = processed;
	}

	public Integer getRetryCount() {
		return this.retryCount;
	}

	public void setRetryCount(Integer retryCount) {
		this.retryCount = retryCount;
	}

	public String getExceptionMetaData() {
		return this.exceptionMetaData;
	}

	public void setExceptionMetaData(String exceptionMetaData) {
		this.exceptionMetaData = exceptionMetaData;
	}

	public String getExceptionMessage() {
		return this.exceptionMessage;
	}

	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	public Date getLastUpdateDate() {
		return this.lastUpdateDate;
	}

	public void setLastUpdateDate(Date lastUpdateDate) {
		this.lastUpdateDate = lastUpdateDate;
	}
}
