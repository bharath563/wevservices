package org.tiaa.business.process.util;

import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.exception.BusinessProcessApplicationException;

@Component
public class XMLUtil {

	private static final Logger LOGGER = Logger.getLogger(XMLUtil.class);

	@SuppressWarnings("unchecked")
	public <T> T unMarshall(final String message, Class<T> clazzz) {

		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(clazzz);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			StringReader reader = new StringReader(message);
			return (T) jaxbUnmarshaller.unmarshal(reader);
		} catch (Exception e) {
			LOGGER.error("Exception Occured during XML UnMarshalling ", e);
			throw new BusinessProcessApplicationException(
					"Exception Occured during XML UnMarshalling ", e);
		}
	}
}
