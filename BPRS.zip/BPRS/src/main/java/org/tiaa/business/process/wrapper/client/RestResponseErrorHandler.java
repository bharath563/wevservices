package org.tiaa.business.process.wrapper.client;

import java.io.IOException;

import org.apache.log4j.Logger;

import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.DefaultResponseErrorHandler;

/**
 *
 * Overriding Default Error Handler to just log the message and not throw any
 * error
 *
 * @author subashr
 *
 */
public class RestResponseErrorHandler extends DefaultResponseErrorHandler {

	private static final Logger LOGGER = Logger
			.getLogger(RestResponseErrorHandler.class);

	@Override
	public void handleError(ClientHttpResponse response) throws IOException {
		LOGGER.error("Rest Response error: " + response.getStatusCode()
				+ " Message:" + response.getStatusText());
	}

}
