package org.tiaa.business.process.service.exception;

/**
 * Base Exception class for BPRS1. Extends RuntimeException
 * 
 * @author subashr
 *
 */
public class BusinessProcessBaseException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public BusinessProcessBaseException(String message, Throwable cause) {
		super(message, cause);
	}

	public BusinessProcessBaseException(String message) {
		super(message);
	}
}
