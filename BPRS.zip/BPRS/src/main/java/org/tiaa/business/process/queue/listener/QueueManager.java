package org.tiaa.business.process.queue.listener;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.exception.NotFoundException;

@Component
public class QueueManager {

	public static final Logger LOGGER = Logger.getLogger(QueueManager.class);

	@Autowired
	@Qualifier("request01AQueueMessageListener")
	DefaultMessageListenerContainer request01AQueueMessageListener;

	@Autowired
	@Qualifier("request01BQueueMessageListener")
	DefaultMessageListenerContainer request01BQueueMessageListener;

	@Autowired
	@Qualifier("request02AQueueMessageListener")
	DefaultMessageListenerContainer request02AQueueMessageListener;

	@Autowired
	@Qualifier("request02BQueueMessageListener")
	DefaultMessageListenerContainer request02BQueueMessageListener;

	@Autowired
	@Qualifier("correlation01AQueueMessageListener")
	DefaultMessageListenerContainer correlation01AQueueMessageListener;

	@Autowired
	@Qualifier("correlation01BQueueMessageListener")
	DefaultMessageListenerContainer correlation01BQueueMessageListener;

	@Autowired
	@Qualifier("correlation02AQueueMessageListener")
	DefaultMessageListenerContainer correlation02AQueueMessageListener;

	@Autowired
	@Qualifier("correlation02BQueueMessageListener")
	DefaultMessageListenerContainer correlation02BQueueMessageListener;
	
	@Autowired
	@Qualifier("requestCTH01AQueueMessageListener")
	DefaultMessageListenerContainer requestCTH01AQueueMessageListener;
	
	@Autowired
	@Qualifier("requestCTH01BQueueMessageListener")
	DefaultMessageListenerContainer requestCTH01BQueueMessageListener;
	
	@Autowired
	@Qualifier("requestCTH02AQueueMessageListener")
	DefaultMessageListenerContainer requestCTH02AQueueMessageListener;
	
	@Autowired
	@Qualifier("requestCTH02BQueueMessageListener")
	DefaultMessageListenerContainer requestCTH02BQueueMessageListener;
	

	@Value("${bpm.req.inbound.queue}")
	private String requestQueueName;

	@Value("${bpm.resp.inbound.queue}")
	private String correlationQueueName;
	
	@Value("${bpm.cth.req.inbound.queue}")
	private String requestCTHQueueName;

	public String manageQueue(final String queueName, boolean start) {

		LOGGER.info("Queue Manager: " + (start ? "Starting" : "Stopping")	+ " Queue " + queueName);

		if (this.requestQueueName.equalsIgnoreCase(queueName)) {
			doOperation(this.request01AQueueMessageListener,
					this.request01BQueueMessageListener,
					this.request02AQueueMessageListener,
					this.request02BQueueMessageListener,
					start);
		} else if (this.correlationQueueName.equalsIgnoreCase(queueName)) {
			doOperation(this.correlation01AQueueMessageListener,
					this.correlation01BQueueMessageListener,
					this.correlation02AQueueMessageListener,
					this.correlation02BQueueMessageListener,
					start);
		} 
		else if (this.requestCTHQueueName.equalsIgnoreCase(queueName)) {
			doOperation(this.requestCTH01AQueueMessageListener,
					this.requestCTH01BQueueMessageListener,
					this.requestCTH02AQueueMessageListener,
					this.requestCTH02BQueueMessageListener,
					start);
		}else {
			throw new NotFoundException("Queue Name " + queueName
					+ " Not Found.");
		}

		return getQueueStatus();
	}

	private void doOperation(DefaultMessageListenerContainer o1,
			DefaultMessageListenerContainer o2,
			DefaultMessageListenerContainer o3,
			DefaultMessageListenerContainer o4,
			boolean isStart) {

		if (isStart) {
			if (!o1.isRunning()) {
				o1.start();
			}
			if (!o2.isRunning()) {
				o2.start();
			}
			if (!o3.isRunning()) {
				o3.start();
			}
			if (!o4.isRunning()) {
				o4.start();
			}
		} else {
			if (o1.isRunning()) {
				o1.stop();
			}
			if (o2.isRunning()) {
				o2.stop();
			}
			if (o3.isRunning()) {
				o3.stop();
			}
			if (o4.isRunning()) {
				o4.stop();
			}
		}
	}

	public String getQueueStatus() {
		StringBuilder builder = new StringBuilder("{");
		builder.append("\"request01AQueueMessageListener\":"
				+ getStatus(this.request01AQueueMessageListener) + ",");
		builder.append("\"request01BQueueMessageListener\":"
				+ getStatus(this.request01BQueueMessageListener) + ",");
		builder.append("\"request02AQueueMessageListener\":"
				+ getStatus(this.request02AQueueMessageListener) + ",");
		builder.append("\"request02BQueueMessageListener\":"
				+ getStatus(this.request02BQueueMessageListener) + ",");

		builder.append("\"correlation01AQueueMessageListener\":"
				+ getStatus(this.correlation01AQueueMessageListener) + ",");
		builder.append("\"correlation01BQueueMessageListener\":"
				+ getStatus(this.correlation01BQueueMessageListener) + ",");
		builder.append("\"correlation02AQueueMessageListener\":"
				+ getStatus(this.correlation02AQueueMessageListener) + ",");
		builder.append("\"correlation02BQueueMessageListener\":"
				+ getStatus(this.correlation02BQueueMessageListener) + ",");
		builder.append("\"requestCTH01AQueueMessageListener\":"
				+ getStatus(this.requestCTH01AQueueMessageListener) + ",");
		builder.append("\"requestCTH01BQueueMessageListener\":"
				+ getStatus(this.requestCTH01BQueueMessageListener) + ",");
		builder.append("\"requestCTH02AQueueMessageListener\":"
				+ getStatus(this.requestCTH02AQueueMessageListener) + ",");
		builder.append("\"requestCTH02BQueueMessageListener\":"
				+ getStatus(this.requestCTH02BQueueMessageListener) + "}");

		return builder.toString();
	}

	private String getStatus(DefaultMessageListenerContainer obj) {
		return obj.isRunning() ? "\"running\"" : "\"not-started\"";
	}
}