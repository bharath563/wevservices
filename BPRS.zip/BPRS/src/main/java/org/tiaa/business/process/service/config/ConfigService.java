package org.tiaa.business.process.service.config;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.bean.BusinessArea;
import org.tiaa.business.process.bean.SearchIdentifier;
import org.tiaa.business.process.service.exception.NotFoundException;
import org.tiaa.business.process.util.Constants;
import org.tiaa.business.process.wrapper.client.ActivitiWrapperRestClient;
import org.tiaa.esb.case_management_common_types.types.ConfigData;
import org.tiaa.esb.case_management_common_types.types.ConfigItem;
import org.tiaa.esb.case_management_common_types.types.ConfigItems;
import org.tiaa.esb.case_management_common_types.types.SubField;
import org.tiaa.esb.case_management_common_types.types.SubFields;

/**
 * This is a Service class for all the config operations
 * @author pamdama
 *
 */
@Component
public class ConfigService {
	
	private static final Logger LOGGER = Logger.getLogger(ConfigService.class);
	
	@Autowired
	public ActivitiWrapperRestClient activitiWrapperRestClient;

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	private static final String GET_BUSINESSAREA_SQL = "SELECT BA_NAME,BA_LNG_NAME FROM NXTGENAPP.CMF_PM_BUSINESSAREA WHERE ACTIVE = 'Y' AND ( SOLUTION_ID IS NULL OR SOLUTION_ID != 3280)";

	private static final String GET_SEARCH_IDETIFIERS_SQL = "select i.idcode as ShortDescription, i.iddesc as LongDescription, f.fldnbr as FieldNumber,"
			+ "f.flddesc as FieldDescription, f.fldsize as FieldSize, f.ENTRYREQ as FieldEntryType, "
			+ "Case      when f.FLDTYPE=1 then 'Alphabetic' "
			+ "when f.FLDTYPE=2 then 'Alphanumeric' "
			+ "when f.FLDTYPE=3 then 'Numeric'  "
			+ "when f.FLDTYPE=4 then 'Catalogued' "
			+ "when f.FLDTYPE=5 then 'Date' "
			+ "when f.FLDTYPE=6 then 'Dropdown' END as FLDTYPE,  "
			+ "f.REQ as FieldRequired from NXTGENAPP.CMF_NXTGEN_IDTYPE i, NXTGENAPP.CMF_NXTGEN_IDFIELD f "
			+ "where i.active = 'Y' and f.idcode = i.idcode AND ( i.SOLUTION_ID IS NULL OR i.SOLUTION_ID != 3280) order by i.idcode,f.fldnbr";

	private static final String GET_ADDITIONAL_IDETIFIERS_SQL = "select adi.IDNAME as name from NXTGENAPP.CMF_NXTGEN_IDTYPE idtype, NXTGENAPP.CMF_NXTGEN_IDFIELD_ADDITIDENT adi where idtype.active = 'Y' and idtype.idcode = adi.idcode and UPPER(idtype.IDDESC)=:searchIdentifier order by adi.idcode";
	
	
	
	/**
	 * This method returns all the businessAreas
	 * 
	 * @return ConfigItems
	 */
	public ConfigItems getBusinessAreas(final String basicAuth) {

		// Validate if the user has access to this system. This is done by
		// calling Wrapper Ping service. Since ping doesn't do any process level
		// checks this will be a faster alternative rather than implementing any
		// authentication checks.
		this.activitiWrapperRestClient.ping(basicAuth);

		// 1. Get the BusinessArea from the database
		List<BusinessArea> busAreas = this.jdbcTemplate.query(
				GET_BUSINESSAREA_SQL, new RowMapper<BusinessArea>() {

					@Override
					public BusinessArea mapRow(ResultSet rs, int rowNum)
							throws SQLException {

						BusinessArea busiArea = new BusinessArea();
						busiArea.setBaName(rs.getString("BA_NAME"));
						busiArea.setBaLongName(rs.getString("BA_LNG_NAME"));
						return busiArea;
					}
				});

		if (busAreas == null || busAreas.size() == 0) {
			throw new NotFoundException("No BusinessAreas found");
		} else {
			LOGGER.info("List of BusinessAreas - " + busAreas.size());
		}

		ConfigItems cfItems = new ConfigItems();
		ConfigItem cfItem = new ConfigItem();
		cfItem.setItemName(Constants.ITEM_BA_DESCRIPTION);

		for (BusinessArea busiArea : busAreas) {
			ConfigData cfData = new ConfigData();
			cfData.setShortDescription(busiArea.getBaName());
			cfData.setLongDescription(busiArea.getBaLongName());
			cfItem.getDataPair().add(cfData);
		}

		cfItems.getConfigItem().add(cfItem);
		LOGGER.info("List of BusinessArea ConfigItems - "
				+ cfItems.getConfigItem().size());
		return cfItems;

	}

	/**
	 * This method returns all the additional SearchIdentifiers for a given
	 * identifier
	 * 
	 * @return ConfigItems
	 */
	public ConfigItems getSearchIdentifiers(final String basicAuth) {

		// Validate if the user has access to this system. This is done by
		// calling Wrapper Ping service. Since ping doesn't do any process level
		// checks this will be a faster alternative rather than implementing any
		// authentication checks.
		this.activitiWrapperRestClient.ping(basicAuth);

		List<SearchIdentifier> srchIdenfs = this.jdbcTemplate.query(
				GET_SEARCH_IDETIFIERS_SQL, new RowMapper<SearchIdentifier>() {

					@Override
					public SearchIdentifier mapRow(ResultSet rs, int rowNum)
							throws SQLException {

						SearchIdentifier srchIdent = new SearchIdentifier();
						srchIdent.setShortDescription(rs
								.getString("ShortDescription"));
						srchIdent.setLongDescription(rs
								.getString("LongDescription"));
						srchIdent.setFieldNumber(rs.getString("FieldNumber"));
						srchIdent.setFieldName(rs.getString("FieldDescription"));
						srchIdent.setFieldSize(rs.getString("FieldSize"));
						srchIdent.setFieldType(rs.getString("FLDTYPE"));
						srchIdent.setFieldEntryType(rs
								.getString("FieldEntryType"));
						srchIdent.setFieldRequired(rs
								.getString("FieldRequired"));

						return srchIdent;
					}
				});

		if (srchIdenfs == null || srchIdenfs.size() == 0) {
			throw new NotFoundException("No SearchIdentifiers found");
		}

		ConfigItems cfItems = new ConfigItems();
		ConfigItem cfItem = new ConfigItem();
		cfItem.setItemName(Constants.ITEM_IDENFITIFER_DESCRIPTION);

		for (SearchIdentifier srchIden : srchIdenfs) {
			ConfigData cfData = new ConfigData();
			// TODO: do we need anyother params??
			cfData.setShortDescription(srchIden.getShortDescription());
			cfData.setLongDescription(srchIden.getLongDescription());

			SubField subFld = new SubField();
			SubFields subflds = new SubFields();

			subFld.setFieldNumber(Integer.valueOf(srchIden.getFieldNumber()));
			subFld.setFieldName(srchIden.getFieldName());
			subFld.setFieldSize(Integer.valueOf(srchIden.getFieldSize()));
			subFld.setFieldType(srchIden.getFieldType());
			subFld.setFieldEntryType(srchIden.getFieldEntryType());
			subFld.setFieldRequired(srchIden.getFieldRequired());

			subflds.getSubField().add(subFld);
			cfData.setSubFields(subflds);
			cfItem.getDataPair().add(cfData);
		}

		cfItems.getConfigItem().add(cfItem);
		return cfItems;
	}

	/**
	 * This method returns all the SearchIdentifiers
	 * 
	 * @return ConfigItems
	 */
	public ConfigItems getSearchAdditionalIdentifiers(final String basicAuth,
			String searchIdentifier) {

		// Validate if the user has access to this system. This is done by
		// calling Wrapper Ping service. Since ping doesn't do any process level
		// checks this will be a faster alternative rather than implementing any
		// authentication checks.
		this.activitiWrapperRestClient.ping(basicAuth);

		List<SearchIdentifier> srchIdenfs = this.jdbcTemplate.query(GET_ADDITIONAL_IDETIFIERS_SQL,new Object[] { searchIdentifier },
				new RowMapper<SearchIdentifier>() {

					@Override
					public SearchIdentifier mapRow(ResultSet rs, int rowNum)
							throws SQLException {
						SearchIdentifier srchIdent = new SearchIdentifier();
						srchIdent.setLongDescription(rs.getString("name"));
						return srchIdent;
					}
				});

		if (srchIdenfs == null || srchIdenfs.size() == 0) {
			throw new NotFoundException(
					"No Additional SearchIdentifiers found for - "
							+ searchIdentifier);
		}

		ConfigItems cfItems = new ConfigItems();
		ConfigItem cfItem = new ConfigItem();
		cfItem.setItemName(searchIdentifier.toUpperCase());

		for (SearchIdentifier srchIden : srchIdenfs) {
			ConfigData cfData = new ConfigData();
			// TODO: do we need anyother params??
			cfData.setLongDescription(srchIden.getLongDescription());
			cfItem.getDataPair().add(cfData);
		}

		cfItems.getConfigItem().add(cfItem);
		return cfItems;

	}


}
