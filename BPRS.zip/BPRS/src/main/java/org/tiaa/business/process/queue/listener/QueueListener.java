package org.tiaa.business.process.queue.listener;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.wrapper.AsyncService;

/**
 * Request Queue Listener
 *
 * @author subashr
 *
 */
@Component
public class QueueListener {
	private static final Logger LOGGER = Logger.getLogger(QueueListener.class);

	private String type;

	@Autowired
	AsyncService asyncService;

	public void handleMessage(Object message) {
		try {
			LOGGER.info("Received Message in " + this.type + " Queue:"	+ message + ". Type " + this.type);
			this.asyncService.addAsyncMessage(this.type,String.valueOf(message));
		} catch (Exception e) {
			LOGGER.error("Error consuming request message:" + message+ " . Reason :" + e.getMessage(), e);
		}
	}

	public void setType(String type) {
		this.type = type;
	}
}
