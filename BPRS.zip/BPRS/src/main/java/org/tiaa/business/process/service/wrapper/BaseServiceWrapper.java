package org.tiaa.business.process.service.wrapper;

import static org.tiaa.business.process.util.Constants.*;

import java.util.Date;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.entities.ProcessComments;
import org.tiaa.business.process.repository.nxtgen.CommentsRepository;
import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.business.process.util.DateUtil;
import org.tiaa.business.process.util.SerializerUtil;
import org.tiaa.business.process.wrapper.client.ActivitiWrapperRestClient;
import org.tiaa.esb.case_management_common_types.types.Comment;
import org.tiaa.esb.case_management_common_types.types.Comments;
import org.tiaa.esb.case_management_common_types.types.Process;
import org.tiaa.esb.case_management_common_types.types.Properties;
import org.tiaa.esb.case_management_common_types.types.Task;
import org.tiaa.esb.case_management_common_types.types.Tasks;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComment;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComments;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariables;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTask;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTasks;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Documents;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.NameValue;

/**
 *
 * @author subashr
 *
 */
@Component
public class BaseServiceWrapper {

	private static final int MAX_COMMENT_SIZE = 4000;

	@Autowired
	public ActivitiWrapperRestClient activitiWrapperRestClient;

	@Autowired
	public ConversionService conversionService;

	@Autowired
	public SerializerUtil serializerUtil;
	
	@Autowired
	CommentsRepository commentsRepository;

	protected Properties createPropertiesFromActivtiVariables(ActivitiVariables activitiVariables) {

		if ((activitiVariables == null) || (activitiVariables.getVariable().isEmpty())) {
			return null;
		}

		Properties properties = new Properties();

		for (ActivitiVariable variable : activitiVariables.getVariable()) {
			if (!VARIABLE_EXLCUSION_LIST.contains(variable.getName().toLowerCase())) {

				NameValue nvPair = this.conversionService.convert(variable, NameValue.class);

				properties.getProperty().add(nvPair);
			}
		}
		return properties;
	}

	protected Comments createCommentsFromActivitiComments(ActivitiComments actComments) {

		if (actComments == null) {
			return null;
		}

		Comments comments = new Comments();

		for (ActivitiComment actComment : actComments.getComment()) {
			comments.getComment().add(createCommentFromActivitiComment(actComment));
		}

		return comments;
	}

	protected Comment createCommentFromActivitiComment(ActivitiComment actComment) {
		if (actComment == null) {
			return null;
		}

		return this.conversionService.convert(actComment, Comment.class);
	}

	protected Task createTaskFromProcessTask(ProcessTask processTask) {
		Task task = this.conversionService.convert(processTask, Task.class);
		task.setTaskProperties(createPropertiesFromActivtiVariables(processTask.getVariables()));
		return task;
	}

	protected Process createProcessFromProcessInstance(ProcessInstance processInstance, boolean miscDetails) {
		Process process = this.conversionService.convert(processInstance, Process.class);
		process.setEditMode(processInstance.getEditMode());
		process.setLockedBy(processInstance.getLockedBy());
		process.setProcessProperties(createPropertiesFromActivtiVariables(processInstance.getVariables()));

		// Set Document Variable
		ActivitiVariable docVar = getDocumentVariable(processInstance.getVariables());

		if (docVar != null) {
			Documents docs = this.serializerUtil.deSerialize(String.valueOf(docVar.getValue()), Documents.class);
			process.setDocuments(docs);
		}

		// If MiscDetails enabled then populate Process Tasks & Process Comments
		if (miscDetails) {
			process.setComments(createCommentsFromActivitiComments(processInstance.getComments()));
			process.setTasks(createTasksFromProcessTasks(processInstance.getTasks()));
		}

		return process;
	}

	protected Tasks createTasksFromProcessTasks(ProcessTasks processTasks) {

		if (processTasks == null) {
			return null;
		}

		Tasks tasks = new Tasks();
		for (ProcessTask processTask : processTasks.getProcessTasks()) {
			tasks.getTask().add(createTaskFromProcessTask(processTask));
		}

		return tasks;
	}

	protected ActivitiVariables createActivitiVariablesFromProperties(final Properties properties) {

		ActivitiVariables variables = new ActivitiVariables();

		if (properties == null) {
			return variables;
		}

		for (NameValue nvPair : properties.getProperty()) {
			ActivitiVariable variable = this.conversionService.convert(nvPair, ActivitiVariable.class);
			variables.getVariable().add(variable);
		}

		return variables;
	}

	protected ActivitiVariable getDocumentVariable(ActivitiVariables variables) {

		if (variables == null) {
			return null;
		}
		for (ActivitiVariable variable : variables.getVariable()) {
			if (DOCUMENT_VARIABLE_NAME.equalsIgnoreCase(variable.getName())) {
				return variable;
			}
		}
		return null;
	}

	public ActivitiComment createActivitiCommmentFromComment(final Comment comment) {
		String message = this.serializerUtil.serialize(comment);

		if (message.length() >= MAX_COMMENT_SIZE) {
			throw new BadRequestException("Comment message/desc/type exceeds Max length");
		}

		ActivitiComment actComment = new ActivitiComment();
		actComment.setMessage(this.serializerUtil.serialize(comment));
		return actComment;
	}
	
	public void createComments(String processId, String taskId, String userId, Comment comment){
		
		
		ProcessComments taskComments = taskId!=null?this.commentsRepository
				.findByProcessInstanceIdAndTaskId(processId, taskId):this.commentsRepository.findByProcessInstanceId(processId);
		if (taskComments == null) {
			taskComments = new ProcessComments();
			taskComments.setProcessInstanceId(processId);
			taskComments.setTaskId(taskId);
			taskComments.setCreateTime(new Date());
		}
		String cStr = taskComments.getComments();
		Comments comments = this.serializerUtil.deSerialize(cStr, Comments.class);
		
		if (comments == null) {
			comments = new Comments();
		}

		XMLGregorianCalendar xgc =DateUtil.convertStringToDate(new Date());
		comment.setCreateDate(xgc);
		comment.setCreateTime(xgc);
		comment.setCreateOper(userId);
		comment.setProcessId(processId);
	
		comments.getComment().add(comment);

		cStr = this.serializerUtil.serialize(comments);
		taskComments.setComments(cStr);
		taskComments.setLastUpdatedTime(new Date());
		this.commentsRepository.save(taskComments);
	}

}