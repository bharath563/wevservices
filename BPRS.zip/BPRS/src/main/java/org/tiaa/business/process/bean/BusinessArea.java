package org.tiaa.business.process.bean;

import java.io.Serializable;

/**
 * @author pamdama
 *
 */
public class BusinessArea implements Serializable {

	private static final long serialVersionUID = 3400923837047787218L;
	
	
	private Long baCode;
	
	private String baName;

	private String baLongName;

	/**
	 * @return the baCode
	 */
	public Long getBaCode() {
		return baCode;
	}

	/**
	 * @param baCode the baCode to set
	 */
	public void setBaCode(Long baCode) {
		this.baCode = baCode;
	}

	/**
	 * @return the baName
	 */
	public String getBaName() {
		return baName;
	}

	/**
	 * @param baName the baName to set
	 */
	public void setBaName(String baName) {
		this.baName = baName;
	}

	/**
	 * @return the baLongName
	 */
	public String getBaLongName() {
		return baLongName;
	}

	/**
	 * @param baLongName the baLongName to set
	 */
	public void setBaLongName(String baLongName) {
		this.baLongName = baLongName;
	}
	
	
	

}
