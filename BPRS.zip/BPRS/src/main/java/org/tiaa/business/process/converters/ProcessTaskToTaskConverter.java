package org.tiaa.business.process.converters;

import static org.tiaa.business.process.util.Constants.*;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.util.SerializerUtil;
import org.tiaa.esb.case_management_common_types.types.SLADetail;
import org.tiaa.esb.case_management_common_types.types.Task;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTask;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Status;
import org.tiaa.tiaacommon.tiaa_common_complex_types_v2.Statuses;

/**
 * Converter class to Activiti Process Task to Object Model Task
 *
 * @author subashr
 *
 */
@Component
public class ProcessTaskToTaskConverter implements Converter<ProcessTask, Task> {

	@Autowired
	SerializerUtil serializerUtil;

	@Override
	public Task convert(ProcessTask source) {

		if (source == null) {
			return null;
		}

		Task task = new Task();
		task.setID(source.getTaskId());
		task.setName(source.getTaskName());
		task.setDescription(source.getTaskDesc());
		task.setPriority(source.getPriority());

		if (source.getAssignee() != null) {
			task.setAssignedTo(source.getAssignee().getUserId());
		}

		task.setCreateTime(source.getCreateDate());
		task.setCreateDate(source.getCreateDate());

		task.setCompleteDate(source.getEndDate());
		task.setCompleteTime(source.getEndDate());

		task.setReceivedDate(source.getClaimDate());
		task.setReceivedTime(source.getClaimDate());

		if (source.getDueDate() != null) {
			SLADetail sladetail = new SLADetail();
			sladetail.setDueDate(source.getDueDate());
			task.setSLADetail(sladetail);
		}

		if (StringUtils.isNotBlank(source.getTaskStatus())) {
			Statuses statuses = new Statuses();
			Status status = new Status();
			status.setSts(source.getTaskStatus());

			statuses.getSts().add(status);
			task.setStatusHistory(statuses);
		}

		task.setPriority(source.getPriority());
		task.setType(USER_TASK_TYPE);

		task.setDepartment(source.getDepartment());

		// Fields Not populated
		task.setAction(null);
		task.setAwakeDate(null);
		task.setAwakeTime(null);
		task.setGroup(null);
		task.setLastUpdatedDate(null);
		task.setLastUpdatedTime(null);
		task.setScanMode(null);
		task.setTaskProperties(null);
		task.setVIPIndicator(null);
		task.setWobId(null);

		return task;
	}
}
