package org.tiaa.business.process.validator;

import org.springframework.stereotype.Component;

import org.tiaa.business.process.service.exception.BadRequestException;
import org.tiaa.esb.transaction_event_rs_v1_0.types.EventRequest;

/**
 * Validator class for EventRequest
 * @author pamdama
 *
 */
@Component
public class EventRequestValidator implements ObjectValidator<EventRequest> {

	@Override
	public void validate(EventRequest eventReq) {
		
		if (eventReq == null) {
			throw new BadRequestException("EventRequest object cannot be NULL");
		}

		if (eventReq.getEvent() == null) {
			throw new BadRequestException("Event object cannot be NULL");
		}
		
		if (eventReq.getEvent().getEventName() == null) {
			throw new BadRequestException("EventName in Event cannot be NULL");
		}
		
		if (eventReq.getEvent().getProcessType() == null) {
			throw new BadRequestException("ProcessType in Event cannot be NULL");
		}
		
		if (eventReq.getEvent().getRequestType() == null) {
			throw new BadRequestException("RequestType in Event cannot be NULL");
		}
	}

}
