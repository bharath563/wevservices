package org.tiaa.business.process.resource;

import static org.tiaa.business.process.util.Constants.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import org.tiaa.business.process.queue.listener.QueueManager;
import org.tiaa.business.process.service.deploy.BPMNDeployService;
import org.tiaa.business.process.wrapper.client.ActivitiWrapperRestClient;

/**
 * Admin Resource class
 *
 * @author subashr
 *
 */
@RestController
@ResponseStatus(HttpStatus.OK)
public class AdminResource {

	@Autowired
	QueueManager queueManager;

	@Autowired
	BPMNDeployService bpmnDeployService;

	@Autowired
	public ActivitiWrapperRestClient activitiWrapperRestClient;

	@RequestMapping(value = { "/admin/queue" }, method = RequestMethod.GET, produces = { JSON_CONTENT_TYPE })
	public String getQueueStatus(
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth) {
		// Validate if the user has access to this system. This is done by
		// calling Wrapper Ping service. Since ping doesn't do any process level
		// checks this will be a faster alternative rather than implementing any
		// authentication checks.
		this.activitiWrapperRestClient.ping(basicAuth);

		return this.queueManager.getQueueStatus();
	}

	@RequestMapping(value = { "/admin/queue/{queueName}/start" }, method = RequestMethod.POST, produces = { JSON_CONTENT_TYPE })
	public String startQueue(@PathVariable("queueName") String queueName,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth) {
		// Validate if the user has access to this system. This is done by
		// calling Wrapper Ping service. Since ping doesn't do any process level
		// checks this will be a faster alternative rather than implementing any
		// authentication checks.
		this.activitiWrapperRestClient.ping(basicAuth);

		return this.queueManager.manageQueue(queueName, true);
	}

	@RequestMapping(value = { "/admin/queue/{queueName}/stop" }, method = RequestMethod.POST, produces = { JSON_CONTENT_TYPE })
	public String stopQueue(@PathVariable("queueName") String queueName,
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth) {

		// Validate if the user has access to this system. This is done by
		// calling Wrapper Ping service. Since ping doesn't do any process level
		// checks this will be a faster alternative rather than implementing any
		// authentication checks.
		this.activitiWrapperRestClient.ping(basicAuth);
		return this.queueManager.manageQueue(queueName, false);
	}

	@RequestMapping(value = "/admin/bpmn/deploy", method = RequestMethod.POST, consumes = { MULTIPART_FORM_DATA }, produces = { JSON_CONTENT_TYPE })
	public String deployBPMN(
			@RequestHeader(BASIC_AUTH_HEADER) String basicAuth,
			@RequestPart("file") MultipartFile file) {
		return this.bpmnDeployService.deployBPMN(file, basicAuth);
	}
}
