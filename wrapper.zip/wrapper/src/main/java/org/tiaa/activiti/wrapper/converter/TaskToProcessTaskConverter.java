package org.tiaa.activiti.wrapper.converter;

import static org.tiaa.activiti.wrapper.util.Constants.*;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.activiti.wrapper.util.UserUtils;
import org.tiaa.business.process.util.DateUtil;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTask;

@Component
public class TaskToProcessTaskConverter implements
Converter<org.activiti.engine.task.Task, ProcessTask> {

	public static final Logger logger = Logger.getLogger(TaskToProcessTaskConverter.class);

	@Autowired
	private UserUtils userUtils;

	@Override
	public ProcessTask convert(org.activiti.engine.task.Task actiTask) {
		logger.debug("convert Method START ");

		if (actiTask == null) {
			return null;
		}

		ProcessTask task = new ProcessTask();
		task.setTaskId(actiTask.getId());
		task.setTaskName(actiTask.getName());
		task.setTaskDesc(actiTask.getDescription());
		task.setPriority(String.valueOf(actiTask.getPriority()));
		task.setDueDate(DateUtil.convertStringToDate(actiTask.getDueDate()));
		task.setDepartment(actiTask.getCategory());
		task.setTaskStatus(STATUS_OPEN);

		task.setAssignee(this.userUtils.getUserById(actiTask.getAssignee()));
		task.setCreateDate(DateUtil.convertStringToDate(actiTask
				.getCreateTime()));

		task.setDueDate(DateUtil.convertStringToDate(actiTask.getDueDate()));

		logger.debug("convert Method END ");
		return task;
	}

}
