package org.tiaa.activiti.wrapper.converter;

import org.activiti.engine.history.HistoricActivityInstance;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.activiti.wrapper.util.UserUtils;
import org.tiaa.business.process.util.DateUtil;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.Event;

/**
 * This class converts the HistoricActivityInstance to Event.This HistoricActivityInstance
 * can be a service/user/receive task
 * 
 * @author pamdama
 *
 */
@Component
public class HistoricActivityInstToEventConverter implements
		Converter<HistoricActivityInstance, Event> {

	public static final Logger LOGGER = Logger
			.getLogger(HistoricActivityInstToEventConverter.class);

	@Autowired
	UserUtils userUtils;

	@Override
	public Event convert(HistoricActivityInstance histActiInst) {
		LOGGER.debug("convert Method START ");

		if (histActiInst == null) {
			return null;
		}

		Event event = new Event();
		event.setTitle(histActiInst.getActivityName());
		event.setEventType(histActiInst.getActivityType());
		event.setCreateDateTime(DateUtil.convertStringToDate(histActiInst.getStartTime()));
		event.setEndDateTime(DateUtil.convertStringToDate(histActiInst.getEndTime()));
		event.setCreatedBy(this.userUtils.getUserExternalId(histActiInst.getAssignee()));
		event.setExecutionId(histActiInst.getExecutionId());

		LOGGER.debug("convert Method END ");
		return event;
	}

}
