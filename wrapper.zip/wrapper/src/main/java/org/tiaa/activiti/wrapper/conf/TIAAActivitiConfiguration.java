package org.tiaa.activiti.wrapper.conf;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ConversionServiceFactoryBean;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;

import org.tiaa.business.process.uuid.CorrelationUUIDGenerator;

@Configuration
@SuppressWarnings("rawtypes")
public class TIAAActivitiConfiguration {

	@Autowired
	List<Converter> converters;

	@Bean
	public ConversionService conversionService() {
		ConversionServiceFactoryBean factory = new ConversionServiceFactoryBean();
		Set<Converter> converterSet = new HashSet<Converter>();

		for (Converter converter : this.converters) {
			converterSet.add(converter);
		}

		factory.setConverters(converterSet);
		factory.afterPropertiesSet();
		return factory.getObject();
	}

	@Bean
	public CorrelationUUIDGenerator corrGen() {
		return new CorrelationUUIDGenerator();
	}
}
