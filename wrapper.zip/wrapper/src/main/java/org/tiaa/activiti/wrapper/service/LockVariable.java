package org.tiaa.activiti.wrapper.service;

import java.util.Date;

public class LockVariable {

	private Long userId;
	private Date lockExpirationTime;

	public LockVariable(Long userId2, Date lockExpirationTime) {
		this.userId = userId2;
		this.lockExpirationTime = lockExpirationTime;
	}

	public Long getUserId() {
		return this.userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Date getLockExpirationTime() {
		return this.lockExpirationTime;
	}

	public void setLockExpirationTime(Date lockExpirationTime) {
		this.lockExpirationTime = lockExpirationTime;
	}
}
