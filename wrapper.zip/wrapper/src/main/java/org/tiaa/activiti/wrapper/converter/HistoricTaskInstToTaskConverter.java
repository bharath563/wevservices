package org.tiaa.activiti.wrapper.converter;

import static org.tiaa.activiti.wrapper.util.Constants.*;

import org.activiti.engine.history.HistoricTaskInstance;

import org.apache.log4j.Logger;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.util.DateUtil;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTask;

@Component
public class HistoricTaskInstToTaskConverter implements
		Converter<HistoricTaskInstance, ProcessTask> {

	public static final Logger logger = Logger.getLogger(HistoricTaskInstToTaskConverter.class);

	@Override
	public ProcessTask convert(HistoricTaskInstance histTaskInst) {

		logger.debug("convert Method START ");

		if (histTaskInst == null) {
			return null;
		}

		ProcessTask task = new ProcessTask();
		task.setTaskId(histTaskInst.getId());
		task.setTaskName(histTaskInst.getName());
		task.setTaskDesc(histTaskInst.getDescription());
		task.setPriority(String.valueOf(histTaskInst.getPriority()));
		task.setDueDate(DateUtil.convertStringToDate(histTaskInst.getDueDate()));
		task.setDepartment(histTaskInst.getCategory());
		if (histTaskInst.getEndTime() != null) {
			task.setEndDate(DateUtil.convertStringToDate(histTaskInst
					.getEndTime()));
			task.setTaskStatus(STATUS_COMPLETED);
		} else {
			task.setTaskStatus(STATUS_OPEN);
		}

		task.setClaimDate(DateUtil.convertStringToDate(histTaskInst
				.getClaimTime()));

		task.setCreateDate(DateUtil.convertStringToDate(histTaskInst
				.getCreateTime()));

		logger.debug("convert Method END ");
		return task;
	}
}
