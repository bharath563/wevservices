package org.tiaa.activiti.wrapper.transformer;

import static org.tiaa.activiti.wrapper.util.Constants.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.HistoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricVariableInstance;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.activiti.domain.idm.User;
import com.activiti.service.exception.BadRequestException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import org.tiaa.activiti.wrapper.service.LockService;
import org.tiaa.activiti.wrapper.service.ProcessRunTimeService;
import org.tiaa.activiti.wrapper.service.ProcessServiceUtil;
import org.tiaa.activiti.wrapper.util.UserUtils;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariables;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.Event;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.Events;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance;

@Component
public class TNGServiceTransformer {

	// TODO Remove all unwanted process model ids and change it to correct one
	private static final String PROC_DEF_KEYS[] = new String[] { "InstitutionalPlanOffer",
		"InstitutionalPlanOfferV2", "InstitutionalPlanOfferV3", "InstitutionalPlanOfferV5",
		"InstitutionalPlanOfferV6", "InstitutionalPlanOfferV7", "InstitutionalPlanOfferV8",
		"InstitutionalPlanOfferV9", "InstitutionalPlanOfferV10",
	"SimpleUserTaskDirectlyAssigned" };

	private static final String MILESTONE_UI_OPTIONS = "milestoneUIOptions";
	private static final String MILESTONE_SIGNAL_UI_MAPPING = "milestoneSignalUIMapping";
	private static final String MILESTONE_REQUEST_TIMELINE_MAPPING = "milestoneRequestTimeLineMapping";
	private static final String OFFER_MILESTONE = "offerMilestone";

	private static final String TNG_PROCESS_IDENTIFIER = "InstitutionalPlanOffer";

	public static final Logger logger = Logger.getLogger(TNGServiceTransformer.class);

	@Autowired
	UserUtils userUtils;

	@Autowired
	ProcessServiceUtil serviceUtil;

	@Autowired
	protected RuntimeService runtimeService;

	@Autowired
	protected ProcessRunTimeService processRuntimeService;

	@Autowired
	protected LockService lockService;

	@Autowired
	HistoryService historyService;

	@Value("${tng.caseworker.group.name}")
	private String tngCaseworkerGroupName;

	public void enrichTNGGetProcess(ProcessInstance process) {
		ActivitiVariable mileStoneUIOptionsVariable = getActivitiVariable(
				process.getVariables(), MILESTONE_UI_OPTIONS);
		ActivitiVariable offerMileStone = getActivitiVariable(process.getVariables(),
				OFFER_MILESTONE);

		if (offerMileStone != null) {
			offerMileStone.setType("LIST");

			if (mileStoneUIOptionsVariable != null) {
				String offerMileStoneValue = offerMileStone.getValue();
				String offerUIOptionsValue = mileStoneUIOptionsVariable.getValue();

				if (StringUtils.isNotBlank(offerUIOptionsValue)) {
					offerMileStone.setValue(offerMileStoneValue + "," + offerUIOptionsValue);
				}
			}
		}

		}

	private ActivitiVariable getActivitiVariable(ActivitiVariables variables,
			String variableName) {
		for (ActivitiVariable variable : variables.getVariable()) {
			if (variableName.equalsIgnoreCase(variable.getName())) {
				return variable;
			}
		}

		return null;
	}

	private ActivitiVariable getMileStoneUIOptions(ActivitiVariables variables) {
		for (ActivitiVariable variable : variables.getVariable()) {
			if (MILESTONE_UI_OPTIONS.equalsIgnoreCase(variable.getName())) {
				return variable;
			}
		}

		return null;
	}

	public boolean isProcessLockable(final ProcessInstance process) {

		User user = this.userUtils.getSessionUser();
		logger.info("********** Came to TNG is process lockable ******** "
				+ hasProcessReachedState(process.getVariables())
				+ "  ******** User Access: "
				+ this.userUtils.hasUserHasAccessToGroup(user.getId(),
						this.tngCaseworkerGroupName));
		return hasProcessReachedState(process.getVariables())
				&& this.userUtils.hasUserHasAccessToGroup(user.getId(),
						this.tngCaseworkerGroupName);
	}

	public boolean isProcessInstanceTNG(final HistoricProcessInstance processInstance) {
		String processKey = this.serviceUtil.getProcessDefinitionKey(processInstance);
		logger.info("************ Came to is ProcessInstance TNG ******** " + processKey
				+ " ******* PID :" + processInstance + " ******** " );
		return processKey == null ? false : processKey.startsWith(TNG_PROCESS_IDENTIFIER);
	}


	private boolean hasProcessReachedState(ActivitiVariables activitiVariables) {
		ActivitiVariable mileStoneVariable = getMileStoneUIOptions(activitiVariables);
		return ((mileStoneVariable != null) && StringUtils.isNotBlank(mileStoneVariable
				.getValue()));
	}

	public void updateProcess(String processInstanceId, Map<String, Object> variables) {

		String milestone = (String) variables.get(OFFER_MILESTONE);
		logger.debug("OfferMilestone value is:"+milestone);
		if (StringUtils.isBlank(milestone)) {
			throw new BadRequestException("offerMilestone value is needed for update");
		}

		List<HistoricVariableInstance> vars = getVariables(processInstanceId);
		String existingOfferMilestone = getVariableValue(vars, OFFER_MILESTONE);

		if (milestone.equalsIgnoreCase(existingOfferMilestone)) {
			throw new BadRequestException(
					"The Production Readiness Milestone must be changed in order to be updated");
		}

		String signalUIOptionsValue = getVariableValue(vars, MILESTONE_SIGNAL_UI_MAPPING);
		String receiveTaskNameOptionsValue = getVariableValue(vars,
				MILESTONE_REQUEST_TIMELINE_MAPPING);
		logger.debug("MilestoneSignalUIMapping: "+signalUIOptionsValue);
		logger.debug("MilestoneRequestTimelineMapping: "+receiveTaskNameOptionsValue);
		if (receiveTaskNameOptionsValue == null) {
			throw new BadRequestException("ReceiveTask variable is needed for MileStone update");
		}

		if (StringUtils.isBlank(signalUIOptionsValue)) {
			throw new BadRequestException(
					"SignalMileStoneUIOptions variable is need for MileStone update");
		}

		String signalName = parseMilestoneSignalMapping(signalUIOptionsValue, milestone);
		String receiveTaskName = parseMilestoneSignalMapping(receiveTaskNameOptionsValue,
				signalName);
		String receiveTaskUserId = getVariableValue(vars, TNGRECEIVE_UI_VARIABLE_NAME);
		String userId = this.userUtils.getSessionUser().getExternalId();
		receiveTaskUserId = (receiveTaskUserId == null) ? (receiveTaskName + ":" + userId)
				: receiveTaskUserId.concat(";" + (receiveTaskName + ":" + userId));
		logger.debug("SignalName: "+signalName + ",userId: "+userId + ",receiveTaskUserId: "+receiveTaskUserId);

		variables.put(TNGRECEIVE_UI_VARIABLE_NAME, receiveTaskUserId);
		if (StringUtils.isBlank(signalName)) {
			throw new BadRequestException("Not able to derive Signal Name. MileStoneValue:"
					+ milestone + " . Signal Mappping:" + signalUIOptionsValue);
		}

		this.processRuntimeService.signal(processInstanceId, signalName, variables);
	}

	public String parseMilestoneSignalMapping(final String milestoneSignalMapping,
			final String milestone) {
		Map<String, String> msMap = new HashMap<String, String>();
		String[] chunks = milestoneSignalMapping.split(";");
		for (String chunk : chunks) {
			String[] milestoneSignal = chunk.split(":");

			if (milestoneSignal.length == 2) {
				msMap.put(milestoneSignal[0], milestoneSignal[1]);
			}
		}

		logger.info("MileStone Map is " + msMap);
		return msMap.get(milestone);
	}

	private String getVariableValue(List<HistoricVariableInstance> vars, String variableName) {
		String variableValue = null;
		for (HistoricVariableInstance var : vars) {
			if (variableName.equalsIgnoreCase(var.getVariableName())) {
				variableValue = String.valueOf(var.getValue());
			}
		}
		return variableValue;
	}

	private List<HistoricVariableInstance> getVariables(String processInstanceId) {
		List<HistoricVariableInstance> vars = this.historyService
				.createHistoricVariableInstanceQuery().processInstanceId(processInstanceId)
				.list();
		return vars;
	}

	public void enrichTNGHistoryCall(HistoricProcessInstance processInstance, Events events) {

		List<HistoricVariableInstance> vars = getVariables(processInstance.getId());
		String receiveTaskUserId = getVariableValue(vars, TNGRECEIVE_UI_VARIABLE_NAME);
		Map<String, String> receiveTaskUserMap = new HashMap<String, String>();

		if (receiveTaskUserId == null) {
			return;
		}

		for (String arr : receiveTaskUserId.split(";")) {
			String arr1[] = arr.split(":");

			if (arr1.length == 2) {
				receiveTaskUserMap.put(arr1[0], arr1[1]);
			}
		}

		for (Event event : events.getEvents()) {
			if (receiveTaskUserMap.keySet().contains(event.getTitle())) {
				event.setEventType("tngReceiveTask");
				event.setCreatedBy(receiveTaskUserMap.get(event.getTitle()));
			}
		}
	}
}
