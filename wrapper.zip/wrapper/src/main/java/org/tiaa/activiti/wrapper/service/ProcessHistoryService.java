package org.tiaa.activiti.wrapper.service;

import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComments;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstances;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTask;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTasks;

/**
 * This is an interface providing methods to access history information about
 * past and ongoing process instances.
 *
 * @author pamdama
 *
 */
public interface ProcessHistoryService {
	/**
	 * This method gets the variables associated to the given processInstanceId.
	 *
	 * @param processInstanceId
	 * @param lock
	 *
	 */
	public ProcessInstance getProcessInstance(String processInstanceId,
			final String isHistoryEnabled, boolean lock);

	/**
	 * This method retrieves information about the Document MetaData associated
	 * to the ProcessInsatnceId
	 *
	 * @param processInstanceId
	 * @return
	 */
	public ActivitiVariable getProcessDocuments(String processInstanceId);

	/**
	 * This method retrieves information about the Comments associated to the
	 * given ProcessInstanceId
	 *
	 * @param processInstanceId
	 * @return
	 */
	public ActivitiComments getProcessComments(String processInstanceId);

	/**
	 * This method retrieves information about the Comments associated to the
	 * given TaskId
	 *
	 * @param processInstanceId
	 * @return
	 */
	public ActivitiComments getTaskComments(String processInstanceId,
			String taskId);

	/**
	 * This method retrieves information about the Tasks associated to the given
	 * ProcessInstanceId
	 *
	 * @param processInstanceId
	 * @return
	 */
	public ProcessTasks getTasks(String processInstanceId);

	/**
	 * This method retrieves tasks assigned to the user.
	 *
	 * @param userId
	 * @return
	 */
	public ProcessInstances getTasksAssignedToUser();

	/**
	 * This method retrieves the tasks claimable to the user.
	 *
	 * @param userId
	 * @return
	 */
	public ProcessInstances getTasksClaimableToUser();

	/**
	 * This method retrieves the task associated to the TaskId
	 *
	 * @param taskId
	 * @param userId
	 * @return
	 */
	public ProcessTask getTask(final String processInstanceId,
			final String taskId);

	/**
	 * This method returns all the historic activities associated to the
	 * processInstance
	 *
	 * @param processInstanceId
	 * @return
	 */
	public org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance getProcessHistory(
			String processInstanceId);

}