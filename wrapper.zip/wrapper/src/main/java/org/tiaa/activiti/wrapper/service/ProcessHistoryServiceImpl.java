package org.tiaa.activiti.wrapper.service;

import static org.tiaa.activiti.wrapper.util.Constants.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.activiti.engine.HistoryService;
import org.activiti.engine.IdentityService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.task.Task;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.activiti.domain.idm.User;
import com.activiti.domain.runtime.Comment;
import com.activiti.service.api.UserService;
import com.activiti.service.exception.NotFoundException;
import com.activiti.service.runtime.AlfrescoCommentService;
import com.activiti.service.runtime.CommentService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;

import org.tiaa.activiti.wrapper.transformer.TNGServiceTransformer;
import org.tiaa.activiti.wrapper.util.Constants;
import org.tiaa.activiti.wrapper.util.UserUtils;
import org.tiaa.business.process.util.DateUtil;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComment;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComments;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariables;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.Event;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.Events;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstances;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTask;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTasks;

/**
 * This is Service implementation class for ProcessHistoryService.
 *
 * @author pamdama
 *
 */
@Component
public class ProcessHistoryServiceImpl implements ProcessHistoryService {

	public static final Logger logger = Logger.getLogger(ProcessHistoryServiceImpl.class);

	@Autowired
	HistoryService historyService;

	@Autowired
	TaskService taskService;

	@Autowired
	IdentityService identityService;

	@Autowired
	AlfrescoCommentService alfrescoCommentService;

	@Autowired
	UserService userService;

	@Autowired
	ConversionService conversionService;

	@Autowired
	CommentService commentService;

	@Autowired
	UserUtils userUtils;

	@Autowired
	LockService lockService;

	@Autowired
	TNGServiceTransformer tngServiceTransformer;

	private static final String[] FILTER_ACTIVITY_TYPES = { "receiveTask",
		// "boundaryMessage",
		"manualTask", "userTask", "intermediateMessageCatch" };

	/*
	 * (non-Javadoc)
	 * @see
	 * com.activiti.extension.bean.ProcessHistoryService#getProcessInstance(
	 * java.lang.String)
	 */
	@Override
	public org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance getProcessInstance(
			String processInstanceId, String isHistoryEnabled, boolean lock) {

		logger.debug("getProcessInstance method START ");
		ProcessInstance process = null;

		HistoricProcessInstance processInstance = getActivitiProcessInstance(processInstanceId);

		logger.debug("Process Details:" + processInstance.getId() + ":"
				+ processInstance.getProcessDefinitionId() + ":"
				+ processInstance.getDurationInMillis() + ":" + processInstance.getStartTime()
				+ ":" + processInstance.getEndTime() + ":::"
				+ processInstance.getProcessVariables());

		// 1. Get Process
		process = this.conversionService.convert(processInstance,
				org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance.class);

		// 2. Get ProcessProperties
		List<HistoricVariableInstance> vars = this.historyService
				.createHistoricVariableInstanceQuery().processInstanceId(processInstanceId)
				.list();
		process.setVariables(createActivitiVariablesFromHistoricVariablesList(vars));

		logger.debug("###### Checking is process locakable");

		logger.info("ProcessHistoryServiceimpl.getProcessInstance().lock : " + lock);

		process.setEditMode("Read");

		boolean lockable = false;

		if (lock && this.lockService.isProcessLockable(processInstance, vars)) {
			lockable = true;

			if (this.tngServiceTransformer.isProcessInstanceTNG(processInstance)) {
				lockable = this.tngServiceTransformer.isProcessLockable(process);
			}
		}
		else if (lock) {
			// its not lockable because someone else locked it. Get user and setit.
			process.setLockedBy(this.lockService.getLockOwner(vars));
		}

		logger.info("Lockable value : " + lockable);
		if (lockable) {
			User user = this.userUtils.getSessionUser();
			this.lockService.lockProcess(processInstanceId, user.getId());
			process.setEditMode("Write");
		}

		if (this.tngServiceTransformer.isProcessInstanceTNG(processInstance)) {
			this.tngServiceTransformer.enrichTNGGetProcess(process);
		}

		if (Boolean.valueOf(isHistoryEnabled)) {
			ActivitiComments comments = getProcessComments(processInstanceId);
			process.setComments(comments);
			ProcessTasks tasks = getTasks(processInstanceId);
			process.setTasks(tasks);
		}

		logger.debug("getProcessInstance method END ");
		return process;
	}

	/**
	 * This returns the documents associated to the ProcessInstance
	 *
	 * @param processInstanceId
	 * @return
	 */
	@Override
	public ActivitiVariable getProcessDocuments(String processInstanceId) {

		logger.debug("getProcessDocuments method START ");

		getActivitiProcessInstance(processInstanceId);

		HistoricVariableInstance document = this.historyService
				.createHistoricVariableInstanceQuery().processInstanceId(processInstanceId)
				.variableName(DOCUMENT_VARIABLE_NAME).singleResult();
		ActivitiVariable docVar = null;
		if ((document == null) || StringUtils.isBlank((String) document.getValue())) {
			logger.info("No Documents variable associated to the ProcessInstance - "
					+ processInstanceId);
		}
		else {
			docVar = new ActivitiVariable();
			docVar = this.conversionService.convert(document, ActivitiVariable.class);
		}

		logger.debug("getProcessDocuments method END ");
		return docVar;
	}

	/*
	 * (non-Javadoc)
	 * @see
	 * com.activiti.extension.bean.ProcessHistoryService#getProcessComments(
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public ActivitiComments getProcessComments(String processInstanceId) {
		logger.debug("getProcessComments method START ");
		getActivitiProcessInstance(processInstanceId);
		List<com.activiti.domain.runtime.Comment> allComments = new ArrayList<com.activiti.domain.runtime.Comment>();

		// 1. Get ProcessComments
		List<com.activiti.domain.runtime.Comment> processComments = this.commentService
				.getCommentsForProcessInstance(processInstanceId, true);
		allComments.addAll(processComments);
		return createActivitiCommentFromComment(allComments);
	}

	/**
	 * This method returns the HistoricProcessInstance associated to the
	 * ProcessInstanceId
	 *
	 * @param processInstanceId
	 * @return
	 */
	private HistoricProcessInstance getActivitiProcessInstance(
			final String processInstanceId) {

		if (StringUtils.isBlank(processInstanceId)) {
			throw new NotFoundException("Process ID cannot be NULL or Blank");
		}

		HistoricProcessInstance processInstance = this.historyService
				.createHistoricProcessInstanceQuery().processInstanceId(processInstanceId)
				.singleResult();

		if (processInstance == null) {
			throw new NotFoundException("Process " + processInstanceId + " not found.");
		}
		return processInstance;
	}

	@Override
	public ProcessTasks getTasks(String processInstanceId) {
		logger.debug("getTasks method START ");
		getActivitiProcessInstance(processInstanceId);

		List<HistoricTaskInstance> tasks = this.historyService
				.createHistoricTaskInstanceQuery().processInstanceId(processInstanceId).list();

		ProcessTasks allTasks = new ProcessTasks();

		logger.info("Number of HistoricTasks are - " + tasks.size());
		for (HistoricTaskInstance histTask : tasks) {
			allTasks.getProcessTasks().add(createProcessTaskFromHistoricTask(histTask));
		}

		logger.debug("getTasks method END ");
		return allTasks;
	}

	@Override
	public ProcessTask getTask(String processInstanceId, String taskId) {
		logger.debug("getTasks method START ");
		getActivitiProcessInstance(processInstanceId);

		HistoricTaskInstance histTask = this.historyService.createHistoricTaskInstanceQuery()
				.processInstanceId(processInstanceId).taskId(taskId).singleResult();

		if (histTask == null) {
			throw new NotFoundException("Task " + taskId + " not found for ProcessInstanceId "
					+ processInstanceId);
		}

		return createProcessTaskFromHistoricTask(histTask);
	}

	@Override
	public ActivitiComments getTaskComments(String processInstanceId, String taskId) {
		logger.debug("getProcessComments method START ");
		getTask(processInstanceId, taskId);

		List<Comment> taskComments = this.commentService.getCommentsForTask(taskId, true);

		return createActivitiCommentFromComment(taskComments);
	}

	/*
	 * (non-Javadoc)
	 * @see
	 * com.activiti.extension.bean.ProcessHistoryService#getTasksAssignedToUser
	 * (java.lang.String)
	 */
	@Override
	public ProcessInstances getTasksAssignedToUser() {
		User user = this.userUtils.getSessionUser();
		List<Task> tasks = this.taskService.createTaskQuery()
				.taskAssignee(String.valueOf(user.getId())).list();

		ProcessInstances processes = new ProcessInstances();

		logger.info("Number of Assigned Tasks found - " + tasks.size() + " for user "
				+ user.getExternalId());
		for (org.activiti.engine.task.Task task : tasks) {
			processes.getProcessInstance().add(addTaskToProcessInstance(task));
		}

		logger.debug("getTasksAssignedToUser method END ");
		return processes;
	}

	/*
	 * (non-Javadoc)
	 * @see
	 * com.activiti.extension.bean.ProcessHistoryService#getTasksClaimableToUser
	 * (java.lang.String)
	 */
	@Override
	public ProcessInstances getTasksClaimableToUser() {
		User user = this.userUtils.getSessionUser();
		ProcessInstances processes = new ProcessInstances();

		List<String> groupIds = new ArrayList<String>();
		logger.info("Number of UserGroups found  " + user.getGroups().size());

		for (com.activiti.domain.idm.Group group : user.getGroups()) {
			logger.debug("Group Name:" + group.getName() + " Group Id :" + group.getId());
			groupIds.add(String.valueOf(group.getId()));
		}

		List<Task> tasks = this.taskService.createTaskQuery().taskCandidateGroupIn(groupIds)
				.list();
		logger.info("Number of Tasks found - " + tasks.size());
		for (org.activiti.engine.task.Task task : tasks) {
			processes.getProcessInstance().add(addTaskToProcessInstance(task));
		}

		logger.debug("getTasksClaimableToUser method END ");
		return processes;
	}

	private ActivitiComments createActivitiCommentFromComment(final List<Comment> comments) {
		ActivitiComments actComments = new ActivitiComments();

		for (Comment comment : comments) {

			ActivitiComment pvmComment = new ActivitiComment();

			pvmComment.setMessage(comment.getMessage());
			pvmComment.setCreateDate(DateUtil.convertStringToDate(comment.getCreated()));
			pvmComment.setProcessInstanceId(String.valueOf(comment.getProcessInstanceId()));
			if ((comment.getCreatedBy() != null)
					&& (comment.getCreatedBy().getExternalId() != null)) {
				org.tiaa.pvm.activiti_wrapper_v1_0.types.User user = new org.tiaa.pvm.activiti_wrapper_v1_0.types.User();
				user.setUserId(comment.getCreatedBy().getExternalId());
				pvmComment.setCreatedBy(user);

			}
			pvmComment.setTaskId(comment.getTaskId());
			actComments.getComment().add(pvmComment);
		}

		return actComments;
	}

	private ProcessInstance addTaskToProcessInstance(
			final org.activiti.engine.task.Task actTask) {

		ProcessInstance process = new ProcessInstance();

		ProcessTask procTask = this.conversionService.convert(actTask, ProcessTask.class);

		process.setProcessInstanceId(actTask.getProcessInstanceId());
		ProcessTasks respTasks = new ProcessTasks();
		respTasks.getProcessTasks().add(procTask);
		process.setTasks(respTasks);

		// 2. Get ProcessProperties
		List<HistoricVariableInstance> vars = this.historyService
				.createHistoricVariableInstanceQuery()
				.processInstanceId(actTask.getProcessInstanceId()).list();
		logger.info("No. of variables found - " + vars.size());
		process.setVariables(createActivitiVariablesFromHistoricVariablesList(vars));

		// 3. Get Task Process Properties
		List<HistoricVariableInstance> taskVars = this.historyService
				.createHistoricVariableInstanceQuery().taskId(actTask.getId()).list();
		procTask.setVariables(createActivitiVariablesFromHistoricVariablesList(taskVars));

		return process;
	}

	private ProcessTask createProcessTaskFromHistoricTask(HistoricTaskInstance histTask) {
		ProcessTask task = this.conversionService.convert(histTask, ProcessTask.class);

		task.setAssignee(this.userUtils.getUserById(histTask.getAssignee()));
		List<HistoricVariableInstance> variables = this.historyService
				.createHistoricVariableInstanceQuery().taskId(histTask.getId()).list();
		task.setVariables(createActivitiVariablesFromHistoricVariablesList(variables));

		return task;
	}

	private ActivitiVariables createActivitiVariablesFromHistoricVariablesList(
			List<HistoricVariableInstance> variables) {
		ActivitiVariables vars = new ActivitiVariables();
		logger.info("Variables size - " + variables.size());
		for (HistoricVariableInstance activitiVar : variables) {
			ActivitiVariable props = this.conversionService.convert(activitiVar,
					ActivitiVariable.class);
			vars.getVariable().add(props);
		}

		return vars;
	}

	/*
	 * (non-Javadoc)
	 * @see
	 * org.tiaa.activiti.wrapper.service.ProcessHistoryService#getProcessHistory
	 * (java.lang.String)
	 */
	@Override
	public org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance getProcessHistory(
			String processInstanceId) {
		HistoricProcessInstance processInstance = getActivitiProcessInstance(processInstanceId);

		List<HistoricActivityInstance> activities = this.historyService
				.createHistoricActivityInstanceQuery().processInstanceId(processInstanceId)
				.orderByHistoricActivityInstanceStartTime().desc()
				.list();

		ProcessInstance procInstance = new ProcessInstance();
		Events events = new Events();

		logger
		.info("Number of HistoricActivityInstance from Activiti - " + activities.size());

		for (HistoricActivityInstance activInstan : activities) {
			// Filter start,end,gateway,timer activityTypes
			if ((activInstan != null)
					&& (Arrays.asList(FILTER_ACTIVITY_TYPES)
							.contains(activInstan.getActivityType()))) {
				events.getEvents().add(
						createEventFromHistoricActivityInstance(activInstan, processInstanceId));
			}
		}
		logger.info("Number of Events are  - " + events.getEvents().size());

		if (this.tngServiceTransformer.isProcessInstanceTNG(processInstance)) {
			this.tngServiceTransformer.enrichTNGHistoryCall(processInstance, events);
		}

		procInstance.setEvents(events);
		logger.info("Number of Events are  - " + events.getEvents().size());
		logger.debug("getTasks method END ");
		return procInstance;
	}

	private Event createEventFromHistoricActivityInstance(
			HistoricActivityInstance histActiviti, String processInstanceId) {
		Event event = this.conversionService.convert(histActiviti, Event.class);
		String title = event.getTitle();
		HistoricVariableInstance variable = null;
		// Check for dynamic variable replacement
		if ((title != null) && title.contains(Constants.DOLLAR)) {
			String dynamicVarName = getVarName(event.getTitle());

			variable = this.historyService
					.createHistoricVariableInstanceQuery().executionId(event.getExecutionId()).variableName(dynamicVarName).singleResult();
			logger.info("HistoricVariable for execution - "+event.getExecutionId() + " is  " +variable);

			if(variable == null){
				variable = this.historyService.createHistoricVariableInstanceQuery().processInstanceId(processInstanceId).variableName(dynamicVarName).singleResult();
				logger.info("Retrieved HistoricVariable for ProcessInstanceId - "+processInstanceId + ", " +variable);
			}

			String dynamicVarValue = null;
			String varName = null;
			if ((variable != null)  && variable.getVariableName().equals(dynamicVarName)) {
				dynamicVarValue = (String) variable.getValue();
				logger.info("Variable Name - " +variable.getVariableName()  +", Variable Value - " + dynamicVarValue);
				varName = Constants.DOLLAR + "{" + dynamicVarName + "}";
				title = title.replace(varName, dynamicVarValue);
				logger.info("Updated Event Name - " + title);
				event.setTitle(title);
			}
		}
		return event;
	}

	private String getVarName(String eventName) {

		int ind1 = eventName.lastIndexOf("$") + 2;
		int ind2 = eventName.lastIndexOf("}");

		String varName = eventName.substring(ind1, ind2);
		logger.info("Dynamic Variable Name - " + varName);
		return varName;

	}

}