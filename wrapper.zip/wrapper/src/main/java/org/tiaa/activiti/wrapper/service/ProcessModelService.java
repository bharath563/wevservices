package org.tiaa.activiti.wrapper.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.activiti.domain.editor.AppModelDefinition;
import com.activiti.model.editor.AppDefinitionPublishRepresentation;
import com.activiti.model.editor.AppDefinitionRepresentation;
import com.activiti.model.editor.AppDefinitionSaveRepresentation;
import com.activiti.model.editor.ModelRepresentation;
import com.activiti.service.editor.AlfrescoAppDefinitionService;
import com.activiti.service.editor.AlfrescoModelService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.pvm.activiti_wrapper_v1_0.types.AppProcessMapping;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.AppProcessMappings;

@Component
public class ProcessModelService {

	public static final Logger logger = Logger
			.getLogger(ProcessModelService.class);

	@Autowired
	AlfrescoAppDefinitionService appDefinitionService;

	@Autowired
	AlfrescoModelService alfrescoModelService;

	public void deployApp(final AppProcessMappings appProcessMappings) {
		Map<Long, AppDefinitionRepresentation> appDefReps = getAppDefRepresentation(appProcessMappings);

		// Iterate for each App.
		for (AppProcessMapping mapping : appProcessMappings
				.getAppProcessMappings()) {

			Long appId = Long.parseLong(mapping.getAppId());
			AppDefinitionRepresentation appDef = appDefReps.get(appId);

			if (appDef.getDefinition().getModels() == null) {
				appDef.getDefinition().setModels(
						new ArrayList<AppModelDefinition>());
			}

			List<String> deploydProcessKeys = getProcessKeysInApp(appDef);

			for (String processDefId : mapping.getProcessId()) {
				logger.info("Trying to check for Process Def Model Id "
						+ processDefId);
				ModelRepresentation processDef = this.alfrescoModelService
						.getModel(Long.parseLong(processDefId), false);

				if (!deploydProcessKeys.contains(processDef.getName())) {
					mapProcessToApp(appDef, processDef);
				}
			}

			if (StringUtils.isEmpty(appDef.getDefinition().getIcon())) {
				appDef.getDefinition().setIcon("glyphicon-asterisk");
			}

			if (StringUtils.isEmpty(appDef.getDefinition().getTheme())) {
				appDef.getDefinition().setTheme("theme-1");
			}

			// Save App First and Later Publish it
			AppDefinitionSaveRepresentation updatedApp = new AppDefinitionSaveRepresentation();
			updatedApp.setAppDefinition(appDef);
			this.appDefinitionService.updateAppDefinition(appId, updatedApp);

			AppDefinitionPublishRepresentation publishModel = new AppDefinitionPublishRepresentation();
			publishModel.setForce(true);
			this.appDefinitionService.publishAppDefinition(appId, publishModel);
		}
	}

	private Map<Long, AppDefinitionRepresentation> getAppDefRepresentation(
			AppProcessMappings appProcessMappings) {
		Map<Long, AppDefinitionRepresentation> appDefReps = new HashMap<Long, AppDefinitionRepresentation>();

		for (AppProcessMapping mapping : appProcessMappings
				.getAppProcessMappings()) {
			Long appId = Long.parseLong(mapping.getAppId());
			logger.info("***** App Id:" + appId + " : Process Ids :"
					+ mapping.getProcessId());
			if (!appDefReps.containsKey(appId)) {
				AppDefinitionRepresentation appDef = this.appDefinitionService
						.getAppDefinition(appId);
				appDefReps.put(appId, appDef);
			}
		}

		return appDefReps;
	}

	private List<String> getProcessKeysInApp(
			final AppDefinitionRepresentation appDef) {
		List<String> processKeys = new ArrayList<String>();

		for (AppModelDefinition appModelDef : appDef.getDefinition()
				.getModels()) {
			processKeys.add(appModelDef.getName());
		}

		return processKeys;
	}

	private void mapProcessToApp(AppDefinitionRepresentation appDef,
			ModelRepresentation processDef) {

		AppModelDefinition appModDef = new AppModelDefinition();
		appModDef.setId(processDef.getId());
		appModDef.setCreatedBy(processDef.getCreatedBy());
		appModDef.setCreatedByFullName(processDef.getCreatedByFullName());
		appModDef.setDescription(processDef.getDescription());
		appModDef.setLastUpdated(processDef.getLastUpdated());
		appModDef.setLastUpdatedBy(processDef.getLastUpdatedBy());
		appModDef.setLastUpdatedByFullName(processDef
				.getLastUpdatedByFullName());
		appModDef.setModelType(processDef.getModelType());
		appModDef.setName(processDef.getName());
		appModDef.setStencilSetId(processDef.getStencilSet());
		appModDef.setVersion(processDef.getVersion());

		appDef.getDefinition().getModels().add(appModDef);
	}
}
