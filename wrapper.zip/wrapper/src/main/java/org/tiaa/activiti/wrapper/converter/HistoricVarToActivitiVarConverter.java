package org.tiaa.activiti.wrapper.converter;

import static org.tiaa.activiti.wrapper.util.Constants.*;

import java.util.Date;

import org.activiti.engine.history.HistoricVariableInstance;

import org.apache.log4j.Logger;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;

@Component
public class HistoricVarToActivitiVarConverter implements
		Converter<HistoricVariableInstance, ActivitiVariable> {

	public static final Logger logger = Logger
			.getLogger(HistoricVarToActivitiVarConverter.class);

	@Override
	public ActivitiVariable convert(HistoricVariableInstance hisVar) {
		logger.debug("Method start ");
		if (hisVar == null) {
			return null;
		}

		ActivitiVariable variable = new ActivitiVariable();
		logger.debug("Variable Name - " + hisVar.getVariableName());

		variable.setName(hisVar.getVariableName());

		Object varValue = hisVar.getValue();

		if (BOOLEAN_TYPE.equalsIgnoreCase(hisVar.getVariableTypeName())) {
			variable.setValue(String.valueOf(varValue));
			variable.setType(BOOLEAN_TYPE);
		}
		else if ("bytes".equalsIgnoreCase(hisVar.getVariableTypeName())) {
			variable.setValue(new String((byte[]) varValue));
			variable.setType(CLOB_TYPE);
		}
		else if ("serializable".equalsIgnoreCase(hisVar.getVariableTypeName())) {
			// Commenting out supporting XMLGregCalendar types
			/*
			 * if (varValue instanceof XMLGregorianCalendar) {
			 * XMLGregorianCalendar calendar = (XMLGregorianCalendar) varValue;
			 * variable.setValue(DateUtil.convertDateToString(calendar));
			 * variable.setType(DATE_TYPE);
			 * }
			 */
		}
		else if ("double".equalsIgnoreCase(hisVar.getVariableTypeName())) {
			variable.setValue(String.valueOf(varValue));
			variable.setType(DECIMAL_TYPE);
		}
		else if ("integer".equalsIgnoreCase(hisVar.getVariableTypeName())) {
			variable.setValue(String.valueOf(varValue));
			variable.setType("integer");
		}
		else if ("date".equalsIgnoreCase(hisVar.getVariableTypeName())) {
			Date date = (Date) varValue;
			variable.setValue(date.getTime() + "");
			variable.setType(DATE_TYPE);
		}
		else {
			variable.setValue(varValue != null ? String.valueOf(varValue) : null);
			variable.setType(STRING);
		}

		logger.debug("Method end ");
		return variable;
	}
}
