package org.tiaa.activiti.wrapper.util;

public class Constants {

	public static final String DATE_FORMAT_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";

	public static final String DOCUMENT_VARIABLE_NAME = "activiti_Internal_Document";

	public static final String INITIATOR_VARIABLE_NAME = "initiator";

	public static final String STATUS_COMPLETED = "COMPLETED";

	public static final String STATUS_IN_PROGRESS = "IN-PROGRESS";

	public static final String STATUS_OPEN = "OPEN";

	public static final String EVENT_TYPE_TASK = "Task";

	public static final String EVENT_TYPE_COMMENT = "Comment";

	public static final String JSON_CONTENT_TYPE = "application/json";

	public static final String XML_CONTENT_TYPE = "application/xml";

	public static final String TASK_ASSIGNED = "assigned";

	public static final String END = "End";

	public static final String START = "Start";

	public static final String BOOLEAN_TYPE = "Boolean";

	public static final String CLOB_TYPE = "Clob";

	public static final String DATE_TYPE = "Date";

	public static final String DECIMAL_TYPE = "Decimal";

	public static final String STRING = "String";

	public static final String FALSE = "false";

	public static final String TIAA_LOGGED_IN_USER_HEADER = "tiaa_user";

	public static final String LOCK_VARIABLE_NAME = "activiti_Internal_LockVariable";

	public static final String TNGRECEIVE_UI_VARIABLE_NAME = "activiti_Internal_ReceiveTaskUserId";

	public static final String DOLLAR = "$";

	public static final String START_EVENT_TYPE = "startEvent";

	public static final String END_EVENT_TYPE = "endEvent";

	public static final String GATEWAY_EVENT_TYPE = "Gateway";

	public static final String TIMER_EVENT_TYPE = "Timer";

	private Constants() {
		// Intentionally left blank.
	}

}
