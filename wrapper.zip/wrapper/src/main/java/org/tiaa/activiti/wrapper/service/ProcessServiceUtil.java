package org.tiaa.activiti.wrapper.service;

import org.activiti.engine.RepositoryService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.repository.ProcessDefinition;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ProcessServiceUtil {

	@Autowired
	protected RepositoryService repositoryService;

	public String getProcessDefinitionKey(final HistoricProcessInstance processInstance) {

		if (processInstance == null) {
			return null;
		}

		ProcessDefinition definition = this.repositoryService.createProcessDefinitionQuery()
				.processDefinitionId(processInstance.getProcessDefinitionId()).singleResult();

		return definition.getKey();
	}

}
