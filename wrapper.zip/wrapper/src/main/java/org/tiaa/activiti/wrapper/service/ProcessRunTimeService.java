package org.tiaa.activiti.wrapper.service;

import java.util.Map;

import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComment;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariables;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.CTHEvent;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstances;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTask;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.Signal;

/**
 * This is an interface providing methods to access Runtime information about
 * the current processInstances.
 *
 * @author subashr
 *
 */
public interface ProcessRunTimeService {

	/**
	 * This method starts the ProcessInstance with processName/message and
	 * businessKey
	 *
	 * @param process
	 * @param userId
	 * @return
	 */
	public ProcessInstance startProcessInstance(final ProcessInstance process);

	/**
	 * This method signals the ReceiveTask
	 *
	 * @param signal
	 * @param userId
	 */
	public ProcessInstance signalReceiveTask(final Signal signal);

	/**
	 * This method signals the Message Wait Task
	 *
	 * @param signal
	 * @param userId
	 */
	public ProcessInstance signalMessage(final Signal signal);

	/**
	 * This method adds a document for a given processInstanceId
	 *
	 * @param document
	 * @param processInstanceId
	 * @param userId
	 * @return
	 */
	public ActivitiVariable addDocument(final ActivitiVariable document,
			String processInstanceId);

	/**
	 * This method adds a comment to the given processInstanceId
	 *
	 * @param comment
	 * @param processInstanceId
	 * @param userId
	 * @return
	 */
	public ActivitiComment addProcessInstanceComment(
			final ActivitiComment comment, final String processInstanceId);

	/**
	 * This method adds a comment to a given task
	 *
	 * @param comment
	 * @param processInstanceId
	 * @param taskId
	 * @param userId
	 * @return
	 */
	public ActivitiComment addTaskComment(final ActivitiComment comment,
			final String processInstanceId, final String taskId);

	/**
	 * This method claims the Tasks associated to the given user and the
	 * processInstanceId.
	 *
	 * @param processInstanceId
	 * @param taskId
	 * @param userId
	 * @return
	 */
	public ProcessTask claimTask(final String processInstanceId,
			final String taskId);

	/**
	 * This method completes the Task associated to the given user under the
	 * processInstanceId
	 *
	 * @param processInstanceId
	 * @param taskId
	 * @param vars
	 * @param userId
	 * @return
	 */

	public ProcessTask unclaimTask(final String processInstanceId,
			final String taskId);

	/**
	 * This method completes the Task associated to the given user under the
	 * processInstanceId
	 *
	 * @param processInstanceId
	 * @param taskId
	 * @param vars
	 * @param userId
	 * @return
	 */

	public ProcessTask completeTask(final String processInstanceId,
			final String taskId, final ActivitiVariables vars);

	/**
	 * This method updates the task associated with the given ProcessInstanceId
	 * with the variables.
	 *
	 * @param processInstanceId
	 * @param taskId
	 * @param vars
	 * @param userId
	 * @return
	 */
	public ProcessTask updateTask(final String processInstanceId,
			final String taskId, final ActivitiVariables vars);

	/**
	 * This method updates the Process associated to the given ProcessInstanceId
	 * with the variables.
	 *
	 * @param processInstanceId
	 * @param vars
	 * @param string
	 * @param string
	 * @return
	 */
	public void updateProcess(final String processInstanceId,
			final ActivitiVariables vars, String action);

	/**
	 * This method correlates the CTHUpdateEvents based on messageName and
	 * processInstanceId
	 *
	 * @param signal
	 * @param userId
	 */
	public ProcessInstance updateCTHEvent(final CTHEvent event);

	public void signal(String processId, String signalName,
			Map<String, Object> variables);

	/**
	 * This method retrieves all the process instances associated to a given
	 * processDefinitionId
	 * @param processes
	 * @return ProcessInstances
	 */
	public ProcessInstances retrieveProcessInstance(final ProcessInstances processes);


}
