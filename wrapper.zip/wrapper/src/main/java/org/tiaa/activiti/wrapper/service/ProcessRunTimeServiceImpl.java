package org.tiaa.activiti.wrapper.service;

import static org.tiaa.activiti.wrapper.util.Constants.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.activiti.engine.ActivitiException;
import org.activiti.engine.HistoryService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.Execution;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.IdentityLink;
import org.activiti.engine.task.Task;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.activiti.domain.idm.Group;
import com.activiti.domain.idm.User;
import com.activiti.service.api.UserService;
import com.activiti.service.exception.BadRequestException;
import com.activiti.service.exception.ConflictingRequestException;
import com.activiti.service.exception.NotFoundException;
import com.activiti.service.exception.UnauthorizedException;
import com.activiti.service.runtime.AlfrescoCommentService;
import com.activiti.service.runtime.CommentService;
import com.activiti.service.runtime.ProcessInstanceService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;

import org.tiaa.activiti.wrapper.transformer.TNGServiceTransformer;
import org.tiaa.activiti.wrapper.util.UserUtils;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComment;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariables;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.CTHEvent;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstances;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTask;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.Signal;

@Component
public class ProcessRunTimeServiceImpl implements ProcessRunTimeService {

	public static final Logger logger = Logger
			.getLogger(ProcessRunTimeServiceImpl.class);

	public static final String TENANT_PREFIX = "tenant_";

	@Autowired
	protected RepositoryService repositoryService;

	@Autowired
	protected TaskService taskService;

	@Autowired
	protected HistoryService historyService;

	@Autowired
	protected RuntimeService runtimeService;

	@Autowired
	protected ProcessInstanceService processInstanceService;

	@Autowired
	AlfrescoCommentService alfrescoCommentService;

	@Autowired
	UserService userService;

	@Autowired
	ConversionService conversionService;

	@Autowired
	ProcessHistoryService processHistoryService;

	@Autowired
	CommentService commentService;

	@Autowired
	UserUtils userUtils;

	@Autowired
	TNGServiceTransformer tngServiceTransformer;

	@Autowired
	LockService lockService;

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.tiaa.activiti.wrapper.service.ProcessRunTimeService#startProcessInstance
	 * (org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance,
	 * java.lang.String)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance startProcessInstance(
			final org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance process) {

		logger.debug("startProcessInstance method START ");

		Map<String, Object> variables = this.conversionService.convert(
				process.getVariables(), Map.class);

		ProcessInstance processInstance = startProcessByKeyOrMessage(
				process.getProcessName(), process.getMessageName(),
				process.getBusinessKey(), variables);

		// Add comments to the ProcessInstance
		if (process.getComments() != null) {
			logger.debug("Adding " + process.getComments().getComment().size()
					+ "  Comments  to a process");
			for (ActivitiComment comment : process.getComments().getComment()) {
				addProcessInstanceComment(comment, processInstance.getId());
			}
		}

		logger.debug("startProcessInstance method END ");

		return this.processHistoryService.getProcessInstance(
				processInstance.getId(), String.valueOf(FALSE), false);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.tiaa.activiti.wrapper.service.ProcessRunTimeService#addDocument(org
	 * .tiaa.pvm.activiti_wrapper_v1_0.types.Variable, java.lang.String)
	 */
	@Override
	public ActivitiVariable addDocument(final ActivitiVariable document,
			String processInstanceId) {
		logger.debug("addDocument method START ");

		// call getProcess / to check if process with the given instance exists
		getRuntimeProcessInstance(processInstanceId);
		logger.info("Inserting activiti_Internal_Document variable with value - "
				+ document.getValue());
		this.runtimeService.setVariable(processInstanceId, document.getName(),
				document.getValue());

		logger.debug("addDocument method END ");

		return document;
	}

	/**
	 * This method returns the HistoricProcessInstance associated to the
	 * ProcessInstanceId
	 *
	 * @param processInstanceId
	 * @return
	 */
	private List<Execution> getRuntimeProcessInstance(
			final String processInstanceId) {
		if (StringUtils.isBlank(processInstanceId)) {
			throw new NotFoundException("Process ID cannot be NULL or Blank");
		}

		List<Execution> executions = this.runtimeService.createExecutionQuery()
				.processInstanceId(processInstanceId).list();

		if ((executions == null) || (executions.size() == 0)) {
			throw new BadRequestException("No execution found for Process "
					+ processInstanceId);
		}
		return executions;
	}

	/**
	 * This method returns the HistoricProcessInstance associated to the
	 * ProcessInstanceId
	 *
	 * @param processInstanceId
	 * @return
	 */
	private HistoricProcessInstance getActivitiProcessInstance(
			final String processInstanceId) {
		if (StringUtils.isBlank(processInstanceId)) {
			throw new NotFoundException("Process ID cannot be NULL or Blank");
		}

		HistoricProcessInstance processInstance = this.historyService
				.createHistoricProcessInstanceQuery()
				.processInstanceId(processInstanceId).singleResult();

		if (processInstance == null) {
			throw new NotFoundException("Process " + processInstanceId
					+ " not found.");
		}
		return processInstance;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.tiaa.activiti.wrapper.service.ProcessRunTimeService#signalReceiveTask
	 * (java.lang.String, java.lang.String)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance signalReceiveTask(
			Signal signal) {

		logger.debug("signalReceiveTask method START ");

		List<Execution> ids = this.runtimeService.createExecutionQuery()
				.processInstanceId(signal.getProcessInstanceId()).list();

		// Get a list of execution with ProcessInstance id and not Activiti ID.
		// The reason is, while generating CorrelationID, text is converted into
		// lower cases and
		// searching directly will not find any records. So Get a list of
		// executions for given pid
		// and then do a equalsIgnorecase check
		Execution execId = null;
		for (Execution id : ids) {
			if (signal.getWaitTaskId().equalsIgnoreCase(id.getActivityId())) {
				execId = id;
			}
		}

		if (execId == null) {
			throw new NotFoundException("ExecutionId "
					+ signal.getProcessInstanceId()
					+ " not found for activiti id " + signal.getWaitTaskId());
		}

		Map<String, Object> variables = this.conversionService.convert(
				signal.getVariables(), Map.class);

		this.runtimeService.signal(execId.getId(), variables);

		return this.processHistoryService.getProcessInstance(
				signal.getProcessInstanceId(), String.valueOf(FALSE), false);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.tiaa.activiti.wrapper.service.ProcessRunTimeService#
	 * addProcessInstanceComment
	 * (org.tiaa.pvm.activiti_wrapper_v1_0.types.Comment, java.lang.String,
	 * java.lang.String)
	 */
	@Override
	public ActivitiComment addProcessInstanceComment(ActivitiComment comment,
			String processInstanceId) {
		logger.debug("addProcessInstanceComment method START ");

		return addComment(comment, processInstanceId, null);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.tiaa.activiti.wrapper.service.ProcessRunTimeService#addTaskComment
	 * (org.tiaa.pvm.activiti_wrapper_v1_0.types.Comment, java.lang.String,
	 * java.lang.String, java.lang.String)
	 */
	@Override
	public ActivitiComment addTaskComment(ActivitiComment comment,
			String processInstanceId, String taskId) {
		logger.debug("addTaskComment method START ");

		return addComment(comment, processInstanceId, taskId);
	}

	/**
	 * This method adds a comment to a processInstance and to a task.
	 *
	 * @param comment
	 * @param processInstanceId
	 * @param taskId
	 * @param userId
	 * @return
	 */
	private ActivitiComment addComment(ActivitiComment comment,
			String processInstanceId, String taskId) {

		logger.debug("addComment method START ");

		User user = this.userUtils.getSessionUser();

		// call getProcess / to check if process with the given instance exists
		// or not
		getActivitiProcessInstance(processInstanceId);

		// call to check if an active task exists with the given taskId
		if (taskId != null) {
			getTask(processInstanceId, taskId);
		}

		com.activiti.domain.runtime.Comment actiComment = this.commentService
				.createComment(comment.getMessage(), user, taskId,
						processInstanceId);
		logger.info("Sucessfully added comment with id - "
				+ actiComment.getId());

		logger.debug("addComment method END ");

		// Convert com.activiti.domain.runtime.Comment to ActivitiComment and
		// return it back
		return this.conversionService.convert(actiComment,
				ActivitiComment.class);

	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.tiaa.activiti.wrapper.service.ProcessRunTimeService#claimTask(java
	 * .lang.String, java.lang.String)
	 */
	@Override
	public ProcessTask claimTask(String processInstanceId, String taskId) {

		logger.debug("claimTask method START ");
		Task task = getActiveTask(processInstanceId, taskId);
		User user = this.userUtils.getSessionUser();

		// Verify if the user has access

		if (!ifUserHasAccessToTask(taskId, user)) {
			logger.error("User " + user.getExternalId() + " of Id:"
					+ user.getId() + " Task Id " + task.getId()
					+ " Task Assignee " + task.getAssignee()
					+ " doesn't have access.");
			throw new UnauthorizedException("User " + user.getExternalId()
					+ " doesnt have access to claim task " + taskId);
		}

		this.taskService.claim(taskId, String.valueOf(user.getId()));

		return this.processHistoryService.getTask(processInstanceId, taskId);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.tiaa.activiti.wrapper.service.ProcessRunTimeService#unclaimTask(java
	 * .lang.String, java.lang.String)
	 */
	@Override
	public ProcessTask unclaimTask(String processInstanceId, String taskId) {

		logger.debug("unclaimTask method START ");
		Task task = getActiveTask(processInstanceId, taskId);
		User user = this.userUtils.getSessionUser();

		this.taskService.unclaim(taskId);

		return this.processHistoryService.getTask(processInstanceId, taskId);
	}

	private boolean ifUserHasAccessToTask(final String taskId, User user) {

		boolean hasAccess = false;
		List<IdentityLink> idLinks = this.taskService
				.getIdentityLinksForTask(taskId);

		List<String> groupIds = new ArrayList<String>();
		for (Group group : user.getGroups()) {
			groupIds.add(String.valueOf(group.getId()));
		}

		logger.info("ID Links for User " + user.getId() + ": " + idLinks
				+ "  Group Links :" + groupIds);

		for (IdentityLink link : idLinks) {
			logger.info("ID Link for User " + user.getId() + ": "
					+ link.getUserId() + "-" + link.getGroupId());
			if (String.valueOf(user.getId()).equals(link.getUserId())
					|| groupIds.contains(link.getGroupId())) {
				hasAccess = true;
				break;
			}
		}

		return hasAccess;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.tiaa.activiti.wrapper.service.ProcessRunTimeService#completeTask(
	 * java.lang.String, java.lang.String,
	 * org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariables,
	 * java.lang.String)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public ProcessTask completeTask(String processInstanceId, String taskId,
			ActivitiVariables vars) {
		logger.debug("completeTask method START ");

		Task task = getActiveTask(processInstanceId, taskId);

		if ((task.getAssignee() == null)) {
			throw new BadRequestException(
					"Task needs to be claimed before completing");
		}

		User user = this.userUtils.getSessionUser();
		if (!String.valueOf(user.getId()).equalsIgnoreCase(task.getAssignee())) {
			logger.error("User " + user.getExternalId()
					+ " doesnt have access to complete task " + taskId
					+ ". Its assigned to :" + task.getAssignee()
					+ ": And User I got is :" + user.getId() + ":");
			throw new UnauthorizedException("User " + user.getExternalId()
					+ " doesnt have access to complete task " + taskId);
		}

		Map<String, Object> variables = this.conversionService.convert(vars,
				Map.class);
		this.taskService.complete(taskId, variables);

		return this.processHistoryService.getTask(processInstanceId, taskId);
	}

	/**
	 * This method returns the task associated to the ProcessInstanceId
	 *
	 * @param processInstanceId
	 * @param taskId
	 * @return
	 */
	private HistoricTaskInstance getTask(final String processInstanceId,
			String taskId) {
		if (StringUtils.isBlank(processInstanceId)) {
			throw new NotFoundException("Process ID cannot be NULL or Blank");
		}

		HistoricTaskInstance task = this.historyService
				.createHistoricTaskInstanceQuery()
				.processInstanceId(processInstanceId).taskId(taskId)
				.singleResult();
		if (task == null) {
			throw new NotFoundException("Task " + taskId
					+ " not found for ProcessInstanceId " + processInstanceId);
		}
		return task;
	}

	/**
	 * This method returns the task associated to the ProcessInstanceId
	 *
	 * @param processInstanceId
	 * @param taskId
	 * @return
	 */
	private Task getActiveTask(final String processInstanceId, String taskId) {
		if (StringUtils.isBlank(processInstanceId)) {
			throw new NotFoundException("Process ID cannot be NULL or Blank");
		}

		Task task = this.taskService.createTaskQuery().taskId(taskId)
				.processInstanceId(processInstanceId).singleResult();
		if (task == null) {
			throw new BadRequestException("No execution found for Task "
					+ taskId + " and ProcessInstanceId " + processInstanceId);
		}
		return task;
	}

	/**
	 * This method starts the Process with the processKey, message ,
	 * businesskey, and variables
	 *
	 * @param processkey
	 * @param message
	 * @param businessKey
	 * @param variables
	 * @return
	 */
	private ProcessInstance startProcessByKeyOrMessage(String processkey,
			String message, String businessKey, Map<String, Object> variables) {

		logger.debug("startProcessByKeyOrMessage method START  ");
		logger.info("Inputs to start Process - " + "processkey - " + processkey
				+ " message - " + message + " businessKey - " + businessKey);

		ProcessInstance processInstance = null;
		User user = this.userUtils.getSessionUser();

		try {
			if (processkey != null) {
				ProcessDefinition processDefinition = this.repositoryService
						.createProcessDefinitionQuery()
						.processDefinitionKey(processkey).active()
						.latestVersion().singleResult();

				if (processDefinition == null) {
					throw new BadRequestException(
							"No Process Definition found for Key '"
									+ processkey + "'");
				}

				logger.debug("Executing by key");
				processInstance = this.runtimeService.startProcessInstanceById(
						processDefinition.getId(), businessKey, variables);
			} else {

				logger.debug("Executing by Message");
				processInstance = this.runtimeService
						.startProcessInstanceByMessageAndTenantId(message,
								businessKey, variables, getUserTenant(user));
				logger.debug("Response:" + processInstance);
			}
		} catch (ActivitiException ae) {
			ae.printStackTrace();
			throw new BadRequestException(
					"Error Creating Process with Message :" + message, ae);
		}
		logger.debug("startProcessByKeyOrMessage method END ");

		return processInstance;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.tiaa.activiti.wrapper.service.ProcessRunTimeService#updateTask(java
	 * .lang.String, java.lang.String,
	 * org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariables,
	 * java.lang.String)
	 */
	@Override
	@SuppressWarnings("unchecked")
	public ProcessTask updateTask(String processInstanceId, String taskId,
			ActivitiVariables vars) {
		getActiveTask(processInstanceId, taskId);
		Map<String, Object> variables = this.conversionService.convert(vars,
				Map.class);
		this.taskService.setVariablesLocal(taskId, variables);
		return this.processHistoryService.getTask(processInstanceId, taskId);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see
	 * org.tiaa.activiti.wrapper.service.ProcessRunTimeService#updateProcess
	 * (java.lang.String,
	 * org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariables,
	 * java.lang.String)
	 */

	@Override
	@SuppressWarnings("unchecked")
	public void updateProcess(String processInstanceId, ActivitiVariables vars,
			String action) {
		logger.debug("ProcessInstanceId: " + processInstanceId + " Action:"
				+ action);
		getRuntimeProcessInstance(processInstanceId);
		Map<String, Object> variables = this.conversionService.convert(vars,
				Map.class);
		HistoricProcessInstance processInstance = getActivitiProcessInstance(processInstanceId);

		if (!this.lockService.isProcessUnLockable(processInstanceId)) {
			throw new ConflictingRequestException(
					"Process already locked by other user.");
		}

		if ("update".equalsIgnoreCase(action)) {
			if (this.tngServiceTransformer
					.isProcessInstanceTNG(processInstance)) {
				logger.debug("Updating TNG Process");
				this.tngServiceTransformer.updateProcess(processInstanceId,
						variables);
			} else {
				logger.debug("Updating non TNG Process");
				if (variables != null) {
					this.runtimeService.setVariables(processInstanceId,
							variables);
				}
			}
		}

		this.lockService.unlockProcess(processInstanceId);
	}

	private String getUserTenant(final User user) {
		return TENANT_PREFIX + user.getTenantId();
	}

	@Override
	public org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance updateCTHEvent(
			CTHEvent event) {
		logger.debug("updateCTHEvent method START ");

		if (event.getProcessInstanceIds().size() == 0) {
			logger.error("No valid processInstanceId found for updating CTHEvent for Event - "
					+ event.getMessageName());
			throw new BadRequestException(
					"No valid processInstanceId found for updating CTHEvent for Event - "
							+ event.getMessageName());
		}
		if (StringUtils.isEmpty(event.getMessageName())) {
			logger.error("No valid MessageName found for the CTHEvent");
			throw new BadRequestException(
					"No valid MessageName found for the CTHEvent");
		}

		logger.info("Number of ProcessInstanceId's  -"
				+ event.getProcessInstanceIds().size());
		org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance procInstance = null;
		for (String processId : event.getProcessInstanceIds()) {

			Execution execution = this.runtimeService.createExecutionQuery()
					.processInstanceId(processId)
					.messageEventSubscriptionName(event.getMessageName())
					.singleResult();
			// Assumption is that there is only one Execution

			if (execution != null) {
				logger.info("Execution - " + execution.getId());
				Map<String, Object> variables = this.conversionService.convert(
						event.getVariables(), Map.class);

				logger.info("*********** Variables Map : " + variables);
				// To set variables at global scope
				this.runtimeService.setVariables(processId, variables);

				variables = new HashMap<String, Object>();

				this.runtimeService.messageEventReceived(
						event.getMessageName(), execution.getId(), variables);
				procInstance = this.processHistoryService.getProcessInstance(
						processId, String.valueOf(FALSE), false);
			} else {
				throw new NotFoundException("No Execution found for Message "
						+ event.getMessageName() + ". Process ID:" + processId);
			}
		}
		return procInstance;
	}

	@Override
	public org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance signalMessage(
			Signal signal) {

		Map<String, Object> variables = this.conversionService.convert(
				signal.getVariables(), Map.class);
		signal(signal.getProcessInstanceId(), signal.getWaitTaskId(), variables);
		return this.processHistoryService.getProcessInstance(
				signal.getProcessInstanceId(), String.valueOf(FALSE), false);
	}

	@Override
	public void signal(String processId, String signalName,
			Map<String, Object> variables) {
		Execution execution = this.runtimeService.createExecutionQuery()
				.processInstanceId(processId)
				.messageEventSubscriptionName(signalName).singleResult();

		if (execution == null) {
			throw new NotFoundException("No Execution found for Message "
					+ signalName + " in proces " + processId);
		}

		this.runtimeService.messageEventReceived(signalName, execution.getId(),
				variables);

	}

	/* (non-Javadoc)
	 * @see org.tiaa.activiti.wrapper.service.ProcessRunTimeService#retrieveProcessInstance(org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstances)
	 */
	@Override
	public ProcessInstances retrieveProcessInstance(ProcessInstances processes) {
		logger.debug("retrieveProcessInstance method START ");


		if((processes == null) || (processes.getProcessInstance().size() == 0)){
			logger.error("No valid process definition keys found to retrieve the processInstances");
			throw new BadRequestException("No valid process definition keys found to retrieve the processInstances");
		}
		ProcessInstances procInstances = new ProcessInstances();

		List<ProcessDefinition> processDefinitions = null;
		for(org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance procInst : processes.getProcessInstance()){

			processDefinitions = this.repositoryService.createProcessDefinitionQuery().processDefinitionKeyLike(procInst.getProcessName()).active().list();

			if (processDefinitions == null) {
				logger.error("No Process Definition found for Key '"+ procInst.getProcessName() + "'");
			}else{

				for(ProcessDefinition def : processDefinitions){
					org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance newProcDef = new org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance();
					newProcDef.setProcessDefinitionId(def.getId());
					procInstances.getProcessInstance().add(newProcDef);
				}
			}
		}
		logger.debug("retrieveProcessInstance method END ");
		return procInstances;

	}


}
