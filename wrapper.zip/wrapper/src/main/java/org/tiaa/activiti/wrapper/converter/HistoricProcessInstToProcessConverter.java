package org.tiaa.activiti.wrapper.converter;

import static org.tiaa.activiti.wrapper.util.Constants.*;

import java.util.Date;

import org.activiti.engine.history.HistoricProcessInstance;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.util.DateUtil;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.User;

/**
 * This is a converter class which converts HistoricProcessInstance to
 * org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance
 *
 * @author pamdama
 *
 */
@Component
public class HistoricProcessInstToProcessConverter
implements
Converter<HistoricProcessInstance, org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance> {

	@Override
	public org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance convert(
			HistoricProcessInstance source) {
		if (source == null) {
			return null;
		}
		org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance process = new org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance();
		process.setProcessInstanceId(source.getId());
		process.setStatus(createStatus(source.getEndTime()));

		process.setStartTime(DateUtil.convertStringToDate(source.getStartTime()));
		process.setEndTime(DateUtil.convertStringToDate(source.getEndTime()));
		process.setBusinessKey(source.getBusinessKey());
		if (source.getStartUserId() != null) {
			User user = new User();
			user.setUserId(source.getStartUserId());
			process.setInitiatedBy(user);
		}
		process.setProcessName(source.getName());
		return process;
	}

	/**
	 * This method calculates the status based on the EndTime.
	 *
	 * @param endTime
	 * @return
	 */
	private String createStatus(final Date endTime) {

		String status = null;
		if (endTime != null) {
			status = STATUS_COMPLETED;
		} else {
			status = STATUS_OPEN;
		}
		// TODO: how to verify for other status.
		return status;
	}

}
