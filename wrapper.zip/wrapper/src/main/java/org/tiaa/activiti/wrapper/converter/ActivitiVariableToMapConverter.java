package org.tiaa.activiti.wrapper.converter;

import java.util.HashMap;
import java.util.Map;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.util.DateUtil;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariables;

@Component
public class ActivitiVariableToMapConverter implements
Converter<ActivitiVariables, Map<String, Object>> {

	@Override
	public Map<String, Object> convert(ActivitiVariables vars) {

		Map<String, Object> variablesMap = new HashMap<String, Object>();

		if ((vars == null) || (vars.getVariable() == null)
				|| (vars.getVariable().size() == 0)) {
			return variablesMap;
		}

		for (ActivitiVariable variable : vars.getVariable()) {
			// Set value
			Object mapVal = null;
			if ("Boolean".equalsIgnoreCase(variable.getType())) {
				mapVal = Boolean.valueOf(variable.getValue());
			} else if ("Date".equalsIgnoreCase(variable.getType())) {
				mapVal = DateUtil.convertToDate(variable.getValue());
			} else if ("Decimal".equalsIgnoreCase(variable.getType())) {
				mapVal = Double.parseDouble(variable.getValue());
			} else if ("Integer".equalsIgnoreCase(variable.getType())) {
				mapVal = Integer.parseInt(variable.getValue());
			} else if ("Clob".equalsIgnoreCase(variable.getType())) {
				mapVal = variable.getValue().getBytes();
			} else {
				mapVal = variable.getValue();
			}

			variablesMap.put(variable.getName(), mapVal);
		}
		return variablesMap;
	}
}
