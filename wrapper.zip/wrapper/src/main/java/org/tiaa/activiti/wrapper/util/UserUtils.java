package org.tiaa.activiti.wrapper.util;

import java.util.List;

import org.activiti.engine.IdentityService;

import org.apache.log4j.Logger;

import com.activiti.domain.idm.Group;
import com.activiti.domain.idm.User;
import com.activiti.domain.idm.UserStatus;
import com.activiti.repository.idm.GroupRepository;
import com.activiti.security.SecurityUtils;
import com.activiti.service.api.UserService;
import com.activiti.service.exception.BadRequestException;
import com.activiti.service.exception.NotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import org.tiaa.pvm.activiti_wrapper_v1_0.types.Groups;

@Component
public class UserUtils {

	public static final Logger logger = Logger.getLogger(UserUtils.class);
	protected static ThreadLocal<User> userThreadLocal = new ThreadLocal<User>();

	@Autowired
	UserService userService;

	@Autowired
	protected IdentityService identityService;

	@Autowired
	protected GroupRepository groupRepo;

	@Value("${es.index.name}")
	private String esTenantId;

	public String getGroupId(final String groupName) {

		String tenantId = this.esTenantId.substring(this.esTenantId.lastIndexOf("_") + 1);

		List<com.activiti.domain.idm.Group> groups = this.groupRepo
				.findFunctionalGroupsByTenantId(Long.parseLong(tenantId));

		String groupId = "-1";
		for (com.activiti.domain.idm.Group group : groups) {
			if (group.getName().equalsIgnoreCase(groupName)) {
				groupId = group.getId().toString();
			}
		}

		logger.info(" Group Id for " + groupName + " is  " + groupId);
		return groupId;
	}

	public void assumeUser(final String userId) {
		User user = this.userService.findUserByExternalId(userId);

		if ((user == null) || !UserStatus.ACTIVE.equals(user.getStatus())) {
			logger.error("User " + userId + " Not Found or Inactive.");
			throw new BadRequestException("User " + userId + " Not Found or Inactive.");
		}

		this.identityService.setAuthenticatedUserId(String.valueOf(user.getId()));
		userThreadLocal.set(user);
	}

	public User getSessionUser() {

		if (userThreadLocal.get() != null) {
			return userThreadLocal.get();
		}

		throw new BadRequestException("User Information not found.");
	}

	public org.tiaa.pvm.activiti_wrapper_v1_0.types.User getUserById(final String userId) {

		if (userId == null) {
			return null;
		}

		User actUser = this.userService.findUser(Long.parseLong(userId));

		if (actUser == null) {
			return null;
		}

		org.tiaa.pvm.activiti_wrapper_v1_0.types.User pvmUser = new org.tiaa.pvm.activiti_wrapper_v1_0.types.User();
		pvmUser.setUserId(actUser.getExternalId());
		return pvmUser;
	}

	public String getUserExternalId(final String userId) {
		if (userId == null) {
			return null;
		}

		User actUser = this.userService.findUser(Long.parseLong(userId));

		if (actUser == null) {
			return null;
		}

		return actUser.getExternalId();
	}

	public boolean hasUserHasAccessToGroup(Long userId, String group) {
		if (userId == null) {
			return false;
		}

		User actUser = this.userService.getUser(userId);
		List<String> userCapabilities = this.userService.getUserCapabilities(userId);
		logger.info("user Capabilities: " + userCapabilities);
		if (actUser == null) {
			return false;
		}
		List<Group> groups = actUser.getGroups();
		logger.info("############### Groups ################## for userid: " + userId);
		for (Group grp : groups) {
			logger.info("GropName=" + grp.getName());
			if (grp.getName().equalsIgnoreCase(group)) {
				return true;
			}
		}

		return false;

	}

	public Groups getAllUserGroups() {
		User actUser = SecurityUtils.getCurrentUserObject();
		List<Group> actUserGroups = actUser.getGroups();
		Groups groups = new Groups();
		for (Group grp : actUserGroups) {
			org.tiaa.pvm.activiti_wrapper_v1_0.types.Group group = new org.tiaa.pvm.activiti_wrapper_v1_0.types.Group();
			group.setId(grp.getId().toString());
			group.setName(grp.getName());
			group.setExternalId(grp.getExternalId());
			groups.getGroup().add(group);

		}
		return groups;
	}

	public org.tiaa.pvm.activiti_wrapper_v1_0.types.Group getUserGroup(String groupName) {
		Groups groups = getAllUserGroups();

		org.tiaa.pvm.activiti_wrapper_v1_0.types.Group groupObj = null;
		for (org.tiaa.pvm.activiti_wrapper_v1_0.types.Group group : groups.getGroup()) {
			if (groupName.equalsIgnoreCase(group.getName())) {
				groupObj = group;
			}
		}

		if (groupObj == null) {
			throw new NotFoundException(
					"Group is not available or user doesnt have access to it");
		}

		return groupObj;
	}

}
