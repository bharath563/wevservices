package org.tiaa.activiti.wrapper.converter;

import org.apache.log4j.Logger;

import com.activiti.domain.runtime.Comment;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import org.tiaa.business.process.util.DateUtil;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComment;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.User;

@Component
public class CommentToActivitiComment implements
		Converter<Comment, ActivitiComment> {

	public static final Logger logger = Logger.getLogger(CommentToActivitiComment.class);

	@Override
	public ActivitiComment convert(Comment source) {

		if (source == null) {
			return null;
		}

		logger.info("Message - " + source.getMessage() + "CreateDate - "
				+ source.getCreated() + " ProcessInstanceId - "
				+ source.getProcessInstanceId() + " TaskId - "
				+ source.getTaskId());

		ActivitiComment comment = new ActivitiComment();
		comment.setCreateDate(DateUtil.convertStringToDate(source.getCreated()));
		comment.setMessage(source.getMessage());
		comment.setProcessInstanceId(source.getProcessInstanceId());
		comment.setTaskId(source.getTaskId());
		if ((source.getCreatedBy() != null)
				&& (source.getCreatedBy().getExternalId() != null)) {
			User user = new User();
			user.setUserId(String
					.valueOf(source.getCreatedBy().getExternalId()));
			comment.setCreatedBy(user);
		}

		return comment;

	}

}
