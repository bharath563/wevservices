package org.tiaa.activiti.wrapper.service;

import static org.tiaa.activiti.wrapper.util.Constants.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.activiti.engine.HistoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricVariableInstance;
import org.activiti.engine.runtime.Execution;

import org.apache.log4j.Logger;

import com.activiti.domain.idm.User;
import com.google.gson.GsonBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import org.tiaa.activiti.wrapper.util.Constants;
import org.tiaa.activiti.wrapper.util.UserUtils;

@Component
public class LockService {

	public static final Logger logger = Logger.getLogger(LockService.class);

	@Autowired
	HistoryService historyService;

	@Autowired
	protected RuntimeService runtimeService;

	@Autowired
	UserUtils userUtils;

	@Value("${lock.expiration.time}")
	private long expirationTime;

	public boolean isProcessLockable(HistoricProcessInstance processInstance,
			List<HistoricVariableInstance> variables) {
		logger.info("##################### InLockServiceIMPL.isProcessLockable:");

		if (processInstance.getEndTime() != null) {
			return false;
		}

		HistoricVariableInstance variable = getHistoricLockVar(variables);

		if ((variable == null) || (variable.getValue() == null)) {
			return true;
		}

		User user = this.userUtils.getSessionUser();

		LockVariable var = new GsonBuilder().create().fromJson((String) variable.getValue(),
				LockVariable.class);
		logger.info("Process Already Locked by: "
				+ var.getUserId()
				+ " Expired By: "
				+ var.getLockExpirationTime()
				+ "Current Time: "
				+ new Date()
				+ " Current User:"
				+ user.getId()
				+ " : Lock User:"
				+ var.getUserId()
				+ " : Final Condition :"
				+ (var.getLockExpirationTime().before(new Date()) || var.getUserId().equals(
						user.getId())));

		return var.getLockExpirationTime().before(new Date())
				|| var.getUserId().equals(user.getId());
	}

	public boolean isLockExpired(List<HistoricVariableInstance> variables) {
		logger.info("##################### InLockServiceIMPL.isLockExpired:");

		HistoricVariableInstance variable = getHistoricLockVar(variables);

		if ((variable == null) || (variable.getValue() == null)) {
			return true;
		}

		LockVariable var = new GsonBuilder().create().fromJson((String) variable.getValue(),
				LockVariable.class);

		return var.getLockExpirationTime().before(new Date());
	}

	private HistoricVariableInstance getHistoricLockVar(
			List<HistoricVariableInstance> variables) {
		for (HistoricVariableInstance activitiVar : variables) {
			if (activitiVar.getVariableName().equalsIgnoreCase(Constants.LOCK_VARIABLE_NAME)) {
				return activitiVar;
			}
		}
		return null;
	}

	public boolean isProcessUnLockable(String processInstanceId) {
		logger.info("##################### InLockServiceIMPL.isProcessUnLockable:");

		HistoricVariableInstance variable = this.historyService
				.createHistoricVariableInstanceQuery().processInstanceId(processInstanceId)
				.variableName(LOCK_VARIABLE_NAME).singleResult();

		if ((variable == null) || (variable.getValue() == null)) {
			return true;
		}

		String userId = this.userUtils.getSessionUser().getId().toString();

		boolean flag = false;
		LockVariable var = new GsonBuilder().create().fromJson((String) variable.getValue(),
				LockVariable.class);
		if (var.getLockExpirationTime().before(new Date())) {
			flag = true;
		}
		else if ((String.valueOf(var.getUserId())).equals(userId)) {
			flag = true;
		}
		return flag;
	}

	public void lockProcess(String processInstanceId, Long userId) {

		// TODO Need to add expirationLimitTime in properties
		logger.info("##### Locking process " + processInstanceId);
		Map<String, String> variables = new HashMap<String, String>();
		Date oldDate = new Date();
		Date lockExpirationTime = new Date(oldDate.getTime()
				+ TimeUnit.HOURS.toMillis(this.expirationTime));
		LockVariable lockVar = new LockVariable(userId, lockExpirationTime);
		String lockVarJsonStr = new GsonBuilder().create().toJson(lockVar);

		variables.put(Constants.LOCK_VARIABLE_NAME, lockVarJsonStr);

		this.runtimeService.setVariables(processInstanceId, variables);
	}

	public void unlockProcess(String processInstanceId) {

		Map<String, String> variables = new HashMap<String, String>();
		variables.put(Constants.LOCK_VARIABLE_NAME, null);

		Execution execution = this.runtimeService.createExecutionQuery()
				.executionId(processInstanceId).singleResult();

		if (execution != null) {
			this.runtimeService.setVariables(processInstanceId, variables);
		}
	}

	public String getLockOwner(List<HistoricVariableInstance> variables) {
		HistoricVariableInstance variable = getHistoricLockVar(variables);

		if ((variable == null) || (variable.getValue() == null)) {
			return null;
		}

		LockVariable var = new GsonBuilder().create().fromJson((String) variable.getValue(),
				LockVariable.class);
		return var.getUserId() == null ? null : this.userUtils.getUserExternalId(String
				.valueOf(var.getUserId()));
	}

}
