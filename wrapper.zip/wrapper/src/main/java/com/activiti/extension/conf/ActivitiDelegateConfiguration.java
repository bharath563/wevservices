package com.activiti.extension.conf;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

@Configuration
@ComponentScan("org.tiaa.activiti.*")
@PropertySources({
	@PropertySource(value = "classpath:BusinessProcessConfig.properties", ignoreResourceNotFound = false),
	@PropertySource(value = "classpath:NxtGenBusinessProcessGlobalEnvironment.properties", ignoreResourceNotFound = true),
	@PropertySource(value = "classpath:BusinessProcessConfigEnvironment.properties", ignoreResourceNotFound = false) })
public class ActivitiDelegateConfiguration {

}
