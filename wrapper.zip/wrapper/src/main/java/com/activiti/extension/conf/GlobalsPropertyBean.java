package com.activiti.extension.conf;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;

import org.springframework.stereotype.Component;

@Component
public class GlobalsPropertyBean {

	private Map<String, String> initMap = new HashMap<String, String>();

	private static final String GLOBAL_CONFIG_PROPERTIES = "NxtGenBusinessProcessGlobalEnvironment.properties";

	public static final Logger LOGGER = Logger
			.getLogger(GlobalsPropertyBean.class);

	@PostConstruct
	public void afterPropertiesSet() throws IOException {
		InputStream propsFile = Thread.currentThread().getContextClassLoader()
				.getResourceAsStream(GLOBAL_CONFIG_PROPERTIES);

		if (propsFile == null) {
			LOGGER.error("Properties file "
					+ GLOBAL_CONFIG_PROPERTIES
					+ " not found in classpath. Deployment will continue but uses of GlobalPropertyBean will always return null!!");
			return;
		}
		ResourceBundle resources = new PropertyResourceBundle(propsFile);

		// convert ResourceBundle to Map
		Enumeration<String> keys = resources.getKeys();
		while (keys.hasMoreElements()) {
			String key = keys.nextElement();
			this.initMap.put(key, resources.getString(key));
		}
	}

	public String getValue(final String key) {
		return this.initMap.get(key);
	}
}
