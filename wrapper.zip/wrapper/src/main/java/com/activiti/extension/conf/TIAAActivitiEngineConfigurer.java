package com.activiti.extension.conf;

import org.activiti.spring.SpringProcessEngineConfiguration;

import com.activiti.api.engine.ProcessEngineConfigurationConfigurer;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class TIAAActivitiEngineConfigurer implements
		ProcessEngineConfigurationConfigurer {

	// Activiti AsyncExecutor
	@Value("${activiti.asyncexecutor.enabled}")
	private String activitiAsyncExecutorEnabled;

	@Override
	public void processEngineConfigurationInitialized(
			SpringProcessEngineConfiguration arg0) {
		arg0.setAsyncExecutorEnabled(Boolean
				.valueOf(this.activitiAsyncExecutorEnabled));
	}
}