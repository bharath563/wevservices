package com.activiti.extension.api;

import static org.tiaa.activiti.wrapper.util.Constants.*;

import javax.ws.rs.QueryParam;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.activiti.service.exception.BadRequestException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import org.tiaa.activiti.wrapper.service.ProcessHistoryService;
import org.tiaa.activiti.wrapper.service.ProcessModelService;
import org.tiaa.activiti.wrapper.service.ProcessRunTimeService;
import org.tiaa.activiti.wrapper.util.UserUtils;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComment;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiComments;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariable;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ActivitiVariables;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.AppProcessMappings;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.CTHEvent;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.Group;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.Groups;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstance;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessInstances;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTask;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.ProcessTasks;
import org.tiaa.pvm.activiti_wrapper_v1_0.types.Signal;

@RestController
@RequestMapping(produces = { JSON_CONTENT_TYPE, XML_CONTENT_TYPE }, consumes = {
		JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
@ResponseStatus(HttpStatus.OK)
public class TIAAActivitiRestController {

	public static final Logger logger = Logger.getLogger(TIAAActivitiRestController.class);

	@Autowired
	ProcessRunTimeService processRuntimeService;

	@Autowired
	ProcessHistoryService processHistoryService;

	@Autowired
	ProcessModelService processModelService;

	@Autowired
	UserUtils userUtils;

	@RequestMapping(value = "/enterprise/tiaa-activiti-rs-v1/ping",
			method = RequestMethod.GET)
	public String ping() {
		return "{\"message\":\"Service Up & Running\"}";
	}

	@RequestMapping(value = "/enterprise/tiaa-activiti-rs-v1/usergroups",
			method = RequestMethod.GET, produces = { JSON_CONTENT_TYPE, XML_CONTENT_TYPE },
			consumes = { JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public Groups usergroups() {
		// return List of Groups
		// this.userUtils.assumeUser(userId);
		return this.userUtils.getAllUserGroups();
	}

	@RequestMapping(value = "/enterprise/tiaa-activiti-rs-v1/usergroup/{groupName}",
			method = RequestMethod.GET, produces = { JSON_CONTENT_TYPE, XML_CONTENT_TYPE },
			consumes = { JSON_CONTENT_TYPE, XML_CONTENT_TYPE })
	public Group getUserGroup(@PathVariable("groupName") String groupName) {
		// this.userUtils.assumeUser(userId);
		if (StringUtils.isBlank(groupName)) {
			throw new BadRequestException("Group Name cannot be Empty!");
		}
		return this.userUtils.getUserGroup(groupName);
	}

	@RequestMapping(value = "/enterprise/tiaa-activiti-rs-v1/process",
			method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public ProcessInstance startProcess(@RequestBody ProcessInstance process,
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId) {
		this.userUtils.assumeUser(userId);
		return this.processRuntimeService.startProcessInstance(process);
	}

	@RequestMapping(
			value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}/comment" },
			method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public ActivitiComment addProcessComment(@PathVariable("processId") String processId,
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestBody ActivitiComment comment) {
		this.userUtils.assumeUser(userId);
		return this.processRuntimeService.addProcessInstanceComment(comment, processId);
	}

	@RequestMapping(
			value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}/task/{taskId}/comment" },
			method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public ActivitiComment addTaskComment(@PathVariable("processId") String processId,
			@PathVariable("taskId") String taskId,
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestBody ActivitiComment comment) {
		this.userUtils.assumeUser(userId);
		return this.processRuntimeService.addTaskComment(comment, processId, taskId);
	}

	@RequestMapping(
			value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}/task/{taskId}/claim" },
			method = RequestMethod.PUT)
	public ProcessTask claimTask(@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@PathVariable("processId") String processId, @PathVariable("taskId") String taskId) {
		this.userUtils.assumeUser(userId);
		return this.processRuntimeService.claimTask(processId, taskId);
	}

	@RequestMapping(
			value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}/task/{taskId}/unclaim" },
			method = RequestMethod.PUT)
	public ProcessTask unclaimTask(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@PathVariable("processId") String processId, @PathVariable("taskId") String taskId) {
		this.userUtils.assumeUser(userId);
		return this.processRuntimeService.unclaimTask(processId, taskId);
	}

	@RequestMapping(
			value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}/task/{taskId}/complete" },
			method = RequestMethod.PUT)
	public ProcessTask completeTask(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@PathVariable("processId") String processId, @PathVariable("taskId") String taskId,
			@RequestBody ActivitiVariables variables) {
		this.userUtils.assumeUser(userId);
		return this.processRuntimeService.completeTask(processId, taskId, variables);
	}

	@RequestMapping(value = { "/enterprise/tiaa-activiti-rs-v1/signal" },
			method = RequestMethod.POST)
	public ProcessInstance signalProcess(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId, @RequestBody Signal signal) {
		this.userUtils.assumeUser(userId);
		return this.processRuntimeService.signalReceiveTask(signal);
	}

	@RequestMapping(value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}" },
			method = RequestMethod.GET)
	public ProcessInstance getProcess(@PathVariable("processId") String processId,
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@QueryParam("isHistoryEnabled") String isHistoryEnabled,
			@QueryParam("lock") boolean lock) {
		this.userUtils.assumeUser(userId);
		return this.processHistoryService.getProcessInstance(processId, isHistoryEnabled,
				lock);
	}

	@RequestMapping(
			value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}/comments" },
			method = RequestMethod.GET)
	public ActivitiComments getProcessComments(@PathVariable("processId") String processId,
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId) {
		this.userUtils.assumeUser(userId);
		return this.processHistoryService.getProcessComments(processId);
	}

	@RequestMapping(
			value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}/task/{taskId}/comments" },
			method = RequestMethod.GET)
	public ActivitiComments getTaskComments(@PathVariable("processId") String processId,
			@PathVariable("taskId") String taskId,
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId) {
		this.userUtils.assumeUser(userId);
		return this.processHistoryService.getTaskComments(processId, taskId);
	}

	@RequestMapping(
			value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}/tasks" },
			method = RequestMethod.GET)
	public ProcessTasks getTasks(@PathVariable("processId") String processId,
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId) {
		this.userUtils.assumeUser(userId);
		return this.processHistoryService.getTasks(processId);
	}

	@RequestMapping(
			value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}/task/{taskId}" },
			method = RequestMethod.GET)
	public ProcessTask getTask(@PathVariable("processId") String processId,
			@PathVariable("taskId") String taskId, @RequestHeader("tiaa_user") String userId) {
		this.userUtils.assumeUser(userId);
		return this.processHistoryService.getTask(processId, taskId);
	}

	@RequestMapping(value = { "/enterprise/tiaa-activiti-rs-v1/query/tasks" },
			method = RequestMethod.GET)
	public ProcessInstances queryTasksForUser(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@QueryParam("type") String type) {
		this.userUtils.assumeUser(userId);

		if (TASK_ASSIGNED.equalsIgnoreCase(type)) {
			return this.processHistoryService.getTasksAssignedToUser();
		}
		else {
			return this.processHistoryService.getTasksClaimableToUser();
		}
	}

	@RequestMapping(
			value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}/document" },
			method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public ActivitiVariable addDocument(@PathVariable("processId") String processId,
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestBody ActivitiVariable document) {
		this.userUtils.assumeUser(userId);
		return this.processRuntimeService.addDocument(document, processId);
	}

	@RequestMapping(
			value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}/task/{taskId}" },
			method = RequestMethod.PUT)
	public ProcessTask updateTask(@PathVariable("processId") String processId,
			@PathVariable("taskId") String taskId,
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestBody ActivitiVariables reqstVariables) {
		this.userUtils.assumeUser(userId);
		return this.processRuntimeService.updateTask(processId, taskId, reqstVariables);
	}

	@RequestMapping(value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}" },
			method = RequestMethod.PUT)
	public void updateProcess(@PathVariable("processId") String processId,
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestBody ActivitiVariables reqstVariables, @QueryParam("action") String action) {
		this.userUtils.assumeUser(userId);
		this.processRuntimeService.updateProcess(processId, reqstVariables, action);

	}

	@RequestMapping(
			value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}/documents" },
			method = RequestMethod.GET)
	public ActivitiVariable getProcessDocuments(
			@PathVariable("processId") String processId,
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId) {
		this.userUtils.assumeUser(userId);
		return this.processHistoryService.getProcessDocuments(processId);
	}

	@RequestMapping(value = { "/enterprise/tiaa-activiti-rs-v1/cthEvent" },
			method = RequestMethod.PUT)
	public ProcessInstance signalProcess(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId,
			@RequestBody CTHEvent event) {
		this.userUtils.assumeUser(userId);
		return this.processRuntimeService.updateCTHEvent(event);
	}

	@RequestMapping(value = { "/enterprise/tiaa-activiti-rs-v1/message" },
			method = RequestMethod.POST)
	public ProcessInstance signalMessage(
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId, @RequestBody Signal signal) {
		this.userUtils.assumeUser(userId);
		return this.processRuntimeService.signalMessage(signal);
	}

	@RequestMapping(value = { "/enterprise/tiaa-activiti-rs-v1/app/deploy" },
			method = RequestMethod.POST)
	public void updateAppAndPublish(@RequestBody AppProcessMappings appProcessMappings) {
		this.processModelService.deployApp(appProcessMappings);
	}

	@RequestMapping(
			value = { "/enterprise/tiaa-activiti-rs-v1/process/{processId}/history" },
			method = RequestMethod.GET)
	public ProcessInstance getProcessHistory(@PathVariable("processId") String processId,
			@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId) {
		this.userUtils.assumeUser(userId);
		return this.processHistoryService.getProcessHistory(processId);
	}

	@RequestMapping(value = "/enterprise/tiaa-activiti-rs-v1/processdefinitions", method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	public ProcessInstances getProcessDefinitions(@RequestBody ProcessInstances process,@RequestHeader(TIAA_LOGGED_IN_USER_HEADER) String userId) {
		this.userUtils.assumeUser(userId);
		return this.processRuntimeService.retrieveProcessInstance(process);
	}


}