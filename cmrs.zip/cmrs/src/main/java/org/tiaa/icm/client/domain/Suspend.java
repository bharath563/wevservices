package org.tiaa.icm.client.domain;

import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnore;

public class Suspend {
	private Date suspendedOn;

	private String suspendedBy;

	private Date resumedOn;

	private String resumedBy;

	private String stepSqn;

	public Date getSuspendedOn() {
		return suspendedOn;
	}

	public void setSuspendedOn(Date suspendedOn) {
		this.suspendedOn = suspendedOn;
	}

	public String getSuspendedBy() {
		return suspendedBy;
	}

	public void setSuspendedBy(String suspendedBy) {
		this.suspendedBy = suspendedBy;
	}

	public Date getResumedOn() {
		return resumedOn;
	}

	public void setResumedOn(Date resumedOn) {
		this.resumedOn = resumedOn;
	}

	public String getResumedBy() {
		return resumedBy;
	}

	public void setResumedBy(String resumedBy) {
		this.resumedBy = resumedBy;
	}

	@JsonIgnore
	public String getStepSqn() {
		return stepSqn;
	}

	public void setStepSqn(String stepSqn) {
		this.stepSqn = stepSqn;
	}
}
