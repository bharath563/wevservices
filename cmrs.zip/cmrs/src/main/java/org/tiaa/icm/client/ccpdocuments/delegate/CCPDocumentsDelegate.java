package org.tiaa.icm.client.ccpdocuments.delegate;

import java.util.List;

import com.filenet.api.property.Properties;

import org.tiaa.icm.client.domain.Document;

public interface CCPDocumentsDelegate {
	public List<Document> getCCPDocuments(String caseId, String solutionName, Properties props);
}
