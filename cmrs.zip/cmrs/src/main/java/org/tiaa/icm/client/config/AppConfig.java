package org.tiaa.icm.client.config;

import java.util.LinkedHashMap;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import org.tiaa.icm.client.aspect.AspectGetUtil;
import org.tiaa.icm.client.aspect.AspectUtil;
import org.tiaa.icm.client.aspect.LoggingAspect;
import org.tiaa.icm.client.bean.CaseBean;
import org.tiaa.icm.client.bean.TaskBean;
import org.tiaa.icm.client.bo.engine.ContentBO;
import org.tiaa.icm.client.bo.engine.ProcessBO;
import org.tiaa.icm.client.bo.security.P8Authentication;
import org.tiaa.icm.client.bo.util.CaseSearchHelper;
import org.tiaa.icm.client.bo.util.ResponseUtil;
import org.tiaa.icm.client.cache.SolutionConfigCreator;
import org.tiaa.icm.client.domain.Request;
import org.tiaa.icm.client.domain.Response;
import org.tiaa.icm.client.entitlement.BaseSolution;
import org.tiaa.icm.client.entitlement.IPSSolution;
import org.tiaa.icm.client.infocaddy.bean.InfoCaddyBean;
import org.tiaa.icm.client.provider.AppPropertiesProvider;

@Configuration
public class AppConfig {

	static Logger logger = Logger.getLogger(AppConfig.class);

	@Value("${BASE-URI}")
	private String baseURI;

	@Bean
	public CaseBean caseBean() {
		return new CaseBean();
	}

	@Bean
	public P8Authentication p8Authentication() {
		return new P8Authentication();
	}

	@Bean
	public ContentBO contentBO() {
		return new ContentBO();
	}

	// Added by mamillv, ICMClientResponse bean is the response sent for write
	// operations of CE/PE
	@Bean
	public Response icmClientReponse() {
		return new Response();
	}

	@Bean
	public ProcessBO processBO() {
		return new ProcessBO();
	}

	@Bean
	public TaskBean taskBean() {
		return new TaskBean();
	}

	@Bean
	public LoggingAspect loggingAspect() {
		return new LoggingAspect();
	}

	@Bean
	public Request icmsrequest() {
		return new Request();
	}

	@Bean
	public AspectUtil aspectUtil() {
		return new AspectUtil();
	}

	@Bean
	public AspectGetUtil aspectGetUtil() {
		return new AspectGetUtil();
	}

	@Bean
	public ResponseUtil responseUtil() {
		return new ResponseUtil();
	}

	@Bean
	public SolutionConfigCreator configCreator() {
		return new SolutionConfigCreator();
	}

	@Bean
	@Scope("prototype")
	public Map<String, String> solutionConfigs() {
		String configuredSolutions = AppPropertiesProvider.getProperty("SOLUTION-CONFIG");
		Map<String, String> solutionConfigs = new LinkedHashMap<String, String>();

		String configFileBasePath = "org/tiaa/icm/client/config/";

		if (baseURI.equalsIgnoreCase(AppPropertiesProvider.getProperty("PROD-BASE-URI"))) {
			configFileBasePath = configFileBasePath.concat("prod/");
		} else {
			configFileBasePath = configFileBasePath.concat("test/");
		}

		for (String solution : configuredSolutions.split(",")) {
			logger.debug("Configuring for Solution->" + solution);
			solutionConfigs.put(AppPropertiesProvider.getProperty(solution), configFileBasePath + solution + ".json");
		}

		return solutionConfigs;
	}

	@Bean
	public ObjectMapper objectMapper() {
		return new ObjectMapper();
	}

	@Bean
	public BaseSolution baseSolution() {
		return new BaseSolution();
	}

	@Bean
	public IPSSolution ipsSolution() {
		return new IPSSolution();
	}

	@Bean
	public CaseSearchHelper caseSearchHelper() {
		return new CaseSearchHelper();
	}

	@Bean
	public InfoCaddyBean infoCaddyBean() {
		return new InfoCaddyBean();
	}

}