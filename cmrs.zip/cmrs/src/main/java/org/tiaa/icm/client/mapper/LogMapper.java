
package org.tiaa.icm.client.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import org.tiaa.icm.client.domain.Request;

public interface LogMapper {

	String insertLogQry = "INSERT INTO TCFILENET.D_ICMRS_REQUEST (REQUEST_SQN,MSG_GUID,DP_TRANSACTION_ID,CORRELATION_ID, SESSION_ID,DEVICE_ID,CLIENT_ADDRESS,USER_ID,REQUEST_RECIEVED_TIME,CONTENT_TYPE,URI,HTTP_METHOD,REQUEST_PAYLOAD) VALUES (#{requestSqn}, #{msgguid,jdbcType=VARCHAR},#{dpTransactionId,jdbcType=VARCHAR},#{correlationId,jdbcType=VARCHAR},#{sessionId},#{deviceId,jdbcType=VARCHAR},#{clientAddress,jdbcType=VARCHAR},#{userId,jdbcType=VARCHAR},TO_TIMESTAMP(#{requestReceivedTime,jdbcType=VARCHAR},'RRRR-MM-DD HH24:MI:SS.FF') ,#{contentType,jdbcType=VARCHAR},#{uri,jdbcType=VARCHAR},#{httpMethod,jdbcType=VARCHAR},#{requestPayload,jdbcType=VARCHAR})";

	@Insert(insertLogQry)
	public void insertLog(Request icmsrequest);

	@Select("select TCFILENET.ICMRS_REQUEST_SQN.NEXTVAL as NEXTVAL from dual")
	public int selectSequence();

	@Update("UPDATE TCFILENET.D_ICMRS_REQUEST SET RESPONSE_PAYLOAD=#{responsePayload,jdbcType=VARCHAR},STATUS=#{status}, RESPONSE_SENT_TIME=TO_TIMESTAMP(#{responseSentTime},'RRRR-MM-DD HH24:MI:SS.FF') WHERE REQUEST_SQN =#{requestSqn}")
	public void updateLog(Request icmsrequest);
}
