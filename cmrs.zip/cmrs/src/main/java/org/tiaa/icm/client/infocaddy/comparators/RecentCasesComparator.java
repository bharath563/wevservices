package org.tiaa.icm.client.infocaddy.comparators;

import java.util.Comparator;

import org.tiaa.icm.client.infocaddy.constant.InfoCaddyConstant;
import org.tiaa.icm.client.infocaddy.json.RecentCasesObject;
import org.tiaa.icm.client.utils.ICMClientUtil;

public class RecentCasesComparator implements Comparator<RecentCasesObject> {

	private String sortOrder;
	private String sortBy;

	public RecentCasesComparator(String sortOrder, String sortBy) {
		this.sortBy = sortBy;
		this.sortOrder = sortOrder;
	}

	@Override
	public int compare(RecentCasesObject recentCases1, RecentCasesObject recentCases2) {

		int compare = 0;

		if (sortBy.equalsIgnoreCase(InfoCaddyConstant.CASEID)) {

			if (sortOrder.equalsIgnoreCase("ASC")) {
				if (!ICMClientUtil.isNull(recentCases1.getCaseId())
						&& !ICMClientUtil.isNull(recentCases2.getCaseId())) {
					compare = recentCases1.getCaseId().compareToIgnoreCase(recentCases2.getCaseId());
				}

			} else {
				if (!ICMClientUtil.isNull(recentCases1.getCaseId())
						&& !ICMClientUtil.isNull(recentCases2.getCaseId())) {
					compare = recentCases2.getCaseId().compareToIgnoreCase(recentCases1.getCaseId());
				}
			}

		} else if (sortBy.equalsIgnoreCase(InfoCaddyConstant.PROCESSED)) {

			if (sortOrder.equalsIgnoreCase("ASC")) {
				if (!ICMClientUtil.isNull(recentCases1.getProcessed())
						&& !ICMClientUtil.isNull(recentCases2.getProcessed())) {
					compare = recentCases1.getProcessed().compareToIgnoreCase(recentCases2.getProcessed());
				}

			} else {
				if (!ICMClientUtil.isNull(recentCases1.getProcessed())
						&& !ICMClientUtil.isNull(recentCases2.getProcessed())) {
					compare = recentCases2.getProcessed().compareToIgnoreCase(recentCases1.getProcessed());
				}
			}

		} else if (sortBy.equalsIgnoreCase(InfoCaddyConstant.CREATED)) {

			if (sortOrder.equalsIgnoreCase("ASC")) {
				if (!ICMClientUtil.isNull(recentCases1.getCreated())
						&& !ICMClientUtil.isNull(recentCases2.getCreated())) {
					compare = recentCases1.getCreated().compareToIgnoreCase(recentCases2.getCreated());
				}

			} else {
				if (!ICMClientUtil.isNull(recentCases1.getCreated())
						&& !ICMClientUtil.isNull(recentCases2.getCreated())) {
					compare = recentCases2.getCreated().compareToIgnoreCase(recentCases1.getCreated());
				}
			}

		} else if (sortBy.equalsIgnoreCase(InfoCaddyConstant.STATUS)) {

			if (sortOrder.equalsIgnoreCase("ASC")) {
				if (!ICMClientUtil.isNull(recentCases1.getStatus())
						&& !ICMClientUtil.isNull(recentCases2.getStatus())) {
					compare = recentCases1.getStatus().compareToIgnoreCase(recentCases2.getStatus());
				}

			} else {
				if (!ICMClientUtil.isNull(recentCases1.getStatus())
						&& !ICMClientUtil.isNull(recentCases2.getStatus())) {
					compare = recentCases2.getStatus().compareToIgnoreCase(recentCases1.getStatus());
				}
			}

		} else if (sortBy.equalsIgnoreCase(InfoCaddyConstant.FILENAME)) {

			if (sortOrder.equalsIgnoreCase("ASC")) {
				if (!ICMClientUtil.isNull(recentCases1.getFileName())
						&& !ICMClientUtil.isNull(recentCases2.getFileName())) {
					compare = recentCases1.getFileName().compareToIgnoreCase(recentCases2.getFileName());
				}

			} else {
				if (!ICMClientUtil.isNull(recentCases1.getFileName())
						&& !ICMClientUtil.isNull(recentCases2.getFileName())) {
					compare = recentCases2.getFileName().compareToIgnoreCase(recentCases1.getFileName());
				}
			}

		}

		return compare;

	}
}
