package org.tiaa.icm.client.controller;

import java.net.UnknownHostException;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import org.tiaa.icm.client.bean.ICMClientBean;
import org.tiaa.icm.client.domain.Configuration;
import org.tiaa.icm.client.domain.PingResponse;

@Controller
public class CommonController {
	private static Logger LOG = Logger.getLogger(CommonController.class);

	@Autowired
	private ICMClientBean icmClientBean;

	@RequestMapping(value = "/ping", method = RequestMethod.GET)
	public @ResponseBody PingResponse ping(HttpServletRequest request, @RequestHeader("racfId") String racfId)
			throws UnknownHostException {
		LOG.debug("Entered ping request method");
		return icmClientBean.ping(request, racfId);
	}

	@RequestMapping(value = "/config", method = RequestMethod.GET)
	public @ResponseBody Configuration getConfig(@RequestParam(value = "type", required = false) String type,
			@RequestParam(value = "solution", required = false) String solution,
			@RequestParam(value = "tableheader", required = false) String tableheader)
			throws UnknownHostException, NamingException {
		LOG.debug("Entered getConfig method");
		return new Configuration(type, solution, tableheader);
	}

}