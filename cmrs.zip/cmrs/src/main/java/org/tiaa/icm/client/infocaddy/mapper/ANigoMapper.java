package org.tiaa.icm.client.infocaddy.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.type.Alias;

import org.tiaa.icm.client.infocaddy.domain.ANigo;

@Alias("aNigo")
public interface ANigoMapper {

	public List<ANigo> fetchNigo(@Param("caseId") String caseId);

	public List<ANigo> fetchNigoByGroupId(@Param("id") String id);

}
