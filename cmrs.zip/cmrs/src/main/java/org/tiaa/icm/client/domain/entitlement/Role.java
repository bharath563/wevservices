package org.tiaa.icm.client.domain.entitlement;

import java.util.List;

public class Role {

	private String name;

	private List<String> groups;

	private String type;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getGroups() {
		return groups;
	}

	public void setGroups(List<String> groups) {
		this.groups = groups;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Role [getName()=" + getName() + "]";
	}

}
