package org.tiaa.icm.client.infocaddy.bo;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import org.tiaa.icm.client.infocaddy.constant.InfoCaddyConstant;
import org.tiaa.icm.client.infocaddy.json.Type;
import org.tiaa.icm.client.infocaddy.utils.InfoCaddyUtil;
import org.tiaa.icm.client.rest.InfoCaddyService;
import org.tiaa.icm.client.utils.ICMClientUtil;

@Repository(value = "pmoInfoCaddyBO")
public class PMOInfoCaddyBO implements InfoCaddyBODelegate {

	@Autowired
	private InfoCaddyService infoCaddyService;

	private ObjectMapper objectMapper = new ObjectMapper();

	private final Logger logger = Logger.getLogger(POInfoCaddyBO.class);

	private List<Object> processGeneralInformation(List<Object> infoCaddyDetailsList, String caseId)
			throws Exception, JsonMappingException, IOException {

		logger.debug("Entering processGeneralInformation(Type[] infoCaddyDetails, String caseId)...");

		String infoCaddyResponseJSONString = this.objectMapper.writeValueAsString(infoCaddyDetailsList);

		Type[] infoCaddyDetails = this.objectMapper.readValue(infoCaddyResponseJSONString, Type[].class);

		infoCaddyDetailsList.clear();

		for (Type type : infoCaddyDetails) {

			// Remove HTML elements for Age Of Case
			if (!ICMClientUtil.isEmpty(type.getName())
					&& type.getName().equalsIgnoreCase(InfoCaddyConstant.AGE_OF_CASE)) {

				String ageOfCase = !ICMClientUtil.isNull(type.getValue())
						? type.getValue().toString().replaceAll("\\<.*?>", "") : "";
				type.setValue(ageOfCase);
			}

			if (!ICMClientUtil.isEmpty(type.getName()) && !ICMClientUtil.isNull(type.getValue())) {

				if (type.getType().equalsIgnoreCase("property") && type.getValue().toString().contains("href=")
						&& InfoCaddyUtil.checkChatLinksLabel(type.getName())) {

					String chatlink = type.getValue().toString();
					chatlink = InfoCaddyUtil.getRacfId(chatlink);
					logger.debug("Chatlink: " + chatlink + " for type.getName() " + type.getName());
					type.setValue(chatlink);
				}
			}

			// Remove blank propertyGroup item
			if (type.getType().equalsIgnoreCase("propertyGroup") && ICMClientUtil.isEmpty(type.getName())
					&& (type.getContent().size() == 0)) {
				infoCaddyDetails = InfoCaddyUtil.removeRelatedCase(infoCaddyDetails, type);
			}

			// Remove Related Cases group item
			if (!ICMClientUtil.isEmpty(type.getType()) && type.getType().equalsIgnoreCase("group")
					&& type.getName().equalsIgnoreCase(InfoCaddyConstant.RELATED_CASES)) {
				infoCaddyDetails = InfoCaddyUtil.removeRelatedCase(infoCaddyDetails, type);
			}

			List<Type> contentList = type.getContent();
			List<Type> toRemove = new ArrayList<Type>();
			if (null != contentList) {

				for (Type contentType : contentList) {

					if (!ICMClientUtil.isEmpty(contentType.getType())
							&& "propertyGroup".equalsIgnoreCase(contentType.getType())) {

						if (ICMClientUtil.isEmpty(contentType.getName()) && (contentType.getContent().size() == 0)) {
							toRemove.add(contentType);
						}
						// Parse for PropertyGroup
						List<Type> propertyContentList = contentType.getContent();
						List<Type> removeList = new ArrayList<Type>();
						if (propertyContentList != null) {
							for (Type propertyContent : propertyContentList) {

								if (ICMClientUtil.isEmpty(propertyContent.getName())
										&& (propertyContent.getContent().size() == 0)) {
									removeList.add(propertyContent);
								}
							}

							if (removeList != null) {
								for (Type removeitem : removeList) {
									propertyContentList.remove(removeitem);
								}
							}
						}
					}
				}

				if (toRemove != null) {
					for (Type removeitem : toRemove) {
						contentList.remove(removeitem);
					}
				}
			}
		}

		infoCaddyDetailsList.add(infoCaddyDetails);
		logger.debug("Exiting processGeneralInformation(Type[] infoCaddyDetails, String caseId)...");

		return infoCaddyDetailsList;
	}

	@Override
	public List<Object> getInfoCaddyDetails(String caseId, String solution, String section) throws Exception {
		logger.debug("Entering getInfoCaddyDetails(String caseId, String solution, String section...");

		List<Object> infoCaddyDetailsList = infoCaddyService.getInfoCaddyDetails(solution, caseId, section);

		// Process response for General section only. For other sections use
		// response as it is.
		if (InfoCaddyConstant.GENERAL.equalsIgnoreCase(section)) {

			infoCaddyDetailsList = processGeneralInformation(infoCaddyDetailsList, caseId);

			logger.debug("Processing PMO general");

		}

		return infoCaddyDetailsList;
	}

}
