package org.tiaa.icm.client.config;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.infocaddy.bo.InfoCaddyBODelegate;

@Component
public class InfoCaddyBOConfig {

	private Logger logger = Logger.getLogger(InfoCaddyBOConfig.class);

	@Autowired
	@Qualifier("poInfoCaddyBO")
	private InfoCaddyBODelegate poInfoCaddyBODelegate;

	@Autowired
	@Qualifier("toInfoCaddyBO")
	private InfoCaddyBODelegate toInfoCaddyBODelegate;

	@Autowired
	@Qualifier("pmoInfoCaddyBO")
	private InfoCaddyBODelegate pmoInfoCaddyBODelegate;

	@Autowired
	@Qualifier("isInfoCaddyBO")
	private InfoCaddyBODelegate isInfoCaddyBODelegate;

	@Autowired
	@Qualifier("piInfoCaddyBO")
	private InfoCaddyBODelegate piInfoCaddyBODelegate;

	public InfoCaddyBODelegate getInfoCaddyBO(String solutionName) {

		logger.info("Entering getInfoCaddyBO(String solutionName)...");

		InfoCaddyBODelegate infoCaddyBO = null;

		if (CommonConstants.PAYOUT_OPERATIONS.equalsIgnoreCase(solutionName)) {
			infoCaddyBO = poInfoCaddyBODelegate;
		} else if (CommonConstants.PARTICIPANT_MAINTENANCE_OPERATIONS.equalsIgnoreCase(solutionName)) {
			infoCaddyBO = pmoInfoCaddyBODelegate;
		} else if (CommonConstants.TRANSFER_OPERATIONS.equalsIgnoreCase(solutionName)) {
			infoCaddyBO = toInfoCaddyBODelegate;
		} else if (CommonConstants.IS_OPERATIONS.equalsIgnoreCase(solutionName)) {
			infoCaddyBO = isInfoCaddyBODelegate;
		} else if (CommonConstants.PAYIN_OPERATIONS.equalsIgnoreCase(solutionName)) {
			infoCaddyBO = piInfoCaddyBODelegate;
		}

		logger.info("Exiting getInfoCaddyBO(String solutionName)...");

		return infoCaddyBO;

	}

}
