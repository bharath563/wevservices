package org.tiaa.icm.client.bo.util;

import java.io.IOException;

import javax.xml.parsers.FactoryConfigurationError;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

import org.springframework.core.io.ClassPathResource;

public class Log4JConfig {

	private ClassPathResource classpathResource;

	public ClassPathResource getClasspathResource() {
		return classpathResource;
	}

	public void setClasspathResource(ClassPathResource classpathResource) {
		this.classpathResource = classpathResource;
	}

	public void init() {
		try {
			DOMConfigurator.configure(classpathResource.getFile().getAbsolutePath());
		}
		catch (FactoryConfigurationError e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			Logger.getLogger(Log4JConfig.class).error(e.getStackTrace());
		}
	}
}
