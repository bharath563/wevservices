package org.tiaa.icm.client.domain.spi;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.filenet.api.collection.EventSet;
import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.constants.TaskState;
import com.filenet.api.core.CmTask;
import com.filenet.api.property.Properties;

import org.tiaa.icm.client.constant.EventType;
import org.tiaa.icm.client.domain.Event;

public class Tasks implements IEvents {

	private IndependentObjectSet ios;

	public Tasks(IndependentObjectSet ios) {
		this.ios = ios;
	}

	@Override
	public List<Event> getEvents() {
		Iterator<CmTask> iterator = this.ios.iterator();
		List<Event> events = new ArrayList<Event>();

		while (iterator.hasNext()) {
			CmTask task = iterator.next();
			events.addAll(getAuditedTaskEvents(task.get_AuditedEvents()));
		}
		return events;
	}

	private List<Event> getAuditedTaskEvents(EventSet eventSet) {

		Iterator<com.filenet.api.events.Event> iterator = eventSet.iterator();
		Map<Integer, Event> eventMap = new HashMap<Integer, Event>();
		while (iterator.hasNext()) {
			Event event = new Event();
			com.filenet.api.events.Event ceEvent = iterator.next();
			Properties props = ceEvent.getProperties();
			int objectState = props.getInteger32Value("CmAcmObjectState");
			event.setCreatedOn(ceEvent.get_DateCreated());
			event.setCreatedBy(ceEvent.get_Creator());
			event.setTitle(props.getStringValue("CmAcmObjectName"));
			event.setType(EventType.TASK.getType());
			event.setDescription("Task " + ((objectState >= 1) && (objectState <= 2) ? "Created"
					: TaskState.getInstanceFromInt(objectState).toString()));
			if (eventMap.containsKey(objectState)) {
				Event existingEvent = eventMap.get(objectState);
				if (event.getCreatedOn().compareTo(existingEvent.getCreatedOn()) > 0) {
					eventMap.put(objectState, event);
				} else { // skip the same event with older date...
					continue;
				}
			} else {
				eventMap.put(objectState, event);
			}
		}
		List<Event> events = new ArrayList<Event>();
		events.addAll(eventMap.values());
		return events;
	}

}
