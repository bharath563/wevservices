package org.tiaa.icm.client.aspect;

import java.io.IOException;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.icm.client.domain.Request;

@Aspect
public class LoggingAspect {

	@Autowired
	private AspectUtil aspectUtil;

	@Autowired
	private AspectGetUtil aspectGetUtil;

	/******** Pointcut for searchCase ************************/

	@Pointcut("execution(* org.tiaa.icm.client.controller.CaseController.searchCase(..))")
	public void log() {
	}

	@Before("log()")
	public Request searchCase(JoinPoint joinPoint) throws Throwable {
		return aspectUtil.insertRequestLog(joinPoint.getArgs(), "org.tiaa.icm.client.domain.CaseSearch");
	}

	@AfterReturning(value = "execution(* org.tiaa.icm.client.controller.CaseController.searchCase(..))", returning = "result")
	public void afterReturningSearchCase(JoinPoint joinPoint, Object result) throws IOException {
		aspectUtil.updateResultLog(joinPoint.getArgs(), result);
	}

	/******** Pointcut for addCaseComments ************************/

	@Before("execution(* org.tiaa.icm.client.controller.CaseController.addCaseComments(..))")
	public void addCaseComments(JoinPoint joinPoint) throws Throwable {
		aspectUtil.insertRequestLog(joinPoint.getArgs(), "org.tiaa.icm.client.domain.Comment");
	}

	@AfterReturning(value = "execution(* org.tiaa.icm.client.controller.CaseController.addCaseComments(..))", returning = "result")
	public void afterReturningaddCaseComments(JoinPoint joinPoint, Object result) throws IOException {
		aspectUtil.updateResultLog(joinPoint.getArgs(), result);
	}

	/********
	 * Pointcut for addTaskComments
	 ************************/

	@Before("execution(* org.tiaa.icm.client.controller.CaseController.addTaskComments(..))")
	public void addTaskComments(JoinPoint joinPoint) throws Throwable {
		aspectUtil.insertRequestLog(joinPoint.getArgs(), "org.tiaa.icm.client.domain.Comment");
	}

	@AfterReturning(value = "execution(* org.tiaa.icm.client.controller.CaseController.addTaskComments(..))", returning = "result")
	public void afterReturningaddTaskComments(JoinPoint joinPoint, Object result) throws IOException {
		aspectUtil.updateResultLog(joinPoint.getArgs(), result);
	}

	/********* Pointcut for documentComments ************************/

	@Before("execution(* org.tiaa.icm.client.controller.CaseController.documentComments(..))")
	public void documentComments(JoinPoint joinPoint) throws Throwable {
		aspectUtil.insertRequestLog(joinPoint.getArgs(), "org.tiaa.icm.client.domain.Comment");
	}

	@AfterReturning(value = "execution(* org.tiaa.icm.client.controller.CaseController.documentComments(..))", returning = "result")
	public void afterReturningdocumentComments(JoinPoint joinPoint, Object result) throws IOException {
		aspectUtil.updateResultLog(joinPoint.getArgs(), result);
	}

	/********* Pointcut for StepComments ************************/

	@Before("execution(* org.tiaa.icm.client.controller.CaseController.stepComments(..))")
	public void stepComments(JoinPoint joinPoint) throws Throwable {
		aspectUtil.insertRequestLog(joinPoint.getArgs(), "org.tiaa.icm.client.domain.Comment");
	}

	@AfterReturning(value = "execution(* org.tiaa.icm.client.controller.CaseController.stepComments(..))", returning = "result")
	public void afterReturningstepComments(JoinPoint joinPoint, Object result) throws IOException {
		aspectUtil.updateResultLog(joinPoint.getArgs(), result);
	}

	/********
	 * Pointcut for CreateDocument
	 ************************/

	@Before("execution(* org.tiaa.icm.client.controller.CaseController.createDocument(..))")
	public void createDocument(JoinPoint joinPoint) throws Throwable {
		aspectUtil.insertRequestLog(joinPoint.getArgs(), "org.tiaa.icm.client.domain.Document");
	}

	@AfterReturning(value = "execution(* org.tiaa.icm.client.controller.CaseController.createDocument(..))", returning = "result")
	public void afterReturningCreateDocument(JoinPoint joinPoint, Object result) throws IOException {
		aspectUtil.updateResultLog(joinPoint.getArgs(), result);
	}

	/********
	 * Pointcut for UpdateDocument
	 ************************/

	@Before("execution(* org.tiaa.icm.client.controller.CaseController.updateDocument(..))")
	public void updateDocument(JoinPoint joinPoint) throws Throwable {
		aspectUtil.insertRequestLog(joinPoint.getArgs(), "org.tiaa.icm.client.domain.Document");
	}

	@AfterReturning(value = "execution(* org.tiaa.icm.client.controller.CaseController.updateDocument(..))", returning = "result")
	public void afterReturningUpdateDocument(JoinPoint joinPoint, Object result) throws IOException {
		aspectUtil.updateResultLog(joinPoint.getArgs(), result);
	}

	/******** Pointcut for getCaseProperties ************************/

	@Before("execution(* org.tiaa.icm.client.controller.CaseController.get*(..))")
	public void getCaseProperties(JoinPoint joinPoint) throws Throwable {
		aspectGetUtil.insertRequestLog(joinPoint.getArgs());
	}

	@AfterReturning(value = "execution(* org.tiaa.icm.client.controller.CaseController.get*(..))", returning = "result")
	public void afterReturningGetCaseProperties(JoinPoint joinPoint, Object result) throws IOException {
		aspectGetUtil.updateResultLog(joinPoint.getArgs(), result);
	}

	/********* Exception handling ********/

	@AfterThrowing(value = "execution(* org.tiaa.icm.client.controller.CaseController.*(..))", throwing = "e")
	public void afterThrowingGetCaseProperties(JoinPoint joinPoint, Throwable e) throws IOException {
		aspectUtil.afterThrowingException(joinPoint.getArgs(), e);
	}

	/******** Pointcut for TaskRelated Get Operations ************************/

	@Before("execution(* org.tiaa.icm.client.controller.TaskController.get*(..))")
	public void getTaskProperties(JoinPoint joinPoint) throws Throwable {
		aspectGetUtil.insertRequestLog(joinPoint.getArgs());
	}

	@AfterReturning(value = "execution(* org.tiaa.icm.client.controller.TaskController.get*(..))", returning = "result")
	public void afterReturningGetTaskProperties(JoinPoint joinPoint, Object result) throws IOException {
		aspectGetUtil.updateResultLog(joinPoint.getArgs(), result);
	}

	/******** Pointcut for completeTask ************************/

	@Before("execution(* org.tiaa.icm.client.controller.TaskController.completeTask(..))")
	public void completeTask(JoinPoint joinPoint) throws Throwable {
		aspectUtil.insertRequestLog(joinPoint.getArgs(), "org.tiaa.icm.client.domain.Step");
	}

	@AfterReturning(value = "execution(* org.tiaa.icm.client.controller.TaskController.completeTask(..))", returning = "result")
	public void afterReturningCompleteTask(JoinPoint joinPoint, Object result) throws IOException {
		aspectUtil.updateResultLog(joinPoint.getArgs(), result);
	}

	/******** Pointcut for reassignTask ************************/

	@Before("execution(* org.tiaa.icm.client.controller.TaskController.reassignTask(..))")
	public void reassignTask(JoinPoint joinPoint) throws Throwable {
		aspectUtil.insertRequestLog(joinPoint.getArgs(), "org.tiaa.icm.client.domain.Step");
	}

	@AfterReturning(value = "execution(* org.tiaa.icm.client.controller.TaskController.reassignTask(..))", returning = "result")
	public void afterReturningReassignTask(JoinPoint joinPoint, Object result) throws IOException {
		aspectUtil.updateResultLog(joinPoint.getArgs(), result);
	}

	/******** Pointcut for unlockTask ************************/

	@Before("execution(* org.tiaa.icm.client.controller.TaskController.unlockTask(..))")
	public void unlockTask(JoinPoint joinPoint) throws Throwable {
		aspectUtil.insertRequestLog(joinPoint.getArgs(), "org.tiaa.icm.client.domain.Step");
	}

	@AfterReturning(value = "execution(* org.tiaa.icm.client.controller.TaskController.unlockTask(..))", returning = "result")
	public void afterReturningUnlockTask(JoinPoint joinPoint, Object result) throws IOException {
		aspectUtil.updateResultLog(joinPoint.getArgs(), result);
	}

	/********* Exception handling ********/

	@AfterThrowing(value = "execution(* org.tiaa.icm.client.controller.TaskController.*(..))", throwing = "e")
	public void afterThrowingGetTaskProperties(JoinPoint joinPoint, Throwable e) throws IOException {
		aspectUtil.afterThrowingException(joinPoint.getArgs(), e);
	}

}
