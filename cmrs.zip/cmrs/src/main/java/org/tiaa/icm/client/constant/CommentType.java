package org.tiaa.icm.client.constant;

public enum CommentType {

	CmAcmCaseComment("Case"), CmAcmTaskComment("Task"), CmAcmWorkItemComment("Step"), CmAcmVersionSeriesComment(
			"Document");

	String commentType;

	CommentType(String type) {
		this.commentType = type;
	}

	public String getType() {
		return commentType;
	}

}
