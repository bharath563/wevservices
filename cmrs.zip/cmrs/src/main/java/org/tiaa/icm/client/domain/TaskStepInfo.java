package org.tiaa.icm.client.domain;

import java.util.Date;

public class TaskStepInfo {
	private String taskId;
	private String stepActionTakenBy;
	private Date stepCompletedTs;
	private Date taskStartedOn;
	private String taskStartedBy;

	public String getStepActionTakenBy() {
		return stepActionTakenBy;
	}

	public void setStepActionTakenBy(String stepActionTakenBy) {
		this.stepActionTakenBy = stepActionTakenBy;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public Date getStepCompletedTs() {
		return stepCompletedTs;
	}

	public void setStepCompletedTs(Date stepCompletedTs) {
		this.stepCompletedTs = stepCompletedTs;
	}

	public String getTaskStartedBy() {
		return taskStartedBy;
	}

	public void setTaskStartedBy(String taskStartedBy) {
		this.taskStartedBy = taskStartedBy;
	}

	public Date getTaskStartedOn() {
		return taskStartedOn;
	}

	public void setTaskStartedOn(Date taskStartedOn) {
		this.taskStartedOn = taskStartedOn;
	}

}
