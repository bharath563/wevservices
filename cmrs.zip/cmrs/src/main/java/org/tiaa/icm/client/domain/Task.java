package org.tiaa.icm.client.domain;

import java.util.Date;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;

public class Task implements Comparable<Task> {

	private String id;

	private String type;

	private String name;

	private Date createdOn;

	private String createdBy;

	private List<Status> statuses;

	private Date completedOn;

	private String completedAction;

	private String completedBy;

	// private String stepSqn;

	private String status;

	private String sequence;
	private String eventClass;
	private String parentId;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@JsonIgnore
	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	@JsonIgnore
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public List<Status> getStatuses() {
		return statuses;
	}

	public void setStatuses(List<Status> statuses) {
		this.statuses = statuses;
	}

	@JsonIgnore
	public Date getCompletedOn() {
		return completedOn;
	}

	public void setCompletedOn(Date completedOn) {
		this.completedOn = completedOn;
	}

	public String getCompletedAction() {
		return completedAction;
	}

	public void setCompletedAction(String completedAction) {
		this.completedAction = completedAction;
	}

	@JsonIgnore
	public String getCompletedBy() {
		return completedBy;
	}

	public void setCompletedBy(String completedBy) {
		this.completedBy = completedBy;
	}

	/*
	 * @JsonIgnore public String getStepSqn() { return stepSqn; }
	 *
	 * public void setStepSqn(String stepSqn) { this.stepSqn = stepSqn; }
	 */

	@JsonIgnore
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@JsonIgnore
	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}

	@JsonIgnore
	public String getEventClass() {
		return eventClass;
	}

	public void setEventClass(String eventClass) {
		this.eventClass = eventClass;
	}

	@JsonIgnore
	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	@Override
	public int compareTo(Task taskObj) {
		if (getCreatedOn().compareTo(taskObj.getCreatedOn()) == -1) {
			return 1;
		}
		if (getCreatedOn().compareTo(taskObj.getCreatedOn()) == 1) {
			return -1;
		} else {
			return 0;
		}
	}

}
