package org.tiaa.icm.client.infocaddy.domain;

import java.sql.Timestamp;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import org.apache.ibatis.type.Alias;

@Alias("aOmniTransactions")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class AOmniTransactions {

	private Long omniSqn;
	private String omniTransactionId;
	private String omniTransactionType;
	private String planNum;
	private String subPlanNum;
	private String participantSegment;
	private String planSegment;
	private String omniFolderName;
	private String omniTradeDate;
	private String omniSequenceNum;
	private String omniStatus;
	private String omniErrorCode;
	private String omniErrorMessage;
	private Timestamp omniPostDate;
	private Long amount;
	private String paymentMethod;
	private String transactionStatus;
	private String statusReason;
	private String otherInfo;
	private String groupId;
	private String batchId;
	private Timestamp processEndTs;
	private String processStatus;
	private Timestamp updatedTs;

	/**
	 * @return the omniSqn
	 */
	public Long getOmniSqn() {
		return this.omniSqn;
	}

	/**
	 * @param omniSqn
	 *            the omniSqn to set
	 */
	public void setOmniSqn(Long omniSqn) {
		this.omniSqn = omniSqn;
	}

	/**
	 * @return the omniTransactionId
	 */
	public String getOmniTransactionId() {
		return this.omniTransactionId;
	}

	/**
	 * @param omniTransactionId
	 *            the omniTransactionId to set
	 */
	public void setOmniTransactionId(String omniTransactionId) {
		this.omniTransactionId = omniTransactionId;
	}

	/**
	 * @return the omniTransactionType
	 */
	public String getOmniTransactionType() {
		return this.omniTransactionType;
	}

	/**
	 * @param omniTransactionType
	 *            the omniTransactionType to set
	 */
	public void setOmniTransactionType(String omniTransactionType) {
		this.omniTransactionType = omniTransactionType;
	}

	/**
	 * @return the planNumber
	 */
	public String getPlanNum() {
		return this.planNum;
	}

	/**
	 * @param planNumber
	 *            the planNumber to set
	 */
	public void setPlanNum(String planNum) {
		this.planNum = planNum;
	}

	/**
	 * @return the subPlanNumber
	 */
	public String getSubPlanNum() {
		return this.subPlanNum;
	}

	/**
	 * @param subPlanNumber
	 *            the subPlanNumber to set
	 */
	public void setSubPlanNum(String subPlanNum) {
		this.subPlanNum = subPlanNum;
	}

	/**
	 * @return the participantSegment
	 */
	public String getParticipantSegment() {
		return this.participantSegment;
	}

	/**
	 * @param participantSegment
	 *            the participantSegment to set
	 */
	public void setParticipantSegment(String participantSegment) {
		this.participantSegment = participantSegment;
	}

	/**
	 * @return the planSegment
	 */
	public String getPlanSegment() {
		return this.planSegment;
	}

	/**
	 * @param planSegment
	 *            the planSegment to set
	 */
	public void setPlanSegment(String planSegment) {
		this.planSegment = planSegment;
	}

	/**
	 * @return the omniFolderName
	 */
	public String getOmniFolderName() {
		return this.omniFolderName;
	}

	/**
	 * @param omniFolderName
	 *            the omniFolderName to set
	 */
	public void setOmniFolderName(String omniFolderName) {
		this.omniFolderName = omniFolderName;
	}

	/**
	 * @return the omniTradeDate
	 */
	public String getOmniTradeDate() {
		return this.omniTradeDate;
	}

	/**
	 * @param omniTradeDate
	 *            the omniTradeDate to set
	 */
	public void setOmniTradeDate(String omniTradeDate) {
		this.omniTradeDate = omniTradeDate;
	}

	/**
	 * @return the omniStatus
	 */
	public String getOmniStatus() {
		return this.omniStatus;
	}

	/**
	 * @param omniStatus
	 *            the omniStatus to set
	 */
	public void setOmniStatus(String omniStatus) {
		this.omniStatus = omniStatus;
	}

	/**
	 * @return the omniErrorCode
	 */
	public String getOmniErrorCode() {
		return this.omniErrorCode;
	}

	/**
	 * @param omniErrorCode
	 *            the omniErrorCode to set
	 */
	public void setOmniErrorCode(String omniErrorCode) {
		this.omniErrorCode = omniErrorCode;
	}

	/**
	 * @return the omniErrorMessage
	 */
	public String getOmniErrorMessage() {
		return this.omniErrorMessage;
	}

	/**
	 * @param omniErrorMessage
	 *            the omniErrorMessage to set
	 */
	public void setOmniErrorMessage(String omniErrorMessage) {
		this.omniErrorMessage = omniErrorMessage;
	}

	/**
	 * @return the omniPostDate
	 */
	public Timestamp getOmniPostDate() {
		return this.omniPostDate;
	}

	/**
	 * @param omniPostDate
	 *            the omniPostDate to set
	 */
	public void setOmniPostDate(Timestamp omniPostDate) {
		this.omniPostDate = omniPostDate;
	}

	/**
	 * @return the amount
	 */
	public Long getAmount() {
		return this.amount;
	}

	/**
	 * @param amount
	 *            the amount to set
	 */
	public void setAmount(Long amount) {
		this.amount = amount;
	}

	/**
	 * @return the paymentMethod
	 */
	public String getPaymentMethod() {
		return this.paymentMethod;
	}

	/**
	 * @param paymentMethod
	 *            the paymentMethod to set
	 */
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	/**
	 * @return the transactionStatus
	 */
	public String getTransactionStatus() {
		return this.transactionStatus;
	}

	/**
	 * @param transactionStatus
	 *            the transactionStatus to set
	 */
	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	/**
	 * @return the statusReason
	 */
	public String getStatusReason() {
		return this.statusReason;
	}

	/**
	 * @param statusReason
	 *            the statusReason to set
	 */
	public void setStatusReason(String statusReason) {
		this.statusReason = statusReason;
	}

	/**
	 * @return the otherInfo
	 */
	public String getOtherInfo() {
		return this.otherInfo;
	}

	/**
	 * @param otherInfo
	 *            the otherInfo to set
	 */
	public void setOtherInfo(String otherInfo) {
		this.otherInfo = otherInfo;
	}

	/**
	 * @return the groupId
	 */
	public String getGroupId() {
		return this.groupId;
	}

	/**
	 * @param groupId
	 *            the groupId to set
	 */
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	/**
	 * @return the batchId
	 */
	public String getBatchId() {
		return this.batchId;
	}

	/**
	 * @param batchId
	 *            the batchId to set
	 */
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	/**
	 * @return the processEndTs
	 */
	public Timestamp getProcessEndTs() {
		return this.processEndTs;
	}

	/**
	 * @param processEndTs
	 *            the processEndTs to set
	 */
	public void setProcessEndTs(Timestamp processEndTs) {
		this.processEndTs = processEndTs;
	}

	/**
	 * @return the processStatus
	 */
	public String getProcessStatus() {
		return this.processStatus;
	}

	/**
	 * @param processStatus
	 *            the processStatus to set
	 */
	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}

	/**
	 * @return the updatedTs
	 */
	public Timestamp getUpdatedTs() {
		return this.updatedTs;
	}

	/**
	 * @param updatedTs
	 *            the updatedTs to set
	 */
	public void setUpdatedTs(Timestamp updatedTs) {
		this.updatedTs = updatedTs;
	}

	public String getOmniSequenceNum() {
		return this.omniSequenceNum;
	}

	public void setOmniSequenceNum(String omniSequenceNum) {
		this.omniSequenceNum = omniSequenceNum;
	}

}
