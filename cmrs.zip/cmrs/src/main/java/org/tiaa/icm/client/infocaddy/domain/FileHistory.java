package org.tiaa.icm.client.infocaddy.domain;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import org.apache.ibatis.type.Alias;

@Alias("fileHistory")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class FileHistory implements Comparator<FileHistory> {

	private String identifierName;
	private String identifierValue;
	public static final CompareByIdentifierOrder compareByIdentifierOrder = new CompareByIdentifierOrder();

	/**
	 * @return the identifierName
	 */
	public String getIdentifierName() {
		return this.identifierName;
	}

	/**
	 * @param identifierName
	 *            the identifierName to set
	 */
	public void setIdentifierName(String identifierName) {
		this.identifierName = identifierName;
	}

	/**
	 * @return the identifierValue
	 */
	public String getIdentifierValue() {
		return this.identifierValue;
	}

	/**
	 * @param identifierValue
	 *            the identifierValue to set
	 */
	public void setIdentifierValue(String identifierValue) {
		this.identifierValue = identifierValue;
	}

	@Override
	public int compare(FileHistory o1, FileHistory o2) {
		int index1 = listFileInfoIdentifierName.indexOf(o1.getIdentifierName());
		int index2 = listFileInfoIdentifierName.indexOf(o2.getIdentifierName());
		if (index1 < index2) {
			return -1;
		}
		if (index2 < index1) {
			return 1;
		}
		return 0;
	}

	private static class CompareByIdentifierOrder implements Comparator<FileHistory> {
		@Override
		public int compare(FileHistory o1, FileHistory o2) {
			int index1 = listFileInfoIdentifierName.indexOf(o1.getIdentifierName());
			int index2 = listFileInfoIdentifierName.indexOf(o2.getIdentifierName());
			if (index1 < index2) {
				return -1;
			}
			if (index2 < index1) {
				return 1;
			}
			return 0;
		}
	}

	/**
	 * Identifier names and order
	 */
	public static final List<String> listFileInfoIdentifierName = new ArrayList<String>();

	static {
		listFileInfoIdentifierName.add("Reports Name");

		listFileInfoIdentifierName.add("Task File Type");
		listFileInfoIdentifierName.add("Task File Name");
		listFileInfoIdentifierName.add("Platform");
		listFileInfoIdentifierName.add("Edited By");
		listFileInfoIdentifierName.add("Edited On");

		listFileInfoIdentifierName.add("Submitted By");
		listFileInfoIdentifierName.add("Submitted On");

		listFileInfoIdentifierName.add("Report Name");
		listFileInfoIdentifierName.add("Client Name");
		listFileInfoIdentifierName.add("Client ID");
		listFileInfoIdentifierName.add("Frequency");
		listFileInfoIdentifierName.add("Discrepancy Count");

		listFileInfoIdentifierName.add("Source File Type");
		listFileInfoIdentifierName.add("Date Created");
		listFileInfoIdentifierName.add("Case Number");
		listFileInfoIdentifierName.add("Location ID");
		listFileInfoIdentifierName.add("Last Processed By");

	}

}
