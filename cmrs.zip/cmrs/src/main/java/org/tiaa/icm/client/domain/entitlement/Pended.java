package org.tiaa.icm.client.domain.entitlement;

import java.util.List;

public class Pended extends WorkItemType {

	private String type;

	private String name;

	private List<String> queues;

	private String filters;

	@Override
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public List<String> getQueues() {
		return queues;
	}

	public void setQueue(List<String> queues) {
		this.queues = queues;
	}

	@Override
	public String getFilters() {
		return filters;
	}

	public void setFilters(String filters) {
		this.filters = filters;
	}

	@Override
	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Pended [type=" + type + "]";
	}

}
