/**
 *
 */
package org.tiaa.icm.client.rest;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.log4j.Logger;

import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.DefaultResponseErrorHandler;

/**
 * @author oyapeo
 *
 */
public class RestErrorHandler extends DefaultResponseErrorHandler {
	private static Logger logger = Logger.getLogger(RestErrorHandler.class);
	ThreadLocal<String> currentError = new ThreadLocal<String>();
	ThreadLocal<String> currentGuid = new ThreadLocal<String>();

	/**
	 *
	 */
	public RestErrorHandler() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void handleError(ClientHttpResponse response) throws IOException {
		String errorMsg = null;
		try {
			InputStream is = response.getBody();
			byte[] dataBuffer = new byte[32655];
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			int dataRead = -1;
			while ((dataRead = is.read(dataBuffer)) > 0) {
				baos.write(dataBuffer, 0, dataRead);
			}
			// int rawStatusCode = response.getRawStatusCode();
			HttpStatus httpStatus = response.getStatusCode();
			String statusText = response.getStatusText();
			StringBuilder sb = new StringBuilder();
			sb.append("HttpError  Status:").append(httpStatus.toString()).append("          ").append(statusText);
			sb.append("\nError-Details:\t").append(new String(baos.toByteArray()));
			errorMsg = sb.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		throw new RuntimeException(errorMsg.toString());
	}

	public String getErrorString() {
		return currentError.get();
	}

	/**
	 * @return the currentGuid
	 */
	public ThreadLocal<String> getCurrentGuid() {
		return currentGuid;
	}

	/**
	 * @param currentGuid
	 *            the currentGuid to set
	 */
	public void setCurrentGuid(ThreadLocal<String> _currentGuid) {
		this.currentGuid = _currentGuid;
	}

}
