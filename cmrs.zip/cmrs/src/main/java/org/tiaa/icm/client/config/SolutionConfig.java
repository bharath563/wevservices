/**
 *
 */
package org.tiaa.icm.client.config;

import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.annotate.JsonDeserialize;

import org.tiaa.icm.client.deserializer.FilterConfigDeserializer;
import org.tiaa.icm.client.domain.entitlement.InBasketHeaders;
import org.tiaa.icm.client.domain.entitlement.ProfileConfig;
import org.tiaa.icm.client.domain.entitlement.Role;
import org.tiaa.icm.client.domain.entitlement.WorkItemType;

/**
 * @author ganapaa
 *
 */
public class SolutionConfig {

	private List<InBasketHeaders> inbasketHeaders;

	private String solutionIdentifier;

	private List<Role> roles;

	private boolean profile;

	private ProfileConfig profiles;

	private String genericCaseType;

	@JsonDeserialize(using = FilterConfigDeserializer.class)
	// key - Operation Role Name value - List of Filters of workitemtype
	private Map<String, List<WorkItemType>> filters;

	public List<Role> getRoles() {
		return roles;
	}

	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}

	public ProfileConfig getProfiles() {
		return profiles;
	}

	public void setProfiles(ProfileConfig profiles) {
		this.profiles = profiles;
	}

	public boolean isProfile() {
		return profile;
	}

	public void setProfile(boolean profile) {
		this.profile = profile;
	}

	public Map<String, List<WorkItemType>> getFilters() {
		return filters;
	}

	public void setFilters(Map<String, List<WorkItemType>> filters) {
		this.filters = filters;
	}

	public List<InBasketHeaders> getInbasketHeaders() {
		return inbasketHeaders;
	}

	public void setInbasketHeaders(List<InBasketHeaders> inbasketHeaders) {
		this.inbasketHeaders = inbasketHeaders;
	}

	public String getSolutionIdentifier() {
		return solutionIdentifier;
	}

	public void setSolutionIdentifier(String solutionIdentifier) {
		this.solutionIdentifier = solutionIdentifier;
	}

	public String getGenericCaseType() {
		return genericCaseType;
	}

	public void setGenericCaseType(String genericCaseType) {
		this.genericCaseType = genericCaseType;
	}

}
