package org.tiaa.icm.client.mapper;

import java.util.List;

import org.tiaa.icm.client.domain.RelatedCase;

public interface RelatedCasesMapper {

	public List<RelatedCase> getRelatedCases(String caseId);

	public List<RelatedCase> getRelatedCasesForBO(String caseId);

	public List<RelatedCase> getRelatedCasesForPI_PMO(String caseId);

	public String getLoanId(String caseId);

}
