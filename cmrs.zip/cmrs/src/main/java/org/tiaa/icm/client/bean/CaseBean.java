package org.tiaa.icm.client.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.filenet.api.util.Id;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.icm.client.bo.engine.ContentBO;
import org.tiaa.icm.client.bo.engine.ProcessBO;
import org.tiaa.icm.client.bo.util.CaseSearchHelper;
import org.tiaa.icm.client.bo.util.ResponseUtil;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Case;
import org.tiaa.icm.client.domain.CaseSearch;
import org.tiaa.icm.client.domain.Comment;
import org.tiaa.icm.client.domain.Document;
import org.tiaa.icm.client.domain.Event;
import org.tiaa.icm.client.domain.RelatedCase;
import org.tiaa.icm.client.domain.Response;
import org.tiaa.icm.client.domain.ResponseList;
import org.tiaa.icm.client.domain.Solution;
import org.tiaa.icm.client.domain.Status;
import org.tiaa.icm.client.domain.Task;
import org.tiaa.icm.client.domain.TaskStepInfo;
import org.tiaa.icm.client.mapper.CaseMapper;
import org.tiaa.icm.client.mapper.RelatedCasesMapper;
import org.tiaa.icm.client.mapper.TaskStepMapper;
import org.tiaa.icm.client.provider.AppPropertiesProvider;

public class CaseBean {

	private static Logger logger = Logger.getLogger(CaseBean.class);

	@Autowired
	private CaseMapper caseMapper;

	@Autowired
	private TaskStepMapper taskStepMapper;

	@Autowired
	private ContentBO contentBO;

	@Autowired
	private ProcessBO processBO;

	@Autowired
	private RelatedCasesMapper relatedCasesMapper;

	@Autowired
	private ResponseUtil responseUtil;

	@Autowired
	private Response response;

	@Autowired
	private CaseSearchHelper caseSearchHelper;

	private static TaskComparatorByDateDescending taskComparatorByDateDescending = new TaskComparatorByDateDescending();

	public ResponseList searchCase(CaseSearch caseSearch, String start, String osName) throws Exception {
		logger.debug("Entered searchCase method");

		if ((caseSearch.getSortField() == null) || (caseSearch.getSortOrder() == null)) {
			throw new RuntimeException("sortField and sortOrder are required fields and cannot be null");
		}
		return caseSearchHelper.doSearch(caseSearch, start, osName);

	}

	public Case getCaseProperties(String osName, String caseid) {
		Case caseDetail = contentBO.getCaseDetails(osName, caseid);
		String caseStatus = caseMapper.getCaseStatus(caseid);

		if ((null != caseStatus) && CommonConstants.STARTED.equalsIgnoreCase(caseStatus)) {
			caseStatus = CommonConstants.IN_PROCESS;
		}

		logger.debug("Case Status for case:" + caseid + ", is :" + caseStatus);
		caseDetail.setStatus(caseStatus);
		return caseDetail;
	}

	public List<Document> getDocuments(String osName, String caseid) {
		return contentBO.getDocuments(osName, caseid);
	}

	public List<Comment> getComments(String osName, String caseid) {
		return contentBO.getComments(osName, caseid);
	}

	public List<Task> getTasks(String osName, String caseid, String startStr) {
		// Get solution name and confirmation number to get Brokerage case id
		// for AT case id
		List<Task> sortedTaskList = new ArrayList<Task>();
		Solution solution = caseMapper.getSolutionNameAndConfirmationNumber(caseid);

		if ((solution == null) || (solution.getSoultionName() == null) || (solution.getCaseType() == null)) {
			return sortedTaskList;
		}
		logger.debug("solution Name:" + solution.getSoultionName());
		if (CommonConstants.ICS.equalsIgnoreCase(solution.getSoultionName())
				|| CommonConstants.IPS.equalsIgnoreCase(solution.getSoultionName())
				|| CommonConstants.CS.equalsIgnoreCase(solution.getSoultionName())
				|| CommonConstants.SS.equalsIgnoreCase(solution.getSoultionName())) {

			Map<String, Task> tasksFromCE = contentBO.getTasks(osName, caseid);

			List<TaskStepInfo> stepInfo = taskStepMapper.getTaskStepInfo(tasksFromCE.keySet());
			sortedTaskList = setStepInfoOnTask(new ArrayList<Task>(tasksFromCE.values()), stepInfo);

		} else {
			StringBuffer solutionName = new StringBuffer();
			String caseType = solution.getCaseType();

			solutionName.append("'").append(solution.getSoultionName()).append("'");
			if (CommonConstants.ASSET_TRANSFER_OPERATIONS.equalsIgnoreCase(solution.getSoultionName())) {
				solutionName.append(", ").append("'Brokerage Operations'");
			}

			List<Task> taskList = caseMapper.getTasks(getCaseIdsForTaskList(caseid, solution), solutionName.toString(),
					caseType);

			// Creating List of unique tasks
			Map<String, Task> uniqueRecords = new HashMap<String, Task>();
			for (Task taskObj : taskList) {
				if ((!uniqueRecords.containsKey(taskObj.getId())) && ("Task".equalsIgnoreCase(taskObj.getEventClass()))
						&& (taskObj.getStatus().equalsIgnoreCase("Started")
								|| taskObj.getStatus().equalsIgnoreCase("Initiated"))) {
					uniqueRecords.put(taskObj.getId(), taskObj);
					logger.debug("Task id After setting in to map::::" + taskObj.getId());
				}
			}

			// Including tasks in unique task list which are not having Started
			// or
			// Initiated status
			for (Task taskObj : taskList) {
				if ((!uniqueRecords.containsKey(taskObj.getId()))
						&& ("Task".equalsIgnoreCase(taskObj.getEventClass()))) {
					uniqueRecords.put(taskObj.getId(), taskObj);
					logger.debug("Task id After setting in to map::::" + taskObj.getId());
				}
			}
			// Getting final step statuses from property file

			String stepStatuses = AppPropertiesProvider.getProperty("STEP-FINAL-STATUSES");
			List stepStatusList = new ArrayList();
			for (String stepFinalStatus : stepStatuses.split(",")) {
				stepStatusList.add(stepFinalStatus);
			}

			// Building Status records for tasks in unique task list
			for (String taskId : uniqueRecords.keySet()) {
				List<Status> statuses = new ArrayList<Status>();
				String actionedBy = null;
				Date completedDate = null;
				for (Task taskObj : taskList) {
					// for the task statuses comparing with eventId --
					// taskObj.getId() - is eventId here
					if (taskId.equals(taskObj.getId())) {
						statuses.add(getTaskStatus(taskObj));
						// for the Step statuses comparing with the parentId
					} else if (taskId.equals(taskObj.getParentId())) {
						/*
						 * If step action is Started/Open then ignore step
						 * record and for all stepStatusList step action
						 * statuses take actionedBy completedDate from step
						 */

						if ("Started".equals(taskObj.getStatus()) || "Open".equals(taskObj.getStatus())) {
							continue;
						} else if (stepStatusList.contains(taskObj.getStatus())) {
							actionedBy = taskObj.getCreatedBy();
							completedDate = taskObj.getCreatedOn();
						} else {
							statuses.add(getTaskStatus(taskObj));
						}
					}
				}

				// For the status of task which completes a task, set statusBy
				// and
				// statusOn from step
				for (Status status : statuses) {
					if (stepStatusList.contains(status.getStatus())) {
						if (actionedBy != null) {
							status.setStatusBy(actionedBy);
						}

						if (completedDate != null) {
							status.setStatusOn(completedDate);
						}
					}
				}
				uniqueRecords.get(taskId).setStatuses(statuses);
			}

			sortedTaskList.addAll(uniqueRecords.values());
		}
		Collections.sort(sortedTaskList, taskComparatorByDateDescending);

		return sortedTaskList;
	}

	private List<Task> setStepInfoOnTask(List<Task> sortedTaskList, List<TaskStepInfo> taskStepInfoList) {
		// stepInfo is from DB, taskList is from CE
		for (org.tiaa.icm.client.domain.Task task : sortedTaskList) {
			// if the task exists in D_STEP, its human
			for (TaskStepInfo taskStepInfo : taskStepInfoList) {
				if (taskStepInfo.getTaskId().equals(task.getId())) {
					populateStatusBy(task, taskStepInfo);
					task.setType(CommonConstants.HUMAN);
					logger.debug("Task Id:" + task.getId() + ",task createdOn:" + task.getCreatedOn()
							+ ",taskStepInfo.getTaskStartedOn():" + taskStepInfo.getTaskStartedOn());
				}
			}
			// found no entry in taskStepInfoList/D_STEP - mark it as system
			if (task.getType() == null) {
				task.setType(CommonConstants.SYSTEM);
			}
		}

		return sortedTaskList;

	}

	private void populateStatusBy(org.tiaa.icm.client.domain.Task task, TaskStepInfo step) {

		for (Status status : task.getStatuses()) {
			// logger.debug("task ID:" + task.getId() + ",before populating
			// started/completed by:" + status.getStatusBy());
			String userName = null;

			if (CommonConstants.COMPLETED.equalsIgnoreCase(status.getStatus())) {
				userName = step.getStepActionTakenBy();
			} else if (CommonConstants.STARTED.equalsIgnoreCase(status.getStatus())) {
				userName = step.getTaskStartedBy();
			}
			// if userName is not null in DB, get it - else leave
			// whatever was from CE
			if (userName != null) {
				userName = userName.toLowerCase().startsWith(CommonConstants.CE_ADMIN_USER) ? CommonConstants.SYSTEM
						: userName;
				status.setStatusBy(userName);
			}
			// logger.debug("task ID:" + task.getId() + ",after populating
			// started/completed by:" + status.getStatusBy());
		}

	}

	private String getCaseIdsForTaskList(String caseId, Solution solution) {
		String boCaseId = null;
		StringBuffer caseIds = new StringBuffer();
		caseIds.append("'").append(caseId).append("'");

		// For ATO solutions, fetch tasks from both Brokerage case id and ATO
		// case id
		if ((solution != null) && (solution.getSoultionName() != null)
				&& solution.getSoultionName().equalsIgnoreCase(CommonConstants.ASSET_TRANSFER_OPERATIONS)) {
			if (solution.getConfirmation() != null) {
				List<String> boCaseIds = caseMapper.getParallelCaseId(solution.getConfirmation(), caseId);
				if ((boCaseIds != null) && (boCaseIds.size() > 0)) {
					boCaseId = boCaseIds.get(0);
				}
			}
		}

		if (boCaseId != null) {
			caseIds.append(", '").append(boCaseId).append("'");
		}

		return caseIds.toString();
	}

	private Status getTaskStatus(Task taskObj) {
		Status status = new Status();
		status.setStatus(taskObj.getStatus());
		status.setStatusBy(taskObj.getCreatedBy());
		status.setStatusOn(taskObj.getCreatedOn());
		return status;
	}

	private static class TaskComparatorByDateDescending implements Comparator<Task> {
		@Override
		public int compare(Task o1, Task o2) {
			// descending order

			if ((null != o2.getCreatedOn()) && (null != o1.getCreatedOn())) {
				// logger.debug(o1.getId() + ":o1.getCreatedOn():" +
				// o1.getCreatedOn() + "," + o1.getId()
				// + ",o2.getCreatedOn():" + o2.getCreatedOn());

				final int i = o2.getCreatedOn().compareTo(o1.getCreatedOn());
				// logger.debug("o2.getCreatedOn().compareTo(o1.getCreatedOn():"
				// + i);
				if (i != 0) {
					return i;
				}
			}
			int compareReturn = 0;
			if ((o2.getSequence() != null) && (o1.getSequence() != null)) {
				compareReturn = o2.getSequence().compareTo(o1.getSequence());
			}
			return compareReturn;
		}
	}

	private ResponseList createResponseList(List pagedList, int size, int start) {
		int maxSize = 0;
		if (start <= 0) {
			start = 1;
		}
		ResponseList responseList = new ResponseList();
		responseList.setResults(pagedList);
		if ((pagedList != null) && (pagedList.size() > 0)) {
			maxSize = pagedList.size();
		} else {
			size = 0;
		}
		responseList.setStart(start);
		if (maxSize > 0) {
			responseList.setEnd((start + maxSize) - 1);
		}

		responseList.setTotalRecords(size);
		logger.debug("In createResponseList - responseList:" + responseList);
		return responseList;
	}

	public List<Event> getHistory(String osName, String caseid, String type) {
		return contentBO.getHistory(osName, caseid, type);
	}

	public Response addCaseComments(String osName, String caseId, String commentText) {

		try {
			Id id = contentBO.addCaseComments(osName, caseId, commentText);
			response = responseUtil.createSuccessResponse(id.toString());
		} catch (Exception e) {
			response = responseUtil.createFailureResponse(e);
		}
		return response;
	}

	public Response addTaskComments(String osName, String caseId, String taskId, String commentText) {

		try {
			Id id = contentBO.addTaskComments(osName, caseId, taskId, commentText);
			response = responseUtil.createSuccessResponse(id.toString());
		} catch (Exception e) {
			response = responseUtil.createFailureResponse(e);
		}
		return response;
	}

	public Response addDocumentComments(String osName, String caseId, String docId, String commentText) {

		try {
			Id id = contentBO.addDocumentComments(osName, caseId, docId, commentText);
			response = responseUtil.createSuccessResponse(id.toString());
		} catch (Exception e) {
			response = responseUtil.createFailureResponse(e);
		}
		return response;
	}

	public Response stepComments(String osName, String caseId, String wobId, String queueName, String commentText,
			String racfId) {

		try {
			Id id = contentBO.addStepComments(osName, caseId, wobId, queueName, commentText, racfId);
			response = responseUtil.createSuccessResponse(id.toString());
		} catch (Exception e) {
			response = responseUtil.createFailureResponse(e);
		}
		return response;
	}

	public Response createDocument(String osName, String caseId, Document document) {

		try {
			Id id = contentBO.createDocument(osName, caseId, document);
			response = responseUtil.createSuccessResponse(id.toString());
		} catch (Exception e) {
			response = responseUtil.createFailureResponse(e);
		}
		return response;
	}

	public Response updateDocument(String osName, String caseId, Document document, String documentId) {

		try {
			Id id = contentBO.updateDocument(osName, caseId, document, documentId);
			response = responseUtil.createSuccessResponse(id.toString());
		} catch (Exception e) {
			response = responseUtil.createFailureResponse(e);
		}
		return response;
	}

	public List<RelatedCase> getRelatedCases(String osName, String caseId, String solutionName) {
		List<RelatedCase> relatedCases = new ArrayList<RelatedCase>();
		logger.debug("solution Name in getRelatedCases:" + solutionName);

		solutionName = solutionName == null ? "" : solutionName;

		if (CommonConstants.PAYIN_OPERATIONS.equalsIgnoreCase(solutionName)
				|| CommonConstants.PARTICIPANT_MAINTENANCE_OPERATIONS.equalsIgnoreCase(solutionName)) {
			relatedCases = relatedCasesMapper.getRelatedCasesForPI_PMO(caseId);
		} else if (CommonConstants.BROKERAGE_OPERATIONS.equalsIgnoreCase(solutionName)) {
			relatedCases = relatedCasesMapper.getRelatedCasesForBO(caseId);
		} else {
			relatedCases = relatedCasesMapper.getRelatedCases(caseId);

			if (CommonConstants.PAYOUT_OPERATIONS.equalsIgnoreCase(solutionName)) {
				for (RelatedCase relatedCase : relatedCases) {
					// if the relatedCase is a PI, get the loanId and set it in
					// confirmation
					if (relatedCase.getCaseIdentifier().startsWith("PI")) {
						String loanId = relatedCasesMapper.getLoanId(relatedCase.getCaseId());
						logger.debug("PI CaseId:" + relatedCase.getCaseId() + ",loan Id" + loanId);
						relatedCase.setConfirmation(loanId);
						logger.debug("what is in relatedcaseList:" + relatedCase.getConfirmation());
					}
				}
			}
		}
		return relatedCases;

	}

}
