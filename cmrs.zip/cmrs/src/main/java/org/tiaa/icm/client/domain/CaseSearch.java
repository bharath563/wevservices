package org.tiaa.icm.client.domain;

import java.util.Iterator;
import java.util.List;

public class CaseSearch {
	private List<String> pins;
	private String clientId;
	private String confirmation;
	private DateRange dateRange;
	private String caseType;
	private String channel;
	private List<String> ssns;
	private String caseStatus;
	private String plan;

	private String sortField;
	private String sortOrder;
	
	private String solution;

	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}

	public List<String> getPins() {
		return pins;
	}

	public void setPins(List<String> pins) {
		this.pins = pins;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getConfirmation() {
		return confirmation;
	}

	public void setConfirmation(String confirmation) {
		this.confirmation = confirmation;
	}

	public DateRange getDateRange() {
		return dateRange;
	}

	public void setDateRange(DateRange dateRange) {
		this.dateRange = dateRange;
	}

	public String getCaseType() {
		return caseType;
	}

	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public List<String> getSsns() {
		return ssns;
	}

	public void setSsns(List<String> ssns) {
		this.ssns = ssns;
	}

	public String getCaseStatus() {
		return caseStatus;
	}

	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}

	public String getPlan() {
		return plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public String getSortField() {
		return sortField;
	}

	public void setSortField(String sortField) {
		this.sortField = sortField;
	}

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	@Override
	public String toString() {
		StringBuffer sBufCaseSearch = new StringBuffer();
		sBufCaseSearch.append("{");
		appendStrProperty(sBufCaseSearch, "pins", pins);
		appendStrProperty(sBufCaseSearch, "clientId", clientId);
		appendStrProperty(sBufCaseSearch, "confirmation", confirmation);
		appendStrProperty(sBufCaseSearch, "plan", plan);
		appendStrProperty(sBufCaseSearch, "dateRange", dateRange);
		appendStrProperty(sBufCaseSearch, "caseType", caseType);
		appendStrProperty(sBufCaseSearch, "channel", channel);
		appendStrProperty(sBufCaseSearch, "ssns", ssns);
		appendStrProperty(sBufCaseSearch, "caseStatus", caseStatus);

		appendStrProperty(sBufCaseSearch, "sortOrder", sortOrder);
		appendStrProperty(sBufCaseSearch, "sortField", sortField);
		appendStrProperty(sBufCaseSearch, "solution", solution);

		sBufCaseSearch.append("}");
		return sBufCaseSearch.toString();
	}

	private void appendStrProperty(StringBuffer sBufCaseSearch, String property, DateRange dateRange) {
		if (dateRange != null) {
			dateRange.toString(sBufCaseSearch);
		}
	}

	private void appendStrProperty(StringBuffer sBufCaseSearch, String property, String value) {
		if (value != null) {
			if (sBufCaseSearch.indexOf("=") > -1) {
				sBufCaseSearch.append(",").append(property).append("=").append(value);
			} else {
				sBufCaseSearch.append(property).append("=").append(value);
			}
		}
	}

	private void appendStrProperty(StringBuffer sBufCaseSearch, String property, List<String> value) {
		if (value != null) {

			Iterator<String> iter = value.iterator();
			while (iter.hasNext()) {
				String pin = iter.next();
				if (value.size() > 1) {
					sBufCaseSearch.append(",").append(property).append("=");
				} else {
					sBufCaseSearch.append(property).append("=").append(value);
				}
				sBufCaseSearch.append(pin);
			}

		}
	}

}
