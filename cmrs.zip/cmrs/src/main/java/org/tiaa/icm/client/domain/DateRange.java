package org.tiaa.icm.client.domain;

public class DateRange {
	private String type;
	private String from;
	private String to;

	public void setType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public void toString(StringBuffer sBufCaseSearch) {
		StringBuffer sBufDateRange = new StringBuffer();
		if (sBufCaseSearch.indexOf("=") > -1) {
			sBufCaseSearch.append(",DateRange {");
		} else {
			sBufCaseSearch.append("DateRange {");
		}
		appendStrProperty(sBufDateRange, "type", type);
		appendStrProperty(sBufDateRange, "from", from);
		appendStrProperty(sBufDateRange, "to", to);
		sBufCaseSearch.append(sBufDateRange.toString());
		sBufCaseSearch.append("}");
	}

	private void appendStrProperty(StringBuffer sBufDateRange, String property, String value) {
		if (value != null) {
			if (sBufDateRange.indexOf("=") > -1) {
				sBufDateRange.append(",").append(property).append("=").append(value);
			} else {
				sBufDateRange.append(property).append("=").append(value);
			}
		}
	}

}
