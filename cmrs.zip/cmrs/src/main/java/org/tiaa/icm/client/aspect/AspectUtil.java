package org.tiaa.icm.client.aspect;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.sql.SQLException;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Request;
import org.tiaa.icm.client.domain.Response;
import org.tiaa.icm.client.mapper.LogMapper;
import org.tiaa.icm.client.provider.AppPropertiesProvider;
import org.tiaa.icm.client.utils.ICMClientUtil;

public class AspectUtil {

	@Autowired
	private LogMapper logMapper;

	private static Logger LOGGER = Logger.getLogger(AspectUtil.class);

	private static final String REQUEST_SQN = "REQUEST_SQN";

	public Request insertRequestLog(Object[] args, String className)
			throws ClassNotFoundException, SQLException, UnsupportedEncodingException {
		Request icmrsRequest = new Request();
		String headerName = null;
		String decodedUrl = null;

		try {
			Class<?> castClass = Class.forName(className);
			for (int i = 0; i < args.length; i++) {
				if (castClass.isInstance(args[i])) {
					Object obj = castClass.cast(args[i]);
					icmrsRequest.setRequestPayload(obj.toString());
				}

				if (args[i] instanceof HttpServletRequest) {
					HttpServletRequest request = (HttpServletRequest) args[i];
					int reqSequenceNo = logMapper.selectSequence();
					icmrsRequest.setRequestSqn(reqSequenceNo);
					HttpSession session = request.getSession(true);
					session.setAttribute(REQUEST_SQN, reqSequenceNo);
					icmrsRequest.setSessionId(request.getSession().getId());
					icmrsRequest.setHttpMethod(request.getMethod());
					String url = request.getRequestURL().toString();

					String queryString = request.getQueryString() == null ? "" : "?" + request.getQueryString();
					if ((queryString != null) && (queryString.length() > 0)) {
						decodedUrl = URLDecoder.decode(url + queryString, "UTF-8");
					} else {
						decodedUrl = URLDecoder.decode(request.getRequestURL().toString(), "UTF-8");
					}
					icmrsRequest.setUri(decodedUrl);
					Enumeration<String> headerNames = request.getHeaderNames();
					while (headerNames.hasMoreElements()) {
						headerName = headerNames.nextElement();
						if ("msg-guid".equalsIgnoreCase(headerName)) {
							icmrsRequest.setMsgguid(request.getHeader(headerName));
						}
						if ("dp-transaction-id".equalsIgnoreCase(headerName)) {
							icmrsRequest.setDpTransactionId(request.getHeader(headerName));
						}
						if ("correlation-id".equalsIgnoreCase(headerName)) {
							icmrsRequest.setCorrelationId(request.getHeader(headerName));
						}
						if ("racfid".equalsIgnoreCase(headerName)) {
							icmrsRequest.setUserId(request.getHeader(headerName));
						}
						if ("content-type".equalsIgnoreCase(headerName)) {
							String contentType = request.getHeader(headerName);
							if ((contentType != null) && (contentType.indexOf(";") > -1)) {
								icmrsRequest.setContentType(ICMClientUtil.stringBeforeGivenChar(contentType, ';'));
							} else {
								icmrsRequest.setContentType(contentType);
							}
						}
						if ("client-address".equalsIgnoreCase(headerName)) {
							icmrsRequest.setClientAddress(request.getHeader(headerName));
						}
						if ("dp-device-id".equalsIgnoreCase(headerName)) {
							icmrsRequest.setDeviceId(request.getHeader(headerName));
						}
						if ("date-time".equalsIgnoreCase(headerName)) {
							icmrsRequest.setRequestReceivedTime(
									ICMClientUtil.stringBeforeGivenChar(request.getHeader(headerName), '.'));

						} /*
							 * else {
							 * icmrsRequest.setRequestReceivedTime(ICMClientUtil
							 * .getCurrentDateWithTime()); }
							 */

					}
					if (icmrsRequest.getRequestReceivedTime() == null) {
						icmrsRequest.setRequestReceivedTime(ICMClientUtil.getCurrentDateWithTime());
					}
				}
			}
			logMapper.insertLog(icmrsRequest);
		} catch (Exception e) {
			e.printStackTrace();
			// e.getMessage();
		}
		return icmrsRequest;
	}

	public Request updateResultLog(Object[] args, Object result) throws IOException {
		Request icmrsRequest = new Request();
		Response icmClientResponse = new Response();
		ObjectMapper mapper = new ObjectMapper();
		HttpServletRequest request = null;
		HttpSession session = null;
		LOGGER.debug("entered updateResultLog");
		try {
			for (int i = 0; i < args.length; i++) {
				if (args[i] instanceof HttpServletRequest) {
					request = (HttpServletRequest) args[i];
				}

				icmrsRequest.setStatus(CommonConstants.SUCCESS);
				if (result instanceof Response) {
					icmClientResponse = (Response) result;
					if ((icmClientResponse.getStatus() != null)
							&& icmClientResponse.getStatus().equalsIgnoreCase("ERROR")) {
						icmrsRequest.setStatus(CommonConstants.FAILURE);
					}
				}
			}
			String responseString = mapper.writeValueAsString(result);

			if (responseString.length() <= AppPropertiesProvider.getIntProperty("maxResponsePayloadSize")) {
				icmrsRequest.setResponsePayload(responseString.replaceAll("\\\\", ""));
			} else {
				icmrsRequest.setResponsePayload("Response payload size is greater than "
						+ AppPropertiesProvider.getIntProperty("maxResponsePayloadSize"));
			}
			icmrsRequest.setResponseSentTime(ICMClientUtil.getCurrentDateWithTime());
			session = request.getSession(false);
			icmrsRequest.setRequestSqn((Integer) session.getAttribute(REQUEST_SQN));
			LOGGER.debug("just before updateLog");
			logMapper.updateLog(icmrsRequest);
			LOGGER.debug("after updateLog");
		} catch (Exception e) {
			e.printStackTrace();
			// e.getMessage();
		} finally {
			if (session != null) {
				session.removeAttribute(REQUEST_SQN);
			}
		}
		LOGGER.debug("exiting updateResultLog");
		return icmrsRequest;
	}

	public Request afterThrowingException(Object[] args, Throwable e) throws IOException {
		Request icmrsRequest = new Request();
		HttpServletRequest request = null;
		HttpSession session = null;
		try {
			for (int i = 0; i < args.length; i++) {
				if (args[i] instanceof HttpServletRequest) {
					request = (HttpServletRequest) args[i];
				}
			}
			icmrsRequest.setStatus(CommonConstants.FAILURE);
			icmrsRequest.setResponsePayload(e.toString());
			icmrsRequest.setResponseSentTime(ICMClientUtil.getCurrentDateWithTime());
			session = request.getSession(false);
			icmrsRequest.setRequestSqn((Integer) session.getAttribute(REQUEST_SQN));
			logMapper.updateLog(icmrsRequest);
		} catch (Exception ex) {
			e.printStackTrace();
			// e.getMessage();
		} finally {
			if (session != null) {
				session.removeAttribute(REQUEST_SQN);
			}
		}
		return icmrsRequest;
	}

}
