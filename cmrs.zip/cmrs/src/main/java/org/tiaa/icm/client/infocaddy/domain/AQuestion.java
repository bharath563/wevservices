package org.tiaa.icm.client.infocaddy.domain;

import java.sql.Timestamp;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import org.apache.ibatis.type.Alias;

@Alias("aQuestion")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class AQuestion {

	public AQuestion() {

	}

	String questionSqn;
	String id;
	String question;
	String value;
	Timestamp questionTS;
	String questionAT;
	Timestamp updatedTS;
	String questionSrc;
	String questionSetName;

	public String getQuestionSqn() {
		return questionSqn;
	}

	public void setQuestionSqn(String questionSqn) {
		this.questionSqn = questionSqn;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Timestamp getQuestionTS() {
		return questionTS;
	}

	public void setQuestionTS(Timestamp questionTS) {
		this.questionTS = questionTS;
	}

	public String getQuestionAT() {
		return questionAT;
	}

	public void setQuestionAT(String questionAT) {
		this.questionAT = questionAT;
	}

	public Timestamp getUpdatedTS() {
		return updatedTS;
	}

	public void setUpdatedTS(Timestamp updatedTS) {
		this.updatedTS = updatedTS;
	}

	/**
	 * @return the questionSrc
	 */
	public String getQuestionSrc() {
		return questionSrc;
	}

	/**
	 * @param questionSrc
	 *            the questionSrc to set
	 */
	public void setQuestionSrc(String questionSrc) {
		this.questionSrc = questionSrc;
	}

	/**
	 * @return the questionSetName
	 */
	public String getQuestionSetName() {
		return questionSetName;
	}

	/**
	 * @param questionSetName
	 *            the questionSetName to set
	 */
	public void setQuestionSetName(String questionSetName) {
		this.questionSetName = questionSetName;
	}
}
