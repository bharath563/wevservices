package org.tiaa.icm.client.infocaddy.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.type.Alias;

import org.tiaa.icm.client.infocaddy.domain.AOmniTransactions;

@Alias("aOmniTransactions")
public interface OmniTransactionsMapper {

	public AOmniTransactions fetchLoanOmniTransaction(@Param("omniSqn") Long omniSqn);

}
