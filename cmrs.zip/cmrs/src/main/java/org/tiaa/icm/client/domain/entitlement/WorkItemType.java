package org.tiaa.icm.client.domain.entitlement;

import java.util.List;

import org.codehaus.jackson.annotate.JsonSubTypes;
import org.codehaus.jackson.annotate.JsonSubTypes.Type;
import org.codehaus.jackson.annotate.JsonTypeInfo;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "@type", defaultImpl = Unassigned.class)
@JsonSubTypes({ @Type(value = Unassigned.class, name = "unassigned"), @Type(value = Pended.class, name = "pended"),
		@Type(value = AllAssigned.class, name = "allassigned") })
public abstract class WorkItemType {

	public abstract String getType();

	public abstract String getName();

	public abstract List<String> getQueues();

	public abstract String getFilters();

	public WorkItemType() {
	}

}
