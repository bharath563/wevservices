package org.tiaa.icm.client.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.QueryParam;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import org.tiaa.icm.client.bean.CaseBean;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Case;
import org.tiaa.icm.client.domain.CaseSearch;
import org.tiaa.icm.client.domain.Comment;
import org.tiaa.icm.client.domain.Document;
import org.tiaa.icm.client.domain.Event;
import org.tiaa.icm.client.domain.RelatedCase;
import org.tiaa.icm.client.domain.Response;
import org.tiaa.icm.client.domain.ResponseList;
import org.tiaa.icm.client.domain.Task;
import org.tiaa.icm.client.infocaddy.bean.InfoCaddyBean;
import org.tiaa.icm.client.utils.ICMClientUtil;

import filenet.vw.api.VWException;

@Controller
public class CaseController extends BaseController {

	static Logger LOG = Logger.getLogger(CaseController.class);

	@Autowired
	private CaseBean caseBean;

	@Autowired
	Response icmClientResponse;

	@Autowired
	private InfoCaddyBean infoCaddyBean;

	@Value("${DEFAULT-OBJECT-STORE}")
	private String osName;

	@RequestMapping(value = "/cases", method = RequestMethod.POST)
	public @ResponseBody ResponseList searchCase(@RequestBody CaseSearch caseSearch, HttpServletRequest request,
			@RequestParam(value = "start", required = false) String start, @RequestHeader("racfId") String racfId)
			throws Exception {
		LOG.debug("Case Search for PIN-->" + caseSearch.getPins());
		LOG.debug("Case Search for racfId-->" + racfId);
		return caseBean.searchCase(caseSearch, start, osName);
	}

	@RequestMapping(value = "/cases/{caseid}", method = RequestMethod.GET)
	public @ResponseBody Case getCaseProperties(@PathVariable("caseid") String caseid, HttpServletRequest request,
			@RequestHeader("racfId") String racfId, @QueryParam("section") String section,
			@QueryParam("solution") String solution, @RequestParam(value = "start", required = false) String start,
			@RequestParam(value = "sortBy", required = false) String sortBy,
			@RequestParam(value = "sortOrder", required = false) String sortOrder,
			@RequestParam(value = "tableName", required = false) String tableName,
			@RequestParam(value = "groupId", required = false) String groupId) throws Exception {
		LOG.debug(" for Case ID-->" + caseid);

		Case caseObj = new Case();

		if (!ICMClientUtil.isEmpty(section) && !ICMClientUtil.isEmpty(solution)) {

			Map<String, String> parameters = new HashMap<String, String>();
			parameters.put("start", start);
			parameters.put("sortBy", sortBy);
			parameters.put("sortOrder", sortOrder);
			parameters.put("tableName", tableName);
			parameters.put("groupId", groupId);

			List<Object> infoCaddyList = infoCaddyBean.getInfoCaddyDetails(caseid, solution, section, parameters);
			caseObj.getAdditionalIdentifiers().clear();
			caseObj.setInfoCaddyDetails(infoCaddyList);

		} else {
			caseObj = caseBean.getCaseProperties(osName, caseid);
		}

		return caseObj;
	}

	@RequestMapping(value = "/cases/{caseid}/documents", method = RequestMethod.GET)
	public @ResponseBody ResponseList getCaseDocuments(@PathVariable("caseid") String caseid,
			HttpServletRequest request, @RequestHeader("racfId") String racfId,
			@RequestParam(value = "start", required = false) String start) throws LoginException {
		LOG.debug("Get Documents for Case ID-->" + caseid);
		List<Document> documentList = caseBean.getDocuments(osName, caseid);
		return callResponseSubList(documentList, start);
	}

	@RequestMapping(value = "/cases/{caseid}/comments", method = RequestMethod.GET)
	public @ResponseBody ResponseList getComments(@PathVariable("caseid") String caseid, HttpServletRequest request,
			@RequestHeader("racfId") String racfId, @RequestParam(value = "start", required = false) String start)
			throws LoginException {
		LOG.debug("Get Comments for Case ID-->" + caseid);
		List<Comment> commentList = caseBean.getComments(osName, caseid);
		return callResponseSubList(commentList, start);
	}

	@RequestMapping(value = "/cases/{caseid}/tasks", method = RequestMethod.GET)
	public @ResponseBody ResponseList getTasks(@PathVariable("caseid") String caseid, HttpServletRequest request,
			@RequestHeader("racfId") String racfId, @RequestParam(value = "start", required = false) String start)
			throws LoginException {
		List<Task> taskList = caseBean.getTasks(osName, caseid, start);
		return callResponseSubList(taskList, start);
	}

	@RequestMapping(value = "/cases/{caseid}/history", method = RequestMethod.GET)
	public @ResponseBody ResponseList getHistory(@PathVariable("caseid") String caseid, HttpServletRequest request,
			@RequestHeader("racfId") String racfId, @RequestParam(value = "start", required = false) String start,
			@RequestParam(value = "type", required = false) String type) throws LoginException {
		LOG.debug("Get History for Case ID-->" + caseid);
		List<Event> eventList = caseBean.getHistory(osName, caseid, type);
		return callResponseSubList(eventList, start);
	}

	@RequestMapping(value = "/cases/{caseid}/comments", method = RequestMethod.POST)
	public @ResponseBody Response addCaseComments(@PathVariable("caseid") String caseId, HttpServletRequest request,
			@RequestBody Comment comment, @RequestHeader("racfId") String racfId) throws LoginException {
		LOG.debug("Get add case comments for Case ID-->" + caseId);
		return caseBean.addCaseComments(osName, caseId, comment.getComment());
	}

	@RequestMapping(value = "/cases/{caseid}/tasks/{taskid}/comments", method = RequestMethod.POST)
	public @ResponseBody Response addTaskComments(@PathVariable("caseid") String caseId,
			@PathVariable("taskid") String taskid, HttpServletRequest request, @RequestHeader("racfId") String racfId,
			@RequestBody Comment comment) throws LoginException {
		LOG.debug("Get add task Comments for Case ID-->" + taskid);
		return caseBean.addTaskComments(osName, caseId, taskid, comment.getComment());
	}

	@RequestMapping(value = "/cases/{caseid}/documents/{documentid}/comments", method = RequestMethod.POST)
	public @ResponseBody Response documentComments(@PathVariable("caseid") String caseId,
			@PathVariable("documentid") String docid, HttpServletRequest request,
			@RequestHeader("racfId") String racfId, @RequestBody Comment comment) throws LoginException {
		LOG.debug("Get add document Comments for Case ID-->" + docid);
		return caseBean.addDocumentComments(osName, caseId, docid, comment.getComment());
	}

	@RequestMapping(value = "/cases/{caseid}/step/{wobid}/comments", method = RequestMethod.POST)
	public @ResponseBody Response stepComments(@PathVariable("caseid") String caseId,
			@PathVariable("wobid") String wobId, HttpServletRequest request, @RequestHeader("racfId") String racfId,
			@RequestBody Comment comment, @QueryParam("queueName") String queueName)
			throws LoginException, VWException {
		LOG.debug("Get add Step Comments for WOB ID-->" + wobId);
		try {
			icmClientResponse = caseBean.stepComments(osName, caseId, wobId, queueName, comment.getComment(), racfId);
		} catch (Exception e) {
			icmClientResponse.setErrorMessage(e.getLocalizedMessage());
			icmClientResponse.setStatus(CommonConstants.ERROR);
			e.getMessage();
		}
		return icmClientResponse;

	}

	@RequestMapping(value = "/cases/{caseid}/documents", method = RequestMethod.POST)
	public @ResponseBody Response createDocument(@PathVariable("caseid") String caseId, HttpServletRequest request,
			@RequestHeader("racfId") String racfId, @RequestBody Document document) throws LoginException {

		LOG.debug("Get add document Comments for Case ID-->" + caseId + "document-----" + document);
		return caseBean.createDocument(osName, caseId, document);
	}

	@RequestMapping(value = "/cases/{caseid}/documents/{documentid}", method = RequestMethod.PUT)
	public @ResponseBody Response updateDocument(@PathVariable("caseid") String caseId,
			@PathVariable("documentid") String documentId, HttpServletRequest request,
			@RequestHeader("racfId") String racfId, @RequestBody Document document) throws LoginException {
		LOG.debug("Get update document for Case ID-->" + caseId);
		return caseBean.updateDocument(osName, caseId, document, documentId);
	}

	@RequestMapping(value = "/cases/{caseid}/relatedcases", method = RequestMethod.GET)
	public @ResponseBody ResponseList getRelatedCases(@PathVariable("caseid") String caseid, HttpServletRequest request,
			@RequestHeader("racfId") String racfId, @RequestParam(value = "start", required = false) String start,
			@RequestParam(value = "solutionName", required = false) String solutionName) throws LoginException {
		LOG.debug("Get RelatedCases for Case ID-->" + caseid);
		List<RelatedCase> relatedCases = caseBean.getRelatedCases(osName, caseid, solutionName);
		return callResponseSubList(relatedCases, start);
	}

}
