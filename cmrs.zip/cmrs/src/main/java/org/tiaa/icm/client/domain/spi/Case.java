package org.tiaa.icm.client.domain.spi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.core.Folder;
import com.filenet.api.meta.ClassDescription;

import org.tiaa.icm.client.domain.Event;

public class Case implements IEvents {

	private Folder folder;

	public Case(Folder caseFolder) {
		this.folder = caseFolder;
	}

	@Override
	public List<Event> getEvents() {
		if (this.folder == null) {
			return null;
		}

		List<Event> events = new ArrayList<Event>();

		IndependentObjectSet ios = this.folder.get_AuditedEvents();

		Iterator<com.filenet.api.events.Event> ceEvents = ios.iterator();

		while (ceEvents.hasNext()) {
			Event event = new Event();
			com.filenet.api.events.Event caseEvent = ceEvents.next();
			ClassDescription classDesc = caseEvent.get_ClassDescription();
			// skip update Events.. we just need only creation events for case..
			if (classDesc.get_SymbolicName().equalsIgnoreCase("UpdateEvent")) {
				continue;
			}
			event.setType(org.tiaa.icm.client.constant.EventType.CASE.getType());
			event.setDescription("Case created");
			event.setCreatedOn(caseEvent.get_DateCreated());
			event.setCreatedBy(caseEvent.get_Creator());
			events.add(event);
		}

		return events;

	}

}
