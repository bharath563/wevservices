package org.tiaa.icm.client.rest.util;

import java.nio.charset.Charset;
import java.security.MessageDigest;

import org.apache.commons.codec.binary.Base64;

public class SecurityUtil {

	/**
	 *
	 */
	public SecurityUtil() {
		// TODO Auto-generated constructor stub
	}

	public final static String toBase64SHADigest(String value) {
		String shaDigest = null;
		try {
			MessageDigest digester = MessageDigest.getInstance("SHA");
			digester.reset();
			byte[] valueAsBytes = value.getBytes("UTF-8");
			digester.update(valueAsBytes, 0, valueAsBytes.length);
			byte[] hash = digester.digest();
			shaDigest = new String(Base64.encodeBase64(hash), Charset.forName("UTF-8"));
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
		return shaDigest;
	}
}