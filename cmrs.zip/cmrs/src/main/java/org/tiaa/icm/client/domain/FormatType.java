package org.tiaa.icm.client.domain;

/**
 * This enum is to define list of acceptable values for FormatType
 *
 * @author mamillv
 *
 */
public enum FormatType {
	Document, MobiusEmail, Voice;
}
