package org.tiaa.icm.client.domain.entitlement;

import java.util.List;

public class Profile {

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<String> getGroups() {
		return groups;
	}

	public void setGroups(List<String> groups) {
		this.groups = groups;
	}

	private String name;

	private List<String> groups;

}
