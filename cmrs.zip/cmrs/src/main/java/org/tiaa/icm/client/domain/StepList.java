package org.tiaa.icm.client.domain;

import java.util.List;

public class StepList {
	private List<Step> steps;

	public List<Step> getSteps() {
		return steps;
	}

	public void setSteps(List<Step> steps) {
		this.steps = steps;
	}

}
