package org.tiaa.icm.client.domain;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

import org.tiaa.icm.client.utils.ICMClientUtil;

@JsonSerialize(include = Inclusion.NON_NULL)
public class Case {

	private String id;
	private String type;
	private String channel;
	private String createdDate;
	private String requestReceivedDate;
	private String status;
	private String modifiedDate;
	private String pathName;
	private String confirmation;
	private String pin;
	private String clientId;
	private int totalRecords;
	private HashMap<String, Object> additionalIdentifiers;
	@JsonIgnore
	private Date createdDt;
	@JsonIgnore
	private Date requestReceivedDt;
	@JsonIgnore
	private Date modifiedDt;
	private String plan;
	private String solution;
	private List<Object> infoCaddyDetails;

	public List<Object> getInfoCaddyDetails() {
		return infoCaddyDetails;
	}

	public void setInfoCaddyDetails(List<Object> infoCaddyDetails) {
		this.infoCaddyDetails = infoCaddyDetails;
	}

	@JsonIgnore
	public Date getCreatedDt() {
		return createdDt;
	}

	@JsonIgnore
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	@JsonIgnore
	public Date getRequestReceivedDt() {
		return requestReceivedDt;
	}

	@JsonIgnore
	public void setRequestReceivedDt(Date requestReceivedDt) {
		this.requestReceivedDt = requestReceivedDt;
	}

	@JsonIgnore
	public Date getModifiedDt() {
		return modifiedDt;
	}

	@JsonIgnore
	public void setModifiedDt(Date modifiedDt) {
		this.modifiedDt = modifiedDt;
	}

	public String getId() {
		return id;
	}

	public void setId(String caseId) {
		this.id = caseId;
	}

	public String getType() {
		return type;
	}

	public void setType(String caseType) {
		this.type = caseType;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String caseCreatedDate) {
		this.createdDate = caseCreatedDate;
	}

	@JsonSerialize(include = Inclusion.NON_NULL)
	public String getRequestReceivedDate() {

		return requestReceivedDate;
	}

	public void setRequestReceivedDate(String requestReceivedDate) {
		this.requestReceivedDate = requestReceivedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String caseStatus) {
		this.status = caseStatus;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	@JsonSerialize(include = Inclusion.NON_NULL)
	public String getPathName() {
		return pathName;
	}

	public void setPathName(String pathName) {
		this.pathName = pathName;
	}

	@JsonIgnore
	public String getConfirmation() {
		return confirmation;
	}

	public void setConfirmation(String confirmation) {
		this.confirmation = confirmation;
	}

	@JsonIgnore
	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	@JsonIgnore
	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	@JsonIgnore
	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}

	@JsonSerialize(include = JsonSerialize.Inclusion.NON_EMPTY)
	public HashMap<String, Object> getAdditionalIdentifiers() {
		if (additionalIdentifiers == null) {
			additionalIdentifiers = new HashMap<String, Object>();
			additionalIdentifiers.put("confirmation", getConfirmation());
			additionalIdentifiers.put("pin", getPin());
			additionalIdentifiers.put("clientId", getClientId());
			additionalIdentifiers.put("plan", getPlan());
			additionalIdentifiers.put("solution", getSolution());
		}
		return additionalIdentifiers;
	}

	public void setAdditionalIdentifiers(HashMap<String, Object> additionalIdentifiers) {
		this.additionalIdentifiers = additionalIdentifiers;
	}

	@JsonIgnore
	public int getTotalRecords() {
		return totalRecords;
	}

	public void setTotalRecords(int totalRecords) {
		this.totalRecords = totalRecords;
	}

	@JsonIgnore
	public String getPlan() {
		return plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	// @Override
	// public String toString() {
	// return "CaseDetails " + toString(this);
	// }
	@Override
	public String toString() {
		return ICMClientUtil.ObjectAsJSON(this);

	}

}
