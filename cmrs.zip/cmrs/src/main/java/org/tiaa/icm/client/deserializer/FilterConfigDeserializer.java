package org.tiaa.icm.client.deserializer;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import org.apache.log4j.Logger;

import org.tiaa.icm.client.domain.entitlement.WorkItemType;

public class FilterConfigDeserializer extends JsonDeserializer<Map<String, List<WorkItemType>>> {

	static Logger logger = Logger.getLogger(FilterConfigDeserializer.class);

	private static ObjectMapper mapper = new ObjectMapper();

	@Override
	public Map<String, List<WorkItemType>> deserialize(JsonParser parser, DeserializationContext context)
			throws IOException, JsonProcessingException {

		logger.debug("FilterConfigDeserializer -> Calling Deserialize");
		JsonNode node = parser.getCodec().readTree(parser);
		TypeReference<Map<String, List<WorkItemType>>> typeRef = new TypeReference<Map<String, List<WorkItemType>>>() {
		};
		Map<String, List<WorkItemType>> filters = mapper.readValue(node, typeRef);
		logger.debug(filters.size());
		return filters;
	}

}
