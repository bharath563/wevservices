package org.tiaa.icm.client.infocaddy.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.type.Alias;

import org.tiaa.icm.client.infocaddy.domain.AOmniProcess;

@Alias("aOmniProcess")
public interface OmniProcessMapper {

	public List<AOmniProcess> fetchOmniProcess(@Param("groupId") String groupId);
}
