package org.tiaa.icm.client.infocaddy.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.infocaddy.domain.PaymentMethod;
import org.tiaa.icm.client.infocaddy.domain.RepaymentDetails;
import org.tiaa.icm.client.infocaddy.json.Type;
import org.tiaa.icm.client.ldap.LDAPUtil;
import org.tiaa.icm.client.provider.AppPropertiesProvider;

public class InfoCaddyUtil {
	public static String[] SplitUsingTokenizer(String subject, String delimiters) {

		StringTokenizer st = new StringTokenizer(subject, delimiters);
		ArrayList<String> strs = new ArrayList<String>(subject.length());

		while (st.hasMoreTokens()) {
			strs.add(st.nextToken());
		}

		return strs.toArray(new String[0]);
	}

	public static String fetchPaymentMethod(RepaymentDetails repaymentInfo) {

		if (null != PaymentMethod.fromValue(repaymentInfo.getPaymentMethod())) {
			return PaymentMethod.fromValue(repaymentInfo.getPaymentMethod()).toString();
		} else {
			return repaymentInfo.getPaymentMethod();
		}

	}

	public static Type createPropertyType(String name, Object value) {

		Type type = new Type();

		type.setName(name);
		type.setType("property");
		type.setValue(value);

		return type;
	}

	// get racfId from a chatlink
	public static String getRacfId(String emailId) throws Exception {

		String racfId = "";
		emailId = emailId.substring(emailId.indexOf("href='sip:"), emailId.indexOf("' class=")).replace("href='sip:",
				"");
		racfId = LDAPUtil.getUserRacfid(emailId);

		return racfId;

	}

	// Remove Related Cases
	public static Type[] removeRelatedCase(Type[] infoCaddyDetails, Type type) {
		List<Type> list = new ArrayList<Type>(Arrays.asList(infoCaddyDetails));
		list.remove(type);
		infoCaddyDetails = list.toArray(new Type[0]);
		return infoCaddyDetails;
	}

	public static boolean checkChatLinksLabel(String label) {

		String chatLinks = AppPropertiesProvider.getProperty("chatLinks");
		List<String> chatLinksList = Arrays.asList(chatLinks.split(CommonConstants.DELIMITER_COMMA));
		boolean isChatLinkConfigured = false;

		for (String chatLinkStr : chatLinksList) {

			if (label.equalsIgnoreCase(chatLinkStr)) {
				isChatLinkConfigured = true;
				break;
			}

		}

		return isChatLinkConfigured;
	}

}
