package org.tiaa.icm.client.entitlement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.icm.client.cache.SolutionConfigCache;
import org.tiaa.icm.client.config.SolutionConfig;
import org.tiaa.icm.client.domain.entitlement.OperationalRole;
import org.tiaa.icm.client.domain.entitlement.Role;
import org.tiaa.icm.client.domain.entitlement.WorkItemType;
import org.tiaa.icm.client.mapper.FilterMapper;

public class IPSSolution extends AbstractSolution {

	private static Logger logger = Logger.getLogger(IPSSolution.class);

	@Autowired
	private FilterMapper filterMapper;

	@Override
	List<org.tiaa.icm.client.domain.entitlement.OperationalRole> compareRolesWithLDAP(String solution, String racfId,
			List<String> ldaps, String workItemType) {

		// key - RoleName, Value - Queue Object..
		// Key (role name) reason -> to avoid querying the same queue with the
		// same filter if user has mulitple role level LDAPs for the same role.

		Map<String, OperationalRole> roles = new HashMap<String, OperationalRole>();

		SolutionConfig config = SolutionConfigCache.getSolutionConfigCache().get(solution);

		if (config.getRoles() != null) {
			Iterator<Role> iter = config.getRoles().iterator();
			while (iter.hasNext()) {
				Role role = iter.next();
				/*
				 * If user has the particular role ldaps add the queue and
				 * filter to list of queue if he\she has entitled too..
				 */
				if (ldaps.containsAll(role.getGroups())) {
					logger.info("compareRolesWithLDAP()->User belongs to Role:'" + role.getName() + "'");
					OperationalRole queue = new OperationalRole();
					// get the queue info operational role name, queueName from
					// configuration and
					// filter from DB table tcfilenet.temp_registered_rep by
					// passing racfId
					if (config.getFilters().containsKey(role.getName())) {
						// get the workitem types
						Iterator<WorkItemType> iterator = config.getFilters().get(role.getName()).iterator();
						while (iterator.hasNext()) {
							List<String> queueNames = null;
							String roleName = null;
							String filters = null;

							WorkItemType type = iterator.next();
							if (type.getClass().toString().contains(workItemType)) {
								logger.debug(type.getClass().toString());
								queueNames = type.getQueues();
								if (getIPSSolutionFilters(racfId) != null) {
									filters = "LocationID IN (" + getIPSSolutionFilters(racfId) + ")";
									logger.debug("filters for IPS Solution--->" + filters);
								}
								roleName = role.getName();
								queue.setRoleName(roleName).setQueueNames(queueNames).setFilters(filters);
								roles.put(roleName, queue);
								// either Unassigned or Pended not both
								break;
							}

						}

					}

				}
			}
		}
		return new ArrayList<OperationalRole>(roles.values());
	}

	@Override
	List<OperationalRole> getQueueManagerRoles(List<OperationalRole> roles) {

		List<OperationalRole> queueManagers = new ArrayList<OperationalRole>();

		// is User part of QueueManager?
		if ((roles != null) && (roles.size() > 0)) {
			Iterator<OperationalRole> iter = roles.iterator();
			while (iter.hasNext()) {
				OperationalRole role = iter.next();
				if (role.getRoleName().startsWith("Queue Manager")) {
					queueManagers.add(role);
				}
			}
		}
		if (queueManagers.size() > 0) {
			logger.debug("User is part of QueueManager");
		}
		return queueManagers;
	}

	@Override
	List<OperationalRole> overrideRoles(String solution, List<OperationalRole> queues, List<String> ldaps,
			String type) {
		return null;
	}

	private String getIPSSolutionFilters(String racfId) {
		logger.info("Getting the filterInformation for the user'" + racfId + "'");
		String filters = null;
		try {
			List<String> locationsList = filterMapper.getFilterInformation(racfId);

			StringBuffer locationID = new StringBuffer();
			String location = null;
			if (locationsList != null) {
				Iterator<String> iter = locationsList.iterator();
				while (iter.hasNext()) {
					location = iter.next();
					locationID.append("'").append(location).append("'").append(",");
				}
				filters = locationID.substring(0, locationID.length() - 1);
			}
		} catch (IndexOutOfBoundsException e) {
			return null;
		}
		return filters;
	}

}
