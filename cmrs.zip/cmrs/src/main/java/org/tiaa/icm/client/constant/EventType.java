package org.tiaa.icm.client.constant;

public enum EventType {

	CASE("Case"), COMMENT("Comment"), FOLDER("Folder"), TASK("Task"), DOCUMENT("Document");

	String type;

	EventType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}
}
