package org.tiaa.icm.client.domain.spi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.filenet.api.collection.EventSet;
import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.core.Document;
import com.filenet.api.meta.ClassDescription;
import com.filenet.api.property.Properties;

import org.tiaa.icm.client.constant.EventType;
import org.tiaa.icm.client.domain.Event;

public class Documents implements IEvents {

	private IndependentObjectSet ios;

	public Documents(IndependentObjectSet ios) {
		this.ios = ios;
	}

	@Override
	public List<Event> getEvents() {
		List<Event> events = new ArrayList<Event>();

		Iterator<Document> iter = this.ios.iterator();
		while (iter.hasNext()) {
			Document doc = iter.next();
			events.addAll(getAuditedEvents(doc.get_AuditedEvents(), doc.get_MajorVersionNumber() == 1 ? true : false));
		}

		return events;
	}

	private List<Event> getAuditedEvents(EventSet eventSet, Boolean majorVersion) {

		if (eventSet.iterator() == null) {
			return null;
		}

		Iterator<com.filenet.api.events.Event> iterator = eventSet.iterator();
		List<Event> events = new ArrayList<Event>();
		while (iterator.hasNext()) {
			Event event = new Event();
			com.filenet.api.events.Event ceEvent = iterator.next();
			ClassDescription classDesc = ceEvent.get_ClassDescription();
			// skip update Events
			if (classDesc.get_SymbolicName().equalsIgnoreCase("UpdateEvent")
					|| (classDesc.get_SymbolicName().equalsIgnoreCase("CheckinEvent") && majorVersion)) {
				continue;
			}
			Properties props = ceEvent.getProperties();
			event.setTitle(props.getStringValue("CmAcmObjectName"));
			if (classDesc.get_SymbolicName().equals("CmAcmCaseFileEvent")) {
				event.setDescription("Document Filed in " + props.getStringValue("CmAcmFileFolderName"));
			} else {
				event.setDescription("Document " + classDesc.get_DisplayName());
			}
			event.setType(EventType.DOCUMENT.getType());
			event.setCreatedOn(ceEvent.get_DateCreated());
			event.setCreatedBy(ceEvent.get_Creator());
			events.add(event);
		}

		return events;
	}
}
