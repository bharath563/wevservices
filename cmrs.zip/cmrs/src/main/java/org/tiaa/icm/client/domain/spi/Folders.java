package org.tiaa.icm.client.domain.spi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.filenet.api.collection.EventSet;
import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.core.Folder;
import com.filenet.api.property.Properties;

import org.tiaa.icm.client.constant.EventType;
import org.tiaa.icm.client.domain.Event;

public class Folders implements IEvents {

	private IndependentObjectSet ios;

	public Folders(IndependentObjectSet ios) {
		this.ios = ios;
	}

	@Override
	public List<Event> getEvents() {
		List<Event> events = new ArrayList<Event>();

		Iterator<Folder> iter = this.ios.iterator();
		while (iter.hasNext()) {
			Folder folder = iter.next();
			events.addAll(getAuditedCommentEvents(folder.get_AuditedEvents()));
		}

		return events;
	}

	private List<Event> getAuditedCommentEvents(EventSet eventSet) {

		if (eventSet.iterator() == null) {
			return null;
		}

		Iterator<com.filenet.api.events.Event> iterator = eventSet.iterator();
		List<Event> events = new ArrayList<Event>();
		while (iterator.hasNext()) {
			Event event = new Event();
			com.filenet.api.events.Event ceEvent = iterator.next();
			Properties props = ceEvent.getProperties();
			event.setTitle(props.getStringValue("CmAcmObjectName"));
			event.setDescription("Folder created");
			event.setType(EventType.FOLDER.getType());
			event.setCreatedOn(ceEvent.get_DateCreated());
			event.setCreatedBy(ceEvent.get_Creator());
			events.add(event);
		}

		return events;
	}

}
