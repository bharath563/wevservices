package org.tiaa.icm.client.infocaddy.json;

public class Fields {
	private String label;
	private String field;

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

}
