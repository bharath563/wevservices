package org.tiaa.icm.client.infocaddy.mapper;

import java.sql.Timestamp;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.type.Alias;

import org.tiaa.icm.client.infocaddy.domain.RecentCases;

@Alias("recentCases")
public interface RecentCasesMapper {
	public List<RecentCases> fetchRecentCases(@Param("caseId") String caseId, @Param("date") Timestamp date);
}
