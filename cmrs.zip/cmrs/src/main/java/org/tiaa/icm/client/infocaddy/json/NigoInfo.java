package org.tiaa.icm.client.infocaddy.json;

import org.springframework.util.MultiValueMap;

public class NigoInfo {

	private String nigoedBy;
	private String nigoedOn;

	private MultiValueMap<String, String> reasons;

	public MultiValueMap<String, String> getReasons() {
		return reasons;
	}

	public void setReasons(MultiValueMap<String, String> reasons) {
		this.reasons = reasons;
	}

	public String getNigoedBy() {
		return nigoedBy;
	}

	public void setNigoedBy(String nigoedBy) {
		this.nigoedBy = nigoedBy;
	}

	public String getNigoedOn() {
		return nigoedOn;
	}

	public void setNigoedOn(String nigoedOn) {
		this.nigoedOn = nigoedOn;
	}

}
