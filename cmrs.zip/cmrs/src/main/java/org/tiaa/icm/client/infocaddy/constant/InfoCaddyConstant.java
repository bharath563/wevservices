package org.tiaa.icm.client.infocaddy.constant;

public interface InfoCaddyConstant {

	public static final String DISPLAY_DATE_FORMAT = "MM/d/yyyy hh:mm:ss aa";
	public static final String NIGO_DELIMITER = "||";
	public static final String TASK_NAME = "Task Name:";
	public static final String SYSTEM = "System";
	public static final String DISPLAYNAME = "displayName";
	public static final String PLAN_SPONSOR = "Plan Sponsor";
	public static final String GENERAL = "General";
	public static final String OMNI = "omni";
	public static final String QC = "qc";
	public static final String AGE_OF_CASE = "Age of Case";
	public static final String NIGO_REASONS = "NIGO Reason(s)";
	public static final String ADDITIONAL_QUESTIONS = "Additional Questions";
	public static final String NIGO_INFO = "NIGO Info";
	public static final String RELATED_CASES = "Related Cases";
	public static final String RECENT_CASES = "Recent Cases";
	public static final String NIGO_ED_BY = "NIGO'ed By";
	public static final String NIGO_ED_ON = "NIGO'ed On";
	public static final String INFOCADDY_DISPLAY_DATE_FORMAT = "MM/dd/yyyy";
	public static final String REPAYMENT_DETAILS = "Repayment Details";
	public static final String DISPLAY_TRADE_DATE_FORMAT = "MM/d/yyyy";
	public static final String CASEID = "CASEID";
	public static final String FILENAME = "FILENAME";
	public static final String CREATED = "CREATED";
	public static final String PROCESSED = "PROCESSED";
	public static final String STATUS = "STATUS";
	public static final String OMNI_DETAILS = "Omni Details";

}
