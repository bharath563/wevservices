package org.tiaa.icm.client.propertynamingstrategy;

import java.util.Map;

import org.codehaus.jackson.map.MapperConfig;
import org.codehaus.jackson.map.PropertyNamingStrategy;
import org.codehaus.jackson.map.introspect.AnnotatedMethod;

public class ReplaceNamingStrategy extends PropertyNamingStrategy {

	private Map<String, String> replaceMap;

	public ReplaceNamingStrategy(Map<String, String> replaceMap) {
		this.replaceMap = replaceMap;
	}

	@Override
	public String nameForGetterMethod(MapperConfig<?> config, AnnotatedMethod method, String defaultName) {
		if (replaceMap.containsKey(defaultName)) {
			return replaceMap.get(defaultName);
		}

		return super.nameForGetterMethod(config, method, defaultName);
	}
}