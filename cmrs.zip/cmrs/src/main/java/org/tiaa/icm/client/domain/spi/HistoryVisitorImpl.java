package org.tiaa.icm.client.domain.spi;

import java.util.List;

import org.tiaa.icm.client.domain.Event;

public class HistoryVisitorImpl implements IHistoryVisitor {

	@Override
	public List<Event> visit(Comments comments) {
		return comments.getEvents();
	}

	@Override
	public List<Event> visit(Tasks tasks) {
		return tasks.getEvents();
	}

}
