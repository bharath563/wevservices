package org.tiaa.icm.client.bo.security;

import java.util.Enumeration;
import java.util.Properties;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class Scrambler {// TODO rewrite Scrambler where toolType passed as
						// string, tool
						// and subject are passed as String
	Properties props;
	String toolType;
	String subjectStr;
	byte[] tool;

	/**
	 *
	 * @param _toolType
	 * @param _subject
	 *            is nullable
	 * @param _tool
	 */
	public Scrambler(String _toolType, String _subjectStr, String _tool) {
		toolType = _toolType;
		setSubject(_subjectStr);
		tool = stringAsBytes(_tool);
	}

	public static Scrambler parse(Properties props) {
		int toolTypeInt = 64892;
		int subjectInt = 76641;
		int toolInt = -888908048;
		Scrambler instance = null;
		try {
			String toolType = find(toolTypeInt, props);
			String subjectStr = find(subjectInt, props);
			String tool = find(toolInt, props);
			instance = new Scrambler(toolType, subjectStr, tool);
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
		return instance;
	}

	public void setSubject(String _subjectStr) {
		subjectStr = _subjectStr;
	}

	public String unScramble() {
		return unScramble(subjectStr);
	}

	/**
	 *
	 * @param _subjectStr
	 *            the subject-String to be unscrambled
	 * @return
	 */
	public String unScramble(String _subjectStr) {
		String result = null;
		if (_subjectStr == null) {
			throw new IllegalStateException("No _subjectStr specified");
		}
		byte[] subject = stringAsBytes(_subjectStr);
		try {
			SecretKeySpec key = new SecretKeySpec(tool, toolType);
			Cipher dc = Cipher.getInstance(toolType);
			dc.init(Cipher.DECRYPT_MODE, key);
			result = new String(dc.doFinal(subject));
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
		return result;

	}

	/**
	 * Used when unscrambling value of keys in propList or Map<String, String>
	 * Determines if the key is associate with an encyrpted value based on the
	 * key pattern> Key with encrypted value must start with "${" and ends with
	 * "}". eg. ${passsword}
	 *
	 * @param key
	 * @return
	 */
	public static boolean isKeyForEncryptedValue(String key) {
		key = key.trim();
		return key.startsWith("${") && key.endsWith("}");
	}

	public static String toNormalKey(String key) {
		return key.substring(0, key.length() - 1).substring(2);
	}

	/**
	 * Decrypts values associated with keys that start with "${" and ends with
	 * "}", and <b>normalizes</b> the key associated with decrypted value
	 *
	 * @param _subjectStr
	 *            the subject-String to be unscrambled
	 * @return
	 */
	public Properties unScramble(Properties _props) {

		String[] keys = new String[_props.size()];
		_props.keySet().toArray(keys);
		for (String key : keys) {
			String value = _props.getProperty(key);
			if (isKeyForEncryptedValue(key)) {
				String newKey = toNormalKey(key);
				_props.put(newKey, (value != null ? unScramble(value) : null));
				_props.remove(key);
			}
		}
		return _props;
	}

	public String scramble(String _value) {
		String result = null;
		if (_value == null) {
			throw new IllegalStateException("No _value specified");
		}
		try {
			SecretKeySpec key = new SecretKeySpec(tool, toolType);
			Cipher dc = Cipher.getInstance(toolType);
			dc.init(Cipher.ENCRYPT_MODE, key);
			result = bytesAsString(dc.doFinal(_value.getBytes()));
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
		return result;
	}

	public static String find(int criteria, Properties _props) {
		String value = null;
		Enumeration<?> keys = _props.keys();
		while (keys.hasMoreElements()) {
			String key = keys.nextElement().toString();
			if (key.hashCode() == criteria) {
				value = _props.get(key).toString();
				break;
			}
		}
		return value;
	}

	public static String bytesAsString(byte[] data) {
		StringBuilder sb = new StringBuilder();
		for (int ai = 0; ai < data.length; ai++) {
			if (ai > 0) {
				sb.append(',');
			}
			sb.append(data[ai]);
		}
		return sb.toString();
	}

	public static byte[] stringAsBytes(String str) {
		String[] strings = str.split(",");
		byte[] data = new byte[strings.length];
		for (int ai = 0; ai < data.length; ai++) {
			data[ai] = new Byte(strings[ai]).byteValue();
		}
		return data;
	}
}
