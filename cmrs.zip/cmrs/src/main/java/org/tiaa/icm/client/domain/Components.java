package org.tiaa.icm.client.domain;

public class Components {
	private String vcase = "SUCCESS";
	private String ce = "SUCCESS";
	private String pe = "SUCCESS";

	public String getVcase() {
		return vcase;
	}

	public void setVcase(String vcase) {
		this.vcase = vcase;
	}

	public String getCe() {
		return ce;
	}

	public void setCe(String ce) {
		this.ce = ce;
	}

	public String getPe() {
		return pe;
	}

	public void setPe(String pe) {
		this.pe = pe;
	}

}
