/**
 *
 */
package org.tiaa.icm.client.domain.spi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.filenet.api.collection.EventSet;
import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.core.Annotation;
import com.filenet.api.property.Properties;

import org.tiaa.icm.client.constant.EventType;
import org.tiaa.icm.client.domain.Event;

/**
 * @author ganapaa
 *
 */
public class Comments implements IEvents {

	private IndependentObjectSet ios;

	public Comments(IndependentObjectSet ios) {
		this.ios = ios;
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see org.tiaa.icm.client.domain.spi.Events#getEvents(com.filenet.api.
	 * collection.IndependentObjectSet)
	 */
	@Override
	public List<Event> getEvents() {
		List<Event> events = new ArrayList<Event>();

		Iterator<Annotation> iter = this.ios.iterator();
		while (iter.hasNext()) {
			Annotation annotation = iter.next();
			events.addAll(getAuditedCommentEvents(annotation.get_AuditedEvents()));
		}

		return events;
	}

	private List<Event> getAuditedCommentEvents(EventSet eventSet) {

		if (eventSet.iterator() == null) {
			return null;
		}

		Iterator<com.filenet.api.events.Event> iterator = eventSet.iterator();
		List<Event> events = new ArrayList<Event>();
		while (iterator.hasNext()) {
			Event event = new Event();
			com.filenet.api.events.Event ceEvent = iterator.next();
			Properties props = ceEvent.getProperties();
			if (props.isPropertyPresent("CmAcmCommentText")) {
				event.setTitle(props.getStringValue("CmAcmCommentText"));
				event.setDescription("Comment added to case"); // always default
																// to case..
				event.setType(EventType.COMMENT.getType());
				if (props.isPropertyPresent("CmAcmTaskName")) {
					// override for task\step
					event.setDescription("Comment added to " + props.getStringValue("CmAcmTaskName") + " for "
							+ props.getStringValue("CmAcmStepName"));
				}
			}
			event.setCreatedOn(ceEvent.get_DateCreated());
			event.setCreatedBy(ceEvent.get_Creator());
			// ceEvent.getProperties().get("ObjectState");
			events.add(event);
		}

		return events;
	}

}
