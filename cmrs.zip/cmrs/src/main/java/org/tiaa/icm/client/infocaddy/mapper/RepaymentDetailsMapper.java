package org.tiaa.icm.client.infocaddy.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.type.Alias;

import org.tiaa.icm.client.infocaddy.domain.RepaymentDetails;

@Alias("repaymentDetails")
public interface RepaymentDetailsMapper {

	public List<RepaymentDetails> fetchPlanRepaymentDetails(@Param("caseId") String caseId,
			@Param("omniStatus") String omniStatus, @Param("omniTransactionType") String omniTransactionType);

	// TBD: To be removed..
	public List<RepaymentDetails> fetchSubPlanRepaymentDetails(@Param("caseId") String caseId,
			@Param("plan") String plan, @Param("subPlan") String subPlan, @Param("omniStatus") String omniStatus,
			@Param("omniTransactionType") String omniTransactionType);
}
