package org.tiaa.icm.client.domain;

import java.util.Iterator;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class Step implements Comparable<Step> {

	private String caseId;
	private String taskId;
	private String wobId;
	private String queueName;
	private List<String> action;
	private boolean locked;
	private String lockedby;
	private String reassignRacfId;
	private List<StepElementDataField> fields;
	private List<StepElementHeaderField> headerFields;
	private String stepCreateTime;
	private Status status;
	private String wakeDateTime;

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getWobId() {
		return wobId;
	}

	public void setWobId(String wobId) {
		this.wobId = wobId;
	}

	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public List<String> getAction() {
		return action;
	}

	public void setAction(List<String> action) {
		this.action = action;
	}

	public List<StepElementDataField> getFields() {
		return fields;
	}

	public void setFields(List<StepElementDataField> fields) {
		this.fields = fields;
	}

	public boolean isLocked() {
		return locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public String getLockedby() {
		return lockedby;
	}

	public void setLockedby(String lockedby) {
		this.lockedby = lockedby;
	}

	public String getReassignRacfId() {
		return reassignRacfId;
	}

	public void setReassignRacfId(String reassignRacfId) {
		this.reassignRacfId = reassignRacfId;
	}

	public List<StepElementHeaderField> getHeaderFields() {
		return headerFields;
	}

	public void setHeaderFields(List<StepElementHeaderField> headerFields) {
		this.headerFields = headerFields;
	}

	@JsonIgnore
	public String getStepCreateTime() {
		return stepCreateTime;
	}

	public void setStepCreateTime(String stepCreateTime) {
		this.stepCreateTime = stepCreateTime;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	@JsonSerialize(include = Inclusion.NON_NULL)
	public String getWakeDateTime() {
		return wakeDateTime;
	}

	public void setWakeDateTime(String wakeDateTime) {
		this.wakeDateTime = wakeDateTime;
	}

	@Override
	public String toString() {
		StringBuffer sBufStep = new StringBuffer();
		sBufStep.append("{");

		appendStrProperty(sBufStep, "caseId", caseId);
		appendStrProperty(sBufStep, "taskId", taskId);
		appendStrProperty(sBufStep, "wobId", wobId);
		appendStrProperty(sBufStep, "action", action);
		appendStrProperty(sBufStep, "status", status.getStatus());
		appendStrProperty(sBufStep, "wakeDateTime", wakeDateTime);
		stepElementDataFields(sBufStep, "fields", fields);

		sBufStep.append("}");
		return sBufStep.toString();
	}

	private void appendStrProperty(StringBuffer sBufStep, String property, String id) {
		if (id != null) {
			if (sBufStep.indexOf("=") > -1) {
				sBufStep.append(",").append(property).append("=").append(id);
			} else {
				sBufStep.append(property).append("=").append(id);
			}
		}
	}

	private void appendStrProperty(StringBuffer sBufStep, String property, List<String> value) {
		if (value != null) {
			Iterator<String> iter = value.iterator();
			while (iter.hasNext()) {
				String action = iter.next();
				if (value.size() > 1) {
					sBufStep.append(",").append(property).append("=");
				} else {
					sBufStep.append(",").append(property).append("=").append(value);
				}

			}
		}
	}

	private void stepElementDataFields(StringBuffer sBufStep, String property, List<StepElementDataField> dataFields) {
		if (dataFields != null) {
			Iterator<StepElementDataField> iter = dataFields.iterator();
			while (iter.hasNext()) {
				StepElementDataField fields = iter.next();
				fields.toString(sBufStep);
			}
		}

	}

	@Override
	public int compareTo(Step o) {
		if (getStepCreateTime().compareTo(o.getStepCreateTime()) == -1) {
			return 1;
		}
		if (getStepCreateTime().compareTo(o.getStepCreateTime()) == 1) {
			return -1;
		} else {
			return 0;
		}
	}

}
