package org.tiaa.icm.client.infocaddy.json;

@SuppressWarnings("unused")
public class RepaymentDetailsObject {
	String date;
	String amount;
	String method;
	String status;
	String omniInfoUrl;

	public String getOmniInfoUrl() {
		return omniInfoUrl;
	}

	public void setOmniInfoUrl(String omniInfoUrl) {
		this.omniInfoUrl = omniInfoUrl;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDate() {
		return date;
	}

	public String getAmount() {
		return amount;
	}

	public String getMethod() {
		return method;
	}

	public String getStatus() {
		return status;
	}

}
