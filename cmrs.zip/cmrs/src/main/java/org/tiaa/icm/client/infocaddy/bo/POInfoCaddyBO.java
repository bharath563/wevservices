package org.tiaa.icm.client.infocaddy.bo;

import static org.tiaa.icm.client.infocaddy.utils.InfoCaddyUtil.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import org.tiaa.icm.client.infocaddy.constant.InfoCaddyConstant;
import org.tiaa.icm.client.infocaddy.domain.ANigo;
import org.tiaa.icm.client.infocaddy.domain.AQuestion;
import org.tiaa.icm.client.infocaddy.domain.AReason;
import org.tiaa.icm.client.infocaddy.domain.Reason;
import org.tiaa.icm.client.infocaddy.json.NigoInfo;
import org.tiaa.icm.client.infocaddy.json.Type;
import org.tiaa.icm.client.infocaddy.mapper.ANigoMapper;
import org.tiaa.icm.client.infocaddy.mapper.AQuestionMapper;
import org.tiaa.icm.client.infocaddy.mapper.AReasonMapper;
import org.tiaa.icm.client.infocaddy.utils.InfoCaddyUtil;
import org.tiaa.icm.client.rest.InfoCaddyService;
import org.tiaa.icm.client.utils.ICMClientUtil;

@Repository(value = "poInfoCaddyBO")
public class POInfoCaddyBO implements InfoCaddyBODelegate {

	private final Logger logger = Logger.getLogger(POInfoCaddyBO.class);

	@Autowired
	private AReasonMapper reasonsMapper;

	@Autowired
	private ANigoMapper nigoMapper;

	@Autowired
	private AQuestionMapper questionsMapper;

	@Autowired
	private InfoCaddyService infoCaddyService;

	private ObjectMapper objectMapper = new ObjectMapper();

	private List<NigoInfo> fetchNigoInfo(String caseId, String groupId) {

		logger.debug("Entering fetchNigoInfo(String caseId, String groupId)...");
		List<ANigo> aNigoList = new ArrayList<ANigo>();

		Map<String, List<Reason>> nigoMap = new HashMap<String, List<Reason>>();

		aNigoList = nigoMapper.fetchNigo(caseId);
		if (aNigoList.size() == 0) {
			return Collections.emptyList();
		}

		ANigo aNigo = aNigoList.get(0);
		String nigoReason = aNigo.getReasons();

		if ((nigoReason != null) && !nigoReason.isEmpty()) {

			List<Reason> arrList = new ArrayList<Reason>();

			String[] reasons = SplitUsingTokenizer(nigoReason, InfoCaddyConstant.NIGO_DELIMITER);

			for (int i = 0; i < reasons.length; i++) {
				arrList.add(new Reason(reasons[i]));
			}

			nigoMap.put("nigoReasons", arrList);

		} else {

			// Reasons
			List<AReason> reasonsList = reasonsMapper.fetchReasonsByGrouopId(groupId);

			for (int i = 0; i < reasonsList.size(); i++) {

				AReason aReason = reasonsList.get(i);

				String reasonTxt = aReason.getReasonTxt();
				String[] reasons = SplitUsingTokenizer(reasonTxt, InfoCaddyConstant.NIGO_DELIMITER);

				List<Reason> reasonList = null;

				if (reasons.length > 1) {
					reasonList = nigoMap.get(reasons[1]);
				} else {
					reasonList = nigoMap.get("noheader");
				}

				if (reasonList != null) {
					reasonList.add(new Reason(reasons[0]));
				} else {

					reasonList = new ArrayList<Reason>();
					reasonList.add(new Reason(reasons[0]));

				}
				if (reasons.length > 1) {

					nigoMap.put(reasons[1], reasonList);

				} else {

					nigoMap.put("noheader", reasonList);

				}

			}

			// Question Answer
			List<AQuestion> questionsObjList = questionsMapper.fetchQuestionsByGrouopId(groupId);

			List<Reason> questionList = new ArrayList<Reason>();

			int questionObjSize = questionsObjList.size();

			for (int i = 0; i < questionObjSize; i++) {

				AQuestion aQuestion = questionsObjList.get(i);
				String reasonTxt = aQuestion.getQuestion();
				reasonTxt = reasonTxt + " " + aQuestion.getValue();
				questionList.add(new Reason(reasonTxt));

			}
			if (questionObjSize > 0) {

				nigoMap.put(InfoCaddyConstant.ADDITIONAL_QUESTIONS, questionList);

			}

		}

		logger.debug("Exiting fetchNigoInfo(String caseId, String groupId)...");

		return processNigoInformation(nigoMap);
	}

	private List<NigoInfo> processNigoInformation(Map<String, List<Reason>> nigoMap) {

		logger.debug("Entering processNigoInformation(Map<String, List<Reason>> nigoMap)...");

		List<NigoInfo> nigoInfoList = new ArrayList<NigoInfo>();

		for (Map.Entry<String, List<Reason>> entry : nigoMap.entrySet()) {

			MultiValueMap<String, String> reasonMultiMap = new LinkedMultiValueMap<String, String>();
			NigoInfo nigoInfo = new NigoInfo();
			List<String> newReasonList = new ArrayList<String>();

			List<Reason> reasonList = entry.getValue();

			for (Reason reason : reasonList) {

				newReasonList.add(reason.getReason());
				reasonMultiMap.add(entry.getKey(), reason.getReason());
			}

			nigoInfo.setReasons(reasonMultiMap);
			nigoInfoList.add(nigoInfo);
		}

		logger.debug("Exiting processNigoInformation(Map<String, List<Reason>> nigoMap)...");

		return nigoInfoList;

	}

	@Override
	public List<Object> getInfoCaddyDetails(String caseId, String solution, String section) throws Exception {
		logger.debug("Entering getInfoCaddyDetails(String caseId, String solution, String section...");

		List<Object> infoCaddyDetailsList = infoCaddyService.getInfoCaddyDetails(solution, caseId, section);

		// Process response for General section only. For other sections use
		// response as it is.
		if (InfoCaddyConstant.GENERAL.equalsIgnoreCase(section)) {

			infoCaddyDetailsList = processGeneralInformation(infoCaddyDetailsList, caseId);

		}

		logger.debug("Exiting getInfoCaddyDetails(String caseId, String solution, String section...");

		return infoCaddyDetailsList;

	}

	private List<Object> processGeneralInformation(List<Object> infoCaddyDetailsList, String caseId) throws Exception {
		logger.debug("Entering processGeneralInformation(Type[] infoCaddyDetails, String caseId)...");

		String infoCaddyResponseJSONString = this.objectMapper.writeValueAsString(infoCaddyDetailsList);

		Type[] infoCaddyDetails = this.objectMapper.readValue(infoCaddyResponseJSONString, Type[].class);

		infoCaddyDetailsList.clear();

		for (Type type : infoCaddyDetails) {

			// Remove HTML elements for Age Of Case
			if (!ICMClientUtil.isEmpty(type.getName())
					&& type.getName().equalsIgnoreCase(InfoCaddyConstant.AGE_OF_CASE)) {

				String ageOfCase = !ICMClientUtil.isNull(type.getValue())
						? type.getValue().toString().replaceAll("\\<.*?>", "") : "";
				type.setValue(ageOfCase);

			}

			// Remove blank propertyGroup item
			if (type.getType().equalsIgnoreCase("propertyGroup") && ICMClientUtil.isEmpty(type.getName())
					&& (type.getContent().size() == 0)) {

				infoCaddyDetails = InfoCaddyUtil.removeRelatedCase(infoCaddyDetails, type);
			}

			// Remove Related Cases group item
			if (!ICMClientUtil.isEmpty(type.getType()) && type.getType().equalsIgnoreCase("group")
					&& type.getName().equalsIgnoreCase(InfoCaddyConstant.RELATED_CASES)) {
				infoCaddyDetails = InfoCaddyUtil.removeRelatedCase(infoCaddyDetails, type);
			}

			List<Type> contentList = type.getContent();
			List<Type> toRemove = new ArrayList<Type>();
			if (null != contentList) {

				for (Type contentType : contentList) {

					if (!ICMClientUtil.isEmpty(contentType.getType())
							&& "propertyGroup".equalsIgnoreCase(contentType.getType())) {

						if (ICMClientUtil.isEmpty(contentType.getName()) && (contentType.getContent().size() == 0)) {
							toRemove.add(contentType);
						}

						if (!ICMClientUtil.isEmpty(contentType.getName())
								&& !ICMClientUtil.isNull(contentType.getValue())) {

							if (contentType.getValue().toString().contains("href=")
									&& (InfoCaddyUtil.checkChatLinksLabel(contentType.getName()))) {

								String chatlink = contentType.getValue().toString();
								chatlink = InfoCaddyUtil.getRacfId(chatlink);
								logger.debug("Chatlink: " + chatlink + " propertyContent.getName(): "
										+ contentType.getName());
								contentType.setValue(chatlink);
							}
						}

						// Parse for PropertyGroup
						List<Type> propertyContentList = contentType.getContent();
						List<Type> removeList = new ArrayList<Type>();
						if (propertyContentList != null) {
							for (Type propertyContent : propertyContentList) {

								if (ICMClientUtil.isEmpty(propertyContent.getName())
										&& (propertyContent.getContent().size() == 0)) {
									removeList.add(propertyContent);
								}

								if (!ICMClientUtil.isEmpty(propertyContent.getName())
										&& !ICMClientUtil.isNull(propertyContent.getValue())) {

									// populate Originated By chat link
									if (propertyContent.getValue().toString().contains("href=")
											&& (InfoCaddyUtil.checkChatLinksLabel(propertyContent.getName()))) {

										String chatlink = propertyContent.getValue().toString();
										chatlink = InfoCaddyUtil.getRacfId(chatlink);
										logger.debug("Chatlink: " + chatlink + " for propertyContent.getName() "
												+ propertyContent.getName());
										propertyContent.setValue(chatlink);

									}

								}
							}

							if (removeList != null) {
								for (Type removeitem : removeList) {
									propertyContentList.remove(removeitem);
								}
							}
						}
					}

					// Remove HTML chatlinks from Nigo Ed By
					if (!ICMClientUtil.isEmpty(contentType.getName()) && !ICMClientUtil.isNull(contentType.getValue())
							&& contentType.getValue().toString().contains("href=")
							&& contentType.getName().equalsIgnoreCase(InfoCaddyConstant.NIGO_ED_BY)) {

						String nigoedby = contentType.getValue().toString();
						nigoedby = InfoCaddyUtil.getRacfId(nigoedby);

						logger.debug("Nigo ed By: " + nigoedby);
						contentType.setValue(nigoedby);
					}

					// Populate NIGO Reasons
					if (!ICMClientUtil.isEmpty(contentType.getName()) && !ICMClientUtil.isNull(contentType.getValue())
							&& contentType.getName().equalsIgnoreCase(InfoCaddyConstant.NIGO_REASONS)) {

						String nigoReasons = contentType.getValue().toString();
						if (!ICMClientUtil.isEmpty(nigoReasons) && nigoReasons.contains("data-detailuri=")) {

							String groupId = nigoReasons.substring(nigoReasons.indexOf("data-detailuri="),
									nigoReasons.indexOf("/nigoReason")).replace("data-detailuri='", "");

							contentType.setValue(fetchNigoInfo(caseId, groupId));
						}
					}

				}

				if (toRemove != null) {
					for (Type removeitem : toRemove) {
						contentList.remove(removeitem);
					}
				}
			}
		}

		// Make Nigo Info similar to TO and other solutions
		processNigoInfo(infoCaddyDetails);

		infoCaddyDetailsList.add(infoCaddyDetails);

		logger.debug("Exiting processGeneralInformation(Type[] infoCaddyDetails, String caseId)...");

		return infoCaddyDetailsList;
	}

	private void processNigoInfo(Type[] infoCaddyDetails) {

		logger.debug("Entering processNigoInfo(Type[] infoCaddyDetails)...");

		List<Type> nigoInfoList = new ArrayList<Type>();

		// Populate NIGO Info List
		for (Type type : infoCaddyDetails) {

			List<Type> contentList = type.getContent();

			if (null != contentList) {

				for (Type contentType : contentList) {
					if (!ICMClientUtil.isEmpty(contentType.getName())
							&& !ICMClientUtil.isNull(contentType.getValue())) {

						if (contentType.getName().equalsIgnoreCase(InfoCaddyConstant.NIGO_ED_BY)) {
							nigoInfoList.add(contentType);
						}
						if (contentType.getName().equalsIgnoreCase(InfoCaddyConstant.NIGO_ED_ON)) {
							nigoInfoList.add(contentType);
						}
						if (contentType.getName().equalsIgnoreCase(InfoCaddyConstant.NIGO_REASONS)) {
							nigoInfoList.add(contentType);
						}
					}
				}
			}
		}

		// List for getting unique NIGO Objects
		List<NigoInfo> listOfNigo = new ArrayList<NigoInfo>();

		for (int start = 0; start < nigoInfoList.size(); start = start + 3) {

			int end = start + 3;

			// Get sublist having 3 nigo properties
			List<Type> subList = nigoInfoList.subList(start, end);

			NigoInfo nigoInfo = new NigoInfo();

			for (Type subListType : subList) {
				if (subListType.getName().equalsIgnoreCase(InfoCaddyConstant.NIGO_ED_BY)) {
					nigoInfo.setNigoedBy(subListType.getValue().toString());
				}

				if (subListType.getName().equalsIgnoreCase(InfoCaddyConstant.NIGO_ED_ON)) {
					nigoInfo.setNigoedOn(subListType.getValue().toString());
				}

				if (subListType.getName().equalsIgnoreCase(InfoCaddyConstant.NIGO_REASONS)) {

					List<NigoInfo> nigoReasonList = (List<NigoInfo>) subListType.getValue();
					MultiValueMap<String, String> reasonMultiMap = new LinkedMultiValueMap<String, String>();

					for (NigoInfo nigo : nigoReasonList) {

						MultiValueMap<String, String> nigoReasonMap = nigo.getReasons();

						if (nigoReasonMap != null) {
							for (Map.Entry<String, List<String>> entry : nigoReasonMap.entrySet()) {
								reasonMultiMap.put(entry.getKey(), entry.getValue());
							}
						}
						nigoInfo.setReasons(reasonMultiMap);
					}

				}

			}
			// Populate Nigo object
			listOfNigo.add(nigoInfo);
		}

		// Use newly created NIGO Info in propertygroup.
		for (Type type : infoCaddyDetails) {

			List<Type> contentList = type.getContent();

			if (null != contentList) {

				for (Type contentType : contentList) {
					if (!ICMClientUtil.isEmpty(contentType.getName())
							&& !ICMClientUtil.isNull(contentType.getValue())) {

						if (contentType.getName().equalsIgnoreCase(InfoCaddyConstant.NIGO_ED_BY)) {
							contentType.setName(InfoCaddyConstant.NIGO_INFO);
							contentType.setValue(listOfNigo);
							break;
						}
					}
				}
			}

		}

		// Remove all other NIGO's items
		List<Type> toRemove = new ArrayList<Type>();

		for (Type type : infoCaddyDetails) {

			List<Type> contentList = type.getContent();

			if (null != contentList) {

				for (Type contentType : contentList) {
					if (!ICMClientUtil.isEmpty(contentType.getName())
							&& !ICMClientUtil.isNull(contentType.getValue())) {

						if (contentType.getName().equalsIgnoreCase(InfoCaddyConstant.NIGO_ED_BY)) {
							toRemove.add(contentType);
						}

						if (contentType.getName().equalsIgnoreCase(InfoCaddyConstant.NIGO_ED_ON)) {
							toRemove.add(contentType);
						}

						if (contentType.getName().equalsIgnoreCase(InfoCaddyConstant.NIGO_REASONS)) {
							toRemove.add(contentType);
						}
					}
				}
			}

			if (toRemove != null) {
				for (Type removeitem : toRemove) {
					contentList.remove(removeitem);
				}
			}
		}

		logger.debug("Exiting processNigoInfo(Type[] infoCaddyDetails)...");

	}

}
