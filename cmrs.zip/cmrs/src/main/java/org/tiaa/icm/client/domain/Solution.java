package org.tiaa.icm.client.domain;

public class Solution {

	private String soultionName;
	private String confirmation;
	private String caseType;

	public String getSoultionName() {
		return soultionName;
	}

	public void setSoultionName(String soultionName) {
		this.soultionName = soultionName;
	}

	public String getConfirmation() {
		return confirmation;
	}

	public void setConfirmation(String confirmation) {
		this.confirmation = confirmation;
	}

	public String getCaseType() {
		return caseType;
	}

	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}

}
