package org.tiaa.icm.client.bo.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;

import org.apache.log4j.Logger;

import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Case;

public class CaseComparator implements Comparator<Case> {
	private static Logger logger = Logger.getLogger(CaseComparator.class);

	private String sortField;

	public CaseComparator(String sortField) {
		this.sortField = sortField;
	}

	@Override
	public int compare(Case case1, Case case2) {
		int comp = 0;
		String prev = null;
		String current = null;
		try {

			if (sortField.equalsIgnoreCase("ID")) {
				prev = case1.getId();
				current = case2.getId();
			} else if (sortField.equalsIgnoreCase("CONFIRMATION")) {
				prev = case1.getConfirmation();
				current = case2.getConfirmation();
			} else if (sortField.equalsIgnoreCase("caseType")) {
				prev = case1.getConfirmation();
				current = case2.getConfirmation();
			} else if (sortField.equalsIgnoreCase("PIN")) {
				prev = case1.getPin();
				current = case2.getPin();
			} else if (sortField.equalsIgnoreCase("CLIENTID")) {
				prev = case1.getClientId();
				current = case2.getClientId();
			} else if (sortField.equalsIgnoreCase("caseStatus")) {
				prev = case1.getStatus();
				current = case2.getStatus();
			} else if (sortField.equalsIgnoreCase("CHANNEL")) {
				prev = case1.getChannel();
				current = case2.getChannel();
			}

			if ((prev != null) && (current != null)) {
				// logger.debug("prev:" + prev + ",current:" + current);
				comp = prev.compareTo(current);
			}
			if (sortField.equalsIgnoreCase("REQUESTRECEIVEDDATE")
					|| sortField.equalsIgnoreCase("Request Received Date")) {
				Date case1Date = null;
				Date case2Date = null;
				try {
					if ((case1.getRequestReceivedDate() != null) && (case2.getRequestReceivedDate() != null)) {
						SimpleDateFormat df = new SimpleDateFormat(CommonConstants.MMDDYYYYHHMMSS);
						case1Date = df.parse(case1.getRequestReceivedDate());
						case2Date = df.parse(case2.getRequestReceivedDate());

					}
				} catch (ParseException e) {
					DateFormat df = new SimpleDateFormat(CommonConstants.MMDDYYYY12HR);
					case1Date = df.parse(case1.getRequestReceivedDate());
					case2Date = df.parse(case2.getRequestReceivedDate());
				} finally {
					if ((case1Date != null) && (case2Date != null)) {

						comp = case1Date.compareTo(case2Date);
						// logger.debug("date1:" + case1Date + ",date2:" +
						// case2Date + ",comp:" + comp);
					}
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		// LOG.debug("Comparator case::" + comp);
		return comp;
	}

}