package org.tiaa.icm.client.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import org.tiaa.icm.client.ccpdocuments.delegate.CCPDocumentsDelegate;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.provider.AppPropertiesProvider;

@Component
public class CCPDocumentsConfig {

	private Logger logger = Logger.getLogger(CCPDocumentsConfig.class);
	private Map<String, CCPDocumentsDelegate> ccpDocumentsConfig = new HashMap<String, CCPDocumentsDelegate>();

	@Autowired
	@Qualifier("poCCPDocumentsProcessor")
	private CCPDocumentsDelegate poCCPDocumentsDelegate;

	@Autowired
	@Qualifier("piCCPDocumentsProcessor")
	private CCPDocumentsDelegate piCCPDocumentsDelegate;

	@Autowired
	@Qualifier("isCCPDocumentsProcessor")
	private CCPDocumentsDelegate isCCPDocumentsDelegate;

	public Map<String, CCPDocumentsDelegate> getCCPDocumentsConfiguredSolutions() {
		logger.info("Entering getCCPDocumentsConfiguredSolutions()...");

		String configuredSolutionsForCCPDocuments = AppPropertiesProvider.getProperty("CCP-DOCUMENTS-CONFIG");

		for (String solution : configuredSolutionsForCCPDocuments.split(",")) {

			logger.debug("Configured Solution for getting CCP Documents-> " + solution);

			if (CommonConstants.PAYOUT_OPERATIONS.equalsIgnoreCase(solution)) {
				ccpDocumentsConfig.put(solution, poCCPDocumentsDelegate);
			} else if (CommonConstants.PAYIN_OPERATIONS.equalsIgnoreCase(solution)) {
				ccpDocumentsConfig.put(solution, piCCPDocumentsDelegate);
			} else if (CommonConstants.IS_OPERATIONS.equalsIgnoreCase(solution)) {
				ccpDocumentsConfig.put(solution, isCCPDocumentsDelegate);
			}

			logger.debug("Exiting getCCPDocumentsConfiguredSolutions()...");

		}
		return ccpDocumentsConfig;

	}

}
