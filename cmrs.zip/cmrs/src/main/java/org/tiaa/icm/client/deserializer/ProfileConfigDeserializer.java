package org.tiaa.icm.client.deserializer;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;

import org.apache.log4j.Logger;

import org.tiaa.icm.client.domain.entitlement.Profile;
import org.tiaa.icm.client.domain.entitlement.ProfileConfig;

public class ProfileConfigDeserializer extends JsonDeserializer<ProfileConfig> {

	Logger logger = Logger.getLogger(ProfileConfigDeserializer.class);

	@Override
	public ProfileConfig deserialize(JsonParser parser, DeserializationContext context)
			throws IOException, JsonProcessingException {

		JsonNode node = parser.getCodec().readTree(parser);
		ProfileConfig profileConfig = null;
		profileConfig = new ProfileConfig();

		Iterator<String> fields = node.getFieldNames();
		while (fields.hasNext()) {
			String field = fields.next();
			if (field.equalsIgnoreCase("@type")) {
				profileConfig.setType(node.get(field).asText());
			}
			if (field.equalsIgnoreCase("list")) {
				List<Profile> profileList = new ArrayList<Profile>();
				node.get(field).getElements();
				Iterator<JsonNode> profileListNode = node.get(field).getElements();
				while (profileListNode.hasNext()) {
					JsonNode profileNode = profileListNode.next();
					Profile profile = new Profile();
					profile.setName(profileNode.get("name").asText());
					List<String> groups = new ArrayList<String>();
					if (profileNode.has("groups")) {
						Iterator<JsonNode> groupNode = profileNode.get("groups").getElements();
						while (groupNode.hasNext()) {
							groups.add(groupNode.next().getTextValue());
						}
						profile.setGroups(groups);
					}
					profileList.add(profile);
					logger.debug("Parsed the profile for-> " + profile.getName());
				}
				profileConfig.setProfiles(profileList);
			}
		}
		return profileConfig;
	}

}
