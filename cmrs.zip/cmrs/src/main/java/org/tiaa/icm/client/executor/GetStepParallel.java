package org.tiaa.icm.client.executor;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import javax.security.auth.Subject;

import org.apache.log4j.Logger;

import com.filenet.api.util.UserContext;

import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Status;
import org.tiaa.icm.client.domain.Step;
import org.tiaa.icm.client.domain.StepElementHeaderField;
import org.tiaa.icm.client.domain.entitlement.Properties;
import org.tiaa.icm.client.utils.ICMClientUtil;

import filenet.vw.api.VWException;
import filenet.vw.api.VWFetchType;
import filenet.vw.api.VWQueue;
import filenet.vw.api.VWQueueQuery;
import filenet.vw.api.VWSession;
import filenet.vw.api.VWWorkObject;

public class GetStepParallel implements Callable<List<Step>> {
	public final String queueName;
	public final String filter;
	public final VWSession vwSession;
	public final Map<String, Properties> columns;
	public final Subject currentSubject;
	public final String workitemType;

	private static Logger logger = Logger.getLogger(GetStepParallel.class);

	public GetStepParallel(String queueName, String filter, Map<String, Properties> columns, VWSession vwSession,
			Subject currentSubject, String workitemType) {
		this.queueName = queueName;
		this.filter = filter;
		this.columns = columns;
		this.vwSession = vwSession;
		this.currentSubject = currentSubject;
		this.workitemType = workitemType;
	}

	@Override
	public List<Step> call() throws VWException, ParseException {
		return getStepsFromQueue(queueName, filter, columns, vwSession, currentSubject);
	}

	private List<Step> getStepsFromQueue(String queueName, String filter, Map<String, Properties> columns,
			VWSession vwSession, Subject currentSubject) throws VWException, ParseException {
		int queryFlags = VWQueue.QUERY_READ_BOUND + VWQueue.QUERY_READ_LOCKED;
		// int queryFlags = VWQueue.QUERY_READ_BOUND + VWQueue.QUERY_READ_LOCKED
		// + VWQueue.QUERY_GET_NO_TRANSLATED_SYSTEM_FIELDS;
		int fetchType = VWFetchType.FETCH_TYPE_WORKOBJECT;

		VWQueueQuery vwQuery = null;
		VWQueue queue = null;
		// For each new thread, need to push subject
		UserContext userContext = UserContext.get();
		userContext.pushSubject(currentSubject);
		if (vwSession != null) {
			queue = vwSession.getQueue(queueName);
			vwQuery = queue.createQuery(null, null, null, queryFlags, filter, null, fetchType);

			logger.info("Fetch Count " + vwQuery.fetchCount() + " For Queue:" + queueName + " and Filter: " + filter);
		}
		List<Step> steps = new ArrayList<Step>();

		while ((vwQuery != null) && vwQuery.hasNext()) {
			VWWorkObject wo = (VWWorkObject) vwQuery.next();
			// VWStepElement stepElement = wo.fetchStepElement();
			Step step = new Step();
			step.setCaseId(wo.getFieldValue("F_CaseFolder").toString());
			step.setTaskId(wo.getFieldValue("F_CaseTask").toString());
			step.setWobId(wo.getWorkObjectNumber());

			step.setQueueName(queueName);
			Status status = new Status();
			if (wo.hasFieldName(CommonConstants.IS_SUSPENDED)
					&& (Boolean.TRUE == (Boolean) wo.getFieldValue(CommonConstants.IS_SUSPENDED))) {
				status.setStatus(CommonConstants.SUSPENDED);
				if (wo.hasFieldName("WakeDateTimeET")) {
					step.setWakeDateTime(ICMClientUtil.DF_MMDDYYYY12HR.format(wo.getFieldValue("WakeDateTimeET")));
				} else if (wo.hasFieldName("PO_WakeDateTime")) {
					step.setWakeDateTime(ICMClientUtil.DF_MMDDYYYY12HR.format(wo.getFieldValue("PO_WakeDateTime")));
				}
			} else {
				status.setStatus(CommonConstants.OPEN);
			}

			// status.setStatus(CommonConstants.OPEN);
			step.setStatus(status);

			List<StepElementHeaderField> headerFields = new ArrayList<StepElementHeaderField>();

			/*
			 * Setting Step Create Time to Sort StepList based upon Step Create
			 * Time
			 */

			String createDate = ICMClientUtil.DF_MMDDYYYY12HR.format(wo.getFieldValue("F_CreateTime"));

			// Date stepCreateTime = sdf.parse(createDate);
			step.setStepCreateTime(createDate);

			List<String> fields = Arrays.asList(wo.getFieldNames());
			// Setting display name as field name instead of symbolic name
			String assignedTo = null;
			for (Map.Entry<String, Properties> entry : columns.entrySet()) {
				String symbolicName = entry.getKey();
				Properties headerDetails = entry.getValue();
				String displayName = headerDetails.getDisplayName();
				StepElementHeaderField field = new StepElementHeaderField();
				field.setName(displayName);
				try {
					if (fields.contains(symbolicName)) {
						if (symbolicName.equals("F_BoundUser")) {
							assignedTo = vwSession
									.convertIdToUserName(Integer.parseInt(wo.getFieldValue(symbolicName).toString()));
							field.setValue(assignedTo);
						} else if (wo.getFieldValue(symbolicName) != null) {
							if (displayName.contains("Trade Date")) {
								field.setValue(ICMClientUtil.TRADE_DF_MMDDYYYY.format(wo.getFieldValue(symbolicName)));
							} else if (displayName.contains("Date")) {
								field.setValue(ICMClientUtil.DF_MMDDYYYY12HR.format(wo.getFieldValue(symbolicName)));
							} else {
								field.setValue(wo.getFieldValue(symbolicName).toString());
							}
						}
					} else {
						field.setValue("");
					}
				} catch (Exception e) {
					logger.error("Exception while getting value for " + symbolicName + ":" + e.getMessage());
					field.setValue("");
				}

				headerFields.add(field);
			}

			step.setHeaderFields(headerFields);

			boolean locked = wo.fetchLockedStatus() > 0 ? true : false;
			if (locked) {
				String lockedBy = wo.getLockedUser();
				step.setLocked(true);
				logger.debug("assignedTo:" + assignedTo + ",lockedBy:" + lockedBy);
				step.setLockedby(lockedBy);
			} else {
				step.setLocked(false);
			}

			// String[] stepResponses = wo.getStepResponses();
			// if (stepResponses != null) {
			// step.setAction(Arrays.asList(stepResponses));
			// }

			steps.add(step);
		}
		Collections.sort(steps);

		userContext.popSubject();
		return steps;
	}

}
