package org.tiaa.icm.client.infocaddy.bo;

import java.util.List;

public interface InfoCaddyBODelegate {
	public List<Object> getInfoCaddyDetails(String caseId, String solution, String section) throws Exception;
}
