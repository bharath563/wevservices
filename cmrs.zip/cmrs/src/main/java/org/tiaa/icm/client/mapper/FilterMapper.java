package org.tiaa.icm.client.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface FilterMapper {

	@Select("select LOCATION_ID locationId from tcfilenet.temp_registered_rep where RACFID= #{racfId}")
	public List<String> getFilterInformation(@Param("racfId") String racfId);

}
