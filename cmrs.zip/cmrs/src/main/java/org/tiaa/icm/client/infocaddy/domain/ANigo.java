package org.tiaa.icm.client.infocaddy.domain;

import static org.tiaa.icm.client.infocaddy.utils.InfoCaddyUtil.*;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import org.apache.ibatis.type.Alias;

import org.tiaa.icm.client.infocaddy.constant.InfoCaddyConstant;

@Alias("aNigo")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class ANigo {

	public ANigo() {

	}

	String nigoSqn;
	String stepSqn;
	String id;
	String nigoedBy;
	Timestamp nigoedTimeStamp;
	String nigoedTS;
	String reasons;
	String taskId;
	String stepTypeName;
	Timestamp updatedTS;

	private String nigoReasons;
	private List<String> nigoReasonList;
	private Map<String, List<Reason>> reasonsMap;

	public String getStepSqn() {
		return stepSqn;
	}

	public void setStepSqn(String stepSqn) {
		this.stepSqn = stepSqn;
	}

	public String getNigoSqn() {
		return nigoSqn;
	}

	public void setNigoSqn(String nigoSqn) {
		this.nigoSqn = nigoSqn;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNigoedBy() {
		return nigoedBy;
	}

	public void setNigoedBy(String nigoedBy) {
		this.nigoedBy = nigoedBy;
	}

	public String getReasons() {
		return reasons;
	}

	public void setReasons(String reasons) {
		this.reasons = reasons;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getStepTypeName() {
		return stepTypeName;
	}

	public void setStepTypeName(String stepTypeName) {
		this.stepTypeName = stepTypeName;
	}

	public Timestamp getNigoedTimeStamp() {
		return nigoedTimeStamp;
	}

	public void setNigoedTimeStamp(Timestamp nigoedTimeStamp) {
		this.nigoedTimeStamp = nigoedTimeStamp;
	}

	public String getNigoedTS() {
		return nigoedTS;
	}

	public void setNigoedTS(String nigoedTS) {
		this.nigoedTS = nigoedTS;
	}

	public Timestamp getUpdatedTS() {
		return updatedTS;
	}

	public void setUpdatedTS(Timestamp updatedTS) {
		this.updatedTS = updatedTS;
	}

	public String getNigoReasons() {
		return nigoReasons;
	}

	public void setNigoReasons(String reasonText) {
		this.nigoReasons = reasonText;
	}

	public List<String> getNigoReasonList() {
		if (nigoReasonList == null) {
			nigoReasonList = new ArrayList<String>();
		}
		return nigoReasonList;
	}

	public void setNigoReasonList(List<String> nigoReasonList) {
		this.nigoReasonList = nigoReasonList;
	}

	public void addNIGOReason(String nigoReasons) {
		getNigoReasonList().add(nigoReasons);
	}

	public List<Reason> getReasonsList() {
		if ((reasons == null) || reasons.isEmpty()) {
			return Collections.emptyList();
		}
		List<Reason> reasonsList = new ArrayList<Reason>();
		for (String reason : SplitUsingTokenizer(reasons, InfoCaddyConstant.NIGO_DELIMITER)) {
			reasonsList.add(new Reason(reason));
		}
		return reasonsList;
	}

	public Map<String, List<Reason>> getReasonsMap() {
		if (reasonsMap == null) {
			reasonsMap = new LinkedHashMap<String, List<Reason>>();
		}
		return reasonsMap;
	}

}
