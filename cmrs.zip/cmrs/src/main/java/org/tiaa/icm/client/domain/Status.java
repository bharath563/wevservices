package org.tiaa.icm.client.domain;

import java.util.Date;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import org.tiaa.icm.client.serializer.JsonDateSerializer;

public class Status {

	private String status;

	private Date statusOn;

	private String statusBy;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@JsonSerialize(using = JsonDateSerializer.class)
	public Date getStatusOn() {
		return statusOn;
	}

	public void setStatusOn(Date statusOn) {
		this.statusOn = statusOn;
	}

	public String getStatusBy() {
		return statusBy;
	}

	public void setStatusBy(String statusBy) {
		this.statusBy = statusBy;
	}

}
