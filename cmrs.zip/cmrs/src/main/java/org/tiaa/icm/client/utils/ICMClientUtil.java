package org.tiaa.icm.client.utils;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.ResponseList;
import org.tiaa.icm.client.provider.AppPropertiesProvider;

public class ICMClientUtil {
	private final static ObjectMapper JSON = new ObjectMapper();

	public static final DateFormat DF_MMDDYYYY12HR = new SimpleDateFormat(CommonConstants.MMDDYYYY12HR);
	public static final DateFormat TRADE_DF_MMDDYYYY = new SimpleDateFormat(CommonConstants.MMDDYYYY);

	public static boolean isEmpty(String str) {
		return (str == null) || str.equals("") || str.equals("null");
	}

	public static boolean equals(String str1, String str2) {
		if ((str1 == null) || (str2 == null)) {
			return false;
		} else {
			return str1.equals(str2);
		}
	}

	public static int convertStrToInt(String str) {
		if (isEmpty(str)) {
			return 0;
		} else {
			return Integer.valueOf(str);
		}
	}

	public static boolean isNull(Object object) {
		return object == null;
	}

	public static String stringAfterGivenChar(String string, String character) {
		if (!isEmpty(string)) {
			int pos = string.lastIndexOf(character);
			if (pos > -1) {
				return string.substring(pos + 1);
			}
		}
		return null;
	}

	public static Map<String, String> pojoToMap(List<ICMClientMap> icmClientMapList) {
		Map<String, String> resultMap = null;
		if (!icmClientMapList.isEmpty()) {
			resultMap = new LinkedHashMap<String, String>();
			for (ICMClientMap icmClientMap : icmClientMapList) {
				resultMap.put(icmClientMap.getKey(), icmClientMap.getValue());
			}
		}
		return resultMap;
	}

	public static String getCurrentDateWithTime() {
		DateFormat dateFormat = new SimpleDateFormat(CommonConstants.YYYYMMDD24HR);
		return dateFormat.format(new Date());
	}

	public static String stringBeforeGivenChar(String string, char ch) {
		if (string != null) {
			return string.substring(0, string.lastIndexOf(ch));
		}
		return null;
	}

	public static Map<String, Integer> getStartEnd(String startStr) {
		Map<String, Integer> resultMap = new HashMap<String, Integer>();
		int noOfRecPerPage = AppPropertiesProvider.getIntProperty("noOfRecPerPage");
		int start = ICMClientUtil.convertStrToInt(startStr);
		start = (start > 0) ? start : 1;
		int end = (start > 0) ? (start + (noOfRecPerPage - 1)) : noOfRecPerPage;
		resultMap.put("START", start);
		resultMap.put("END", end);
		return resultMap;
	}

	public static String ObjectAsJSON(Object object) {
		String jsonString = "";
		try {
			jsonString = JSON.writeValueAsString(object);
		} catch (JsonGenerationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jsonString;
	}

	public static String convertDateFormat(String oldDateString, String currentFormat, String expectedFormat)
			throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat(currentFormat);
		Date d = null;
		d = sdf.parse(oldDateString);

		sdf.applyPattern(expectedFormat);
		return sdf.format(d);
	}

	public static String convertDateFormat(Date oldDate, String currentFormat, String expectedFormat) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat(currentFormat);

		sdf.applyPattern(expectedFormat);
		return sdf.format(oldDate);
	}

	public static String getEndOfDay(String toDate, String format) throws Exception {
		DateFormat dateFormat = new SimpleDateFormat(format);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateFormat.parse(toDate));
		cal.add(Calendar.DATE, 1);
		return dateFormat.format(cal.getTime());
	}

	public static ResponseList callResponseSubList(List responseList, String startStr) {
		return callResponseSubList(responseList, startStr, 0);
	}

	public static ResponseList callResponseSubList(List responseList, String startStr, int size) {
		int noOfRecPerPage = AppPropertiesProvider.getIntProperty("noOfRecPerPage");
		int maxSize = 0;
		int start = ICMClientUtil.convertStrToInt(startStr);
		start = (start > 0) ? start : 1;
		int end = (start > 0) ? (start + (noOfRecPerPage - 1)) : noOfRecPerPage;

		ResponseList response = new ResponseList();
		response.setStart(start);
		List pagedList = new ArrayList();

		if (responseList.size() >= end) {
			pagedList = responseList.subList(start - 1, end);
		} else if (responseList.size() >= start) {
			pagedList = responseList.subList(start - 1, responseList.size());
		}
		response.setResults(pagedList);
		if ((pagedList != null) && (pagedList.size() > 0)) {
			maxSize = pagedList.size();
			if (size != 0) {
				response.setTotalRecords(size);
			} else {
				response.setTotalRecords(responseList.size());
			}
		}
		if (maxSize > 0) {
			response.setEnd((start + maxSize) - 1);
		}

		return response;
	}

	public static ResponseList createResponseList(List<?> list) {
		ResponseList responseList = new ResponseList();
		int start = 0;
		int size = 0;
		if (!((list == null) || list.isEmpty())) {
			start = 1;
			size = list.size();
		}
		responseList.setStart(start);
		responseList.setEnd(size);
		responseList.setTotalRecords(size);
		responseList.setResults(list);
		return responseList;
	}

}
