/**
 *
 */
package org.tiaa.icm.client.ccpdocuments.delegate.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.filenet.api.property.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import org.tiaa.icm.client.ccpdocuments.delegate.CCPDocumentsDelegate;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Document;
import org.tiaa.icm.client.domain.FormatType;
import org.tiaa.icm.client.esb.federated_document_rs.types.Metadata;
import org.tiaa.icm.client.rest.FederatedSearch;
import org.tiaa.icm.client.utils.ICMClientUtil;

/**
 * @author watwe
 *
 */
@Repository(value = "isCCPDocumentsProcessor")
public class ISCCPDocumentsProcessor implements CCPDocumentsDelegate {

	private static Logger logger = Logger.getLogger(ISCCPDocumentsProcessor.class);

	@Autowired
	FederatedSearch federatedSearch;

	@Override
	public List<Document> getCCPDocuments(String caseId, String solutionName, Properties props) {

		logger.debug("Entering getCCPDocuments(String caseId, String solutionName, Properties props)....");
		List<Document> docList = new ArrayList<Document>();

		List<org.tiaa.icm.client.esb.federated_document_rs.types.Document> ccpDocumentsList = federatedSearch
				.getCCPDocuments(createQueryParamMap(caseId));

		docList = processCCPDocumentsResponse(ccpDocumentsList, docList);

		logger.debug("Exiting getCCPDocuments(String caseId, String solutionName, Properties props)....");
		return docList;

	}

	private List<Document> processCCPDocumentsResponse(
			List<org.tiaa.icm.client.esb.federated_document_rs.types.Document> ccpDocumentsList,
			List<Document> docList) {

		logger.debug(
				"Entering processCCPDocumentsResponse(List<org.tiaa.icm.client.esb.federated_document_rs.types.Document> ccpDocumentsList, List<Document> docList)....");

		for (org.tiaa.icm.client.esb.federated_document_rs.types.Document ccpDocument : ccpDocumentsList) {

			Map<String, String> ccpDocumentsMap = new HashMap<String, String>();

			String relativeUrl = ccpDocument.getDocumentLocator().getValue();

			List<Metadata> metadataList = ccpDocument.getMetadatas();

			for (Metadata metadata : metadataList) {
				ccpDocumentsMap.put(metadata.getName(), metadata.getValue());
			}

			docList.add(populateCCPDocumentMetadata(ccpDocumentsMap, relativeUrl));

		}
		logger.debug(
				"Exiting processCCPDocumentsResponse(List<org.tiaa.icm.client.esb.federated_document_rs.types.Document> ccpDocumentsList, List<Document> docList), String planNumber....");
		return docList;
	}

	private Document populateCCPDocumentMetadata(Map<String, String> ccpDocumentsMap, String relativeUrl) {
		logger.debug(
				"Entering populateCCPDocumentMetadata(Map<String, String> ccpDocumentsMap, String relativeUrl)....");

		Document document = new Document();
		document.setId(ccpDocumentsMap.get(CommonConstants.DOCUMENT_REQUEST_ID));

		if (!ICMClientUtil.isEmpty(ccpDocumentsMap.get(CommonConstants.DOCUMENT_REQUEST_ID))) {
			document.setIdtype(CommonConstants.DRI);
			document.setMimeType(CommonConstants.APPLICATION_PDF);
		} else {
			document.setMimeType(CommonConstants.TEXT_HTML);
			document.setIdtype(CommonConstants.TCICONTENTLOCATIONID);
		}

		document.setBusinessUnit(CommonConstants.ALL);
		document.setDocCode(CommonConstants.IS_DOCS);
		document.setVersion("1");

		// Folder name - for Remittance CM Internal communications
		document.setFolder(CommonConstants.OUTBOUND);

		document.setFormatType(FormatType.Document.toString());
		document.setDocUrl(federatedSearch.getBaseUrl() + relativeUrl);
		document.setDocumentName(ccpDocumentsMap.get(CommonConstants.DOCUMENT_DESCRIPTION));

		document.setCreatedBy(CommonConstants.SYSTEM);

		if (!ICMClientUtil.isEmpty(ccpDocumentsMap.get(CommonConstants.ARCHIVED_DATE))) {

			Date archivedDate;
			DateFormat dateFormat = new SimpleDateFormat(CommonConstants.MMDDYYYY12HR);
			DateFormat archivedDateformat = new SimpleDateFormat(CommonConstants.MMMDDYYYYHHMMSS);

			try {
				archivedDate = archivedDateformat.parse(ccpDocumentsMap.get(CommonConstants.ARCHIVED_DATE));
				document.setCreatedDate(dateFormat.format(archivedDate));

			} catch (ParseException e) {
				logger.error("Error occured in converting archived date ", e);
			}

		}

		logger.debug(
				"Exiting populateCCPDocumentMetadata(Map<String, String> ccpDocumentsMap, String relativeUrl)....");
		return document;
	}

	private MultiValueMap<String, String> createQueryParamMap(String caseId) {

		logger.debug("Entering createQueryParamMap(String caseType)....");
		MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();

		queryParams.add(CommonConstants.DOC_CODE, CommonConstants.IS_DOCS);
		queryParams.add(CommonConstants.VESRION, "1");
		queryParams.add(CommonConstants.BUSINESS_UNIT_CODE, CommonConstants.PENSION);
		queryParams.add(CommonConstants.TRANSACTION_ID, CommonConstants.CSID + caseId);
		queryParams.add(CommonConstants.DELIVERY_METHOD, CommonConstants.ED);
		queryParams.add(CommonConstants.DELIVERY_METHOD, CommonConstants.EM);

		logger.debug("Exiting createQueryParamMap(String caseType)....");
		return queryParams;

	}

}
