package org.tiaa.icm.client.domain;

import org.tiaa.icm.client.utils.ICMClientUtil;

public class Request {

	private Integer requestSqn;
	private String msgguid;
	private String dpTransactionId;
	private String correlationId;
	private String sessionId;
	private String deviceId;
	private String clientAddress;
	private String userId;
	private String requestReceivedTime;
	private String contentType;
	private String uri;
	private String httpMethod;
	private String status;
	private String requestPayload;
	private String responsePayload;
	private String responseSentTime;

	public String getMsgguid() {
		return msgguid;
	}

	public void setMsgguid(String msgguid) {
		this.msgguid = msgguid;
	}

	public String getDpTransactionId() {
		return dpTransactionId;
	}

	public void setDpTransactionId(String dpTransactionId) {
		this.dpTransactionId = dpTransactionId;
	}

	public String getCorrelationId() {
		return correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getClientAddress() {
		return clientAddress;
	}

	public void setClientAddress(String clientAddress) {
		this.clientAddress = clientAddress;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getRequestReceivedTime() {
		return requestReceivedTime;
	}

	public void setRequestReceivedTime(String requestReceivedTime) {
		this.requestReceivedTime = requestReceivedTime;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getHttpMethod() {
		return httpMethod;
	}

	public void setHttpMethod(String httpMethod) {
		this.httpMethod = httpMethod;
	}

	public String getRequestPayload() {
		return requestPayload;
	}

	public void setRequestPayload(String requestPayload) {
		this.requestPayload = requestPayload;
	}

	public String getResponsePayload() {
		return responsePayload;
	}

	public void setResponsePayload(String responsePayload) {
		this.responsePayload = responsePayload;
	}

	public String getResponseSentTime() {
		return responseSentTime;
	}

	public void setResponseSentTime(String responseSentTime) {
		this.responseSentTime = responseSentTime;
	}

	public Integer getRequestSqn() {
		return requestSqn;
	}

	public int setRequestSqn(Integer requestSqn) {
		return this.requestSqn = requestSqn;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		String jsonString = "";
		jsonString = ICMClientUtil.ObjectAsJSON(this);
		return jsonString;
	}

}
