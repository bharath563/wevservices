package org.tiaa.icm.client.bo.security;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.TextOutputCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.log4j.Logger;

public class UserCallbackHandler implements CallbackHandler {

	private String username;

	private String password;

	static Logger LOG = Logger.getLogger(UserCallbackHandler.class);

	@Override
	public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {

		LOG.debug("UserCallbackHandler -> handle");

		for (int i = 0; i < callbacks.length; i++) {
			if (callbacks[i] instanceof TextOutputCallback) {
				continue;
			} else if (callbacks[i] instanceof NameCallback) {
				NameCallback nc = (NameCallback) callbacks[i];
				nc.setName(this.getUsername());
			} else if (callbacks[i] instanceof PasswordCallback) {
				PasswordCallback pwd = (PasswordCallback) callbacks[i];
				pwd.setPassword(this.getPassword().toCharArray());
			}
		}

	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
