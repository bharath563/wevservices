package org.tiaa.icm.client.constant;

public interface CommonConstants {
	public static final String HEADER_QRY = "SELECT * FROM (SELECT r.*, ROWNUM RNUM, COUNT(*) OVER () TOTALRECORDS FROM (";
	public static final String TRAIL_QRY = ") R) WHERE RNUM between {START} and {END} ";
	public static final String MMDDYYYY12HR = "MM/dd/yyyy hh:mm:ss.SSS a";
	public static final String MMDDYYYYHHMMSS = "MM/dd/yyyy hh:mm:ss a";
	public static final String YYYYMMDD24HR = "yyyy-MM-dd HH:mm:ss.SSS";
	public static final String YYYY_MM_DD = "yyyy-MM-dd";
	public static final String YYYYMMDDTHHMMSSZ = "yyyyMMdd'T'HHmmss'Z'";
	public static final String MMDDYYYY = "MM/dd/yyyy";

	public static final String CM_ACM_ACTION = "CmAcmAction";
	public static final String CM_ACM_COMMENT_TEXT = "CmAcmCommentText";
	public static final String CM_ACM_COMMENTED_TASK = "CmAcmCommentedTask";
	public static final String CM_ACM_COMMENTED_VERSION_SERIES = "CmAcmCommentedVersionSeries";
	public static final String DOCUMENT_TITLE = "DocumentTitle";
	public static final String CM_ACM_TASK_NAME = "CmAcmTaskName";
	public static final String CM_ACM_STEP_NAME = "CmAcmStepName";
	public static final String CM_ACM_WORKFLOW_NUMBER = "CmAcmWorkflowNumber";

	public static final String[] FDRS_URL_PARAMS = { "driBaseURI", "idtype", "id", "docName", "bizUnit", "docCode",
			"version", "mimeType", "formatType" };
	public static final String SUCCESS = "SUCCESS";
	public static final String ERROR = "ERROR";
	public static final String FAILURE = "FAILURE";
	public static final String NULL_POINTER_CUSTOM_MSG = "NullPointerException - please check all the data sent";

	public static final String FDRS_URL = "%{driBaseURI}/EsbRestProxy/rest/federatedSearch/getContent?bizUnit=%{bizUnit}&idtype=%{idType}&id=%{id}&docCode=%{docCode}&version=1&name=%{docName}&mimeType=%{mimeType}";

	public static final String MY_WORK_ITEM = "MyWorkItems";
	public static final String UNASSIGNED_WORK_ITEM = "Unassigned";
	public static final String ALL_ASSIGNED_WORK_ITEM = "AllAssigned";
	public static final String PENDED_WORK_ITEM = "Pended";

	public static final String PAYOUT_PAYIN_TRANSFERS = "Payout_Payin_Transfers";
	public static final String NON_PLAN = "NON_PLAN";

	public static final String PAYIN_OPERATIONS = "Payin Operations";
	public static final String PAYOUT_OPERATIONS = "Payout Operations";
	public static final String PARTICIPANT_MAINTENANCE_OPERATIONS = "Participant Maintenance Operations";
	public static final String ICS = "Institutional Client Solutions";
	public static final String IS_OPERATIONS = "Institutional Servicing";
	public static final String IPS = "Imaging Portfolio Services";
	public static final String CS = "Client Servicing";
	public static final String SS = "Survivor Solutions";

	public static final String NIGOED = "nigo''ed";

	public static final String ASSET_TRANSFER_OPERATIONS = "Asset Transfer Operations";
	public static final String BROKERAGE_OPERATIONS = "Brokerage Operations";

	public static final String STARTED = "Started";
	public static final String IN_PROCESS = "In Process";
	public static final String COMPLETED = "Completed";

	public static final String IS_CASE_CREATED_DATE = "IS-CASE-CREATED-DATE";

	public static final String HUMAN = "Human";
	public static final String SYSTEM = "System";

	public static final String CE_ADMIN_USER = "ser_p8admin";

	public static final String NICE = "niceTelephony";
	public static final String RACF_ID = "racfId";
	public static final String RECORDING_DATE_TIME = "recordingDateTime";
	public static final String FROM_EMAIL_ADDRESS = "FROM_EMAIL_ADDRESS";
	public static final String SUBJECT_LINE = "SUBJECT_LINE";
	public static final String TO_EMAIL_ADDRESS = "TO_EMAIL_ADDRESS";
	public static final String SEND_DATE = "SEND_DATE";
	public static final String YYYMMDDHHMMSS = "yyyyMMddHHmmss";
	public static final String MMMDDYYYYHHMMSS = "MMM dd, yyyy hh:mm:ss a";
	public static final String DRI = "DRI";
	public static final String CCP_EMAIL_MIMETYPE = "application/x-services-email";
	public static final String ALL = "ALL";;
	public static final String OUTBOUND_DOCS = "OUTBOUND_DOCS";
	public static final String DOCUMENT_DESCRIPTION = "Document_Description";
	public static final String APPLICATION_X_SERVICES = "application/x-services-email";
	public static final String APPLICATION_PDF = "application/pdf";
	public static final String TEXT_HTML = "text/html";
	public static final String ORDERNUMS = "OrderNumbers";
	public static final String PAYMENTNUMS = "PaymentNumbers";
	public static final String DELIMITER_COMMA = ",";
	public static final String ORCH = "ORCH-";
	public static final String BUSINESS_UNIT_CODE = "business-unit-code";
	public static final String DOC_CODE = "doc-code";
	public static final String VESRION = "version";
	public static final String TRANSACTION_ID = "Transaction_ID";
	public static final String ED = "ED";
	public static final String EM = "EM";
	public static final String PR = "PR";
	public static final String DELIVERY_METHOD = "Delivery_Method";
	public static final String IDTYPE = "idtype";
	public static final String ID_TYPE = "id-type";
	public static final String VTRANID = "VTranID";
	public static final String VTRAN_ID = "VTran_ID";
	public static final String APPLICATION = "application";
	public static final String MEDIA_TYPES = "vnd.tiaa.federated-document-rs-v1.0+xml";
	public static final String PLAN_NUMBER = "PlanNumbers";
	public static final String OUTBOUND = "Outbound";
	public static final String INBOUND_DOCS = "INBOUND_DOCS";
	public static final String INBOUND = "Inbound";
	public static final String DOCUMENT_REQUEST_ID = "Document_Request_ID";
	public static final String CASE_TYPE = "CaseType";
	public static final String TC_CASETYPE = "TC_CaseType";
	public static final String LOAN_REPAYMENT = "Loan Repayment";
	public static final String ADDITIONAL_LOAN_REPAYMENT = "Additional Loan Repayment";
	public static String LOAN_ID = "LoanID";
	public static String LOAN = "LOAN-";
	public static final String TCICONTENTLOCATIONID = "TCIContentLocationID";
	public static final String IS_DOCS = "IS_DOCS";
	public static final String PENSION = "PENSION";
	public static final String CSID = "CSID-";
	public static final String SUPPORTING_DOCS = "Supporting Documents";
	public static final String ARCHIVED_DATE = "Archived_Date";
	public static String RECORDING_TEMPLATE = "{racf-id}/recordings/{recording-date-time}";
	public static final String PLAN_ID = "Plan_ID";
	public static final String LOAN_MAINTENANCE = "Loan Maintenance";
	public static final String CONTENT_AREA = "CONTENT_AREA";
	public static final String UNKOWN = "Unknown";
	public static final String PLAN_PAYIN = "PAYIN";
	public static final String PLAN_NON_PAYIN = "NON_PAYIN";
	public static final String ICS_PLAN_ADMIN = "ICS_PlanAdmin";

	public static final String TRANSFER_OPERATIONS = "Transfer Operations";

	public static final String OPEN = "Open";
	public static final String SUSPENDED = "Suspended";
	public static final String STEP_STATUS = "StepStatus";
	public static final String IS_SUSPENDED = "IsSuspended";

	// disabled MyWorkItems and can be enabled as needed for Metrics
	// public static final String[] WORKITEMTYPES = { "Unassigned",
	// "AllAssigned", "Pended", "MyWorkItems" };
	public static final String[] WORKITEMTYPES = { "Unassigned", "AllAssigned", "Pended" };
	public static final String[] WORKITEMTYPES_2 = { "Unassigned", "Pended" };
	public static final String AWAKE_TODAY = "AwakeToday";
}
