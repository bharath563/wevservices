package org.tiaa.icm.client.domain;

import org.tiaa.icm.client.utils.ICMClientUtil;

public class Document {

	private String id;

	private String idtype;

	private String mimeType;

	private String documentName;

	private String businessUnit = "PENSION";

	private String docCode = "FILENET_INBOUND_DOC";

	private String version = "1";

	private String folder = "";

	private String formatType = FormatType.Document.toString();

	private String docInstanceId;

	private String createdBy;

	private String createdDate;

	private String docUrl;

	public String getDocUrl() {
		return docUrl;
	}

	public void setDocUrl(String docUrl) {
		this.docUrl = docUrl;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getFolder() {
		return folder;
	}

	public Document setFolder(String folder) {
		this.folder = folder;
		return this;
	}

	public Document() {
	}

	public String getId() {
		return id;
	}

	public String getBusinessUnit() {
		return businessUnit;
	}

	public Document setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
		return this;
	}

	public String getDocCode() {
		return docCode;
	}

	public Document setDocCode(String docCode) {
		this.docCode = docCode;
		return this;
	}

	public String getVersion() {
		return version;
	}

	public Document setVersion(String version) {
		this.version = version;
		return this;
	}

	public Document setId(String id) {
		this.id = id;
		return this;
	}

	public String getIdtype() {
		return idtype;
	}

	public Document setIdtype(String idtype) {
		this.idtype = idtype;
		return this;
	}

	public String getMimeType() {
		return mimeType;
	}

	public Document setMimeType(String mimeType) {
		this.mimeType = mimeType;
		return this;
	}

	public String getDocumentName() {
		return documentName;
	}

	public Document setDocumentName(String documentName) {
		this.documentName = documentName;
		return this;
	}

	public String getFormatType() {
		return formatType;
	}

	public void setFormatType(String formatType) {
		this.formatType = formatType;
	}

	// @Override
	// public String toString() {
	// return super.toString(this);
	// }

	public String getDocInstanceId() {
		return docInstanceId;
	}

	public void setDocInstanceId(String docInstanceId) {
		this.docInstanceId = docInstanceId;
	}

	@Override
	public String toString() {
		return ICMClientUtil.ObjectAsJSON(this);

	}

}
