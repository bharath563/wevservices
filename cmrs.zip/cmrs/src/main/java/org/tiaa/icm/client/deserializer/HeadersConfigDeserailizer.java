package org.tiaa.icm.client.deserializer;

import java.io.IOException;
import java.util.Map;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.JsonProcessingException;
import org.codehaus.jackson.map.DeserializationContext;
import org.codehaus.jackson.map.JsonDeserializer;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;

import org.apache.log4j.Logger;

import org.tiaa.icm.client.domain.entitlement.Properties;

public class HeadersConfigDeserailizer extends JsonDeserializer<Map<String, Properties>> {

	static Logger logger = Logger.getLogger(HeadersConfigDeserailizer.class);

	private static ObjectMapper mapper = new ObjectMapper();

	@Override
	public Map<String, Properties> deserialize(JsonParser parser, DeserializationContext context)
			throws IOException, JsonProcessingException {
		JsonNode node = parser.getCodec().readTree(parser);

		TypeReference<Map<String, Properties>> typeRef = new TypeReference<Map<String, Properties>>() {
		};
		Map<String, Properties> headers = mapper.readValue(node, typeRef);
		logger.debug("HeadersConfigDeserailizer -> headers:" + headers);
		return headers;

	}

}
