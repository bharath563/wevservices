package org.tiaa.icm.client.infocaddy.bo;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import org.tiaa.icm.client.infocaddy.comparators.RecentCasesComparator;
import org.tiaa.icm.client.infocaddy.constant.InfoCaddyConstant;
import org.tiaa.icm.client.infocaddy.domain.RecentCases;
import org.tiaa.icm.client.infocaddy.json.RecentCasesObject;
import org.tiaa.icm.client.infocaddy.json.Type;
import org.tiaa.icm.client.infocaddy.mapper.RecentCasesMapper;
import org.tiaa.icm.client.provider.AppPropertiesProvider;
import org.tiaa.icm.client.rest.InfoCaddyService;
import org.tiaa.icm.client.utils.ICMClientUtil;

@Repository(value = "isInfoCaddyBO")
public class ISInfoCaddyBO implements InfoCaddyBODelegate {

	@Autowired
	private InfoCaddyService infoCaddyService;

	private ObjectMapper objectMapper = new ObjectMapper();

	private final Logger logger = Logger.getLogger(ISInfoCaddyBO.class);

	@Autowired
	private RecentCasesMapper recentCasesMapper;

	private boolean defaultPagination = true;

	public boolean isDefaultPagination() {
		return defaultPagination;
	}

	public void setDefaultPagination(boolean defaultPagination) {
		this.defaultPagination = defaultPagination;
	}

	public List<RecentCasesObject> fetchRecentCases(String caseId) {

		List<Map<String, Object>> completeRecentCaseList = new ArrayList<Map<String, Object>>();

		List<RecentCases> recentCasesList = recentCasesMapper.fetchRecentCases(caseId, getOlderDate());
		String recentcaseId = null;

		Map<String, Object> recentCaseMap = new HashMap<String, Object>();

		for (RecentCases recentCase : recentCasesList) {
			String idValue = (null == recentCase.getIdentifierValue()) ? "" : recentCase.getIdentifierValue();
			// Means this is the new case
			if ((null == recentcaseId) || !recentcaseId.equalsIgnoreCase(recentCase.getCaseId())) {
				recentcaseId = recentCase.getCaseId();
				recentCaseMap = new HashMap<String, Object>();

				recentCaseMap.put("caseid", idValue);
				recentCaseMap.put("filename", "");
				recentCaseMap.put("created", recentCase.getStrCaseStartedTS());
				recentCaseMap.put("processed", "");
				recentCaseMap.put("status", recentCase.getStatus());
				completeRecentCaseList.add(recentCaseMap);

			} else {
				if (recentCase.getIdentifierName().equalsIgnoreCase("Client File Name")) {
					recentCaseMap.put("filename", idValue);
				} else
				// If third identifier, set it
				if (recentCase.getIdentifierName().equalsIgnoreCase("Last Processed By")) {
					recentCaseMap.put("processed", idValue);
				}
			}
		}

		return convertToRecentCasesList(completeRecentCaseList);
	}

	private List<RecentCasesObject> convertToRecentCasesList(List<Map<String, Object>> recentCasesListObject) {

		List<RecentCasesObject> recentCases = new ArrayList<RecentCasesObject>();

		for (Map<String, Object> map : recentCasesListObject) {

			RecentCasesObject recentCasesObject = new RecentCasesObject();

			recentCasesObject.setCaseId((String) map.get("caseid"));
			recentCasesObject.setCreated((String) map.get("created"));
			recentCasesObject.setFileName((String) map.get("filename"));
			recentCasesObject.setProcessed((String) map.get("processed"));
			recentCasesObject.setStatus((String) map.get("status"));
			recentCases.add(recentCasesObject);
		}

		// Default Pagination
		if (isDefaultPagination() && (recentCases.size() > 0)) {

			Collections.sort(recentCases, new RecentCasesComparator("DESC", "created"));

			int end = recentCases.size() > AppPropertiesProvider.getIntProperty("noOfRecentCases")
					? AppPropertiesProvider.getIntProperty("noOfRecentCases") : recentCases.size();

			recentCases = recentCases.subList(0, end);
		}

		return recentCases;

	}

	private Timestamp getOlderDate() {
		int months = AppPropertiesProvider.getIntProperty("noOfMonthsForRecentCases");
		Calendar cal = Calendar.getInstance();

		// subtracting configured months.
		cal.add(Calendar.MONTH, -months);

		return new Timestamp(new Date(cal.getTimeInMillis()).getTime());
	}

	private List<Object> processGeneralInformation(List<Object> infoCaddyDetailsList, String caseId) throws Exception {

		logger.debug("Entering processGeneralInformation(Type[] infoCaddyDetails, String caseId)...");

		String infoCaddyResponseJSONString = this.objectMapper.writeValueAsString(infoCaddyDetailsList);

		Type[] infoCaddyDetails = this.objectMapper.readValue(infoCaddyResponseJSONString, Type[].class);

		infoCaddyDetailsList.clear();

		for (Type type : infoCaddyDetails) {

			// Get Recent Cases
			if (!ICMClientUtil.isEmpty(type.getName())
					&& type.getName().equalsIgnoreCase(InfoCaddyConstant.RECENT_CASES)) {

				String recentCasesInfo = !ICMClientUtil.isNull(type.getValue()) ? type.getValue().toString() : "";

				if (!ICMClientUtil.isEmpty(recentCasesInfo) && recentCasesInfo.contains("action-hover='recentCase'")) {
					String occurences = recentCasesInfo.substring(recentCasesInfo.indexOf("<span class='count'>"),
							recentCasesInfo.indexOf("</span>"));

					occurences = occurences.substring(occurences.lastIndexOf(">") + 1);
					try {

						int occurencesValue = Integer.parseInt(occurences);

						if (occurencesValue > 0) {

							type.setValue(fetchRecentCases(caseId));

						} else {

							type.setValue(null);

						}

					} catch (NumberFormatException nfe) {

						logger.error("Error in converting string to number " + nfe.getMessage());

					}
				}

			}
		}

		infoCaddyDetailsList.add(infoCaddyDetails);
		logger.debug("Exiting processGeneralInformation(Type[] infoCaddyDetails, String caseId)...");

		return infoCaddyDetailsList;
	}

	@Override
	public List<Object> getInfoCaddyDetails(String caseId, String solution, String section) throws Exception {
		logger.debug("Entering getInfoCaddyDetails(String caseId, String solution, String section...)");

		List<Object> infoCaddyDetailsList = infoCaddyService.getInfoCaddyDetails(solution, caseId, section);

		// Process response for General section only. For other sections use
		// response as it is.
		if (InfoCaddyConstant.GENERAL.equalsIgnoreCase(section)) {

			infoCaddyDetailsList = processGeneralInformation(infoCaddyDetailsList, caseId);

		}

		logger.debug("Exiting getInfoCaddyDetails(String caseId, String solution, String section...)");

		return infoCaddyDetailsList;
	}

}
