package org.tiaa.icm.client.bo.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.security.auth.Subject;

import org.apache.log4j.Logger;

import com.ibm.websphere.security.auth.WSSubject;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.icm.client.bo.engine.ContentBO;
import org.tiaa.icm.client.cache.ICMClientCache;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Case;
import org.tiaa.icm.client.domain.CaseSearch;
import org.tiaa.icm.client.domain.ResponseList;
import org.tiaa.icm.client.mapper.CaseMapper;
import org.tiaa.icm.client.provider.AppPropertiesProvider;
import org.tiaa.icm.client.utils.ICMClientUtil;

public class CaseSearchHelper {

	@Autowired
	private CaseMapper caseMapper;

	@Autowired
	private ContentBO contentBO;

	private static Logger logger = Logger.getLogger(CaseSearchHelper.class);

	public ResponseList doSearch(CaseSearch caseSearch, String start, String osName) throws Exception {
		logger.debug("doSearch method ...................");

		List<Case> caseList = new ArrayList<Case>();

		logger.debug("caseSearch.getPlan():" + caseSearch.getPlan());
		// Getting current subject to push to new threads
		Subject currentSubject = WSSubject.getCallerSubject();
		// Subject currentSubject = UserContext.get().getSubject();
		logger.debug("Subject before submitting request to CaseSearchPlanNoCE:" + currentSubject);

		caseList = getCasesFromDB_CE(caseSearch, start, osName, currentSubject);
		setCaseDetails(caseSearch, caseList);
		// caseList = sortCaseList(caseList, caseSearch.getSortField(),
		// caseSearch.getSortOrder());
		return ICMClientUtil.createResponseList(caseList);

	}

	private void setCaseDetails(CaseSearch caseSearch, List<Case> caseList) {
		SimpleDateFormat formatter = new SimpleDateFormat(CommonConstants.MMDDYYYYHHMMSS);

		int size = 0;
		if ((caseList != null) && !caseList.isEmpty()) {
			// if (!ICMClientUtil.isNull(caseSearch.getPlan())) {
			size = caseList.size();
			/*
			 * } else { size = caseList.size() > 0 ?
			 * caseList.get(0).getTotalRecords() : 0; }
			 */
			logger.debug("BEFORE setting key values in caseList size:::" + size);

			for (Case caseObj : caseList) {
				if (!ICMClientUtil.isNull(caseObj.getCreatedDt())) {
					caseObj.setCreatedDate(formatter.format(caseObj.getCreatedDt()));
				}

				if (!ICMClientUtil.isNull(caseObj.getModifiedDt())) {
					caseObj.setModifiedDate((formatter.format(caseObj.getModifiedDt())));
				}

				if (!ICMClientUtil.isNull(caseObj.getRequestReceivedDt())) {
					caseObj.setRequestReceivedDate((formatter.format(caseObj.getRequestReceivedDt())));
				}

				if (ICMClientUtil.isEmpty(caseSearch.getCaseStatus())) {
					caseObj.setStatus(ICMClientCache.getUWMappingStatuses(caseObj.getStatus()));
				} else {
					caseObj.setStatus(caseSearch.getCaseStatus());
				}

				if (!ICMClientUtil.isEmpty(caseObj.getChannel())) {
					caseObj.setChannel(caseObj.getChannel().toUpperCase());
				}

				if (!ICMClientUtil.isEmpty(caseSearch.getSolution())) {
					caseObj.setSolution(caseSearch.getSolution());
				}
			}
		}

	}

	private List<Case> getCasesFromDB_CE(CaseSearch caseSearch, String start, String osName, Subject currentSubject)
			throws Exception {
		// PLAN solutions are PO,PI, TRANSFERS and ICS
		// caseSearchDBForPlanSolutions is PO,PI, TRANSFERS
		// NON PLAN solutions are all other solutions except PO,PI, TRANSFERS
		// and ICS
		ExecutorService executor = null;
		List<Case> caseList = new ArrayList<Case>();
		List<Callable<List<Case>>> searchTasks = new ArrayList<Callable<List<Case>>>();
		try {

			if (checkCESearch(caseSearch.getPlan(), caseSearch.getSolution(), caseSearch.getCaseType())) {

				logger.debug(
						"CaseSearchPlanNoDB invoked with plan number = " + caseSearch.getPlan() + " , Department = "
								+ caseSearch.getSolution() + " And Case Type = " + caseSearch.getCaseType());

				CaseSearchPlanNumCE caseSearchPlanNumCE_ICS = new CaseSearchPlanNumCE(caseSearch, start, osName,
						currentSubject);
				searchTasks.add(caseSearchPlanNumCE_ICS);

			} else if (ICMClientUtil.isEmpty(caseSearch.getPlan())) {
				logger.debug("CaseSearchPlanNoDB invoked with NO plan number ...................");
				CaseSearchDB caseSearchNonPlanSolutions = new CaseSearchDB(caseSearch, CommonConstants.NON_PLAN, start);
				searchTasks.add(caseSearchNonPlanSolutions);
			}

			CaseSearchDB caseSearchDB_Plan_Payin = null;
			CaseSearchDB caseSearchDB_Plan_NonPayin = null;

			// If there is no solution name passed then execute both Query 1 and
			// Query 2 mentioned below
			if (ICMClientUtil.isEmpty(caseSearch.getSolution())) {
				// search for cases that have plan number
				// Query 1 : for Payin solution cases
				caseSearchDB_Plan_Payin = new CaseSearchDB(caseSearch, CommonConstants.PLAN_PAYIN, start);

				// Query 2: for all other plan solutions that are not payin
				caseSearchDB_Plan_NonPayin = new CaseSearchDB(caseSearch, CommonConstants.PLAN_NON_PAYIN, start);
				searchTasks.add(caseSearchDB_Plan_Payin);
				searchTasks.add(caseSearchDB_Plan_NonPayin);
			} else {
				// For Payin Operation is passed in request then execute query
				// 1 as shown below.
				if (CommonConstants.PAYIN_OPERATIONS.equalsIgnoreCase(caseSearch.getSolution())) {
					// Query 1 : for Payin solution cases
					caseSearchDB_Plan_Payin = new CaseSearchDB(caseSearch, CommonConstants.PLAN_PAYIN, start);
					searchTasks.add(caseSearchDB_Plan_Payin);
				}
				// Otherwise execute Query#2 for other solutions
				else {
					// Query 2: for all other plan solutions that are not payin
					caseSearchDB_Plan_NonPayin = new CaseSearchDB(caseSearch, CommonConstants.PLAN_NON_PAYIN, start);
					searchTasks.add(caseSearchDB_Plan_NonPayin);
				}
			}

			logger.info("Case Search Executor Start--> ");

			executor = Executors
					.newFixedThreadPool(Integer.parseInt(AppPropertiesProvider.getProperty("maxThreadPoolSize")));
			// executor.awaitTermination(Integer.parseInt(AppPropertiesProvider.getProperty("searchThreadsTimeOut")),
			// TimeUnit.SECONDS);

			List<Future<List<Case>>> results = executor.invokeAll(searchTasks);
			for (Future<List<Case>> future : results) {
				caseList.addAll(future.get());
			}
			logger.info("Case Search Executor End , CaseList size:::::" + caseList.size());

		} catch (Exception e) {
			throw e;
		} finally {
			if (executor != null) {
				executor.shutdown();
			}
		}

		return filterAddMultiPlan(caseList);
	}

	// private List<Case> sortCaseList(List<Case> caseList, String sortField,
	// String sortOrder) {
	//
	// if (sortOrder.equalsIgnoreCase("asc")) {
	// Collections.sort(caseList, new CaseComparator(sortField));
	// } else if (sortOrder.equalsIgnoreCase("desc")) {
	// Collections.sort(caseList, Collections.reverseOrder(new
	// CaseComparator(sortField)));
	// // Collections.sort(caseList, new CaseComparator(sortField));
	// // Collections.reverseOrder();
	// }
	// return caseList;
	// }

	private List<Case> filterAddMultiPlan(List<Case> caseList) {
		// logger.debug("caseList in filterAddMultiPlan caseList:" + caseList);
		logger.debug("caseList in filterAddMultiPlan start:" + caseList.size());
		Map<String, Case> casesMap = new HashMap<String, Case>();
		for (Case eachCase : caseList) {
			String caseId = eachCase.getId();
			String currentPlan = eachCase.getPlan();
			if (casesMap.containsKey(caseId)) {
				String existingPlan = casesMap.get(caseId).getPlan();

				if ((currentPlan != null) && (existingPlan != null)) {
					existingPlan = existingPlan.concat(",");
					eachCase.setPlan(existingPlan.concat(currentPlan));
				} else if ((currentPlan != null) && (existingPlan == null)) {
					eachCase.setPlan(currentPlan);
				} else if ((currentPlan == null) && (existingPlan != null)) {
					eachCase.setPlan(existingPlan);
				}
			}
			// logger.debug(caseId + "eachCase.getPlan():" +
			// eachCase.getPlan());
			eachCase.getAdditionalIdentifiers().put("plan", eachCase.getPlan());
			casesMap.put(caseId, eachCase);
		}
		logger.info("caseList in filterAddMultiPlan end: " + casesMap.size());

		return new ArrayList<Case>(casesMap.values());
	}

	private class CaseSearchDB implements Callable<List<Case>> {

		private String planIdentifier;
		private CaseSearch caseSearch;
		private String start;

		public CaseSearchDB(CaseSearch caseSearch, String planIdentifier, String start) {
			this.planIdentifier = planIdentifier;
			this.caseSearch = caseSearch;
			this.start = start;
			logger.debug("planIdentifier:" + this.planIdentifier);

		}

		@Override
		public List<Case> call() throws Exception {
			return fetchDBInfoForPlanNo();
		}

		/*
		 * This method searches data from DB for 1) PLAN related solutions = Not
		 * NON PLAN 2) Non-plan related soutions
		 *
		 */
		private List<Case> fetchDBInfoForPlanNo() {
			List<Case> caseList = null;
			if ((caseSearch.getDateRange() == null) && !(planIdentifier.equalsIgnoreCase(CommonConstants.NON_PLAN))) {
				caseList = caseMapper.searchCase(caseSearch.getConfirmation(), caseSearch.getPins(),
						caseSearch.getClientId(), caseSearch.getCaseType(), caseSearch.getChannel(), null, null, null,
						caseSearch.getSsns(), caseSearch.getCaseStatus(), caseSearch.getPlan(),
						caseSearch.getSortField(), caseSearch.getSortOrder(), planIdentifier, caseSearch.getSolution(),
						start);
			} else if ((caseSearch.getDateRange() != null)
					&& !(planIdentifier.equalsIgnoreCase(CommonConstants.NON_PLAN))) {
				caseList = caseMapper.searchCase(caseSearch.getConfirmation(), caseSearch.getPins(),
						caseSearch.getClientId(), caseSearch.getCaseType(), caseSearch.getChannel(),
						caseSearch.getDateRange().getType(), caseSearch.getDateRange().getFrom(),
						caseSearch.getDateRange().getTo(), caseSearch.getSsns(), caseSearch.getCaseStatus(),
						caseSearch.getPlan(), caseSearch.getSortField(), caseSearch.getSortOrder(), planIdentifier,
						caseSearch.getSolution(), start);
			} else if ((caseSearch.getDateRange() == null)
					&& planIdentifier.equalsIgnoreCase(CommonConstants.NON_PLAN)) {
				caseList = caseMapper.searchCase(caseSearch.getConfirmation(), caseSearch.getPins(),
						caseSearch.getClientId(), caseSearch.getCaseType(), caseSearch.getChannel(), null, null, null,
						caseSearch.getSsns(), caseSearch.getCaseStatus(), caseSearch.getPlan(),
						caseSearch.getSortField(), caseSearch.getSortOrder(), CommonConstants.NON_PLAN,
						caseSearch.getSolution(), start);
			} else if ((caseSearch.getDateRange() != null)
					&& planIdentifier.equalsIgnoreCase(CommonConstants.NON_PLAN)) {
				caseList = caseMapper.searchCase(caseSearch.getConfirmation(), caseSearch.getPins(),
						caseSearch.getClientId(), caseSearch.getCaseType(), caseSearch.getChannel(),
						caseSearch.getDateRange().getType(), caseSearch.getDateRange().getFrom(),
						caseSearch.getDateRange().getTo(), caseSearch.getSsns(), caseSearch.getCaseStatus(),
						caseSearch.getPlan(), caseSearch.getSortField(), caseSearch.getSortOrder(),
						CommonConstants.NON_PLAN, caseSearch.getSolution(), start);
			}

			/*
			 * if (solutionName.equalsIgnoreCase(CommonConstants.
			 * PAYOUT_PAYIN_TRANSFERS)) { // method to append if the same case
			 * has multiple plans for // PI,PO and TO cases caseList =
			 * filterAddMultiPlan(caseList); }
			 */
			logger.info("CaseList size after plan related solutionName:" + planIdentifier + ",::::" + caseList.size());
			return caseList;
		}

	}

	private class CaseSearchPlanNumCE implements Callable<List<Case>> {

		private String osName;
		private CaseSearch caseSearch;
		private String start;
		private Subject currentSubject;

		public CaseSearchPlanNumCE(CaseSearch caseSearch, String start, String osName, Subject currentSubject) {
			this.osName = osName;
			this.caseSearch = caseSearch;
			this.start = start;
			logger.debug("currentSubject::::" + currentSubject);
			this.currentSubject = currentSubject;
			logger.debug("this. currentSubject:::" + this.currentSubject);
		}

		@Override
		public List<Case> call() throws Exception {
			// logger.debug("Entered CaseSearchPlanNoCE:" + this.caseSearch +
			// "," + this.start + "," + this.osName + ","
			// + this.currentSubject);
			return contentBO.getICSCasesForPlanNo(this.caseSearch, this.start, this.osName, this.currentSubject);

		}

	}

	private boolean checkCESearch(String planNumber, String solution, String caseType) {

		// If plan number is present and if solution name or case type or
		// both are present in search request then check conditions below.
		if (!ICMClientUtil.isEmpty(planNumber) && ((!ICMClientUtil.isEmpty(solution)
				&& CommonConstants.ICS.equalsIgnoreCase(solution))
				|| (!ICMClientUtil.isEmpty(caseType) && CommonConstants.ICS_PLAN_ADMIN.equalsIgnoreCase(caseType)))) {

			return true;

		}

		// If plan number is not present and if either solution name or case
		// type or both specific to ICS solution are present in search request
		// then check conditions below.
		else if (ICMClientUtil.isEmpty(planNumber) && ((!ICMClientUtil.isEmpty(solution)
				&& CommonConstants.ICS.equalsIgnoreCase(solution))
				|| (!ICMClientUtil.isEmpty(caseType) && CommonConstants.ICS_PLAN_ADMIN.equalsIgnoreCase(caseType)))) {

			return true;

		}

		// Only plan number is present in case search request then fetch plan
		// numbers from CE as well.
		else if (!ICMClientUtil.isEmpty(planNumber) && ICMClientUtil.isEmpty(solution)
				&& ICMClientUtil.isEmpty(caseType)) {

			return true;

		}

		return false;
	}

}
