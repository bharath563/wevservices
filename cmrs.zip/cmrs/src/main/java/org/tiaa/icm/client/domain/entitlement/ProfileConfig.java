package org.tiaa.icm.client.domain.entitlement;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonDeserialize;

import org.tiaa.icm.client.deserializer.ProfileConfigDeserializer;

@JsonDeserialize(using = ProfileConfigDeserializer.class)
public class ProfileConfig {

	private String type;

	private List<Profile> profiles;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<Profile> getProfiles() {
		return profiles;
	}

	public void setProfiles(List<Profile> profiles) {
		this.profiles = profiles;
	}

}
