package org.tiaa.icm.client.bean;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.apache.tomcat.jdbc.pool.DataSource;

import com.filenet.api.core.Factory;
import com.filenet.api.exception.EngineRuntimeException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Components;
import org.tiaa.icm.client.domain.PingResponse;
import org.tiaa.icm.client.mapper.ICMClientMapper;
import org.tiaa.icm.client.utils.ICMClientUtil;

import filenet.vw.api.VWException;
import filenet.vw.api.VWSession;

public class ICMClientBean {

	private static Logger logger = Logger.getLogger(ICMClientBean.class);

	@Autowired
	private DataSource cmRepotingDataSource;

	@Value("${ceIIOPBootStrapUrl}")
	private String ceEJBURI;

	@Value("${connectionPoint}")
	private String PEConnectionPoint;

	public PingResponse ping(HttpServletRequest request, String racfId) throws UnknownHostException {
		DateFormat dateFormat = new SimpleDateFormat(CommonConstants.MMDDYYYY12HR);
		boolean healthFlag = true;
		PingResponse pingResponse = new PingResponse();
		InetAddress ip = InetAddress.getLocalHost();
		pingResponse.setService(request.getContextPath().substring(1));
		pingResponse.setPingDateTime(dateFormat.format(new Date()));
		pingResponse.setIpaddress(ip.getHostAddress());
		pingResponse.setHostName(ip.getHostName());
		Components components = new Components();
		try {
			cmRepotingDataSource.getConnection();
			Factory.Connection.getConnection(ceEJBURI);
			logger.debug("connection---" + Factory.Connection.getConnection(ceEJBURI));
			VWSession peSession = new VWSession(PEConnectionPoint);

		} catch (EngineRuntimeException e) {
			healthFlag = false;
			components.setCe(e.getMessage());
		} catch (VWException ve) {
			healthFlag = false;
			components.setPe(ve.getMessage());

		} catch (Exception e) {
			healthFlag = false;
			components.setVcase(e.getMessage());
		}

		if (healthFlag) {
			pingResponse.setHealthCheck("SUCCESS");
		} else {
			pingResponse.setHealthCheck("FAILURE");
		}

		pingResponse.setComponents(components);
		return pingResponse;
	}

	public Map<String, String> getCaseTypes(ICMClientMapper icmClientMapper) {
		return ICMClientUtil.pojoToMap(icmClientMapper.getCaseTypes());
	}

	public Map<String, String> getCaseStatus(ICMClientMapper icmClientMapper) {
		return ICMClientUtil.pojoToMap(icmClientMapper.getStatuses());
	}

	public Map<String, String> getChannel(ICMClientMapper icmClientMapper) {
		return ICMClientUtil.pojoToMap(icmClientMapper.getChannels());
	}

	public Map<String, String> getSolutions(ICMClientMapper icmClientMapper) {
		return ICMClientUtil.pojoToMap(icmClientMapper.getSolutions());
	}

	public Map<String, String> getCaseMappingStatuses(ICMClientMapper icmClientMapper) {
		return ICMClientUtil.pojoToMap(icmClientMapper.getCaseMappingStatuses());
	}

}
