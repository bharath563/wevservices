package org.tiaa.icm.client.infocaddy.domain;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class RepaymentDetails {

	private String plan;
	private String subPlan;
	private String groupId;
	private String omniStatus;
	private Timestamp omniPostDate;
	private BigDecimal amount;
	private String paymentMethod;
	private String loanId;
	private String transactionType;
	private String transactionValue;
	private String type;

	public String getPlan() {
		return this.plan;
	}

	public void setPlan(String plan) {
		this.plan = plan;
	}

	public String getSubPlan() {
		return this.subPlan;
	}

	public void setSubPlan(String subPlan) {
		this.subPlan = subPlan;
	}

	public String getGroupId() {
		return this.groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getOmniStatus() {
		return this.omniStatus;
	}

	public void setOmniStatus(String omniStatus) {
		this.omniStatus = omniStatus;
	}

	public Timestamp getOmniPostDate() {
		return this.omniPostDate;
	}

	public void setOmniPostDate(Timestamp omniPostDate) {
		this.omniPostDate = omniPostDate;
	}

	public BigDecimal getAmount() {
		return this.amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getPaymentMethod() {
		return this.paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getLoanId() {
		return this.loanId;
	}

	public void setLoanId(String loanId) {
		this.loanId = loanId;
	}

	public String getTransactionType() {
		return this.transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return this.type;
	}

	/**
	 * @param type
	 *            the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	public String getTransactionValue() {
		return this.transactionValue;
	}

	public void setTransactionValue(String transactionValue) {
		this.transactionValue = transactionValue;
	}

}
