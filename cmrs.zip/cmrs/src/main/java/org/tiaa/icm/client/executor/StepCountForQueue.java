package org.tiaa.icm.client.executor;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;

import javax.security.auth.Subject;

import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;

import com.filenet.api.util.UserContext;

import org.tiaa.icm.client.constant.CommonConstants;

import filenet.vw.api.VWException;
import filenet.vw.api.VWFetchType;
import filenet.vw.api.VWQueue;
import filenet.vw.api.VWQueueQuery;
import filenet.vw.api.VWSession;
import filenet.vw.api.VWWorkObject;

public class StepCountForQueue implements Callable<Map<String, Integer>> {

	public final String queueName;
	public final String filter;
	public final VWSession vwSession;
	public final Subject currentSubject;
	public final String workitemType;

	private static Logger logger = Logger.getLogger(GetStepParallel.class);

	public StepCountForQueue(String queueName, String filter, VWSession vwSession, Subject currentSubject,
			String workitemType) {
		this.queueName = queueName;
		this.filter = filter;
		this.vwSession = vwSession;
		this.currentSubject = currentSubject;
		this.workitemType = workitemType;
	}

	@Override
	public Map<String, Integer> call() throws VWException, ParseException {
		return getStepsCountForQueue(queueName, filter, vwSession, currentSubject);
	}

	private Map<String, Integer> getStepsCountForQueue(String queueName, String filter, VWSession vwSession,
			Subject currentSubject) throws VWException, ParseException {
		int queryFlags = VWQueue.QUERY_READ_BOUND + VWQueue.QUERY_READ_LOCKED;
		int fetchType = VWFetchType.FETCH_TYPE_WORKOBJECT;
		Map<String, Integer> queueCount = new HashMap<String, Integer>();
		VWQueueQuery vwQuery = null;
		VWQueue queue = null;
		UserContext userContext = UserContext.get();
		userContext.pushSubject(currentSubject);
		int count = 0;
		try {
			if (vwSession != null) {
				queue = vwSession.getQueue(queueName);
				vwQuery = queue.createQuery(null, null, null, queryFlags, filter, null, fetchType);
				count = vwQuery.fetchCount();
				logger.info(
						"Fetch Count " + vwQuery.fetchCount() + " For Queue:" + queueName + " and Filter: " + filter);
			}
			queueCount.put(queueName, count);

			if (this.workitemType.equalsIgnoreCase("Pended")) {
				int awakeDayToday = 0;
				while ((vwQuery != null) && vwQuery.hasNext()) {

					VWWorkObject wo = (VWWorkObject) vwQuery.next();
					Date awakeDate = null;
					if (wo.hasFieldName("WakeDateTimeET")) {
						awakeDate = (Date) wo.getFieldValue("WakeDateTimeET");
					} else if (wo.hasFieldName("PO_WakeDateTime")) {
						awakeDate = (Date) wo.getFieldValue("PO_WakeDateTime");
					}
					logger.debug("awakeDate:" + awakeDate);
					Date today = new Date();
					if ((awakeDate != null) && DateUtils.isSameDay(today, awakeDate)) {

						awakeDayToday++;
					}
					queueCount.put(CommonConstants.AWAKE_TODAY, awakeDayToday);
				}
			}
		} finally {
			userContext.popSubject();
		}
		return queueCount;
	}
}
