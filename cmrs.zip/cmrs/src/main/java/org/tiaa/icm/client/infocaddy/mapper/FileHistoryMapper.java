package org.tiaa.icm.client.infocaddy.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.type.Alias;

import org.tiaa.icm.client.infocaddy.domain.FileHistory;

@Alias("dIdentifier")
public interface FileHistoryMapper {
	public List<FileHistory> fetchByGroupIdAndIdentifierNames(@Param("groupIds") List<String> groupIds,
			@Param("identifierNames") List<String> identifierNames);

}
