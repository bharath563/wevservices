package org.tiaa.icm.client.domain.spi;

import java.util.List;

import org.tiaa.icm.client.domain.Event;

public interface IEvents {

	public List<Event> getEvents();
}
