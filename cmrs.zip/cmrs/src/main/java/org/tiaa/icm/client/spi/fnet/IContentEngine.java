/**
 *
 */
package org.tiaa.icm.client.spi.fnet;

import java.util.List;
import java.util.Map;

import javax.security.auth.Subject;

import com.filenet.api.exception.EngineRuntimeException;
import com.filenet.api.util.Id;

import org.tiaa.icm.client.domain.Case;
import org.tiaa.icm.client.domain.CaseSearch;
import org.tiaa.icm.client.domain.Comment;
import org.tiaa.icm.client.domain.Document;
import org.tiaa.icm.client.domain.Event;
import org.tiaa.icm.client.domain.Task;

/**
 * @author ganapaa
 *
 */
public interface IContentEngine {

	public Case getCaseDetails(String osName, String caseID) throws EngineRuntimeException, Exception;

	public List<Comment> getComments(String osName, String caseID) throws Exception;

	public List<Document> getDocuments(String osName, String caseID) throws Exception;

	public List<Event> getHistory(String osName, String caseID, String type) throws Exception;

	public Id addCaseComments(String osName, String caseId, String commentText) throws Exception;

	public Id addDocumentComments(String osName, String caseId, String docId, String commentText) throws Exception;

	public Id addTaskComments(String osName, String caseId, String taskId, String commentText) throws Exception;

	public Id addStepComments(String osName, String caseId, String wobId, String queueName, String commentText,
			String racfId) throws Exception;

	public Id createDocument(String osName, String caseID, Document document) throws Exception;

	public Id updateDocument(String osName, String caseID, Document document, String documentId) throws Exception;

	public Id createTask(String osName, String caseID, String taskDisplayName, String taskType) throws Exception;

	// public List<RelatedCase> getRelatedCases(String osName, String caseID);

	public List<Case> getICSCasesForPlanNo(CaseSearch caseSearch, String start, String osName, Subject currentSubject);

	public Map<String, Task> getTasks(String osName, String caseID);
}
