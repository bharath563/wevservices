package org.tiaa.icm.client.infocaddy.domain;

public enum PaymentMethod {
	ADT_SINGLEDEBIT("1") {
		@Override
		public String toString() {
			return "ADT / Single Debit";
		}
	},
	LOCKBOX("2") {
		@Override
		public String toString() {
			return "Lockbox";
		}
	},
	Manual("3") {
		@Override
		public String toString() {
			return "Manual";
		}
	},
	DISTRIBUTABLE_DEFAULT("4") {
		@Override
		public String toString() {
			return "Distributable Default";
		}
	},
	WRITEOFF("5") {
		@Override
		public String toString() {
			return "Writeoff";
		}
	},
	PAYROLL("7") {
		@Override
		public String toString() {
			return "Payroll";
		}
	},
	PAL_MANUAL_REPAYMENT("8") {
		@Override
		public String toString() {
			return "PAL manual repayment";
		}
	},
	AFTER_TAX_DEFAULT_REPAYMENT("B") {
		@Override
		public String toString() {
			return "After tax default repayment";
		}
	};

	private String value;

	private PaymentMethod(String _value) {
		this.value = _value;
	}

	public static PaymentMethod fromValue(String value) {
		PaymentMethod result = null;
		PaymentMethod[] instances = PaymentMethod.values();
		for (PaymentMethod instance : instances) {
			if (instance.value.equals(value)) {
				result = instance;
				break;
			}
		}
		return result;
	}
}
