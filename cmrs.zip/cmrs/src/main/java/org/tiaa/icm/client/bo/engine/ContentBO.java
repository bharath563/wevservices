package org.tiaa.icm.client.bo.engine;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.security.auth.Subject;

import org.apache.log4j.Logger;

import com.filenet.api.collection.AnnotationSet;
import com.filenet.api.collection.CmTaskSet;
import com.filenet.api.collection.ContentElementList;
import com.filenet.api.collection.DocumentSet;
import com.filenet.api.collection.FolderSet;
import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.collection.PropertyDescriptionList;
import com.filenet.api.constants.AutoClassify;
import com.filenet.api.constants.AutoUniqueName;
import com.filenet.api.constants.CheckinType;
import com.filenet.api.constants.ClassNames;
import com.filenet.api.constants.DefineSecurityParentage;
import com.filenet.api.constants.FilteredPropertyType;
import com.filenet.api.constants.LifecycleChangeFlags;
import com.filenet.api.constants.PropertyNames;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.constants.ReservationType;
import com.filenet.api.constants.TaskState;
import com.filenet.api.constants.TypeID;
import com.filenet.api.core.Annotation;
import com.filenet.api.core.CmTask;
import com.filenet.api.core.Connection;
import com.filenet.api.core.ContentElement;
import com.filenet.api.core.ContentReference;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.IndependentObject;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.ReferentialContainmentRelationship;
import com.filenet.api.core.VersionSeries;
import com.filenet.api.core.Versionable;
import com.filenet.api.exception.EngineRuntimeException;
import com.filenet.api.meta.ClassDescription;
import com.filenet.api.meta.PropertyDescription;
import com.filenet.api.property.FilterElement;
import com.filenet.api.property.Properties;
import com.filenet.api.property.Property;
import com.filenet.api.property.PropertyFilter;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;
import com.filenet.api.util.Id;
import com.filenet.api.util.UserContext;
import com.filenet.apiimpl.core.FolderImpl;
import com.filenet.apiimpl.property.PropertyBooleanImpl;
import com.filenet.apiimpl.property.PropertyDateTimeImpl;
import com.filenet.apiimpl.property.PropertyFloat64Impl;
import com.filenet.apiimpl.property.PropertyStringImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.tiaa.icm.client.ccpdocuments.delegate.CCPDocumentsDelegate;
import org.tiaa.icm.client.config.CCPDocumentsConfig;
import org.tiaa.icm.client.constant.CommentType;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Case;
import org.tiaa.icm.client.domain.CaseSearch;
import org.tiaa.icm.client.domain.Comment;
import org.tiaa.icm.client.domain.Document;
import org.tiaa.icm.client.domain.Event;
import org.tiaa.icm.client.domain.FormatType;
import org.tiaa.icm.client.domain.Status;
import org.tiaa.icm.client.domain.Task;
import org.tiaa.icm.client.domain.spi.Comments;
import org.tiaa.icm.client.domain.spi.Documents;
import org.tiaa.icm.client.domain.spi.Folders;
import org.tiaa.icm.client.domain.spi.Tasks;
import org.tiaa.icm.client.mapper.RelatedCasesMapper;
import org.tiaa.icm.client.provider.AppPropertiesProvider;
import org.tiaa.icm.client.spi.fnet.IContentEngine;
import org.tiaa.icm.client.utils.ICMClientUtil;

import filenet.vw.api.VWException;
import filenet.vw.api.VWSession;
import filenet.vw.api.VWStepElement;

public class ContentBO implements IContentEngine {

	private HashMap<String, ObjectStore> objectStores = new HashMap<String, ObjectStore>();

	private static Logger LOG = Logger.getLogger(ContentBO.class);
	public static final int SEARCH_PAGE_SIZE = 100;
	public static final Long SEARCH_MAX_SIZE = 100000L;
	private static String receivedDatesConfig = null;

	@Value("${ceIIOPBootStrapUrl}")
	private String ceEJBURI;

	@Value("${BASE-URI}")
	private String fdribaseUri;

	@Autowired
	private ProcessBO processBO;

	@Autowired
	private RelatedCasesMapper relatedCasesMapper;

	@Autowired
	CCPDocumentsConfig ccpDocumentsConfig;

	@Value("${niceRestEndpoint}")
	private String niceRestEndpoint;

	private final static Long MAX_SIZE = 1000000L;

	private final static int PAGE_SIZE = 100;

	private VWSession vwSession = null;

	private DateFormat dateFormat = new SimpleDateFormat(CommonConstants.MMDDYYYY12HR);

	@Override
	public Case getCaseDetails(String osName, String caseID) {
		DateFormat dateFormat = new SimpleDateFormat(CommonConstants.MMDDYYYYHHMMSS);
		Folder caseFolder = null;
		Case caseObj = new Case();
		caseFolder = Factory.Folder.fetchInstance(getOS(osName), caseID, null);

		if (caseFolder == null) {
			LOG.error("Case doesn't exist with ID->'" + caseID + "'");
			return caseObj;
		}
		HashMap<String, Object> caseProperties = new HashMap<String, Object>();
		caseObj.setId(caseFolder.get_Id().toString());
		IndependentObject io = caseFolder.get_ClassDescription();
		LOG.debug(io.getObjectReference().getObjectIdentity());

		HashMap<String, String> propertyInfo = getPropertyDescription(osName,
				io.getObjectReference().getObjectIdentity());

		Properties props = caseFolder.getProperties();

		String solutionName = getSolutionName(props);

		// to support different types of channel property template being
		// used in
		// solution
		if (props.isPropertyPresent("OPSChannel")) {
			caseObj.setChannel(props.getStringValue("OPSChannel"));
		} else if (props.isPropertyPresent("TC_Channel")) {
			caseObj.setChannel(props.getStringValue("TC_Channel"));
		} else if (props.isPropertyPresent("AT_Channel")) {
			caseObj.setChannel(props.getStringValue("AT_Channel"));
		} else if (props.isPropertyPresent("ICS_Channel")) {
			caseObj.setChannel(props.getStringValue("ICS_Channel"));
		} else if (props.isPropertyPresent("Channel")) {
			caseObj.setChannel(props.getStringValue("Channel"));
		}

		caseObj.setCreatedDate(dateFormat.format(props.getDateTimeValue("DateCreated")));
		caseObj.setModifiedDate(dateFormat.format(props.getDateTimeValue("DateLastModified")));
		caseObj.setPathName(caseFolder.get_PathName());

		/*
		 * if (props.isPropertyPresent("CaseStatus")) {
		 * caseObj.setStatus(props.getStringValue("CaseStatus")); } else if
		 * (props.isPropertyPresent("TC_CaseStatus")) {
		 * caseObj.setStatus(props.getStringValue("TC_CaseStatus")); }
		 */

		if (props.isPropertyPresent("CaseType")) {
			caseObj.setType(props.getStringValue("CaseType"));
		} else if (props.isPropertyPresent("TC_CaseType")) {
			caseObj.setType(props.getStringValue("TC_CaseType"));
		}

		// Hardcoded for CS solution.since it CaseType case property is N/A.
		if (props.isPropertyPresent("TC_SolutionName")) {
			if ("Client Servicing".equalsIgnoreCase(props.getStringValue("TC_SolutionName"))) {
				caseObj.setType("Inquiry Processing");
			}
		}

		// to fix duplicate segment problem
		if (props.isPropertyPresent("PO_Segment")) {
			props.removeFromCache("PO_Segment");
		} else if (props.isPropertyPresent("TO_Segment")) {
			props.removeFromCache("TO_Segment");
		}

		// For moving recievedDate from additional Identifiers to core
		// property
		if (receivedDatesConfig == null) {
			receivedDatesConfig = AppPropertiesProvider.getProperty("RECEIVED-DATE");
		}
		for (String eachReceivedDtConfig : receivedDatesConfig.split(",")) {
			if (props.isPropertyPresent(eachReceivedDtConfig)) {
				if (props.getDateTimeValue(eachReceivedDtConfig) != null) {
					String recDate = dateFormat.format(props.getDateTimeValue(eachReceivedDtConfig));
					caseObj.setRequestReceivedDate(recDate);
				}
			}
		}
		Iterator<Property> propIter = props.iterator();
		while (propIter.hasNext()) {
			Property property = propIter.next();
			String displayName = propertyInfo.get(property.getPropertyName());

			if (property instanceof PropertyStringImpl) {
				caseProperties.put(displayName, property.getStringValue());
			} else if (property instanceof PropertyDateTimeImpl) {
				caseProperties.put(displayName,
						property.getDateTimeValue() != null ? dateFormat.format(property.getDateTimeValue()) : null);
			} else if (property instanceof PropertyBooleanImpl) {
				caseProperties.put(displayName, property.getBooleanValue());
			} else if (property instanceof PropertyFloat64Impl) {
				caseProperties.put(displayName, property.getFloat64Value());
			}
		}

		// Hardcoded for CS solution.since it CaseType case property is N/A.
		if (props.isPropertyPresent("TC_SolutionName")) {
			if ("Client Servicing".equalsIgnoreCase(props.getStringValue("TC_SolutionName"))) {
				caseProperties.put("Case Type", "Inquiry Processing");
			}
		}

		if (props.isPropertyPresent("ConfirmationNumber")) {
			try {
				if (CommonConstants.IS_OPERATIONS.equalsIgnoreCase(solutionName)
						&& (dateFormat.parse(AppPropertiesProvider.getProperty(CommonConstants.IS_CASE_CREATED_DATE))
								.after(props.getDateTimeValue("DateCreated")))) {
					caseProperties.put("Confirmation #", null);
				}

			} catch (ParseException e) {
				LOG.debug("Error in converting to date");
			}
		}

		caseObj.setAdditionalIdentifiers(caseProperties);
		LOG.debug(caseObj.toString());

		return caseObj;
	}

	public HashMap<String, String> getPropertyDescription(String osName, String id) {

		ClassDescription classDescription = Factory.ClassDescription.fetchInstance(getOS(osName), id, null);

		PropertyDescriptionList propDescList = classDescription.get_PropertyDescriptions();
		Iterator<PropertyDescription> iter = propDescList.iterator();

		// key : Symbolic Name , Value : Display Name
		HashMap<String, String> propertyMap = new HashMap<String, String>();

		while (iter.hasNext()) {
			PropertyDescription propDesc = iter.next();
			if (propDesc.get_DataType() != TypeID.OBJECT) {
				propertyMap.put(propDesc.get_SymbolicName(), propDesc.get_DisplayName());
			}
		}
		return propertyMap;
	}

	@Override
	public List<Comment> getComments(String osName, String caseID) {
		LOG.debug("ContentBO.getCaseNotes()--> '" + caseID + "'");

		PropertyFilter filter = new PropertyFilter();
		filter.addIncludeProperty(1, MAX_SIZE, true, PropertyNames.ANNOTATIONS, PAGE_SIZE);
		filter.addIncludeProperty(1, MAX_SIZE, true, CommonConstants.CM_ACM_COMMENT_TEXT, PAGE_SIZE);
		filter.addIncludeProperty(1, MAX_SIZE, true, PropertyNames.CLASS_DESCRIPTION, PAGE_SIZE);
		filter.addIncludeProperty(1, MAX_SIZE, true, PropertyNames.CREATOR, PAGE_SIZE);
		filter.addIncludeProperty(1, MAX_SIZE, true, PropertyNames.CONTENT_SIZE, PAGE_SIZE);
		filter.addIncludeProperty(1, MAX_SIZE, true, PropertyNames.SYMBOLIC_NAME, PAGE_SIZE);
		filter.addIncludeProperty(1, MAX_SIZE, true, PropertyNames.DATE_CREATED, PAGE_SIZE);
		filter.addIncludeProperty(1, MAX_SIZE, true, PropertyNames.ID, PAGE_SIZE);
		filter.addIncludeProperty(1, MAX_SIZE, true, CommonConstants.CM_ACM_STEP_NAME, PAGE_SIZE);
		filter.addIncludeProperty(1, MAX_SIZE, true, CommonConstants.CM_ACM_TASK_NAME, PAGE_SIZE);
		filter.addIncludeProperty(1, MAX_SIZE, true, CommonConstants.DOCUMENT_TITLE, PAGE_SIZE);
		filter.addIncludeProperty(1, MAX_SIZE, true, CommonConstants.CM_ACM_COMMENTED_TASK, PAGE_SIZE);

		Folder caseFolder = Factory.Folder.fetchInstance(getOS(osName), caseID, filter);
		AnnotationSet annotations = caseFolder.get_Annotations();
		Iterator<Annotation> iter = annotations.iterator();

		List<Comment> notes = new ArrayList<Comment>();
		while (iter.hasNext()) {
			Annotation annotation = iter.next();
			Properties props = annotation.getProperties();
			ClassDescription classDescription = (ClassDescription) annotation.getProperties()
					.getObjectValue("ClassDescription");
			String symbolicName = classDescription.get_SymbolicName();

			Comment note = new Comment();
			LOG.debug("symbolicName of comment:" + symbolicName);
			switch (CommentType.valueOf(symbolicName)) {

			case CmAcmCaseComment:
				note.setType(CommentType.CmAcmCaseComment.getType());
				note.setDescription("Comment added to case");
				break;

			case CmAcmVersionSeriesComment:
				note.setType(CommentType.CmAcmVersionSeriesComment.getType());
				note.setDescription(
						"Comment added to document " + (props.isPropertyPresent(CommonConstants.DOCUMENT_TITLE)
								? props.getStringValue(CommonConstants.DOCUMENT_TITLE) : null));
				break;

			case CmAcmTaskComment:
				note.setType(CommentType.CmAcmTaskComment.getType());
				note.setDescription(
						"Comment added to "
								+ (props.isPropertyPresent(CommonConstants.CM_ACM_TASK_NAME)
										? props.getStringValue(CommonConstants.CM_ACM_TASK_NAME) : null)
						+ " activity.");
				break;

			case CmAcmWorkItemComment:
				note.setType(CommentType.CmAcmWorkItemComment.getType());
				note.setDescription("Comment added to "
						+ (props.isPropertyPresent(CommonConstants.CM_ACM_TASK_NAME)
								? props.getStringValue(CommonConstants.CM_ACM_TASK_NAME) : null)
						+ " for " + (props.isPropertyPresent(CommonConstants.CM_ACM_STEP_NAME)
								? props.getStringValue(CommonConstants.CM_ACM_STEP_NAME) : null));
				break;

			default:
				note.setType("Unknown");
				break;
			}

			// add the note details
			note.setComment(annotation.getProperties().getStringValue("CmAcmCommentText"));
			note.setCreatedBy(annotation.get_Creator());
			note.setCreatedOn(annotation.get_DateCreated());
			note.setId(annotation.get_Id().toString());
			LOG.debug(note.toString());
			notes.add(note);
		}
		LOG.debug("Comments Size->" + notes.size());
		return notes;
	}

	@Override
	public List<Document> getDocuments(String osName, String caseID) {
		LOG.debug("Entering getDocuments(String osName, String caseID)....");

		Folder caseFolder = Factory.Folder.fetchInstance(getOS(osName), caseID, null);
		String caseFolderPath = caseFolder.getProperties().getStringValue("PathName");
		Properties props = caseFolder.getProperties();

		String solutionName = getSolutionName(props);

		LOG.debug(String.format("Getting Documents for a case with caseID [%s] from path->[%s] ", caseID,
				caseFolderPath));
		String sqlSelect = "doc.id, doc.MimeType, doc.Name, doc.CmAcmAssociatedCase, doc.ContentElements, doc.FoldersFiledIn, doc.DateCreated, doc.Creator";

		IndependentObjectSet docSet = getDocuments(osName, caseFolderPath, sqlSelect, "doc");
		List<Document> docList = new ArrayList<Document>();

		if (!docSet.isEmpty()) {
			docList = getDocumentInfo(docSet, solutionName);
			// return docList;
		}

		LOG.debug("Got Documents from CE: " + docList.toString());
		LOG.debug("Number of documents from CE: " + docList.size());

		// Get Documents from FDRS in a list and add these documents in CE List
		CCPDocumentsDelegate ccpDocumentsDelegate = getCCPDocumentsDelegate(solutionName);
		if (null != ccpDocumentsDelegate) {

			LOG.debug("Getting CCP Documents for Solution: " + solutionName);
			List<Document> ccpDocList = ccpDocumentsDelegate.getCCPDocuments(caseID, solutionName, props);
			LOG.debug("Got CCP Documents for Solution: " + solutionName);
			docList.addAll(ccpDocList);
		}

		LOG.debug("Documents: " + docList.toString());

		LOG.debug("Total List of documents that are in the RELEASED state:" + docList.size());
		return docList;
	}

	private IndependentObjectSet getDocuments(String osName, String caseFolderPath, String searchSQL, String alias) {

		SearchSQL docSearchSQL = new SearchSQL();
		String select = searchSQL;
		docSearchSQL.setSelectList(select);
		String className = "Document"; // always OOTB base class
		docSearchSQL.setFromClauseInitialValue(className, alias, true);
		String whereClause = "doc.CmAcmAssociatedCase = Object('" + caseFolderPath + "') and doc.VersionStatus=1";
		docSearchSQL.setWhereClause(whereClause);
		LOG.debug("Doc SQL Search -->" + docSearchSQL.toString());
		SearchScope scope = new SearchScope(getOS(osName));
		DocumentSet docSet = (DocumentSet) scope.fetchObjects(docSearchSQL, PAGE_SIZE, null, new Boolean(true));

		return docSet;
	}

	/**
	 * This method fetches a specific document object properties like id,
	 * MimeType, Name, CmAcmAssociatedCase, ContentElements,FoldersFiledIn,
	 * VersionSeries for the given documentId
	 *
	 * @param osName
	 *            - ObjectStore Name
	 * @param documentId
	 *            - Document Id
	 * @param alias
	 *            - alias name for Document table
	 * @return - Document object for the given document Object Id
	 * @throws Exception
	 *
	 *
	 */
	private com.filenet.api.core.Document getDocument(String osName, String caseID, String documentId, String alias)
			throws RuntimeException, Exception {
		Folder caseFolder = Factory.Folder.fetchInstance(getOS(osName), caseID, null);
		String caseFolderPath = caseFolder.getProperties().getStringValue("PathName");
		SearchSQL docSearchSQL = new SearchSQL();
		String select = alias + ".id, " + alias + ".MimeType, " + alias + ".Name, " + alias + ".CmAcmAssociatedCase, "
				+ alias + ".ContentElements, " + alias + ".FoldersFiledIn," + alias + ".VersionSeries";
		docSearchSQL.setSelectList(select);
		String className = "Document"; // always OOTB base class
		docSearchSQL.setFromClauseInitialValue(className, alias, true);
		String whereClause = "doc.Id = ('" + documentId + "') and doc.CmAcmAssociatedCase = Object('" + caseFolderPath
				+ "')";
		docSearchSQL.setWhereClause(whereClause);
		// LOG.debug("Doc SQL Search -->" + docSearchSQL.toString());
		SearchScope scope = new SearchScope(getOS(osName));
		DocumentSet docSet = (DocumentSet) scope.fetchObjects(docSearchSQL, PAGE_SIZE, null, new Boolean(true));
		Iterator<com.filenet.api.core.Document> iterator = docSet.iterator();
		if (!iterator.hasNext()) {
			throw new RuntimeException("Not found any Document with ID:" + documentId + " in the case ID:" + caseID);
		}
		com.filenet.api.core.Document document = iterator.next();
		return getLatestVersionDoc(document);
	}

	private com.filenet.api.core.Document getLatestVersionDoc(com.filenet.api.core.Document document) {
		Properties props = document.getProperties();
		if (!props.isPropertyPresent("VersionSeries")) {
			return document;
		}

		VersionSeries versionableSeries = document.get_VersionSeries();
		com.filenet.api.core.Document latestVersionDoc = (com.filenet.api.core.Document) versionableSeries
				.get_CurrentVersion();
		return latestVersionDoc;
	}

	/**
	 * createDocument method creates a filenet Document object, creates a
	 * content Reference with a url inside it. URL refers to object in FDRS
	 * using the properties of org.tiaa.icm.client.domain.response.Document
	 * object for the given caseId and objectStore
	 *
	 * @param osName
	 *            - ObjectStore Name
	 *
	 * @param caseId
	 *            - caseId to which this document needs to be associated
	 * @param document
	 *            - org.tiaa.icm.client.domain.response.Document object with the
	 *            properties that needs to be set in filenet Document object
	 *
	 * @return com.filenet.api.core.Document
	 *
	 */

	private Folder getDocumentFolder(ObjectStore os, String caseID, Document document) {

		Folder caseFolder = Factory.Folder.fetchInstance(os, new Id(caseID), null);
		String path = caseFolder.get_PathName();

		return Factory.Folder.fetchInstance(os, path + "/" + document.getFolder(), null);

	}

	@Override
	public Id updateDocument(String osName, String caseID, Document document, String documentId)
			throws EngineRuntimeException, NullPointerException, Exception {

		VersionSeries verSeries = null;
		com.filenet.api.core.Document reservation = null;
		com.filenet.api.core.Document filenetDoc = null;
		ObjectStore os = getOS(osName);
		filenetDoc = getDocument(osName, caseID, documentId, "doc");

		ContentReference oldContentRef = (ContentReference) filenetDoc.get_ContentElements().get(0);
		String existingFDRSUrl = oldContentRef.get_ContentLocation();

		verSeries = filenetDoc.get_VersionSeries();

		Versionable version = verSeries.get_CurrentVersion();
		LOG.debug("Status of current version: " + version.get_VersionStatus().toString()
				+ "\n Number of current version: " + version.get_MajorVersionNumber() + "."
				+ version.get_MinorVersionNumber());

		verSeries.checkout(ReservationType.OBJECT_STORE_DEFAULT, null, null, null);
		verSeries.save(RefreshMode.REFRESH);

		reservation = (com.filenet.api.core.Document) verSeries.get_Reservation();

		ContentReference contentRef = Factory.ContentReference.createInstance(os);

		String fdrsUrl = createFDRSUrl(document, existingFDRSUrl);
		contentRef.set_ContentLocation(fdrsUrl);
		// contentRef.set_ContentType("text/plain");
		contentRef.set_ContentType(document.getMimeType());
		ContentElementList contentList = Factory.ContentElement.createList();
		contentList.add(contentRef);
		reservation.set_ContentElements(contentList);

		reservation.checkin(null, CheckinType.MAJOR_VERSION);
		reservation.save(RefreshMode.REFRESH);

		return filenetDoc.get_Id();

	}

	@Override
	public Id createDocument(String osName, String caseID, Document document)
			throws EngineRuntimeException, NullPointerException, Exception {

		com.filenet.api.core.Document filenetDoc = null;
		ObjectStore os = getOS(osName);

		filenetDoc = Factory.Document.createInstance(os, ClassNames.DOCUMENT);

		ContentReference contentRef = Factory.ContentReference.createInstance(os);

		String fdrsUrl = createFDRSUrl(document, null);// needs to be
														// created
		contentRef.set_ContentLocation(fdrsUrl);
		// contentRef.set_ContentType(javax.ws.rs.core.MediaType.TEXT_PLAIN);
		contentRef.set_ContentType(document.getMimeType());

		ContentElementList contentList = Factory.ContentElement.createList();
		contentList.add(contentRef);
		filenetDoc.set_ContentElements(contentList);
		filenetDoc.set_MimeType(document.getMimeType());
		filenetDoc.save(RefreshMode.NO_REFRESH);
		Properties props = filenetDoc.getProperties();
		props.putObjectValue("DocumentTitle", document.getDocumentName());

		filenetDoc.checkin(AutoClassify.DO_NOT_AUTO_CLASSIFY, CheckinType.MAJOR_VERSION);
		filenetDoc.save(RefreshMode.REFRESH);

		Folder docFolder = getDocumentFolder(os, caseID, document);

		ReferentialContainmentRelationship rcr = docFolder.file(filenetDoc, AutoUniqueName.AUTO_UNIQUE,
				document.getDocumentName(), DefineSecurityParentage.DO_NOT_DEFINE_SECURITY_PARENTAGE);

		rcr.save(RefreshMode.REFRESH);
		LOG.info("Document Created/Updated:" + filenetDoc.get_Id().toString());
		return filenetDoc.get_Id();

	}

	/**
	 * This method creates a FDRI url based on the properties in
	 * org.tiaa.icm.client.domain.response.Document object and returns the url
	 * in a string format
	 *
	 * @param document
	 *            - org.tiaa.icm.client.domain.response.Document object
	 * @return String - url
	 *
	 */

	private String createFDRSUrl(Document document, String existingFDRSUrl) throws Exception {

		// "idType", "id", "mimeType", "businessUnit", "docCode", "version"

		if (existingFDRSUrl != null) {
			document = populateExistingValues(existingFDRSUrl, document);
		}

		LOG.debug("document:" + document.toString());

		return createFdrsUrl(document);
	}

	private String createFdrsUrl(Document document) {
		String fdrs_URL = CommonConstants.FDRS_URL;
		for (String queryParam : CommonConstants.FDRS_URL_PARAMS) {
			try {
				if (queryParam.equalsIgnoreCase("driBaseURI")) {
					fdrs_URL = fdrs_URL.replace("%{driBaseURI}", fdribaseUri);
				} else if (queryParam.equalsIgnoreCase("idtype")) {
					fdrs_URL = fdrs_URL.replace("%{idType}", document.getIdtype());
				} else if (queryParam.equalsIgnoreCase("id")) {
					fdrs_URL = fdrs_URL.replace("%{id}", document.getId());
				} else if (queryParam.equalsIgnoreCase("docCode")) {
					fdrs_URL = fdrs_URL.replace("%{docCode}", document.getDocCode());
				} else if (queryParam.equalsIgnoreCase("bizUnit")) {
					fdrs_URL = fdrs_URL.replace("%{bizUnit}", document.getBusinessUnit());
				} else if (queryParam.equalsIgnoreCase("mimeType")) {
					fdrs_URL = fdrs_URL.replace("%{mimeType}", document.getMimeType());
				} else if (queryParam.equalsIgnoreCase("docName")) {
					fdrs_URL = fdrs_URL.replace("%{docName}", document.getDocumentName());
				}
			} catch (NullPointerException e) {
				throw new NullPointerException(
						"NullPointerException: " + queryParam + " cannot be null, please send a valid value");
			}
		}
		return fdrs_URL;
	}

	private Document populateExistingValues(String existingFDRSUrl, Document document) {
		for (String queryParam : CommonConstants.FDRS_URL_PARAMS) {
			System.out.println("queryParam:" + queryParam);
			if (queryParam.equals("driBaseURI")) {
				continue;
			}
			String existingValue = getValueInUrl(existingFDRSUrl, queryParam);
			LOG.debug("queryParamexistingValue:" + existingValue);

			if (queryParam.equalsIgnoreCase("idtype")) {
				String newValue = document.getIdtype();
				if (newValue == null) {
					document.setIdtype(existingValue);
				}
			} else if (queryParam.equalsIgnoreCase("docId")) {
				String newValue = document.getId();
				if (newValue == null) {
					document.setId(existingValue);
				}
			} else if (queryParam.equalsIgnoreCase("docCode")) {
				String newValue = document.getDocCode();
				if (newValue == null) {
					document.setDocCode(existingValue);
				}

			} else if (queryParam.equalsIgnoreCase("mimeType")) {
				String newValue = document.getMimeType();
				if (newValue == null) {
					document.setMimeType(existingValue);
				}
			} else if (queryParam.equalsIgnoreCase("docName")) {
				String newValue = document.getDocumentName();
				if (newValue == null) {
					document.setDocumentName(existingValue);
				}
			}
		}
		return document;
	}

	private String getValueInUrl(String fdrsURL, String paramKey) {
		String existingValue = null;
		try {

			if (paramKey.equals("docName")) {
				paramKey = "name";
			}
			int index = fdrsURL.indexOf(paramKey + "=");
			if (!paramKey.equals("formatType")) {
				String keyValue = fdrsURL.substring(index, fdrsURL.indexOf("&", index));
				existingValue = keyValue.split("=")[1];
			}
		} catch (IndexOutOfBoundsException e) {
			return null;
		}
		return existingValue;

	}

	/**
	 * addCaseComments method adds the given commentText to the caseId given in
	 * the ObjectStore - osName
	 *
	 * @param osName
	 *            - object Store Name
	 * @param caseId
	 *            - caseId to which comments needs to be applied
	 * @param commentText
	 *            - The comment Text that needs to be added to a case
	 *
	 */

	@Override
	public Id addCaseComments(String osName, String caseId, String commentText)
			throws EngineRuntimeException, NullPointerException, VWException, Exception {
		Annotation annotation = null;
		Properties props = null;

		ObjectStore os = getOS(osName);
		Folder caseFolder = Factory.Folder.fetchInstance(os, new Id(caseId), null);
		annotation = Factory.Annotation.createInstance(os, CommentType.CmAcmCaseComment.toString());
		props = annotation.getProperties();
		props.putValue(CommonConstants.CM_ACM_ACTION, 102);// case - 102
		return addComments(caseFolder, annotation, commentText);
	}

	/**
	 * addDocumentComments method adds the given commentText to the docId in the
	 * caseId given.
	 *
	 * @param osName
	 *            - object Store Name
	 * @param caseId
	 *            - caseId to which the document is associated to.
	 * @param docId
	 *            - docId to which comments needs to be applied.
	 * @param commentText
	 *            - The comment Text that needs to be added to a case.
	 * @throws Exception
	 * @throws RuntimeException
	 *
	 */

	@Override
	public Id addDocumentComments(String osName, String caseId, String docId, String commentText)
			throws RuntimeException, Exception {
		Annotation annotation = null;
		Properties props = null;

		ObjectStore os = getOS(osName);
		Folder caseFolder = Factory.Folder.fetchInstance(os, new Id(caseId), null);
		com.filenet.api.core.Document document = getDocument(osName, caseId, docId, "doc");
		annotation = Factory.Annotation.createInstance(os, CommentType.CmAcmVersionSeriesComment.toString());
		props = annotation.getProperties();

		props.putObjectValue(CommonConstants.CM_ACM_COMMENTED_VERSION_SERIES, document.get_VersionSeries());
		props.putObjectValue(CommonConstants.DOCUMENT_TITLE, document.get_Name());
		props.putValue(CommonConstants.CM_ACM_ACTION, 402);// Document - 402

		return addComments(caseFolder, annotation, commentText);

	}

	/**
	 * addStepComments method adds the given commentText to the wobId/stepId of
	 * the queueName in the caseId given for the user racfId
	 *
	 * @param osName
	 *            - object Store Name
	 * @param caseId
	 *            - caseId to which the Work Object is associated to.
	 * @param wobId
	 *            - wobId to which comments needs to be applied.
	 * @param queueName
	 *            - queueName in which the stepElement for the wobId resides.
	 * @param commentText
	 *            - The comments that needs to be added to the step.
	 * @param racfId
	 *            - the userId who gave the comments
	 * @throws VWException
	 *
	 */

	@Override
	public Id addStepComments(String osName, String caseId, String wobId, String queueName, String commentText,
			String racfId) throws EngineRuntimeException, NullPointerException, VWException, Exception {
		try {
			Annotation annotation = null;
			Properties props = null;

			ObjectStore os = getOS(osName);
			Folder caseFolder = Factory.Folder.fetchInstance(os, new Id(caseId), null);
			annotation = Factory.Annotation.createInstance(os, CommentType.CmAcmWorkItemComment.toString());

			vwSession = processBO.getVWSession();
			VWStepElement stepElement = processBO.getStepElement(queueName, wobId, racfId, vwSession);
			props = annotation.getProperties();
			// get taskId from PE
			String taskId = stepElement.fetchWorkObject(false, false).getFieldValue("F_CaseTask").toString();

			CmTask task = getTask(caseFolder, taskId);
			if (task == null) {
				throw new RuntimeException(
						"NullPointerException: Could not find task " + taskId + ", in folder:" + caseFolder);
			}
			props.putObjectValue(CommonConstants.CM_ACM_COMMENTED_TASK, task);// API_UNSUPPORTED_PROPERTY_TYPE:
			props.putObjectValue(CommonConstants.CM_ACM_TASK_NAME,
					task.getProperties().getStringValue(CommonConstants.CM_ACM_TASK_NAME));// taskName
			props.putObjectValue(CommonConstants.CM_ACM_STEP_NAME, stepElement.getStepName());

			props.putObjectValue(CommonConstants.CM_ACM_WORKFLOW_NUMBER, wobId);

			props.putObjectValue("CmAcmWorkClassName", task.get_ClassDescription().get_SymbolicName());// mandatory

			props.putValue(CommonConstants.CM_ACM_ACTION, 302);// workitem - 302
			return addComments(caseFolder, annotation, commentText);
		} finally {
			processBO.logOffSession(vwSession);
			vwSession = null;
		}

	}

	/**
	 * addTaskComments method adds the given commentText to the taskId of a
	 * case.
	 *
	 * @param osName
	 *            - object Store Name
	 * @param caseId
	 *            - caseId to which the Work Object is associated to.
	 * @param taskId
	 *            - taskId to which comments needs to be applied.
	 * @param commentText
	 *            - The comments that needs to be added to the step.
	 *
	 */

	@Override
	public Id addTaskComments(String osName, String caseId, String taskId, String commentText) {
		Annotation annotation = null;
		Properties props = null;

		ObjectStore os = getOS(osName);
		Folder caseFolder = Factory.Folder.fetchInstance(os, new Id(caseId), null);
		CmTask task = getTask(caseFolder, taskId);
		if (task == null) {
			throw new RuntimeException(
					"NullPointerException: Could not find task " + taskId + ", in folder:" + caseFolder);
		}
		annotation = Factory.Annotation.createInstance(os, CommentType.CmAcmTaskComment.toString());
		props = annotation.getProperties();
		props.putObjectValue(CommonConstants.CM_ACM_COMMENTED_TASK, task);

		props.putValue(CommonConstants.CM_ACM_ACTION, 205);//
		return addComments(caseFolder, annotation, commentText);

	}

	/**
	 * addComments saves the given annotation after setting the annotated object
	 * to the given case folder
	 *
	 * @param caseFolder
	 *            - to which the annotation needs to be associated
	 * @param annotation
	 *            - is the comment object created
	 * @param commentText
	 *            - actual comment entered by user
	 * @return Id - of the object created
	 *
	 */
	private Id addComments(Folder caseFolder, Annotation annotation, String commentText) {
		annotation.set_AnnotatedObject(caseFolder);
		annotation.getProperties().putValue(CommonConstants.CM_ACM_COMMENT_TEXT, commentText);
		annotation.save(RefreshMode.REFRESH);
		System.out.println("annotation id:" + annotation.get_Id());
		return annotation.get_Id();
	}

	/**
	 * getTask method returns a specific CmTask object for the given taskId
	 *
	 * @param caseFolder
	 *            - Folder to which the task is associated
	 * @param taskId
	 *            - Id of the task to be searched
	 * @return CmTask - the task object
	 *
	 */

	private CmTask getTask(Folder caseFolder, String taskId) {

		CmTaskSet tasks = caseFolder.get_CoordinatedTasks();
		Iterator<CmTask> taskIterator = tasks.iterator();

		while (taskIterator.hasNext()) {
			CmTask task = taskIterator.next();
			LOG.debug("taskIdFromCaseFolder:" + task.get_Id().toString() + ",taskId:" + taskId);
			if (task.get_Id().toString().equals(taskId)) {
				return task;
			}
		}
		return null;
	}

	public final IndependentObjectSet fetchObjectsBySql(String osName, String sql) throws Exception {

		SearchSQL sqlObj = new SearchSQL();
		sqlObj.setMaxRecords(10);
		sqlObj.setQueryString(sql);
		SearchScope searchScope = new SearchScope(getOS(osName));
		PropertyFilter propFilter = new PropertyFilter();
		propFilter.addIncludeProperty(6, SEARCH_MAX_SIZE, false, "ID", SEARCH_PAGE_SIZE);
		IndependentObjectSet objSet = searchScope.fetchObjects(sqlObj, 10, propFilter, false);
		return objSet;
	}

	private List<Document> getDocumentInfo(IndependentObjectSet docSet, String solutionName) {

		Iterator<com.filenet.api.core.Document> iterator = docSet.iterator();

		List<Document> docList = new ArrayList<Document>();
		// Set<Document> docList = new HashSet<Document>();

		while (iterator.hasNext()) {
			// com.filenet.api.core.Document ceDoc = iterator.next();
			// commented above line and added below two lines to get the latest
			// version document info
			com.filenet.api.core.Document filenetDoc = iterator.next();
			LOG.debug("docuemnt Id:" + filenetDoc.get_Id());
			com.filenet.api.core.Document ceDoc = getLatestVersionDoc(filenetDoc);

			ContentElementList list = ceDoc.get_ContentElements();

			String id = ceDoc.get_Id().toString();
			String idType = "Object_Id"; // Hardcoded to satify FDRS..
			String businessUnit = "PENSION";
			String docCode = "FILENET_INBOUND_DOC";
			String version = "1";
			String mimeType = ceDoc.get_MimeType();
			String docName = ceDoc.get_Name();
			String createdBy = ceDoc.get_Creator();
			Date dateCreated = ceDoc.get_DateCreated();
			String folderName = "";
			String docUrl = "";
			String formatType = FormatType.Document.toString();
			// String docInstanceId = "";

			if (ceDoc.get_FoldersFiledIn().iterator().hasNext()) {
				Folder folder = (Folder) ceDoc.get_FoldersFiledIn().iterator().next();
				ClassDescription folderClassDesc = folder.get_ClassDescription();
				if (folderClassDesc.get_Name().equalsIgnoreCase("Case Subfolder")) {
					folderName = getParentFolderName(solutionName, folder);
				}
			}

			Iterator<ContentElement> contentElementIter = list.iterator();
			while (contentElementIter.hasNext()) {
				ContentElement content = contentElementIter.next();
				// documents stored outside CM....
				if (content instanceof ContentReference) {
					id = "";
					idType = "";
					ContentReference reference = (ContentReference) content;
					String fdrsURL = reference.get_ContentLocation();

					if (fdrsURL.contains(CommonConstants.NICE)) {

						docUrl = getNiceURL(fdrsURL);
						formatType = FormatType.Voice.toString();
						mimeType = "";
						version = "";
						docCode = "";
						businessUnit = "";

					} else {
						String[] params = fdrsURL.substring(fdrsURL.indexOf("?") + 1).split("&");
						for (String queryParam : params) {
							try {
								int index = queryParam.indexOf("=") + 1;
								String param = queryParam.substring(0, queryParam.indexOf("="));
								if (param.equalsIgnoreCase("idtype")) {
									idType = queryParam.substring(index);
								} else if (param.equalsIgnoreCase("id")) {
									id = queryParam.substring(index);
								} else if (param.equalsIgnoreCase("bizUnit")) {
									businessUnit = queryParam.substring(index);
								} else if (param.equalsIgnoreCase("docCode")) {
									docCode = queryParam.substring(index);
								} else if (param.equalsIgnoreCase("version")) {
									version = queryParam.substring(index);
								} else if (param.equalsIgnoreCase("formatType")) {
									if (queryParam.substring(index).equals(FormatType.Document.toString())) {
										formatType = FormatType.Document.toString();
									} else if (queryParam.substring(index).equals(FormatType.MobiusEmail.toString())) {
										formatType = FormatType.MobiusEmail.toString();
									}

								} else if (param.equalsIgnoreCase("mimeType")) {
									try {
										mimeType = URLDecoder.decode(queryParam.substring(index), "UTF-8");
									} catch (UnsupportedEncodingException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
						LOG.debug("Content Reference-->" + reference.get_ContentLocation());
					}
				}

			}

			Document doc = new Document();
			doc.setId(id).setIdtype(idType).setDocumentName(docName).setBusinessUnit(businessUnit).setDocCode(docCode)
					.setVersion(version).setMimeType(mimeType).setFolder(folderName).setFormatType(formatType);
			doc.setDocInstanceId(filenetDoc.get_Id().toString());
			doc.setCreatedBy(createdBy);
			doc.setCreatedDate(dateFormat.format(dateCreated));
			doc.setDocUrl(docUrl);
			LOG.debug(doc.toString());
			docList.add(doc);
		}
		LOG.debug("Document set:" + docList);
		// List list = new ArrayList();
		// list.addAll(docList);
		// LOG.debug("Document List:" + list);
		return docList;
	}

	private ObjectStore getOS(String osName) {

		if (!objectStores.containsKey(osName)) {
			LOG.debug("Connecting to CE Using IIOP URL --> '" + ceEJBURI + "' with osName:" + osName);
			Connection conn = Factory.Connection.getConnection(ceEJBURI);
			Domain domain = Factory.Domain.fetchInstance(conn, null, null);
			ObjectStore os = Factory.ObjectStore.fetchInstance(domain, osName, null);
			objectStores.put(osName, os);
		}

		return objectStores.get(osName);

	}

	private String getParentFolderName(String solutionName, Folder folder) {

		boolean matchedFolder = false;
		String folderName = "";
		String configuredFolderNames = AppPropertiesProvider.getProperty(solutionName);

		if (null != configuredFolderNames) {
			String path = folder.getProperties().get("PathName").getStringValue();
			int index = path.lastIndexOf("/") + 1;
			folderName = path.substring(index, path.length());

			List<String> parentFoldersList = Arrays
					.asList(configuredFolderNames.split(CommonConstants.DELIMITER_COMMA));

			if ((null != parentFoldersList) && (parentFoldersList.size() > 0)
					&& parentFoldersList.contains(folderName)) {
				matchedFolder = true;
			}

			if (!matchedFolder) {
				folderName = folder.get_Parent().get_Name();
			}

		}

		return folderName;
	}

	@Override
	public List<Event> getHistory(String osName, String caseID, String type) {

		List<Event> events = new ArrayList<Event>();

		type = ((type == null) || type.trim().equals("")) ? CommonConstants.ALL : type;

		Folder caseFolder = Factory.Folder.fetchInstance(getOS(osName), caseID, null);

		if (caseFolder == null) {
			LOG.error("Case doesn't exist with ID->'" + caseID + "'");
			return null;
		}

		if ((type.equalsIgnoreCase(CommonConstants.ALL) || type.equalsIgnoreCase("Case"))) {
			events.addAll(new org.tiaa.icm.client.domain.spi.Case(caseFolder).getEvents());
		}

		if (!caseFolder.get_Annotations().isEmpty()
				&& (type.equalsIgnoreCase(CommonConstants.ALL) || type.equalsIgnoreCase("Comments"))) {
			events.addAll(new Comments(caseFolder.get_Annotations()).getEvents());
		}

		if (!caseFolder.get_CoordinatedTasks().isEmpty()
				&& (type.equalsIgnoreCase(CommonConstants.ALL) || type.equalsIgnoreCase("Tasks"))) {
			events.addAll(new Tasks(caseFolder.get_CoordinatedTasks()).getEvents());
		}

		if (!caseFolder.get_SubFolders().isEmpty()
				&& (type.equalsIgnoreCase(CommonConstants.ALL) || type.equalsIgnoreCase("Folders"))) {
			events.addAll(new Folders(caseFolder.get_SubFolders()).getEvents());
		}
		if ((type.equalsIgnoreCase(CommonConstants.ALL) || type.equalsIgnoreCase("Documents"))) {
			IndependentObjectSet ios = getDocuments(osName, caseFolder.get_PathName(),
					"doc.MajorVersionNumber, doc.AuditedEvents, doc.FoldersFiledIn", "doc");
			if (!ios.isEmpty()) {
				events.addAll(new Documents(ios).getEvents());

			}
		}

		Collections.sort(events);
		return events;
	}

	@Override
	public Id createTask(String osName, String caseID, String taskDisplayName, String taskType)
			throws EngineRuntimeException, NullPointerException, Exception {
		Folder caseFolder = Factory.Folder.fetchInstance(getOS(osName), caseID, null);

		// taskType = "IS_RequestReview";
		CmTask task = Factory.CmTask.createInstance(getOS(osName), taskType);
		Properties props = task.getProperties();
		task.set_Coordinator(caseFolder);
		if (taskDisplayName != null) {
			props.putValue("CmAcmTaskName", taskDisplayName);
		}
		task.save(RefreshMode.NO_REFRESH);
		task.refresh();
		// // promote 2 times to change state from
		// // WAITING_PRECONDITION-->READY-->WORKING
		task.changeState(LifecycleChangeFlags.PROMOTE);
		task.changeState(LifecycleChangeFlags.PROMOTE);
		task.save(RefreshMode.NO_REFRESH);
		task.refresh();
		return task.get_Id();

	}

	// @Override
	// public List<RelatedCase> getRelatedCases(String osName, String caseID) {
	// Folder caseFolder = null;
	// List<RelatedCase> relatedCases = new ArrayList<RelatedCase>();
	// caseFolder = Factory.Folder.fetchInstance(getOS(osName), caseID, null);
	// if (caseFolder == null) {
	// LOG.error("Case doesn't exist with ID->'" + caseID + "'");
	// return relatedCases;
	// }
	//
	// String caseId = caseFolder.get_Id().toString();
	//
	// Properties props = caseFolder.getProperties();
	// String solutionName = getSolutionName(props);
	//
	// LOG.debug("getRelatedCases solutionName:" + solutionName + ".");
	// if (CommonConstants.BROKERAGE_OPERATIONS.equalsIgnoreCase(solutionName))
	// {
	// relatedCases = relatedCasesMapper.getRelatedCasesForBO(caseId);
	// } else {
	// relatedCases = relatedCasesMapper.getRelatedCases(caseId);
	// if (CommonConstants.PAYOUT_OPERATIONS.equalsIgnoreCase(solutionName)) {
	// for (RelatedCase relatedCase : relatedCases) {
	// // if the relatedCase is a PI, get the loanId and set it in
	// // confirmation
	// if ((relatedCase.getCaseIdentifier() != null) &&
	// relatedCase.getCaseIdentifier().startsWith("PI")) {
	// String loanId = relatedCasesMapper.getLoanId(relatedCase.getCaseId());
	// LOG.debug("PI CaseId:" + relatedCase.getCaseId() + ",loan Id" + loanId);
	// relatedCase.setConfirmation(loanId);
	// LOG.debug("what is in relatedcaseList:" + relatedCase.getConfirmation());
	// }
	// }
	// }
	// }
	// return relatedCases;
	// }

	@Override
	public List<Case> getICSCasesForPlanNo(CaseSearch caseSearch, String start, String osName, Subject currentSubject) {
		LOG.debug("current subject in getICSCasesForPlanNo:::" + currentSubject);
		UserContext userContext = UserContext.get();
		userContext.pushSubject(currentSubject);
		List<Case> caseList = new ArrayList<Case>();

		try {
			SearchSQL caseSearchSQL = new SearchSQL();
			caseSearchSQL = prepareICSQuery(caseSearch);

			PropertyFilter myFilter = new PropertyFilter();
			int myFilterLevel = 1;
			myFilter.setMaxRecursion(myFilterLevel);
			myFilter.addIncludeType(new FilterElement(null, null, null, FilteredPropertyType.ANY, null));

			SearchScope scope = new SearchScope(getOS(osName));
			LOG.info("ICS CE Case Search Query for planNo just before Query:::" + caseSearchSQL.toString());

			FolderSet caseSet = (FolderSet) scope.fetchObjects(caseSearchSQL, PAGE_SIZE, myFilter, new Boolean(true));
			LOG.info("ICS CE Case Search Query for planNo after Query:::");

			if (!caseSet.isEmpty()) {
				caseList = prepareICSCaseList(caseSet, osName);
			}

			LOG.debug("ICS caseList size:::" + caseList.size());
		} catch (Exception e) {

			LOG.error("Error in getting plan numbers for :::" + e.getMessage());

		} finally {
			userContext.popSubject();
		}
		return caseList;
	}

	private List<Case> prepareICSCaseList(FolderSet caseSet, String osName) {
		List<Case> caseList = new ArrayList<Case>();
		Iterator iter = caseSet.iterator();

		while (iter.hasNext()) {
			Case icmCase = new Case();
			FolderImpl folder = (FolderImpl) iter.next();
			Properties props = folder.getProperties();
			if (folder.get_Id() != null) {
				icmCase.setId(folder.get_Id().toString());
			}

			icmCase.setType(props.getStringValue("TC_CaseType"));
			icmCase.setChannel(props.getStringValue("ICS_Channel"));

			DateFormat dateFormat = new SimpleDateFormat(CommonConstants.MMDDYYYYHHMMSS);

			icmCase.setRequestReceivedDate(dateFormat.format(props.getDateTimeValue("TC_ReceivedDate")));
			icmCase.setCreatedDate(dateFormat.format(props.getDateTimeValue("DateCreated")));
			icmCase.setModifiedDate(dateFormat.format(props.getDateTimeValue("DateLastModified")));
			icmCase.setStatus(props.getStringValue("TC_CaseStatus"));

			String planNonErisa = null;
			String planErisa = null;
			StringBuffer result = new StringBuffer();
			if (props.isPropertyPresent("ICS_PlanNumbersERISAForSearch")
					&& (props.getStringValue("ICS_PlanNumbersERISAForSearch") != null)) {
				planErisa = props.getStringValue("ICS_PlanNumbersERISAForSearch");
			}
			if (props.isPropertyPresent("ICS_PlanNumbersNonERISAForSearch")
					&& (props.getStringValue("ICS_PlanNumbersNonERISAForSearch") != null)) {
				planNonErisa = props.getStringValue("ICS_PlanNumbersNonERISAForSearch");
			}

			if (planNonErisa != null) {
				result.append(planNonErisa);
			}

			if ((planErisa != null) && (!planErisa.isEmpty())) {
				result.append(",").append(planErisa);
			}

			String finalPlan = result.toString().replaceAll(";", ",");
			icmCase.setPlan(finalPlan);

			icmCase.setConfirmation(props.getStringValue("TC_RequestID"));
			icmCase.setClientId(props.getStringValue("TC_ClientID"));

			// Solution name would be always ICS.
			icmCase.setSolution(CommonConstants.ICS);

			caseList.add(icmCase);
		}

		return caseList;
	}

	private SearchSQL prepareICSQuery(CaseSearch caseSearch) throws Exception {

		SearchSQL caseSearchSQL = new SearchSQL();

		StringBuffer sqlSelect = new StringBuffer().append(
				"Id, TC_CaseType, ICS_Channel, DateCreated, TC_ReceivedDate, TC_CaseStatus, DateLastModified, TC_RequestID,TC_ClientID,ICS_PlanNumbersERISAForSearch,ICS_PlanNumbersNonERISAForSearch, TC_SolutionName");
		caseSearchSQL.setSelectList(sqlSelect.toString());

		String className = "ICS_PlanAdmin";
		caseSearchSQL.setFromClauseInitialValue(className, null, false);

		StringBuffer whereClause = new StringBuffer();

		String clientId = caseSearch.getClientId();
		String caseType = caseSearch.getCaseType();
		String channel = caseSearch.getChannel();
		String caseStatus = caseSearch.getCaseStatus();
		String solution = caseSearch.getSolution();
		String plan = caseSearch.getPlan();
		String confirmation = caseSearch.getConfirmation();

		if (!ICMClientUtil.isEmpty(plan)) {
			whereClause.append("(ICS_PlanNumbersERISAForSearch like '%" + plan + "%'")
					.append(" or ICS_PlanNumbersNonERISAForSearch like '%" + plan + "%' )");
		}

		if (ICMClientUtil.isEmpty(plan) && !ICMClientUtil.isEmpty(solution)) {
			whereClause.append(" TC_SolutionName='" + solution + "'");
		} else if (!ICMClientUtil.isEmpty(plan) && !ICMClientUtil.isEmpty(solution)) {
			whereClause.append(" AND TC_SolutionName='" + solution + "'");
		}

		if (!ICMClientUtil.isEmpty(confirmation)) {
			whereClause.append(" AND TC_RequestID='").append(confirmation).append("'");
		}

		String from = null;
		String to = null;
		String type = null;

		if (caseSearch.getDateRange() != null) {
			from = caseSearch.getDateRange().getFrom();
			to = caseSearch.getDateRange().getTo();
			type = caseSearch.getDateRange().getType();
		}

		if (!ICMClientUtil.isEmpty(clientId)) {
			whereClause.append(" AND TC_ClientID='" + clientId + "'");
		}

		if (!ICMClientUtil.isEmpty(caseType)) {
			whereClause.append(" AND TC_CaseType='" + caseType + "' ");
		}

		if (!ICMClientUtil.isEmpty(channel)) {
			whereClause.append(" AND ICS_Channel='" + channel + "' ");
		}

		if (!ICMClientUtil.isEmpty(caseStatus)) {
			whereClause.append(" AND TC_CaseStatus='" + caseStatus + "'");
		}

		if (!ICMClientUtil.isEmpty(from) && !ICMClientUtil.isEmpty(to)) {
			String fromFormatted = ICMClientUtil.convertDateFormat(from, CommonConstants.YYYY_MM_DD,
					CommonConstants.YYYYMMDDTHHMMSSZ);

			String formattedDate = ICMClientUtil.convertDateFormat(to, CommonConstants.YYYY_MM_DD,
					CommonConstants.YYYYMMDDTHHMMSSZ);
			String toFormatted = ICMClientUtil.getEndOfDay(formattedDate, CommonConstants.YYYYMMDDTHHMMSSZ);

			if (ICMClientUtil.equals(type, "Case Creation Date")) {
				whereClause.append(" AND DateCreated >=").append(fromFormatted).append(" AND DateCreated <=")
						.append(toFormatted);
			} else if (ICMClientUtil.equals(type, "Case Modified Date")) {
				whereClause.append(" AND DateLastModified >=").append(fromFormatted).append(" AND DateLastModified <=")
						.append(toFormatted);
			} else if (ICMClientUtil.equals(type, "Request Received Date")) {
				whereClause.append(" AND TC_ReceivedDate >=").append(fromFormatted).append(" AND TC_ReceivedDate <=")
						.append(toFormatted);
			}
		}
		caseSearchSQL.setWhereClause(whereClause.toString());
		String orderField = getICSSortField(caseSearch.getSortField());
		if (!ICMClientUtil.isEmpty(orderField)) {
			caseSearchSQL.setOrderByClause(orderField);
		}
		int icsTimeOut = AppPropertiesProvider.getIntProperty("ICS-TIME-OUT");
		caseSearchSQL.setTimeLimit(icsTimeOut);
		return caseSearchSQL;
	}

	private String getICSSortField(String sortField) {
		String icsSortField = null;
		if (sortField.equalsIgnoreCase("confirmation")) {
			icsSortField = "TC_RequestID";
		} else if (sortField.equalsIgnoreCase("pin")) {
			icsSortField = "";
		} else if (sortField.equalsIgnoreCase("clientid")) {
			icsSortField = "TC_ClientID";
		} else if (sortField.equalsIgnoreCase("requestReceivedDate")
				|| sortField.equalsIgnoreCase("Request Received Date")) {
			icsSortField = "TC_ReceivedDate";
		} else if (sortField.equalsIgnoreCase("Case Modified Date")) {
			icsSortField = "DateLastModified";
		} else if (sortField.equalsIgnoreCase("Case Creation Date")) {
			icsSortField = "DateCreated";
		} else if (sortField.equalsIgnoreCase("caseType")) {
			icsSortField = "TC_CaseType";
		} else if (sortField.equalsIgnoreCase("channel")) {
			icsSortField = "ICS_Channel";
		} else if (sortField.equalsIgnoreCase("caseStatus")) {
			icsSortField = "TC_CaseStatus";
		} else if (sortField.equalsIgnoreCase("solution")) {
			icsSortField = "TC_SolutionName";
		}
		return icsSortField;

	}

	private String getSolutionName(Properties props) {

		String solutionName = "";
		if (props.isPropertyPresent("TC_SolutionName")) {
			solutionName = props.getStringValue("TC_SolutionName");
		} else if (props.isPropertyPresent("SolutionName")) {
			solutionName = props.getStringValue("SolutionName");
		}

		// If Solution Name is null then reset it to blank string
		if (ICMClientUtil.isEmpty(solutionName)) {
			solutionName = "";
		}

		return solutionName;
	}

	@Override
	public Map<String, Task> getTasks(String osName, String caseID) {
		PropertyFilter propFilter = new PropertyFilter();
		propFilter.addIncludeProperty(1, MAX_SIZE, true, PropertyNames.COORDINATED_TASKS, PAGE_SIZE);
		propFilter.addIncludeProperty(1, MAX_SIZE, true, PropertyNames.TASK_STATE, PAGE_SIZE);
		propFilter.addIncludeProperty(1, MAX_SIZE, true, PropertyNames.ID, PAGE_SIZE);
		propFilter.addIncludeProperty(1, MAX_SIZE, true, PropertyNames.NAME, PAGE_SIZE);
		propFilter.addIncludeProperty(1, MAX_SIZE, true, PropertyNames.DATE_STARTED, PAGE_SIZE);
		propFilter.addIncludeProperty(1, MAX_SIZE, true, PropertyNames.DATE_COMPLETED, PAGE_SIZE);

		Folder caseFolder = Factory.Folder.fetchInstance(getOS(osName), caseID, propFilter);
		Map<String, Task> tasksMap = new HashMap<String, Task>();
		CmTaskSet cmTaskSet = caseFolder.get_CoordinatedTasks();
		if (cmTaskSet != null) {
			Iterator<?> cmTaskSetIterator = cmTaskSet.iterator();
			while (cmTaskSetIterator.hasNext()) {
				CmTask cmTask = (CmTask) cmTaskSetIterator.next();
				int taskState = cmTask.get_TaskState().getValue();
				LOG.debug("taskId:" + cmTask.get_Id() + ",TaskName:" + cmTask.get_Name() + ",taskState:" + taskState);
				if ((taskState == TaskState.COMPLETE_AS_INT) || (taskState == TaskState.READY_AS_INT)
						|| (taskState == TaskState.WORKING_AS_INT)) {
					Task task = populateTaskDetails(cmTask);
					tasksMap.put(cmTask.get_Id().toString(), task);
				}
			}
		}
		return tasksMap;
	}

	private Task populateTaskDetails(CmTask cmTask) {
		Task task = new Task();
		task.setId(cmTask.get_Id().toString());
		task.setName(cmTask.get_Name());
		TaskState status = cmTask.get_TaskState();
		// task.setCompletedAction("" + status);
		LOG.debug("task:" + cmTask.get_Id().toString() + ",status:" + status);
		List<Status> statuses = new ArrayList<Status>();
		if (status.getValue() == TaskState.COMPLETE_AS_INT) {// Complete
			statuses.add(populateStatus(CommonConstants.STARTED.toString(), cmTask.get_DateStarted()));
			statuses.add(populateStatus(CommonConstants.COMPLETED.toString(), cmTask.get_DateCompleted()));
			task.setCompletedOn(cmTask.get_DateCompleted());
			task.setCreatedOn(cmTask.get_DateStarted());
		} else if ((status.getValue() == TaskState.READY_AS_INT) // Started
				|| (status.getValue() == TaskState.WORKING_AS_INT)) {// Working
			statuses.add(populateStatus(CommonConstants.STARTED.toString(), cmTask.get_DateStarted()));
			task.setCreatedOn(cmTask.get_DateStarted());
		}
		LOG.debug("task:" + cmTask.get_Id().toString() + ",CE Created on:" + task.getCreatedOn() + ",CE Date Completed:"
				+ cmTask.get_DateCompleted());
		task.setStatuses(statuses);

		return task;

	}

	private Status populateStatus(String state, Date statusOn) {
		Status status = new Status();
		status.setStatus(state);
		// statusBy will be overridden in CaseBean for Human tasks
		status.setStatusBy(CommonConstants.SYSTEM);
		status.setStatusOn(statusOn);
		return status;
	}

	/**
	 * Create NICE URL.
	 */
	private String getNiceURL(String url) {

		LOG.debug("Entering getNiceURL(String url)....");

		String niceURL = niceRestEndpoint + AppPropertiesProvider.getProperty("NICE_URI")
				+ CommonConstants.RECORDING_TEMPLATE;

		String[] params = url.substring(url.indexOf("?") + 1).split("&");

		for (String queryParam : params) {
			int index = queryParam.indexOf("=") + 1;
			String param = queryParam.substring(0, queryParam.indexOf("="));
			if (param.equalsIgnoreCase(CommonConstants.RACF_ID)) {
				niceURL = niceURL.replace("{racf-id}", queryParam.substring(index));
			} else if (param.equalsIgnoreCase(CommonConstants.RECORDING_DATE_TIME)) {
				niceURL = niceURL.replace("{recording-date-time}", queryParam.substring(index));
			}
		}

		LOG.debug("niceURL: " + niceURL);

		LOG.debug("Exiting getNiceURL(String url)....");

		return niceURL;

	}

	private CCPDocumentsDelegate getCCPDocumentsDelegate(String solutionName) {
		LOG.debug("Entering getCCPDocumentsDelegate(String solutionName)...");

		Map<String, CCPDocumentsDelegate> ccpDocumentsSolutionMap = ccpDocumentsConfig
				.getCCPDocumentsConfiguredSolutions();

		LOG.debug("Exiting getCCPDocumentsDelegate(String solutionName)...");
		return ccpDocumentsSolutionMap.get(solutionName);
	}

}
