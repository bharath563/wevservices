package org.tiaa.icm.client.bean;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.ibm.websphere.security.WSSecurityException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.tiaa.icm.client.bo.engine.ProcessBO;
import org.tiaa.icm.client.cache.ICMClientCache;
import org.tiaa.icm.client.cache.SolutionConfigCache;
import org.tiaa.icm.client.domain.Response;
import org.tiaa.icm.client.domain.ResponseList;
import org.tiaa.icm.client.domain.Step;
import org.tiaa.icm.client.domain.StepElementDataField;
import org.tiaa.icm.client.domain.StepList;
import org.tiaa.icm.client.utils.ICMClientUtil;

import filenet.vw.api.VWException;

public class TaskBean {

	private static Logger logger = Logger.getLogger(TaskBean.class);

	@Autowired
	private ProcessBO processBO;

	public Response completeORSaveStep(String queueName, String wobId, Step stepElement, String racfId)
			throws ParseException, Exception {

		Map<String, Object> dataFieldsMap = new HashMap<String, Object>();
		List<StepElementDataField> dataFields = stepElement.getFields();
		List<String> actions = stepElement.getAction();

		if ((actions == null) || (actions.size() != 1)) {
			throw new RuntimeException("Please ensure that 'action' has exactly one value");
		}

		if (dataFields != null) {
			for (StepElementDataField dataField : dataFields) {
				if (dataField.getType().equalsIgnoreCase("String")) {
					dataFieldsMap.put(dataField.getId(), dataField.getValue().get(0));
				} else if (dataField.getType().equalsIgnoreCase("String[]")) {
					dataFieldsMap.put(dataField.getId(), dataField.getValue().toArray());
				} else if (dataField.getType().equalsIgnoreCase("Integer")) {
					dataFieldsMap.put(dataField.getId(), Integer.parseInt(dataField.getValue().get(0)));
				} else if (dataField.getType().equalsIgnoreCase("Integer[]")) {
					List<Integer> intValues = new ArrayList<Integer>();
					for (String value : dataField.getValue()) {
						intValues.add(Integer.parseInt(value));
					}
					dataFieldsMap.put(dataField.getId(), intValues.toArray());
				} else if (dataField.getType().equalsIgnoreCase("Boolean")) {
					dataFieldsMap.put(dataField.getId(), Boolean.parseBoolean(dataField.getValue().get(0)));
				} else if (dataField.getType().equalsIgnoreCase("Boolean[]")) {
					List<Boolean> booleanValues = new ArrayList<Boolean>();
					for (String value : dataField.getValue()) {
						booleanValues.add(Boolean.parseBoolean(value));
					}
					dataFieldsMap.put(dataField.getId(), booleanValues.toArray());
				} else if (dataField.getType().equalsIgnoreCase("Time")) {
					DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa");
					Date dateValue = sdf.parse(dataField.getValue().get(0));
					dataFieldsMap.put(dataField.getId(), dateValue);
				} else if (dataField.getType().equalsIgnoreCase("Time[]")) {
					List<Date> dateValues = new ArrayList<Date>();
					DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa");
					for (String value : dataField.getValue()) {
						dateValues.add(sdf.parse(value));
					}
					dataFieldsMap.put(dataField.getId(), dateValues.toArray());
				} else if (dataField.getType().equalsIgnoreCase("Float")) {
					dataFieldsMap.put(dataField.getId(), Double.parseDouble(dataField.getValue().get(0)));
				} else if (dataField.getType().equalsIgnoreCase("Float[]")) {
					List<Double> doubleValues = new ArrayList<Double>();
					for (String value : dataField.getValue()) {
						doubleValues.add(Double.parseDouble(value));
					}
					dataFieldsMap.put(dataField.getId(), doubleValues.toArray());
				}

			}
		}

		return processBO.doAction(queueName, wobId, dataFieldsMap, actions.get(0), racfId);
	}

	public Response unlockStep(String queueName, String wobId, String racfId) {
		return processBO.unlockWorkItem(queueName, wobId, racfId);
	}

	public ResponseEntity<?> getStepDetails(String queueName, String wobID) throws VWException, Exception {
		return processBO.getStepDetails(queueName, wobID);
	}

	public Response reassignTask(String queueName, String wobId, String reassignRacfId) {
		return processBO.reassignWorkitem(queueName, wobId, reassignRacfId);
	}

	public ResponseList getSteps(String solution, String racfId, String type, String startStr)
			throws NamingException, VWException, InterruptedException, ExecutionException, WSSecurityException {

		logger.debug("Solution: " + solution);

		StepList stepList = processBO.getWorkItems(solution, racfId, type);

		Map<String, Integer> resultMap = ICMClientUtil.getStartEnd(startStr);
		int start = resultMap.get("START");
		int end = resultMap.get("END");

		/*
		 * List<Step> steps = stepList.getSteps();
		 *
		 * // Pagination logic on list of Step objects List<Step> pagedList =
		 * null; if (steps != null) { if (steps.size() >= end) { pagedList =
		 * steps.subList(start - 1, end); } else if (steps.size() >= start) {
		 * pagedList = steps.subList(start - 1, steps.size()); } }
		 *
		 * stepList.setSteps(pagedList);
		 */
		logger.debug("End Time --> " + System.currentTimeMillis());
		int size = 0;
		if (stepList.getSteps() != null) {
			size = stepList.getSteps().size();
		}
		return createResponseList(stepList, size, start);

	}

	public List<String> getSolutions(String racfId) throws NamingException, ExecutionException {
		List<String> ldaps = ICMClientCache.getLdapCache().get(racfId);
		return SolutionConfigCache.getEntitledSolutions(racfId, ldaps);
	}

	private ResponseList createResponseList(StepList stepList, int size, int start) {
		int maxSize = 0;
		if (start <= 0) {
			start = 1;
		}

		// Setting result as list of StepList object
		ResponseList responseList = new ResponseList();
		List pagedStepList = new ArrayList();
		pagedStepList.add(stepList);

		// Setting ResponseList count parameters based upon list of Step object
		List<Step> pagedList = stepList.getSteps();

		responseList.setResults(pagedStepList);
		if ((pagedList != null) && (pagedList.size() > 0)) {
			maxSize = pagedList.size();
			responseList.setTotalRecords(size);
		}
		responseList.setStart(start);
		if (maxSize > 0) {
			responseList.setEnd((start + maxSize) - 1);
		}

		logger.debug("In createResponseList - responseList:" + responseList);
		return responseList;
	}

	public ResponseList getStepsCount(String solution, String racfid)
			throws WSSecurityException, NamingException, VWException, InterruptedException, ExecutionException {
		ResponseList responseList = new ResponseList();

		responseList.setResults(processBO.getStepsCount(solution, racfid));
		return responseList;
	}
}
