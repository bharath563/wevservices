package org.tiaa.icm.client.bo.engine;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.naming.NamingException;
import javax.security.auth.Subject;

import org.apache.log4j.Logger;

import com.ibm.websphere.security.WSSecurityException;
import com.ibm.websphere.security.auth.WSSubject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.tiaa.icm.client.bo.util.ResponseUtil;
import org.tiaa.icm.client.cache.ICMClientCache;
import org.tiaa.icm.client.cache.SolutionConfigCache;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Response;
import org.tiaa.icm.client.domain.Status;
import org.tiaa.icm.client.domain.Step;
import org.tiaa.icm.client.domain.StepElementDataField;
import org.tiaa.icm.client.domain.StepList;
import org.tiaa.icm.client.domain.entitlement.OperationalRole;
import org.tiaa.icm.client.domain.entitlement.Properties;
import org.tiaa.icm.client.entitlement.BaseSolution;
import org.tiaa.icm.client.entitlement.IPSSolution;
import org.tiaa.icm.client.executor.GetStepParallel;
import org.tiaa.icm.client.executor.StepCountForQueue;
import org.tiaa.icm.client.provider.AppPropertiesProvider;
import org.tiaa.icm.client.spi.fnet.IProcessEngine;

import filenet.vw.api.VWException;
import filenet.vw.api.VWFetchType;
import filenet.vw.api.VWFieldType;
import filenet.vw.api.VWModeType;
import filenet.vw.api.VWParameter;
import filenet.vw.api.VWQueue;
import filenet.vw.api.VWQueueQuery;
import filenet.vw.api.VWSession;
import filenet.vw.api.VWStepElement;
import filenet.vw.api.VWUserInfo;
import filenet.vw.api.VWWorkObject;

/**
 * This class contains APIs to perform PE operations.
 *
 * @author awasts
 *
 */
public class ProcessBO implements IProcessEngine {
	private static Logger logger = Logger.getLogger(ProcessBO.class);

	@Value("${ceIIOPBootStrapUrl}")
	private String ceEJBURI;

	@Value("${connectionPoint}")
	private String connectionPoint;

	@Autowired
	private ResponseUtil responseUtil;

	private VWSession vwSession = null;

	@Autowired
	private BaseSolution baseSolution;

	@Autowired
	private IPSSolution ipsSolution;

	/**
	 * returns vwSession based upon connectionPoint
	 *
	 * @return
	 * @throws VWException
	 */
	public VWSession getVWSession() throws VWException {
		return new VWSession(connectionPoint);
	}

	/**
	 * Performs action on Step Element and saves updated data fields
	 *
	 * @param queueName
	 * @param wobID
	 * @param dataFields
	 * @param action
	 * @param vwSession
	 * @return response object
	 *
	 */
	@Override
	public Response doAction(String queueName, String wobID, Map<String, Object> dataFields, String action,
			String racfID) {

		try {
			vwSession = getVWSession();
			VWUserInfo user = vwSession.fetchCurrentUserInfo();
			logger.debug("User --> " + user.getName());
			VWStepElement stepElement = getStepElement(queueName, wobID, racfID, vwSession);
			if (stepElement != null) {
				stepElement.doLock(true);
				logger.debug("Racf iD ---> " + racfID);
				logger.debug("Step Element racf id -->" + stepElement.fetchWorkObject(false, false).getLockedUser());
				for (Map.Entry<String, Object> dataField : dataFields.entrySet()) {
					String dataFieldName = dataField.getKey();

					// Update data field only if it is in read-write mode
					if (stepElement.getParameter(dataFieldName).getMode() == 3) {
						stepElement.setParameterValue(dataField.getKey(), dataField.getValue(), true);
					}
				}
				if (action.equalsIgnoreCase("None")) {
					logger.debug("Save Work Item of Wob ID --> " + wobID);
					stepElement.doSave(true);
				} else if (action.equalsIgnoreCase("Save")) {
					logger.debug("Save Work Item of Wob ID --> " + wobID);
					stepElement.doSave(false);
				} else {
					logger.debug("Action on Work Item of Wob ID --> " + wobID);
					stepElement.setSelectedResponse(action);
					stepElement.doDispatch();
				}
			} else {
				throw new RuntimeException("StepElement is not found of " + wobID + " for Queue: " + queueName);
			}
			return responseUtil.createSuccessResponse(null);

		} catch (VWException ex) {
			return responseUtil.createFailureResponse(ex);
		} catch (NullPointerException npe) {
			return responseUtil.createFailureResponse(npe);
		} catch (Exception e) {
			return responseUtil.createFailureResponse(e);
		} finally {
			logOffSession(vwSession);
			vwSession = null;
		}
	}

	/**
	 * Unlocks locked work item
	 *
	 * @param queueName
	 * @param wobID
	 * @param racfID
	 * @param vwSession
	 * @return response object
	 *
	 */
	@Override
	public Response unlockWorkItem(String queueName, String wobID, String racfID) {
		VWStepElement stepElement;
		try {
			vwSession = getVWSession();
			stepElement = getStepElement(queueName, wobID, racfID, vwSession);

			if (stepElement != null) {
				VWWorkObject wo = stepElement.fetchWorkObject(false, false);
				if (wo.fetchLockedStatus() > 0) {
					wo.doSave(true);
				}
			} else {
				throw new RuntimeException("StepElement is not found of " + wobID + " for Queue: " + queueName);
			}
			return responseUtil.createSuccessResponse(null);
		} catch (VWException ex) {
			return responseUtil.createFailureResponse(ex);
		} catch (NullPointerException npe) {
			return responseUtil.createFailureResponse(npe);
		} catch (Exception e) {
			return responseUtil.createFailureResponse(e);
		} finally {
			logOffSession(vwSession);
			vwSession = null;
		}
	}

	/**
	 * returns query elements based upon the filter criteria on work object id
	 *
	 * @param queueName
	 * @param wobID
	 * @param vwSession
	 * @return VWQueueQuery
	 *
	 */
	@Override
	public VWQueueQuery getVWQueueQuery(String queueName, String wobID, VWSession vwSession) throws VWException {
		String filter = "F_WobNum = '" + wobID + "'";
		int queryFlags = VWQueue.QUERY_READ_BOUND + VWQueue.QUERY_READ_LOCKED;
		int fetchType = VWFetchType.FETCH_TYPE_WORKOBJECT;

		VWQueueQuery vwQuery = null;

		if (vwSession != null) {
			VWQueue queue = vwSession.getQueue(queueName);
			vwQuery = queue.createQuery(null, null, null, queryFlags, filter, null, fetchType);
			logger.debug("Fetch Count " + vwQuery.fetchCount());
		}
		return vwQuery;
	}

	/**
	 * returns StepElement based upon queue name and work object id
	 *
	 * @param queueName
	 * @param wobID
	 * @param racfID
	 * @param vwSession
	 * @return VWStepElement
	 *
	 */
	@Override
	public VWStepElement getStepElement(String queueName, String wobID, String racfID, VWSession vwSession)
			throws VWException, Exception {
		VWStepElement stepElement = null;
		VWQueueQuery vwQuery = getVWQueueQuery(queueName, wobID, vwSession);

		if ((vwQuery == null) || (vwQuery.fetchCount() == 0)) {
			throw new RuntimeException("Work Item is not found of Wob ID : " + wobID + " for Queue: " + queueName);
		}
		while (vwQuery.hasNext()) {
			VWWorkObject wo = (VWWorkObject) vwQuery.next();

			if ((wo.fetchLockedStatus() == 0)
					|| ((wo.fetchLockedStatus() > 0) && wo.getLockedUser().equalsIgnoreCase(racfID))) {
				stepElement = wo.fetchStepElement();
			} else {
				throw new RuntimeException("Work Item is locked by other user.");
			}
		}
		return stepElement;
	}

	/**
	 * returns Step Details based upon queue name and work object id
	 *
	 * @param queueName
	 * @param wobID
	 * @param vwSession
	 * @return Step
	 *
	 */
	@Override
	public ResponseEntity<?> getStepDetails(String queueName, String wobID) throws VWException, Exception {
		try {
			vwSession = getVWSession();
			VWUserInfo user = vwSession.fetchCurrentUserInfo();
			logger.debug("User --> " + user.getName());
			VWQueueQuery vwQuery = getVWQueueQuery(queueName, wobID, vwSession);
			VWStepElement stepElement = null;
			Step step = new Step();
			if ((vwQuery == null) || (vwQuery.fetchCount() == 0)) {
				return new ResponseEntity(HttpStatus.NOT_FOUND);
			}

			// this for getting case properties from Cache
			Map<String, String> solutionProperties = new HashMap<String, String>();
			while (vwQuery.hasNext()) {

				VWWorkObject wo = (VWWorkObject) vwQuery.next();
				// for getting properties from Cache
				if (solutionProperties.isEmpty() && wo.hasFieldName("SolutionIdentifier")) {
					String solutionIdentifier = null;
					solutionIdentifier = (String) wo.getFieldValue("SolutionIdentifier");
					if (solutionIdentifier != null) {
						Map<String, Map<String, String>> caseProperties = SolutionConfigCache.getCaseProperties();
						solutionProperties = caseProperties.get(solutionIdentifier);
					}
				}

				stepElement = wo.fetchStepElement();
				String[] dataFieldNames = stepElement.getParameterNames();
				boolean locked = wo.fetchLockedStatus() > 0 ? true : false;
				step.setCaseId(wo.getFieldValue("F_CaseFolder").toString());
				step.setTaskId(wo.getFieldValue("F_CaseTask").toString());

				// If workitem is not locked, lock the workitem
				if (!locked) {
					wo.doLock(false);
					wo.doSave(false);
				}

				step.setWobId(wobID);

				step.setLocked(true);
				step.setLockedby(wo.getLockedUser());

				Status status = new Status();
				if (wo.hasFieldName(CommonConstants.STEP_STATUS)) {
					status.setStatus((String) wo.getFieldValue(CommonConstants.STEP_STATUS));
				} else if (wo.hasFieldName("StepActionStatus")) {
					status.setStatus((String) wo.getFieldValue("StepActionStatus"));
				}
				step.setStatus(status);

				List<StepElementDataField> dataFields = new ArrayList<StepElementDataField>();

				// set stepName and Subject
				if (wo.hasFieldName("F_StepName")) {
					List<String> valuelist = new ArrayList<String>();
					valuelist.add((String) wo.getFieldValue("F_StepName"));
					dataFields.add(createStepElementDataFld("F_StepName", "Step Name", "String", "Read", valuelist));
				}

				if (wo.hasFieldName("F_Subject")) {
					List<String> valuelist = new ArrayList<String>();
					valuelist.add((String) wo.getFieldValue("F_Subject"));
					dataFields.add(createStepElementDataFld("F_Subject", "Subject", "String", "Read", valuelist));
				}

				step.setAction(Arrays.asList(stepElement.getStepResponses()));

				List<String> fieldNamesNotToBeIncluded = new ArrayList<String>();
				fieldNamesNotToBeIncluded.add("F_Comment");
				fieldNamesNotToBeIncluded.add("F_Responses");
				fieldNamesNotToBeIncluded.add("F_Subject");

				for (String dataFieldName : dataFieldNames) {
					if (fieldNamesNotToBeIncluded.contains(dataFieldName)) {
						continue;
					}
					StepElementDataField dataField = new StepElementDataField();
					VWParameter parameter = stepElement.getParameter(dataFieldName);

					// ID is symbolic Name
					dataField.setId(parameter.getName());

					if ((solutionProperties != null) && (solutionProperties.get(parameter.getName()) != null)
							&& (!solutionProperties.get(parameter.getName()).trim().equalsIgnoreCase(""))) {
						dataField.setName(solutionProperties.get(parameter.getName()));
						// } else if (parameter.getDescription() != null) {
						// dataField.setName(parameter.getDescription());
					} else {
						dataField.setName(parameter.getName());
					}

					// Sending Mode type's String Name
					dataField.setMode(VWModeType.getLocalizedString(parameter.getMode()));
					List<String> values = new ArrayList<String>();
					if (parameter.isArray()) {
						if (parameter.getValue() instanceof String[]) {
							dataField.setType("String[]");
							String[] fieldValues = (String[]) parameter.getValue();
							values.addAll(Arrays.asList(fieldValues));
						} else if (parameter.getValue() instanceof Integer[]) {
							dataField.setType("Integer[]");
							Integer[] intValues = (Integer[]) parameter.getValue();
							for (Integer intValue : intValues) {
								values.add(intValue.toString());
							}
						} else if (parameter.getValue() instanceof Boolean[]) {
							dataField.setType("Boolean[]");
							Boolean[] booleanValues = (Boolean[]) parameter.getValue();
							for (Boolean booleanValue : booleanValues) {
								values.add(booleanValue.toString());
							}
						} else if (parameter.getValue() instanceof Date[]) {
							dataField.setType("Time[]");
							Date[] dateValues = (Date[]) parameter.getValue();
							for (Date dateValue : dateValues) {
								values.add(formatDateToString(dateValue));
							}
						} else if ((parameter.getValue() instanceof Float[])
								|| (parameter.getValue() instanceof Double[])
								|| (parameter.getValue() instanceof Long[])) {
							dataField.setType("Float[]");
							Double[] floatValues = (Double[]) parameter.getValue();
							for (Double floatValue : floatValues) {
								values.add(floatValue.toString());
							}
						}

					} else {
						if (parameter.getValue() instanceof String) {
							dataField.setType("String");
							values.add(parameter.getValue().toString());
						} else if (parameter.getValue() instanceof Integer) {
							dataField.setType("Integer");
							values.add(parameter.getValue().toString());
						} else if (parameter.getValue() instanceof Boolean) {
							dataField.setType("Boolean");
							values.add(parameter.getValue().toString());
						} else if (parameter.getValue() instanceof Date) {
							dataField.setType("Time");
							values.add(formatDateToString((Date) parameter.getValue()));
						} else if ((parameter.getValue() instanceof Float) || (parameter.getValue() instanceof Double)
								|| (parameter.getValue() instanceof Long)) {
							dataField.setType("Float");
							values.add(parameter.getValue().toString());
						} else {
							dataField.setType(VWFieldType.getLocalizedString(parameter.getFieldType()));
							values.add(parameter.getStringValue());
						}

					}
					dataField.setValue(values);
					dataFields.add(dataField);
				}

				step.setFields(dataFields);
			}
			return new ResponseEntity(step, HttpStatus.OK);
			// return step;
		} finally {
			logOffSession(vwSession);
			vwSession = null;
		}
	}

	private StepElementDataField createStepElementDataFld(String id, String name, String type, String mode,
			List<String> valueList) {
		StepElementDataField stepElementDataField = new StepElementDataField();
		stepElementDataField.setId(id);
		stepElementDataField.setName(name);
		stepElementDataField.setType(type);
		stepElementDataField.setMode(mode);

		stepElementDataField.setValue(valueList);
		return stepElementDataField;
	}

	/**
	 * reassign work item to other participant
	 *
	 * @param queueName
	 * @param wobID
	 * @param racfID
	 * @param participantRacfID
	 * @param vwSession
	 * @return ICMClientResponse
	 *
	 */
	@Override
	public Response reassignWorkitem(String queueName, String wobID, String reassignRacfId) {

		try {
			vwSession = getVWSession();
			VWQueueQuery vwQuery = getVWQueueQuery(queueName, wobID, vwSession);

			if ((vwQuery == null) || (vwQuery.fetchCount() == 0)) {
				throw new RuntimeException("Work Item is not found of Wob ID : " + wobID + " for Queue: " + queueName);
			}
			while (vwQuery.hasNext()) {
				VWWorkObject wo = (VWWorkObject) vwQuery.next();
				VWStepElement stepElement = wo.fetchStepElement();
				stepElement.doLock(false);
				stepElement.doReassign(reassignRacfId, false, null);
				stepElement.doAbort();
			}
			return responseUtil.createSuccessResponse(null);
		} catch (VWException ex) {
			return responseUtil.createFailureResponse(ex);
		} catch (NullPointerException npe) {
			return responseUtil.createFailureResponse(npe);
		} catch (Exception e) {
			return responseUtil.createFailureResponse(e);
		} finally {
			logOffSession(vwSession);
			vwSession = null;
		}
	}

	/**
	 * returns work items of a user based upon the type (unassigned, pended, my
	 * inbox)
	 *
	 * @param solution
	 * @param racfId
	 * @param type
	 * @param vwSession
	 * @return StepList
	 * @throws WSSecurityException
	 *
	 */
	@Override
	public StepList getWorkItems(String solution, String racfId, String workitemType)
			throws NamingException, VWException, InterruptedException, ExecutionException, WSSecurityException {

		vwSession = getVWSession();
		List<Step> steps = new ArrayList<Step>();

		List<OperationalRole> roles = getRoles(solution, racfId, workitemType);

		StepList stepList = new StepList();
		Map<String, Properties> columns = getColumns(solution, workitemType);

		// stepList.setColumns(displayNames);

		logger.debug("Headers -->" + columns);
		if ((roles != null) && (!roles.isEmpty())) {

			// Using executor to fetch steps from different queues/filters
			// parallel
			ExecutorService executor = null;
			try {
				List<GetStepParallel> tasks = new ArrayList<GetStepParallel>();
				// Creating Map to have unique filter and queue name pair to
				// avoid duplicate steps
				Map<String, Set<String>> uniqueQueueFilters = getUniqueQueueFilters(roles);

				// Getting current subject to push to new threads
				Subject currentSubject = WSSubject.getCallerSubject();
				// Subject currentSubject = UserContext.get().getSubject();

				logger.info("Subject -->" + currentSubject);
				logger.info("Principal -->" + WSSubject.getCallerPrincipal());

				for (String filter : uniqueQueueFilters.keySet()) {
					Set<String> queues = uniqueQueueFilters.get(filter);
					for (String queueName : queues) {
						logger.info("Queue:" + queueName + " and Filter: " + filter + ", workitemType:" + workitemType);
						GetStepParallel task = new GetStepParallel(queueName, filter, columns, vwSession,
								currentSubject, workitemType);
						tasks.add(task);
					}
				}

				logger.debug("Time before Executor --> " + System.currentTimeMillis());
				executor = Executors.newFixedThreadPool(tasks.size());
				List<Future<List<Step>>> results = executor.invokeAll(tasks);
				for (Future<List<Step>> future : results) {
					steps.addAll(future.get());
				}
				logger.debug("Time after Executor --> " + System.currentTimeMillis());
			} finally {
				if (executor != null) {
					executor.shutdown();
				}
				logOffSession(vwSession);
			}

		}

		stepList.setSteps(steps);

		return stepList;
	}

	public Map<String, Map<String, Integer>> getStepsCount(String solution, String racfId)
			throws NamingException, VWException, InterruptedException, ExecutionException, WSSecurityException {
		Map<String, Map<String, Integer>> workItemTypeCounts = new HashMap<String, Map<String, Integer>>();
		try {
			vwSession = getVWSession();
			String[] workItemTypes = CommonConstants.WORKITEMTYPES;
			if ((solution != null) && CommonConstants.IS_OPERATIONS.equalsIgnoreCase(solution)) {
				workItemTypes = CommonConstants.WORKITEMTYPES_2;
			}

			for (String workItemType : workItemTypes) {
				Integer totalCount = 0;
				Integer awakeCount = 0;
				List<OperationalRole> roles = getRoles(solution, racfId, workItemType);
				Map<String, Integer> workItemTypeCount = new HashMap<String, Integer>();

				if ((roles != null) && (!roles.isEmpty())) {
					ExecutorService executor = null;
					try {
						List<StepCountForQueue> stepCount = new ArrayList<StepCountForQueue>();
						Map<String, Set<String>> uniqueQueueFilters = getUniqueQueueFilters(roles);

						Subject currentSubject = WSSubject.getCallerSubject();
						// Subject currentSubject =
						// UserContext.get().getSubject();
						logger.info("Subject -->" + currentSubject);
						logger.info("Principal -->" + WSSubject.getCallerPrincipal());

						for (String filter : uniqueQueueFilters.keySet()) {
							Set<String> queues = uniqueQueueFilters.get(filter);
							for (String queueName : queues) {
								StepCountForQueue stepCountMap = new StepCountForQueue(queueName, filter, vwSession,
										currentSubject, workItemType);
								stepCount.add(stepCountMap);
							}
						}

						logger.debug("Time before Executor --> " + System.currentTimeMillis());
						executor = Executors.newFixedThreadPool(
								Integer.parseInt(AppPropertiesProvider.getProperty("maxThreadPoolSize")));
						List<Future<Map<String, Integer>>> results = executor.invokeAll(stepCount);
						if (results != null) {
							for (Future<Map<String, Integer>> countsReceived : results) {
								if ((countsReceived != null) && (countsReceived.get() != null)) {
									Map<String, Integer> queueCountMap = countsReceived.get();
									for (String queueName : queueCountMap.keySet()) {
										if (queueName.equalsIgnoreCase(CommonConstants.AWAKE_TODAY)) {
											logger.debug("awakeToday queueName:" + queueName + ", Count:"
													+ queueCountMap.get(queueName));
											awakeCount = awakeCount + queueCountMap.get(queueName);
										} else {
											totalCount = totalCount + queueCountMap.get(queueName);
										}
									}
								}
							}
						}
						logger.debug("Time after Executor --> " + System.currentTimeMillis());
						workItemTypeCount.put("TotalCount", totalCount);
						if ("pended".equalsIgnoreCase(workItemType)) {
							workItemTypeCount.put(CommonConstants.AWAKE_TODAY, awakeCount);
						}

					} finally {
						if (executor != null) {
							executor.shutdown();
						}
					}
				}

				workItemTypeCounts.put(workItemType, workItemTypeCount);
			}

		} catch (Exception e) {
			logger.error(
					"Exception while getting total counts for solution:" + solution + ", exception :" + e.getMessage());
		} finally {
			logOffSession(vwSession);
		}
		return workItemTypeCounts;
	}

	private Map<String, Set<String>> getUniqueQueueFilters(List<OperationalRole> roles) {
		Map<String, Set<String>> uniqueQueueFilters = new HashMap<String, Set<String>>();

		for (OperationalRole role : roles) {
			List<String> queueNames = role.getQueueNames();
			for (String queueName : queueNames) {
				Set<String> uniqueQueues = new HashSet<String>();
				if (uniqueQueueFilters.containsKey(role.getFilters())) {
					uniqueQueues = uniqueQueueFilters.get(role.getFilters());
				}
				uniqueQueues.add(queueName);
				uniqueQueueFilters.put(role.getFilters(), uniqueQueues);

			}
		}
		return uniqueQueueFilters;
	}

	private Map<String, Properties> getColumns(String solution, String workitemType) {
		// My Work Items will have same headers as for unassigned work items
		Map<String, Properties> columns;
		if (workitemType.equalsIgnoreCase(CommonConstants.MY_WORK_ITEM)
				|| workitemType.equalsIgnoreCase(CommonConstants.UNASSIGNED_WORK_ITEM)) {
			columns = SolutionConfigCache.getHeaders(solution, CommonConstants.UNASSIGNED_WORK_ITEM);
		} else {
			columns = SolutionConfigCache.getHeaders(solution, workitemType);
		}
		// setting display names to columns instead of symbolic names
		List<String> displayNames = new ArrayList<String>();
		for (Map.Entry<String, Properties> entry : columns.entrySet()) {
			Properties headerDetails = entry.getValue();
			String displayName = headerDetails.getDisplayName();
			displayNames.add(displayName);
		}
		return columns;
	}

	private List<OperationalRole> getRoles(String solution, String racfId, String workitemType)
			throws VWException, NamingException, ExecutionException {
		List<OperationalRole> roles = new ArrayList<OperationalRole>();
		// List<String> columns = new ArrayList<String>();
		Map<String, Properties> columns = new HashMap<String, Properties>();

		/*
		 * For MyWorkItems work items, queue and filter will be same for all
		 * solutions so these work items are not the part of json configuration.
		 *
		 * AllAssigned workitems have the same filter as Unassigned +
		 * solutionIdentifier queueName would be Inbox(0)
		 */
		if (workitemType.equalsIgnoreCase(CommonConstants.MY_WORK_ITEM)) {
			int userId = vwSession.convertUserNameToId(racfId);
			OperationalRole queueFilterForInbox = new OperationalRole();
			List<String> queuesNames = new ArrayList<String>();
			queuesNames.add("Inbox(0)");
			queueFilterForInbox.setQueueNames(queuesNames);
			String filter = "F_BoundUser = " + userId + " AND solutionIdentifier = '"
					+ SolutionConfigCache.getAllAssignedFilter(solution) + "'";
			queueFilterForInbox.setFilters(filter);
			roles.add(queueFilterForInbox);
		} else if (workitemType.equalsIgnoreCase(CommonConstants.ALL_ASSIGNED_WORK_ITEM)) {
			List<String> ldaps = ICMClientCache.getLdapCache().get(racfId);

			/*
			 * List<OperationalRole> operationalRoles =
			 * baseSolution.getUserEntitledRoles(racfId, solution,
			 * ldaps,CommonConstants.UNASSIGNED_WORK_ITEM); List<String>
			 * queuesNames = new ArrayList<String>();
			 * queuesNames.add("Inbox(0)");
			 *
			 * for (OperationalRole role : operationalRoles) {
			 *
			 * // All Assigned is only for Queue Manager if ((role.getRoleName()
			 * != null) && role.getRoleName().startsWith("Queue Manager")) {
			 * roles.add(role); role.setQueueNames(queuesNames);
			 * role.setFilters(role.getFilters() + " AND solutionIdentifier = '"
			 * + SolutionConfigCache.getAllAssignedQMFilter(solution, racfId,
			 * ldaps)); } }
			 */

			roles.addAll(
					baseSolution.getUserEntitledRoles(racfId, solution, ldaps, CommonConstants.ALL_ASSIGNED_WORK_ITEM));

		} else {
			List<String> ldaps = ICMClientCache.getLdapCache().get(racfId);
			if (solution.equalsIgnoreCase("Imaging Portfolio Services")) {
				// for ips filters configuration from table data based on racfid
				roles.addAll(ipsSolution.getUserEntitledRoles(racfId, solution, ldaps, workitemType));
			} else {
				roles.addAll(baseSolution.getUserEntitledRoles(racfId, solution, ldaps, workitemType));
			}
		}
		return roles;
	}

	private String formatDateToString(Date dt) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/d/yyyy hh:mm:ss aa");
		return sdf.format(dt);
	}

	/**
	 * logs off VWSession
	 *
	 * @param vwSession
	 */
	public void logOffSession(VWSession vwSession) {
		if (vwSession != null) {
			try {
				vwSession.logoff();
			} catch (VWException e) {
				vwSession = null;
				e.printStackTrace();
			}
		}
	}

}
