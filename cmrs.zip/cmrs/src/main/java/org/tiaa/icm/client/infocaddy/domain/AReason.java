package org.tiaa.icm.client.infocaddy.domain;

import java.sql.Timestamp;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import org.apache.ibatis.type.Alias;

import org.tiaa.icm.report.util.JsonUtilReport;

@Alias("aReason")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class AReason {

	String reasonSqn;
	String id;
	String reasonTxt;
	Timestamp reasonTS;
	String reasonAT;
	Timestamp updatedTS;
	String reasonSetName;
	String reasonSrc;
	String stepActionTakenBy;
	private Map<String, List<Reason>> reasonsMap;

	public AReason() {
	}

	public AReason(String id, String reasonTxt) {
		this.reasonSqn = UUID.randomUUID().toString();
		this.id = id;
		this.reasonTxt = reasonTxt;
		this.reasonAT = JsonUtilReport.formatDate(new Date());
	}

	public AReason(String reasonSqn, String id, String reasonTxt, String reasonAT) {
		this.reasonSqn = reasonSqn;
		this.id = id;
		this.reasonTxt = reasonTxt;
		this.reasonAT = reasonAT;
	}

	public String getReasonSqn() {
		return this.reasonSqn;
	}

	public void setReasonSqn(String reasonSqn) {
		this.reasonSqn = reasonSqn;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getReasonTxt() {
		return this.reasonTxt;
	}

	public void setReasonTxt(String reasonTxt) {
		this.reasonTxt = reasonTxt;
	}

	public Timestamp getReasonTS() {
		return this.reasonTS;
	}

	public void setReasonTS(Timestamp reasonTS) {
		this.reasonTS = reasonTS;
	}

	public String getReasonAT() {
		return this.reasonAT;
	}

	public void setReasonAT(String reasonAT) {
		this.reasonAT = reasonAT;
	}

	public Timestamp getUpdatedTS() {
		return this.updatedTS;
	}

	public void setUpdatedTS(Timestamp updatedTS) {
		this.updatedTS = updatedTS;
	}

	/**
	 * @return the reasonSrc
	 */
	public String getReasonSrc() {
		return this.reasonSrc;
	}

	/**
	 * @param reasonSrc
	 *            the reasonSrc to set
	 */
	public void setReasonSrc(String reasonSrc) {
		this.reasonSrc = reasonSrc;
	}

	/**
	 * @return the reasonSetName
	 */
	public String getReasonSetName() {
		return this.reasonSetName;
	}

	/**
	 * @param reasonSetName
	 *            the reasonSetName to set
	 */
	public void setReasonSetName(String reasonSetName) {
		this.reasonSetName = reasonSetName;
	}

	public String getStepActionTakenBy() {
		return this.stepActionTakenBy;
	}

	public void setStepActionTakenBy(String stepActionTakenBy) {
		this.stepActionTakenBy = stepActionTakenBy;
	}

	public Map<String, List<Reason>> getReasonsMap() {
		if (this.reasonsMap == null) {
			this.reasonsMap = new LinkedHashMap<String, List<Reason>>();
		}
		return this.reasonsMap;
	}
}
