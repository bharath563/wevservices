package org.tiaa.icm.client.infocaddy.domain;

public class Reason {

	public Reason() {

	}

	public Reason(String reason) {
		this.reason = reason;
	}

	public Reason(String question, String answer) {
		this.reason = question + " " + answer;
	}

	String reason;

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
}
