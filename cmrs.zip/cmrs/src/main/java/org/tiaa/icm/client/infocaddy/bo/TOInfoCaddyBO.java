package org.tiaa.icm.client.infocaddy.bo;

import static org.tiaa.icm.client.infocaddy.utils.InfoCaddyUtil.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import org.tiaa.icm.client.infocaddy.constant.InfoCaddyConstant;
import org.tiaa.icm.client.infocaddy.domain.ANigo;
import org.tiaa.icm.client.infocaddy.domain.AQuestion;
import org.tiaa.icm.client.infocaddy.domain.AReason;
import org.tiaa.icm.client.infocaddy.domain.Reason;
import org.tiaa.icm.client.infocaddy.json.NigoInfo;
import org.tiaa.icm.client.infocaddy.json.Type;
import org.tiaa.icm.client.infocaddy.mapper.ANigoMapper;
import org.tiaa.icm.client.infocaddy.mapper.AQuestionMapper;
import org.tiaa.icm.client.infocaddy.mapper.AReasonMapper;
import org.tiaa.icm.client.infocaddy.utils.InfoCaddyUtil;
import org.tiaa.icm.client.rest.InfoCaddyService;
import org.tiaa.icm.client.utils.ICMClientUtil;

@Repository(value = "toInfoCaddyBO")
public class TOInfoCaddyBO implements InfoCaddyBODelegate {

	private final Logger logger = Logger.getLogger(TOInfoCaddyBO.class);

	@Autowired
	private AReasonMapper reasonsMapper;

	@Autowired
	private ANigoMapper nigoMapper;

	@Autowired
	private AQuestionMapper questionsMapper;

	@Autowired
	private InfoCaddyService infoCaddyService;

	private ObjectMapper objectMapper = new ObjectMapper();

	public String formatDate(Date dt) {

		if (dt == null) {
			return "";
		} else {
			SimpleDateFormat sdf = new SimpleDateFormat(InfoCaddyConstant.DISPLAY_DATE_FORMAT);
			return sdf.format(dt);
		}
	}

	private List<NigoInfo> fetchNIGOHistoryWithQnAReasons(String caseId, String entitySequence) {

		logger.debug("Entering fetchNIGOHistoryWithQnAReasons(String caseId, String entitySequence)...");

		List<ANigo> aNigoList = new ArrayList<ANigo>();

		if ((null == entitySequence) || "".equalsIgnoreCase(entitySequence)) {

			aNigoList = nigoMapper.fetchNigo(caseId);

			if (aNigoList.isEmpty()) {
				return Collections.emptyList();
			}

			for (ANigo aNigo : aNigoList) {

				Map<String, List<Reason>> reasonsMap = aNigo.getReasonsMap();
				String groupId = aNigo.getNigoSqn();
				addQuestionAndAnswers(groupId, reasonsMap);
				addReasons(groupId, reasonsMap);
				addAgentResolutionNotes(caseId, reasonsMap);

			}

		} else {

			aNigoList = nigoMapper.fetchNigoByGroupId(entitySequence);

			if ((null == aNigoList) || aNigoList.isEmpty()) {
				return Collections.emptyList();
			}

			for (ANigo aNigo : aNigoList) {

				Map<String, List<Reason>> reasonsMap = aNigo.getReasonsMap();
				String groupId = aNigo.getNigoSqn();
				addQuestionAndAnswers(groupId, reasonsMap);
				addReasons(groupId, reasonsMap);
				addAgentResolutionNotes(caseId, reasonsMap);

			}

		}

		logger.debug("Exiting fetchNIGOHistoryWithQnAReasons(String caseId, String entitySequence)...");

		return processNigoInformation(aNigoList);
	}

	private List<NigoInfo> processNigoInformation(List<ANigo> aNigoList) {

		logger.debug("Entering processNigoInformation(List<ANigo> aNigoList)...");

		List<NigoInfo> nigoInfoList = new ArrayList<NigoInfo>();

		for (ANigo aNigo : aNigoList) {

			MultiValueMap<String, String> reasonMultiMap = new LinkedMultiValueMap<String, String>();
			NigoInfo nigoInfo = new NigoInfo();

			nigoInfo.setNigoedBy(aNigo.getNigoedBy());
			nigoInfo.setNigoedOn(formatDate(aNigo.getNigoedTimeStamp()));

			Map<String, List<Reason>> reasonMap = aNigo.getReasonsMap();

			for (Map.Entry<String, List<Reason>> entry : reasonMap.entrySet()) {

				List<Reason> reasonList = entry.getValue();

				for (Reason reason : reasonList) {
					reasonMultiMap.add(entry.getKey(), reason.getReason());
				}
				nigoInfo.setReasons(reasonMultiMap);
			}

			nigoInfoList.add(nigoInfo);
		}

		logger.debug("Exiting processNigoInformation(List<ANigo> aNigoList)...");

		return nigoInfoList;
	}

	private void addQuestionAndAnswers(String groupId, Map<String, List<Reason>> reasonsMap) {

		logger.debug("Entering addQuestionAndAnswers(String groupId, Map<String, List<Reason>> reasonsMap)...");

		List<AQuestion> questionsObjList = questionsMapper.fetchQuestionsByGrouopId(groupId);

		for (AQuestion aQuestion : questionsObjList) {

			String question = aQuestion.getQuestion();
			String[] questionAndPage = SplitUsingTokenizer(question, InfoCaddyConstant.NIGO_DELIMITER);

			String group = questionAndPage.length > 1 ? questionAndPage[1] : "noheader";

			if ("noheader".equals(group)) {
				group = aQuestion.getQuestionSetName();
			}

			if (group == null) {
				group = "noheader";
			}

			List<Reason> questionAnswerList = reasonsMap.get(group);

			if (questionAnswerList == null) {

				questionAnswerList = new ArrayList<Reason>();
				reasonsMap.put(group, questionAnswerList);

			}

			questionAnswerList.add(new Reason(questionAndPage[0], aQuestion.getValue()));

		}

		logger.debug("Exiting addQuestionAndAnswers(String groupId, Map<String, List<Reason>> reasonsMap)...");
	}

	private void addReasons(String groupId, Map<String, List<Reason>> reasonsMap) {

		logger.debug("Enetring addReasons(String groupId, Map<String, List<Reason>> reasonsMap)...");

		for (AReason aReason : reasonsMapper.fetchReasonsByGrouopId(groupId)) {

			String reasonTxt = aReason.getReasonTxt();
			String[] reasonAndPage = SplitUsingTokenizer(reasonTxt, InfoCaddyConstant.NIGO_DELIMITER);

			String group = reasonAndPage.length > 1 ? reasonAndPage[1] : "noheader";

			if ("noheader".equals(group)) {
				group = aReason.getReasonSetName();
			}

			if (group == null) {
				group = "noheader";
			}

			List<Reason> reasonTextList = reasonsMap.get(group);

			if (reasonTextList == null) {
				reasonTextList = new ArrayList<Reason>();
				reasonsMap.put(group, reasonTextList);
			}

			reasonTextList.add(new Reason(reasonAndPage[0]));

		}

		logger.debug("Exiting addReasons(String groupId, Map<String, List<Reason>> reasonsMap)...");
	}

	private void addAgentResolutionNotes(String caseId, Map<String, List<Reason>> reasonsMap) {

		logger.debug("Entering addReasons(String groupId, Map<String, List<Reason>> reasonsMap)...");

		addReasons(caseId, reasonsMap);

		logger.debug("Exiting addReasons(String groupId, Map<String, List<Reason>> reasonsMap)...");
	}

	@Override
	public List<Object> getInfoCaddyDetails(String caseId, String solution, String section) throws Exception {
		logger.debug("Entering getInfoCaddyDetails(String caseId, String solution, String section...");

		List<Object> infoCaddyDetailsList = infoCaddyService.getInfoCaddyDetails(solution, caseId, section);

		if (InfoCaddyConstant.GENERAL.equalsIgnoreCase(section)) {

			infoCaddyDetailsList = processGeneralInformation(infoCaddyDetailsList, caseId);

		}

		logger.debug("Exiting getInfoCaddyDetails(String caseId, String solution, String section...");

		return infoCaddyDetailsList;

	}

	private List<Object> processGeneralInformation(List<Object> infoCaddyDetailsList, String caseId) throws Exception {
		logger.debug("Entering processGeneralInformation(Type[] infoCaddyDetails, String caseId)...");

		String infoCaddyResponseJSONString = this.objectMapper.writeValueAsString(infoCaddyDetailsList);

		Type[] infoCaddyDetails = this.objectMapper.readValue(infoCaddyResponseJSONString, Type[].class);

		infoCaddyDetailsList.clear();

		for (Type type : infoCaddyDetails) {

			// Remove HTML elements for Age Of Case
			if (!ICMClientUtil.isEmpty(type.getName())
					&& type.getName().equalsIgnoreCase(InfoCaddyConstant.AGE_OF_CASE)) {

				String ageOfCase = !ICMClientUtil.isNull(type.getValue())
						? type.getValue().toString().replaceAll("\\<.*?>", "") : "";
				type.setValue(ageOfCase);
			}

			// Remove blank propertyGroup item
			if (!ICMClientUtil.isEmpty(type.getType()) && type.getType().equalsIgnoreCase("propertyGroup")
					&& ICMClientUtil.isEmpty(type.getName())) {
				infoCaddyDetails = InfoCaddyUtil.removeRelatedCase(infoCaddyDetails, type);
			}

			// Remove Related Cases group item
			if (!ICMClientUtil.isEmpty(type.getType()) && type.getType().equalsIgnoreCase("group")
					&& type.getName().equalsIgnoreCase(InfoCaddyConstant.RELATED_CASES)) {
				infoCaddyDetails = InfoCaddyUtil.removeRelatedCase(infoCaddyDetails, type);
			}

			// Populate NIGO Info
			if (!ICMClientUtil.isEmpty(type.getName())
					&& type.getName().equalsIgnoreCase(InfoCaddyConstant.NIGO_INFO)) {

				String nigoInfo = !ICMClientUtil.isNull(type.getValue()) ? type.getValue().toString() : "";
				String groupId = "";

				if (!ICMClientUtil.isEmpty(nigoInfo) && nigoInfo.contains("action-hover='nigoHistory'")) {

					String occurences = nigoInfo.substring(nigoInfo.indexOf("<span class='count'>"),
							nigoInfo.indexOf("</span>"));

					occurences = occurences.substring(occurences.lastIndexOf(">") + 1);

					try {

						int occurencesValue = Integer.parseInt(occurences);

						if (occurencesValue > 0) {

							type.setValue(fetchNIGOHistoryWithQnAReasons(caseId, groupId));

						} else {

							type.setValue(null);

						}

					} catch (NumberFormatException nfe) {

						logger.error("Error in converting string to number " + nfe.getMessage());

					}

				}

			}
			// Removing Blank propertyGroup item inside Content.
			List<Type> contentList = type.getContent();
			List<Type> toRemove = new ArrayList<Type>();
			if (null != contentList) {

				for (Type contentType : contentList) {

					if (!ICMClientUtil.isEmpty(contentType.getType())
							&& "propertyGroup".equalsIgnoreCase(contentType.getType())) {

						if (ICMClientUtil.isEmpty(contentType.getName()) && (contentType.getContent().size() == 0)) {
							toRemove.add(contentType);
						}
						// Parse for PropertyGroup
						List<Type> propertyContentList = contentType.getContent();
						List<Type> removeList = new ArrayList<Type>();
						if (propertyContentList != null) {
							for (Type propertyContent : propertyContentList) {

								if (ICMClientUtil.isEmpty(propertyContent.getName())
										&& (propertyContent.getContent().size() == 0)) {
									removeList.add(propertyContent);
								}

								if (!ICMClientUtil.isEmpty(propertyContent.getName())
										&& !ICMClientUtil.isNull(propertyContent.getValue())) {

									// populate Originated By chat link
									if (propertyContent.getValue().toString().contains("href=")
											&& (InfoCaddyUtil.checkChatLinksLabel(propertyContent.getName()))) {

										String chatlink = propertyContent.getValue().toString();
										chatlink = InfoCaddyUtil.getRacfId(chatlink);
										logger.debug("chatlink: " + chatlink + " for propertyContent.getName() "
												+ propertyContent.getName());
										propertyContent.setValue(chatlink);

									}

								}
							}

							if (removeList != null) {
								for (Type removeitem : removeList) {
									propertyContentList.remove(removeitem);
								}
							}
						}
					}
				}

				if (toRemove != null) {
					for (Type removeitem : toRemove) {
						contentList.remove(removeitem);
					}
				}
			}
		}

		infoCaddyDetailsList.add(infoCaddyDetails);

		logger.debug("Exiting processGeneralInformation(Type[] infoCaddyDetails, String caseId)...");

		return infoCaddyDetailsList;
	}

}
