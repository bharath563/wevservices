package org.tiaa.icm.client.cache;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import org.tiaa.icm.client.bo.engine.ContentBO;
import org.tiaa.icm.client.bo.security.P8Authentication;
import org.tiaa.icm.client.config.SolutionConfig;

/**
 * @author ganapaa
 *
 */
public class SolutionConfigCreator {

	static Logger logger = Logger.getLogger(SolutionConfigCreator.class);

	@javax.annotation.Resource(name = "solutionConfigs")
	private HashMap<String, String> solutionConfigFiles;

	@Autowired(required = true)
	public ObjectMapper objectMapper;

	@Autowired
	public ContentBO contentBO;

	@Autowired
	public P8Authentication p8Authentication;

	@Value("${objStoreUserId}")
	public String userId;

	@Value("${objStoreUserPwd}")
	public String password;

	@Value("${DEFAULT-OBJECT-STORE}")
	private String osName;

	public HashMap<String, String> getSolutionConfigFiles() {
		return solutionConfigFiles;
	}

	public void setSolutionConfigFiles(HashMap<String, String> solutionConfigFiles) {
		this.solutionConfigFiles = solutionConfigFiles;
	}

	@PostConstruct
	public void populateCache() throws Exception {
		logger.debug("Calling SolutionConfigCreator-->Post Construct");
		logger.debug(this.getSolutionConfigFiles().size());
		Map<String, Map<String, String>> caseProperties = new HashMap<String, Map<String, String>>();
		try {
			// login as CE user to get the Solution details...

			/*
			 * Subject subject = p8Authentication.login(userId, password); if
			 * (subject != null) { UserContext.get().pushSubject(subject); }
			 */

			InputStream is = null;
			if (getSolutionConfigFiles().size() > 0) {
				for (Map.Entry<String, String> solutionConfig : getSolutionConfigFiles().entrySet()) {

					is = this.getClass().getClassLoader().getResourceAsStream(solutionConfig.getValue());
					logger.debug("Loading Config File for Solution->" + solutionConfig.getKey() + " from location'"
							+ solutionConfig.getValue() + "'");
					if (is != null) {
						objectMapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
						SolutionConfig config = objectMapper.readValue(is, SolutionConfig.class);
						SolutionConfigCache.getSolutionConfigCache().put(solutionConfig.getKey(), config);

						logger.debug(config.getInbasketHeaders().size());
						logger.debug("InBasket Headers-->" + config.getInbasketHeaders().size());
						logger.debug("Number of Operational Roles->" + config.getRoles().size());
						logger.debug("Number of Filters->" + config.getFilters().size());
						if (config.getProfiles() != null) {
							logger.debug("Number of Profiles->" + config.getProfiles().getProfiles().size());
						}
						logger.debug("Has Profile-->" + config.isProfile());

						// populate properties for each solution..

						/*
						 * if (config.getGenericCaseType() != null) {
						 * caseProperties.put(config.getSolutionIdentifier(),
						 * contentBO.getPropertyDescription(osName,
						 * config.getGenericCaseType())); }
						 */
					} else {
						logger.debug("Config File is missing for Solution->" + solutionConfig.getKey() + " in location'"
								+ solutionConfig.getValue() + "'");
					}
				}
				// SolutionConfigCache.setCaseProperties(caseProperties);
			}
		} finally {
			// login as CE user to get the Solution details...
			// UserContext.get().popSubject();
		}
	}
}
