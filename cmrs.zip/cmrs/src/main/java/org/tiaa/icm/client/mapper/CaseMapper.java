package org.tiaa.icm.client.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.mapping.ResultSetType;

import org.tiaa.icm.client.domain.Case;
import org.tiaa.icm.client.domain.Solution;
import org.tiaa.icm.client.domain.Task;
import org.tiaa.icm.client.querybuilder.CaseQueryBuilder;
import org.tiaa.icm.client.utils.ICMClientMap;

public interface CaseMapper {

	@SelectProvider(type = CaseQueryBuilder.class, method = "getCaseSearchProvider")
	@Options(resultSetType = ResultSetType.FORWARD_ONLY, fetchSize = 1000, timeout = 0, useCache = false, flushCache = false)
	public List<Case> searchCase(@Param("confirmation") String confirmation, @Param("pins") List<String> pins,
			@Param("clientId") String clientId, @Param("caseType") String caseType, @Param("channel") String channel,
			@Param("type") String type, @Param("from") String from, @Param("to") String to,
			@Param("ssns") List<String> ssns, @Param("caseStatus") String caseStatus, @Param("plan") String plan,
			@Param("sortField") String sortField, @Param("sortOrder") String sortOrder,
			@Param("planIdentifier") String planIdentifier, @Param("solution") String solution,
			@Param("start") String start);

	@SelectProvider(type = CaseQueryBuilder.class, method = "getHumanTaskProvider")
	public List<Task> getHumanTasks(@Param("caseids") String caseIds);

	@SelectProvider(type = CaseQueryBuilder.class, method = "getSystemTaskProvider")
	public List<Task> getSystemTasks(@Param("caseids") String caseIds);

	@SelectProvider(type = CaseQueryBuilder.class, method = "getTaskProvider")
	public List<Task> getTasks(@Param("caseids") String caseIds, @Param("solutionName") String solutionName,
			@Param("caseType") String caseType);

	@SelectProvider(type = CaseQueryBuilder.class, method = "getStatusProvider")
	public List<ICMClientMap> getStatus(@Param("caseIds") String caseIds);

	// @SelectProvider(type = CaseQueryBuilder.class, method =
	// "getRelatedCases")
	// public List<RelatedCase> getRelatedCases(@Param("caseId") String caseId,
	// @Param("solutionName") String solutionName,
	// @Param("pathName") String pathName, @Param("caseType") String caseType);

	@SelectProvider(type = CaseQueryBuilder.class, method = "getCaseStatus")
	public String getCaseStatus(@Param("caseid") String caseid);

	@SelectProvider(type = CaseQueryBuilder.class, method = "getSolutionNameAndConfirmationNumber")
	public Solution getSolutionNameAndConfirmationNumber(@Param("caseid") String caseid);

	@SelectProvider(type = CaseQueryBuilder.class, method = "getParallelCaseId")
	public List<String> getParallelCaseId(@Param("confirmationNumber") String confirmationNumber,
			@Param("caseid") String caseid);

}
