package org.tiaa.icm.client.entitlement;

import java.util.List;

import org.apache.log4j.Logger;

import org.tiaa.icm.client.cache.SolutionConfigCache;
import org.tiaa.icm.client.domain.entitlement.OperationalRole;

public abstract class AbstractSolution {

	Logger logger = Logger.getLogger(AbstractSolution.class);

	abstract List<OperationalRole> compareRolesWithLDAP(String solution, String racfId, List<String> ldaps,
			String type);

	abstract List<OperationalRole> overrideRoles(String solution, List<OperationalRole> queues, List<String> ldaps,
			String type);

	abstract List<OperationalRole> getQueueManagerRoles(List<OperationalRole> roles);

	public final List<OperationalRole> getUserEntitledRoles(String racfId, String solution, List<String> ldaps,
			String workitemType) {

		logger.info("Getting the role and queue entitiled by the user'" + racfId + "'");
		// get the roles and its ldap and check with user's ldap
		List<OperationalRole> roles = compareRolesWithLDAP(solution, racfId, ldaps, workitemType);

		// to map roles with profile if solution has profiles
		if ((SolutionConfigCache.getSolutionConfigCache().get(solution) != null)
				&& SolutionConfigCache.getSolutionConfigCache().get(solution).isProfile()) {
			// override the roles with the operational role based on profile
			roles = overrideRoles(solution, roles, ldaps, workitemType);
		}

		// finally check user is part of queue Manager, if yes provide the
		// queueManager roles...
		List<OperationalRole> queueManagers = getQueueManagerRoles(roles);
		if (queueManagers.size() > 0) {
			roles.retainAll(queueManagers);
		}
		return roles;
	}

}
