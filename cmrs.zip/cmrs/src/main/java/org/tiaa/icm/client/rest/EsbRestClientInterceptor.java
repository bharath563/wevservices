package org.tiaa.icm.client.rest;

import java.io.IOException;
import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;

import org.apache.log4j.Logger;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import org.tiaa.icm.client.rest.util.GUIDUtility;
import org.tiaa.icm.client.rest.util.SecurityUtil;
import org.tiaa.icm.jaxws.client.HttpRequestData;

public class EsbRestClientInterceptor implements ClientHttpRequestInterceptor {
	private static Logger logger = Logger.getLogger(EsbRestClientInterceptor.class);
	public static final String XSD_TIME_STAMP_FORMAT_STR = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	public static final SimpleDateFormat ESB_TIME_STAMP_FORMAT = new SimpleDateFormat(XSD_TIME_STAMP_FORMAT_STR);

	static {
		ESB_TIME_STAMP_FORMAT.setTimeZone(TimeZone.getTimeZone("UTC"));
	}

	ArrayList<MediaType> mediaTypes;
	HttpRequestData httpRequestData;
	public ThreadLocal<String> currentGuid = new ThreadLocal<String>();
	public ThreadLocal<String> threadCorrId = new ThreadLocal<String>();
	String hostName;
	String appName = "CaseManager";
	String password;
	String endPointAppName;

	public EsbRestClientInterceptor() {
		try {
			hostName = InetAddress.getLocalHost().getCanonicalHostName();
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
		httpRequestData = new HttpRequestData();
	}

	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
			throws IOException {
		updateHeaders(request.getHeaders());
		return execution.execute(request, body);
	}

	public void updateHeaders(HttpHeaders httpHeaders) {
		httpHeaders.add("tiaa-consumer", appName);
		String timeStamp = ESB_TIME_STAMP_FORMAT.format(Calendar.getInstance().getTime());
		httpHeaders.add("tiaa-timestamp", timeStamp);
		String timestamp_pwd = timeStamp + password;
		String digest = SecurityUtil.toBase64SHADigest(timestamp_pwd);
		logger.debug("federated-rs-v1 digest: " + digest);
		httpHeaders.add("tiaa-digest", digest);// add tiaa-digest
		if (currentGuid.get() == null) {
			currentGuid.set(GUIDUtility.generateStr());
		}
		httpHeaders.add("tiaa-guid", currentGuid.get());
		String userRef = httpRequestData.getUserRef();
		userRef = (userRef != null) ? userRef : "UNKNOWN";
		httpHeaders.add("tiaa-user-ref", userRef);
		httpHeaders.add("tiaa-sender-machine", hostName);
		if (threadCorrId.get() != null) {
			httpHeaders.add("tiaa-correlation-id", threadCorrId.get());
		}
		if (endPointAppName != null) {
			httpHeaders.add("tiaa-partner-id", endPointAppName);
		}
		if (getMediaTypes() != null) {
			httpHeaders.setAccept(getMediaTypes());
		}
		logger.debug("httpHeaders:" + httpHeaders.toString());
	}

	/**
	 * @return the currentGuid
	 */
	public ThreadLocal<String> getCurrentGuid() {
		return currentGuid;
	}

	/**
	 * @param _currentGuid
	 *            the currentGuid to set
	 */
	public void setCurrentGuid(ThreadLocal<String> _currentGuid) {
		this.currentGuid = _currentGuid;
	}

	public ArrayList<MediaType> getMediaTypes() {
		return mediaTypes;
	}

	public void setMediaTypes(ArrayList<MediaType> mediaTypes) {
		this.mediaTypes = mediaTypes;
	}

	/**
	 * @return the httpRequestData
	 */
	public HttpRequestData getHttpRequestData() {
		return httpRequestData;
	}

	/**
	 * @param httpRequestData
	 *            the httpRequestData to set
	 */
	public void setHttpRequestData(HttpRequestData httpRequestData) {
		this.httpRequestData = httpRequestData;
	}

	/**
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}

	/**
	 * @param appName
	 *            the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}

	/**
	 * @return the password
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param password
	 *            the password to set
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the endPointAppName
	 */
	public String getEndPointAppName() {
		return endPointAppName;
	}

	/**
	 * @param endPointAppName
	 *            the endPointAppName to set
	 */
	public void setEndPointAppName(String endPointAppName) {
		this.endPointAppName = endPointAppName;
	}
}
