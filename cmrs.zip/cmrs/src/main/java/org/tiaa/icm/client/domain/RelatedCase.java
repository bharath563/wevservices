package org.tiaa.icm.client.domain;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import org.tiaa.icm.client.serializer.JsonDateSerializer;

/**
 * To get the related details of a Case
 *
 * <p>
 * Java class for RelatedCasesResponseType complex type.
 *
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 *
 * <pre>
* &lt;complexType name="RelatedCasesResponseType">
*   &lt;complexContent>
*     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
*       &lt;sequence>
*         &lt;element name="caseId" type="{http://www.w3.org/2001/XMLSchema}string"/>
*         &lt;element name="confirmation" type="{http://www.w3.org/2001/XMLSchema}string"/>
*         &lt;element name="caseType" type="{http://www.w3.org/2001/XMLSchema}string"/>
*         &lt;element name="caseIdentifier" type="{http://www.w3.org/2001/XMLSchema}string"/>
*         &lt;element name="caseStatus" type="{http://www.w3.org/2001/XMLSchema}string"/>
*         &lt;element name="createdDate" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
*         &lt;element name="completedDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
*         &lt;element name="pathName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
*         &lt;/sequence>
*     &lt;/restriction>
*   &lt;/complexContent>
* &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RelatedCasesResponseType", propOrder = { "caseId", "confirmation", "caseType", "caseStatus",
		"createdDate", "completedDate", "pathName" })
public class RelatedCase {

	@XmlElement(required = true)
	protected String caseId;
	@XmlElement(required = true)
	protected String confirmation;
	@XmlElement(required = true)
	protected String caseType;
	@XmlElement(required = true)
	protected String caseStatus;
	@XmlElement(required = true)
	@XmlSchemaType(name = "dateTime")
	// protected XMLGregorianCalendar createdDate;
	protected Date createdDate;
	@XmlSchemaType(name = "dateTime")
	// protected XMLGregorianCalendar completedDate;
	protected Date completedDate;
	@XmlElement(required = false)
	@JsonIgnore
	protected String caseIdentifier;
	@JsonIgnore
	protected String pathName;

	/**
	 * Gets the value of the caseId property.
	 *
	 * @return possible object is {@link String }
	 *
	 */
	public String getCaseId() {
		return caseId;
	}

	/**
	 * Sets the value of the caseId property.
	 *
	 * @param value
	 *            allowed object is {@link String }
	 *
	 */
	public void setCaseId(String value) {
		this.caseId = value;
	}

	/**
	 * Gets the value of the confirmation property.
	 *
	 * @return possible object is {@link String }
	 *
	 */
	public String getConfirmation() {
		return confirmation;
	}

	/**
	 * Sets the value of the confirmation property.
	 *
	 * @param value
	 *            allowed object is {@link String }
	 *
	 */
	public void setConfirmation(String value) {
		this.confirmation = value;
	}

	/**
	 * Gets the value of the case identifier property.
	 *
	 * @return possible object is {@link String }
	 */
	public String getCaseIdentifier() {
		return caseIdentifier;
	}

	/**
	 * Sets the value of the case identifier property.
	 *
	 * @param value
	 *            allowed object is {@link String }
	 *
	 */
	public void setCaseIdentifier(String value) {
		this.caseIdentifier = value;
	}

	/**
	 * Gets the value of the caseType property.
	 *
	 * @return possible object is {@link String }
	 *
	 */
	public String getCaseType() {
		return caseType;
	}

	/**
	 * Sets the value of the caseType property.
	 *
	 * @param value
	 *            allowed object is {@link String }
	 *
	 */
	public void setCaseType(String value) {
		this.caseType = value;
	}

	/**
	 * Gets the value of the caseStatus property.
	 *
	 * @return possible object is {@link String }
	 *
	 */
	public String getCaseStatus() {
		return caseStatus;
	}

	/**
	 * Sets the value of the caseStatus property.
	 *
	 * @param value
	 *            allowed object is {@link String }
	 *
	 */
	public void setCaseStatus(String value) {
		this.caseStatus = value;
	}

	/**
	 * Gets the value of the createdDate property.
	 *
	 * @return possible object is {@link XMLGregorianCalendar }
	 *
	 */
	@JsonSerialize(using = JsonDateSerializer.class)
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * Sets the value of the createdDate property.
	 *
	 * @param value
	 *            allowed object is {@link XMLGregorianCalendar }
	 *
	 */
	public void setCreatedDate(Date value) {
		this.createdDate = value;
	}

	/**
	 * Gets the value of the completedDate property.
	 *
	 * @return possible object is {@link XMLGregorianCalendar }
	 *
	 */
	@JsonSerialize(using = JsonDateSerializer.class)
	public Date getCompletedDate() {
		return completedDate;
	}

	/**
	 * Sets the value of the completedDate property.
	 *
	 * @param value
	 *            allowed object is {@link XMLGregorianCalendar }
	 *
	 */
	public void setCompletedDate(Date value) {
		this.completedDate = value;
	}
	
	/**
	 * Gets the value of the pathName property.
	 *
	 * @return possible object is {@link String }
	 *
	 */
	public String getPathName() {
		return pathName;
	}

	/**
	 * Sets the value of the pathName property.
	 *
	 * @param value
	 *            allowed object is {@link String }
	 *
	 */
	public void setPathName(String value) {
		this.pathName = value;
	}
}
