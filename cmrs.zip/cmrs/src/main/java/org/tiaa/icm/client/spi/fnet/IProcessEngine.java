package org.tiaa.icm.client.spi.fnet;

import java.util.Map;
import java.util.concurrent.ExecutionException;

import javax.naming.NamingException;

import com.ibm.websphere.security.WSSecurityException;

import org.springframework.http.ResponseEntity;

import org.tiaa.icm.client.domain.Response;
import org.tiaa.icm.client.domain.StepList;

import filenet.vw.api.VWException;
import filenet.vw.api.VWQueueQuery;
import filenet.vw.api.VWSession;
import filenet.vw.api.VWStepElement;

public interface IProcessEngine {
	public Response doAction(String queueName, String wobID, Map<String, Object> dataFields, String action,
			String racfID);

	public VWStepElement getStepElement(String queueName, String wobID, String racfID, VWSession vwSession)
			throws VWException, Exception;

	public VWQueueQuery getVWQueueQuery(String queueName, String wobID, VWSession vwSession) throws VWException;

	public Response unlockWorkItem(String queueName, String wobID, String racfID);

	public ResponseEntity<?> getStepDetails(String queueName, String wobID) throws VWException, Exception;

	public Response reassignWorkitem(String queueName, String wobID, String reassignRacfId);

	public StepList getWorkItems(String solution, String racfId, String type)
			throws NamingException, VWException, InterruptedException, ExecutionException, WSSecurityException;

}
