package org.tiaa.icm.client.mapper;

import java.util.List;
import java.util.Set;

import org.apache.ibatis.annotations.Param;

import org.tiaa.icm.client.domain.TaskStepInfo;

public interface TaskStepMapper {

	public List<TaskStepInfo> getTaskStepInfo(@Param("set") Set<String> set);

}
