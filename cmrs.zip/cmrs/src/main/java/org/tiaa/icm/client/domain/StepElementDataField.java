package org.tiaa.icm.client.domain;

import java.util.List;

public class StepElementDataField {
	private String name;
	private String id;
	private String type;
	private String mode;
	private List<String> value;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<String> getValue() {
		return value;
	}

	public void setValue(List<String> value) {
		this.value = value;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public void toString(StringBuffer sBufStep) {
		StringBuffer sBuffields = new StringBuffer();
		if (sBufStep.indexOf("=") > -1) {
			sBufStep.append(",fields { [");
		} else {
			sBufStep.append("fields { [");
		}
		appendStrProperty(sBuffields, "name", name);
		appendStrProperty(sBuffields, "id", id);
		appendStrProperty(sBuffields, "type", type);
		appendStrProperty(sBuffields, "mode", mode);
		appendStrProperty(sBuffields, "value", value);
		sBufStep.append(sBuffields.toString());
		sBufStep.append(" ] }");

	}

	private void appendStrProperty(StringBuffer sBuffields, String property, String value) {
		if (value != null) {
			if (sBuffields.indexOf("=") > -1) {
				sBuffields.append(",").append(property).append("=").append(value);
			} else {
				sBuffields.append(property).append("=").append(value);
			}
		}
	}

	private void appendStrProperty(StringBuffer sBuffields, String property, List<String> fieldValue) {
		if (fieldValue != null) {
			sBuffields.append(",").append(property).append("=").append(fieldValue);
		} else {
			sBuffields.append(property).append("=").append(fieldValue);
		}
	}

}
