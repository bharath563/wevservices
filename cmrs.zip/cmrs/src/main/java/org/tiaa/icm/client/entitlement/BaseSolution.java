/**
 *
 */
package org.tiaa.icm.client.entitlement;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.tiaa.icm.client.cache.SolutionConfigCache;
import org.tiaa.icm.client.config.SolutionConfig;
import org.tiaa.icm.client.domain.entitlement.OperationalRole;
import org.tiaa.icm.client.domain.entitlement.Profile;
import org.tiaa.icm.client.domain.entitlement.ProfileConfig;
import org.tiaa.icm.client.domain.entitlement.Role;
import org.tiaa.icm.client.domain.entitlement.WorkItemType;

/**
 * @author ganapaa
 *
 */
public class BaseSolution extends AbstractSolution {

	@Override
	List<org.tiaa.icm.client.domain.entitlement.OperationalRole> compareRolesWithLDAP(String solution, String racfId,
			List<String> ldaps, String workItemType) {

		// key - RoleName, Value - Queue Object..
		// Key (role name) reason -> to avoid querying the same queue with the
		// same filter if user has mulitple role level LDAPs for the same role.
		// example - Payout users can have LDAPs for the same role like below.
		// [%AP_UD_APP_CM_OPS_PROC_ALL_WTHDRWLS%,
		// %AP_CM_ROLE_WITHDRAWAL_PROCESSOR%]
		Map<String, OperationalRole> roles = new HashMap<String, OperationalRole>();

		SolutionConfig config = SolutionConfigCache.getSolutionConfigCache().get(solution);

		if ((config != null) && (config.getRoles() != null)) {
			Iterator<Role> iter = config.getRoles().iterator();
			while (iter.hasNext()) {
				Role role = iter.next();
				/*
				 * If user has the particular role ldaps add the queue and
				 * filter to list of queue if he\she has entitled too..
				 */
				if (ldaps.containsAll(role.getGroups())) {
					logger.info("compareRolesWithLDAP()->User belongs to Role:'" + role.getName() + "'");
					OperationalRole queue = new OperationalRole();
					// get the queue info operational role name, queueName and
					// filter from filter configuration
					if (config.getFilters().containsKey(role.getName())) {
						// get the workitem types
						Iterator<WorkItemType> iterator = config.getFilters().get(role.getName()).iterator();
						while (iterator.hasNext()) {
							List<String> queueNames = null;
							String roleName = null;
							String filters = null;

							WorkItemType type = iterator.next();
							if (type.getClass().toString().contains(workItemType)) {
								logger.debug(type.getClass().toString());
								queueNames = type.getQueues();
								filters = type.getFilters();
								roleName = role.getName();
								queue.setRoleName(roleName).setQueueNames(queueNames).setFilters(filters);
								roles.put(roleName, queue);
								// either Unassigned or Pended not both
								break;
							}

						}

					}

				}
			}
		}
		return new ArrayList<OperationalRole>(roles.values());
	}

	// Map each role with the existing profile and check again the
	// user ldaps and override the actual role with the operational Roles..
	@Override
	List<org.tiaa.icm.client.domain.entitlement.OperationalRole> overrideRoles(String solution,
			List<OperationalRole> queues, List<String> ldaps, String workItemType) {

		SolutionConfig config = SolutionConfigCache.getSolutionConfigCache().get(solution);
		Iterator<OperationalRole> iter = queues.iterator(); // existing queue...
		List<OperationalRole> overriddenQueues = new ArrayList<OperationalRole>();

		ProfileConfig profiles = config.getProfiles();
		boolean isOrdered = profiles.getType() != null ? profiles.getType().equalsIgnoreCase("order") : false;

		// for each new role the user has been part of..
		while (iter.hasNext()) {
			OperationalRole queue = iter.next();
			logger.info("User belongs to Role->'" + queue.getRoleName() + "'");
			// now check whether user has which profile??
			Iterator<Profile> iterProfile = profiles.getProfiles().iterator();
			while (iterProfile.hasNext()) {
				Profile profile = iterProfile.next();
				if (ldaps.containsAll(profile.getGroups())) {
					/*
					 * for this role we found a profile. so we are safe to
					 * remove the existing role from the queue..
					 */
					iter.remove();
					logger.info("User has profile-> '" + profile.getName() + "'");
					// user has the profile ldap
					String operationalRole = queue.getRoleName() + " - " + profile.getName();
					logger.info("After applying profile user has operational Role-> '" + operationalRole + "'");
					/*
					 * get the operationRole from the filter configuration and
					 * add it to the list of queues to be returned..
					 */
					if (config.getFilters().containsKey(operationalRole)) {
						OperationalRole overriddenQueue = new OperationalRole();

						// get the workitem types
						Iterator<WorkItemType> iterator = config.getFilters().get(operationalRole).iterator();
						while (iterator.hasNext()) {
							List<String> queueNames = null;
							String roleName = null;
							String filters = null;

							WorkItemType type = iterator.next();

							logger.debug(type.getClass().toString());
							if (type.getClass().toString().contains(workItemType)) {
								queueNames = type.getQueues();
								filters = type.getFilters();
								roleName = operationalRole;
								overriddenQueues.add(overriddenQueue.setRoleName(roleName).setQueueNames(queueNames)
										.setFilters(filters));
								break; // atleast one type should be requested
										// either Unassigned or Pended...
							}

						}
					}

					/*
					 * profile type is ordered so if we have found the highest
					 * level we can skip the next lower levels example is payout
					 * segment L3, L2 and L1..
					 */
					if (isOrdered) {
						break;
					}
				}
			}
		}
		queues.addAll(overriddenQueues);
		return queues;
	}

	@Override
	List<OperationalRole> getQueueManagerRoles(List<OperationalRole> roles) {

		List<OperationalRole> queueManagers = new ArrayList<OperationalRole>();

		// is User part of QueueManager?
		if ((roles != null) && (roles.size() > 0)) {
			Iterator<OperationalRole> iter = roles.iterator();
			while (iter.hasNext()) {
				OperationalRole role = iter.next();
				if (role.getRoleName().startsWith("Queue Manager")) {
					queueManagers.add(role);
				}
			}
		}
		if (queueManagers.size() > 0) {
			logger.info("User is part of QueueManager");
		}
		return queueManagers;
	}
}
