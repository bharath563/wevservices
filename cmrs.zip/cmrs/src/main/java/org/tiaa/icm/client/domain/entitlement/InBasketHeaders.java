package org.tiaa.icm.client.domain.entitlement;

import java.util.Map;

import org.codehaus.jackson.annotate.JsonProperty;

public class InBasketHeaders {

	private String type;

	// @JsonDeserialize(using = HeadersConfigDeserailizer.class)
	@JsonProperty(value = "headers")
	private Map<String, Properties> headers;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Map<String, Properties> getHeaders() {
		return headers;
	}

	public void setHeaders(Map<String, Properties> headers) {
		this.headers = headers;
	}

}
