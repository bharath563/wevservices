package org.tiaa.icm.client.infocaddy.bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.icm.client.config.InfoCaddyBOConfig;
import org.tiaa.icm.client.domain.ResponseList;
import org.tiaa.icm.client.infocaddy.bo.ISInfoCaddyBO;
import org.tiaa.icm.client.infocaddy.bo.InfoCaddyBODelegate;
import org.tiaa.icm.client.infocaddy.bo.PIInfoCaddyBO;
import org.tiaa.icm.client.infocaddy.comparators.RecentCasesComparator;
import org.tiaa.icm.client.infocaddy.constant.InfoCaddyConstant;
import org.tiaa.icm.client.infocaddy.json.RecentCasesObject;
import org.tiaa.icm.client.infocaddy.json.Type;
import org.tiaa.icm.client.infocaddy.utils.InfoCaddyUtil;
import org.tiaa.icm.client.provider.AppPropertiesProvider;
import org.tiaa.icm.client.utils.ICMClientUtil;

public class InfoCaddyBean {
	private static Logger logger = Logger.getLogger(InfoCaddyBean.class);

	@Autowired
	InfoCaddyBOConfig infoCaddyConfig;

	public List<Object> getInfoCaddyDetails(String caseId, String solution, String section,
			Map<String, String> parameters) throws Exception {
		logger.info("Entering getInfoCaddyDetails(String caseId, String solution, String section...");

		InfoCaddyBODelegate infoCaddyDelegate = infoCaddyConfig.getInfoCaddyBO(solution);

		String startStr = parameters.get("start");
		String sortBy = parameters.get("sortBy");
		String sortOrder = parameters.get("sortOrder");
		String tableName = parameters.get("tableName");
		String groupId = parameters.get("groupId");

		if ((infoCaddyDelegate instanceof ISInfoCaddyBO) && !ICMClientUtil.isEmpty(startStr)
				&& !ICMClientUtil.isEmpty(sortBy) && !ICMClientUtil.isEmpty(sortOrder)) {

			List<Object> recentCasesList = new ArrayList<Object>();

			ISInfoCaddyBO isInfoCaddyBO = (ISInfoCaddyBO) infoCaddyDelegate;

			isInfoCaddyBO.setDefaultPagination(false);

			List<RecentCasesObject> recentCaseListObjectList = isInfoCaddyBO.fetchRecentCases(caseId);

			if (recentCaseListObjectList.size() > 0) {

				Collections.sort(recentCaseListObjectList, new RecentCasesComparator(sortOrder, sortBy));

				ResponseList responseList = addPagination(recentCaseListObjectList, startStr);

				// Wrap Recent Cases in Type object
				Type type = InfoCaddyUtil.createPropertyType(InfoCaddyConstant.RECENT_CASES, responseList);

				recentCasesList.add(type);

				logger.info(
						"Exiting getInfoCaddyDetails(String caseId, String solutionName, String section...) for IS pagination");

			}

			return recentCasesList;

		}

		else if ((infoCaddyDelegate instanceof PIInfoCaddyBO) && !ICMClientUtil.isEmpty(tableName)
				&& !ICMClientUtil.isEmpty(groupId)) {

			List<Object> omniDetailsList = new ArrayList<Object>();

			PIInfoCaddyBO piInfoCaddyBO = (PIInfoCaddyBO) infoCaddyDelegate;

			List<Object> omniDetailsObjectList = piInfoCaddyBO.getOmniDetails(groupId, tableName);

			// Wrap Omni Details in Type object
			Type type = InfoCaddyUtil.createPropertyType(InfoCaddyConstant.OMNI_DETAILS, omniDetailsObjectList);

			omniDetailsList.add(type);

			logger.info(
					"Exiting getInfoCaddyDetails(String caseId, String solutionName, String section...) for OmniInfo");

			return omniDetailsList;
		}

		logger.info("Exiting getInfoCaddyDetails(String caseId, String solutionName, String section...");

		return infoCaddyDelegate.getInfoCaddyDetails(caseId, solution, section);
	}

	private ResponseList addPagination(List<RecentCasesObject> recentCasesList, String startStr) {

		int noOfRecPerPage = AppPropertiesProvider.getIntProperty("noOfRecentCases");
		int maxSize = 0;

		int start = ICMClientUtil.convertStrToInt(startStr);
		start = (start > 0) ? start : 1;
		int end = (start > 0) ? (start + (noOfRecPerPage - 1)) : noOfRecPerPage;

		ResponseList response = new ResponseList();
		response.setStart(start);

		if (recentCasesList != null) {

			List<RecentCasesObject> pagedList = new ArrayList<RecentCasesObject>();

			if (recentCasesList.size() >= end) {

				pagedList = recentCasesList.subList(start - 1, end);

			} else if (recentCasesList.size() >= start) {

				pagedList = recentCasesList.subList(start - 1, recentCasesList.size());

			}
			response.setResults(pagedList);

			if ((pagedList != null) && (pagedList.size() > 0)) {

				maxSize = pagedList.size();
				response.setTotalRecords(recentCasesList.size());

			}
			if (maxSize > 0) {

				response.setEnd((start + maxSize) - 1);

			}
		} else {

			response.setError("No Data Found");

		}

		return response;
	}

}
