package org.tiaa.icm.client.infocaddy.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.type.Alias;

import org.tiaa.icm.client.infocaddy.domain.AQuestion;

@Alias("aQuestion")
public interface AQuestionMapper {

	public List<AQuestion> fetchQuestions(@Param("caseId") String caseId);

	public List<AQuestion> fetchQuestionsByGrouopId(@Param("groupId") String groupId);
}
