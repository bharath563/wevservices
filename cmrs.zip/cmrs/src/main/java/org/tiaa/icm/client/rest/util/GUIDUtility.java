package org.tiaa.icm.client.rest.util;

import java.util.Random;
import java.util.UUID;

public class GUIDUtility {
	public final static Random rand = new Random();

	/**
	 *
	 */
	public GUIDUtility() {
		// TODO Auto-generated constructor stub
	}

	public static int generateInt() {
		return UUID.randomUUID().hashCode();
	}

	public static String generateStr() {
		return UUID.randomUUID().toString();
	}

	public static String generateStr(String prefix) {
		return prefix + UUID.randomUUID();
	}
}
