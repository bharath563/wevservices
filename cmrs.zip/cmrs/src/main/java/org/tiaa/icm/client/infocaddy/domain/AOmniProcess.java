package org.tiaa.icm.client.infocaddy.domain;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import org.apache.ibatis.type.Alias;

@Alias("aOmniProcess")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class AOmniProcess {

	public AOmniProcess() {

	}

	String id;
	String omniFolderName;
	String omniTradeDate;
	@JsonIgnore
	Timestamp omniTradeDateTS;
	String omniSequenceNum;
	String omniStatus;
	String omniErrorCode;
	String omniErrorMsg;
	String updatedTS;
	@JsonIgnore
	Timestamp updatedTimeStamp;
	private Timestamp omniPostDate;
	private BigDecimal amount;
	private String paymentMethod;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOmniFolderName() {
		return omniFolderName;
	}

	public void setOmniFolderName(String omniFolderName) {
		this.omniFolderName = omniFolderName;
	}

	public String getOmniTradeDate() {
		return omniTradeDate;
	}

	public void setOmniTradeDate(String omniTradeDate) {
		this.omniTradeDate = omniTradeDate;
	}

	public Timestamp getOmniTradeDateTS() {
		return omniTradeDateTS;
	}

	public void setOmniTradeDateTS(Timestamp omniTradeDateTS) {
		this.omniTradeDateTS = omniTradeDateTS;
	}

	public String getOmniSequenceNum() {
		return omniSequenceNum;
	}

	public void setOmniSequenceNum(String omniSequenceNum) {
		this.omniSequenceNum = omniSequenceNum;
	}

	public String getOmniStatus() {
		return omniStatus;
	}

	public void setOmniStatus(String omniStatus) {
		this.omniStatus = omniStatus;
	}

	public String getOmniErrorCode() {
		return omniErrorCode;
	}

	public void setOmniErrorCode(String omniErrorCode) {
		this.omniErrorCode = omniErrorCode;
	}

	public String getOmniErrorMsg() {
		return omniErrorMsg;
	}

	public void setOmniErrorMsg(String omniErrorMsg) {
		this.omniErrorMsg = omniErrorMsg;
	}

	public String getUpdatedTS() {
		return updatedTS;
	}

	public void setUpdatedTS(String updatedTS) {
		this.updatedTS = updatedTS;
	}

	public Timestamp getUpdatedTimeStamp() {
		return updatedTimeStamp;
	}

	public void setUpdatedTimeStamp(Timestamp updatedTimeStamp) {
		this.updatedTimeStamp = updatedTimeStamp;
	}

	/**
	 * @return the omniPostDate
	 */
	public Timestamp getOmniPostDate() {
		return omniPostDate;
	}

	/**
	 * @param omniPostDate
	 *            the omniPostDate to set
	 */
	public void setOmniPostDate(Timestamp omniPostDate) {
		this.omniPostDate = omniPostDate;
	}

	/**
	 * @return the amount
	 */
	public BigDecimal getAmount() {
		return amount;
	}

	/**
	 * @param amount
	 *            the amount to set
	 */
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	/**
	 * @return the paymentMethod
	 */
	public String getPaymentMethod() {
		return paymentMethod;
	}

	/**
	 * @param paymentMethod
	 *            the paymentMethod to set
	 */
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
}
