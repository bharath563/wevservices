package org.tiaa.icm.client.domain;

import java.util.Date;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import org.tiaa.icm.client.serializer.JsonDateSerializer;

public class Event implements Comparable<Event> {

	private String title;

	private String description;

	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	private Date createdOn;

	private String createdBy;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@JsonSerialize(using = JsonDateSerializer.class)
	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	@Override
	public int compareTo(Event o) {
		if (getCreatedOn().compareTo(o.getCreatedOn()) == -1) {
			return 1;
		}
		if (getCreatedOn().compareTo(o.getCreatedOn()) == 1) {
			return -1;
		} else {
			return 0;
		}
	}

}
