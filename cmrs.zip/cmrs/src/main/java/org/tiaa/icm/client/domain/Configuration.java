package org.tiaa.icm.client.domain;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.naming.NamingException;

import org.codehaus.jackson.map.annotate.JsonSerialize;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

import org.tiaa.icm.client.cache.ICMClientCache;
import org.tiaa.icm.client.cache.SolutionConfigCache;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.entitlement.Properties;

public class Configuration {
	private List<String> casetype;
	private List<String> channel;
	private List<String> casestatus;

	private List<String> solution;

	private Map<String, List<Map<String, Properties>>> solutionHeaders;

	public Configuration(String type, String solution, String tableheader) throws NamingException {
		if (type != null) {
			if (type.equals("all")) {
				this.casetype = ICMClientCache.getCaseTypeList();
				this.channel = ICMClientCache.getChannelList();
				this.casestatus = ICMClientCache.getCaseStatusList();
				this.solution = ICMClientCache.getSolutionList();
			} else if (type.equals("casetype")) {
				this.casetype = ICMClientCache.getCaseTypeList();
			} else if (type.equals("channel")) {
				this.channel = ICMClientCache.getChannelList();
			} else if (type.equals("casestatus")) {
				this.casestatus = ICMClientCache.getCaseStatusList();
			} else if (type.equals("solution")) {
				this.solution = ICMClientCache.getSolutionList();
			}
		} else if ((solution != null) && (tableheader != null)) {
			if (tableheader.equalsIgnoreCase("all")) {
				this.solutionHeaders = getSolutionHeaders(solution, CommonConstants.UNASSIGNED_WORK_ITEM);
				// IS does not have AllAssigned & My Work Items
				if (!CommonConstants.IS_OPERATIONS.equalsIgnoreCase(solution)) {
					// Unassigned and MyWorkItems will have same headers
					this.solutionHeaders.put(CommonConstants.MY_WORK_ITEM,
							this.solutionHeaders.get(CommonConstants.UNASSIGNED_WORK_ITEM));

					this.solutionHeaders.putAll(getSolutionHeaders(solution, CommonConstants.ALL_ASSIGNED_WORK_ITEM));
				}
				this.solutionHeaders.putAll(getSolutionHeaders(solution, CommonConstants.PENDED_WORK_ITEM));

			} else {
				this.solutionHeaders = getSolutionHeaders(solution, tableheader);

			}
		}

	}

	private Map<String, List<Map<String, Properties>>> getSolutionHeaders(String solution, String workItemType)
			throws NamingException {

		Map<String, Properties> columns = new LinkedHashMap<String, Properties>();
		Map<String, List<Map<String, Properties>>> typeColumnHeaders = new LinkedHashMap<String, List<Map<String, Properties>>>();
		String tempWorkItemType = workItemType;
		if (CommonConstants.MY_WORK_ITEM.equalsIgnoreCase(workItemType)
				&& !CommonConstants.IS_OPERATIONS.equalsIgnoreCase(solution)) {
			tempWorkItemType = CommonConstants.UNASSIGNED_WORK_ITEM;
		}
		columns = SolutionConfigCache.getHeaders(solution, tempWorkItemType);
		// setting display names to columns instead of symbolic names and its
		// type
		List<Map<String, Properties>> displayFieldsList = new ArrayList<Map<String, Properties>>();
		Map<String, Properties> displayNames = new LinkedHashMap<String, Properties>();
		if (columns != null) {
			for (Map.Entry<String, Properties> entry : columns.entrySet()) {
				Properties headerDetails = entry.getValue();
				displayNames.put(headerDetails.getDisplayName(), headerDetails);
			}
			displayFieldsList.add(displayNames);
		}
		typeColumnHeaders.put(workItemType, displayFieldsList);
		return typeColumnHeaders;
	}

	@JsonSerialize(include = Inclusion.NON_NULL)
	public List<String> getCasetype() {
		return casetype;
	}

	@JsonSerialize(include = Inclusion.NON_NULL)
	public List<String> getChannel() {
		return channel;
	}

	@JsonSerialize(include = Inclusion.NON_NULL)
	public List<String> getCasestatus() {
		return casestatus;
	}

	@JsonSerialize(include = Inclusion.NON_NULL)
	public List<String> getSolution() {
		return solution;
	}

	@JsonSerialize(include = Inclusion.NON_NULL)
	public Map<String, List<Map<String, Properties>>> getSolutionHeaders() {
		return solutionHeaders;
	}

}
