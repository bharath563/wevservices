package org.tiaa.icm.client.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.tiaa.icm.client.config.SolutionConfig;
import org.tiaa.icm.client.domain.entitlement.InBasketHeaders;
import org.tiaa.icm.client.domain.entitlement.OperationalRole;
import org.tiaa.icm.client.domain.entitlement.Properties;
import org.tiaa.icm.client.domain.entitlement.Role;
import org.tiaa.icm.client.entitlement.BaseSolution;

public class SolutionConfigCache {

	private final static BaseSolution baseSolution = new BaseSolution();

	static Logger logger = Logger.getLogger(SolutionConfigCache.class);

	private static Map<String, SolutionConfig> solutionConfigCache = new HashMap<String, SolutionConfig>();

	private static Map<String, Map<String, String>> caseProperties = new HashMap<String, Map<String, String>>();

	public static Map<String, SolutionConfig> getSolutionConfigCache() {
		return solutionConfigCache;
	}

	public static Map<String, Properties> getHeaders(String solution, String type) {

		Map<String, Properties> symbolicNameHeaders = new HashMap<String, Properties>();
		SolutionConfig solutionConfig = solutionConfigCache.get(solution);
		if (solutionConfig != null) {
			List<InBasketHeaders> inbasketHeaders = solutionConfig.getInbasketHeaders();
			Iterator<InBasketHeaders> iterator = inbasketHeaders.iterator();
			while (iterator.hasNext()) {
				InBasketHeaders object = iterator.next();
				if (object.getType().equalsIgnoreCase(type)) {
					symbolicNameHeaders = object.getHeaders();
				}
			}
		}
		return symbolicNameHeaders;
	}

	public static List<String> getEntitledSolutions(String racfId, List<String> ldaps) {

		List<String> solutions = new ArrayList<String>();

		for (Map.Entry<String, SolutionConfig> solutionConfigs : getSolutionConfigCache().entrySet()) {
			logger.debug(solutionConfigs.getKey());
			SolutionConfig config = solutionConfigs.getValue();
			if (config.getRoles() != null) {
				Iterator<Role> iter = config.getRoles().iterator();
				while (iter.hasNext()) {
					Role role = iter.next();
					if (ldaps.containsAll(role.getGroups())) {
						logger.debug(racfId + "->user has access to solution" + solutionConfigs.getKey());
						solutions.add(solutionConfigs.getKey());
						// if we found at least one role, we are good to add
						// that solution to the list of solutions user is
						// entitled to.
						break;
					}
				}
			}
		}

		return solutions;
	}

	public static String getAllAssignedFilter(String solution) {
		return getSolutionConfigCache().get(solution).getSolutionIdentifier();
	}

	public static String getAllAssignedQMFilter(String solution, String racfId, List<String> ldaps) {

		StringBuilder allAssignedFilter = new StringBuilder(
				getSolutionConfigCache().get(solution).getSolutionIdentifier());
		allAssignedFilter.append("'");

		if (solution.equalsIgnoreCase("Bank Operations") || solution.equalsIgnoreCase("Asset Transfer Operations")) {
			List<OperationalRole> roles = baseSolution.getUserEntitledRoles(racfId, solution, ldaps, "Unassigned");
			Iterator<OperationalRole> iterator = roles.iterator();
			while (iterator.hasNext()) {
				OperationalRole role = iterator.next();
				allAssignedFilter.append(" AND (").append(role.getFilters()).append(")");
			}
		}

		return allAssignedFilter.toString();

	}

	public static Map<String, Map<String, String>> getCaseProperties() {
		return caseProperties;
	}

	public static void setCaseProperties(Map<String, Map<String, String>> caseProperties) {
		SolutionConfigCache.caseProperties = caseProperties;
	}

}
