package org.tiaa.icm.client.domain;

import java.util.Date;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;

import org.tiaa.icm.client.serializer.JsonDateSerializer;
import org.tiaa.icm.client.utils.ICMClientUtil;

@JsonIgnoreProperties("id")
public class Comment {

	private String id;

	private String comment;

	private String type;

	private Date createdOn;

	private String createdBy;

	private String description;

	public String getComment() {
		return comment;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@JsonSerialize(using = JsonDateSerializer.class)
	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	// @Override
	// public String toString() {
	// return super.toString(this);
	// }

	@Override
	public String toString() {
		return ICMClientUtil.ObjectAsJSON(this);
	}
}
