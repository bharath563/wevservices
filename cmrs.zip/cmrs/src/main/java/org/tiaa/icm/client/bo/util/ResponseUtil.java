package org.tiaa.icm.client.bo.util;

import org.apache.log4j.Logger;

import com.filenet.api.exception.EngineRuntimeException;

import org.springframework.stereotype.Component;

import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Response;

import filenet.vw.api.VWException;

@Component
public class ResponseUtil {

	// @Autowired
	// private ICMClientResponse icmClientResponse;

	static Logger LOG = Logger.getLogger(ResponseUtil.class);

	public Response createFailureResponse(Throwable e) {
		Response icmClientResponse = new Response();
		e.printStackTrace();
		if (e instanceof EngineRuntimeException) {
			EngineRuntimeException ex = (EngineRuntimeException) e;
			icmClientResponse.setErrorCode(ex.getExceptionCode().getErrorId());
			icmClientResponse.setErrorMessage(ex.getLocalizedMessage());
			icmClientResponse.setStatus(CommonConstants.ERROR);
		} else if (e instanceof NullPointerException) {
			String errorMsg = (e.getMessage() == null) ? CommonConstants.NULL_POINTER_CUSTOM_MSG : e.getMessage();
			icmClientResponse.setErrorMessage(errorMsg);
			icmClientResponse.setStatus(CommonConstants.ERROR);
		} else if ((e instanceof VWException) || (e instanceof Exception)) {
			icmClientResponse.setErrorMessage(e.getLocalizedMessage());
			icmClientResponse.setStatus(CommonConstants.ERROR);
		}
		return icmClientResponse;
	}

	public Response createSuccessResponse(String id) {
		Response icmClientResponse = new Response();
		icmClientResponse.setId(id);
		icmClientResponse.setStatus(CommonConstants.SUCCESS);
		return icmClientResponse;
	}

	/*
	 * public ResponseEntity<String> createResponse(Object responseObject,
	 * Throwable cause) { String responseJson = null; ObjectMapper objectMapper
	 * = new ObjectMapper(); ResponseEntity<String> responseEntity = null; try {
	 * responseJson = objectMapper.writeValueAsString(responseObject); } catch
	 * (Exception e) { if (responseObject instanceof ResponseList) {
	 * ResponseList responseList = (ResponseList) responseObject;
	 * responseList.setErrorMessage(e.getMessage());
	 * responseList.setStatus(CommonConstants.FAILURE); responseEntity = new
	 * ResponseEntity<String>(responseJson, HttpStatus.INTERNAL_SERVER_ERROR); }
	 * else if (responseObject instanceof Response) { Response resp = (Response)
	 * responseObject; resp.setErrorMessage(e.getMessage());
	 * resp.setStatus(CommonConstants.FAILURE); responseEntity = new
	 * ResponseEntity<String>(responseJson, HttpStatus.INTERNAL_SERVER_ERROR); }
	 * }
	 * 
	 * if (cause != null) { responseEntity = new
	 * ResponseEntity<String>(responseJson, HttpStatus.INTERNAL_SERVER_ERROR); }
	 * 
	 * if (cause == null) { System.out.println("responseJson, when cause null:"
	 * + responseJson);
	 * 
	 * responseEntity = new ResponseEntity<String>(responseJson, HttpStatus.OK);
	 * 
	 * } System.out.println("responseEntity:" + responseEntity.getBody());
	 * return responseEntity;
	 * 
	 * }
	 * 
	 * public static String convertToJSONResponse(Object object, String
	 * errorMessage) throws JsonGenerationException, JsonMappingException,
	 * IOException { LOG.debug("Entered convertToJSONResponse"); Response
	 * response = new Response(); // response.setError(error);
	 * response.setErrorMessage(errorMessage); response.setResults(object);
	 * ObjectMapper mapper = new ObjectMapper();
	 * mapper.setPropertyNamingStrategy(new
	 * ReplaceNamingStrategy(Collections.singletonMap("results",
	 * ICMClientUtil.stringAfterGivenChar(object.getClass().getName(),
	 * ".").toLowerCase()))); try { return mapper.writeValueAsString(response);
	 * } catch (JsonGenerationException e) {
	 * response.setErrorMessage(response.getErrorMessage() + "/n" +
	 * e.getMessage()); return mapper.writeValueAsString(response); } catch
	 * (JsonMappingException e) {
	 * response.setErrorMessage(response.getErrorMessage() + "/n" +
	 * e.getMessage()); return mapper.writeValueAsString(response); } catch
	 * (IOException e) { response.setErrorMessage(response.getErrorMessage() +
	 * "/n" + e.getMessage()); return mapper.writeValueAsString(response); } }
	 */

}
