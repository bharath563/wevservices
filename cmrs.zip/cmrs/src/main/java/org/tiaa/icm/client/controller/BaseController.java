package org.tiaa.icm.client.controller;

import java.util.ArrayList;
import java.util.List;

import javax.security.auth.Subject;
import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.tiaa.icm.client.bo.engine.ProcessBO;
import org.tiaa.icm.client.bo.security.P8Authentication;
import org.tiaa.icm.client.domain.ResponseList;
import org.tiaa.icm.client.provider.AppPropertiesProvider;
import org.tiaa.icm.client.utils.ICMClientUtil;

import filenet.vw.api.VWException;
import filenet.vw.api.VWSession;

public abstract class BaseController {

	static Logger LOG = Logger.getLogger(BaseController.class);

	@Autowired
	private ProcessBO processBO;

	@Autowired
	private P8Authentication p8Authentication;

	public ResponseEntity<?> successResponse(Object entity) {
		return new ResponseEntity<Object>(entity, HttpStatus.OK);
	}

	public ResponseEntity<?> errorResponse(String errMsg, HttpStatus statusCode) {
		return new ResponseEntity<Object>(errMsg, statusCode);
	}

	public Subject getSubject(HttpServletRequest request, String racfId, String password) throws LoginException {
		LOG.debug("Get Subject for -->" + racfId);
		authenticateUser(request, racfId, password);
		Subject subj = (Subject) request.getSession().getAttribute("SUBJECT");
		LOG.debug("Subject Principal Name--> " + subj.getPrincipals().iterator().next().getName());
		return subj;
	}

	private void authenticateUser(HttpServletRequest request, String racfId, String password) throws LoginException {
		HttpSession session = null;
		if (request.getSession(false) != null) {
			session = request.getSession(false);
			if (session.getId().toString().equals(session.getAttribute("SESSIONID").toString())) {
				LOG.debug("Same session");
				return;
			}
		}
		Subject subject = p8Authentication.login(racfId, password);
		session = request.getSession(true);
		session.setAttribute("SUBJECT", subject);
		session.setAttribute("SESSIONID", session.getId());
	}

	public ResponseList callResponseSubList(List responseList, String startStr) {
		int noOfRecPerPage = AppPropertiesProvider.getIntProperty("noOfRecPerPage");
		int maxSize = 0;
		int start = ICMClientUtil.convertStrToInt(startStr);
		start = (start > 0) ? start : 1;
		int end = (start > 0) ? (start + (noOfRecPerPage - 1)) : noOfRecPerPage;

		ResponseList response = new ResponseList();
		response.setStart(start);
		if (responseList != null) {
			List pagedList = new ArrayList();

			if (responseList.size() >= end) {
				pagedList = responseList.subList(start - 1, end);
			} else if (responseList.size() >= start) {
				pagedList = responseList.subList(start - 1, responseList.size());
			}
			response.setResults(pagedList);
			if ((pagedList != null) && (pagedList.size() > 0)) {
				maxSize = pagedList.size();
				response.setTotalRecords(responseList.size());
			}
			if (maxSize > 0) {
				response.setEnd((start + maxSize) - 1);
			}
		} else {
			response.setError("No Data Found");
		}
		return response;
	}

	public VWSession getVWSession(HttpServletRequest request) throws VWException {
		VWSession vwSession = (VWSession) request.getSession().getAttribute("VWSESSION");
		if (vwSession == null) {
			vwSession = processBO.getVWSession();
			request.getSession().setAttribute("VWSESSION", vwSession);
		}
		return vwSession;
	}

	public void logOffSession(VWSession vwSession) throws VWException {
		if (vwSession != null) {
			vwSession.logoff();
			vwSession = null;
		}
	}

}
