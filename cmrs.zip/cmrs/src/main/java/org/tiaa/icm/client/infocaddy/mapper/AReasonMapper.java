package org.tiaa.icm.client.infocaddy.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.type.Alias;

import org.tiaa.icm.client.infocaddy.domain.AReason;

@Alias("aReason")
public interface AReasonMapper {
	public List<AReason> fetchReasonsByCaseIdAndTask(@Param("caseId") String caseId);

	public List<AReason> fetchReasonsByGrouopId(@Param("groupId") String groupId);

	public List<AReason> fetchReasonsByGrouopAndSet(@Param("groupId") String groupId,
			@Param("reasonSetName") String reasonSetName);
}
