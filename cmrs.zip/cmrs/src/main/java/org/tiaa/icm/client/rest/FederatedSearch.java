package org.tiaa.icm.client.rest;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import org.apache.log4j.Logger;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.http.converter.xml.MarshallingHttpMessageConverter;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.util.UriComponentsBuilder;

import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.esb.federated_document_rs.types.Document;
import org.tiaa.icm.client.esb.federated_document_rs.types.SearchResponse;
import org.tiaa.icm.client.provider.AppPropertiesProvider;

public class FederatedSearch extends BaseRestService {
	private static Logger logger = Logger.getLogger(FederatedSearch.class);

	public FederatedSearch() {

	}

	private void addMessageConverters() {
		logger.debug("Entering addMessageConverters()....");

		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();

		// add xml converter
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setClassesToBeBound(SearchResponse.class);
		MarshallingHttpMessageConverter mhmc = new MarshallingHttpMessageConverter(jaxb2Marshaller);

		List<org.springframework.http.MediaType> supportedMediaTypes = new ArrayList<org.springframework.http.MediaType>();
		supportedMediaTypes
				.add(new org.springframework.http.MediaType(CommonConstants.APPLICATION, CommonConstants.MEDIA_TYPES));
		mhmc.setSupportedMediaTypes(supportedMediaTypes);
		messageConverters.add(mhmc);

		// add form converter
		FormHttpMessageConverter fmc = new FormHttpMessageConverter();
		fmc.addPartConverter(new Jaxb2RootElementHttpMessageConverter());
		messageConverters.add(fmc);

		getRestTemplate().setMessageConverters(messageConverters);

		logger.debug("Exiting addMessageConverters()....");

	}

	/**
	 * Get CCP Document metadata through FDRS Rest Service call.
	 *
	 * Set the message converters. Call the FDRS service.
	 */

	public List<Document> getCCPDocuments(MultiValueMap<String, String> params) {
		logger.debug("Entering getCCPDocuments(MultiValueMap<String, String> params)....");

		List<Document> ccpDocumentList = new ArrayList<Document>();

		try {

			addMessageConverters();

			String fdrsSearchURL = getBaseUrl() + AppPropertiesProvider.getProperty("FDRS_SEARCH_URI");
			logger.debug("FDRSURL is " + fdrsSearchURL);

			UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(fdrsSearchURL);

			for (Entry<String, List<String>> entry : params.entrySet()) {
				builder.queryParam(entry.getKey(), entry.getValue().toArray());
			}

			URI fdrsSearchURI = builder.build().toUri();

			ResponseEntity<SearchResponse> response = getRestTemplate().exchange(fdrsSearchURI, HttpMethod.GET, null,
					SearchResponse.class);

			SearchResponse searchResponse = response.getBody();

			logger.debug("CCP Documents list from FDRS call: " + searchResponse);

			if ((null != searchResponse) && (null != searchResponse.getSearchResp())
					&& (null != searchResponse.getSearchResp().getDocuments())) {
				ccpDocumentList = searchResponse.getSearchResp().getDocuments().getDocuments();
			}

		} catch (RestClientException e) {
			logger.error("Error occured in calling FDRS Service : get operation federated-document-rs-v1 ", e);
			throw new RuntimeException(
					"Error occured in calling FDRS Service : get operation federated-document-rs-v1 ", e);
		} catch (Exception e) {
			logger.error("Error occured in calling FDRS Service : get operation federated-document-rs-v1 ", e);
			throw new RuntimeException(
					"Error occured in calling FDRS Service : get operation federated-document-rs-v1 ", e);
		}
		logger.debug("ccpDocumentList " + ccpDocumentList);

		logger.debug("Number of CCP Documents from FDRS call " + ccpDocumentList.size());

		logger.debug("Exiting getCCPDocuments(MultiValueMap<String, String> params)....");

		return ccpDocumentList;
	}

}
