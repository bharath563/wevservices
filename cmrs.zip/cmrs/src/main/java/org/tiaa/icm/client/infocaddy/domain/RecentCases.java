package org.tiaa.icm.client.infocaddy.domain;

import java.sql.Timestamp;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import org.apache.ibatis.type.Alias;

@Alias("recentCases")
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
public class RecentCases {

	/**
	 * Case Id
	 */
	private String caseId;
	/**
	 * Identifier Name
	 */
	private String identifierName;
	/**
	 * Identifier Value
	 */
	private String identifierValue;
	/**
	 * Case Started Time
	 */
	private Timestamp caseStartedTS;
	/**
	 * String representation of timestamp
	 */
	private String strCaseStartedTS;
	/**
	 * Case Status
	 */
	private String status;

	/**
	 * @return the caseId
	 */
	public String getCaseId() {
		return caseId;
	}

	/**
	 * @param caseId
	 *            the caseId to set
	 */
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	/**
	 * @return the identifierName
	 */
	public String getIdentifierName() {
		return identifierName;
	}

	/**
	 * @param identifierName
	 *            the identifierName to set
	 */
	public void setIdentifierName(String identifierName) {
		this.identifierName = identifierName;
	}

	/**
	 * @return the identifierValue
	 */
	public String getIdentifierValue() {
		return identifierValue;
	}

	/**
	 * @param identifierValue
	 *            the identifierValue to set
	 */
	public void setIdentifierValue(String identifierValue) {
		this.identifierValue = identifierValue;
	}

	/**
	 * @return the caseStartedTS
	 */
	public Timestamp getCaseStartedTS() {
		return caseStartedTS;
	}

	/**
	 * @param caseStartedTS
	 *            the caseStartedTS to set
	 */
	public void setCaseStartedTS(Timestamp caseStartedTS) {
		this.caseStartedTS = caseStartedTS;
	}

	/**
	 * @return the strCaseStartedTS
	 */
	public String getStrCaseStartedTS() {
		return strCaseStartedTS;
	}

	/**
	 * @param strCaseStartedTS
	 *            the strCaseStartedTS to set
	 */
	public void setStrCaseStartedTS(String strCaseStartedTS) {
		this.strCaseStartedTS = strCaseStartedTS;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status
	 *            the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
}
