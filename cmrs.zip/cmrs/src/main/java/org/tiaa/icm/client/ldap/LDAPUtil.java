package org.tiaa.icm.client.ldap;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import org.tiaa.icm.client.infocaddy.constant.InfoCaddyConstant;
import org.tiaa.icm.client.utils.ICMClientUtil;

@Component
public class LDAPUtil {
	private final static Logger logger = Logger.getLogger(LDAPUtil.class);

	private static String ldapProviderUrl;

	private static String ldapPrincipal;

	private static String ldapCredentials;

	private static String ldapBase;

	@Value("${LDAP-PROVIDER-URL}")
	public void setLDAPProviderUrl(String ldapProviderUrl) {
		LDAPUtil.ldapProviderUrl = ldapProviderUrl;
	}

	@Value("${LDAP-SECURITY-CREDENTIALS}")
	public void setLDAPCredentials(String ldapCredentials) {
		LDAPUtil.ldapCredentials = ldapCredentials;
	}

	@Value("${LDAP-SECURITY-PRINCIPAL}")
	public void setLDAPPrincipal(String ldapPrincipal) {
		LDAPUtil.ldapPrincipal = ldapPrincipal;
	}

	@Value("${LDAP-SEARCH-BASE}")
	public void setLDAPBase(String ldapBase) {
		LDAPUtil.ldapBase = ldapBase;
	}

	public static List<String> getLDAPs(String racfId) throws Exception {

		logger.debug("Gettting LDAPs for racId -> '" + racfId + "'");
		List<String> groups = new ArrayList<String>();
		String attribute = "memberOf";
		String filter = "CN=" + racfId;

		LdapContext ctx = getLdapContext();
		logger.debug("Successfully connected LDAP.");
		SearchControls searchCtls = new SearchControls();
		searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);

		NamingEnumeration<SearchResult> answer = ctx.search(ldapBase, filter, searchCtls);

		while (answer.hasMoreElements()) {
			SearchResult sr = answer.next();
			Attributes attrs = sr.getAttributes();
			if (attrs != null) {
				for (NamingEnumeration ae = attrs.get(attribute).getAll(); ae.hasMore();) {
					String group = ae.next().toString();
					groups.add(group.split(",")[0].split("=")[1]);
				}
			}
		}
		logger.debug("Groups for user " + racfId + ": " + groups);
		return groups;
	}

	private static LdapContext getLdapContext() throws NamingException {
		Hashtable<String, String> env = new Hashtable<String, String>();
		logger.debug("Principal --> " + ldapPrincipal);
		logger.debug("Credentials --> " + ldapCredentials);
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		env.put(Context.SECURITY_AUTHENTICATION, "simple");
		env.put(Context.SECURITY_PRINCIPAL, ldapPrincipal);
		env.put(Context.SECURITY_CREDENTIALS, ldapCredentials);
		env.put(Context.PROVIDER_URL, ldapProviderUrl);
		return new InitialLdapContext(env, null);
	}

	// get racfId from emailId for Infocaddy chatlinks.
	public static String getUserRacfid(String mail) throws NamingException, IOException {
		logger.debug("displayName: " + mail);

		if (ICMClientUtil.isEmpty(mail)) {
			return "";
		} else if (InfoCaddyConstant.SYSTEM.equalsIgnoreCase(mail)
				|| InfoCaddyConstant.PLAN_SPONSOR.equalsIgnoreCase(mail)) {
			return mail;
		}

		String racfId = "";
		String attr = "mailnickname";
		String filter = "mail=" + mail;

		LdapContext ctx = getLdapContext();
		logger.debug("Successfully connected LDAP.");
		SearchControls searchCtls = new SearchControls();
		searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);

		NamingEnumeration<SearchResult> answer = ctx.search(ldapBase, filter, searchCtls);

		// Loop through the search results
		while (answer.hasMoreElements()) {
			SearchResult sr = answer.next();
			Attributes attrs = sr.getAttributes();
			racfId = attrs.get(attr).get().toString();
		}

		logger.debug("racfId: " + racfId);

		return racfId;
	}

	/**
	 * Process an attribute to get all of its values and return as a list
	 *
	 * @param attribute
	 * @return
	 * @throws NamingException
	 */
	private static List<String> getAttributeValues(Attribute attribute) throws NamingException {
		ArrayList<String> values = new ArrayList<String>();

		for (NamingEnumeration<String> enumerator = (NamingEnumeration<String>) attribute.getAll(); enumerator
				.hasMoreElements();) {
			values.add(enumerator.nextElement());
		}

		return values;
	}

}
