package org.tiaa.icm.client.infocaddy.bo;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;

import org.apache.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import org.tiaa.icm.client.infocaddy.constant.InfoCaddyConstant;
import org.tiaa.icm.client.infocaddy.domain.AOmniProcess;
import org.tiaa.icm.client.infocaddy.domain.AOmniTransactions;
import org.tiaa.icm.client.infocaddy.domain.AReason;
import org.tiaa.icm.client.infocaddy.domain.FileHistory;
import org.tiaa.icm.client.infocaddy.domain.RepaymentDetails;
import org.tiaa.icm.client.infocaddy.json.RepaymentDetailsObject;
import org.tiaa.icm.client.infocaddy.json.Type;
import org.tiaa.icm.client.infocaddy.mapper.AReasonMapper;
import org.tiaa.icm.client.infocaddy.mapper.FileHistoryMapper;
import org.tiaa.icm.client.infocaddy.mapper.OmniProcessMapper;
import org.tiaa.icm.client.infocaddy.mapper.OmniTransactionsMapper;
import org.tiaa.icm.client.infocaddy.mapper.RepaymentDetailsMapper;
import org.tiaa.icm.client.infocaddy.utils.InfoCaddyUtil;
import org.tiaa.icm.client.rest.InfoCaddyService;
import org.tiaa.icm.client.utils.ICMClientUtil;

@Repository(value = "piInfoCaddyBO")
public class PIInfoCaddyBO implements InfoCaddyBODelegate {

	private final Logger logger = Logger.getLogger(PIInfoCaddyBO.class);

	@Autowired
	private InfoCaddyService infoCaddyService;

	@Autowired
	private RepaymentDetailsMapper repaymentDetailsMapper;

	private ObjectMapper objectMapper = new ObjectMapper();

	@Autowired
	private OmniProcessMapper omniProcessMapper;

	@Autowired
	private AReasonMapper aReasonMapper;

	@Autowired
	private FileHistoryMapper fileHistoryMapper;

	@Autowired
	private OmniTransactionsMapper omniTransactionsMapper;

	@Override
	public List<Object> getInfoCaddyDetails(String caseId, String solution, String section) throws Exception {
		logger.debug("Entering getInfoCaddyDetails(String caseId, String solution, String section...");

		List<Object> infoCaddyDetailsList = infoCaddyService.getInfoCaddyDetails(solution, caseId, section);

		if (InfoCaddyConstant.GENERAL.equalsIgnoreCase(section)) {

			infoCaddyDetailsList = processGeneralInformation(infoCaddyDetailsList, caseId, solution, section);

		}

		logger.debug("Exiting getInfoCaddyDetails(String caseId, String solution, String section...");

		return infoCaddyDetailsList;

	}

	private List<Object> processGeneralInformation(List<Object> infoCaddyDetailsList, String caseId, String solution,
			String section) throws Exception {
		logger.debug("Entering processGeneralInformation(Type[] infoCaddyDetails, String caseId)...");

		Type[] infoCaddyDetails = this.objectMapper.convertValue(infoCaddyDetailsList, Type[].class);

		infoCaddyDetailsList.clear();

		for (Type type : infoCaddyDetails) {

			// Remove HTML elements for Age Of Case
			if (!ICMClientUtil.isEmpty(type.getName())
					&& type.getName().equalsIgnoreCase(InfoCaddyConstant.AGE_OF_CASE)) {

				String ageOfCase = !ICMClientUtil.isNull(type.getValue())
						? type.getValue().toString().replaceAll("\\<.*?>", "") : "";
				type.setValue(ageOfCase);
			}

			// Remove blank propertyGroup item
			if (!ICMClientUtil.isEmpty(type.getType()) && type.getType().equalsIgnoreCase("propertyGroup")
					&& ICMClientUtil.isEmpty(type.getName())) {
				infoCaddyDetails = InfoCaddyUtil.removeRelatedCase(infoCaddyDetails, type);
			}

			// Remove Related Cases group item
			if (!ICMClientUtil.isEmpty(type.getType()) && type.getType().equalsIgnoreCase("group")
					&& type.getName().equalsIgnoreCase(InfoCaddyConstant.RELATED_CASES)) {
				infoCaddyDetails = InfoCaddyUtil.removeRelatedCase(infoCaddyDetails, type);
			}

			// Removing Blank propertyGroup item inside Content.
			List<Type> contentList = type.getContent();
			List<Type> toRemove = new ArrayList<Type>();
			if (null != contentList) {

				for (Type contentType : contentList) {

					if (!ICMClientUtil.isEmpty(contentType.getType())
							&& "propertyGroup".equalsIgnoreCase(contentType.getType())) {

						if (ICMClientUtil.isEmpty(contentType.getName()) && (contentType.getContent().size() == 0)) {
							toRemove.add(contentType);
						}
						// Parse for PropertyGroup
						List<Type> propertyContentList = contentType.getContent();
						List<Type> removeList = new ArrayList<Type>();
						if (propertyContentList != null) {
							for (Type propertyContent : propertyContentList) {

								if (ICMClientUtil.isEmpty(propertyContent.getName())
										&& (propertyContent.getContent().size() == 0)) {
									removeList.add(propertyContent);
								}

								if (!ICMClientUtil.isEmpty(propertyContent.getName())
										&& !ICMClientUtil.isNull(propertyContent.getValue())) {

									// remove chat links
									if (propertyContent.getValue().toString().contains("href=")
											&& (InfoCaddyUtil.checkChatLinksLabel(propertyContent.getName()))) {

										String chatlink = propertyContent.getValue().toString();
										chatlink = InfoCaddyUtil.getRacfId(chatlink);
										logger.debug("Chatlink: " + chatlink + " propertyContent.getName(): "
												+ propertyContent.getName());
										propertyContent.setValue(chatlink);

									}
								}
							}

							if (removeList != null) {
								for (Type removeitem : removeList) {
									propertyContentList.remove(removeitem);
								}
							}
						}
					}
				}

				if (toRemove != null) {
					for (Type removeitem : toRemove) {
						contentList.remove(removeitem);
					}
				}
			}
		}

		Map<String, List<RepaymentDetailsObject>> repaymentDetailsMap = getRepaymentDetails(caseId, solution, section);

		boolean isFullRepaymentDetailsRequired = false;

		for (Map.Entry<String, List<RepaymentDetailsObject>> entry : repaymentDetailsMap.entrySet()) {
			List<RepaymentDetailsObject> repaymentDetailsList = entry.getValue();
			if (repaymentDetailsList.size() > 10) {
				isFullRepaymentDetailsRequired = true;
				break;
			}
		}

		if (isFullRepaymentDetailsRequired) {
			repaymentDetailsMap.clear();
			repaymentDetailsMap = getFullRepaymentDetails(caseId, solution, section);
		}

		processRepaymentDetails(infoCaddyDetails, repaymentDetailsMap);

		infoCaddyDetailsList.add(infoCaddyDetails);

		logger.debug("Exiting processGeneralInformation(Type[] infoCaddyDetails, String caseId)...");

		return infoCaddyDetailsList;
	}

	private Map<String, List<RepaymentDetailsObject>> getFullRepaymentDetails(String caseId, String solution,
			String section) {

		Map<String, List<RepaymentDetailsObject>> repaymentDetailsMap = new HashMap<String, List<RepaymentDetailsObject>>();

		List<RepaymentDetailsObject> repaymentDetails = new ArrayList<RepaymentDetailsObject>();

		List<RepaymentDetails> omniTasksDetails = repaymentDetailsMapper.fetchPlanRepaymentDetails(caseId, "POST",
				"LOAN");

		for (RepaymentDetails repaymentInfo : omniTasksDetails) {

			String plan = repaymentInfo.getPlan();
			String subPlan = repaymentInfo.getSubPlan();
			String loanId = repaymentInfo.getLoanId();
			String omniStatus = repaymentInfo.getOmniStatus();
			String groupId = repaymentInfo.getGroupId();
			String type = repaymentInfo.getType();

			String omniInfoUrl = "/cases/" + caseId + "?groupId=" + groupId + "&section=" + section + "&solution="
					+ solution + "&tableName=" + type;

			if ((null == plan) || (null == subPlan) || (null == loanId)) {
				continue;
			}

			String planSubPlanKey = plan + "," + subPlan + "," + loanId;
			RepaymentDetailsObject repaymentObject = new RepaymentDetailsObject();

			if (null == repaymentInfo.getAmount()) {
				repaymentObject.setAmount("");
			} else {
				repaymentObject.setAmount(NumberFormat.getCurrencyInstance().format(repaymentInfo.getAmount()));
			}

			repaymentObject.setDate(formatInfocaddyDisplayDateToString(repaymentInfo.getOmniPostDate()));

			repaymentObject.setMethod(InfoCaddyUtil.fetchPaymentMethod(repaymentInfo));

			omniStatus = omniStatus.equalsIgnoreCase("POST") ? "Success" : omniStatus;

			repaymentObject.setStatus(omniStatus);

			if (!repaymentDetailsMap.containsKey(planSubPlanKey)) {
				repaymentDetails = new ArrayList<RepaymentDetailsObject>();
			}

			repaymentObject.setOmniInfoUrl(omniInfoUrl);

			repaymentDetails.add(repaymentObject);

			repaymentDetailsMap.put(planSubPlanKey, repaymentDetails);
		}

		return repaymentDetailsMap;

	}

	private void processRepaymentDetails(Type[] infoCaddyDetails,
			Map<String, List<RepaymentDetailsObject>> repaymentDetailsMap) {

		logger.debug(
				"Entering processRepaymentDetails(Type[] infoCaddyDetails, Map<String, List<RepaymentDetailsObject>> repaymentDetailsMap)...");

		for (Type type : infoCaddyDetails) {

			List<Type> contentTypeList = type.getContent();

			if (null != contentTypeList) {

				List<Type> subPlanTypeList = type.getContent();

				if (null != subPlanTypeList) {

					for (Type subPlanType : subPlanTypeList) {

						List<Type> repaymentDetailsTypeList = subPlanType.getContent();

						boolean repaymentDetailsAvailable = false;
						List<RepaymentDetailsObject> repaymentDetailsObjectList = new ArrayList<RepaymentDetailsObject>();

						if (null != repaymentDetailsTypeList) {

							for (Type repaymentDetailsType : repaymentDetailsTypeList) {

								if (!ICMClientUtil.isEmpty(repaymentDetailsType.getName())
										&& repaymentDetailsType.getName().contains("data-detailuri")) {
									repaymentDetailsType.setName(null);
									repaymentDetailsType.setType(null);
								}

								if (!repaymentDetailsAvailable) {

									repaymentDetailsObjectList.addAll(getRepaymentDetailsListFromMap(type, subPlanType,
											repaymentDetailsType, repaymentDetailsMap));
									repaymentDetailsAvailable = true;

								}

								if ((repaymentDetailsObjectList.size() > 0) && repaymentDetailsAvailable) {

									if (!ICMClientUtil.isEmpty(repaymentDetailsType.getTitle()) && repaymentDetailsType
											.getTitle().equalsIgnoreCase(InfoCaddyConstant.REPAYMENT_DETAILS)) {

										repaymentDetailsType.setName(InfoCaddyConstant.REPAYMENT_DETAILS);
										repaymentDetailsType.setValue(repaymentDetailsObjectList);
										repaymentDetailsType.setType("property");

										// Remove Data, Fields and Title as we
										// have everything under property.
										repaymentDetailsType.setData(null);
										repaymentDetailsType.setFields(null);
										repaymentDetailsType.setTitle(null);

									}
								}

							}
						}
					}
				}
			}

		}

		logger.debug(
				"Exiting processRepaymentDetails(Type[] infoCaddyDetails, Map<String, List<RepaymentDetailsObject>> repaymentDetailsMap)...");
	}

	private List<RepaymentDetailsObject> getRepaymentDetailsListFromMap(Type type, Type subPlanType,
			Type repaymentDetailsType, Map<String, List<RepaymentDetailsObject>> repaymentDetailsMap) {

		logger.debug(
				"Entering getRepaymentDetailsListFromMap(Type type, Type subPlanType, Type repaymentDetailsType, Map<String, List<RepaymentDetailsObject>> repaymentDetailsMap)...");

		List<RepaymentDetailsObject> repaymentDetailsList = new ArrayList<RepaymentDetailsObject>();

		if (!ICMClientUtil.isEmpty(type.getName()) && type.getName().equalsIgnoreCase("Plan")
				&& !ICMClientUtil.isEmpty(subPlanType.getName()) && subPlanType.getName().equalsIgnoreCase("SubPlan")
				&& !ICMClientUtil.isEmpty(repaymentDetailsType.getName())
				&& repaymentDetailsType.getName().equalsIgnoreCase("Loan ID")) {

			String plan = !ICMClientUtil.isNull(type.getValue()) ? type.getValue().toString() : "";
			String subPlan = !ICMClientUtil.isNull(subPlanType.getValue()) ? subPlanType.getValue().toString() : "";
			String loanId = !ICMClientUtil.isNull(repaymentDetailsType.getValue())
					? repaymentDetailsType.getValue().toString() : "";

			String planSubPlanKey = plan + "," + subPlan + "," + loanId;

			if (!ICMClientUtil.isNull(repaymentDetailsMap.get(planSubPlanKey))) {
				repaymentDetailsList.addAll(repaymentDetailsMap.get(planSubPlanKey));
			}
		}

		logger.debug(
				"Exiting getRepaymentDetailsListFromMap(Type type, Type subPlanType, Type repaymentDetailsType, Map<String, List<RepaymentDetailsObject>> repaymentDetailsMap)...");

		return repaymentDetailsList;

	}

	private Map<String, List<RepaymentDetailsObject>> getRepaymentDetails(String caseId, String solution,
			String section) {

		Map<String, List<RepaymentDetailsObject>> repaymentDetailsMap = new HashMap<String, List<RepaymentDetailsObject>>();

		List<RepaymentDetailsObject> repaymentDetails = new ArrayList<RepaymentDetailsObject>();

		List<RepaymentDetails> omniTasksDetails = repaymentDetailsMapper.fetchPlanRepaymentDetails(caseId, "POST",
				"LOAN");

		for (RepaymentDetails repaymentInfo : omniTasksDetails) {

			String plan = repaymentInfo.getPlan();
			String subPlan = repaymentInfo.getSubPlan();
			String loanId = repaymentInfo.getLoanId();
			String omniStatus = repaymentInfo.getOmniStatus();
			String groupId = repaymentInfo.getGroupId();
			String type = repaymentInfo.getType();

			String omniInfoUrl = "/cases/" + caseId + "?groupId=" + groupId + "&section=" + section + "&solution="
					+ solution + "&tableName=" + type;

			if ((null == plan) || (null == subPlan) || (null == loanId)) {
				continue;
			}
			// Payin Loan Re payment Details Section not to display completed
			// information
			// hence the AOPR completed means, either omni success or other omni
			// transactions should be pulled up.
			if ((omniStatus != null) && omniStatus.equalsIgnoreCase("Completed")) {
				continue;
			}
			// -- changes ends...
			String planSubPlanKey = plan + "," + subPlan + "," + loanId;
			RepaymentDetailsObject repaymentObject = new RepaymentDetailsObject();

			if (null == repaymentInfo.getAmount()) {
				repaymentObject.setAmount("");
			} else {
				repaymentObject.setAmount(NumberFormat.getCurrencyInstance().format(repaymentInfo.getAmount()));
			}

			repaymentObject.setDate(formatInfocaddyDisplayDateToString(repaymentInfo.getOmniPostDate()));

			repaymentObject.setMethod(InfoCaddyUtil.fetchPaymentMethod(repaymentInfo));

			omniStatus = omniStatus.equalsIgnoreCase("POST") ? "Success" : omniStatus;

			repaymentObject.setStatus(omniStatus);

			if (!repaymentDetailsMap.containsKey(planSubPlanKey)) {
				repaymentDetails = new ArrayList<RepaymentDetailsObject>();
			}

			repaymentObject.setOmniInfoUrl(omniInfoUrl);

			repaymentDetails.add(repaymentObject);

			repaymentDetailsMap.put(planSubPlanKey, repaymentDetails);
		}

		return repaymentDetailsMap;
	}

	private String formatInfocaddyDisplayDateToString(Date dt) {

		if (dt == null) {
			return null;
		}

		SimpleDateFormat sdf = new SimpleDateFormat(InfoCaddyConstant.INFOCADDY_DISPLAY_DATE_FORMAT);

		return sdf.format(dt);
	}

	public List<Object> getOmniDetails(String groupId, String tableName) throws Exception {

		logger.debug("Entering getOmniDetails(String groupId, String tableName)...");

		List<Object> infoCaddyDetailsList = new ArrayList<Object>();

		List<AOmniProcess> omniInfoList = omniProcessMapper.fetchOmniProcess(groupId);

		if ((null != tableName) && "Omni".equalsIgnoreCase(tableName)
				&& ((omniInfoList != null) && (omniInfoList.size() > 1))) {

			for (AOmniProcess omniProcess : omniInfoList) {

				infoCaddyDetailsList.add(fetchMultipleOmniInfo(omniProcess, groupId));

			}

		} else {

			infoCaddyDetailsList.add(fetchOmniInfo(groupId, tableName));

		}

		logger.debug("Exiting getOmniDetails(String groupId, String tableName)...");

		return infoCaddyDetailsList;

	}

	private Map<String, String> fetchOmniInfo(String groupId, String tableName) {

		Map<String, String> omniInfoMap = new HashMap<String, String>();

		if ((null != tableName) && "Omni".equalsIgnoreCase(tableName)) {
			List<AOmniProcess> omniInfoList = omniProcessMapper.fetchOmniProcess(groupId);
			if ((omniInfoList != null) && (omniInfoList.size() > 0)) {
				AOmniProcess omniProcess = omniInfoList.get(0);

				omniInfoMap.put("Folder Name", omniProcess.getOmniFolderName());
				omniInfoMap.put("Trade Date", formatTradeDate(omniProcess.getOmniTradeDateTS()));
				omniInfoMap.put("Sequence Number", omniProcess.getOmniSequenceNum());
				omniInfoMap.put("Status", omniProcess.getOmniStatus());

				String errorCode = omniProcess.getOmniErrorCode();
				omniInfoMap.put("Error Code", (null == errorCode) ? "" : errorCode);

				String errMsg = omniProcess.getOmniErrorMsg();
				omniInfoMap.put("Fail Reason(s)", (null == errMsg) ? "" : errMsg);
			}

			populateReasons(groupId, omniInfoMap);
			populateIdentifiers(groupId, omniInfoMap);
		}

		else if ((null != tableName) && "OmniBatch".equalsIgnoreCase(tableName)) {

			AOmniTransactions omniTransaction = omniTransactionsMapper.fetchLoanOmniTransaction(new Long(groupId));

			if (null != omniTransaction) {

				omniInfoMap.put("Folder Name", omniTransaction.getOmniFolderName());
				omniInfoMap.put("Trade Date", omniTransaction.getOmniTradeDate());

				// omniInfoMap.put("Sequence
				// Number",omniTransaction.getOmniSequenceNum());

				String omniStatus = omniTransaction.getOmniStatus() == null ? "" : omniTransaction.getOmniStatus();
				omniStatus = omniStatus.equalsIgnoreCase("POST") ? "Success" : omniStatus;
				omniInfoMap.put("Status", omniStatus);

				String errorCode = omniTransaction.getOmniErrorCode();
				omniInfoMap.put("Error Code", (null == errorCode) ? "" : errorCode);

				String errMsg = omniTransaction.getOmniErrorMessage();
				omniInfoMap.put("Fail Reason(s)", (null == errMsg) ? "" : errMsg);

			}
		}

		return omniInfoMap;

	}

	private Map<String, String> fetchMultipleOmniInfo(AOmniProcess omniProcess, String groupId) {

		Map<String, String> omniInfoMap = new HashMap<String, String>();

		omniInfoMap.put("Folder Name", omniProcess.getOmniFolderName());
		omniInfoMap.put("Trade Date", formatTradeDate(omniProcess.getOmniTradeDateTS()));
		omniInfoMap.put("Sequence Number", omniProcess.getOmniSequenceNum());
		omniInfoMap.put("Status", omniProcess.getOmniStatus());

		String errorCode = omniProcess.getOmniErrorCode();
		omniInfoMap.put("Error Code", (null == errorCode) ? "" : errorCode);

		String errMsg = omniProcess.getOmniErrorMsg();
		omniInfoMap.put("Fail Reason(s)", (null == errMsg) ? "" : errMsg);

		populateReasons(groupId, omniInfoMap);
		populateIdentifiers(groupId, omniInfoMap);

		return omniInfoMap;
	}

	private void populateReasons(String groupId, Map<String, String> omniInfoMap) {

		List<AReason> reasons = aReasonMapper.fetchReasonsByGrouopAndSet(groupId, "Rejected");

		StringBuilder reason = new StringBuilder();

		if ((null != reasons) && (reasons.size() > 0)) {

			for (AReason aReason : reasons) {

				reason.append(aReason.getReasonTxt());
				reason.append(",");

			}
		}

		if (reason.length() > 0) {

			omniInfoMap.put("Rejection Reason(s)", reason.substring(0, reason.length() - 1));

		}
	}

	private void populateIdentifiers(String groupId, Map<String, String> omniInfoMap) {
		List<String> identifierName = new ArrayList<String>();

		identifierName.add("Rejected By");
		identifierName.add("Rejected On");
		identifierName.add("Department");

		List<String> groupIds = new ArrayList<String>();
		groupIds.add(groupId);
		List<FileHistory> listIdentifiers = fileHistoryMapper.fetchByGroupIdAndIdentifierNames(groupIds,
				identifierName);

		if ((null != listIdentifiers) && (listIdentifiers.size() > 0)) {
			for (FileHistory identifier : listIdentifiers) {
				if (null != identifier.getIdentifierName()) {
					omniInfoMap.put(identifier.getIdentifierName().trim().replaceAll(" ", ""),
							identifier.getIdentifierValue());
				}
			}
		}
	}

	public String formatTradeDate(Date dt) {

		if (dt == null) {

			return "";

		} else {

			SimpleDateFormat sdf = new SimpleDateFormat(InfoCaddyConstant.DISPLAY_TRADE_DATE_FORMAT);
			return sdf.format(dt);

		}
	}

}
