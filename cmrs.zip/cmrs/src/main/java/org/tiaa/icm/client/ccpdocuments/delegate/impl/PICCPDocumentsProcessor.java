/**
 *
 */
package org.tiaa.icm.client.ccpdocuments.delegate.impl;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.filenet.api.property.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import org.tiaa.icm.client.ccpdocuments.delegate.CCPDocumentsDelegate;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Document;
import org.tiaa.icm.client.domain.EmailDocument;
import org.tiaa.icm.client.domain.FormatType;
import org.tiaa.icm.client.esb.federated_document_rs.types.Metadata;
import org.tiaa.icm.client.rest.FederatedSearch;
import org.tiaa.icm.client.utils.ICMClientUtil;

/**
 * @author watwe
 *
 */
@Repository(value = "piCCPDocumentsProcessor")
public class PICCPDocumentsProcessor implements CCPDocumentsDelegate {

	private static Logger logger = Logger.getLogger(PICCPDocumentsProcessor.class);

	@Autowired
	FederatedSearch federatedSearch;

	@Override
	public List<Document> getCCPDocuments(String caseId, String solutionName, Properties props) {

		logger.debug("Entering getCCPDocuments(String caseId, String solutionName, Properties props)....");

		String paymentNumbers = props.getStringValue(CommonConstants.PAYMENTNUMS);
		String orderNumbers = props.getStringValue(CommonConstants.ORDERNUMS);
		String planNumber = props.getStringValue(CommonConstants.PLAN_NUMBER);
		String caseType = "";
		String loanId = props.getStringValue(CommonConstants.LOAN_ID);

		List<Document> docList = new ArrayList<Document>();

		if (props.isPropertyPresent(CommonConstants.CASE_TYPE)) {
			caseType = props.getStringValue(CommonConstants.CASE_TYPE);
		} else if (props.isPropertyPresent(CommonConstants.TC_CASETYPE)) {
			caseType = props.getStringValue(CommonConstants.TC_CASETYPE);
		}

		if (!ICMClientUtil.isEmpty(caseType) && caseType.equalsIgnoreCase(CommonConstants.LOAN_REPAYMENT)
				&& ICMClientUtil.isEmpty(loanId)) {

			return docList;

		} else if (!ICMClientUtil.isEmpty(caseType)
				&& caseType.equalsIgnoreCase(CommonConstants.ADDITIONAL_LOAN_REPAYMENT)
				&& ICMClientUtil.isEmpty(orderNumbers) && ICMClientUtil.isEmpty(paymentNumbers)) {

			return docList;

		}

		List<org.tiaa.icm.client.esb.federated_document_rs.types.Document> ccpDocumentsList = federatedSearch
				.getCCPDocuments(createQueryParamMap(orderNumbers, paymentNumbers, caseType, loanId));

		docList = processCCPDocumentsResponse(ccpDocumentsList, docList, planNumber);

		// Remove duplicate DRI documents, if any.
		docList = removeDuplicateDRIDocuments(docList);

		logger.debug("Exiting getCCPDocuments(String caseId, String solutionName, Properties props)....");
		return docList;

	}

	private List<Document> processCCPDocumentsResponse(
			List<org.tiaa.icm.client.esb.federated_document_rs.types.Document> ccpDocumentsList, List<Document> docList,
			String planNumber) {

		logger.debug(
				"Entering processCCPDocumentsResponse(List<org.tiaa.icm.client.esb.federated_document_rs.types.Document> ccpDocumentsList, List<Document> docList), String planNumber....");

		for (org.tiaa.icm.client.esb.federated_document_rs.types.Document ccpDocument : ccpDocumentsList) {

			Map<String, String> ccpDocumentsMap = new HashMap<String, String>();

			String relativeUrl = ccpDocument.getDocumentLocator().getValue();

			List<Metadata> metadataList = ccpDocument.getMetadatas();

			for (Metadata metadata : metadataList) {
				ccpDocumentsMap.put(metadata.getName(), metadata.getValue());
			}

			if (ccpDocumentsMap.containsKey((CommonConstants.FROM_EMAIL_ADDRESS))
					&& ccpDocumentsMap.containsKey((CommonConstants.FROM_EMAIL_ADDRESS))
					&& ccpDocumentsMap.containsKey((CommonConstants.TO_EMAIL_ADDRESS))
					&& ccpDocumentsMap.containsKey((CommonConstants.SUBJECT_LINE))) {

				docList.add(populateCCPEmailDocumentMetadata(ccpDocumentsMap, relativeUrl, planNumber));

			} else {

				docList.add(populateCCPDocumentMetadata(ccpDocumentsMap, relativeUrl, planNumber));

			}

		}

		logger.debug(
				"Exiting processCCPDocumentsResponse(List<org.tiaa.icm.client.esb.federated_document_rs.types.Document> ccpDocumentsList, List<Document> docList), String planNumber....");

		return docList;
	}

	private EmailDocument populateCCPEmailDocumentMetadata(Map<String, String> ccpDocumentsMap, String relativeUrl,
			String planNumber) {

		logger.debug(
				"Entering populateCCPEmailDocumentMetadata(Map<String, String> ccpDocumentsMap,	String relativeUrl)....");

		EmailDocument emailDocument = new EmailDocument();
		emailDocument.setId(ccpDocumentsMap.get(CommonConstants.DOCUMENT_REQUEST_ID));

		if (!ICMClientUtil.isEmpty(ccpDocumentsMap.get(CommonConstants.DOCUMENT_REQUEST_ID))) {
			// TODO: Check Mimetype if other than application/x-services-email
			emailDocument.setMimeType(CommonConstants.CCP_EMAIL_MIMETYPE);
			emailDocument.setIdtype(CommonConstants.DRI);
		}

		emailDocument.setBusinessUnit(CommonConstants.ALL);
		emailDocument.setDocCode(CommonConstants.OUTBOUND_DOCS);
		emailDocument.setVersion("1");

		if (!ICMClientUtil.isEmpty((relativeUrl)) && relativeUrl.contains(CommonConstants.OUTBOUND_DOCS)) {
			emailDocument.setFolder(CommonConstants.OUTBOUND);
		} else if ((relativeUrl != null) && relativeUrl.contains(CommonConstants.INBOUND_DOCS)) {
			emailDocument.setFolder(CommonConstants.INBOUND);
		}

		emailDocument.setFormatType(FormatType.MobiusEmail.toString());

		emailDocument.setDocUrl(federatedSearch.getBaseUrl() + relativeUrl);

		emailDocument.setCreatedBy(CommonConstants.SYSTEM);

		// Set email sent on date as created date
		if (!ICMClientUtil.isEmpty(ccpDocumentsMap.get(CommonConstants.SEND_DATE))) {

			Date archivedDate;
			DateFormat dateFormat = new SimpleDateFormat(CommonConstants.MMDDYYYY12HR);
			DateFormat archivedDateformat = new SimpleDateFormat(CommonConstants.YYYMMDDHHMMSS);

			try {
				archivedDate = archivedDateformat.parse(ccpDocumentsMap.get(CommonConstants.SEND_DATE));
				emailDocument.setCreatedDate(dateFormat.format(archivedDate));

			} catch (ParseException e) {
				logger.error("Error occured in converting created date ", e);
			}

		}

		emailDocument.setFromEmailAddress(ccpDocumentsMap.get(CommonConstants.FROM_EMAIL_ADDRESS));
		emailDocument.setToEmailAddress(ccpDocumentsMap.get(CommonConstants.TO_EMAIL_ADDRESS));
		emailDocument.setSubjectLine(ccpDocumentsMap.get(CommonConstants.SUBJECT_LINE));

		String documentName = CommonConstants.UNKOWN;

		if (!ICMClientUtil.isEmpty(ccpDocumentsMap.get(CommonConstants.DOCUMENT_DESCRIPTION))) {
			documentName = ccpDocumentsMap.get(CommonConstants.DOCUMENT_DESCRIPTION);
		} else if (!ICMClientUtil.isEmpty(ccpDocumentsMap.get(CommonConstants.CONTENT_AREA))) {
			documentName = ccpDocumentsMap.get(CommonConstants.CONTENT_AREA);
		}

		if (!ICMClientUtil.isEmpty(ccpDocumentsMap.get(CommonConstants.PLAN_ID))) {
			documentName = documentName + "-" + ccpDocumentsMap.get(CommonConstants.PLAN_ID);
		} else if (!ICMClientUtil.isEmpty(planNumber)) {
			documentName = documentName + "-" + planNumber;
		}
		emailDocument.setDocumentName(documentName);

		if (!ICMClientUtil.isEmpty(ccpDocumentsMap.get(CommonConstants.SEND_DATE))) {

			DateFormat format = new SimpleDateFormat(CommonConstants.YYYMMDDHHMMSS);
			Date emailSendDate;
			try {
				emailSendDate = format.parse(ccpDocumentsMap.get(CommonConstants.SEND_DATE));
				DateFormat sendDateFormat = new SimpleDateFormat(CommonConstants.MMMDDYYYYHHMMSS);
				emailDocument.setSentOn((sendDateFormat.format(emailSendDate)));
			} catch (ParseException e) {
				logger.error("Error occured in converting date ", e);
			}

		}

		logger.debug(
				"Exiting populateCCPEmailDocumentMetadata(Map<String, String> ccpDocumentsMap,	String relativeUrl)....");

		return emailDocument;

	}

	private Document populateCCPDocumentMetadata(Map<String, String> ccpDocumentsMap, String relativeUrl,
			String planNumber) {
		logger.debug(
				"Entering populateCCPDocumentMetadata(Document document, Map<String, String> ccpDocumentsMap, String relativeUrl, String planNumber)....");
		Document document = new Document();
		document.setId(ccpDocumentsMap.get(CommonConstants.DOCUMENT_REQUEST_ID));

		// TODO: Check Mimetype if other than application/pdf
		if (!ICMClientUtil.isEmpty(ccpDocumentsMap.get(CommonConstants.DOCUMENT_REQUEST_ID))) {
			document.setIdtype(CommonConstants.DRI);
			document.setMimeType(CommonConstants.APPLICATION_PDF);
		}

		document.setBusinessUnit(CommonConstants.ALL);
		document.setDocCode(CommonConstants.OUTBOUND_DOCS);
		document.setVersion("1");

		if (!ICMClientUtil.isEmpty(relativeUrl) && relativeUrl.contains(CommonConstants.OUTBOUND_DOCS)) {
			document.setFolder(CommonConstants.OUTBOUND);
		} else if (!ICMClientUtil.isEmpty(relativeUrl) && relativeUrl.contains(CommonConstants.INBOUND_DOCS)) {
			document.setFolder(CommonConstants.INBOUND);
		}

		document.setFormatType(FormatType.Document.toString());

		document.setDocUrl(federatedSearch.getBaseUrl() + relativeUrl);

		String documentName = CommonConstants.UNKOWN;
		if (!ICMClientUtil.isEmpty(ccpDocumentsMap.get(CommonConstants.DOCUMENT_DESCRIPTION))) {
			documentName = ccpDocumentsMap.get(CommonConstants.DOCUMENT_DESCRIPTION);
		}

		if (!ICMClientUtil.isEmpty(ccpDocumentsMap.get(CommonConstants.PLAN_ID))) {

			documentName = documentName + "-" + ccpDocumentsMap.get(CommonConstants.PLAN_ID);

		} else if (!ICMClientUtil.isEmpty(planNumber)) {

			documentName = documentName + "-" + planNumber;
		}
		document.setDocumentName(documentName);

		document.setCreatedBy(CommonConstants.SYSTEM);

		if (!ICMClientUtil.isEmpty(ccpDocumentsMap.get(CommonConstants.ARCHIVED_DATE))) {

			Date archivedDate;
			DateFormat dateFormat = new SimpleDateFormat(CommonConstants.MMDDYYYY12HR);
			DateFormat archivedDateformat = new SimpleDateFormat(CommonConstants.MMMDDYYYYHHMMSS);

			try {
				archivedDate = archivedDateformat.parse(ccpDocumentsMap.get(CommonConstants.ARCHIVED_DATE));
				document.setCreatedDate(dateFormat.format(archivedDate));

			} catch (ParseException e) {
				logger.error("Error occured in converting archived date ", e);
			}

		}

		logger.debug(
				"Exiting populateCCPDocumentMetadata(Map<String, String> ccpDocumentsMap, String relativeUrl, String planNumber)....");
		return document;
	}

	private MultiValueMap<String, String> createQueryParamMap(String orderNumbers, String paymentNumbers,
			String caseType, String loanId) {

		logger.debug(
				"Entering createQueryParamMap(String orderNumbers, String paymentNumbers, String caseType, String loanId)....");
		MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<String, String>();

		if (!ICMClientUtil.isEmpty(caseType) && caseType.equalsIgnoreCase(CommonConstants.LOAN_REPAYMENT)) {

			queryParams.add(CommonConstants.TRANSACTION_ID, CommonConstants.LOAN + loanId);

		} else {

			if (!ICMClientUtil.isEmpty(orderNumbers)) {
				for (String orderNumber : orderNumbers.split(CommonConstants.DELIMITER_COMMA)) {
					queryParams.add(CommonConstants.TRANSACTION_ID, CommonConstants.ORCH + orderNumber);
				}
			}

			if (!ICMClientUtil.isEmpty(paymentNumbers)) {
				for (String paymentNumber : paymentNumbers.split(CommonConstants.DELIMITER_COMMA)) {
					queryParams.add(CommonConstants.TRANSACTION_ID, CommonConstants.ORCH + paymentNumber);
				}
			}
		}

		queryParams.add(CommonConstants.DOC_CODE, CommonConstants.OUTBOUND_DOCS);
		queryParams.add(CommonConstants.VESRION, "1");
		queryParams.add(CommonConstants.BUSINESS_UNIT_CODE, CommonConstants.ALL);
		queryParams.add(CommonConstants.DELIVERY_METHOD, CommonConstants.ED);
		queryParams.add(CommonConstants.DELIVERY_METHOD, CommonConstants.EM);
		queryParams.add(CommonConstants.DELIVERY_METHOD, CommonConstants.PR);

		logger.debug(
				"Exiting createQueryParamMap(String orderNumbers, String paymentNumbers, String caseType, String loanId)....");
		return queryParams;

	}

	private List<Document> removeDuplicateDRIDocuments(List<Document> ccpDocumentList) {
		logger.debug("Entering removeDuplicateDRIDocuments(List<Document> ccpDocumentList)....");

		Map<String, Document> ccpDocumentsMap = new HashMap<String, Document>();

		for (Document document : ccpDocumentList) {
			String dri = document.getId();
			if (!ccpDocumentsMap.containsKey(dri)) {
				ccpDocumentsMap.put(dri, document);
			}
		}

		logger.debug("Exiting removeDuplicateDRIDocuments(List<Document> ccpDocumentList)....");
		return new ArrayList<Document>(ccpDocumentsMap.values());

	}

}
