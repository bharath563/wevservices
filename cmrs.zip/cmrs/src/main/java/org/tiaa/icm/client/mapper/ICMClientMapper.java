package org.tiaa.icm.client.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import org.tiaa.icm.client.utils.ICMClientMap;

public interface ICMClientMapper {
	@Select("SELECT CASE_TYPE_KEY KEY, CASE_TYPE_NAME VALUE FROM CMREPORTING.K_CASE_TYPE ORDER BY CASE_TYPE_KEY")
	public List<ICMClientMap> getCaseTypes();

	@Select("SELECT STATUS_KEY KEY, STATUS_NAME VALUE FROM CMREPORTING.K_STATUS WHERE STATUS_CLASS='Case' ORDER BY STATUS_KEY")
	public List<ICMClientMap> getStatuses();

	@Select("SELECT CHANNEL_KEY KEY, UPPER(CHANNEL_NAME) VALUE FROM  CMREPORTING.K_CHANNEL ORDER BY CHANNEL_KEY")
	public List<ICMClientMap> getChannels();

	@Select("SELECT SOLUTION_TYPE_KEY KEY, SOLUTION_NAME VALUE FROM CMREPORTING.K_SOLUTION_TYPE ORDER BY SOLUTION_TYPE_KEY")
	public List<ICMClientMap> getSolutions();

	@Select("SELECT UW_REQUEST_STATUS KEY, CM_CASE_STATUS VALUE FROM CMREPORTING.UW_CM_CASE_STATUS_MAPPING ORDER BY UW_REQUEST_STATUS")
	public List<ICMClientMap> getCaseMappingStatuses();

}
