package org.tiaa.icm.client.provider;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

public class AppPropertiesProvider {
	private static Logger LOG = Logger.getLogger(AppPropertiesProvider.class);

	private static Map<String, String> appPropsMap = new HashMap<String, String>();

	public AppPropertiesProvider() {
		Properties prop = new Properties();
		InputStream input = null;
		try {
			input = AppPropertiesProvider.class.getResourceAsStream("/org/tiaa/icm/client/app.properties");
			prop.load(input);
			for (final String name : prop.stringPropertyNames()) {
				appPropsMap.put(name, prop.getProperty(name));
			}
		}
		catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public static String getProperty(String key) {
		return appPropsMap.get(key);
	}

	public static int getIntProperty(String key) {
		String value = appPropsMap.get(key);
		try {
			return Integer.parseInt(value);
		}
		catch (NumberFormatException e) {
			LOG.error("Error in Number Format: " + e.getMessage());
			throw e;
		}
	}
}
