package org.tiaa.icm.client.domain.entitlement;

import java.util.List;

public class OperationalRole {

	private String roleName;

	private List<String> queueNames;

	private String filters;

	private String locationId;

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public List<String> getQueueNames() {
		return queueNames;
	}

	public OperationalRole setQueueNames(List<String> queueNames) {
		this.queueNames = queueNames;
		return this;
	}

	public String getFilters() {
		return filters;
	}

	public OperationalRole setFilters(String filters) {
		this.filters = filters;
		return this;
	}

	public String getRoleName() {
		return roleName;
	}

	public OperationalRole setRoleName(String roleName) {
		this.roleName = roleName;
		return this;
	}

}
