package org.tiaa.icm.client.domain;

public class PingResponse {
	private String service;
	private String pingDateTime;
	private String hostName;
	private String ipaddress;
	private String healthCheck;
	private Components components;

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getPingDateTime() {
		return pingDateTime;
	}

	public void setPingDateTime(String pingDateTime) {
		this.pingDateTime = pingDateTime;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getIpaddress() {
		return ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}

	public String getHealthCheck() {
		return healthCheck;
	}

	public void setHealthCheck(String healthCheck) {
		this.healthCheck = healthCheck;
	}

	public Components getComponents() {
		return components;
	}

	public void setComponents(Components components) {
		this.components = components;
	}

}
