package org.tiaa.icm.client.domain.entitlement;

public class Properties {

	private String displayName;

	private String type;

	// private int length;

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	/*
	 * public int getLength() { return length; }
	 * 
	 * public void setLength(int length) { this.length = length; }
	 */

}
