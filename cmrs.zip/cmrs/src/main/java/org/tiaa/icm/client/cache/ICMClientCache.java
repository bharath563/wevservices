package org.tiaa.icm.client.cache;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

import org.tiaa.icm.client.bean.ICMClientBean;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.ldap.LDAPUtil;
import org.tiaa.icm.client.mapper.ICMClientMapper;
import org.tiaa.icm.client.provider.AppPropertiesProvider;
import org.tiaa.icm.client.utils.ICMClientUtil;

public class ICMClientCache {
	private static Logger logger = Logger.getLogger(ICMClientCache.class);

	private static Map<String, String> caseTypeMap;

	private static Map<String, String> statusMap;

	private static Map<String, String> channelMap;

	private static Map<String, String> solutionMap;

	private static Map<String, String> caseMappigStatusMap;

	private static final long maximumUsersInCache = Long
			.parseLong(AppPropertiesProvider.getProperty("maximumUsersInCache"));

	private static final long ldapCacheExpireHrs = Long
			.parseLong(AppPropertiesProvider.getProperty("ldapCacheExpireHrs"));;

	private static final long ldapCacheRefreshHrs = Long
			.parseLong(AppPropertiesProvider.getProperty("ldapCacheRefreshHrs"));

	static LoadingCache<String, List<String>> ldapCache = CacheBuilder.newBuilder().maximumSize(maximumUsersInCache)
			// each user LDAPs will be expired and refreshed on daily
			// basis...
			.expireAfterWrite(ldapCacheExpireHrs, TimeUnit.HOURS).refreshAfterWrite(ldapCacheRefreshHrs, TimeUnit.HOURS)
			.build(new CacheLoader<String, List<String>>() {
				@Override
				public List<String> load(String racfId) throws Exception {
					return LDAPUtil.getLDAPs(racfId);
				}
			});

	public ICMClientCache(ICMClientMapper icmClientMapper, ICMClientBean icmClientBean) throws Exception {
		logger.debug("Entered ICMClientCache Constructor to cache Master data");
		caseTypeMap = icmClientBean.getCaseTypes(icmClientMapper);
		statusMap = icmClientBean.getCaseStatus(icmClientMapper);
		channelMap = icmClientBean.getChannel(icmClientMapper);
		solutionMap = icmClientBean.getSolutions(icmClientMapper);
		caseMappigStatusMap = icmClientBean.getCaseMappingStatuses(icmClientMapper);

		logger.debug("Case Type Master Data===>" + caseTypeMap);
		logger.debug("Status Master Data===>" + statusMap);
		logger.debug("Channel Master Data===>" + channelMap);
		logger.debug("solutionMap Master Data===>" + solutionMap);
		logger.debug("Case Mapping Statuses Master Data===>" + caseMappigStatusMap);
	}

	public static String getCaseTypeValue(String key) {
		return caseTypeMap.get(key);
	}

	public static String getStatusValue(String key) {
		return statusMap.get(key);
	}

	public static String getChannelValue(String key) {
		return channelMap.get(key);
	}

	public static String getCaseTypeKey(String value) {
		for (Map.Entry<String, String> entry : caseTypeMap.entrySet()) {
			if (value.equals(entry.getValue())) {
				return entry.getKey();
			}
		}
		return null;
	}

	public static String getStatusKey(String value) {
		for (Map.Entry<String, String> entry : statusMap.entrySet()) {
			if (value.equals(entry.getValue())) {
				return entry.getKey();
			}
		}
		return null;
	}

	public static String getChannelKey(String value) {
		for (Map.Entry<String, String> entry : channelMap.entrySet()) {
			if (value.equals(entry.getValue())) {
				return entry.getKey();
			}
		}
		return null;
	}

	public static List<String> getCaseTypeList() {
		return new ArrayList<String>(caseTypeMap.values());
	}

	public static List<String> getCaseStatusList() {
		return new ArrayList<String>(statusMap.values());
	}

	public static List<String> getChannelList() {
		return new ArrayList<String>(channelMap.values());
	}

	public static List<String> getSolutionList() {
		return new ArrayList<String>(solutionMap.values());
	}

	public static String getSolutionKey(String value) {
		return getKey(solutionMap, value);

	}

	private static String getKey(Map<String, String> map, String value) {
		String key = null;
		for (Map.Entry<String, String> entry : map.entrySet()) {
			if (value.equals(entry.getValue())) {
				key = entry.getKey();
			}
		}
		return key;
	}

	public static String getCaseMappingStatuses(String key) {
		for (Map.Entry<String, String> entry : caseMappigStatusMap.entrySet()) {
			if (key.equals(entry.getKey())) {
				return entry.getValue();
			}
		}
		return null;
	}

	public static String getUWMappingStatuses(String value) {
		if (!ICMClientUtil.isNull(value)) {
			value = value.toLowerCase();
			for (Map.Entry<String, String> entry : caseMappigStatusMap.entrySet()) {
				if (entry.getValue().toLowerCase().contains(CommonConstants.NIGOED)) {
					return entry.getKey();
				} else if (entry.getValue().toLowerCase().contains(value)) {
					return entry.getKey();
				}
			}
		}
		return null;
	}

	public static LoadingCache<String, List<String>> getLdapCache() throws NamingException, ExecutionException {
		return ldapCache;
	}

}
