package org.tiaa.icm.jaxws.client;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * The HttpRequestData is created and maintained by spring framework in HTTP
 * Session.
 *
 * @author watwe
 *
 */
@Component
@Scope("request")
@SuppressWarnings("serial")
public class HttpRequestData {

	private String userRef = null;

	public String getUserRef() {
		return userRef;
	}

	public void setUserRef(String val) {
		userRef = val;
	}
}
