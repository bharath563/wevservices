package org.tiaa.icm.client.bo.security;

import javax.security.auth.Subject;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import org.apache.log4j.Logger;

public class P8Authentication {

	static Logger LOG = Logger.getLogger(P8Authentication.class);

	public Subject login(String racfId, String password) throws LoginException {
		LOG.debug("P8Authentication -> login");
		Subject subject = null;
		UserCallbackHandler handler = new UserCallbackHandler();
		handler.setUsername(racfId);
		handler.setPassword(password);
		LoginContext context;
		context = new LoginContext("FileNetP8", handler);
		context.login();
		subject = context.getSubject();
		return subject;
	}

}
