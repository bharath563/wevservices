package org.tiaa.icm.client.domain.spi;

import java.util.List;

import org.tiaa.icm.client.domain.Event;

public interface IHistoryVisitor {

	public List<Event> visit(Comments comments);

	public List<Event> visit(Tasks tasks);

}
