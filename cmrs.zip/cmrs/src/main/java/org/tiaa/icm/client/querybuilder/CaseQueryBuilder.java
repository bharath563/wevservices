package org.tiaa.icm.client.querybuilder;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.tiaa.icm.client.cache.ICMClientCache;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.provider.AppPropertiesProvider;
import org.tiaa.icm.client.utils.ICMClientUtil;

public class CaseQueryBuilder extends QueryBuilder {

	private static Logger logger = Logger.getLogger(CaseQueryBuilder.class);
	private String DATE_FORMAT = "dd-MMM-yyyy";
	private String TIME = " 12.00.00.000000000 AM";

	public String getCaseSearchProvider(Map parameters) throws Exception {

		logger.debug("Entered getCaseSearchProvider method");
		String confirmation = (String) parameters.get("confirmation");
		List<String> pins = (List<String>) parameters.get("pins");
		String clientId = (String) parameters.get("clientId");
		String caseType = (String) parameters.get("caseType");
		String channel = (String) parameters.get("channel");
		List<String> ssns = (List<String>) parameters.get("ssns");
		String caseStatus = (String) parameters.get("caseStatus");
		String type = (String) parameters.get("type");
		String from = (String) parameters.get("from");
		String to = (String) parameters.get("to");
		String plan = (String) parameters.get("plan");
		String planIdentifier = (String) parameters.get("planIdentifier");

		String solution = (String) parameters.get("solution");

		String sortField = (String) parameters.get("sortField");
		String sortOrder = (String) parameters.get("sortOrder");

		String isCaseCreatedDateString = AppPropertiesProvider.getProperty(CommonConstants.IS_CASE_CREATED_DATE);
		Date isCaseCreatedDate = new SimpleDateFormat(CommonConstants.MMDDYYYYHHMMSS).parse(isCaseCreatedDateString);
		isCaseCreatedDateString = new SimpleDateFormat(DATE_FORMAT).format(isCaseCreatedDate);

		StringBuffer caseSearchQry = new StringBuffer();

		caseSearchQry = getHeaderQry(caseSearchQry);

		StringBuffer CASE_SEARCH_SELECT = new StringBuffer().append("SELECT distinct DC.CASE_ID ID, ")
				.append("(CASE WHEN KST.SOLUTION_NAME = '").append(CommonConstants.IS_OPERATIONS)
				.append("' AND DC.CASE_STARTED_TS < '").append(isCaseCreatedDateString)
				.append("' THEN NULL ELSE DC.ORCH_ID END) CONFIRMATION, ").append("KST.SOLUTION_NAME SOLUTION,  ")
				.append("DR.TID PIN, DR.INSTITUTION_ID CLIENTID, ").append("DC.CASE_STARTED_TS CREATEDDATE, ")
				.append("DC.UPDATED_TS MODIFIEDDATE, ")// .append("DR.REQ_RECEIVED_TS
														// REQUESTRECEIVEDDATE,
														// ")
				.append("DC.RECEIVED_TS REQUESTRECEIVEDDATE, ")// String
				// request
				// received Date
				.append("DC.CASE_STARTED_TS CREATEDDT, ").append("DC.UPDATED_TS MODIFIEDDT, ")
				.append("DC.RECEIVED_TS REQUESTRECEIVEDDT, ")// Date Request
				// received Date
				// .append("DR.REQ_RECEIVED_TS REQUESTRECEIVEDDT, ")
				.append("DC.CASE_TYPE_KEY CASE_TYPE_KEY, DR.CHANNEL_KEY CHANNEL_KEY, ")
				.append("KC.CHANNEL_NAME CHANNEL, KCT.CASE_TYPE_NAME TYPE, DC.LATEST_STATUS STATUS ");

		StringBuffer CASE_SEARCH_FROM = new StringBuffer()
				.append("FROM CMREPORTING.D_CASE DC, CMREPORTING.D_REQUEST DR, CMREPORTING.D_SOLUTION DSL, ")
				.append("CMREPORTING.K_CHANNEL KC, CMREPORTING.K_CASE_TYPE KCT, CMREPORTING.K_SOLUTION_TYPE KST ");

		StringBuffer CASE_SEARCH_WHERE = new StringBuffer()
				.append(" WHERE DC.SOLUTION_SQN = DSL.SOLUTION_SQN AND DR.REQUEST_ID = DSL.REQUEST_ID ")
				.append(" and DR.CHANNEL_KEY=KC.CHANNEL_KEY and DC.CASE_TYPE_KEY=KCT.CASE_TYPE_KEY ")
				.append(" AND DSL.SOLUTION_TYPE_KEY = KST.SOLUTION_TYPE_KEY ");

		if (!planIdentifier.equalsIgnoreCase(CommonConstants.NON_PLAN)) {

			CASE_SEARCH_SELECT.append(",DRR.PLAN_NUM PLAN ");
			CASE_SEARCH_FROM.append(", CMREPORTING.D_RET_REFERENCE DRR ");

			if (planIdentifier.equalsIgnoreCase(CommonConstants.PLAN_PAYIN)) {
				logger.debug("payin query");

				CASE_SEARCH_WHERE.append(" AND DC.CASE_ID = DRR.GROUP_ID AND KST.SOLUTION_NAME = 'Payin Operations' ");
			} else if (planIdentifier.equalsIgnoreCase(CommonConstants.PLAN_NON_PAYIN)) {
				logger.debug("non payin query");

				CASE_SEARCH_WHERE
						.append(" AND DR.REQUEST_ID = DRR.GROUP_ID  AND KST.SOLUTION_NAME != 'Payin Operations' ");
			}

			if (!ICMClientUtil.isEmpty(plan)) {

				CASE_SEARCH_WHERE.append(" AND DRR.PLAN_NUM ='" + plan + "' ");
			}

		}

		caseSearchQry.append(CASE_SEARCH_SELECT.append(CASE_SEARCH_FROM).append(CASE_SEARCH_WHERE));

		if (!ICMClientUtil.isEmpty(solution)) {
			caseSearchQry.append(" AND KST.SOLUTION_NAME ='").append(solution).append("'");
		}

		if (!ICMClientUtil.isEmpty(confirmation)) {
			caseSearchQry.append(" AND DC.ORCH_ID='").append(confirmation).append("'");
		}

		if (!ICMClientUtil.isNull(pins)) {
			Iterator<String> iter = pins.iterator();
			int count = 0;
			while (iter.hasNext()) {
				String pin = iter.next();
				if ((pins.size() > 1) && (count == 0)) {
					caseSearchQry.append(" AND DR.TID IN ('").append(pin).append("'");
				} else if ((pins.size() > 1) && (count > 0)) {
					caseSearchQry.append(", '").append(pin).append("')");
				} else if (pins.size() == 1) {
					caseSearchQry.append(" AND DR.TID IN ('").append(pin).append("')");
				}
				count++;
			}
		}

		if (!ICMClientUtil.isEmpty(clientId)) {
			caseSearchQry.append(" AND DR.INSTITUTION_ID='").append(clientId).append("'");
		}

		if (!ICMClientUtil.isEmpty(caseType)) {
			caseSearchQry.append(" AND DC.CASE_TYPE_KEY=").append(ICMClientCache.getCaseTypeKey(caseType));
		}

		if (!ICMClientUtil.isEmpty(channel)) {
			caseSearchQry.append(" AND DR.CHANNEL_KEY=").append(ICMClientCache.getChannelKey(channel.toUpperCase()));
		}
		if (!ICMClientUtil.isNull(ssns)) {
			Iterator<String> iter = ssns.iterator();
			int count = 0;
			while (iter.hasNext()) {
				String ssn = iter.next();
				if ((ssns.size() > 1) && (count == 0)) {
					caseSearchQry.append(" AND DR.SSN IN ('").append(ssn).append("'");
				} else if ((ssns.size() > 1) && (count > 0)) {
					caseSearchQry.append(", '").append(ssn).append("')");
				} else if (ssns.size() == 1) {
					caseSearchQry.append(" AND DR.SSN IN ('").append(ssn).append("')");
				}
				count++;
			}
		}

		if (!ICMClientUtil.isEmpty(caseStatus)) {
			caseSearchQry.append(" AND DC.LATEST_STATUS IN (").append(ICMClientCache.getCaseMappingStatuses(caseStatus))
					.append(")");

		}

		if (!ICMClientUtil.isEmpty(from) && !ICMClientUtil.isEmpty(to)) {

			try {
				Date fromDate = new SimpleDateFormat("yyyy-MM-dd").parse(from);
				SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT);
				from = format.format(fromDate);
			} catch (ParseException e) {
				logger.debug("Error in converting from date");
				e.printStackTrace();
			}

			try {
				Date toDate = new SimpleDateFormat("yyyy-MM-dd").parse(to);
				SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT);
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(toDate);
				calendar.add(Calendar.DATE, 1);
				to = format.format(calendar.getTime());
			} catch (ParseException e) {
				logger.debug("Error in converting to date");
			}

			if (ICMClientUtil.equals(type, "Case Creation Date")) {
				caseSearchQry.append(" AND DC.CASE_STARTED_TS BETWEEN '").append(from).append(TIME).append("' AND '")
						.append(to).append(TIME).append("'");
			} else if (ICMClientUtil.equals(type, "Case Modified Date")) {
				caseSearchQry.append(" AND DC.UPDATED_TS BETWEEN '").append(from).append(TIME).append("' AND '")
						.append(to).append(TIME).append("'");
			} else if (ICMClientUtil.equals(type, "Request Received Date")) {
				// caseSearchQry.append(" AND DR.REQ_RECEIVED_TS BETWEEN
				// '").append(from).append(TIME).append("' AND '")
				caseSearchQry.append(" AND DC.RECEIVED_TS BETWEEN'").append(from).append(TIME).append("' AND '")
						.append(to).append("'");
			}

		}
		caseSearchQry.append(" ORDER BY ");
		if (!sortField.toLowerCase().contains("date")) {
			caseSearchQry.append("lower(");
		}

		caseSearchQry.append(getSortField(sortField));

		if (!sortField.toLowerCase().contains("date")) {
			caseSearchQry.append(") ");
		}
		caseSearchQry.append(" " + sortOrder);
		caseSearchQry.append(") R)");

		logger.info("getCaseSearchProvider Query===>:" + caseSearchQry.toString());
		return caseSearchQry.toString();
	}

	private String getSortField(String sortField) {
		// ,DC.CASE_STARTED_TS,DC.UPDATED_TS,DR.REQ_RECEIVED_TS
		// Confirmation #, Case Type, PIN, Client ID, Case Status, Received
		// Date, Channel).
		// Plan #,
		String sortFieldInDB = null;
		if (sortField.equalsIgnoreCase("ID")) {
			sortFieldInDB = "DC.CASE_ID";
		} else if (sortField.equalsIgnoreCase("CONFIRMATION")) {
			sortFieldInDB = "CONFIRMATION";
		} else if (sortField.equalsIgnoreCase("caseType")) {
			sortFieldInDB = "KCT.CASE_TYPE_NAME";
		} else if (sortField.equalsIgnoreCase("PIN")) {
			sortFieldInDB = "DR.TID";
		} else if (sortField.equalsIgnoreCase("CLIENTID")) {
			sortFieldInDB = "DR.INSTITUTION_ID";
		} else if (sortField.equalsIgnoreCase("caseStatus")) {
			sortFieldInDB = "DC.LATEST_STATUS";
		} else if (sortField.equalsIgnoreCase("CREATEDDATE") || sortField.equalsIgnoreCase("Case Creation Date")) {
			sortFieldInDB = "CREATEDDATE";
		} else if (sortField.equalsIgnoreCase("MODIFIEDDATE") || sortField.equalsIgnoreCase("Case Modified Date")) {
			sortFieldInDB = "MODIFIEDDATE";
		} else if (sortField.equalsIgnoreCase("REQUESTRECEIVEDDATE")
				|| sortField.equalsIgnoreCase("Request Received Date"))

		{
			sortFieldInDB = "REQUESTRECEIVEDDATE";
		} else if (sortField.equalsIgnoreCase("CHANNEL")) {
			sortFieldInDB = "KC.CHANNEL_NAME";
		} else if (sortField.equalsIgnoreCase("SOLUTION")) {
			sortFieldInDB = "SOLUTION";
		}
		return sortFieldInDB;
	}

	public String getStatusProvider(Map parameters) {
		String caseIds = (String) parameters.get("caseIds");
		StringBuffer statusQry = new StringBuffer();
		statusQry.append(
				"SELECT DST.GROUP_ID KEY, DST.STATUS_KEY VALUE FROM CMREPORTING.D_STATUS DST WHERE DST.GROUP_ID IN (");
		statusQry.append(caseIds).append(") ");
		statusQry.append(
				"AND DST.UPDATED_TS = (SELECT MAX(DS.UPDATED_TS) FROM CMREPORTING.D_STATUS DS WHERE DS.GROUP_ID = DST.GROUP_ID)");

		logger.debug("getStatusProvider Query===>" + statusQry.toString());
		return statusQry.toString();
	}

	public String getSolutionNameAndConfirmationNumber(Map parameters) {
		String caseid = (String) parameters.get("caseid");
		StringBuffer solutionQry = new StringBuffer();
		solutionQry.append(
				"select ks.SOLUTION_NAME soultionName, d.ORCH_ID confirmation, ct.CASE_TYPE_NAME caseType from CMREPORTING.D_CASE d inner join CMREPORTING.D_SOLUTION ds on (d.SOLUTION_SQN = ds.SOLUTION_SQN)");
		solutionQry
				.append(" inner join CMREPORTING.K_SOLUTION_TYPE ks on (ds.SOLUTION_TYPE_KEY = ks.SOLUTION_TYPE_KEY) inner join CMREPORTING.K_CASE_TYPE ct on (d.CASE_TYPE_KEY = ct.CASE_TYPE_KEY) where d.case_id ='")
				.append(caseid).append("'");
		logger.debug("getStatusProvider Query===>" + solutionQry.toString());
		return solutionQry.toString();
	}

	public String getParallelCaseId(Map parameters) {
		String confirmationNumber = (String) parameters.get("confirmationNumber");
		String caseid = (String) parameters.get("caseid");
		StringBuffer boCaseIdQuery = new StringBuffer();
		boCaseIdQuery.append("select d.CASE_ID from  CMREPORTING.D_CASE d ");
		boCaseIdQuery.append(" where  d.ORCH_ID = '").append(confirmationNumber).append("' and d.CASE_ID <> '")
				.append(caseid).append("'");
		logger.debug("getStatusProvider Query===>" + boCaseIdQuery.toString());
		return boCaseIdQuery.toString();
	}

	public String getHumanTaskProvider(Map parameters) {
		String caseids = (String) parameters.get("caseids");
		StringBuffer humanTaskQry = new StringBuffer();

		humanTaskQry.append("SELECT DT.TASK_ID ID, 'Human' TYPE, DT.TASK_DISPLAY_NAME NAME,KS.STATUS_NAME STATUS, ");
		humanTaskQry.append(
				"DST.STATUS_STARTED_TS CREATEDON, DT.TASK_CREATED_BY CREATEDBY, DT.TASK_COMPLETED_TS COMPLETEDON, ");
		humanTaskQry.append(
				"KSA.STEP_ACTION COMPLETEDACTION, DS.STEP_ACTION_TAKEN_BY COMPLETEDBY FROM CMREPORTING.D_TASK DT, CMREPORTING.D_STATUS DST , CMREPORTING.K_STATUS KS, ");
		humanTaskQry.append(
				"CMREPORTING.D_STEP DS  LEFT OUTER JOIN CMREPORTING.K_STEP_ACTION KSA ON DS.STEP_ACTION_KEY = KSA.STEP_ACTION_KEY ");
		humanTaskQry.append("WHERE DT.TASK_ID = DS.TASK_ID ");
		// added
		humanTaskQry.append("AND DST.GROUP_ID=DT.TASK_ID AND DST.STATUS_KEY = KS.STATUS_KEY ");
		humanTaskQry.append("AND DT.CASE_ID in (").append(caseids).append(")");

		logger.debug("getHumanTaskProvider Query===>" + humanTaskQry.toString());
		return humanTaskQry.toString();
	}

	public String getSystemTaskProvider(Map parameters) {
		String caseids = (String) parameters.get("caseids");
		StringBuffer systemTaskQry = new StringBuffer();

		systemTaskQry.append("SELECT DT.TASK_ID ID, 'System' TYPE, DT.TASK_DISPLAY_NAME NAME, KS.STATUS_NAME STATUS,");
		systemTaskQry.append(
				"DST.STATUS_STARTED_TS CREATEDON, DT.TASK_CREATED_BY CREATEDBY, DT.TASK_COMPLETED_TS COMPLETEDON, ");
		systemTaskQry.append(
				"NULL COMPLETEDACTION, NULL COMPLETEDBY FROM CMREPORTING.D_TASK DT , CMREPORTING.D_STATUS DST , CMREPORTING.K_STATUS KS ");
		systemTaskQry.append("WHERE DT.TASK_ID NOT IN (SELECT TASK_ID FROM CMREPORTING.D_STEP) ");
		systemTaskQry.append("AND DT.CASE_ID in (").append(caseids).append(") ");
		// added
		systemTaskQry.append("AND DST.GROUP_ID=DT.TASK_ID AND DST.STATUS_KEY = KS.STATUS_KEY ");

		logger.debug("getSystemTaskProvider Query===>" + systemTaskQry.toString());
		return systemTaskQry.toString();
	}

	/*
	 * public String getRelatedCases(Map parameters) { String caseId = (String)
	 * parameters.get("caseId"); String solutionName = (String)
	 * parameters.get("solutionName"); String pathName = (String)
	 * parameters.get("pathName"); // String caseStatus = (String)
	 * parameters.get("caseStatus"); String caseType = (String)
	 * parameters.get("caseType");
	 *
	 * StringBuffer relatedCasesQry = new StringBuffer();
	 * relatedCasesQry.append("select * from ( ") .append(
	 * "SELECT c.case_id CASEID, c.orch_id CONFIRMATION, c.case_started_ts CREATEDDATE, c.case_completed_ts COMPLETEDDATE "
	 * ) .append(",'" + pathName + "' PATHNAME ") // .append(",'" + caseStatus +
	 * "' caseStatus ") .append(",KST.STATUS_NAME CASESTATUS ").append(",'" +
	 * solutionName + "' SOLUTIONNAME") .append(",'" + caseType + "' CASETYPE ")
	 * .append(
	 * " ,ROW_NUMBER() OVER  (partition by dst.group_id order by dst.updated_ts desc) as RN "
	 * ) .append("FROM cmreporting.d_case c, ").append(
	 * "cmreporting.d_solution s, ") .append("cmreporting.d_request r, "
	 * ).append("cmreporting.K_STATUS KST, ") .append(
	 * "cmreporting.D_STATUS DST ").append(
	 * "WHERE c.solution_sqn = s.solution_sqn and ") .append(
	 * "s.request_id = r.request_id ").append("AND C.case_id = DST.group_id ")
	 * .append("AND DST.STATUS_KEY = KST.STATUS_KEY ").append(
	 * " and r.request_id = ( ") .append(
	 * "SELECT soln.request_id FROM cmreporting.d_solution soln, cmreporting.d_case cs "
	 * ) .append("WHERE ").append("soln.solution_sqn = cs.solution_sqn and ")
	 * .append("cs.case_id = '" + caseId + "' ").append(") and ").append(
	 * " c.case_id <> '" + caseId + "' "); // for Payin to Payout // if
	 * (solutionName.equalsIgnoreCase("Payin Operations")) { if
	 * (!ICMClientUtil.isEmpty(solutionName) &&
	 * (CommonConstants.PAYIN_OPERATIONS).equalsIgnoreCase(solutionName)) {
	 * relatedCasesQry.append("and r.morch_id = c.orch_id  "); } else {// all
	 * other solutions relatedCasesQry.append("and r.morch_id <> c.orch_id "); }
	 * relatedCasesQry.append(" ) where rn=1");
	 *
	 * logger.debug("getRelatedCases Query===>" + relatedCasesQry.toString());
	 * return relatedCasesQry.toString(); }
	 */
	public String getTaskProvider(Map parameters) {
		String caseids = (String) parameters.get("caseids");
		String solutionName = (String) parameters.get("solutionName");
		String caseType = (String) parameters.get("caseType");
		StringBuffer taskQry = new StringBuffer();

		taskQry.append(
				"SELECT distinct ae.SEQ_NBR SEQUENCE, ae.EVENT_ID ID, ae.PARENT_ID PARENTID, CASE WHEN  opd.PROP_VALUE = 'true' then 'Human' else 'System' end as TYPE, ");
		taskQry.append(
				"ae.EVENT_CLASS EVENTCLASS, ae.CLASS_NAME NAME, ae.EVENT_NAME STATUS, ae.EVENT_STARTED_TS CREATEDON, ");
		taskQry.append(
				"CASE WHEN ae.EVENT_NAME in ('Assigned', 'Re-assigned') then ae.EVENT_ACTION_RECEIPIENT else coalesce(ae.EVENT_ACTIONED_BY, 'System') end as CREATEDBY ");
		taskQry.append(
				"FROM CMREPORTING.A_EVENT ae left outer join cmreporting.Obj_Prop_Descriptor opd on (opd.SOLUTION_NAME in (")
				.append(solutionName).append(")");
		taskQry.append(" and (opd.CASE_TYPE = 'ALL' OR opd.CASE_TYPE = '").append(caseType).append("')");
		taskQry.append(
				" and (ae.OBJECT_NAME = opd.TASK_NAME OR trim(NVL(SUBSTR(ae.CLASS_NAME, 0, INSTR(ae.CLASS_NAME, '- ')-1), ae.CLASS_NAME)) = opd.TASK_NAME ");
		taskQry.append(
				" OR trim(NVL(SUBSTR(ae.CLASS_NAME, 0, INSTR(ae.CLASS_NAME, ' for ')-1), ae.CLASS_NAME)) = opd.TASK_NAME) and opd.PROP_NAME = 'humanTask') ");
		taskQry.append("WHERE ae.EVENT_CLASS in ('Task','Step') ");
		taskQry.append("AND ae.CASE_ID in (").append(caseids).append(") ");
		taskQry.append("order by ae.EVENT_STARTED_TS desc ");

		logger.debug("getTaskProvider Query===>" + taskQry.toString());
		return taskQry.toString();
	}

	public String getCaseStatus(Map parameters) {
		StringBuffer getCaseStatusQry = new StringBuffer();
		String caseId = (String) parameters.get("caseid");
		getCaseStatusQry.append("SELECT latest_status FROM cmreporting.d_case WHERE case_id='" + caseId + "'");
		logger.debug("get case status query:" + getCaseStatusQry.toString());
		return getCaseStatusQry.toString();
	}
}
