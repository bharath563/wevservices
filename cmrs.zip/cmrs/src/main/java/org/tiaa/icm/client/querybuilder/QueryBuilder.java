package org.tiaa.icm.client.querybuilder;

import java.util.Map;

import org.apache.log4j.Logger;

import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.provider.AppPropertiesProvider;
import org.tiaa.icm.client.utils.ICMClientUtil;

public abstract class QueryBuilder {

	private static Logger logger = Logger.getLogger(QueryBuilder.class);

	public StringBuffer getHeaderQry(StringBuffer query) {
		return query.append(CommonConstants.HEADER_QRY);
	}

	public StringBuffer getTrailQry(StringBuffer query, Map parameters) {
		logger.debug("Entered getTrailQry");

		int noOfRecPerPage = AppPropertiesProvider.getIntProperty("noOfRecPerPage");
		int start = ICMClientUtil.convertStrToInt(ICMClientUtil.isNull(parameters.get("start")) ? "0" : parameters.get("start").toString());
		String startStr = (start > 0) ? String.valueOf(start) : "1";
		String endStr = String.valueOf((start > 0) ? (start + (noOfRecPerPage - 1)) : noOfRecPerPage);

		query.append(CommonConstants.TRAIL_QRY);
		query.replace(query.indexOf("{START}"), query.indexOf("{START}") + 7, startStr);
		query.replace(query.indexOf("{END}"), query.indexOf("{END}") + 5, endStr);
		return query;
	}
}
