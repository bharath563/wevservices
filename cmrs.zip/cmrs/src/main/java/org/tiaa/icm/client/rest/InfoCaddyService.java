package org.tiaa.icm.client.rest;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.util.UriComponentsBuilder;

import org.tiaa.icm.client.infocaddy.constant.InfoCaddyConstant;
import org.tiaa.icm.client.provider.AppPropertiesProvider;

public class InfoCaddyService extends BaseRestService {

	private static Logger logger = Logger.getLogger(InfoCaddyService.class);

	public List<Object> getInfoCaddyDetails(String solutionName, String caseId, String section) throws Exception {

		logger.info("Entering getInfoCaddyDetails(String solutionName, String caseId, String section...");

		List<Object> infoCaddyDetailsList = new ArrayList<Object>();

		String acmReportingServiceUrl = "";

		if (InfoCaddyConstant.GENERAL.equalsIgnoreCase(section)) {
			acmReportingServiceUrl = getBaseUrl() + AppPropertiesProvider.getProperty("GENERAL-URI");

		} else if (InfoCaddyConstant.OMNI.equalsIgnoreCase(section)) {
			acmReportingServiceUrl = getBaseUrl() + AppPropertiesProvider.getProperty("OMNI-URI");
		} else if (InfoCaddyConstant.QC.equalsIgnoreCase(section)) {
			acmReportingServiceUrl = getBaseUrl() + AppPropertiesProvider.getProperty("QC-URI");
		}

		acmReportingServiceUrl = acmReportingServiceUrl.replace("https", "http");

		Map<String, String> uriParams = new HashMap<String, String>();

		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(acmReportingServiceUrl);

		uriParams.put("solutionName", solutionName);
		uriParams.put("caseId", caseId);

		URI uriForRestTemplate = builder.buildAndExpand(uriParams).toUri();

		logger.info("ACMReporting Service URI Formed : " + uriForRestTemplate);

		ResponseEntity<?> responseEntity = getRestTemplate().exchange(uriForRestTemplate, HttpMethod.GET, null,
				List.class);

		logger.info("Received Response after consuming ACMReporting Service -> " + responseEntity);

		infoCaddyDetailsList = (List<Object>) responseEntity.getBody();

		logger.info("Exiting getInfoCaddyDetails(String solutionName, String caseId, String section...");

		return infoCaddyDetailsList;

	}

}
