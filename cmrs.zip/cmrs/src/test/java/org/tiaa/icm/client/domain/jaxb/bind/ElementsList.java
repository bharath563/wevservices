package org.tiaa.icm.client.domain.jaxb.bind;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlJavaTypeAdapter(ElementListAdapter.class)

public class ElementsList extends ArrayList {

	/**
	 *
	 */
	public List<ElementListType> entry = new ArrayList<ElementListType>();
	private static final long serialVersionUID = 1L;

}