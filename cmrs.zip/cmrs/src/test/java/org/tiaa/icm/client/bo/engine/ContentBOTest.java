package org.tiaa.icm.client.bo.engine;

import static org.mockito.Mockito.*;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.security.auth.Subject;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import org.apache.log4j.Logger;

import com.filenet.api.collection.CmTaskSet;
import com.filenet.api.collection.DocumentSet;
import com.filenet.api.collection.VersionableSet;
import com.filenet.api.core.CmTask;
import com.filenet.api.core.Connection;
import com.filenet.api.core.ContentReference;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.VersionSeries;
import com.filenet.api.core.Versionable;
import com.filenet.api.exception.EngineRuntimeException;
import com.filenet.api.property.Properties;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;
import com.filenet.api.util.Id;
import com.filenet.api.util.UserContext;

import org.springframework.context.support.FileSystemXmlApplicationContext;

import org.tiaa.icm.client.bo.security.P8Authentication;
import org.tiaa.icm.client.bo.util.CaseComparator;
import org.tiaa.icm.client.cache.SolutionConfigCache;
import org.tiaa.icm.client.constant.CommentType;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Case;
import org.tiaa.icm.client.domain.CaseSearch;
import org.tiaa.icm.client.domain.Comment;
import org.tiaa.icm.client.domain.DateRange;
import org.tiaa.icm.client.domain.Document;
import org.tiaa.icm.client.domain.Event;
import org.tiaa.icm.client.domain.FormatType;
import org.tiaa.icm.client.domain.ResponseList;
import org.tiaa.icm.client.domain.jaxb.bind.ObjectListAdapter;
import org.tiaa.icm.client.provider.AppPropertiesProvider;
import org.tiaa.icm.client.spi.fnet.IContentEngine;
import org.tiaa.icm.client.utils.ICMClientUtil;

import filenet.vw.api.VWException;
import filenet.vw.api.VWSession;

public class ContentBOTest {

	// String ejbURI = "iiop://chadvt3esfnfe2.ops.tiaa-cref.org:9810";
	// UT

	// devInt
	// String ejbURI = "iiop://chactfnet01.ops.tiaa-cref.org:9080";
	// String ejbURI = "iiop://chadvt3fis01.ops.tiaa-cref.org:9810";

	// UT & DevINT2
	private static final String OS_NAME = "FNACMTOS";

	// private static final String OS_NAME = "FNACMTOS02";
	// DevInt
	// private static final String OS_NAME = "FNACMTOS02";
	// String username = "tst_p8cm01";

	static String[] params = null;
	private static VWSession vwSession;

	// private static final String CASE_ID =
	// "{386B5397-5545-4213-B347-B7A11C604B28}";

	// private static final String CASE_ID =
	// "{5A8A5AF9-D6BD-4BA1-867B-56F87449C2A1}";
	private static final String CASE_ID = "{A6451AB0-E545-4780-B604-BF9CEC258865}";

	private static final String TASK_ID = "{D546E0C9-D327-48D0-A29F-E68A319930BF}";
	private static final String DOC_ID = "0240012015120211340120515920345020000001";
	private static final String QUEUE_NAME = "ICS_WorkIntake";
	private static final String WOB_ID = "8C903CBFB04C5F4AB4E85E73ACCE55A0";

	private static final String CASE_COMMENT_TEXT = "VJJUnitCaseComment1";
	private static final String DOC_COMMENT_TEXT = "VJJUnitDocumentComment1";

	private static final String TASK_COMMENT_TEXT = "VJJUnit Task Comment1";
	private static final String STEP_COMMENT_TEXT = "VJJUnit STEP Comment1";

	private static final String DOC_FOLDER = "";

	private static final String INVALID_ID = "INVALID_ID";
	private static final Integer PAGE_SIZE = 100;
	private static final String RACF_ID = "tst_p8cm01";

	private static final String businessUnit = "PENSION";
	private static final String DOC_CODE = "ICS_DOCS";
	private static final String DOC_NAME = "Test Document Name.doc";
	private static final String ID_TYPE = "DRI";
	private static final String MIME_TYPE = "application/msword";

	private static String DOC_ID_UPDATE = "{7A9D5A00-286C-47A6-82CA-5F5C99094422}";
	private static final String DOC_INSTANCE_ID = DOC_ID_UPDATE;
	// private String ceEJBURI = "iiop://chadvt3esfnfe2.ops.tiaa-cref.org:9810";
	private String connectionPoint = "CP_Region1";

	private HashMap<String, ObjectStore> objectStores = new HashMap<String, ObjectStore>();
	static Logger logger = Logger.getLogger(ContentBOTest.class);

	Subject subject;
	IContentEngine target;
	// Response response;

	UserContext userContext;
	String username = "atdnuw01";
	String password = "Summer16";

	// UT
	String ejbURI = "iiop://chadvt3esfnfe2.ops.tiaa-cref.org:9810";

	// DevINT2
	// String ejbURI = "iiop://dend2b3fntcm02.cloud.tiaa-cref.org:9810";

	// DevINT
	// String ejbURI = "iiop://chadvt3fis01.ops.tiaa-cref.org:9810";

	Context ic;

	@Before
	public void setUp() throws Exception {

		ceInit();
		FileSystemXmlApplicationContext context = new FileSystemXmlApplicationContext(
				"src/main/webapp/WEB-INF/icm-client-rs-v1-context.xml");

		P8Authentication authentication = new P8Authentication();
		subject = authentication.login(username, password);
		target = context.getBean(IContentEngine.class);
		// response = context.getBean(Response.class);
		userContext = UserContext.get();
		userContext.pushSubject(subject);
		vwSession = getVWSession();
	}

	private VWSession getVWSession() throws VWException {
		if (vwSession == null) {
			vwSession = new VWSession(connectionPoint);

		}

		return vwSession;
	}

	private void ceInit() {

		System.setProperty("java.security.auth.login.config",
				"C:/app/IBM/Filenet/AE/CE_API/config/jaas.conf.WebSphere");
		System.setProperty("java.naming.factory.initial", "com.ibm.websphere.naming.WsnInitialContextFactory");
		System.setProperty("com.ibm.CORBA.ConfigURL", "file:///C:/app/IBM/WAS/AppClient/properties/sas.client.props");

		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put("org.omg.CORBA.ORBClass", "com.ibm.CORBA.iiop.ORB");
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.websphere.naming.WsnInitialContextFactory");
		env.put(Context.PROVIDER_URL, ejbURI);//

		try {
			ic = new InitialContext(env);
			ic.lookup("");
		} catch (NamingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

	@Test
	public void testGetCaseProperties() {
		try {
			Case caseObject = target.getCaseDetails(OS_NAME, "{E3905D33-7151-4AB8-B8DC-C3292C9B4FF2}");
			String receivedDate = "08/20/2015 09:49:05 AM";
			Assert.assertEquals(receivedDate, caseObject.getRequestReceivedDate());
			Assert.assertNull(caseObject.getAdditionalIdentifiers().get("requestReceivedDate"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	@Ignore
	public void testGetNotes() {
		List<Comment> comments;
		try {
			comments = target.getComments(OS_NAME, CASE_ID);
			logger.debug("comments size:" + comments.size());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	// @Ignore
	public void testGetDocuments() {
		// target.getDocuments(OS_NAME,
		// "{B9B1C904-5959-4AEA-B979-9D6A62790BA0}");
		try {
			// List<Document> documents = target.getDocuments(OS_NAME,
			// "{CA3F0476-4B8C-4A58-ADE9-91491183684C}");
			List<Document> documents = target.getDocuments("FNACMTOS", "{02E71ABA-1F6C-4FC3-83AD-23AE59517EDD}");
			logger.debug(callResponseSubList(documents, "1"));
			logger.debug("comments size:" + documents.size());
			logger.debug("document Id" + documents.get(1).getId());
			// target.getDocuments(OS_NAME,
			// "{421F03B5-C2C0-4CFE-B2E0-2256A7160A0C}");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private ResponseList callResponseSubList(List responseList, String startStr) throws Exception {
		int noOfRecPerPage = AppPropertiesProvider.getIntProperty("noOfRecPerPage");
		int maxSize = 0;
		int start = ICMClientUtil.convertStrToInt(startStr);
		start = (start > 0) ? start : 1;
		int end = (start > 0) ? (start + (noOfRecPerPage - 1)) : noOfRecPerPage;

		ResponseList response = new ResponseList();
		response.setStart(start);
		if (responseList != null) {
			List pagedList = null;
			if (responseList.size() >= end) {
				pagedList = responseList.subList(start - 1, end);
			} else {
				pagedList = responseList.subList(start - 1, responseList.size());
			}
			ObjectListAdapter listAdapter = new ObjectListAdapter();
			response.setResults(listAdapter.marshal(pagedList));
			if ((pagedList != null) && (pagedList.size() > 0)) {
				maxSize = pagedList.size();
				response.setTotalRecords(responseList.size());
			}
			if (maxSize > 0) {
				response.setEnd((start + maxSize) - 1);
			}
		} else {
			response.setError("No Data Found");
		}
		return response;
	}

	@Test
	@Ignore
	public void testGetHistory() {
		try {
			// target.getHistory(OS_NAME,
			// "{6516C362-FFC1-4074-9A7B-4E3ABE7D4B4F}");

			/*
			 * logger.debug(
			 * "AT_AssetTransferRequest_000000107034 - {5653E2BF-02CF-4B40-954E-0F6283BC3E29} "
			 * ); target.getHistory(OS_NAME,
			 * "{5653E2BF-02CF-4B40-954E-0F6283BC3E29}");
			 *
			 * logger.debug(
			 * "BO_BrokerageRequest_000000107006 - {69370F2A-3E78-4BC5-8278-047A68928676} "
			 * ); target.getHistory(OS_NAME,
			 * "{69370F2A-3E78-4BC5-8278-047A68928676}");
			 *
			 * logger.debug("CS - {CED7D489-150C-4102-8E9D-5F49A5D7E36B} ");
			 * target.getHistory(OS_NAME,
			 * "{CED7D489-150C-4102-8E9D-5F49A5D7E36B}");
			 *
			 * // logger.debug("Imaging Portfolio Services - None");
			 *
			 * logger.debug(
			 * "ICS_PlanAdmin_000000106025 - {1E42A4EE-7B22-4C7A-BD7E-3AD553850E19} "
			 * ); target.getHistory(OS_NAME,
			 * "{1E42A4EE-7B22-4C7A-BD7E-3AD553850E19}");
			 *
			 * logger.debug(
			 * "IS_FileAuditing_000000100004 - {44A2412B-E6BE-4DD7-8B9E-B0E9CAA66956} "
			 * ); target.getHistory(OS_NAME,
			 * "{44A2412B-E6BE-4DD7-8B9E-B0E9CAA66956}");
			 *
			 * // logger.debug("PMO_ParticipantRequest_000000101001 - // //
			 * {7B41AD8B-D311-4705-8346-BCD4670176F1}"); // //
			 * target.getHistory(OS_NAME,
			 * "{7B41AD8B-D311-4705-8346-BCD4670176F1}");
			 *
			 * logger.debug(
			 * "PI_PayinRequest_000000100002 - {6D5444E1-B7EC-489C-9770-EF6702B483A8}"
			 * ); target.getHistory(OS_NAME,
			 * "{6D5444E1-B7EC-489C-9770-EF6702B483A8}");
			 *
			 * logger.debug(
			 * "PO_PayoutRequest_000000100020 - {E608282B-7D99-4410-92DA-07F93C6DDD88}"
			 * ); target.getHistory(OS_NAME,
			 * "{E608282B-7D99-4410-92DA-07F93C6DDD88}");
			 *
			 *
			 * //TST_P8CM08 logger.debug(
			 * "BK_FundTransfer_000000100001 - {AB8096E7-DE60-4BDE-A9C8-4CBEF2F843EA}"
			 * ); target.getHistory(OS_NAME,
			 * "{AB8096E7-DE60-4BDE-A9C8-4CBEF2F843EA}");
			 *
			 * logger.debug("Survivor Services - None");
			 *
			 *
			 * logger.debug(
			 * "TO_TransferRequest_000000100006 - {9C5453C1-A905-4FC4-A81D-51F05673ED34}"
			 * ); target.getHistory(OS_NAME,
			 * "{9C5453C1-A905-4FC4-A81D-51F05673ED34}");
			 */
			target.getHistory(OS_NAME, "{C0B9B43F-DA77-49A1-8D35-AAF9B87CEAA3}", null);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testGetHistoryBasedOnTypes() {
		try {

			// 1 IS - {A537C4E8-4FCB-48C2-B5FE-EBDBE0A3B54F}
			// 2 Payout - {BD5DF0D6-D9B9-4B90-9E55-60B750C2F7EE}
			// 3 PayIn - {992A0ED5-7725-410F-91BA-698DFCC86EE6}
			// 4 Transfer - {F1C96B43-037D-4B8E-94FE-5059153FACC2}
			// 5 PMO - {BF0765B4-D47E-4F96-936C-6EDAD4814B57}

			/*
			 * "IS:{A537C4E8-4FCB-48C2-B5FE-EBDBE0A3B54F}",
			 * "PO:{BD5DF0D6-D9B9-4B90-9E55-60B750C2F7EE}",
			 * "PI:{992A0ED5-7725-410F-91BA-698DFCC86EE6}",
			 * "TO:{F1C96B43-037D-4B8E-94FE-5059153FACC2}",
			 * "PMO:{BF0765B4-D47E-4F96-936C-6EDAD4814B57}
			 */

			final String[] caseIDs = new String[] { "IS:F5C633C9-FD4F-40AD-9D7F-496594B21DD8" };

			for (String caseID : caseIDs) {
				String[] data = caseID.split(":");
				List<Event> events = target.getHistory(OS_NAME, data[1], null);
				Iterator<Event> iterator = events.iterator();
				Assert.assertTrue(events.size() > 0);

				// Test for Case Type Event
				events.clear();
				events = target.getHistory(OS_NAME, data[1], "Case");
				iterator = events.iterator();

				while (iterator.hasNext()) {
					Event event = iterator.next();
					Assert.assertEquals("Case Event is not available", "Case", event.getType());
				}
				Assert.assertTrue("Solution" + data[0] + "has failed", events.size() == 1);
			}

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testCreateDocument() throws Exception {
		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(ID_TYPE);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(businessUnit);
		when(documentObj.getDocCode()).thenReturn(DOC_CODE);
		when(documentObj.getDocumentName()).thenReturn(DOC_NAME);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);

		Id id = target.createDocument(OS_NAME, CASE_ID, documentObj);

		Assert.assertNotNull(id);
		DOC_ID_UPDATE = id.toString();
	}

	@Test
	@Ignore
	public void testUpdateDocument() throws Exception {
		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(ID_TYPE);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(businessUnit);
		when(documentObj.getDocCode()).thenReturn(DOC_CODE);
		when(documentObj.getDocumentName()).thenReturn(DOC_NAME);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);
		Id id = target.updateDocument(OS_NAME, CASE_ID, documentObj, DOC_ID_UPDATE);

		Assert.assertNotNull(id);
		com.filenet.api.core.Document doc = getDocument(OS_NAME, CASE_ID, id.toString(), "doc");
		ContentReference contentRef = (ContentReference) doc.get_ContentElements().get(0);

		logger.debug("contentText:" + contentRef.get_ContentLocation());

		String fdrsURL = contentRef.get_ContentLocation();
		Assert.assertEquals(ID_TYPE, getValueInUrl(fdrsURL, "idtype"));
		Assert.assertEquals(DOC_ID, getValueInUrl(fdrsURL, "id"));
		Assert.assertEquals(MIME_TYPE, getValueInUrl(fdrsURL, "mimeType"));
		Assert.assertEquals("1", getValueInUrl(fdrsURL, "version"));

		Assert.assertEquals(businessUnit, getValueInUrl(fdrsURL, "bizUnit"));
		Assert.assertEquals(DOC_CODE, getValueInUrl(fdrsURL, "docCode"));

		Assert.assertEquals(DOC_NAME, doc.get_Name());// cannot change title

	}

	@Test(expected = java.lang.RuntimeException.class)
	@Ignore
	public void testCreateDocument_IdtypeNull() throws Exception {
		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(null);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(businessUnit);
		when(documentObj.getDocCode()).thenReturn(DOC_CODE);
		when(documentObj.getDocumentName()).thenReturn(DOC_NAME);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);
		Id id = target.createDocument(OS_NAME, CASE_ID, documentObj);

	}

	@Test
	@Ignore
	// folder cannot be null in real time as it is "" in Document
	public void testCreateDocument_folderEmpty() throws Exception {
		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(ID_TYPE);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(businessUnit);
		when(documentObj.getDocCode()).thenReturn(DOC_CODE);
		when(documentObj.getDocumentName()).thenReturn(DOC_NAME);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);

		Id id = target.createDocument(OS_NAME, CASE_ID, documentObj);

		Assert.assertNotNull(id);
	}

	@Test(expected = java.lang.NullPointerException.class)
	@Ignore
	public void testCreateDocument_bizUnitNull() throws Exception {
		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(ID_TYPE);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(null);
		when(documentObj.getDocCode()).thenReturn(DOC_CODE);
		when(documentObj.getDocumentName()).thenReturn(DOC_NAME);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);

		Id id = target.createDocument(OS_NAME, CASE_ID, documentObj);
	}

	@Test(expected = java.lang.NullPointerException.class)
	@Ignore
	public void testCreateDocument_doCodeNull() throws Exception {
		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(ID_TYPE);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(businessUnit);
		when(documentObj.getDocCode()).thenReturn(null);
		when(documentObj.getDocumentName()).thenReturn(DOC_NAME);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);
		Id id = target.createDocument(OS_NAME, CASE_ID, documentObj);

	}

	@Test(expected = java.lang.NullPointerException.class)
	@Ignore
	public void testCreateDocument_docNameNull() throws Exception {
		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(ID_TYPE);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(businessUnit);
		when(documentObj.getDocCode()).thenReturn(DOC_CODE);
		when(documentObj.getDocumentName()).thenReturn(null);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);

		Id id = target.createDocument(OS_NAME, CASE_ID, documentObj);

	}

	@Test(expected = java.lang.NullPointerException.class)
	@Ignore
	public void testCreateDocument_mimeTypeNull() throws Exception {
		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(ID_TYPE);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(businessUnit);
		when(documentObj.getDocCode()).thenReturn(DOC_CODE);
		when(documentObj.getDocumentName()).thenReturn(DOC_NAME);
		when(documentObj.getMimeType()).thenReturn(null);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);

		Id id = target.createDocument(OS_NAME, CASE_ID, documentObj);

	}

	/////////////////////////////////////////////////////////////////////////// CASE
	/////////////////////////////////////////////////////////////////////////// COMMENTS/////////////////////////////////////////////////////////////////////////

	private String getValueInUrl(String fdrsURL, String string) {

		String value = "";
		if (params == null) {
			params = fdrsURL.substring(fdrsURL.indexOf("?") + 1).split("&");
		}
		for (String queryParam : params) {
			int index = queryParam.indexOf("=") + 1;
			String param = queryParam.substring(0, queryParam.indexOf("="));
			if (param.equalsIgnoreCase(string)) {
				value = queryParam.substring(index);
			} else if (param.equalsIgnoreCase(string)) {
				value = queryParam.substring(index);
			} else if (param.equalsIgnoreCase(string)) {
				value = queryParam.substring(index);
			} else if (param.equalsIgnoreCase(string)) {
				value = queryParam.substring(index);
			} else if (param.equalsIgnoreCase(string)) {
				value = queryParam.substring(index);
			} else if (param.equalsIgnoreCase(string)) {
				try {
					value = URLDecoder.decode(queryParam.substring(index), "UTF-8");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		return value;
	}

	@Test
	@Ignore
	public void testAddCaseComments_Valid() throws Exception {
		Id id = target.addCaseComments(OS_NAME, CASE_ID, CASE_COMMENT_TEXT);

		List<Comment> commentsList = target.getComments(OS_NAME, CASE_ID);
		for (Comment comment : commentsList) {
			if (comment.getId().equals(id.toString())) {
				Assert.assertEquals(CASE_COMMENT_TEXT, comment.getComment());
			}
		}

	}

	@Test(expected = java.lang.NullPointerException.class)
	@Ignore
	public void testAddCaseComments_NullCaseId() throws Exception {
		Id id = target.addCaseComments(OS_NAME, null, CASE_COMMENT_TEXT);
		Assert.assertNull(id);
	}

	@Test
	@Ignore
	public void testAddCaseComments_InvalidCaseId() {
		try {
			Id id = target.addCaseComments(OS_NAME, INVALID_ID, CASE_COMMENT_TEXT);
			Assert.assertNull(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test(expected = com.filenet.api.exception.EngineRuntimeException.class)
	@Ignore
	public void testAddCaseComments_nullComments() throws Exception {

		Id id = target.addCaseComments(OS_NAME, CASE_ID, null);
		Assert.assertNull(id);
	}

	//////////////////////////////////////////////////////////////////// DOCUMENT///////////////////////////////////////////////////////////////////////////////////
	@Test
	@Ignore
	public void testAddDocumentComments_Valid() throws Exception {
		Id id = target.addDocumentComments(OS_NAME, CASE_ID, DOC_INSTANCE_ID, DOC_COMMENT_TEXT);

		List<Comment> commentsList = target.getComments(OS_NAME, CASE_ID);
		for (Comment comment : commentsList) {
			if (comment.getId().equals(id.toString())) {
				Assert.assertEquals(DOC_COMMENT_TEXT, comment.getComment());
			}
		}
	}

	@Test(expected = NullPointerException.class)
	@Ignore
	public void testAddDocumentComments_nullCaseId() throws Exception {
		Id id = target.addDocumentComments(OS_NAME, null, DOC_ID, DOC_COMMENT_TEXT);
		Assert.assertNull(id);
	}

	@Test(expected = com.filenet.api.exception.EngineRuntimeException.class)
	@Ignore
	public void testAddDocumentComments_invalidCaseId() throws Exception {
		Id id = target.addDocumentComments(OS_NAME, INVALID_ID, DOC_ID, DOC_COMMENT_TEXT);
		Assert.assertNull(id);
	}

	@Test(expected = com.filenet.api.exception.EngineRuntimeException.class)
	@Ignore
	public void testAddDocumentComments_nullDocId() throws Exception {
		Id id = target.addDocumentComments(OS_NAME, CASE_ID, null, DOC_COMMENT_TEXT);
		Assert.assertNull(id);
	}

	@Test(expected = com.filenet.api.exception.EngineRuntimeException.class)
	@Ignore
	// need to modify this method once AOP is implemented
	public void testAddDocumentComments_invalidDocId() throws Exception {
		Id id = target.addDocumentComments(OS_NAME, CASE_ID, INVALID_ID, DOC_COMMENT_TEXT);

		if (Id.isId(INVALID_ID)) {
			System.out.println("valid Id");
		} else {
			System.out.println("invalid id");
		}

		Assert.assertNull(id);
	}

	@Test(expected = com.filenet.api.exception.EngineRuntimeException.class)
	@Ignore
	public void testAddDocumentComments_nullComments() throws Exception {
		Id id = target.addDocumentComments(OS_NAME, CASE_ID, DOC_ID, null);

		Assert.assertNull(id);

	}

	////////////////////////////////////////////////////////////////////// TASK//////////////////////////////////////////////////////////////////////
	@Test
	@Ignore
	public void testAddTaskComments_valid() throws Exception {
		Id id = target.addTaskComments(OS_NAME, CASE_ID, TASK_ID, TASK_COMMENT_TEXT);

		List<Comment> commentsList = target.getComments(OS_NAME, CASE_ID);
		for (Comment comment : commentsList) {
			if (comment.getId().equals(id.toString())) {
				Assert.assertEquals(TASK_COMMENT_TEXT, comment.getComment());
			}
		}
	}

	@Test(expected = NullPointerException.class)
	@Ignore
	public void testAddTaskComments_nullCaseId() throws Exception {
		Id id = target.addTaskComments(OS_NAME, null, TASK_ID, TASK_COMMENT_TEXT);
		Assert.assertNull(id);

	}

	@Test(expected = EngineRuntimeException.class)
	@Ignore
	public void testAddTaskComments_invalidCaseId() throws Exception {
		Id id = target.addTaskComments(OS_NAME, INVALID_ID, TASK_ID, TASK_COMMENT_TEXT);
		Assert.assertNull(id);
	}

	@Test(expected = RuntimeException.class)
	@Ignore
	public void testAddTaskComments_nullTaskId() throws Exception {
		Id id = target.addTaskComments(OS_NAME, CASE_ID, null, TASK_COMMENT_TEXT);

		Assert.assertNull(id);

	}

	@Test(expected = EngineRuntimeException.class)
	@Ignore
	public void testAddTaskComments_invalidTaskId() throws Exception {
		Id id = target.addTaskComments(OS_NAME, INVALID_ID, INVALID_ID, TASK_COMMENT_TEXT);

		Assert.assertNull(id);

	}

	@Test(expected = EngineRuntimeException.class)
	@Ignore
	public void testAddTaskComments_nullComments() throws Exception {
		Id id = target.addTaskComments(OS_NAME, CASE_ID, TASK_ID, null);

		Assert.assertNull(id);
	}

	@Test(expected = EngineRuntimeException.class)
	@Ignore
	public void testAddTaskComments_taskIdCaseIdInterChanged() throws Exception {
		Id id = target.addTaskComments(OS_NAME, TASK_ID, CASE_ID, TASK_COMMENT_TEXT);

		Assert.assertNull(id);
	}

	@Test(expected = EngineRuntimeException.class)
	@Ignore
	public void testAddTaskComments_taskIdValidCaseIdTaskIdSame() throws Exception {
		Id id = target.addTaskComments(OS_NAME, TASK_ID, TASK_ID, TASK_COMMENT_TEXT);

		Assert.assertNull(id);
	}

	/////////////////////////////////////////////////////////////////////////////// ALL
	/////////////////////////////////////////////////////////////////////////////// COMMENTS/////////////////////////////////////////////////////////////////
	@Test
	@Ignore
	public void testGetComments() throws Exception {
		List<Comment> commentsList = target.getComments(OS_NAME, CASE_ID);

		for (Comment eachComment : commentsList) {
			logger.debug("comment:" + eachComment.getComment() + "-type:" + eachComment.getType());
		}
	}

	@Test
	@Ignore
	public void testGetComments_checkDescription_valid() throws Exception {
		List<Comment> commentsList = target.getComments(OS_NAME, CASE_ID);

		for (Comment eachComment : commentsList) {
			logger.debug("description:" + eachComment.getDescription() + "-type:" + eachComment.getType());
			if (eachComment.getType().equals(CommentType.CmAcmCaseComment.toString())) {
				Assert.assertEquals("Comment added to case", eachComment.getDescription());
			} else if (eachComment.getType().equals(CommentType.CmAcmTaskComment.toString())) {
				Assert.assertEquals("Comment added to null activity.", eachComment.getDescription());
			}

			// cannot test others as they keep changing for each document and
			// step.
		}
	}

	//////////////////////////////////////////////////////////////////////// STEP
	//////////////////////////////////////////////////////////////////////// COMMENTS/////////////////////////////////////////////////////////////////////////////
	@Test
	@Ignore
	public void testAddStepComments_valid() throws Exception {
		Id id = target.addStepComments(OS_NAME, CASE_ID, WOB_ID, QUEUE_NAME, STEP_COMMENT_TEXT, RACF_ID);

		List<Comment> commentsList = target.getComments(OS_NAME, CASE_ID);
		for (Comment comment : commentsList) {
			if (comment.getId().equals(id.toString())) {
				Assert.assertEquals(STEP_COMMENT_TEXT, comment.getComment());
			}
		}

	}

	@Test(expected = NullPointerException.class)
	@Ignore
	public void testAddStepComments_nullCaseId() throws Exception {
		Id id = target.addStepComments(OS_NAME, null, WOB_ID, QUEUE_NAME, STEP_COMMENT_TEXT, RACF_ID);
		Assert.assertNull(id);
	}

	@Test(expected = EngineRuntimeException.class)
	@Ignore
	public void testAddStepComments_invalidCaseId() throws Exception {
		Id id = target.addStepComments(OS_NAME, INVALID_ID, WOB_ID, QUEUE_NAME, STEP_COMMENT_TEXT, RACF_ID);
		Assert.assertNull(id);
	}

	@Test(expected = RuntimeException.class)
	@Ignore
	public void testAddStepComments_nullWobId() throws Exception {
		Id id = target.addStepComments(OS_NAME, CASE_ID, null, QUEUE_NAME, STEP_COMMENT_TEXT, RACF_ID);
		Assert.assertNull(id);
	}

	@Test(expected = RuntimeException.class)
	@Ignore
	public void testAddStepComments_invalidWobId() throws Exception {
		Id id = target.addStepComments(OS_NAME, CASE_ID, INVALID_ID, QUEUE_NAME, STEP_COMMENT_TEXT, RACF_ID);
		Assert.assertNull(id);
	}

	@Test(expected = VWException.class)
	@Ignore
	public void testAddStepComments_nullQueueName() throws Exception {
		Id id = target.addStepComments(OS_NAME, CASE_ID, WOB_ID, null, STEP_COMMENT_TEXT, RACF_ID);
		Assert.assertNull(id);
	}

	/////////////////////////////////////////////////////////////////////////////////////// WOB
	/////////////////////////////////////////////////////////////////////////////////////// ID/////////////////////////////////////////////////////////////////////
	@Test
	@Ignore
	public void getWobId() {
		Folder caseFolder = Factory.Folder.fetchInstance(getOS(OS_NAME), CASE_ID, null);
		String wobID = null;
		CmTaskSet tasks = caseFolder.get_CoordinatedTasks();
		logger.debug(tasks);
		Iterator<CmTask> taskIterator = tasks.iterator();

		while (taskIterator.hasNext()) {
			CmTask myTask = taskIterator.next();
			logger.debug("taskId on the case:" + myTask.get_Id().toString() + ",expected is:" + TASK_ID);
			if (myTask.get_Id().toString().equals(TASK_ID)) {
				wobID = myTask.getProperties().getStringValue("CmAcmProcessInstanceId");
				logger.debug("Process Instance Id after launch " + wobID);
			}

		}

	}

	//////////////////////////////////////////////// PLAN NUMBER CASE
	//////////////////////////////////////////////// SEARCH////////////////////////////////////////////////////////////////

	/*
	 * sortOrder is not mandatory here(by default ASC) as the result is finally
	 * sorted after merging all lists from PI,PO and ICS(this)
	 */
	private static final String PLAN = "100866";
	private static final int NO_OF_RECORD = 107;

	private static final String CONFIRMATION = "308470";

	private static final String CASE_TYPE = "ICS_PlanAdmin";
	private static final String CHANNEL = "Source";
	private static final String CASE_ID_FOR_PLAN = "{A7CB5AF9-AD07-4731-AC0D-41E385B12152}";
	private static final String CASE_STATUS = "In Process";
	private static final String CLIENT_ID = "000065";
	private static final String PLANS = "100865;100866;100868;100297;100300;100296";

	@Test
	public void getICSCasesForPlanNo_Channel() {

		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("channel");
		caseSearch.setPlan(PLAN);

		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		Assert.assertEquals(NO_OF_RECORD, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}

		String prevChannel = null;
		String currentChannel = null;
		for (Case case1 : casesForPlan) {
			if (prevChannel == null) {
				prevChannel = case1.getChannel();
			}
			currentChannel = case1.getChannel();
			logger.debug("prevChannel:" + prevChannel + ",currentChannel:" + currentChannel
					+ "prevChannel.compareTo(currentChannel):" + prevChannel.compareTo(currentChannel));
			Assert.assertTrue(prevChannel.compareTo(currentChannel) <= 0);
			prevChannel = currentChannel;
		}
	}

	@Test
	public void getICSCasesForPlanNo_ChannelConfirmation() {

		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("channel");
		caseSearch.setConfirmation(CONFIRMATION);
		caseSearch.setPlan(PLAN);

		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		// Assert.assertEquals(1, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}

		String prevChannel = null;
		String currentChannel = null;
		for (Case case1 : casesForPlan) {
			if (prevChannel == null) {
				prevChannel = case1.getChannel();
			}
			currentChannel = case1.getChannel();
			logger.debug("case:" + case1.toString());

			logger.debug("prevChannel:" + prevChannel + ",currentChannel:" + currentChannel
					+ "prevChannel.compareTo(currentChannel):" + prevChannel.compareTo(currentChannel));
			Assert.assertTrue(prevChannel.compareTo(currentChannel) <= 0);
			prevChannel = currentChannel;
		}
	}

	@Test
	public void getICSCasesForPlanNo_ChannelConfirmationCaseType() {

		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("channel");
		caseSearch.setConfirmation(CONFIRMATION);
		caseSearch.setPlan(PLAN);
		caseSearch.setCaseType(CASE_TYPE);

		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		// Assert.assertEquals(1, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}

		String prevChannel = null;
		String currentChannel = null;
		for (Case case1 : casesForPlan) {
			if (prevChannel == null) {
				prevChannel = case1.getChannel();
			}
			currentChannel = case1.getChannel();
			logger.debug("case:" + case1.toString());

			logger.debug("prevChannel:" + prevChannel + ",currentChannel:" + currentChannel
					+ "prevChannel.compareTo(currentChannel):" + prevChannel.compareTo(currentChannel));
			Assert.assertTrue(prevChannel.compareTo(currentChannel) <= 0);
			prevChannel = currentChannel;
		}
	}

	@Test
	public void getICSCasesForPlanNo_ChannelConfirmationCaseTypeChannel() {

		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("channel");
		caseSearch.setConfirmation(CONFIRMATION);
		caseSearch.setPlan(PLAN);
		caseSearch.setCaseType(CASE_TYPE);
		caseSearch.setChannel(CHANNEL);
		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		// Assert.assertEquals(1, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}

		String prevChannel = null;
		String currentChannel = null;
		for (Case case1 : casesForPlan) {
			if (prevChannel == null) {
				prevChannel = case1.getChannel();
			}
			currentChannel = case1.getChannel();
			logger.debug("case:" + case1.toString());

			logger.debug("prevChannel:" + prevChannel + ",currentChannel:" + currentChannel
					+ "prevChannel.compareTo(currentChannel):" + prevChannel.compareTo(currentChannel));
			Assert.assertTrue(prevChannel.compareTo(currentChannel) <= 0);
			prevChannel = currentChannel;
		}
	}

	@Test
	public void getICSCasesForPlanNo_ChannelConfirmationCaseTypeChannelClientId() {

		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("channel");
		caseSearch.setConfirmation(CONFIRMATION);
		caseSearch.setPlan(PLAN);
		caseSearch.setCaseType(CASE_TYPE);
		caseSearch.setChannel(CHANNEL);
		caseSearch.setClientId(CLIENT_ID);
		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		// Assert.assertEquals(1, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}

		String prevChannel = null;
		String currentChannel = null;
		for (Case case1 : casesForPlan) {
			if (prevChannel == null) {
				prevChannel = case1.getChannel();
			}
			currentChannel = case1.getChannel();
			logger.debug("case:" + case1.toString());

			logger.debug("prevChannel:" + prevChannel + ",currentChannel:" + currentChannel
					+ "prevChannel.compareTo(currentChannel):" + prevChannel.compareTo(currentChannel));
			Assert.assertTrue(prevChannel.compareTo(currentChannel) <= 0);
			prevChannel = currentChannel;
		}
	}

	@Test
	public void getICSCasesForPlanNo_ChannelConfirmationModifiedDate() {

		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("channel");
		caseSearch.setPlan(PLAN);
		// caseSearch.setConfirmation(CONFIRMATION);
		DateRange dateRange = new DateRange();
		dateRange.setType("Case Modified Date");
		dateRange.setFrom("2016-08-01");
		dateRange.setTo("2016-08-01");
		caseSearch.setDateRange(dateRange);
		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		Assert.assertNotSame(0, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}

		String prevChannel = null;
		String currentChannel = null;
		for (Case case1 : casesForPlan) {
			if (prevChannel == null) {
				prevChannel = case1.getChannel();
			}
			currentChannel = case1.getChannel();
			logger.debug("case:" + case1.toString());

			logger.debug("prevChannel:" + prevChannel + ",currentChannel:" + currentChannel
					+ "prevChannel.compareTo(currentChannel):" + prevChannel.compareTo(currentChannel));
			Assert.assertTrue(prevChannel.compareTo(currentChannel) <= 0);
			prevChannel = currentChannel;
		}
	}

	@Test
	public void getICSCasesForPlanNo_ChannelConfirmationReceivedDate() {

		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("channel");
		caseSearch.setPlan(PLAN);
		// caseSearch.setConfirmation(CONFIRMATION);
		DateRange dateRange = new DateRange();
		dateRange.setType("Request Received Date");
		dateRange.setFrom("2016-06-06");
		dateRange.setTo("2016-06-06");
		caseSearch.setDateRange(dateRange);
		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		Assert.assertNotSame(0, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}

		String prevChannel = null;
		String currentChannel = null;
		for (Case case1 : casesForPlan) {
			if (prevChannel == null) {
				prevChannel = case1.getChannel();
			}
			currentChannel = case1.getChannel();
			logger.debug("case:" + case1.toString());

			logger.debug("prevChannel:" + prevChannel + ",currentChannel:" + currentChannel
					+ "prevChannel.compareTo(currentChannel):" + prevChannel.compareTo(currentChannel));
			Assert.assertTrue(prevChannel.compareTo(currentChannel) <= 0);
			prevChannel = currentChannel;
		}
	}

	@Test
	public void getICSCasesForPlanNo_ChannelConfirmationCreationDate() {

		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("channel");
		caseSearch.setPlan(PLAN);
		// caseSearch.setConfirmation(CONFIRMATION);
		DateRange dateRange = new DateRange();
		dateRange.setType("Case Creation Date");
		dateRange.setFrom("2016-06-06");
		dateRange.setTo("2016-06-06");
		caseSearch.setDateRange(dateRange);
		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		Assert.assertNotSame(0, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}

		String prevChannel = null;
		String currentChannel = null;
		for (Case case1 : casesForPlan) {
			if (prevChannel == null) {
				prevChannel = case1.getChannel();
			}
			currentChannel = case1.getChannel();
			logger.debug("case:" + case1.toString());

			logger.debug("prevChannel:" + prevChannel + ",currentChannel:" + currentChannel
					+ "prevChannel.compareTo(currentChannel):" + prevChannel.compareTo(currentChannel));
			Assert.assertTrue(prevChannel.compareTo(currentChannel) <= 0);
			prevChannel = currentChannel;
		}
	}

	@Test
	public void getICSCasesForPlanNo_CONFIRMATION() {
		logger.debug("getICSCasesForPlanNo_CONFIRMATION");
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("confirmation");
		caseSearch.setPlan(PLAN);

		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		Assert.assertEquals(NO_OF_RECORD, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}

		String prevConfirmation = null;
		String currentConfirmation = null;
		for (Case case1 : casesForPlan) {
			if (prevConfirmation == null) {
				prevConfirmation = case1.getConfirmation();
			}
			currentConfirmation = case1.getConfirmation();
			logger.debug("prevChannel:" + prevConfirmation + ",currentChannel:" + currentConfirmation
					+ "prevChannel.compareTo(currentChannel):" + prevConfirmation.compareTo(currentConfirmation));
			Assert.assertTrue(prevConfirmation.compareTo(currentConfirmation) <= 0);
			prevConfirmation = currentConfirmation;
		}
	}

	@Test
	public void getICSCasesForPlanNo_caseType() {
		logger.debug("getICSCasesForPlanNo_caseType");
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("caseType");
		caseSearch.setPlan(PLAN);

		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		Assert.assertEquals(NO_OF_RECORD, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}
		String prevCaseType = null;
		String currentCaseType = null;
		for (Case case1 : casesForPlan) {
			if (prevCaseType == null) {
				prevCaseType = case1.getType();
			}
			currentCaseType = case1.getType();
			logger.debug("prev:" + prevCaseType + ",current:" + currentCaseType + "prev.compareTo(current):"
					+ prevCaseType.compareTo(currentCaseType));
			Assert.assertTrue(prevCaseType.compareTo(currentCaseType) <= 0);
			prevCaseType = currentCaseType;
		}
	}

	@Test
	public void getICSCasesForPlanNo_pin() {
		logger.debug("getICSCasesForPlanNo_pin");

		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("pin");
		caseSearch.setPlan(PLAN);

		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		Assert.assertEquals(NO_OF_RECORD, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}

		String prev = null;
		String current = null;
		for (Case case1 : casesForPlan) {
			String pin = case1.getPin() == null ? "" : case1.getPin();
			if (prev == null) {
				prev = pin;
			}
			current = pin;
			logger.debug("prev:" + prev + ",current:" + current + "prev.compareTo(current):" + prev.compareTo(current));
			Assert.assertTrue(prev.compareTo(current) <= 0);
			prev = current;
		}
	}

	@Test
	public void getICSCasesForPlanNo_clientId() {
		logger.debug("getICSCasesForPlanNo_clientId");
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("clientid");
		caseSearch.setPlan(PLAN);

		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		Assert.assertEquals(NO_OF_RECORD, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}
		String prev = null;
		String current = null;
		for (Case case1 : casesForPlan) {
			if (prev == null) {
				prev = case1.getClientId();
			}
			current = case1.getClientId();
			logger.debug("prev:" + prev + ",current:" + current + "prev.compareTo(current):" + prev.compareTo(current));
			Assert.assertTrue(prev.compareTo(current) <= 0);
			prev = current;
		}

	}

	@Test
	public void getICSCasesForPlanNo_caseStatus() {
		logger.debug("getICSCasesForPlanNo_caseStatus");
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("caseStatus");
		caseSearch.setPlan(PLAN);

		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		Assert.assertEquals(NO_OF_RECORD, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}
		String prev = null;
		String current = null;
		for (Case case1 : casesForPlan) {
			if (prev == null) {
				prev = case1.getStatus();
			}
			current = case1.getStatus();
			logger.debug("prev:" + prev + ",current:" + current + "prev.compareTo(current):" + prev.compareTo(current));
			Assert.assertTrue(prev.compareTo(current) <= 0);
			prev = current;
		}
	}

	@Test
	public void getICSCasesForPlanNo_requestReceivedDate() throws ParseException {

		logger.debug("getICSCasesForPlanNo_requestReceivedDate");
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("Request Received Date");
		caseSearch.setPlan(PLAN);

		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		Assert.assertEquals(NO_OF_RECORD, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(PLAN));
		}
		CaseComparator caseComp = new CaseComparator(caseSearch.getSortField());
		Case prev = null;
		Case current = null;
		DateFormat df = new SimpleDateFormat(CommonConstants.MMDDYYYYHHMMSS);
		boolean first = true;
		for (Case case1 : casesForPlan) {
			if (first) {
				prev = case1;
				first = false;
				continue;
			}
			current = case1;
			Assert.assertTrue(caseComp.compare(prev, current) <= 0);
			prev = current;
		}
	}

	//////////////////////////////// PLAN DB

	private static final String DB_PLAN = "100868";

	@Test
	public void getICSCasesForPlanNo_requestReceivedDate_DB() throws ParseException {

		logger.debug("getICSCasesForPlanNo_requestReceivedDate");
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortField("Request Received Date");
		caseSearch.setPlan(DB_PLAN);

		List<Case> casesForPlan = target.getICSCasesForPlanNo(caseSearch, null, OS_NAME, userContext.getSubject());
		logger.debug("size of the returned result:" + casesForPlan.size());
		Assert.assertEquals(NO_OF_RECORD, casesForPlan.size());
		for (Case case1 : casesForPlan) {
			Assert.assertNotNull(case1.getPlan());
			Assert.assertTrue(case1.getPlan().contains(DB_PLAN));
		}
		CaseComparator caseComp = new CaseComparator(caseSearch.getSortField());
		Case prev = null;
		Case current = null;
		DateFormat df = new SimpleDateFormat(CommonConstants.MMDDYYYYHHMMSS);
		boolean first = true;
		for (Case case1 : casesForPlan) {
			if (first) {
				prev = case1;
				first = false;
				continue;
			}
			current = case1;
			Assert.assertTrue(caseComp.compare(prev, current) <= 0);
			prev = current;
		}
	}

	// DevINT2 case for plan number - {5535EC76-E389-41F8-B788-A0372D9F68B5}
	// DevINT2 plan numbers - 100865,100866,100868,100297,100300,100296
	String DEVINT2_ICS_CASE = "{5535EC76-E389-41F8-B788-A0372D9F68B5}";
	String DEVINT2_OS_NAME = "FNACMTOS";

	@Test
	public void testPopulatePlanNumbers_bothNull() {
		Folder caseFolder = null;
		caseFolder = Factory.Folder.fetchInstance(getOS(OS_NAME), DEVINT2_ICS_CASE, null);

		Properties props = caseFolder.getProperties();
		props.putObjectValue("ICS_PlanNumbersERISAForSearch", null);
		props.putObjectValue("ICS_PlanNumbersNonERISAForSearch", null);
		String finalPlan = populatePlanNumbers(props);
		Assert.assertEquals("", finalPlan);

	}

	@Test
	public void testPopulatePlanNumbers_bothNotNull() {
		Folder caseFolder = null;
		caseFolder = Factory.Folder.fetchInstance(getOS(OS_NAME), DEVINT2_ICS_CASE, null);

		Properties props = caseFolder.getProperties();
		// erisa & non erisa is not null already
		String finalPlan = populatePlanNumbers(props);
		Assert.assertEquals("100865,100866,100868,100297,100300,100296", finalPlan);

	}

	@Test
	public void testPopulatePlanNumbers_erisaNull() {
		Folder caseFolder = null;
		caseFolder = Factory.Folder.fetchInstance(getOS(OS_NAME), DEVINT2_ICS_CASE, null);

		Properties props = caseFolder.getProperties();
		// non erisa is not null already
		props.putObjectValue("ICS_PlanNumbersERISAForSearch", null);
		String finalPlan = populatePlanNumbers(props);
		Assert.assertEquals("100297,100300,100296", finalPlan);
	}

	@Test
	public void testPopulatePlanNumbers_nonErisaNull() {
		Folder caseFolder = null;
		caseFolder = Factory.Folder.fetchInstance(getOS(OS_NAME), DEVINT2_ICS_CASE, null);

		Properties props = caseFolder.getProperties();
		// erisa is not null already
		// props.putObjectValue("ICS_PlanNumbersERISAForSearch", null);
		// erisa is not null already
		props.putObjectValue("ICS_PlanNumbersNonERISAForSearch", null);
		String finalPlan = populatePlanNumbers(props);
		Assert.assertEquals("100865,100866,100868", finalPlan);

	}
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	private String populatePlanNumbers(Properties props) {
		StringBuffer result = new StringBuffer();
		if (props.isPropertyPresent("ICS_PlanNumbersERISAForSearch")
				&& (props.getStringValue("ICS_PlanNumbersERISAForSearch") != null)) {
			result.append(props.getStringValue("ICS_PlanNumbersERISAForSearch"));

		}

		if (props.isPropertyPresent("ICS_PlanNumbersNonERISAForSearch")
				&& (props.getStringValue("ICS_PlanNumbersNonERISAForSearch") != null)) {
			if ((result != null) && !ICMClientUtil.isEmpty(result.toString())) {
				result.append(",");
			}
			result.append(props.getStringValue("ICS_PlanNumbersNonERISAForSearch"));
		}
		return result.toString().replaceAll(";", ",");

	}

	private ObjectStore getOS(String osName) {

		if (!objectStores.containsKey(osName)) {

			Connection conn = Factory.Connection.getConnection(ejbURI);
			Domain domain = Factory.Domain.fetchInstance(conn, null, null);
			ObjectStore os = Factory.ObjectStore.fetchInstance(domain, osName, null);
			objectStores.put(osName, os);
		}

		return objectStores.get(osName);

	}

	private com.filenet.api.core.Document getDocument(String osName, String caseID, String documentId, String alias)
			throws RuntimeException, Exception {
		Folder caseFolder = Factory.Folder.fetchInstance(getOS(osName), caseID, null);
		String caseFolderPath = caseFolder.getProperties().getStringValue("PathName");
		SearchSQL docSearchSQL = new SearchSQL();
		String select = alias + ".id, " + alias + ".MimeType, " + alias + ".Name, " + alias + ".CmAcmAssociatedCase, "
				+ alias + ".ContentElements, " + alias + ".FoldersFiledIn," + alias + ".VersionSeries";
		docSearchSQL.setSelectList(select);
		String className = "Document"; // always OOTB base class
		docSearchSQL.setFromClauseInitialValue(className, alias, true);
		String whereClause = "doc.Id = ('" + documentId + "') and doc.CmAcmAssociatedCase = Object('" + caseFolderPath
				+ "')";
		docSearchSQL.setWhereClause(whereClause);
		// LOG.debug("Doc SQL Search -->" + docSearchSQL.toString());
		SearchScope scope = new SearchScope(getOS(osName));
		DocumentSet docSet = (DocumentSet) scope.fetchObjects(docSearchSQL, PAGE_SIZE, null, new Boolean(true));
		Iterator<com.filenet.api.core.Document> iterator = docSet.iterator();
		if (!iterator.hasNext()) {
			throw new RuntimeException("Not found any Document with ID:" + documentId + " in the case ID:" + caseID);
		}
		com.filenet.api.core.Document document = iterator.next();
		printAllVersions(document);
		return getLatestVersionDoc(document);
	}

	private void printAllVersions(com.filenet.api.core.Document document) {
		VersionSeries vs = document.get_VersionSeries();
		VersionableSet vss = vs.get_Versions();

		Iterator vssiter = vss.iterator();

		int major = 0;
		int minor = 0;
		while (vssiter.hasNext()) {
			Versionable ver = (Versionable) vssiter.next();

			System.out.println("Major = " + ver.get_MajorVersionNumber() + "; Minor = " + ver.get_MinorVersionNumber());
			com.filenet.api.core.Document filenetDoc = (com.filenet.api.core.Document) ver;
			Object content = filenetDoc.get_ContentElements().get(0);
			if (content instanceof ContentReference) {
				ContentReference reference = (ContentReference) content;
				String fdrsURL = reference.get_ContentLocation();
				System.out.println("fdrsurl:" + fdrsURL);
			}
		}

	}

	private com.filenet.api.core.Document getLatestVersionDoc(com.filenet.api.core.Document document) {
		VersionSeries versionableSeries = document.get_VersionSeries();
		com.filenet.api.core.Document latestVersionDoc = (com.filenet.api.core.Document) versionableSeries
				.get_CurrentVersion();
		return latestVersionDoc;
	}

	@After
	public void tearDown() {
		userContext.popSubject();
	}

	@Test
	public void testCasePropertiesCache() {

		Map<String, Map<String, String>> caseProperties = SolutionConfigCache.getCaseProperties();
		Set<String> keys = caseProperties.keySet();
		Assert.assertTrue(keys.size() == 5);
		for (Map.Entry<String, Map<String, String>> entry : caseProperties.entrySet()) {
			String solutionName = entry.getKey();
			Map<String, String> properties = entry.getValue();
			Assert.assertTrue(properties.size() > 0);
		}

	}
}
