package org.tiaa.icm.client.mapper;

import static org.junit.Assert.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;

import org.springframework.context.support.FileSystemXmlApplicationContext;

import org.tiaa.icm.client.domain.RelatedCase;

public class RelatedCasesMapperTest {

	private static RelatedCasesMapper relatedCasesMapper;
	private static String contextFilePath = "C:/Users/mamillv/ICMWorkspace/ICMClientRSV1/src/main/webapp/WEB-INF/icm-client-rs-v1-context.xml";

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {

		FileSystemXmlApplicationContext context = new FileSystemXmlApplicationContext(contextFilePath);
		relatedCasesMapper = (RelatedCasesMapper) context.getBean("relatedCasesMapper");
	}

	String POPI_CASE_DEVINT2 = "{03731B15-0178-4B6E-8953-9BF0B4CDBF47}";
	String POPMO_CASE_DEVINT2 = "{1A333732-5B1C-4AFD-BC15-6269E33557F2}";
	String POATOBO_CASE_DEVINT2 = "{94014738-E489-40E6-A84F-AC916948BC07}";
	String POBankOps_CASE_DEVINT2 = "{7023C74F-F3AA-4FD1-B876-191657A1978F}";
	String ATOPO_CASE_DEVINT2 = "{1E3DA69E-3974-4583-9A06-FC5CA91A508D}";
	String BOPO_CASE_DEVINT2 = "{5E91FA6A-E581-49D1-8E70-9ACDA9AD0CA9}";
	String BankOpsPO_CASE_DEVINT2 = "{5523C74F-F3AA-4FD1-B876-223344A1978F}";
	String BOBO_CASE_DEVINT2 = "{A6BFC91E-ED07-4ABB-911F-58E40D248E7F}";
	String PMOPO_CASE_DEVINT2 = "{D2684B51-35EE-4778-9E56-B1179BD1B181}";
	String PIPO_CASE_DEVINT2 = "{CA332D78-4AAE-437E-9EB9-C71B2970C959}";

	DateFormat df = new SimpleDateFormat();

	@Test
	public void testGetRelatedCases_POPI() {
		List<RelatedCase> relatedCaseList = relatedCasesMapper.getRelatedCases(POPI_CASE_DEVINT2);

		assertNotNull(relatedCaseList);
		assertEquals(1, relatedCaseList.size());
		assertEquals("{CA332D78-4AAE-437E-9EB9-C71B2970C959}", relatedCaseList.get(0).getCaseId());
		assertNull(relatedCaseList.get(0).getConfirmation());
		assertEquals("Loan Repayment", relatedCaseList.get(0).getCaseType());
		assertEquals("In Process", relatedCaseList.get(0).getCaseStatus());
		// assertEquals(df.format("04/22/2016 04:43:10.000 AM"),
		// relatedCaseList.get(0).getCreatedDate());
		assertNull(relatedCaseList.get(0).getCompletedDate());
	}

	@Test
	public void testGetRelatedCases_POPMO() {
		List<RelatedCase> relatedCaseList = relatedCasesMapper.getRelatedCases(POPMO_CASE_DEVINT2);

		assertNotNull(relatedCaseList);
		assertEquals(8, relatedCaseList.size());

		DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss.SSS a");

		assertEquals("{D2684B51-35EE-4778-9E56-B1179BD1B181}", relatedCaseList.get(0).getCaseId());
		assertEquals("C14LE8GMT", relatedCaseList.get(0).getConfirmation());
		assertEquals("Participant Data Change", relatedCaseList.get(0).getCaseType());
		assertEquals("Expired", relatedCaseList.get(0).getCaseStatus());
		// assertEquals(df.format("08/01/2016 02:03:25.000 AM"),
		// relatedCaseList.get(0).getCreatedDate());
		// assertEquals("08/03/2016 10:00:40.000 AM",
		// relatedCaseList.get(0).getCompletedDate());

		assertEquals("{220C3836-0891-4AA3-995F-171A2A7D65C7}", relatedCaseList.get(1).getCaseId());
		assertEquals("C14LE8IEG", relatedCaseList.get(1).getConfirmation());
		assertEquals("Participant Data Change", relatedCaseList.get(1).getCaseType());
		assertEquals("Expired", relatedCaseList.get(1).getCaseStatus());
		// //assertEquals("08/01/2016 01:31:03.000 PM",
		// relatedCaseList.get(1).getCreatedDate());
		// //assertEquals("08/03/2016 09:56:19.000 AM",
		// relatedCaseList.get(1).getCompletedDate());

		assertEquals("{D68285DC-C079-4188-A70F-EAAEE5218351}", relatedCaseList.get(2).getCaseId());
		assertEquals("C14LE8Y6W", relatedCaseList.get(2).getConfirmation());
		assertEquals("Participant Data Change", relatedCaseList.get(2).getCaseType());
		assertEquals("In Process", relatedCaseList.get(2).getCaseStatus());
		//// assertEquals("08/12/2016 02:10:41.000 PM",
		//// relatedCaseList.get(2).getCreatedDate());
		assertNull(relatedCaseList.get(2).getCompletedDate());

		assertEquals("{D1E76852-37FA-472E-8138-BF23D8E51FE0}", relatedCaseList.get(3).getCaseId());
		assertEquals("C14LE8YT4", relatedCaseList.get(3).getConfirmation());
		assertEquals("Participant Data Change", relatedCaseList.get(3).getCaseType());
		assertEquals("Expired", relatedCaseList.get(3).getCaseStatus());
		// assertEquals("08/15/2016 02:39:45.000 PM",
		// relatedCaseList.get(3).getCreatedDate());
		// assertEquals("11/04/2016 06:15:03.000 AM",
		// relatedCaseList.get(3).getCompletedDate());

		assertEquals("{180FA98A-18FD-4E33-92CB-A8C932144089}", relatedCaseList.get(4).getCaseId());
		assertEquals("C14LE8YB7", relatedCaseList.get(4).getConfirmation());
		assertEquals("Participant Data Change", relatedCaseList.get(4).getCaseType());
		assertEquals("Expired", relatedCaseList.get(4).getCaseStatus());
		//// assertEquals("08/12/2016 03:40:56.000 PM",
		//// relatedCaseList.get(4).getCreatedDate());
		//// assertEquals("11/04/2016 05:58:42.000 AM",
		//// relatedCaseList.get(4).getCompletedDate());

		assertEquals("{9686B55E-CE36-4F46-AAA4-1C6043C6C0E9}", relatedCaseList.get(5).getCaseId());
		assertEquals("C14LE8M8W", relatedCaseList.get(5).getConfirmation());
		assertEquals("Participant Data Change", relatedCaseList.get(5).getCaseType());
		assertEquals("In Process", relatedCaseList.get(5).getCaseStatus());
		//// assertEquals("08/03/2016 01:14:54.000 PM",
		//// relatedCaseList.get(5).getCreatedDate());
		//// assertEquals("08/08/2016 09:45:43.000 PM",
		//// relatedCaseList.get(5).getCompletedDate());

		assertEquals("{1202951C-A2E0-4A5C-8976-751EC5E50DD7}", relatedCaseList.get(6).getCaseId());
		assertEquals("C14LE8Y6U", relatedCaseList.get(6).getConfirmation());
		assertEquals("Participant Data Change", relatedCaseList.get(6).getCaseType());
		assertEquals("Expired", relatedCaseList.get(6).getCaseStatus());
		//// assertEquals("08/12/2016 02:02:55.000 PM",
		//// relatedCaseList.get(6).getCreatedDate());
		//// assertEquals("11/04/2016 05:58:36.000 AM",
		//// relatedCaseList.get(6).getCompletedDate());

		assertEquals("{637B89DD-27DF-4ADE-B544-6DF0DC1251E3}", relatedCaseList.get(7).getCaseId());
		assertEquals("C14LE8YAQ", relatedCaseList.get(7).getConfirmation());
		assertEquals("Participant Data Change", relatedCaseList.get(7).getCaseType());
		assertEquals("Expired", relatedCaseList.get(7).getCaseStatus());
		//// assertEquals("08/12/2016 03:49:13.000 PM",
		//// relatedCaseList.get(7).getCreatedDate());
		//// assertEquals("11/04/2016 05:58:36.000 AM",
		//// relatedCaseList.get(7).getCompletedDate());

	}

	@Test
	public void testGetRelatedCases_POATOBO() {
		List<RelatedCase> relatedCaseList = relatedCasesMapper.getRelatedCases(POATOBO_CASE_DEVINT2);

		assertNotNull(relatedCaseList);

		assertEquals("{1E3DA69E-3974-4583-9A06-FC5CA91A508D}", relatedCaseList.get(0).getCaseId());
		assertEquals("C14LE5NXG", relatedCaseList.get(0).getConfirmation());
		assertEquals("SD Account Opening", relatedCaseList.get(0).getCaseType());
		assertEquals("In Process", relatedCaseList.get(0).getCaseStatus());
		//// assertEquals("05/27/2016 04:16:16.000 PM",
		//// relatedCaseList.get(0).getCreatedDate());
		assertNull(relatedCaseList.get(0).getCompletedDate());

		assertEquals("{5E91FA6A-E581-49D1-8E70-9ACDA9AD0CA9}", relatedCaseList.get(1).getCaseId());
		assertEquals("C14LE5NXG", relatedCaseList.get(1).getConfirmation());
		assertEquals("SD Account Opening", relatedCaseList.get(1).getCaseType());
		assertEquals("In Process", relatedCaseList.get(1).getCaseStatus());
		//// assertEquals("05/27/2016 04:16:12.000 PM",
		//// relatedCaseList.get(1).getCreatedDate());
		assertNull(relatedCaseList.get(1).getCompletedDate());

	}

	@Test
	public void testGetRelatedCases_POBankOps() {
		List<RelatedCase> relatedCaseList = relatedCasesMapper.getRelatedCases(POBankOps_CASE_DEVINT2);
		assertNotNull(relatedCaseList);

		assertEquals("{5523C74F-F3AA-4FD1-B876-223344A1978F}", relatedCaseList.get(0).getCaseId());
		assertEquals("114455", relatedCaseList.get(0).getConfirmation());
		assertEquals("Fund Transfer", relatedCaseList.get(0).getCaseType());
		assertEquals("In Process", relatedCaseList.get(0).getCaseStatus());
		// assertEquals(df.format("01/26/2016 08:37:10.000 PM"),
		// relatedCaseList.get(0).getCreatedDate());
		assertNull(relatedCaseList.get(0).getCompletedDate());

	}

	@Test
	public void testGetRelatedCases_ATOPO() {
		List<RelatedCase> relatedCaseList = relatedCasesMapper.getRelatedCases(ATOPO_CASE_DEVINT2);
		assertNotNull(relatedCaseList);

		assertEquals("{94014738-E489-40E6-A84F-AC916948BC07}", relatedCaseList.get(0).getCaseId());
		assertEquals("C14LE5NXB", relatedCaseList.get(0).getConfirmation());
		assertEquals("Rollover", relatedCaseList.get(0).getCaseType());
		assertEquals("Started", relatedCaseList.get(0).getCaseStatus());
		// assertEquals(df.format("05/27/2016 04:16:07.000 PM"),
		// relatedCaseList.get(0).getCreatedDate());
		assertNull(relatedCaseList.get(0).getCompletedDate());
	}

	@Test
	public void testGetRelatedCases_BOPO() {
		List<RelatedCase> relatedCaseList = relatedCasesMapper.getRelatedCases(BOPO_CASE_DEVINT2);
		assertNotNull(relatedCaseList);

		assertEquals("{94014738-E489-40E6-A84F-AC916948BC07}", relatedCaseList.get(0).getCaseId());
		assertEquals("C14LE5NXB", relatedCaseList.get(0).getConfirmation());
		assertEquals("Rollover", relatedCaseList.get(0).getCaseType());
		assertEquals("Started", relatedCaseList.get(0).getCaseStatus());
		// assertEquals(df.format("05/27/2016 04:16:07.000 PM"),
		// relatedCaseList.get(0).getCreatedDate());
		assertNull(relatedCaseList.get(0).getCompletedDate());
	}

	@Test
	public void testGetRelatedCases_BankOpsPO() {
		List<RelatedCase> relatedCaseList = relatedCasesMapper.getRelatedCases(BankOpsPO_CASE_DEVINT2);
		assertNotNull(relatedCaseList);

		assertEquals("{7023C74F-F3AA-4FD1-B876-191657A1978F}", relatedCaseList.get(0).getCaseId());
		assertEquals("C14LDYYTC", relatedCaseList.get(0).getConfirmation());
		assertEquals("Loan Request", relatedCaseList.get(0).getCaseType());
		assertEquals("Started", relatedCaseList.get(0).getCaseStatus());
		// assertEquals(df.format("11/13/2015 01:20:22.000 PM"),
		// relatedCaseList.get(0).getCreatedDate());
		assertNull(relatedCaseList.get(0).getCompletedDate());
	}

	@Test
	public void testGetRelatedCases_PMOPO() {
		List<RelatedCase> relatedCaseList = relatedCasesMapper.getRelatedCases(PMOPO_CASE_DEVINT2);
		assertNotNull(relatedCaseList);

		assertEquals("{1A333732-5B1C-4AFD-BC15-6269E33557F2}", relatedCaseList.get(0).getCaseId());
		assertEquals("C14LE0PRL", relatedCaseList.get(0).getConfirmation());
		assertEquals("Cash Withdrawal", relatedCaseList.get(0).getCaseType());
		assertEquals("Started", relatedCaseList.get(0).getCaseStatus());
		// assertEquals(df.format("02/18/2016 01:56:44.000 AM"),
		// relatedCaseList.get(0).getCreatedDate());
		assertNull(relatedCaseList.get(0).getCompletedDate());
	}

	@Test
	public void testGetRelatedCases_PIPO() {
		List<RelatedCase> relatedCaseList = relatedCasesMapper.getRelatedCases(PIPO_CASE_DEVINT2);
		assertNotNull(relatedCaseList);

		assertEquals("{03731B15-0178-4B6E-8953-9BF0B4CDBF47}", relatedCaseList.get(0).getCaseId());
		assertEquals("C14LE34SN", relatedCaseList.get(0).getConfirmation());
		assertEquals("Loan Request", relatedCaseList.get(0).getCaseType());
		assertEquals("Completed", relatedCaseList.get(0).getCaseStatus());
		// assertEquals(df.format("04/21/2016 01:40:33.000 AM"),
		// relatedCaseList.get(0).getCreatedDate());
		// assertEquals("04/22/2016 04:43:31.000 AM",
		// relatedCaseList.get(0).getCompletedDate());
	}

	@Test
	// @Ignore
	public void testGetRelatedCases_BOBO() {
		List<RelatedCase> relatedCaseList = relatedCasesMapper.getRelatedCases(BOBO_CASE_DEVINT2);
		assertNotNull(relatedCaseList);
	}
}
