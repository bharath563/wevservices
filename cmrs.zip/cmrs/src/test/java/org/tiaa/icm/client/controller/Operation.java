package org.tiaa.icm.client.controller;

public enum Operation {

	CASE_SEARCH, ADD_CASE_COMMENTS

}
