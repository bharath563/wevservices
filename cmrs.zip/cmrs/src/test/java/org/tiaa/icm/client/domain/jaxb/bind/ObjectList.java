package org.tiaa.icm.client.domain.jaxb.bind;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlJavaTypeAdapter(ObjectListAdapter.class)

public class ObjectList extends ArrayList {

	public List<ObjectListType> entry = new ArrayList<ObjectListType>();
	private static final long serialVersionUID = 1L;

}
