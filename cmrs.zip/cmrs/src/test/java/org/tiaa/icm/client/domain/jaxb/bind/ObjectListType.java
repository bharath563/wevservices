package org.tiaa.icm.client.domain.jaxb.bind;

import javax.xml.bind.annotation.XmlAttribute;

public class ObjectListType {

	@XmlAttribute
	public Object element;
}
