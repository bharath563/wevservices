package org.tiaa.icm.client.domain.jaxb.bind;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public final class ElementListAdapter extends XmlAdapter<ElementsList, List<String>> {

	@Override
	public ElementsList marshal(List<String> inputList) throws Exception {
		ElementsList elementList = new ElementsList();
		for (String entry : inputList) {
			elementList.add(entry);
		}
		return elementList;
	}

	@Override
	public List<String> unmarshal(ElementsList inputList) throws Exception {
		List<String> list = new ArrayList<String>();
		for (Object element : inputList) {
			list.add((String) element);
		}

		return list;
	}

}