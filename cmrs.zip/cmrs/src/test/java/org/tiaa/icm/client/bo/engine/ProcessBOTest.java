package org.tiaa.icm.client.bo.engine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.security.auth.Subject;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import org.apache.log4j.Logger;

import com.filenet.api.collection.CmTaskSet;
import com.filenet.api.constants.LifecycleChangeFlags;
import com.filenet.api.constants.RefreshMode;
import com.filenet.api.core.CmTask;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.property.Properties;
import com.filenet.api.util.UserContext;
import com.ibm.websphere.security.WSSecurityException;

import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.http.ResponseEntity;

import org.tiaa.icm.client.bo.security.P8Authentication;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Response;
import org.tiaa.icm.client.domain.Step;
import org.tiaa.icm.client.domain.StepElementDataField;
import org.tiaa.icm.client.domain.StepList;
import org.tiaa.icm.client.spi.fnet.IProcessEngine;

import edu.emory.mathcs.backport.java.util.Arrays;
import filenet.vw.api.VWException;
import filenet.vw.api.VWGuid;
import filenet.vw.api.VWQueueQuery;
import filenet.vw.api.VWSession;
import filenet.vw.api.VWStepElement;

/**
 * Contains JUnit test cases of PE operations.
 *
 * @author awasts
 *
 */
public class ProcessBOTest {

	// ejbURI = "iiop://chadvt3esfnfe2.ops.tiaa-cref.org:9810";
	// String ejbURI = "iiop://chadvt3esfnfe2.ops.tiaa-cref.org:9810";
	String ejbURI = "iiop://dend2b3fntcm02.cloud.tiaa-cref.org:9810";
	// String username = "TST_OPS_LN4";
	String password = "Spring2017";
	// String password = "Spring17";
	// String password = "Summer17";
	// String password = "Winter2017";
	String caseID = "{CCD0D60B-1568-44A6-AB45-0796CE26D297}";
	String taskType = "IS_RequestReview";
	String wobID;

	String queueName = "IS_Reviewer";
	private static VWSession vwSession;
	private HashMap<String, ObjectStore> objectStores = new HashMap<String, ObjectStore>();

	static Logger logger = Logger.getLogger(ProcessBOTest.class);
	IProcessEngine target;
	Subject subject;
	UserContext userContext;
	String osName = "FNACMTOS";
	private String connectionPoint = "CP_Region1";
	private ProcessBO processbo;

	@Before
	/**
	 * @throws Exception
	 */
	public void setUp() throws Exception {

		logger.debug("From ProcessBO test");
		peInit();
		FileSystemXmlApplicationContext context = new FileSystemXmlApplicationContext(
				"src/main/webapp/WEB-INF/icm-client-rs-v1-context.xml");

		logger.debug("Number of Beans" + context.getBeanDefinitionNames().length);
		P8Authentication authentication = new P8Authentication();
		subject = authentication.login(username, password);
		target = context.getBean(IProcessEngine.class);
		processbo = context.getBean(ProcessBO.class);
		userContext = UserContext.get();
		userContext.pushSubject(subject);
		// vwSession = getVWSession();
	}

	private void peInit() {

		System.setProperty("java.security.auth.login.config", "/app/IBM/Filenet/AE/CE_API/config/jaas.conf.WebSphere");
		System.setProperty("java.naming.factory.initial", "com.ibm.websphere.naming.WsnInitialContextFactory");
		System.setProperty("com.ibm.CORBA.ConfigURL", "file:///C:/app/IBM/WAS/AppClient/properties/sas.client.props");

		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put("org.omg.CORBA.ORBClass", "com.ibm.CORBA.iiop.ORB");
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.websphere.naming.WsnInitialContextFactory");
		env.put(Context.PROVIDER_URL, ejbURI);//

		Context ic;
		try {
			ic = new InitialContext(env);
			ic.lookup("");
		} catch (NamingException e1) {
			e1.printStackTrace();
		}

	}

	public VWSession getVWSession() throws VWException {
		if (vwSession == null) {
			vwSession = new VWSession(connectionPoint);

		}

		return vwSession;
	}

	private CmTask createTask(String taskDisplayName) {
		// Find folder under which task will be created
		Folder caseFolder = Factory.Folder.fetchInstance(getOS(osName), caseID, null);
		// logger.debug(caseFolder.get_CoordinatedTasks());
		CmTask task = Factory.CmTask.createInstance(getOS(osName), taskType);
		try {
			Properties props = task.getProperties();
			task.set_Coordinator(caseFolder);
			if (taskDisplayName != null) {
				props.putValue("CmAcmTaskName", taskDisplayName);
			}
			task.save(RefreshMode.NO_REFRESH);
			task.refresh();
			// promote 2 times to change state from
			// WAITING_PRECONDITION-->READY-->WORKING
			task.changeState(LifecycleChangeFlags.PROMOTE);
			task.changeState(LifecycleChangeFlags.PROMOTE);
			task.save(RefreshMode.NO_REFRESH);
			task.refresh();
			logger.debug("Task ID : " + task.get_Id().toString());
		} catch (Exception e) {
			throw new RuntimeException("Error creating Task " + "Institution", e);
		}
		return task;
	}

	private void launchWorkflow(String workflowName, Map<String, Object> parameters) {

		String errorMsg = null;

		try {
			errorMsg = "Error launching workflow: " + workflowName;

			VWStepElement launchStep = vwSession.createWorkflow(workflowName);
			for (Map.Entry<String, Object> param : parameters.entrySet()) {
				errorMsg = "Error setting launch step parameter: " + param.getKey() + ", for workflow: " + workflowName;
				launchStep.setParameterValue(param.getKey(), param.getValue(), false);
			}

			wobID = launchStep.getWorkObjectNumber();
			logger.debug("Wob ID " + wobID);

			launchStep.doDispatch();

			wobID = launchStep.getWorkObjectNumber();
			logger.debug("Wob ID after dispatch: " + wobID);

		} catch (VWException error) {
			throw new RuntimeException(errorMsg, error);
		}

	}

	private ObjectStore getOS(String osName) {

		if (!objectStores.containsKey(osName)) {
			Connection conn = Factory.Connection.getConnection(ejbURI);
			Domain domain = Factory.Domain.fetchInstance(conn, null, null);
			ObjectStore os = Factory.ObjectStore.fetchInstance(domain, osName, null);
			objectStores.put(osName, os);
		}

		return objectStores.get(osName);

	}

	private String setUpNewTaskAndLounchWorkItem() {

		CmTask task = createTask("Testing Work Item Action Functionality");
		logger.debug("Task Name" + task.get_Name());
		logger.debug("Task Id :: " + task.get_Id());

		Map<String, Object> parameters = new HashMap<String, Object>();

		try {
			parameters.put("F_CaseFolder", new VWGuid(caseID));
			parameters.put("F_CaseTask", new VWGuid(task.get_Id().toString()));
			parameters.put("SupportingDocumentsURI", "MyURI");
			List<String> values = new ArrayList<String>();
			values.add("Testing");
			parameters.put("RoutingReasons", values.toArray());

		} catch (VWException e) {
			logger.error("Not able to create parameters for work object");
		}

		launchWorkflow(taskType, parameters);
		logger.debug("Wob Id from launch method: " + wobID);

		Folder caseFolder = Factory.Folder.fetchInstance(getOS(osName), caseID, null);
		CmTaskSet tasks = caseFolder.get_CoordinatedTasks();
		// logger.debug(tasks);
		Iterator<CmTask> taskIterator = tasks.iterator();

		while (taskIterator.hasNext()) {
			CmTask myTask = taskIterator.next();
			if (myTask.get_Id().equals(task.get_Id())) {
				wobID = myTask.getProperties().getStringValue("CmAcmProcessInstanceId");
				logger.debug("Process Instance Id after launch: " + wobID);
				break;
			}

		}

		return wobID;

	}

	@Test
	@Ignore
	public void testActionProceedSucess() {
		String wobId = setUpNewTaskAndLounchWorkItem();
		Map<String, Object> dataFields = new HashMap<String, Object>();
		List<String> values = new ArrayList<String>();
		values.add("Other");
		values.add("Bad Format");
		dataFields.put("WithdrawReasons", values.toArray());
		String action = "Proceed";
		Response icmClientResponse = target.doAction(queueName, wobId, dataFields, action, username);
		logger.debug("Response: " + icmClientResponse.getStatus());
		logger.debug("Response Error Message: " + icmClientResponse.getErrorMessage());
		Assert.assertEquals("Success", icmClientResponse.getStatus());

		try {
			VWQueueQuery vwQuery = target.getVWQueueQuery(queueName, wobId, vwSession);
			Assert.assertTrue("Work item is completed so should not be more in Work Queue.", vwQuery.fetchCount() == 0);
		} catch (Exception e) {
			logger.error("Error: " + e.getLocalizedMessage());
			Assert.fail();
		}

	}

	@Test
	@Ignore
	public void testActionProceedFailureIncorrectDataFields() {
		String wobId = setUpNewTaskAndLounchWorkItem();
		Map<String, Object> dataFields = new HashMap<String, Object>();
		dataFields.put("Invalid Data Field", "Test");
		String action = "Proceed";
		Response icmClientResponse = target.doAction(queueName, wobId, dataFields, action, username);
		logger.debug("Response: " + icmClientResponse.getStatus());
		logger.debug("Response Error Message: " + icmClientResponse.getErrorMessage());
		Assert.assertEquals("Error", icmClientResponse.getStatus());
		try {
			VWQueueQuery vwQuery = target.getVWQueueQuery(queueName, wobId, vwSession);
			Assert.assertFalse("Failed to Proceed Work Item so work item should still be in repective Queue.",
					vwQuery.fetchCount() == 0);
		} catch (Exception e) {
			logger.error("Error: " + e.getLocalizedMessage());
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testActionProceedFailureIncorrectServiceParam() {
		String wobId = setUpNewTaskAndLounchWorkItem();
		Map<String, Object> dataFields = new HashMap<String, Object>();
		String invalidQueueName = "Invalid_Queue_Name";
		String action = "Proceed";
		Response icmClientResponse = target.doAction(invalidQueueName, wobId, dataFields, action, username);
		logger.debug("Response: " + icmClientResponse.getStatus());
		logger.debug("Response Error Message: " + icmClientResponse.getErrorMessage());
		Assert.assertEquals("Error", icmClientResponse.getStatus());
		try {
			VWQueueQuery vwQuery = target.getVWQueueQuery(queueName, wobId, vwSession);
			Assert.assertFalse("Failed to Proceed Work Item so work item should still be in repective Queue.",
					vwQuery.fetchCount() == 0);
		} catch (Exception e) {
			logger.error("Error: " + e.getLocalizedMessage());
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testActionSaveSucess() {
		String wobId = setUpNewTaskAndLounchWorkItem();
		Map<String, Object> dataFields = new HashMap<String, Object>();
		List<String> values = new ArrayList<String>();
		values.add("Other");
		values.add("Bad Format");
		dataFields.put("WithdrawReasons", values.toArray());
		String action = "Save";
		Response icmClientResponse = target.doAction(queueName, wobId, dataFields, action, username);
		logger.debug("Response: " + icmClientResponse.getStatus());
		logger.debug("Response Error Message: " + icmClientResponse.getErrorMessage());
		Assert.assertEquals("Success", icmClientResponse.getStatus());

		try {
			VWStepElement stpElement = target.getStepElement(queueName, wobId, username, vwSession);
			String[] dataAfterSave = (String[]) stpElement.getParameterValue("WithdrawReasons");
			Assert.assertArrayEquals(values.toArray(), dataAfterSave);

			Assert.assertFalse("Work Item should be locked after Save Action",
					stpElement.fetchWorkObject(false, false).fetchLockedStatus() == 0);

		} catch (Exception e) {
			logger.error("Error: " + e.getLocalizedMessage());
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testActionSaveFailureIncorrectDataFields() {
		String wobId = setUpNewTaskAndLounchWorkItem();
		Map<String, Object> dataFields = new HashMap<String, Object>();
		dataFields.put("Invalid Data Field", "Test");
		String action = "Save";
		Response icmClientResponse = target.doAction(queueName, wobId, dataFields, action, username);
		logger.debug("Response: " + icmClientResponse.getStatus());
		logger.debug("Response Error Message: " + icmClientResponse.getErrorMessage());
		Assert.assertEquals("Error", icmClientResponse.getStatus());

		try {
			VWStepElement stpElement = target.getStepElement(queueName, wobId, username, vwSession);
			List<String> parameterNames = Arrays.asList(stpElement.getParameterNames());
			Assert.assertFalse("Incorrect Parameter can't be saved", parameterNames.contains("Invalid Data Field"));

		} catch (Exception e) {
			logger.error("Error: " + e.getLocalizedMessage());
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testActionSaveFailureIncorrectServiceParam() {
		String wobId = setUpNewTaskAndLounchWorkItem();
		Map<String, Object> dataFields = new HashMap<String, Object>();
		String invalidQueueName = "Invalid_Queue_Name";
		String action = "Save";
		Response icmClientResponse = target.doAction(invalidQueueName, wobId, dataFields, action, username);
		logger.debug("Response: " + icmClientResponse.getStatus());
		logger.debug("Response Error Message: " + icmClientResponse.getErrorMessage());
		Assert.assertEquals("Error", icmClientResponse.getStatus());
	}

	@Test
	@Ignore
	public void testActionUnlockWorkItem() {
		String wobId = "5AF00D2793013847843042CAE144FBB8";
		Map<String, Object> dataFields = new HashMap<String, Object>();
		List<String> values = new ArrayList<String>();
		values.add("Other");
		values.add("Bad Format");
		dataFields.put("WithdrawReasons", values.toArray());
		String action = "Save";
		target.doAction(queueName, wobId, dataFields, action, username);

		Response icmClientResponse = target.unlockWorkItem(queueName, wobId, username);
		logger.debug("Response: " + icmClientResponse.getStatus());
		logger.debug("Response Error Message: " + icmClientResponse.getErrorMessage());
		Assert.assertEquals("Success", icmClientResponse.getStatus());

		try {
			VWStepElement stpElement = target.getStepElement(queueName, wobId, username, vwSession);
			Assert.assertTrue("Work Item should be unlocked after unlock Action",
					stpElement.fetchWorkObject(false, false).fetchLockedStatus() == 0);

		} catch (Exception e) {
			logger.error("Error: " + e.getLocalizedMessage());
			Assert.fail();
		}

	}

	@Test
	@Ignore
	public void testGetStepDetails() throws VWException, Exception {
		String wobId = "751B7971F9068C47B0DDA4A5AC2D6B7B";
		ResponseEntity<?> responseEntity = target.getStepDetails("PO_ProcessorPended", wobId);
		Step step = (Step) responseEntity.getBody();
		Assert.assertNotNull("Case Id should not be null ", step.getCaseId());
		Assert.assertNotNull("Tak Id should not be null ", step.getTaskId());
		Assert.assertNotNull("Wob Id should not be null ", step.getWobId());
		if (step.isLocked()) {
			Assert.assertNotNull("If work item is locked, locked by should not be null ", step.getLockedby());
		} else {
			Assert.assertNull("If work item is not locked, locked by should be null ", step.getLockedby());
		}
		logger.debug("Case Id: " + step.getCaseId());
		logger.debug("Task Id: " + step.getTaskId());
		logger.debug("Wob Id: " + step.getWobId());
		logger.debug("Locked: " + step.isLocked());
		logger.debug("Locked By: " + step.getLockedby());

		List<StepElementDataField> dataFields = step.getFields();
		for (StepElementDataField dataField : dataFields) {
			logger.debug("Data Field Name: " + dataField.getName());
			logger.debug("Data Field Type: " + dataField.getType());
			logger.debug("Data Field Mode: " + dataField.getMode());
			logger.debug("Data Field Value: " + dataField.getValue());
			logger.debug("Data Field Id: " + dataField.getId() + "\n");
		}

	}

	@Test
	@Ignore
	public void testQueue() throws VWException {
		target.getVWQueueQuery("PO_Processor", "12345", vwSession);
	}

	@Test
	@Ignore
	public void testGetWorkItems()
			throws WSSecurityException, NamingException, VWException, InterruptedException, ExecutionException {
		String solution = "Institutional Servicing";
		// StepList stepList = processbo.getWorkItems(solution, username,
		// workitemType);
		StepList stepList = processbo.getWorkItems(solution, "atdnu242", "Unassigned");
		if (stepList != null) {
			for (Step step : stepList.getSteps()) {
				System.out.println("status of " + step.getWobId() + ", status:" + step.getStatus().getStatus());
			}
		}
	}

	String username = "tst_ops_id4";

	@Test
	@Ignore
	public void testStepsCount()
			throws WSSecurityException, NamingException, VWException, InterruptedException, ExecutionException {
		String solution = "Payout Operations";
		Map<String, Map<String, Integer>> stepsCount = processbo.getStepsCount(solution, username);
		if (stepsCount != null) {
			for (String str : CommonConstants.WORKITEMTYPES) {
				// System.out.println("stepsCount for " + solution +
				// "workItemType:" + str + " is:" + stepsCount.get(str));
			}

		}
	}

	@Test
	@Ignore
	public void testGetWorkItems_PO_MyWorkItems()
			throws NamingException, VWException, InterruptedException, ExecutionException, WSSecurityException {
		String solution = "Payout Operations";
		String racfId = "atdnuw20";
		String workitemType = "MyWorkItems";
		processbo.getWorkItems(solution, racfId, workitemType);
	}

	@Test
	@Ignore
	public void testGetWorkItems_PO_Pended()
			throws NamingException, VWException, InterruptedException, ExecutionException, WSSecurityException {
		String solution = "Payout Operations";
		String racfId = "TST_OPS_ID4";
		String workitemType = "Pended";
		processbo.getWorkItems(solution, racfId, workitemType);
	}

	@Test
	@Ignore
	public void testReassign() {
		String queueName = "PO_ProcessorPended";
		String wobID = "BBA72C520F8E944DA9B5E664D110DF00";
		String reassignRacfId = "TST_OPS_ID11";
		processbo.reassignWorkitem(queueName, wobID, reassignRacfId);
	}

}
