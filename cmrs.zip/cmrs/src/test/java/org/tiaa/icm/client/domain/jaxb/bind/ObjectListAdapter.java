package org.tiaa.icm.client.domain.jaxb.bind;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public final class ObjectListAdapter extends XmlAdapter<ObjectList, List<Object>> {

	@Override
	public ObjectList marshal(List<Object> inputList) throws Exception {
		ObjectList taskList = new ObjectList();
		for (Object entry : inputList) {
			taskList.add(entry);
		}
		return taskList;
	}

	@Override
	public List<Object> unmarshal(ObjectList inputList) throws Exception {
		List<Object> list = new ArrayList<Object>();
		for (Object element : inputList) {
			list.add(element);
		}

		return list;
	}

}