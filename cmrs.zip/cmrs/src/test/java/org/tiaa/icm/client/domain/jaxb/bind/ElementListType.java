package org.tiaa.icm.client.domain.jaxb.bind;

import javax.xml.bind.annotation.XmlAttribute;

public class ElementListType {

	@XmlAttribute
	public String element;
}
