package org.tiaa.icm.client.bean;

import static org.mockito.Mockito.*;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.security.auth.Subject;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import org.apache.log4j.Logger;

import com.filenet.api.collection.CmTaskSet;
import com.filenet.api.collection.DocumentSet;
import com.filenet.api.collection.VersionableSet;
import com.filenet.api.core.CmTask;
import com.filenet.api.core.Connection;
import com.filenet.api.core.ContentReference;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.core.VersionSeries;
import com.filenet.api.core.Versionable;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;
import com.filenet.api.util.Id;
import com.filenet.api.util.UserContext;

import org.springframework.context.support.FileSystemXmlApplicationContext;

import org.tiaa.icm.client.bo.security.P8Authentication;
import org.tiaa.icm.client.constant.CommentType;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Case;
import org.tiaa.icm.client.domain.CaseSearch;
import org.tiaa.icm.client.domain.Comment;
import org.tiaa.icm.client.domain.Document;
import org.tiaa.icm.client.domain.FormatType;
import org.tiaa.icm.client.domain.Response;
import org.tiaa.icm.client.domain.ResponseList;

import filenet.vw.api.VWException;
import filenet.vw.api.VWSession;

public class CaseBeanTest {

	private static Logger logger = Logger.getLogger(CaseBeanTest.class);

	private static final String OS_NAME = "FNACMTOS";
	// private static final String CASE_ID =
	// "{5A8A5AF9-D6BD-4BA1-867B-56F87449C2A1}";
	// private static final String CASE_ID =
	// "{686ADA26-8CB3-4E4D-A668-E50B4644F6D2}";

	private static final String CASE_ID = "{DC50D7E9-88CC-4EA1-BE4A-8A047C599BED}";

	private static final String TASK_ID = "{D546E0C9-D327-48D0-A29F-E68A319930BF}";
	private static final String DOC_ID = "0240012015120211340120515920345020000001";
	private static final String QUEUE_NAME = "ICS_WorkIntake";
	private static final String WOB_ID = "8C903CBFB04C5F4AB4E85E73ACCE55A0";

	private static final String CASE_COMMENT_TEXT = "VJJUnitCaseComment1";
	private static final String DOC_COMMENT_TEXT = "VJJUnitDocumentComment1";

	private static final String TASK_COMMENT_TEXT = "VJJUnit Task Comment1";
	private static final String STEP_COMMENT_TEXT = "VJJUnit STEP Comment1";

	private static final String DOC_TITLE = "Test data_20151208.pdf";
	private static final String DOC_FOLDER = "";

	private static final String INVALID_ID = "INVALID_ID";
	private static final String OS_ID = "{AE30A8FF-A280-4AEE-9B72-7D1FFB67861B}";
	private static final Integer PAGE_SIZE = 100;
	private static final String RACF_ID = "tst_p8cm01";
	private static String DOC_INSTANCE_ID_UPDATE = "{C9104A13-D1EB-4F79-A2C5-8D7DE7B21B43}";
	private static final String DOC_INSTANCE_ID = DOC_INSTANCE_ID_UPDATE;

	private static final String START_STR = "2";
	private static final String businessUnit = "PENSION";
	private static final String DOC_CODE = "ICS_DOCS";
	private static final String DOC_NAME = "Test Document Name.doc";
	private static final String ID_TYPE = "DRI";
	private static final String MIME_TYPE = "application/pdf";

	private HashMap<String, ObjectStore> objectStores = new HashMap<String, ObjectStore>();
	private static String[] params = null;
	private Subject subject;
	private CaseBean target;
	private String connectionPoint = "CP_Region1";

	private UserContext userContext;
	private String username = "TST_P8CM04";
	private String password = "Summer2016";
	private String ejbURI = "iiop://chadvt3esfnfe2.ops.tiaa-cref.org:9810";
	private static VWSession vwSession = null;
	private Context ic;

	@Before
	public void setUp() throws Exception {
		ceInit();
		FileSystemXmlApplicationContext context = new FileSystemXmlApplicationContext(
				"src/main/webapp/WEB-INF/icm-client-rs-v1-context.xml");

		P8Authentication authentication = new P8Authentication();
		subject = authentication.login(username, password);
		target = context.getBean(CaseBean.class);

		userContext = UserContext.get();
		userContext.pushSubject(subject);
		vwSession = getVWSession();
	}

	private void ceInit() {

		System.setProperty("java.security.auth.login.config",
				"C:/app/IBM/Filenet/AE/CE_API/config/jaas.conf.WebSphere");
		System.setProperty("java.naming.factory.initial", "com.ibm.websphere.naming.WsnInitialContextFactory");
		System.setProperty("com.ibm.CORBA.ConfigURL", "file:///C:/app/IBM/WAS/AppClient/properties/sas.client.props");

		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put("org.omg.CORBA.ORBClass", "com.ibm.CORBA.iiop.ORB");
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.websphere.naming.WsnInitialContextFactory");
		env.put(Context.PROVIDER_URL, ejbURI);//

		try {
			ic = new InitialContext(env);
			ic.lookup("");
		} catch (NamingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

	@Test
	@Ignore
	public void testGetTasks() {
		 target.getTasks(CASE_ID, START_STR,null);
	}

	@Test
	@Ignore
	public void testSearchCaseStatusAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("caseStatus");
		caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchCaseDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("caseStatus");
		caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchIdAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("ID");
		caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchIdDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("ID");
		caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchConfirmationAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("CONFIRMATION");
		caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchConfirmationDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("CONFIRMATION");
		caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchCliendIdAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("CLIENTID");
		// caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Seed File Auditing");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchClientIdDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("CLIENTID");
		// caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Seed File Auditing");
		testSearchCase(caseSearch);
	}

	@Test
	// //@Ignore
	public void testSearchTypeAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("CaseTYPE");
		caseSearch.setChannel("Paper");
		// caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	@Test
	// //@Ignore
	public void testSearchTypeDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("caseType");
		caseSearch.setChannel("Paper");
		// caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchCreatedDateAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("Case Creation Date");

		caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchCreatedDateDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("creationDate");
		caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchRequestReceivedDateAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("Request Received Date");

		caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchRequestReceivedDateDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("Request Received Date");
		caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchRequestReceivedDateDesc2() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("REQUESTRECEIVEDDATE");
		caseSearch.setCaseType("Seed File Auditing");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchRequestModifiedDateAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("modifiedDate");

		caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	@Test
	@Ignore
	public void testSearchRequestModifiedDateDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("modifiedDate");
		caseSearch.setChannel("Paper");
		caseSearch.setCaseType("Account Fund Tracking");
		testSearchCase(caseSearch);
	}

	//////////////////////////////////////////////////////////// PLAN NUMBER
	//////////////////////////////////////////////////////////// CHANGES//////////////////////////////////////////////////////////////////////

	// 100297; 100300; 100296 100865; 100866; 100868
	// 104680, IRA101, 104681, 100119
	private static final String PLAN = "100865";

	@Test
	// @Ignore
	public void testSearchCasePLANStatusAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("caseStatus");
		caseSearch.setChannel("Source");
		// caseSearch.setCaseType("Account Fund Tracking");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	@Test
	// @Ignore
	public void testSearchCasePLANDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("caseStatus");
		caseSearch.setChannel("Source");
		caseSearch.setCaseType("ICS_PlanAdmin");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	@Test
	// @Ignore
	public void testSearchIdPLANAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("ID");
		caseSearch.setChannel("Source");
		caseSearch.setCaseType("ICS_PlanAdmin");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	@Test
	// @Ignore
	public void testSearchIdPLANDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("ID");
		caseSearch.setChannel("Source");
		caseSearch.setCaseType("ICS_PlanAdmin");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	@Test
	// @Ignore
	public void testSearchPLANConfirmationAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("CONFIRMATION");
		caseSearch.setChannel("Source");
		caseSearch.setCaseType("ICS_PlanAdmin");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	@Test
	// @Ignore
	public void testSearchPLANConfirmationDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("CONFIRMATION");
		caseSearch.setChannel("Source");
		caseSearch.setCaseType("ICS_PlanAdmin");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	@Test
	// @Ignore
	public void testSearchPLANCliendIdAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("CLIENTID");
		// caseSearch.setChannel("Source");
		caseSearch.setCaseType("ICS_PlanAdmin");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	@Test
	// @Ignore
	public void testSearchPLANClientIdDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("CLIENTID");
		// caseSearch.setChannel("Source");
		caseSearch.setCaseType("ICS_PlanAdmin");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	@Test
	// @Ignore
	public void testSearchPLANTypeAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("CaseTYPE");
		caseSearch.setChannel("Source");
		// caseSearch.setCaseType("ICS_PlanAdmin");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	@Test
	// //// @Ignore
	public void testSearchPLANTypeDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("caseType");
		caseSearch.setChannel("Source");
		// caseSearch.setCaseType("ICS_PlanAdmin");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	@Test
	// @Ignore
	public void testSearchPLANCreatedDateAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("Case Creation Date");

		caseSearch.setChannel("Source");
		caseSearch.setCaseType("ICS_PlanAdmin");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	@Test
	// @Ignore
	public void testSearchPLANCreatedDateDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("creationDate");
		caseSearch.setChannel("Source");
		caseSearch.setCaseType("ICS_PlanAdmin");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	@Test
	// @Ignore
	public void testSearchRequestPLANReceivedDateAsc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("Request Received Date");

		caseSearch.setChannel("Source");
		caseSearch.setCaseType("ICS_PlanAdmin");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	@Test
	// @Ignore
	public void testSearchRequestReceivedDatePLANDesc() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("desc");
		caseSearch.setSortField("Request Received Date");
		caseSearch.setChannel("Source");
		caseSearch.setCaseType("ICS_PlanAdmin");
		caseSearch.setPlan(PLAN);
		testSearchCase(caseSearch);
	}

	private static final String DB_PLAN = "TIAA03";

	@Test
	// @Ignore
	public void testSearchRequestPLANReceivedDateAsc_DB() throws Exception {
		CaseSearch caseSearch = new CaseSearch();
		caseSearch.setSortOrder("asc");
		caseSearch.setSortField("Request Received Date");

		caseSearch.setPlan(DB_PLAN);
		testSearchCase(caseSearch);
	}

	//////////////////////////////////////////////////////////// PLAN NUMBER
	//////////////////////////////////////////////////////////// CHANGES
	//////////////////////////////////////////////////////////// END//////////////////////////////////////////////////////////////////////
	public void testSearchCase(CaseSearch caseSearch) throws Exception {

		ResponseList responseList = null;

		responseList = target.searchCase(caseSearch, "1", OS_NAME);

		int totalRecords = responseList.getTotalRecords();
		System.out.println("totalRecords:" + totalRecords);
		int tot = 500;
		do {
			List<Case> caseList = (List<Case>) responseList.getResults();
			Assert.assertNotSame(0, caseList.size());
			for (int i = 0; i < caseList.size(); i++) {
				String currentValue = getValue(caseList.get(i), caseSearch.getSortField());
				String nextRecordValue = null;
				if ((i + 1) >= caseList.size()) {
					System.out.println("reached end");
					break;
				}

				System.out.println("case info :" + caseList.get(i).toString());
				nextRecordValue = getValue(caseList.get(i + 1), caseSearch.getSortField());
				System.out.println(
						i + " " + (tot + i) + " currentValue:" + currentValue + ",nextRecordValue:" + nextRecordValue);
				int comparing = 0;
				if (!caseSearch.getSortField().contains("Date")) {
					comparing = currentValue.compareToIgnoreCase(nextRecordValue);
				} else {// 07/01/2015 01:38:51 PM
					SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");

					Date date1 = null;
					Date date2 = null;
					if ((currentValue != null) && (currentValue != "null")) {
						date1 = format.parse(currentValue);
					}
					if ((nextRecordValue != null) && (nextRecordValue != "null")) {
						date2 = format.parse(nextRecordValue);
					}
					if ((date1 != null) && (date2 != null)) {
						comparing = date1.compareTo(date2);
					}
				}

				if (caseSearch.getSortOrder().equalsIgnoreCase("asc")) {
					if (comparing > 0) {
						System.out.println("currentValue:" + currentValue + ",nextRecordValue:" + nextRecordValue);
					}
					Assert.assertTrue(comparing <= 0);
				} else if (caseSearch.getSortOrder().equalsIgnoreCase("desc")) {
					if (comparing < 0) {
						System.out.println("currentValue:" + currentValue + ",nextRecordValue:" + nextRecordValue);
					}
					Assert.assertTrue(comparing >= 0);
				}

				currentValue = null;
				nextRecordValue = null;

			}
			tot = (tot + 500) > totalRecords ? totalRecords - tot : tot + 500;
			responseList = target.searchCase(caseSearch, "" + tot, OS_NAME);
		} while (tot < totalRecords);
	}

	private String getValue(Case case1, String sortField) {
		String value = null;
		if (sortField.equalsIgnoreCase("ID")) {
			value = case1.getId();
		} else if (sortField.equalsIgnoreCase("CONFIRMATION")) {
			value = case1.getConfirmation();
		} else if (sortField.equalsIgnoreCase("TYPE")) {
			value = case1.getType();
		} else if (sortField.equalsIgnoreCase("PIN")) {
			value = case1.getPin();
		} else if (sortField.equalsIgnoreCase("CLIENTID")) {
			value = case1.getClientId();
		} else if (sortField.equalsIgnoreCase("caseStatus")) {
			value = case1.getStatus();
		} else if (sortField.equalsIgnoreCase("CREATEDDATE") || sortField.equalsIgnoreCase("Case Creation Date")) {
			value = case1.getCreatedDate();
		} else if (sortField.equalsIgnoreCase("MODIFIEDDATE") || sortField.equalsIgnoreCase("Case Modified Date")) {
			value = case1.getModifiedDate();
		} else if (sortField.equalsIgnoreCase("REQUESTRECEIVEDDATE")
				|| sortField.equalsIgnoreCase("Request Received Date")) {
			value = case1.getRequestReceivedDate();
		} else if (sortField.equalsIgnoreCase("CHANNEL")) {
			value = case1.getChannel();
		}
		if (value == null) {
			value = "null";
		}
		return value;
	}

	@Test
	@Ignore
	public void testCreateDocument() throws RuntimeException, Exception {
		Document documentObj = mock(Document.class);

		when(documentObj.getIdtype()).thenReturn(ID_TYPE);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(businessUnit);
		when(documentObj.getDocCode()).thenReturn(DOC_CODE);
		when(documentObj.getDocumentName()).thenReturn(DOC_NAME);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);

		Response response = target.createDocument(OS_NAME, CASE_ID, documentObj);

		Assert.assertEquals(CommonConstants.SUCCESS, response.getStatus());
		com.filenet.api.core.Document doc = getDocument(OS_NAME, CASE_ID, response.getId(), "doc");
		ContentReference contentRef = (ContentReference) doc.get_ContentElements().get(0);

		String fdrsURL = contentRef.get_ContentLocation();
		Assert.assertEquals(ID_TYPE, getValueInUrl(fdrsURL, "idtype"));
		Assert.assertEquals(DOC_ID, getValueInUrl(fdrsURL, "id"));
		Assert.assertEquals(MIME_TYPE, getValueInUrl(fdrsURL, "mimeType"));
		Assert.assertEquals("1", getValueInUrl(fdrsURL, "version"));

		Assert.assertEquals(businessUnit, getValueInUrl(fdrsURL, "bizUnit"));
		Assert.assertEquals(DOC_CODE, getValueInUrl(fdrsURL, "docCode"));

		Assert.assertEquals(DOC_NAME, doc.get_Name());
		Assert.assertNull(response.getErrorCode());
		Assert.assertNull(response.getErrorMessage());
		DOC_INSTANCE_ID_UPDATE = response.getId();
	}

	@Test
	@Ignore
	public void testUpdateDocument() throws Exception {

		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(ID_TYPE);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(businessUnit);
		when(documentObj.getDocCode()).thenReturn(DOC_CODE);
		when(documentObj.getDocumentName()).thenReturn(DOC_NAME);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);

		Response response = target.updateDocument(OS_NAME, CASE_ID, documentObj, DOC_INSTANCE_ID_UPDATE);

		Assert.assertEquals(CommonConstants.SUCCESS, response.getStatus());
		com.filenet.api.core.Document doc = getDocument(OS_NAME, CASE_ID, response.getId(), "doc");
		ContentReference contentRef = (ContentReference) doc.get_ContentElements().get(0);

		String fdrsURL = contentRef.get_ContentLocation();
		Assert.assertEquals(ID_TYPE, getValueInUrl(fdrsURL, "idtype"));
		Assert.assertEquals(DOC_ID, getValueInUrl(fdrsURL, "id"));
		Assert.assertEquals(MIME_TYPE, getValueInUrl(fdrsURL, "mimeType"));
		Assert.assertEquals("1", getValueInUrl(fdrsURL, "version"));

		Assert.assertEquals(businessUnit, getValueInUrl(fdrsURL, "bizUnit"));
		Assert.assertEquals(DOC_CODE, getValueInUrl(fdrsURL, "docCode"));

		Assert.assertEquals(DOC_NAME, doc.get_Name());// cannot change title
		Assert.assertNull(response.getErrorCode());
		Assert.assertNull(response.getErrorMessage());

	}

	@Test
	@Ignore
	public void testCreateDocument_IdtypeNull() throws Exception {
		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(null);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(businessUnit);
		when(documentObj.getDocCode()).thenReturn(DOC_CODE);
		when(documentObj.getDocumentName()).thenReturn(DOC_NAME);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);

		target.createDocument(OS_NAME, CASE_ID, documentObj);

		Response response = target.createDocument(OS_NAME, CASE_ID, documentObj);

		Assert.assertEquals("NullPointerException: idtype cannot be null, please send a valid value",
				response.getErrorMessage());
		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertNull(response.getId());
		Assert.assertNull(response.getErrorCode());
	}

	@Test
	@Ignore
	// folder cannot be null in real time as it is "" in Document
	public void testCreateDocument_folderEmpty() throws Exception {
		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(ID_TYPE);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(businessUnit);
		when(documentObj.getDocCode()).thenReturn(DOC_CODE);
		when(documentObj.getDocumentName()).thenReturn(DOC_NAME);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn("");

		Response response = target.createDocument(OS_NAME, CASE_ID, documentObj);

		Assert.assertEquals(CommonConstants.SUCCESS, response.getStatus());
		Assert.assertNotNull(response.getId());
		Assert.assertNull(response.getErrorCode());
		Assert.assertNull(response.getErrorMessage());
	}

	@Test
	@Ignore
	public void testCreateDocument_bizUnitNull() throws Exception {

		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(ID_TYPE);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(null);
		when(documentObj.getDocCode()).thenReturn(DOC_CODE);
		when(documentObj.getDocumentName()).thenReturn(DOC_NAME);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);

		Response response = target.createDocument(OS_NAME, CASE_ID, documentObj);

		Assert.assertEquals("NullPointerException: bizUnit cannot be null, please send a valid value",
				response.getErrorMessage());
		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertNull(response.getId());
		Assert.assertNull(response.getErrorCode());
	}

	@Test
	@Ignore
	public void testCreateDocument_doCodeNull() throws Exception {
		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(ID_TYPE);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(businessUnit);
		when(documentObj.getDocCode()).thenReturn(null);
		when(documentObj.getDocumentName()).thenReturn(DOC_NAME);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);
		Response response = target.createDocument(OS_NAME, CASE_ID, documentObj);

		Assert.assertEquals("NullPointerException: docCode cannot be null, please send a valid value",
				response.getErrorMessage());
		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertNull(response.getId());
		Assert.assertNull(response.getErrorCode());
	}

	@Test
	@Ignore
	public void testCreateDocument_docNameNull() throws Exception {
		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn(ID_TYPE);
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn(businessUnit);
		when(documentObj.getDocCode()).thenReturn(DOC_CODE);
		when(documentObj.getDocumentName()).thenReturn(null);
		when(documentObj.getMimeType()).thenReturn(MIME_TYPE);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);

		Response response = target.createDocument(OS_NAME, CASE_ID, documentObj);

		Assert.assertEquals("NullPointerException: docName cannot be null, please send a valid value",
				response.getErrorMessage());
		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertNull(response.getId());
		Assert.assertNull(response.getErrorCode());
	}

	@Test
	@Ignore
	public void testCreateDocument_mimeTypeNull() throws Exception {
		Document documentObj = mock(Document.class);
		when(documentObj.getIdtype()).thenReturn("VJidType");
		when(documentObj.getId()).thenReturn(DOC_ID);
		when(documentObj.getBusinessUnit()).thenReturn("VJbizUnit");
		when(documentObj.getDocCode()).thenReturn("VJdocCode");
		when(documentObj.getDocumentName()).thenReturn("VJdocName");
		when(documentObj.getMimeType()).thenReturn(null);
		when(documentObj.getFormatType()).thenReturn(FormatType.Document.toString());
		when(documentObj.getFolder()).thenReturn(DOC_FOLDER);
		Response response = target.createDocument(OS_NAME, CASE_ID, documentObj);

		Assert.assertEquals("NullPointerException: mimeType cannot be null, please send a valid value",
				response.getErrorMessage());
		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertNull(response.getId());
		Assert.assertNull(response.getErrorCode());
	}

	@Test
	@Ignore
	public void testAddCaseComments_Valid() {
		try {
			Response response = target.addCaseComments(OS_NAME, CASE_ID, CASE_COMMENT_TEXT);

			List<Comment> commentsList = target.getComments(OS_NAME, CASE_ID);
			for (Comment comment : commentsList) {
				if (comment.getId().equals(response.getId())) {
					Assert.assertEquals(CASE_COMMENT_TEXT, comment.getComment());
				}
			}
			Assert.assertEquals(CommonConstants.SUCCESS, response.getStatus());
			Assert.assertNull(response.getErrorCode());
			Assert.assertNull(response.getErrorMessage());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test
	@Ignore
	public void testAddCaseComments_NullCaseId() {
		try {
			Response response = target.addCaseComments(OS_NAME, null, CASE_COMMENT_TEXT);

			Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
			Assert.assertEquals(CommonConstants.NULL_POINTER_CUSTOM_MSG, response.getErrorMessage());
			Assert.assertNull(response.getErrorCode());
			Assert.assertNull(response.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	@Ignore
	public void testAddCaseComments_InvalidCaseId() {
		try {
			Response response = target.addCaseComments(OS_NAME, INVALID_ID, CASE_COMMENT_TEXT);
			Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
			Assert.assertEquals("Invalid input parameter: Name=id, Value=" + INVALID_ID + ".",
					response.getErrorMessage());
			Assert.assertEquals("FNRCE0007", response.getErrorCode().toString());
			Assert.assertNull(response.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Test
	@Ignore
	public void testAddCaseComments_nullComments() throws Exception {

		Response response = target.addCaseComments(OS_NAME, CASE_ID, null);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals(
				"A required property value has not been set. Required singleton property CmAcmCommentText has no value.",
				response.getErrorMessage());
		Assert.assertEquals("FNRCE0058", response.getErrorCode());
		Assert.assertNull(response.getId());

	}

	//////////////////////////////////////////////////////////////////// DOCUMENT///////////////////////////////////////////////////////////////////////////////////
	@Test
	@Ignore
	public void testAddDocumentComments_Valid() throws Exception {
		Response response = target.addDocumentComments(OS_NAME, CASE_ID, DOC_INSTANCE_ID, DOC_COMMENT_TEXT);

		Assert.assertEquals(CommonConstants.SUCCESS, response.getStatus());
		List<Comment> commentsList = target.getComments(OS_NAME, CASE_ID);
		for (Comment comment : commentsList) {
			if (comment.getId().equals(response.getId())) {
				Assert.assertEquals(DOC_COMMENT_TEXT, comment.getComment());
			}
		}
		Assert.assertNull(response.getErrorCode());
		Assert.assertNull(response.getErrorMessage());
	}

	@Test
	@Ignore
	public void testAddDocumentComments_nullCaseId() throws Exception {
		Response response = target.addDocumentComments(OS_NAME, null, DOC_INSTANCE_ID, DOC_COMMENT_TEXT);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals("NullPointerException - please check all the data sent", response.getErrorMessage());
		Assert.assertNull(response.getId());
		Assert.assertNull(response.getErrorCode());
	}

	@Test
	@Ignore
	public void testAddDocumentComments_invalidCaseId() throws Exception {
		Response response = target.addDocumentComments(OS_NAME, INVALID_ID, DOC_INSTANCE_ID, DOC_COMMENT_TEXT);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals("FNRCE0007", response.getErrorCode());
		Assert.assertEquals("Invalid input parameter: Name=id, Value=" + INVALID_ID + ".", response.getErrorMessage());
		Assert.assertNull(response.getId());
	}

	@Test
	@Ignore
	public void testAddDocumentComments_nullDocId() throws Exception {
		Response response = target.addDocumentComments(OS_NAME, CASE_ID, null, DOC_COMMENT_TEXT);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals("FNRCR0016", response.getErrorCode());
		// the following message as it fails at fetch itself
		Assert.assertEquals("Can\'t compare dissimilar types.  Near: \'doc...)\'", response.getErrorMessage());
		Assert.assertNull(response.getId());
	}

	@Test
	@Ignore
	// need to modify this method once AOP is implemented
	public void testAddDocumentComments_invalidDocId() throws Exception {
		Response response = target.addDocumentComments(OS_NAME, CASE_ID, INVALID_ID, DOC_COMMENT_TEXT);

		if (Id.isId(INVALID_ID)) {
			System.out.println("valid Id");
		} else {
			System.out.println("invalid id");
		}

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals("FNRCR0016", response.getErrorCode());

		Assert.assertEquals("Can\'t compare dissimilar types.  Near: \'doc...)\'", response.getErrorMessage());
		Assert.assertNull(response.getId());
	}

	@Test
	@Ignore
	public void testAddDocumentComments_nullComments() throws Exception {
		Response response = target.addDocumentComments(OS_NAME, CASE_ID, DOC_INSTANCE_ID, null);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals(
				"A required property value has not been set. Required singleton property CmAcmCommentText has no value.",
				response.getErrorMessage());
		Assert.assertEquals("FNRCE0058", response.getErrorCode());
		Assert.assertNull(response.getId());
	}

	////////////////////////////////////////////////////////////////////// TASK//////////////////////////////////////////////////////////////////////
	@Test
	@Ignore
	public void testAddTaskComments_valid() throws Exception {
		Response response = target.addTaskComments(OS_NAME, CASE_ID, TASK_ID, TASK_COMMENT_TEXT);

		Assert.assertEquals(CommonConstants.SUCCESS, response.getStatus());
		List<Comment> commentsList = target.getComments(OS_NAME, CASE_ID);
		for (Comment comment : commentsList) {
			if (comment.getId().equals(response.getId())) {
				Assert.assertEquals(TASK_COMMENT_TEXT, comment.getComment());
			}
		}
		Assert.assertNull(response.getErrorCode());
	}

	@Test
	@Ignore
	public void testAddTaskComments_nullCaseId() throws Exception {
		Response response = target.addTaskComments(OS_NAME, null, TASK_ID, TASK_COMMENT_TEXT);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals("NullPointerException - please check all the data sent", response.getErrorMessage());
		Assert.assertNull(response.getId());
		Assert.assertNull(response.getErrorCode());

	}

	@Test
	@Ignore
	public void testAddTaskComments_invalidCaseId() throws Exception {
		Response response = target.addTaskComments(OS_NAME, INVALID_ID, TASK_ID, TASK_COMMENT_TEXT);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals("FNRCE0007", response.getErrorCode());
		Assert.assertEquals("Invalid input parameter: Name=id, Value=" + INVALID_ID + ".", response.getErrorMessage());
		Assert.assertNull(response.getId());

	}

	@Test
	@Ignore
	public void testAddTaskComments_nullTaskId() throws Exception {
		Response response = target.addTaskComments(OS_NAME, CASE_ID, null, TASK_COMMENT_TEXT);

		logger.debug(response.getErrorCode());
		logger.debug(response.getErrorMessage());
		logger.debug(response.getStatus());
		logger.debug(response.getId());

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertTrue(response.getErrorMessage().startsWith(
				"NullPointerException: Could not find task null, in folder: Class=com.filenet.apiimpl.core.FolderImpl AccessAllowed="));

		Assert.assertNull(response.getId());

	}

	@Test
	@Ignore
	public void testAddTaskComments_invalidTaskId() throws Exception {
		Response response = target.addTaskComments(OS_NAME, INVALID_ID, INVALID_ID, TASK_COMMENT_TEXT);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals("FNRCE0007", response.getErrorCode());
		Assert.assertEquals("Invalid input parameter: Name=id, Value=" + INVALID_ID + ".", response.getErrorMessage());
		Assert.assertNull(response.getId());

	}

	@Test
	@Ignore
	public void testAddTaskComments_nullComments() throws Exception {
		Response response = target.addTaskComments(OS_NAME, CASE_ID, TASK_ID, null);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals(
				"A required property value has not been set. Required singleton property CmAcmCommentText has no value.",
				response.getErrorMessage());
		Assert.assertEquals("FNRCE0058", response.getErrorCode());
		Assert.assertNull(response.getId());
	}

	@Test
	@Ignore
	public void testAddTaskComments_taskIdCaseIdInterChanged() throws Exception {
		Response response = target.addTaskComments(OS_NAME, TASK_ID, CASE_ID, TASK_COMMENT_TEXT);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals("The requested item was not found. Object identity: classId=Folder&objectId=" + TASK_ID
				+ "&objectStore=" + OS_ID + ".  Class name: Folder.", response.getErrorMessage());
		Assert.assertEquals("FNRCE0051", response.getErrorCode());
		Assert.assertNull(response.getId());
	}

	@Test
	@Ignore
	public void testAddTaskComments_taskIdValidCaseIdTaskIdSame() throws Exception {
		Response response = target.addTaskComments(OS_NAME, TASK_ID, TASK_ID, TASK_COMMENT_TEXT);

		logger.debug(response.getErrorCode());
		logger.debug(response.getErrorMessage());
		logger.debug(response.getStatus());
		logger.debug(response.getId());

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals("The requested item was not found. Object identity: classId=Folder&objectId=" + TASK_ID
				+ "&objectStore=" + OS_ID + ".  Class name: Folder.", response.getErrorMessage());
		Assert.assertEquals("FNRCE0051", response.getErrorCode());
		Assert.assertNull(response.getId());
	}

	/////////////////////////////////////////////////////////////////////////////// ALL
	/////////////////////////////////////////////////////////////////////////////// COMMENTS/////////////////////////////////////////////////////////////////
	@Test
	@Ignore
	public void testGetComments() throws Exception {
		List<Comment> commentsList = target.getComments(OS_NAME, CASE_ID);

		for (Comment eachComment : commentsList) {
			logger.debug("comment:" + eachComment.getComment() + "-type:" + eachComment.getType());
		}
	}

	@Test
	@Ignore
	public void testGetComments_checkDescription_valid() throws Exception {
		List<Comment> commentsList = target.getComments(OS_NAME, CASE_ID);

		for (Comment eachComment : commentsList) {
			logger.debug("description:" + eachComment.getDescription() + "-type:" + eachComment.getType());
			if (eachComment.getType().equals(CommentType.CmAcmCaseComment.toString())) {
				Assert.assertEquals("Comment added to case", eachComment.getDescription());
			} else if (eachComment.getType().equals(CommentType.CmAcmTaskComment.toString())) {
				Assert.assertEquals("Comment added to null activity.", eachComment.getDescription());
			}

			// cannot test others as they keep changing for each document and
			// step.
		}
	}

	//////////////////////////////////////////////////////////////////////// STEP
	//////////////////////////////////////////////////////////////////////// COMMENTS/////////////////////////////////////////////////////////////////////////////
	@Test
	@Ignore
	public void testAddStepComments_valid() throws Exception {
		Response response = target.stepComments(OS_NAME, CASE_ID, WOB_ID, QUEUE_NAME, STEP_COMMENT_TEXT, RACF_ID);

		Assert.assertEquals(CommonConstants.SUCCESS, response.getStatus());
		List<Comment> commentsList = target.getComments(OS_NAME, CASE_ID);
		for (Comment comment : commentsList) {
			if (comment.getId().equals(response.getId())) {
				Assert.assertEquals(STEP_COMMENT_TEXT, comment.getComment());
			}
		}
		Assert.assertNull(response.getErrorCode());
		Assert.assertNull(response.getErrorMessage());
	}

	@Test
	@Ignore
	public void testAddStepComments_nullCaseId() throws Exception {
		Response response = target.stepComments(OS_NAME, null, WOB_ID, QUEUE_NAME, STEP_COMMENT_TEXT, RACF_ID);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals(CommonConstants.NULL_POINTER_CUSTOM_MSG, response.getErrorMessage());
		Assert.assertNull(response.getId());
		Assert.assertNull(response.getErrorCode());
	}

	@Test
	@Ignore
	public void testAddStepComments_invalidCaseId() throws Exception {
		Response response = target.stepComments(OS_NAME, INVALID_ID, WOB_ID, QUEUE_NAME, STEP_COMMENT_TEXT, RACF_ID);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals("FNRCE0007", response.getErrorCode());
		Assert.assertEquals("Invalid input parameter: Name=id, Value=" + INVALID_ID + ".", response.getErrorMessage());
		Assert.assertNull(response.getId());

	}

	@Test
	@Ignore
	public void testAddStepComments_nullWobId() throws Exception {
		Response response = target.stepComments(OS_NAME, CASE_ID, null, QUEUE_NAME, STEP_COMMENT_TEXT, RACF_ID);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals("Work Item is not found of Wob ID : null for Queue: " + QUEUE_NAME,
				response.getErrorMessage());
		Assert.assertNull(response.getId());
		Assert.assertNull(response.getErrorCode());

	}

	@Test
	@Ignore
	public void testAddStepComments_invalidWobId() throws Exception {
		Response response = target.stepComments(OS_NAME, CASE_ID, INVALID_ID, QUEUE_NAME, STEP_COMMENT_TEXT, RACF_ID);

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals("Work Item is not found of Wob ID : INVALID_ID for Queue: " + QUEUE_NAME,
				response.getErrorMessage());
		Assert.assertNull(response.getId());
		Assert.assertNull(response.getErrorCode());

	}

	@Test
	@Ignore
	public void testAddStepComments_nullQueueName() throws Exception {
		Response response = target.stepComments(OS_NAME, CASE_ID, WOB_ID, null, STEP_COMMENT_TEXT, RACF_ID);

		logger.debug(response.getErrorCode());
		logger.debug(response.getErrorMessage());
		logger.debug(response.getStatus());
		logger.debug(response.getId());

		Assert.assertEquals(CommonConstants.ERROR, response.getStatus());
		Assert.assertEquals("The queue name is null or empty.", response.getErrorMessage());
		// Assert.assertEquals("Work Item is not found of Wob ID : " + WOB_ID +
		// " for Queue: null",
		// response.getErrorMessage());
		Assert.assertNull(response.getId());
		Assert.assertNull(response.getErrorCode());

	}

	/////////////////////////////////////////////////////////////////////////////////////// WOB
	/////////////////////////////////////////////////////////////////////////////////////// ID/////////////////////////////////////////////////////////////////////
	@Test
	@Ignore
	public void getWobId() {
		Folder caseFolder = Factory.Folder.fetchInstance(getOS(OS_NAME), CASE_ID, null);
		String wobID = null;
		CmTaskSet tasks = caseFolder.get_CoordinatedTasks();
		logger.debug(tasks);
		Iterator<CmTask> taskIterator = tasks.iterator();

		while (taskIterator.hasNext()) {
			CmTask myTask = taskIterator.next();
			logger.debug("taskId on the case:" + myTask.get_Id().toString() + ",expected is:" + TASK_ID);
			if (myTask.get_Id().toString().equals(TASK_ID)) {
				wobID = myTask.getProperties().getStringValue("CmAcmProcessInstanceId");
				logger.debug("Process Instance Id after launch " + wobID);
			}

		}

	}

	@After
	public void tearDown() throws Exception {
	}

	private com.filenet.api.core.Document getDocument(String osName, String caseID, String documentId, String alias)
			throws RuntimeException, Exception {
		Folder caseFolder = Factory.Folder.fetchInstance(getOS(osName), caseID, null);
		String caseFolderPath = caseFolder.getProperties().getStringValue("PathName");
		SearchSQL docSearchSQL = new SearchSQL();
		String select = alias + ".id, " + alias + ".MimeType, " + alias + ".Name, " + alias + ".CmAcmAssociatedCase, "
				+ alias + ".ContentElements, " + alias + ".FoldersFiledIn," + alias + ".VersionSeries";
		docSearchSQL.setSelectList(select);
		String className = "Document"; // always OOTB base class
		docSearchSQL.setFromClauseInitialValue(className, alias, true);
		String whereClause = "doc.Id = ('" + documentId + "') and doc.CmAcmAssociatedCase = Object('" + caseFolderPath
				+ "')";
		docSearchSQL.setWhereClause(whereClause);
		// LOG.debug("Doc SQL Search -->" + docSearchSQL.toString());
		SearchScope scope = new SearchScope(getOS(osName));
		DocumentSet docSet = (DocumentSet) scope.fetchObjects(docSearchSQL, PAGE_SIZE, null, new Boolean(true));
		Iterator<com.filenet.api.core.Document> iterator = docSet.iterator();
		if (!iterator.hasNext()) {
			throw new RuntimeException("Not found any Document with ID:" + documentId + " in the case ID:" + caseID);
		}
		com.filenet.api.core.Document document = iterator.next();
		printAllVersions(document);
		return getLatestVersionDoc(document);
	}

	private void printAllVersions(com.filenet.api.core.Document document) {
		VersionSeries vs = document.get_VersionSeries();
		VersionableSet vss = vs.get_Versions();

		Iterator vssiter = vss.iterator();

		int major = 0;
		int minor = 0;
		while (vssiter.hasNext()) {
			Versionable ver = (Versionable) vssiter.next();

			System.out.println("Major = " + ver.get_MajorVersionNumber() + "; Minor = " + ver.get_MinorVersionNumber());
			com.filenet.api.core.Document filenetDoc = (com.filenet.api.core.Document) ver;
			Object content = filenetDoc.get_ContentElements().get(0);
			if (content instanceof ContentReference) {
				ContentReference reference = (ContentReference) content;
				String fdrsURL = reference.get_ContentLocation();
				System.out.println("fdrsurl:" + fdrsURL);
			}
		}

	}

	private com.filenet.api.core.Document getLatestVersionDoc(com.filenet.api.core.Document document) {
		VersionSeries versionableSeries = document.get_VersionSeries();
		com.filenet.api.core.Document latestVersionDoc = (com.filenet.api.core.Document) versionableSeries
				.get_CurrentVersion();
		return latestVersionDoc;
	}

	private String getValueInUrl(String fdrsURL, String string) {

		String value = "";
		if (params == null) {
			params = fdrsURL.substring(fdrsURL.indexOf("?") + 1).split("&");
		}
		for (String queryParam : params) {
			int index = queryParam.indexOf("=") + 1;
			String param = queryParam.substring(0, queryParam.indexOf("="));
			if (param.equalsIgnoreCase(string)) {
				value = queryParam.substring(index);
			} else if (param.equalsIgnoreCase(string)) {
				value = queryParam.substring(index);
			} else if (param.equalsIgnoreCase(string)) {
				value = queryParam.substring(index);
			} else if (param.equalsIgnoreCase(string)) {
				value = queryParam.substring(index);
			} else if (param.equalsIgnoreCase(string)) {
				value = queryParam.substring(index);
			} else if (param.equalsIgnoreCase(string)) {
				try {
					value = URLDecoder.decode(queryParam.substring(index), "UTF-8");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return value;
	}

	private ObjectStore getOS(String osName) {
		if (!objectStores.containsKey(osName)) {
			Connection conn = Factory.Connection.getConnection(ejbURI);
			Domain domain = Factory.Domain.fetchInstance(conn, null, null);
			ObjectStore os = Factory.ObjectStore.fetchInstance(domain, osName, null);
			objectStores.put(osName, os);
		}
		return objectStores.get(osName);

	}

	private VWSession getVWSession() throws VWException {
		if (vwSession == null) {
			vwSession = new VWSession(connectionPoint);
		}
		return vwSession;
	}

}
