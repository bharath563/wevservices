package org.tiaa.icm.client.infocaddy.bo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.security.auth.Subject;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import org.apache.log4j.Logger;

import org.springframework.context.support.FileSystemXmlApplicationContext;

import org.tiaa.icm.client.infocaddy.bean.InfoCaddyBean;

import junit.framework.Assert;

public class InfoCaddyBeanTest {

	static Logger logger = Logger.getLogger(InfoCaddyBeanTest.class);

	Subject subject;

	InfoCaddyBean target;
	// Response response;

	Context ic;

	@Before
	public void setUp() throws Exception {

		FileSystemXmlApplicationContext context = new FileSystemXmlApplicationContext(
				"src/main/webapp/WEB-INF/icm-client-rs-v1-context.xml");

		target = context.getBean(InfoCaddyBean.class);

	}

	@Test
	@Ignore
	public void testGetInfoCaddyDetails_POGeneral() {

		String caseid = "{1296CB3A-F3E6-48B0-A890-1031F661474D}";
		String solution = "Payout Operations";
		String section = "General";
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("start", "");
		parameters.put("sortBy", "");
		parameters.put("sortOrder", "");
		parameters.put("tableName", "");
		parameters.put("groupId", "");

		try {
			List<Object> poInfoCaddyDetails = target.getInfoCaddyDetails(caseid, solution, section, parameters);

			Assert.assertNotNull(poInfoCaddyDetails);
			Assert.assertEquals(poInfoCaddyDetails, poInfoCaddyDetails);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testGetInfoCaddyDetails_POOmni() {

		String caseid = "{3BFF77C8-27B2-4E11-9F2A-670F00D3F6A9}";
		String solution = "Payout Operations";
		String section = "omni";
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("start", "");
		parameters.put("sortBy", "");
		parameters.put("sortOrder", "");
		parameters.put("tableName", "");
		parameters.put("groupId", "");
		try {
			List<Object> poInfoCaddyDetails = target.getInfoCaddyDetails(caseid, solution, section, parameters);

			Assert.assertNotNull(poInfoCaddyDetails);
			Assert.assertEquals(poInfoCaddyDetails, poInfoCaddyDetails);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testGetInfoCaddyDetails_POQC() {

		String caseid = "{20BDFD35-F0E6-4B85-87BB-C4B89EF66ACA}";
		String solution = "Payout Operations";
		String section = "qc";
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("start", "");
		parameters.put("sortBy", "");
		parameters.put("sortOrder", "");
		parameters.put("tableName", "");
		parameters.put("groupId", "");
		try {
			List<Object> poInfoCaddyDetails = target.getInfoCaddyDetails(caseid, solution, section, parameters);

			Assert.assertNotNull(poInfoCaddyDetails);
			Assert.assertEquals(poInfoCaddyDetails, poInfoCaddyDetails);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testGetInfoCaddyDetails_PMOGeneral() {
		String caseid = "{78595F98-83C8-403E-91F5-5746169EF9CA}";
		String solution = "Participant Maintenance Operations";
		String section = "General";
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("start", "");
		parameters.put("sortBy", "");
		parameters.put("sortOrder", "");
		parameters.put("tableName", "");
		parameters.put("groupId", "");
		try {
			List<Object> pmoInfoCaddyDetails = target.getInfoCaddyDetails(caseid, solution, section, parameters);

			Assert.assertNotNull(pmoInfoCaddyDetails);
			Assert.assertEquals(pmoInfoCaddyDetails, pmoInfoCaddyDetails);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testGetInfoCaddyDetails_PMOOmni() {
		String caseid = "{78595F98-83C8-403E-91F5-5746169EF9CA}";
		String solution = "Participant Maintenance Operations";
		String section = "omni";
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("start", "");
		parameters.put("sortBy", "");
		parameters.put("sortOrder", "");
		parameters.put("tableName", "");
		parameters.put("groupId", "");
		try {
			List<Object> pmoInfoCaddyDetails = target.getInfoCaddyDetails(caseid, solution, section, parameters);

			Assert.assertNotNull(pmoInfoCaddyDetails);
			Assert.assertEquals(pmoInfoCaddyDetails, pmoInfoCaddyDetails);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testGetInfoCaddyDetails_TOGeneral() {
		String caseid = "{1C49A82E-BAE7-4D0C-9596-38AD03937CF0}";
		String solution = "Transfer Operations";
		String section = "General";
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("start", "");
		parameters.put("sortBy", "");
		parameters.put("sortOrder", "");
		parameters.put("tableName", "");
		parameters.put("groupId", "");
		try {
			List<Object> toInfoCaddyDetails = target.getInfoCaddyDetails(caseid, solution, section, parameters);

			Assert.assertNotNull(toInfoCaddyDetails);
			Assert.assertEquals(toInfoCaddyDetails, toInfoCaddyDetails);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testGetInfoCaddyDetails_TOOmni() {
		String caseid = "{D79D33EF-FCDD-43EA-94E6-B68F417CD1B8}";
		String solution = "Transfer Operations";
		String section = "omni";
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("start", "");
		parameters.put("sortBy", "");
		parameters.put("sortOrder", "");
		parameters.put("tableName", "");
		parameters.put("groupId", "");
		try {
			List<Object> toInfoCaddyDetails = target.getInfoCaddyDetails(caseid, solution, section, parameters);

			Assert.assertNotNull(toInfoCaddyDetails);
			Assert.assertEquals(toInfoCaddyDetails, toInfoCaddyDetails);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testGetInfoCaddyDetails_TOQC() {
		String caseid = "{78595F98-83C8-403E-91F5-5746169EF9CA}";
		String solution = "Transfer Operations";
		String section = "qc";
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("start", "");
		parameters.put("sortBy", "");
		parameters.put("sortOrder", "");
		parameters.put("tableName", "");
		parameters.put("groupId", "");

		try {
			List<Object> toInfoCaddyDetails = target.getInfoCaddyDetails(caseid, solution, section, parameters);

			Assert.assertNotNull(toInfoCaddyDetails);
			Assert.assertEquals(toInfoCaddyDetails, toInfoCaddyDetails);
		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testGetInfoCaddyDetails_ISGeneral() {

		String caseid = "{500A946E-B493-462D-92F8-C60C9934D610}";
		String solution = "Institutional Servicing";
		String section = "General";
		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("start", "");
		parameters.put("sortBy", "");
		parameters.put("sortOrder", "");
		parameters.put("tableName", "");
		parameters.put("groupId", "");
		try {
			List<Object> isInfoCaddyDetails = target.getInfoCaddyDetails(caseid, solution, section, parameters);

			Assert.assertNotNull(isInfoCaddyDetails);
			Assert.assertEquals(isInfoCaddyDetails, isInfoCaddyDetails);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	@Ignore
	public void testGetOrderedRecentCases() {

		String caseid = "{7BD590FD-55B0-4C36-A2C7-CE13028B2CFA}";
		String solution = "Institutional Servicing";
		String section = "General";

		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("start", "5");
		parameters.put("sortBy", "caseid");
		parameters.put("sortOrder", "ASC");
		parameters.put("tableName", "");
		parameters.put("groupId", "");

		List<Object> isInfoCaddyDetails = null;

		try {
			isInfoCaddyDetails = target.getInfoCaddyDetails(caseid, solution, section, parameters);

			Assert.assertNotNull(isInfoCaddyDetails);
			Assert.assertEquals(isInfoCaddyDetails, isInfoCaddyDetails);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

	@Test
	// @Ignore
	public void testGetOmniDetails() {

		String caseid = "{E7D2DB48-1204-4ED1-A311-8FBCA16756F5}";
		String solution = "Payin Operations";
		String section = "General";

		Map<String, String> parameters = new HashMap<String, String>();
		parameters.put("start", "");
		parameters.put("sortBy", "");
		parameters.put("sortOrder", "");
		parameters.put("tableName", "");
		parameters.put("groupId", "");

		List<Object> isInfoCaddyDetails = null;

		try {
			isInfoCaddyDetails = target.getInfoCaddyDetails(caseid, solution, section, parameters);

			Assert.assertNotNull(isInfoCaddyDetails);
			Assert.assertEquals(isInfoCaddyDetails, isInfoCaddyDetails);

		} catch (Exception e) {
			e.printStackTrace();
			Assert.fail();
		}
	}

}
