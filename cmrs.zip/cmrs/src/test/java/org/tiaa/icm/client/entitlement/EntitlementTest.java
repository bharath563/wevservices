package org.tiaa.icm.client.entitlement;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import org.apache.log4j.Logger;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import org.tiaa.icm.client.cache.ICMClientCache;
import org.tiaa.icm.client.cache.SolutionConfigCache;
import org.tiaa.icm.client.cache.SolutionConfigCreator;
import org.tiaa.icm.client.domain.entitlement.OperationalRole;

public class EntitlementTest {

	static Logger LOG = Logger.getLogger(EntitlementTest.class);
	AbstractSolution solution = null;

	String ejbURI = "iiop://chadvt3esfnfe2.ops.tiaa-cref.org:9810";
	Context ic;

	@Before
	public void setup() {
		ceInit();

		ApplicationContext context = new FileSystemXmlApplicationContext(
				"src/main/webapp/WEB-INF/icm-client-rs-v1-context.xml");
		Assert.assertNotNull(context.getBean(SolutionConfigCreator.class));

		solution = new BaseSolution();

	}

	private void ceInit() {

		System.setProperty("java.security.auth.login.config",
				"C:/app/IBM/Filenet/AE/CE_API/config/jaas.conf.WebSphere");
		System.setProperty("java.naming.factory.initial", "com.ibm.websphere.naming.WsnInitialContextFactory");
		System.setProperty("com.ibm.CORBA.ConfigURL", "file:///C:/app/IBM/WAS/AppClient/properties/sas.client.props");

		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put("org.omg.CORBA.ORBClass", "com.ibm.CORBA.iiop.ORB");
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.websphere.naming.WsnInitialContextFactory");
		env.put(Context.PROVIDER_URL, ejbURI);//

		try {
			ic = new InitialContext(env);
			ic.lookup("");
		} catch (NamingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

	@Test
	// test user ids..
	// TST_OPS_ID4 for PO
	// TST_OPS_ID35 for TO

	public void testPayoutProcessorWithdrawals() {

		List<String> ldaps = new ArrayList<String>();

		// for L3 user
		ldaps.add("AP_CM_ROLE_WITHDRAWAL_PROCESSOR_TEST");
		ldaps.add("AP_UD_SPC_ONSHORE_USER_TEST");
		ldaps.add("IS_ST_TIAAEMP_AM");
		OperationalRole queue = solution.getUserEntitledRoles("ganapaa", "Payout Operations", ldaps, "Unassigned")
				.iterator().next();

		Assert.assertNotNull(queue);
		Assert.assertTrue(queue.getRoleName().equals("Processor Withdrawals - L3"));

		// for L2 user
		ldaps = new ArrayList<String>();
		ldaps.add("AP_UD_BUS_OPS_PROCESSOR_TEST");
		ldaps.add("AP_UD_SPC_ONSHORE_USER_TEST");
		queue = solution.getUserEntitledRoles("ganapaa", "Payout Operations", ldaps, "Unassigned").iterator().next();
		Assert.assertNotNull(queue);
		Assert.assertTrue(queue.getRoleName().equals("Processor Withdrawals - L2"));

		// for L1 user
		ldaps = new ArrayList<String>();
		ldaps.add("AP_UD_APP_CM_OPS_PROCESSOR_ALL_WTHDRWLS_TEST");
		queue = solution.getUserEntitledRoles("ganapaa", "Payout Operations", ldaps, "Unassigned").iterator().next();
		Assert.assertNotNull(queue);
		Assert.assertTrue(queue.getRoleName().equals("Processor Withdrawals"));

		// Pended Test cases...
		// ldaps = new ArrayList<String>();
		// ldaps = new ArrayList<String>();
		ldaps.add("AP_CM_ROLE_WITHDRAWAL_PROCESSOR_TEST");
		ldaps.add("AP_UD_SPC_ONSHORE_USER_TEST");
		ldaps.add("IS_ST_TIAAEMP_AM");
		List<OperationalRole> queues = solution.getUserEntitledRoles("ganapaa", "Payout Operations", ldaps, "Pended");
		Assert.assertNotNull(queues);
		queue = queues.get(0);
		Assert.assertTrue(queue.getQueueNames().get(0).equals("PO_ProcessorPended"));
		Assert.assertTrue(queue.getRoleName().equals("Processor Withdrawals - L3"));
		// Since we added two role level ldaps we shouldn't get 2 queue object
		// of same type..
		Assert.assertTrue(queues.size() == 1);

		// for L2 user
		ldaps = new ArrayList<String>();
		ldaps.add("AP_UD_BUS_OPS_PROCESSOR_TEST");
		ldaps.add("AP_UD_SPC_ONSHORE_USER_TEST");
		queue = solution.getUserEntitledRoles("ganapaa", "Payout Operations", ldaps, "Pended").iterator().next();
		Assert.assertNotNull(queue);
		Assert.assertTrue(queue.getQueueNames().get(0).equals("PO_ProcessorPended"));
		Assert.assertTrue(queue.getRoleName().equals("Processor Withdrawals - L2"));

		// for L1 user
		ldaps = new ArrayList<String>();
		ldaps.add("AP_UD_APP_CM_OPS_PROCESSOR_ALL_WTHDRWLS_TEST");
		queue = solution.getUserEntitledRoles("ganapaa", "Payout Operations", ldaps, "Pended").iterator().next();
		Assert.assertNotNull(queue);
		Assert.assertTrue(queue.getQueueNames().get(0).equals("PO_ProcessorPended"));
		Assert.assertTrue(queue.getRoleName().equals("Processor Withdrawals"));
	}

	@Test
	public void testPayoutProcessorLoans() {

		List<String> ldaps = new ArrayList<String>();

		// for Processor Loans L1 ldaps = new ArrayList<String>();
		ldaps.add("AP_UD_APP_CM_OPS_PROCESSOR_LOANS_TEST");
		OperationalRole queue = solution.getUserEntitledRoles("ganapaa", "Payout Operations", ldaps, "Unassigned")
				.get(0);
		Assert.assertNotNull(queue);
		Assert.assertTrue(queue.getRoleName().equals("Processor Loans"));

		// for Processor Loans L2 ldaps = new ArrayList<String>();
		ldaps.add("AP_UD_APP_CM_OPS_PROCESSOR_LOANS_TEST");
		ldaps.add("AP_UD_SPC_ONSHORE_USER_TEST");
		queue = solution.getUserEntitledRoles("ganapaa", "Payout Operations", ldaps, "Unassigned").get(0);
		Assert.assertNotNull(queue);
		Assert.assertTrue(queue.getRoleName().equals("Processor Loans - L2"));

		// for Processor Loans L3 ldaps = new ArrayList<String>();
		ldaps.add("AP_UD_APP_CM_OPS_PROCESSOR_LOANS_TEST");
		ldaps.add("AP_UD_SPC_ONSHORE_USER_TEST");
		ldaps.add("IS_ST_TIAAEMP_AM");
		queue = solution.getUserEntitledRoles("ganapaa", "Payout Operations", ldaps, "Unassigned").get(0);
		Assert.assertNotNull(queue);
		Assert.assertTrue(queue.getRoleName().equals("Processor Loans - L3"));

		ldaps.clear();

		// for Processor Loans L1 ldaps = new ArrayList<String>();
		ldaps.add("AP_UD_APP_CM_OPS_PROCESSOR_LOANS_TEST");
		queue = solution.getUserEntitledRoles("ganapaa", "Payout Operations", ldaps, "Pended").get(0);
		Assert.assertNotNull(queue);
		Assert.assertTrue(queue.getRoleName().equals("Processor Loans"));

		// for Processor Loans L2 ldaps = new ArrayList<String>();
		ldaps.add("AP_UD_APP_CM_OPS_PROCESSOR_LOANS_TEST");
		ldaps.add("AP_UD_SPC_ONSHORE_USER_TEST");
		queue = solution.getUserEntitledRoles("ganapaa", "Payout Operations", ldaps, "Pended").get(0);
		Assert.assertNotNull(queue);
		Assert.assertTrue(queue.getRoleName().equals("Processor Loans - L2"));

		// for Processor Loans L3 ldaps = new ArrayList<String>();
		ldaps.add("AP_UD_APP_CM_OPS_PROCESSOR_LOANS_TEST");
		ldaps.add("AP_UD_SPC_ONSHORE_USER_TEST");
		ldaps.add("IS_ST_TIAAEMP_AM");
		queue = solution.getUserEntitledRoles("ganapaa", "Payout Operations", ldaps, "Pended").get(0);
		Assert.assertNotNull(queue);
		Assert.assertTrue(queue.getRoleName().equals("Processor Loans - L3"));

	}

	/*
	 * @Test
	 *
	 * public void testPayoutQCProcessor() {
	 *
	 * // for QCProcessor Loans L1 List<String> ldaps = new //
	 * ArrayList<String>(); ldaps = new ArrayList<String>();
	 * ldaps.add("%AP_UD_BUS_OPS_QUAL_CNTRL_ASSOC%"); Queue queue; queue =
	 * solution.getQueues("ganapaa", "Payout Operations", ldaps,
	 * "unassigned").get(0); Assert.assertNotNull(queue);
	 * Assert.assertTrue(queue.getRoleName().equals("QCProcessor"));
	 *
	 * // for QCProcessor Loans L2 ldaps = new ArrayList<String>();
	 * ldaps.add("%AP_UD_BUS_OPS_QUAL_CNTRL_ASSOC%");
	 * ldaps.add("%AP_UD_SPC_ONSHORE_USER%"); queue =
	 * solution.getQueues("ganapaa", "Payout Operations", ldaps,
	 * "unassigned").get(0); Assert.assertNotNull(queue);
	 * Assert.assertTrue(queue.getRoleName().equals("QCProcessor - L2"));
	 *
	 * // for QC Processor L3 ldaps = new ArrayList<String>();
	 * ldaps.add("%AP_UD_BUS_OPS_QUAL_CNTRL_ASSOC%");
	 * ldaps.add("AP_UD_ROLE_ONSHORE_USER_TEST"); ldaps.add("IS_ST_TIAAEMP_AM");
	 * queue = solution.getQueues("ganapaa", "Payout Operations", ldaps,
	 * "unassigned").get(0); Assert.assertNotNull(queue);
	 * Assert.assertTrue(queue.getRoleName().equals("QCProcessor - L3")); }
	 */

	@Test
	public void testPayoutQueueManager() throws Exception {

		// List<String> ldaps = new ArrayList<String>();
		// ldaps = new ArrayList<String>();
		// ldaps.add("AP_UD_BUS_OPS_PROCESSOR_MANAGER_TEST");

		List<OperationalRole> queues;
		queues = solution.getUserEntitledRoles("TST_OPS_LN8", "Payout Operations",
				ICMClientCache.getLdapCache().get("TST_OPS_LN8"), "Unassigned");
		assertQueueManager(queues, "Queue Manager");

		// for QCProcessor Loans L2 ldaps = new ArrayList<String>();
		// ldaps.add("AP_UD_BUS_OPS_PROCESSOR_MANAGER_TEST");
		// ldaps.add("AP_UD_SPC_ONSHORE_USER_TEST");

		queues = solution.getUserEntitledRoles("TST_OPS_ID38", "Payout Operations",
				ICMClientCache.getLdapCache().get("TST_OPS_ID38"), "Unassigned");
		assertQueueManager(queues, "Queue Manager - L2");

		// for QC Processor L3 ldaps = new ArrayList<String>();
		// ldaps.add("AP_UD_BUS_OPS_PROCESSOR_MANAGER_TEST");
		// ldaps.add("AP_UD_SPC_ONSHORE_USER_TEST");
		// ldaps.add("IS_ST_TIAAEMP_AM");
		queues = solution.getUserEntitledRoles("TST_OPS_ID6", "Payout Operations",
				ICMClientCache.getLdapCache().get("TST_OPS_ID6"), "Unassigned");
		assertQueueManager(queues, "Queue Manager - L3");

	}

	private void assertQueueManager(List<OperationalRole> queues, String expectedRoleName) {
		Assert.assertNotNull(queues);
		Assert.assertTrue(queues.size() == 1);
		Iterator<OperationalRole> iter = queues.iterator();
		iter = queues.iterator();
		while (iter.hasNext()) {
			OperationalRole role = iter.next();
			Assert.assertTrue(role.getRoleName().equals(expectedRoleName));
			Assert.assertTrue(role.getQueueNames().size() == 2);
		}
	}

	@Test
	public void testInBasketHeaders() {
		Assert.assertTrue(SolutionConfigCache.getHeaders("Payout Operations", "Unassigned").size() > 1);
	}

	@Test
	public void testGetEntitledSolutions() throws Exception {

		Assert.assertTrue(ICMClientCache.getLdapCache().size() == 0);
		List<String> ldaps = ICMClientCache.getLdapCache().get("ganapaa");
		Assert.assertTrue(ICMClientCache.getLdapCache().size() == 1);
		Assert.assertTrue(ldaps.size() > 0);
		String solution = SolutionConfigCache
				.getEntitledSolutions("ganapaa", ICMClientCache.getLdapCache().get("ganapaa")).get(0);
		Assert.assertTrue(solution.equals("Institutional Servicing"));
		Assert.assertTrue(ICMClientCache.getLdapCache().size() == 1);

		// add another user...
		ldaps.clear();
		ldaps = ICMClientCache.getLdapCache().get("ATDNU200");
		solution = SolutionConfigCache.getEntitledSolutions("ATDNU200", ICMClientCache.getLdapCache().get("ATDNU200"))
				.get(0);
		Assert.assertTrue(solution.equals("Payout Operations"));

		Assert.assertTrue(ICMClientCache.getLdapCache().size() == 2);

		ldaps.clear();
		ldaps = ICMClientCache.getLdapCache().get("ATDNU203");
		solution = SolutionConfigCache.getEntitledSolutions("ATDNU203", ICMClientCache.getLdapCache().get("ATDNU203"))
				.get(0);
		Assert.assertTrue(solution.equals("Payout Operations"));

		Assert.assertTrue(ICMClientCache.getLdapCache().size() == 3);

		ldaps.clear();
		ldaps = ICMClientCache.getLdapCache().get("ATDNU206");
		solution = SolutionConfigCache.getEntitledSolutions("ATDNU206", ICMClientCache.getLdapCache().get("ATDNU206"))
				.get(0);
		Assert.assertTrue(solution.equals("Payout Operations"));

		Assert.assertTrue(ICMClientCache.getLdapCache().size() == 4);

		// get again from the cache and check the size
		ICMClientCache.getLdapCache().get("ganapaa");
		ICMClientCache.getLdapCache().get("ATDNU200");
		ICMClientCache.getLdapCache().get("ATDNU203");
		ICMClientCache.getLdapCache().get("ATDNU206");

		Assert.assertTrue(ICMClientCache.getLdapCache().size() == 4);

	}

	@Test
	public void testExpiration() throws Exception {

		Assert.assertTrue(ICMClientCache.getLdapCache().size() == 0);
		List<String> ldaps = ICMClientCache.getLdapCache().get("ganapaa");
		Assert.assertTrue(ICMClientCache.getLdapCache().size() == 1);
		Thread.sleep(2000);
		ldaps.clear();
		// ldaps = ICMClientCache.getLdapCache().getIfPresent("ganapaa");
		Assert.assertTrue(ICMClientCache.getLdapCache().getIfPresent("ganapaa").size() == 0);
		ldaps = ICMClientCache.getLdapCache().get("ganapaa");
		Assert.assertTrue(ICMClientCache.getLdapCache().size() == 1);
	}

	@Test
	public void testGetAllAssignedFilter() {
		Assert.assertTrue(SolutionConfigCache.getAllAssignedFilter("Payout Operations").equals("PO_Payout Operations"));
	}

	@Test
	public void testGetAllAssignedQMFilter() throws Exception {
		List<String> ldaps = new ArrayList<String>();
		ldaps.add("AP_CM_BUS_OPS_BANK_MANAGER_TEST");
		ldaps.add("AP_CM_ROLE_OPS_MANAGER_TEST");

		String expectedFilter = "BK_Bank Operations AND ((StepType = 'Resolve Bank Post Reject' and CaseType='Fund Transfer') OR (StepType='Resolve Bank Validation Reject' and CaseType='RSA Fund Settlement')) AND (StepType='Resolve Bank Transfer Reject' and CaseType='Fund Transfer')";
		Assert.assertTrue(
				SolutionConfigCache.getAllAssignedQMFilter("Bank Operations", "ganapaa", ldaps).equals(expectedFilter));

		Assert.assertTrue(SolutionConfigCache.getAllAssignedQMFilter("Payout Operations", "ganapaa", ldaps)
				.equals("PO_Payout Operations"));

	}
}
