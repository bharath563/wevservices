package org.tiaa.icm.client.domain.jaxb.bind;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlValue;

public class HashMapType {

	@XmlAttribute
	public String key;

	@XmlValue
	public String value;
}
