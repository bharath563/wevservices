package org.tiaa.icm.client.controller;

import javax.naming.NamingException;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import org.springframework.context.support.FileSystemXmlApplicationContext;

import org.tiaa.icm.client.domain.Configuration;

public class ConfigurationTest {

	@BeforeClass
	public static void setUp() throws Exception {
		FileSystemXmlApplicationContext context = new FileSystemXmlApplicationContext(
				"src/main/webapp/WEB-INF/icm-client-rs-v1-context.xml");
	}

	@Test
	// @Ignore
	public void unAssignedHeaders_Payin() throws NamingException {
		String solution = "Payin Operations";
		String tableheader = "Unassigned";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + ":::table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void allAssignedHeaders_Payin() throws NamingException {
		String solution = "Payin Operations";
		String tableheader = "AllAssigned";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void pendedHeaders_Payin() throws NamingException {
		String solution = "Payin Operations";
		String tableheader = "Pended";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void myWorkItemsHeaders_Payin() throws NamingException {
		String solution = "Payin Operations";
		String tableheader = "MyworkItems";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void allHeaders_Payin() throws NamingException {
		String solution = "Payin Operations";
		String tableheader = "all";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void unAssignedHeaders_Payout() throws NamingException {
		String solution = "Payout Operations";
		String tableheader = "UnAssigned";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void allAssignedHeaders_Payout() throws NamingException {
		String solution = "Payout Operations";
		String tableheader = "AllAssigned";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void pendedHeaders_Payout() throws NamingException {
		String solution = "Payout Operations";
		String tableheader = "Pended";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void myWorkItemsHeaders_Payout() throws NamingException {
		String solution = "Payout Operations";
		String tableheader = "MyworkItems";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void allHeaders_Payout() throws NamingException {
		String solution = "Payout Operations";
		String tableheader = "all";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void unAssignedHeaders_Transfers() throws NamingException {
		String solution = "Transfer Operations";
		String tableheader = "Unassigned";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + ":::table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void allAssignedHeaders_Transfer() throws NamingException {
		String solution = "Transfer Operations";
		String tableheader = "AllAssigned";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void pendedHeaders_Transfer() throws NamingException {
		String solution = "Transfer Operations";
		String tableheader = "Pended";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void myWorkItemsHeaders_Transfer() throws NamingException {
		String solution = "Transfer Operations";
		String tableheader = "MyworkItems";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void allHeaders_Transfer() throws NamingException {
		String solution = "Transfer Operations";
		String tableheader = "all";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void unAssignedHeaders_Brokerage() throws NamingException {
		String solution = "Brokerage Operations";
		String tableheader = "Unassigned";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + ":::table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void allAssignedHeaders_Brokerage() throws NamingException {
		String solution = "Brokerage Operations";
		String tableheader = "AllAssigned";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void pendedHeaders_Brokerage() throws NamingException {
		String solution = "Brokerage Operations";
		String tableheader = "Pended";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void myWorkItemsHeaders_Brokerage() throws NamingException {
		String solution = "Brokerage Operations";
		String tableheader = "MyworkItems";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void allHeaders_Brokerage() throws NamingException {
		String solution = "Brokerage Operations";
		String tableheader = "all";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void unAssignedHeaders_PMO() throws NamingException {
		String solution = "Participant Maintenance Operations";
		String tableheader = "Unassigned";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + ":::table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void allAssignedHeaders_PMO() throws NamingException {
		String solution = "Participant Maintenance Operations";
		String tableheader = "AllAssigned";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void pendedHeaders_PMO() throws NamingException {
		String solution = "Participant Maintenance Operations";
		String tableheader = "Pended";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void myWorkItemsHeaders_PMO() throws NamingException {
		String solution = "Participant Maintenance Operations";
		String tableheader = "MyworkItems";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void allHeaders_PMO() throws NamingException {
		String solution = "Participant Maintenance Operations";
		String tableheader = "all";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void unAssignedHeaders_IS() throws NamingException {
		String solution = "Institutional Servicing";
		String tableheader = "Unassigned";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + ":::table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void allAssignedHeaders_IS() throws NamingException {
		String solution = "Institutional Servicing";
		String tableheader = "AllAssigned";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void pendedHeaders_IS() throws NamingException {
		String solution = "Institutional Servicing";
		String tableheader = "Pended";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void myWorkItemsHeaders_IS() throws NamingException {
		String solution = "Institutional Servicing";
		String tableheader = "MyworkItems";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

	@Test
	@Ignore
	public void allHeaders_IS() throws NamingException {
		String solution = "Institutional Servicing";
		String tableheader = "all";
		Configuration config = new Configuration(null, solution, tableheader);
		System.out.println("For Solution::: " + solution + "::: table header :::" + tableheader
				+ "::: Solution Headers are :::::" + config.getSolutionHeaders());
		Assert.assertNotNull(config.getSolutionHeaders());
		Assert.assertEquals(config.getSolutionHeaders(), config.getSolutionHeaders());
	}

}
