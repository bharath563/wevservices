package org.tiaa.icm.client.entitlement;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import org.tiaa.icm.client.domain.entitlement.OperationalRole;

public class IPSSolutionTest {

	AbstractSolution ipsSolution;

	@Before
	public void setup() {
		ApplicationContext context = new FileSystemXmlApplicationContext(
				"src/main/webapp/WEB-INF/icm-client-rs-v1-context.xml");
		System.out.println("FilterMapper object--->" + context.getBean(IPSSolution.class));

	}

	@Test
	@Ignore
	public void testGetFilterInformation() {
		List<String> ldaps = new ArrayList<String>();
		ldaps.add("AP_CM_IPS_ROLE_REV_TEST");
		OperationalRole queue = null;
		try {
			queue = ipsSolution.getUserEntitledRoles("TST_P8CM06", "Imaging Portfolio Solutions", ldaps, "Unassigned")
					.iterator().next();
			Assert.assertNotNull(queue);
			Assert.assertNotNull(queue.getRoleName().equals("Reviewer"));
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
