package org.tiaa.icm.client.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.security.auth.Subject;
import javax.security.auth.login.LoginException;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import org.junit.Assert;
import org.junit.Test;

import com.filenet.api.util.UserContext;

import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.http.ResponseEntity;

import org.tiaa.icm.client.bo.security.P8Authentication;
import org.tiaa.icm.client.constant.CommonConstants;
import org.tiaa.icm.client.domain.Step;
import org.tiaa.icm.client.domain.StepElementDataField;
import org.tiaa.icm.client.domain.StepElementHeaderField;
import org.tiaa.icm.client.domain.jaxb.CaseResponseType;
import org.tiaa.icm.client.domain.jaxb.CaseSearchRequest;
import org.tiaa.icm.client.domain.jaxb.CommentType;
import org.tiaa.icm.client.domain.jaxb.Config;
import org.tiaa.icm.client.domain.jaxb.DateRangeType;
import org.tiaa.icm.client.domain.jaxb.DocumentType;
import org.tiaa.icm.client.domain.jaxb.EventType;
import org.tiaa.icm.client.domain.jaxb.ResponseList;
import org.tiaa.icm.client.domain.jaxb.ResponseType;
import org.tiaa.icm.client.domain.jaxb.TaskType;
import org.tiaa.icm.client.domain.jaxb.bind.ElementsList;
import org.tiaa.icm.client.domain.jaxb.bind.ObjectListAdapter;
import org.tiaa.icm.client.spi.fnet.IContentEngine;

//@RunWith(SpringJUnit4ClassRunner.class)
// @ContextConfiguration(locations = { "application-test.xml" })
//@ContextConfiguration(locations = { "icm-client-rs-v1-context.xml" })
public class CaseSearchTestCase {

	// private static final String CASE_ID =
	// "%7B386B5397-5545-4213-B347-B7A11C604B28%7D";
	// DevINT
	// private static final String CASE_ID =
	// "%7BCE49CDC8-6B9B-43BB-BD83-2EE4492F9ED7%7D";
	// private static final String CASE_ID_RESP =
	// "{CE49CDC8-6B9B-43BB-BD83-2EE4492F9ED7}";

	// UT
	private static final String CASE_ID = "%7BE9B2AABD-E2A4-4527-9E20-BEC3F860D794%7D";
	private static final String CASE_ID_RESP = "{E9B2AABD-E2A4-4527-9E20-BEC3F860D794}";

	private static final String TASK_ID = "{8901E642-E378-432F-9EFB-DE932A508451}";
	private static final String DOC_ID = "{5041DAD2-E79A-42F2-A03F-01B43C008468}";

	private static final String QUEUE_NAME = "IS_Reviewer";
	private static final String WOB_ID = "C6852EC7F8C9AC46AF3B495AE0543187";

	RestClient r = new RestClient();

	Subject subject;
	IContentEngine target;
	// Response response;

	UserContext userContext;
	String username = "TST_P8CM10";
	String password = "Winter2016";
	String ejbURI = "iiop://chadvt3fis01.ops.tiaa-cref.org:9810";

	Context ic;

	public CaseSearchTestCase() throws LoginException {
		// FileSystemXmlApplicationContext context = new
		// FileSystemXmlApplicationContext(
		// "src/test/java/org/tiaa/icm/client/controller/application-test.xml");

		// System.out.println("Number of Beans" +
		// context.getBeanDefinitionNames().length);

		ceInit();

		FileSystemXmlApplicationContext context = new FileSystemXmlApplicationContext(
				"C:/Users/mamillv/ICMWorkspace/ICMClientRSV1/src/main/webapp/WEB-INF/icm-client-rs-v1-context.xml");
		// FileSystemXmlApplicationContext context = new
		// FileSystemXmlApplicationContext(
		// "src/main/resources/org/tiaa/icm/client/icm-client-rs-v1-context.xml");

		P8Authentication authentication = new P8Authentication();
		subject = authentication.login(username, password);
		target = context.getBean(IContentEngine.class);
		// response =
		// context.getBean(org.tiaa.icm.client.domain.Response.class);
		userContext = UserContext.get();
		userContext.pushSubject(subject);
	}

	private void ceInit() {

		System.setProperty("java.security.auth.login.config",
				"C:/app/IBM/Filenet/AE/CE_API/config/jaas.conf.WebSphere");
		System.setProperty("java.naming.factory.initial", "com.ibm.websphere.naming.WsnInitialContextFactory");
		System.setProperty("com.ibm.CORBA.ConfigURL", "file:///C:/app/IBM/WAS/AppClient/properties/sas.client.props");

		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put("org.omg.CORBA.ORBClass", "com.ibm.CORBA.iiop.ORB");
		env.put(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.websphere.naming.WsnInitialContextFactory");
		env.put(Context.PROVIDER_URL, ejbURI);//

		try {
			ic = new InitialContext(env);
			ic.lookup("");
		} catch (NamingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

	String caseSearchInputXMLLoc = "C:\\ICMClientRSV1\\TestCases\\CaseSearch\\test1.xml";
	String caseSearchoutputXMLLoc = "C:\\ICMClientRSV1\\TestCases\\CaseSearch\\testOutput1.xml";
	String racfId = "tst_p8cm01";

	@Test
	// @Ignore
	public void testSearchCases() throws Exception {

		try {
			CaseSearchRequest caseSearch = new CaseSearchRequest();
			caseSearch.setSortOrder("ASC");
			caseSearch.setSortField("pin");
			caseSearch.setChannel("Paper");
			ElementsList pins = new ElementsList();
			pins.add("1231699");
			// pins.add("1234567");

			ElementsList ssns = new ElementsList();
			ssns.add("XXXXX6789");
			ssns.add("123453898");
			caseSearch.setCaseType("Managed Account Opening");
			caseSearch.setPins(pins);
			caseSearch.setSsns(ssns);
			ResponseList responseList = r.searchCases(caseSearch);
			ObjectListAdapter listAdapter = new ObjectListAdapter();
			List<Object> caseList = listAdapter.unmarshal(responseList.getResults());
			ObjectMapper objMapper = new ObjectMapper();

			for (int i = 0; i < caseList.size(); i++) {
				CaseResponseType caseResponse = objMapper.readValue(objMapper.writeValueAsString(caseList.get(i)),
						CaseResponseType.class);
				Assert.assertEquals("1231699", caseResponse.getAdditionalIdentifiers().get("pin"));

			}
		} catch (SQLException e) {
			e.printStackTrace();
			// e.getMessage();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	// @Ignore
	public void SearchBy_PlanNumber_ASC() throws Exception {

		try {
			CaseSearchRequest caseSearch = new CaseSearchRequest();
			caseSearch.setSortOrder("asc");
			caseSearch.setSortField("requestReceivedDate");
			caseSearch.setPlan("TIAA03");

			ResponseList responseList = r.searchCases(caseSearch);
			ObjectListAdapter listAdapter = new ObjectListAdapter();
			List<Object> caseList = listAdapter.unmarshal(responseList.getResults());
			ObjectMapper objMapper = new ObjectMapper();
			for (int i = 0; i < caseList.size(); i++) {
				CaseResponseType caseResponse = objMapper.readValue(objMapper.writeValueAsString(caseList.get(i)),
						CaseResponseType.class);
				System.out
						.println("caseResponse.getAdditionalIdentifiers():" + caseResponse.getAdditionalIdentifiers());
				Assert.assertEquals("TIAA03", caseResponse.getAdditionalIdentifiers().get("plan"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	// @Ignore
	public void SearchBy_PlanNumber_Desc() throws Exception {

		try {
			CaseSearchRequest caseSearch = new CaseSearchRequest();
			caseSearch.setSortOrder("desc");
			caseSearch.setSortField("Case Modified Date");
			caseSearch.setPlan("TIAA03");
			ResponseList responseList = r.searchCases(caseSearch);
			ObjectListAdapter listAdapter = new ObjectListAdapter();
			List<Object> caseList = listAdapter.unmarshal(responseList.getResults());
			ObjectMapper objMapper = new ObjectMapper();
			for (int i = 0; i < caseList.size(); i++) {
				CaseResponseType caseResponse = objMapper.readValue(objMapper.writeValueAsString(caseList.get(i)),
						CaseResponseType.class);
				Assert.assertEquals("TIAA03", caseResponse.getAdditionalIdentifiers().get("plan"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	// @Ignore
	public void SearchBy_PlanNumber_DateRange() throws Exception {

		try {
			CaseSearchRequest caseSearch = new CaseSearchRequest();
			DateRangeType dateRange = new DateRangeType();
			dateRange.setFrom("2016-08-01");
			dateRange.setTo("2016-08-01");
			dateRange.setType("Case Modified Date");
			caseSearch.setSortOrder("desc");
			caseSearch.setSortField("requestReceivedDate");
			caseSearch.setPlan("TIAA03");
			caseSearch.setDateRange(dateRange);
			ResponseList responseList = r.searchCases(caseSearch);
			ObjectListAdapter listAdapter = new ObjectListAdapter();
			List<Object> caseList = listAdapter.unmarshal(responseList.getResults());
			ObjectMapper objMapper = new ObjectMapper();
			for (int i = 0; i < caseList.size(); i++) {
				CaseResponseType caseResponse = objMapper.readValue(objMapper.writeValueAsString(caseList.get(i)),
						CaseResponseType.class);
				Assert.assertTrue(caseResponse.getId(), caseResponse instanceof CaseResponseType);
				Assert.assertEquals("TIAA03", caseResponse.getAdditionalIdentifiers().get("plan"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	// @Ignore
	public void SearchBy_PlanNumber_Desc_DateRange_Channel() throws Exception {

		try {
			CaseSearchRequest caseSearch = new CaseSearchRequest();
			DateRangeType dateRange = new DateRangeType();
			dateRange.setFrom("2016-08-01");
			dateRange.setTo("2016-08-01");
			dateRange.setType("Case Modified Date");
			caseSearch.setSortOrder("desc");
			caseSearch.setSortField("requestReceivedDate");
			caseSearch.setPlan("TIAA03");
			caseSearch.setChannel("Paper");
			caseSearch.setDateRange(dateRange);
			ResponseList responseList = r.searchCases(caseSearch);
			ObjectListAdapter listAdapter = new ObjectListAdapter();
			List<Object> caseList = listAdapter.unmarshal(responseList.getResults());
			ObjectMapper objMapper = new ObjectMapper();
			for (int i = 0; i < caseList.size(); i++) {
				CaseResponseType caseResponse = objMapper.readValue(objMapper.writeValueAsString(caseList.get(i)),
						CaseResponseType.class);
				Assert.assertTrue(caseResponse.getChannel(), caseResponse instanceof CaseResponseType);
				Assert.assertEquals("TIAA03", caseResponse.getAdditionalIdentifiers().get("plan"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	// @Ignore
	public void SearchBy_PlanNumber_Channel_ASC_DateRange() throws Exception {

		try {
			CaseSearchRequest caseSearch = new CaseSearchRequest();
			DateRangeType dateRange = new DateRangeType();
			dateRange.setFrom("2016-08-01");
			dateRange.setTo("2016-08-01");
			dateRange.setType("Case Modified Date");
			caseSearch.setSortOrder("asc");
			caseSearch.setSortField("requestReceivedDate");
			caseSearch.setPlan("368175");
			caseSearch.setChannel("Paper");
			caseSearch.setDateRange(dateRange);
			ResponseList responseList = r.searchCases(caseSearch);
			ObjectListAdapter listAdapter = new ObjectListAdapter();
			List<Object> caseList = listAdapter.unmarshal(responseList.getResults());
			System.out.println("caseList:::" + caseList.size());
			ObjectMapper objMapper = new ObjectMapper();
			for (int i = 0; i < caseList.size(); i++) {
				CaseResponseType caseResponse = objMapper.readValue(objMapper.writeValueAsString(caseList.get(i)),
						CaseResponseType.class);
				Assert.assertTrue(caseResponse.getChannel(), caseResponse instanceof CaseResponseType);
				System.out.println("Total records:::" + caseResponse);
				Assert.assertEquals("368175", caseResponse.getAdditionalIdentifiers().get("plan"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	// @Ignore
	public void SearchBy_Asc_Field_DateRange() {

		try {
			CaseSearchRequest caseSearch = new CaseSearchRequest();
			DateRangeType dateRange = new DateRangeType();
			dateRange.setFrom("2016-08-01");
			dateRange.setTo("2016-08-01");
			dateRange.setType("Case Modified Date");
			caseSearch.setSortOrder("asc");
			caseSearch.setSortField("Case Modified Date");
			caseSearch.setDateRange(dateRange);
			ResponseList responseList = r.searchCases(caseSearch);
			ObjectListAdapter listAdapter = new ObjectListAdapter();
			List<Object> caseList = listAdapter.unmarshal(responseList.getResults());
			System.out.println("caseList:::for DateRange" + caseList.size());
			ObjectMapper objMapper = new ObjectMapper();
			for (int i = 0; i < caseList.size(); i++) {
				CaseResponseType caseResponse = objMapper.readValue(objMapper.writeValueAsString(caseList.get(i)),
						CaseResponseType.class);
				Assert.assertTrue(caseResponse.getId(), caseResponse instanceof CaseResponseType);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	// @Ignore
	public void SearchBy_Desc_Field() throws Exception {

		try {
			CaseSearchRequest caseSearch = new CaseSearchRequest();
			caseSearch.setSortOrder("desc");
			caseSearch.setSortField("Case Modified Date");
			ResponseList responseList = r.searchCases(caseSearch);
			ObjectListAdapter listAdapter = new ObjectListAdapter();
			List<Object> caseList = listAdapter.unmarshal(responseList.getResults());
			ObjectMapper objMapper = new ObjectMapper();
			for (int i = 0; i < caseList.size(); i++) {
				CaseResponseType caseResponse = objMapper.readValue(objMapper.writeValueAsString(caseList.get(i)),
						CaseResponseType.class);
				Assert.assertTrue(caseResponse.getId(), caseResponse instanceof CaseResponseType);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	// @Ignore
	public void SearchBy_Desc_Field_Channel() throws Exception {

		try {
			CaseSearchRequest caseSearch = new CaseSearchRequest();
			caseSearch.setSortOrder("desc");
			caseSearch.setSortField("Case Modified Date");
			caseSearch.setChannel("Paper");
			ResponseList responseList = r.searchCases(caseSearch);
			ObjectListAdapter listAdapter = new ObjectListAdapter();
			List<Object> caseList = listAdapter.unmarshal(responseList.getResults());
			ObjectMapper objMapper = new ObjectMapper();
			for (int i = 0; i < caseList.size(); i++) {
				CaseResponseType caseResponse = objMapper.readValue(objMapper.writeValueAsString(caseList.get(i)),
						CaseResponseType.class);
				Assert.assertTrue(caseResponse.getId(), caseResponse instanceof CaseResponseType);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	// @Ignore
	public void SearchBy_Desc_Field_Channel_() throws Exception {

		try {
			CaseSearchRequest caseSearch = new CaseSearchRequest();
			caseSearch.setSortOrder("desc");
			caseSearch.setSortField("Case Modified Date");
			caseSearch.setChannel("Paper");
			ResponseList responseList = r.searchCases(caseSearch);
			ObjectListAdapter listAdapter = new ObjectListAdapter();
			List<Object> caseList = listAdapter.unmarshal(responseList.getResults());
			ObjectMapper objMapper = new ObjectMapper();
			for (int i = 0; i < caseList.size(); i++) {
				CaseResponseType caseResponse = objMapper.readValue(objMapper.writeValueAsString(caseList.get(i)),
						CaseResponseType.class);
				System.out.println("Caseid:::" + caseResponse.getId());
				Assert.assertTrue(caseResponse.getId(), caseResponse instanceof CaseResponseType);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	// @Ignore
	public void SearchBy_Desc_Field_Channel_Plan() throws Exception {

		try {
			CaseSearchRequest caseSearch = new CaseSearchRequest();
			caseSearch.setSortOrder("desc");
			caseSearch.setSortField("Case Modified Date");
			caseSearch.setChannel("Paper");
			caseSearch.setPlan("100865");
			ResponseList responseList = r.searchCases(caseSearch);
			ObjectListAdapter listAdapter = new ObjectListAdapter();
			List<Object> caseList = listAdapter.unmarshal(responseList.getResults());
			ObjectMapper objMapper = new ObjectMapper();
			for (int i = 0; i < caseList.size(); i++) {
				CaseResponseType caseResponse = objMapper.readValue(objMapper.writeValueAsString(caseList.get(i)),
						CaseResponseType.class);
				Assert.assertEquals(caseResponse, caseResponse instanceof CaseResponseType);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	// @Ignore
	public void getConfig() throws Exception {
		try {
			String configResponse = r.getConfiguration();
			System.out.println("Response is: " + configResponse);
			ObjectMapper objMapper = new ObjectMapper();
			Config.Channel configurationObject = objMapper.readValue(configResponse, Config.Channel.class);

			Iterator<String> listIterator = configurationObject.getChannel().iterator();
			while (listIterator.hasNext()) {
				System.out.println(listIterator.next());
			}

		} catch (SQLException e) {
			e.printStackTrace();
			// e.getMessage();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	public void getRelatedCaseDetails() throws SQLException, JsonParseException, JsonMappingException, IOException {
		ResponseEntity<ResponseList> relatedCaseDetails = r
				.searchRelatedCases("{491E49AB-87DD-4099-BF08-3C95C906F9AA}");
	}

	@Test
	// // @Ignore
	public void getCaseProperties() throws SQLException, JsonParseException, JsonMappingException, IOException {
		Object caseDetails = r.getCaseProperties(CASE_ID);

		// Object caseDetails =
		// r.getCaseProperties("{5CDE490E-B4D0-41B4-8F79-11CF97F86CF6}");
		System.out.println("caseDetails:" + caseDetails);
		Assert.assertEquals(true, caseDetails instanceof String);

		ObjectMapper objMapper = new ObjectMapper();

		CaseResponseType caseDetailsObject = objMapper.readValue(caseDetails.toString(), CaseResponseType.class);
		Assert.assertEquals(CASE_ID_RESP, caseDetailsObject.getId());

	}

	@Test
	// @Ignore
	public void getCaseDocuments() throws Exception {
		Object documents = r.getCaseDocuments(CASE_ID);
		Assert.assertEquals(true, documents instanceof ResponseEntity<?>);
		ResponseEntity<?> documentsEntity = (ResponseEntity<?>) documents;
		Assert.assertEquals(true, documentsEntity.getBody() instanceof ResponseList);
		ResponseList responseList = (ResponseList) documentsEntity.getBody();
		Assert.assertTrue(responseList.getTotalRecords() >= 1);

		ObjectListAdapter listAdapter = new ObjectListAdapter();
		List<Object> documentsList = listAdapter.unmarshal(responseList.getResults());
		ObjectMapper objMapper = new ObjectMapper();
		objMapper.setDateFormat(new SimpleDateFormat(CommonConstants.MMDDYYYY12HR));
		System.out.println("commentList.get(0):" + documentsList.get(0));
		DocumentType document = objMapper.readValue(objMapper.writeValueAsString(documentsList.get(0)),
				DocumentType.class);
		System.out.println(document.getBusinessUnit());
	}

	@Test
	// @Ignore
	public void getComments() throws Exception {
		Object comments = r.getComments(CASE_ID);
		Assert.assertEquals(true, comments instanceof ResponseEntity<?>);
		ResponseEntity<?> commentsEntity = (ResponseEntity<?>) comments;
		Assert.assertEquals(true, commentsEntity.getBody() instanceof ResponseList);
		ResponseList responseList = (ResponseList) commentsEntity.getBody();
		Assert.assertTrue(responseList.getTotalRecords() >= 1);

		ObjectListAdapter listAdapter = new ObjectListAdapter();
		List<Object> commentList = listAdapter.unmarshal(responseList.getResults());
		ObjectMapper objMapper = new ObjectMapper();
		objMapper.setDateFormat(new SimpleDateFormat(CommonConstants.MMDDYYYY12HR));
		System.out.println("commentList.get(0):" + commentList.get(0));
		CommentType comment = objMapper.readValue(objMapper.writeValueAsString(commentList.get(0)), CommentType.class);
		System.out.println(comment.getComment());
	}

	@Test
	// @Ignore
	public void getHistory() throws Exception {

		Object comments = r.getHistory(CASE_ID);
		Assert.assertEquals(true, comments instanceof ResponseEntity<?>);
		ResponseEntity<?> commentsEntity = (ResponseEntity<?>) comments;
		Assert.assertEquals(true, commentsEntity.getBody() instanceof ResponseList);
		ResponseList responseList = (ResponseList) commentsEntity.getBody();

		Assert.assertTrue(responseList.getTotalRecords() >= 1);

		ObjectListAdapter listAdapter = new ObjectListAdapter();
		List<Object> eventList = listAdapter.unmarshal(responseList.getResults());
		ObjectMapper objMapper = new ObjectMapper();
		objMapper.setDateFormat(new SimpleDateFormat(CommonConstants.MMDDYYYY12HR));
		System.out.println("eventList.get(0):" + eventList.get(0));
		EventType event = objMapper.readValue(objMapper.writeValueAsString(eventList.get(0)), EventType.class);
		System.out.println(event.getDescription());
	}

	@Test
	// @Ignore
	public void getTasks() throws Exception {
		Object tasks = r.getTasks(CASE_ID);
		Assert.assertEquals(true, tasks instanceof ResponseEntity<?>);
		ResponseEntity<?> tasksEntity = (ResponseEntity<?>) tasks;
		Assert.assertEquals(true, tasksEntity.getBody() instanceof ResponseList);
		ResponseList responseList = (ResponseList) tasksEntity.getBody();
		ObjectListAdapter listAdapter = new ObjectListAdapter();

		Assert.assertTrue(responseList.getTotalRecords() >= 1);

		List<Object> tasksList = listAdapter.unmarshal(responseList.getResults());
		ObjectMapper objMapper = new ObjectMapper();
		objMapper.setDateFormat(new SimpleDateFormat(CommonConstants.MMDDYYYY12HR));
		System.out.println("tasksList.get(0):" + tasksList.get(0));
		TaskType task = objMapper.readValue(objMapper.writeValueAsString(tasksList.get(0)), TaskType.class);
		System.out.println("task :" + task.getName());
	}

	@Test
	// @Ignore
	public void SearchBy_MultiPlanNumber_ASC() throws Exception {

		try {
			CaseSearchRequest caseSearch = new CaseSearchRequest();
			caseSearch.setSortOrder("asc");
			caseSearch.setSortField("requestReceivedDate");
			caseSearch.setConfirmation("C14LE6SDT");
			caseSearch.setCaseType("Loan Repayment");
			ResponseList responseList = r.searchCases(caseSearch);
			ObjectListAdapter listAdapter = new ObjectListAdapter();
			List<Object> caseList = listAdapter.unmarshal(responseList.getResults());
			ObjectMapper objMapper = new ObjectMapper();
			for (int i = 0; i < caseList.size(); i++) {
				CaseResponseType caseResponse = objMapper.readValue(objMapper.writeValueAsString(caseList.get(i)),
						CaseResponseType.class);
				System.out
						.println("caseResponse.getAdditionalIdentifiers():" + caseResponse.getAdditionalIdentifiers());
				if (caseResponse.getId().equals("{41BD461C-E872-44BA-BC32-D754E3E29FF5}")) {
					Assert.assertEquals("346781,346771", caseResponse.getAdditionalIdentifiers().get("plan"));
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Test
	// @Ignore
	public void caseComments() throws SQLException, UnsupportedEncodingException {
		Object comments = r.caseComments(CASE_ID);

		Assert.assertEquals(true, comments instanceof ResponseType);
		ResponseType response = (ResponseType) comments;
		Assert.assertEquals("SUCCESS", response.getStatus());
	}

	@Test
	// @Ignore
	public void taskComments() throws SQLException, UnsupportedEncodingException {
		Object comments = r.addTaskComments(CASE_ID, "{05B7C740-61BA-402B-8178-79DB3CF89489}");

		Assert.assertEquals(true, comments instanceof ResponseType);
		ResponseType response = (ResponseType) comments;
		Assert.assertEquals("SUCCESS", response.getStatus());
	}

	@Test
	// @Ignore
	public void documentComments() throws SQLException, UnsupportedEncodingException {
		Object comments = r.addDocumentComments(CASE_ID, "{4B30C505-1376-476D-8B6A-68AD8832EE2C}");

		Assert.assertEquals(true, comments instanceof ResponseType);
		ResponseType response = (ResponseType) comments;
		Assert.assertEquals("SUCCESS", response.getStatus());
	}

	@Test
	// @Ignore
	public void stepComments() throws SQLException, UnsupportedEncodingException {
		Object comments = r.stepComments(CASE_ID, WOB_ID, QUEUE_NAME);

		Assert.assertEquals(true, comments instanceof ResponseType);
		ResponseType response = (ResponseType) comments;
		Assert.assertEquals("SUCCESS", response.getStatus());
	}

	@Test
	// @Ignore
	public void createDoc() throws SQLException, UnsupportedEncodingException {
		ResponseType response = r.createDocument(CASE_ID);

		Assert.assertEquals(true, response instanceof ResponseType);
		Assert.assertEquals("SUCCESS", response.getStatus());
	}

	@Test
	// @Ignore
	public void updateDoc() throws SQLException, UnsupportedEncodingException {
		Object response = r.updateDocument(CASE_ID, DOC_ID);

		Assert.assertEquals(true, response instanceof ResponseType);
		ResponseType responseType = (ResponseType) response;
		Assert.assertEquals("SUCCESS", responseType.getStatus());
	}

	@Test
	// @Ignore
	public void getStepDetails() throws Exception {

		Object stepDetails = r.getStepDetails(WOB_ID, "PO_Processor");
		Assert.assertEquals(true, stepDetails instanceof ResponseEntity<?>);
		ResponseEntity<?> stepEntity = (ResponseEntity<?>) stepDetails;
		Assert.assertEquals(true, stepEntity.getBody() instanceof Step);
		Step step = (Step) stepEntity.getBody();
		ObjectListAdapter listAdapter = new ObjectListAdapter();

		List<StepElementDataField> dataFields = step.getFields();
		for (StepElementDataField stepElementDataField : dataFields) {
			System.out.println(stepElementDataField.getName());
		}
		List<StepElementHeaderField> stepElementHeaderFieldList = step.getHeaderFields();
		System.out.println(step.getTaskId());

		if (stepElementHeaderFieldList != null) {
			for (StepElementHeaderField stepElementHeaderField : stepElementHeaderFieldList) {
				System.out.println(stepElementHeaderField.getName());
			}
		}

	}

}
