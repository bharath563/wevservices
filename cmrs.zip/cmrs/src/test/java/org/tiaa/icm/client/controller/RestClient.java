package org.tiaa.icm.client.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.sql.SQLException;
import java.util.Arrays;

import org.codehaus.jackson.map.ObjectMapper;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import org.tiaa.icm.client.domain.Step;
import org.tiaa.icm.client.domain.jaxb.CaseSearchRequest;
import org.tiaa.icm.client.domain.jaxb.CommentType;
import org.tiaa.icm.client.domain.jaxb.Config;
import org.tiaa.icm.client.domain.jaxb.DocumentType;
import org.tiaa.icm.client.domain.jaxb.ResponseList;
import org.tiaa.icm.client.domain.jaxb.ResponseType;

public class RestClient extends RestTemplate {

	private static String uri = "http://localhost:8080/ICMClientRSV1";
	// private static String uri =
	// "http://chadvt3esfncm2.ops.tiaa-cref.org/icm-client-rs-v1";

	// private static String uri =
	// "http://chadvt3esfncm2.ops.tiaa-cref.org/icm-client-rs-v1";
	// private static String uri =
	// "http://chactfnet01.ops.tiaa-cref.org:9080/icm-client-rs-v1";
	private static String casesURI = uri + ("/cases");
	private static String documentsURI = "/documents";
	private static String tasksURI = "/tasks";
	private static String commentsURI = "/comments";
	private static String relatedCasesURI = "/relatedcases";
	private static String historyURI = "/history";
	private static String stepURI = "/step";
	private static String configurationURI = uri + "/config?type=channel";

	private static HttpEntity<String> entity = null;
	private static HttpHeaders headers = new HttpHeaders();
	private static ObjectMapper objectMapper = new ObjectMapper();

	public String expectedOutputJson = null;

	CaseSearchRequest caseSearch = null;
	CommentType comment = null;
	DocumentType docComment = null;
	RestTemplate restTemplate = new RestTemplate();
	Config configuration = null;

	static {
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		// headers.set("racfId", "tst_p8cm01");
		// headers.set("password", "Spring2016");
	}

	public RestClient() {
		super();
		headers.set("racfId", "tst_p8cm01");
	}

	private String removeWhiteSpaces(String input) {

		// input = input.replaceAll("\\t+", "");
		// input.replaceAll(" ", "");
		return input.replaceAll("\\s+", "");
	}

	public ResponseList searchCases(CaseSearchRequest caseSearchReq) throws SQLException {
		ResponseEntity<ResponseList> result = null;
		// ResponseList responseList =
		// restTemplate.postForObject(casesURI.toString(), caseSearchReq,
		// ResponseList.class);
		HttpEntity<CaseSearchRequest> searchEntity = new HttpEntity<CaseSearchRequest>(caseSearchReq, headers);
		result = restTemplate.exchange(casesURI, org.springframework.http.HttpMethod.POST, searchEntity,
				ResponseList.class);
		return result.getBody();
	}

	public ResponseEntity<ResponseList> searchRelatedCases(String caseId)
			throws SQLException, UnsupportedEncodingException {
		ResponseEntity<ResponseList> result = null;
		String decodecaseId = URLDecoder.decode(caseId, "UTF-8");
		entity = new HttpEntity<String>("parameters", headers);
		result = restTemplate.exchange(casesURI + "/" + decodecaseId + relatedCasesURI,
				org.springframework.http.HttpMethod.GET, entity, ResponseList.class, decodecaseId);

		return result;

	}

	/*
	 * public String addCaseComments() { RestTemplate restTemplate = new
	 * RestTemplate();
	 *
	 * org.springframework.util.MultiValueMap<String, String> headers = new
	 * LinkedMultiValueMap<String, String>(); headers.add("racfId",
	 * "tst_p8cm01");
	 *
	 * // RestTemplate restTemplate = new RestTemplate(); //
	 * restTemplate.getMessageConverters().add(new //
	 * MappingJackson2HttpMessageConverter());
	 *
	 * HttpEntity<Comment> request = new HttpEntity<Comment>(comment, headers);
	 *
	 * ICMClientResponse responseList = restTemplate.postForObject(uri +
	 * "/{CASE_ID}/comments", request, ICMClientResponse.class, CASE_ID);
	 *
	 * String result = null; try { result =
	 * removeWhiteSpaces(objectMapper.writeValueAsString(responseList));
	 *
	 * } catch (JsonGenerationException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); } catch (JsonMappingException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); } catch (IOException e) {
	 * // TODO Auto-generated catch block e.printStackTrace(); } catch
	 * (Exception e) { e.printStackTrace(); } return result; }
	 */

	/*
	 * public String getCaseDetails(String caseid, String racfId) throws
	 * SQLException { RestTemplate restTemplate = new RestTemplate();
	 *
	 * String result =
	 * restTemplate.getForObject(casesURI.append("/").append(caseid).toString(),
	 * String.class);
	 *
	 * System.out.println(result); return result; }
	 *
	 * public ResponseEntity<ResponseList> getDocuments(String caseid, String
	 * racfId) throws SQLException { RestTemplate restTemplate = new
	 * RestTemplate(); entity = new HttpEntity<String>("parameters", headers);
	 * ResponseEntity<ResponseList> result = restTemplate.exchange(
	 * casesURI.append("/").append(caseid).append(documentsURI).toString(),
	 * org.springframework.http.HttpMethod.GET, entity, ResponseList.class);
	 *
	 * System.out.println(result); return result; }
	 */
	/**********
	 * getCase Properties -----
	 *
	 * @throws UnsupportedEncodingException
	 */
	public String getCaseProperties(String caseId) throws SQLException, UnsupportedEncodingException {
		String decodecaseId = URLDecoder.decode(caseId, "UTF-8");
		entity = new HttpEntity<String>("parameters", headers);

		ResponseEntity<String> result = restTemplate.exchange(casesURI + "/" + decodecaseId,
				org.springframework.http.HttpMethod.GET, entity, String.class, decodecaseId);

		System.out.println(result);
		return result.getBody();
	}

	/********** getCaseDocuments ----- */

	public ResponseEntity<ResponseList> getCaseDocuments(String caseId)
			throws SQLException, UnsupportedEncodingException {
		entity = new HttpEntity<String>("parameters", headers);
		String decodecaseId = URLDecoder.decode(caseId, "UTF-8");
		ResponseEntity<ResponseList> result = restTemplate.exchange(casesURI + "/" + decodecaseId + documentsURI,
				org.springframework.http.HttpMethod.GET, entity, ResponseList.class, decodecaseId);

		return result;
	}

	/************** getComments ---- */
	public ResponseEntity<ResponseList> getComments(String caseId) throws SQLException, UnsupportedEncodingException {
		String decodecaseId = URLDecoder.decode(caseId, "UTF-8");
		entity = new HttpEntity<String>("parameters", headers);
		ResponseEntity<ResponseList> result = restTemplate.exchange(casesURI + "/" + decodecaseId + commentsURI,
				org.springframework.http.HttpMethod.GET, entity, ResponseList.class, decodecaseId);

		return result;
	}

	/********* getTasks *********/

	public ResponseEntity<ResponseList> getTasks(String caseId) throws SQLException, UnsupportedEncodingException {
		entity = new HttpEntity<String>("parameters", headers);
		String decodecaseId = URLDecoder.decode(caseId, "UTF-8");
		ResponseEntity<ResponseList> result = restTemplate.exchange(casesURI + "/" + decodecaseId + tasksURI,
				org.springframework.http.HttpMethod.GET, entity, ResponseList.class, decodecaseId);

		return result;
	}

	/********* getHistory *********/

	public ResponseEntity<ResponseList> getHistory(String caseId) throws SQLException, UnsupportedEncodingException {
		entity = new HttpEntity<String>("parameters", headers);
		String decodecaseId = URLDecoder.decode(caseId, "UTF-8");
		ResponseEntity<ResponseList> result = restTemplate.exchange(casesURI + "/" + decodecaseId + historyURI,
				org.springframework.http.HttpMethod.GET, entity, ResponseList.class, decodecaseId);

		return result;
	}

	/********* getStepDetails *********/

	public ResponseEntity<Step> getStepDetails(String wobId, String queueName)
			throws SQLException, UnsupportedEncodingException {
		entity = new HttpEntity<String>("parameters", headers);

		ResponseEntity<Step> result = restTemplate.exchange(uri + "/steps/" + wobId + "?queueName=" + queueName,
				org.springframework.http.HttpMethod.GET, entity, Step.class, wobId);

		return result;
	}

	/******** addCaseComments ***********/

	public ResponseType caseComments(String caseId) throws SQLException, UnsupportedEncodingException {
		comment = new CommentType();
		comment.setComment("Added at case level");
		String decodecaseId = URLDecoder.decode(caseId, "UTF-8");
		HttpEntity<CommentType> commentEntity = new HttpEntity<CommentType>(comment, headers);
		ResponseType response = restTemplate.postForObject(casesURI + "/" + decodecaseId + commentsURI, commentEntity,
				ResponseType.class, decodecaseId);
		return response;
		// String result = null;
		// try {
		// result = objectMapper.writeValueAsString(responseList);
		// } catch (JsonGenerationException e) {
		// e.printStackTrace();
		// } catch (JsonMappingException e) {
		// e.printStackTrace();
		// } catch (IOException e) {
		// e.printStackTrace();
		// }
		// return result;
	}

	/******** addTaskComments ***********/

	public ResponseType addTaskComments(String caseId, String taskId)
			throws SQLException, UnsupportedEncodingException {
		comment = new CommentType();
		comment.setComment("Added at task level");
		String decodecaseId = URLDecoder.decode(caseId, "UTF-8");
		System.out.println("decodecaseId---" + decodecaseId);
		String decodetaskId = URLDecoder.decode(taskId, "UTF-8");
		System.out.println("decodetaskId" + decodetaskId);
		HttpEntity<CommentType> commentEntity = new HttpEntity<CommentType>(comment, headers);

		ResponseType response = restTemplate.postForObject(
				casesURI + "/" + decodecaseId + tasksURI + "/" + decodetaskId + commentsURI, commentEntity,
				ResponseType.class, decodecaseId, decodetaskId);
		return response;
		// String result = null;
		// try {
		// result = objectMapper.writeValueAsString(responseList);
		// } catch (JsonGenerationException e) {
		// e.getMessage();
		// // e.printStackTrace();
		// } catch (JsonMappingException e) {
		// // e.getMessage();
		// e.printStackTrace();
		// } catch (IOException e) {
		// // e.getMessage();
		// e.printStackTrace();
		// }
		// return result;
	}

	/******** documentComments ***********/

	public ResponseType addDocumentComments(String caseId, String docId)
			throws SQLException, UnsupportedEncodingException {
		comment = new CommentType();
		comment.setComment("Added at Document level");
		String decodecaseId = URLDecoder.decode(caseId, "UTF-8");
		String decodedocId = URLDecoder.decode(docId, "UTF-8");
		HttpEntity<CommentType> commentEntity = new HttpEntity<CommentType>(comment, headers);
		ResponseType response = restTemplate.postForObject(
				casesURI + "/" + decodecaseId + documentsURI + "/" + decodedocId + commentsURI, commentEntity,
				ResponseType.class, decodecaseId, decodedocId);
		return response;
		// String result = null;
		// try {
		// result = objectMapper.writeValueAsString(responseList);
		// } catch (JsonGenerationException e) {
		// e.getMessage();
		// } catch (JsonMappingException e) {
		// e.getMessage();
		// } catch (IOException e) {
		// e.getMessage();
		// }
		// return result;
	}

	/******** stepComments ***********/

	public ResponseType stepComments(String caseId, String wobId, String queueName)
			throws SQLException, UnsupportedEncodingException {

		comment = new CommentType();
		comment.setComment("Added at stepComments level");
		String decodeCaseId = URLDecoder.decode(caseId, "UTF-8");
		String decodeWobId = URLDecoder.decode(wobId, "UTF-8");
		HttpEntity<CommentType> commentEntity = new HttpEntity<CommentType>(comment, headers);
		ResponseType response = restTemplate.postForObject(
				casesURI + "/" + decodeCaseId + stepURI + "/" + decodeWobId + commentsURI + "?queueName=" + queueName,
				commentEntity, ResponseType.class, decodeCaseId, decodeWobId);
		return response;
		// String result = null;
		// try {
		// result = objectMapper.writeValueAsString(responseList);
		// } catch (JsonGenerationException e) {
		// e.getMessage();
		// } catch (JsonMappingException e) {
		// e.getMessage();
		// } catch (IOException e) {
		// e.getMessage();
		// }
		// return result;
	}

	/******** createDocument ***********/

	public ResponseType createDocument(String caseId) throws SQLException, UnsupportedEncodingException {
		docComment = new DocumentType();
		docComment.setBusinessUnit("PENSION");
		docComment.setId("{4B30C505-1376-476D-8B6A-68AD8832EE2C}");
		docComment.setIdtype("Object_id");
		docComment.setDocumentName("Test-attchmt.docx");
		docComment.setDocCode("FILENET_INBOUND_DOC");
		docComment.setFolder("");
		docComment.setFormatType("Document");
		docComment.setMimeType("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
		String decodecaseId = URLDecoder.decode(caseId, "UTF-8");
		HttpEntity<DocumentType> documentEntity = new HttpEntity<DocumentType>(docComment, headers);
		ResponseType response = restTemplate.postForObject(casesURI + "/" + decodecaseId + documentsURI, documentEntity,
				ResponseType.class, decodecaseId);
		return response;
		// String result = null;
		// try {
		// result = objectMapper.writeValueAsString(responseList);
		// } catch (JsonGenerationException e) {
		// e.getMessage();
		// } catch (JsonMappingException e) {
		// e.getMessage();
		// } catch (IOException e) {
		// e.getMessage();
		// }
		// return result;
	}

	/******** updateDocument ***********/

	public ResponseType updateDocument(String caseId, String docId) throws SQLException, UnsupportedEncodingException {
		docComment = new DocumentType();
		docComment.setBusinessUnit("PENSION");
		docComment.setId("{1907B3DA-73F1-40E6-A747-4CA422119004}");
		docComment.setIdtype("VJIdtype");
		docComment.setDocumentName("VJdocName");
		docComment.setFolder("000000101005");
		docComment.setMimeType("application/ms-word");
		String decodecaseId = URLDecoder.decode(caseId, "UTF-8");
		String decodedocId = URLDecoder.decode(docId, "UTF-8");
		HttpEntity<DocumentType> documentEntity = new HttpEntity<DocumentType>(docComment, headers);
		ResponseEntity<ResponseType> response = restTemplate.exchange(
				casesURI + "/" + decodecaseId + documentsURI + "/" + decodedocId,
				org.springframework.http.HttpMethod.PUT, documentEntity, ResponseType.class, decodecaseId, decodedocId);
		System.out.println("response.getBody():" + response.getBody());
		return response.getBody();
		// String result = null;
		// try {
		// result = objectMapper.writeValueAsString(responseList);
		// } catch (JsonGenerationException e) {
		// // e.printStackTrace();
		// e.getMessage();
		// } catch (JsonMappingException e) {
		// // e.printStackTrace();
		// e.getMessage();
		// } catch (IOException e) {
		// // e.printStackTrace();
		// e.getMessage();
		// }
		// return result;
	}

	public String getConfiguration() throws SQLException {
		entity = new HttpEntity<String>("parameters", headers);

		ResponseEntity<String> response = restTemplate.exchange(configurationURI,
				org.springframework.http.HttpMethod.GET, entity, String.class);

		return response.getBody();
	}

}
