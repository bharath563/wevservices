package org.tiaa.icm.client.domain.jaxb.bind;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.annotation.adapters.XmlAdapter;

public final class AdditionalIdentifiersMapAdapter extends XmlAdapter<AdditionalIdentifiersMap, Map<String, String>> {

	@Override
	public AdditionalIdentifiersMap marshal(Map<String, String> inputMap) throws Exception {
		AdditionalIdentifiersMap mapType = new AdditionalIdentifiersMap();
		for (Entry<String, String> entry : inputMap.entrySet()) {
			HashMapType mapEntryType = new HashMapType();
			mapEntryType.key = entry.getKey();
			mapEntryType.value = entry.getValue();
			mapType.entry.add(mapEntryType);
		}
		return mapType;
	}

	@Override
	public Map<String, String> unmarshal(AdditionalIdentifiersMap inputType) throws Exception {
		HashMap<String, String> hashMap = new HashMap<String, String>();
		for (HashMapType entryType : inputType.entry) {
			hashMap.put(entryType.key, entryType.value);
		}
		return hashMap;
	}

}