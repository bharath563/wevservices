package org.tiaa.cmf.jms;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import javax.jms.JMSException;
 
public class JMSPublisherTest {
 
  public static void main(String[] args) {
    //SimpleJMSProducer producer = new SimpleJMSProducer();
    String file = "C:\\datafiles\\BPMRequest_Transfers_Perf.xml";
    int loopCount = 100;
    String message = null;
    try {
		message = readFile(file);
		System.out.println("*** Read file from folder ***");
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
    try {
    	ESBISVQueuePublisher esbProducer = new ESBISVQueuePublisher();
    	 for(int count=0; count < loopCount;count++ ){
    			esbProducer.sendMessage(message);
          }
    	 System.out.println("*** Published message count to queue --> " + loopCount);
	} catch (JMSException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
  
  public static String readFile(String fileName) throws IOException {
	    BufferedReader br = new BufferedReader(new FileReader(fileName));
	    try {
	        StringBuilder sb = new StringBuilder();
	        String line = br.readLine();

	        while (line != null) {
	            sb.append(line);
	            sb.append("\n");
	            line = br.readLine();
	        }
	        return sb.toString();
	    } finally {
	        br.close();
	    }
	}
}
