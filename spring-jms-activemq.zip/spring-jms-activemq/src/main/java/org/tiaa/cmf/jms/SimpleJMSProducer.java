package org.tiaa.cmf.jms;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

public class SimpleJMSProducer {

	@Autowired
	protected JmsTemplate jmsTemplate;

	public boolean sendMessage(final String jmsMessage) throws JMSException {
		ApplicationContext context = new ClassPathXmlApplicationContext("activiti-custom-context.xml");
		JmsTemplate jmsTemplate = (JmsTemplate) context.getBean("amqProducerTemplate");
		jmsTemplate.send(new MessageCreator() {
			public Message createMessage(Session session) throws JMSException {
				TextMessage message = session.createTextMessage(jmsMessage);
				return message;
			}
		});
		// close application context
		((ClassPathXmlApplicationContext) context).close();
		return true;
	}

}
