package org.tiaa.case_management_rs.constants;

public enum FileTypes {
	BMP,
	csv,
	DOC,
	DOCX,
	JPEG,
	JPG,
	PDF,
	PNG,
	TIF,
	TIFF,
	TXT,
	XLS,
	XLSX;

	public static boolean isValid(String value) {
		boolean valid = false;
		for (FileTypes fileType : FileTypes.values()) {
			if (value.equalsIgnoreCase(fileType.toString())) {
	          valid = true;
	        }
	    }
		return valid;
	}
}
