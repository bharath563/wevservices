package org.tiaa.case_management_rs.delegate.impl;

import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.XMLGregorianCalendar;

import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.Process;

/**
 * General comparator for sorting the combined result from downstream (EXPAG,ICM)
 * @author kumprad
 *
 */
public class SortingComparator implements Comparator<Process>{
	
	private String order;
	private String columnName;
	private final String EXPAG = "EXPAG";
	private final String ICM = "ICM";
	private final String ACTIVITI = "ACTIVITI";
	
	/**
	 * Constructor
	 * @param order -  ASC/DESC
	 * @param columnName column name
	 */
	public SortingComparator(String order, String columnName){
		this.order = order;
		this.columnName = columnName;
	}
	
	@Override
	public int compare(Process p1, Process p2) {

		if(columnName.equalsIgnoreCase(ColumnsMapping.REQUEST_TYPE)){

			if(order.equalsIgnoreCase("ASC")){

				return (p1.getAppName().equalsIgnoreCase(EXPAG) ? p1.getTasks().getTasks().get(0).getType().toLowerCase() : p1.getProcessType().toLowerCase()).
						compareTo(p2.getAppName().equalsIgnoreCase(EXPAG) ? p2.getTasks().getTasks().get(0).getType().toLowerCase() : p2.getProcessType().toLowerCase());	

			}else{
				return (p2.getAppName().equalsIgnoreCase(EXPAG) ? p2.getTasks().getTasks().get(0).getType().toLowerCase() : p2.getProcessType().toLowerCase()).
						compareTo(p1.getAppName().equalsIgnoreCase(EXPAG) ? p1.getTasks().getTasks().get(0).getType().toLowerCase() : p1.getProcessType().toLowerCase());

			}
		}
		//status
		if(columnName.equalsIgnoreCase(ColumnsMapping.STATUS)){

			if(order.equalsIgnoreCase("ASC")){

				return (p1.getAppName().equalsIgnoreCase(EXPAG) ? p1.getTasks().getTasks().get(0).getStatusHistory().getSts().get(0).getSts().toLowerCase() : p1.getStatusHistory().getSts().get(0).getSts().toLowerCase()).
						compareTo(p2.getAppName().equalsIgnoreCase(EXPAG) ? p2.getTasks().getTasks().get(0).getStatusHistory().getSts().get(0).getSts().toLowerCase() : p2.getStatusHistory().getSts().get(0).getSts().toLowerCase());
			}else{
				return (p2.getAppName().equalsIgnoreCase(EXPAG) ? p2.getTasks().getTasks().get(0).getStatusHistory().getSts().get(0).getSts().toLowerCase() : p2.getStatusHistory().getSts().get(0).getSts().toLowerCase()).
						compareTo(p1.getAppName().equalsIgnoreCase(EXPAG) ? p1.getTasks().getTasks().get(0).getStatusHistory().getSts().get(0).getSts().toLowerCase() : p1.getStatusHistory().getSts().get(0).getSts().toLowerCase());
			}
		}
		//request id
		if(columnName.equalsIgnoreCase(ColumnsMapping.REQUEST_ID)){

			if(order.equalsIgnoreCase("ASC")){

				return (p1.getAppName().equalsIgnoreCase(EXPAG) ? p1.getTasks().getTasks().get(0).getID() : getIdICM(p1)).
						compareTo(p2.getAppName().equalsIgnoreCase(EXPAG) ? p2.getTasks().getTasks().get(0).getID() : getIdICM(p2));
			}else{
				return (p2.getAppName().equalsIgnoreCase(EXPAG) ? p2.getTasks().getTasks().get(0).getID() : getIdICM(p2)).
						compareTo(p1.getAppName().equalsIgnoreCase(EXPAG) ? p1.getTasks().getTasks().get(0).getID() : getIdICM(p1));
			}
		}
		// received date
		if(columnName.equalsIgnoreCase(ColumnsMapping.RECEIVED_DATE)){
			Date process1Date = null;
			Date process2Date = null;
			int retVal = 0;
			try {
				process1Date = getProcessReceivedDate(p1);
				process2Date = getProcessReceivedDate(p2);
			} catch (DatatypeConfigurationException e) {
				//log
				e.printStackTrace();
			}
			
			if(order.equalsIgnoreCase("ASC")){
				
				if(process1Date!=null && process2Date!=null){
					retVal= process1Date.compareTo(process2Date);
				}else if(process1Date==null && process2Date!=null){
					retVal = -1;
				}else if(process1Date!=null && process2Date==null){
					retVal = 1;
				}
			}else{
				if(process1Date!=null && process2Date!=null){
					retVal = process2Date.compareTo(process1Date);
				}else if(process1Date==null && process2Date!=null){
					retVal = 1;
				}else if(process1Date!=null && process2Date==null){
					retVal = -1;
				}
			}
			return retVal;

		}
		//channel
		if(columnName.equalsIgnoreCase(ColumnsMapping.CHANNEL)){
			
			if(order.equalsIgnoreCase("ASC")){
				 return (p1.getAppName().equalsIgnoreCase(EXPAG) ? getChannelEXPAG(p1) : getChannelICM(p1))
						.compareTo(p2.getAppName().equalsIgnoreCase(EXPAG) ? getChannelEXPAG(p2) :getChannelICM(p2));
			}else{
				return (p2.getAppName().equalsIgnoreCase(EXPAG) ? getChannelEXPAG(p2) : getChannelICM(p2))
						.compareTo(p1.getAppName().equalsIgnoreCase(EXPAG) ? getChannelEXPAG(p1) :getChannelICM(p1));
			}
		}
		//PIN
		if(columnName.equalsIgnoreCase(ColumnsMapping.PIN)){
			int retVal = 0;
			String val1 = p1.getAppName().equalsIgnoreCase(EXPAG) ? getPinEXPAG(p1) : getPinICM(p1);
			String val2 = p2.getAppName().equalsIgnoreCase(EXPAG) ? getPinEXPAG(p2) :getPinICM(p2);
			if(order.equalsIgnoreCase("ASC")){
				if(val1!=null && val2!=null){
					retVal = val1.compareTo(val2);
				}
			}else{
				if(val1!=null && val2!=null){
					retVal = val2.compareTo(val1);
				}
			}
				return retVal;
		}
		
		// Create date
		if(columnName.equalsIgnoreCase(ColumnsMapping.CREATED_DATE)){
				Date process1Date = null;
				Date process2Date = null;
				int retVal = 0;
				process1Date = getCreateDate(p1);
				process2Date = getCreateDate(p2);

			if(order.equalsIgnoreCase("ASC")){
				
				if(process1Date!=null && process2Date!=null){
					retVal= process1Date.compareTo(process2Date);
				}else if(process1Date==null && process2Date!=null){
					retVal = -1;
				}else if(process1Date!=null && process2Date==null){
					retVal = 1;
				}
			}else{
				if(process1Date!=null && process2Date!=null){
					retVal = process2Date.compareTo(process1Date);
				}else if(process1Date==null && process2Date!=null){
					retVal = 1;
				}else if(process1Date!=null && process2Date==null){
					retVal = -1;
				}
			}
			return retVal;

		}
		
		// AppName
		if(columnName.equalsIgnoreCase("APP NAME")){
			int retVal = 0;
			String val1 = p1.getAppName();
			String val2 = p2.getAppName();
			
			if(order.equalsIgnoreCase("ASC")){
				if(val1!=null && val2!=null){
					retVal = val1.compareTo(val2);
				}
			}else{
				if(val1!=null && val2!=null){
					retVal = val2.compareTo(val1);
				}
			}
				return retVal;

		}

		// assignet_to sorting not immplement in ICM
/*		if(columnName.equalsIgnoreCase(ColumnsMapping.ASSIGNED_TO)){
			if(order.equalsIgnoreCase("ASC")){
				return (p1.getAppName().equalsIgnoreCase(EXPAG) ? p1.getTasks().getTasks().get(0).getAssignedTo() : " ")
						.compareTo(p2.getAppName().equalsIgnoreCase(EXPAG) ? p2.getTasks().getTasks().get(0).getAssignedTo() : " ");
			}else{
				return (p2.getAppName().equalsIgnoreCase(EXPAG) ? p2.getTasks().getTasks().get(0).getAssignedTo() : " ")
						.compareTo(p1.getAppName().equalsIgnoreCase(EXPAG) ? p1.getTasks().getTasks().get(0).getAssignedTo() : " ");
			}
		}*/

		return 0;
	}

	private Date getProcessReceivedDate(Process p) throws DatatypeConfigurationException {
		String appName = p.getAppName();
		String receivedDateStr = null;
		Date receivedDate = null;
		if(appName!=null){
		switch(appName.toUpperCase()){
			case EXPAG:
				receivedDateStr = getReceivedDateEXPAG(p);
				break;
			default:
				receivedDateStr = getReceivedDate(p);
				break;
		}
		}
		if(receivedDateStr!=null){
			receivedDate = DateUtil.fromXMLGregorianDateToDate(receivedDateStr);
		}
		return receivedDate;
	}

	/**
	 * Get Request Received date from ICM
	 * @param p process
	 * @return
	 */
	//private static String  getReceviedDateICM(Process p) {
	private static String  getReceivedDate(Process p) {
		if(p.getProcessProperties()!=null && p.getProcessProperties().getProperties()!=null){
			for(NameValue pair : p.getProcessProperties().getProperties()){
				if((pair.getName() != null && pair.getName().equalsIgnoreCase("requestReceivedDate")) ||
						(pair.getDesc() != null && pair.getDesc().equalsIgnoreCase("requestReceivedDate") )){
						return pair.getDateValue() == null ? null : pair.getDateValue().toString();
				}
			}
		}
		return null;
	}
	
	/**
	 * Get Request Received date from EXPAG
	 * @param p process
	 * @return
	 */
	private static String  getReceivedDateEXPAG(Process p) {
		
		 String date = p.getTasks().getTasks().get(0).getReceivedDate().toString();
		 String time = p.getTasks().getTasks().get(0).getReceivedTime().toString();
		 
		 return date+"T"+time;
	}
	
	/**
	 * Get Channel from ICM process property
	 * @param p process
	 * @return
	 */
	private static String getChannelICM(Process p) {
		if(p.getProcessProperties()!=null && p.getProcessProperties().getProperties()!= null){
			for(NameValue pair : p.getProcessProperties().getProperties()){
				if(pair.getDesc()!=null && pair.getDesc().equalsIgnoreCase("channel")){
					if(pair.getValue()!=null)
						return pair.getValue().toLowerCase();					
				}
			}
		}
		return " ";
	}
	
	/**
	 * Get channel from EXPAG process property
	 * @param p process
	 * @return 
	 */
	private static String getChannelEXPAG(Process p){
		if(p!=null && p.getTasks()!=null && p.getTasks().getTasks()!=null && p.getTasks().getTasks().get(0)!=null && p.getTasks().getTasks().get(0).getTaskProperties()!=null && p.getTasks().getTasks().get(0).getTaskProperties().getProperties()!=null){
			for(NameValue pair : p.getTasks().getTasks().get(0).getTaskProperties().getProperties()){
				for(NameValue nameValuePair : pair.getChildrenNameValues()){
					if(nameValuePair.getName()!=null && nameValuePair.getName().equalsIgnoreCase("channel")){
						if(nameValuePair.getValue()!=null)
							return nameValuePair.getValue().toLowerCase();					
					}
				}
			
			}
		}
		return " ";
	}
	
	/**
	 * Get confirmation(request id) from ICM
	 * @param p process
	 * @return
	 */
	private static String getIdICM(Process p) {
		if(p.getProcessProperties()!=null && p.getProcessProperties().getProperties()!=null){
			for(NameValue pair : p.getProcessProperties().getProperties()){
				if(pair.getDesc().equalsIgnoreCase("confirmation")){
					return pair.getValue().toLowerCase();
				}
			}
		}
		return " ";
	}
	
	/**
	 * Get PIN from EXPAG process property
	 * @param p process
	 * @return 
	 */
	private static String getPinEXPAG(Process p){
		if(p!=null && p.getTasks()!=null && p.getTasks().getTasks()!=null && p.getTasks().getTasks().get(0)!=null && p.getTasks().getTasks().get(0).getTaskProperties()!=null && p.getTasks().getTasks().get(0).getTaskProperties().getProperties()!=null){
			for(NameValue pair : p.getTasks().getTasks().get(0).getTaskProperties().getProperties()){
				for(NameValue nameValuePair : pair.getChildrenNameValues()){
					if(nameValuePair.getName()!=null && nameValuePair.getName().equalsIgnoreCase("pin")){
						if(nameValuePair.getValue()!=null)
							return nameValuePair.getValue();					
					}

				}
			}
		}
		return " ";
	}
	
	/**
	 * Get pin from ICM
	 * @param p process
	 * @return
	 */
	private static String getPinICM(Process p) {
		if(p.getProcessProperties()!=null && p.getProcessProperties().getProperties()!=null){
			for(NameValue pair : p.getProcessProperties().getProperties()){
				if(pair.getDesc().equalsIgnoreCase("pin")){
					return pair.getValue();
				}
			}
		}
		return " ";
	}
	
	/**
	 * Get CreateDate from Activiti/ICM
	 * @param p
	 * @return
	 */
	private static Date  getCreateDate(Process p) {
		
		if(p !=null && p.getTasks().getTasks() !=null && p.getTasks().getTasks().get(0) != null){
			if(p.getTasks().getTasks().get(0).getCreateDate() != null && p.getTasks().getTasks().get(0).getCreateTime() != null) {
				
				XMLGregorianCalendar xmlCalenderDate = p.getTasks().getTasks().get(0).getCreateDate();
				XMLGregorianCalendar xmlCalenderTime = p.getTasks().getTasks().get(0).getCreateTime();
				
				xmlCalenderDate.setHour(xmlCalenderTime.getHour());
				xmlCalenderDate.setMinute(xmlCalenderTime.getMinute());
				xmlCalenderDate.setSecond(xmlCalenderTime.getSecond());
				xmlCalenderDate.setMillisecond(xmlCalenderTime.getMillisecond());
				
				Calendar calendar = xmlCalenderDate.toGregorianCalendar();
				Date createDateTime = calendar.getTime();
	 
				return createDateTime;
			
			}
			
		}
		return null;
	}
	
}
