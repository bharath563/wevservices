package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;

public class CMSTaskTypeSLAMapper extends AbstractRowMapper<CMSTaskTypeSla>implements RowMapper<CMSTaskTypeSla> {

	@Override
	public CMSTaskTypeSla mapRow(ResultSet rs, int rowNum) throws SQLException {
		CMSTaskTypeSla cmsTaskTypeSla = new CMSTaskTypeSla();
		cmsTaskTypeSla.setTaskType(rs.getString("task_type"));
		cmsTaskTypeSla.setSla(rs.getInt("sla"));
		return cmsTaskTypeSla;
	}

}
