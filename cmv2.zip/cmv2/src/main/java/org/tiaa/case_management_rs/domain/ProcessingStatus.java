package org.tiaa.case_management_rs.domain;

public enum ProcessingStatus {
	Success, Failed, InProgress, SameStatus, Aborted, Ignore
}
