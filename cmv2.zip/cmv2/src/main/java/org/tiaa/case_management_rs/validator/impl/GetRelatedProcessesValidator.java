package org.tiaa.case_management_rs.validator.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.apache.commons.lang3.StringUtils;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.case_management_rs.constants.CaseManagementConstants;

public class GetRelatedProcessesValidator extends BaseValidatorImpl{
	@Override
	public void doValidate(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		//String taskId = (String) request.getAttribute(TASK_ID);
		String taskId = (String) request.getAttribute(PROCESS_ID);
		String appName = (String) request.getAttribute(APP_NAME);
		String solutionName = (String) request.getAttribute(SOLUTION_NAME);

		if (StringUtils.isBlank(userId)) {
			handleException(VALIDATION_USERID_IS_EMPTY);
		}

		if (StringUtils.isBlank(taskId)) {
			handleException(VALIDATION_TASKID_IS_EMPTY);
		}

		if (StringUtils.isBlank(appName)) {
			handleException(VALIDATION_APPNAME_IS_EMPTY);
		}
		
		if (CaseManagementConstants.APP_ICM.equalsIgnoreCase(appName)
				&& StringUtils.isBlank(solutionName)) {
			handleException(VALIDATION_SOLUTION_NAME_IS_NULL);
		}
	}

	
}
