package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.case_management_rs.model.NextGenProcessSource;

public class NextGenDelegatorProcessSourceMapper extends AbstractRowMapper<NextGenProcessSource> implements RowMapper<NextGenProcessSource> {

	@Override
	public NextGenProcessSource mapRow(ResultSet rs, int rowNum) throws SQLException {

		NextGenProcessSource nxtGenProcessSource = new NextGenProcessSource();

		String str = null;
		nxtGenProcessSource.setProcessCode(Integer.parseInt(getStringTrimmed(rs, "process_code")));
		nxtGenProcessSource.setProcessName(getStringTrimmed(rs, "process_name"));
		nxtGenProcessSource.setSourceSystem(getStringTrimmed(rs, "source_system"));
		str = getStringTrimmed(rs, "leagacy_system");
		nxtGenProcessSource.setLegacySystem(CaseManagementConstants.YES.equalsIgnoreCase(str) ? true : false);
		str = getStringTrimmed(rs, "nxtgen_system");
		nxtGenProcessSource.setNxtGenSystem(CaseManagementConstants.YES.equalsIgnoreCase(str) ? true : false);

		return nxtGenProcessSource;
	}
}
