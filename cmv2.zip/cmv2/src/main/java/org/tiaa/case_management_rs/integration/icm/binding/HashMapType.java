package org.tiaa.case_management_rs.integration.icm.binding;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlValue;

public class HashMapType {

	@XmlAttribute
	public String key;

	@XmlValue
	public String value;
}
