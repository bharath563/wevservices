package org.tiaa.case_management_rs.model;

/**
 * This is a POJO class made to recover data from the stored procedure in search.
 * @author austit
 *
 */
public class SearchRecord {
	
	private int RN;
    private char status;
    private String tskreq;
	private int beginDate;
	private int begintime;
	private int datercvd;
	private int timercvd;
	private String planid; 
	private String clientid;
	private String planname;
	private String channel;
	private String assignedto;  
	private String actdesc; 
	private String createoper;
	private String lckoper;
	private String suspoper;
	private String department;
	private String departmentdescription;
	private String tasktype;
	private String taskdescription;
	
	public int getRN() {
		return RN;
	}
	public void setRN(int rN) {
		RN = rN;
	}
	public char getStatus() {
		return status;
	}
	public void setStatus(char status) {
		this.status = status;
	}
	public String getTskreq() {
		return tskreq;
	}
	public void setTskreq(String tskreq) {
		this.tskreq = tskreq;
	}
	public int getBeginDate() {
		return beginDate;
	}
	public void setBeginDate(int beginDate) {
		this.beginDate = beginDate;
	}
	public int getBegintime() {
		return begintime;
	}
	public void setBegintime(int begintime) {
		this.begintime = begintime;
	}
	public int getDatercvd() {
		return datercvd;
	}
	public void setDatercvd(int datercvd) {
		this.datercvd = datercvd;
	}
	public int getTimercvd() {
		return timercvd;
	}
	public void setTimercvd(int timercvd) {
		this.timercvd = timercvd;
	}
	public String getPlanid() {
		return planid;
	}
	public void setPlanid(String planid) {
		this.planid = planid;
	}
	public String getClientid() {
		return clientid;
	}
	public void setClientid(String clientid) {
		this.clientid = clientid;
	}
	public String getPlanname() {
		return planname;
	}
	public void setPlanname(String planname) {
		this.planname = planname;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getAssignedto() {
		return assignedto;
	}
	public void setAssignedto(String assignedto) {
		this.assignedto = assignedto;
	}
	public String getActdesc() {
		return actdesc;
	}
	public void setActdesc(String actdesc) {
		this.actdesc = actdesc;
	}
	public String getCreateoper() {
		return createoper;
	}
	public void setCreateoper(String createoper) {
		this.createoper = createoper;
	}
	public String getLckoper() {
		return lckoper;
	}
	public void setLckoper(String lckoper) {
		this.lckoper = lckoper;
	}
	public String getSuspoper() {
		return suspoper;
	}
	public void setSuspoper(String suspoper) {
		this.suspoper = suspoper;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDepartmentdescription() {
		return departmentdescription;
	}
	public void setDepartmentdescription(String departmentdescription) {
		this.departmentdescription = departmentdescription;
	}
	public String getTasktype() {
		return tasktype;
	}
	public void setTasktype(String tasktype) {
		this.tasktype = tasktype;
	}
	public String getTaskdescription() {
		return taskdescription;
	}
	public void setTaskdescription(String taskdescription) {
		this.taskdescription = taskdescription;
	}
	
	
	
	
}
