package org.tiaa.case_management_rs.domain;

public class EXPAGFileInfo {

	private String folderName;
	private String filepath;
	private String volume;

	public String getFilename() {
		return this.folderName;
	}

	public void setFilename(String filename) {
		this.folderName = filename;
	}

	public String getFilepath() {
		return this.filepath;
	}

	public void setFilepath(String filepath) {
		this.filepath = filepath;
	}

	public String getVolume() {
		return this.volume;
	}

	public void setVolume(String volume) {
		this.volume = volume;
	}

}
