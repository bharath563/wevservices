package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;

public class LocationAndMailDropTimeMapper extends AbstractRowMapper<PIOperatorLocationAndMailDropTimes> implements RowMapper<PIOperatorLocationAndMailDropTimes> {

	@Override
	public PIOperatorLocationAndMailDropTimes mapRow(ResultSet rs, int rowNum) throws SQLException {

		PIOperatorLocationAndMailDropTimes piOprLocMailDropTime = new PIOperatorLocationAndMailDropTimes();
		
		piOprLocMailDropTime.setLocationCode(getStringTrimmed(rs, "LOCATIONCODE"));
		piOprLocMailDropTime.setLocationName(getStringTrimmed(rs, "LOCATIONNAME"));
		piOprLocMailDropTime.setMailDropTime(getStringTrimmed(rs, "MAILDROPTIME"));
		
		return piOprLocMailDropTime;
	}

}
