package org.tiaa.case_management_rs.integration.cth;

import org.tiaa.esb.partyrequest.types.CreateRequests;
import org.tiaa.esb.partyrequest.types.CreateRequestsResponse;

public class CTHRecordCreator {
	private CTHWebService cthWebService;
	private CreateRequestsProcessor createRequestsProcessor;

	public CreateRequestsResponse createCTHRecord(CreateCTHContext context) {
		CreateRequests createRequests = createRequestsProcessor.process(context);
		return cthWebService.createCTHEntry(context, (CreateRequests) createRequests);
	}

	public void setCreateRequestsProcessor(CreateRequestsProcessor createRequestsProcessor) {
		this.createRequestsProcessor = createRequestsProcessor;
	}

	public void setCthWebService(CTHWebService cthWebService) {
		this.cthWebService = cthWebService;
	}
}
