package org.tiaa.case_management_rs.integration.exp_ag;

public interface EXPAGTasksQueryProvider {
	String getNewDocumentsUploadedThroughEXPAGUI();

	String getAllDocumentsUploadedThroughEXPAGUI();

	String getAllDocumentsUploadedDuringTaskCompletionThroughEXPAGUI();

	String getNewDocumentsUploadedDuringTaskCompletionThroughEXPAGUI();

	String getTaskEventsForTaskTypes();

	String getTaskStatusForTaskIdOccurredAt();

	String getTaskStatusForTaskTypesSql();

	String getTaskStatusForTaskIdsSql();

	String getCthRequestSchemaName();
}