package org.tiaa.case_management_rs.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CMS_AUDIT_HISTORY")
public class CMSAuditHistory implements Serializable {
	private static final long serialVersionUID = -5542911950750643287L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CMS_AUDIT_HISTORY_SEQ")
	@SequenceGenerator(name = "CMS_AUDIT_HISTORY_SEQ", sequenceName = "CMREPORTING.CMS_AUDIT_HISTORY_SEQ", allocationSize = 1)
	private long cmsAuditHistoryId;
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastUpdatedTs;
	private String status;
	private String comments;
	private String errorMessage;
	private String cthRequestStatus;
	private String taskStatus;
	private int retryAttempt;
	@Column(name="CREATED_DATE_TS")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	@ManyToOne
	private CMSAudit cmsAudit;
	private String taskId;
	private String eventName = "";
	private int startDate;
	private int startTime;
	@Column(name="CTH_EVENT")
	private boolean cthEvent;

	public CMSAudit getCmsAudit() {
		return cmsAudit;
	}

	public long getCmsAuditHistoryId() {
		return cmsAuditHistoryId;
	}

	public String getComments() {
		return comments == null ? "" : comments;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public String getCthRequestStatus() {
		return cthRequestStatus;
	}

	public String getErrorMessage() {
		return errorMessage == null ? "" : errorMessage;
	}

	public Date getLastUpdatedTs() {
		return lastUpdatedTs;
	}

	public int getRetryAttempt() {
		return retryAttempt;
	}

	public String getStatus() {
		return status;
	}

	public String getTaskStatus() {
		return taskStatus;
	}

	public void setCmsAudit(CMSAudit cmsAudit) {
		this.cmsAudit = cmsAudit;
	}

	public void setCmsAuditHistoryId(long id) {
		this.cmsAuditHistoryId = id;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public void setCthRequestStatus(String cthRequestStatus) {
		this.cthRequestStatus = cthRequestStatus;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public void setLastUpdatedTs(Date lastUpdatedTs) {
		this.lastUpdatedTs = lastUpdatedTs;
	}

	public void setRetryAttempt(int retryAttempt) {
		this.retryAttempt = retryAttempt;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public int getStartDate() {
		return startDate;
	}

	public void setStartDate(int startDate) {
		this.startDate = startDate;
	}

	public int getStartTime() {
		return startTime;
	}

	public void setStartTime(int startTime) {
		this.startTime = startTime;
	}

	public boolean isCthEvent() {
		return cthEvent;
	}

	public void setCthEvent(boolean cthEvent) {
		this.cthEvent = cthEvent;
	}

	public boolean hasErrorMessage(String errorMsg) {
		return getErrorMessage().contains(errorMsg) || getComments().equals(errorMsg);
	}

	public String getSystem() {
		return getCmsAudit().getSystem();
	}

	public String getEventName() {
		return eventName == null ? "" : eventName;
	}

	public void setEvent(CMRSEvent event) {
		setEventName(event.name());
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	@Override
	public String toString() {
		String errMessage = errorMessage == null ? "null" : errorMessage.substring(0, 50);
		return "CMSAuditHistory [cmsAuditHistoryId=" + cmsAuditHistoryId + ", lastUpdatedTs=" + lastUpdatedTs + ", status=" + status + ", comments="
						+ comments + ", errorMessage=" + errMessage + ", cthRequestStatus=" + cthRequestStatus + ", taskStatus=" + taskStatus
						+ ", retryAttempt=" + retryAttempt + ", createdDate=" + createdDate + ", cmsAudit=" + cmsAudit + ", taskId=" + taskId
						+ ", eventName=" + eventName + ", startDate=" + startDate + ", startTime=" + startTime + ", cthEvent=" + cthEvent + "]";
	}

}
