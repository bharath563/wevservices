package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;
import org.tiaa.esb.case_management_rs_v2.type.SubField;
import org.tiaa.esb.case_management_rs_v2.type.SubFields;

public class DropdownWithSubfieldsResultMapper extends AbstractRowMapper<ConfigData> implements RowMapper<ConfigData> {

	@Override
	public ConfigData mapRow(ResultSet rs, int rowNum) throws SQLException {

		ConfigData dropDown = new ConfigData();

		dropDown.setShortDescription(getStringTrimmed(rs, "ShortDescription"));
		dropDown.setLongDescription(getStringTrimmed(rs, "LongDescription"));

		// IF subfields available then set it.
		SubFields dropDownSubFields = new SubFields();

		SubField subField = new SubField();

		// Populate information about the fields for validation purposes
		subField.setFieldNumber(rs.getInt("FieldNumber"));
		subField.setFieldName(getStringTrimmed(rs, "FieldDescription"));
		subField.setFieldSize(rs.getInt("FieldSize"));
		subField.setFieldType(getStringTrimmed(rs, "FieldType"));
		subField.setFieldEntryType(getStringTrimmed(rs, "FieldEntryType"));
		subField.setFieldRequired(getStringTrimmed(rs, "FieldRequired"));

		// Add the subfields and return
		dropDownSubFields.getSubFields().add(subField);

		dropDown.setSubFields(dropDownSubFields);

		return dropDown;
	}

}
