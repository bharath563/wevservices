package org.tiaa.case_management_rs.validator.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.apache.commons.lang3.StringUtils;

import org.tiaa.case_management_rs.common.Request;

public class GetWorkItemsValidator extends BaseValidatorImpl {

	@Override
	public void doValidate(Request request) {

		String userid = (String) request.getAttribute(USER_ID);

		if (StringUtils.isBlank(userid)) {
			handleException(VALIDATION_USERID_IS_EMPTY);
		}

	}

}
