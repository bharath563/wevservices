package org.tiaa.case_management_rs.integration.cth;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.integration.plan_sponsor.ContactResponseProcessor;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.partyrequest.types.AdditionalRequestIdentifier;
import org.tiaa.esb.partyrequest.types.AdditionalRequestIdentifiers;
import org.tiaa.esb.partyrequest.types.ObjectFactory;
import org.tiaa.esb.partyrequest.types.PartyIdentifier;
import org.tiaa.esb.partyrequest.types.PartyIdentifiers;
import org.tiaa.esb.partyrequest.types.PartyRequestControlInfo;
import org.tiaa.esb.partyrequest.types.PartyRequestResponse;
import org.tiaa.esb.partyrequest.types.PayloadInfo;
import org.tiaa.esb.partyrequest.types.RequestInfo;
import org.tiaa.esb.partyrequest.types.RetrievePartyReqControlInfo;
import org.tiaa.esb.partyrequest.types.UpdateAdditionalRequestIdentifier;
import org.tiaa.esb.partyrequest.types.UpdateAdditionalRequestIdentifiers;
import org.tiaa.esb.partyrequest.types.UpdatePartyIdentifier;
import org.tiaa.esb.partyrequest.types.UpdatePartyIdentifiers;
import org.tiaa.esb.partyrequest.types.UpdatePartyRequest;
import org.tiaa.esb.partyrequest.types.UpdatePartyRequests;
import org.tiaa.esb.partyrequest.types.UpdateRequests;
import org.tiaa.esb.plansponsor.types.ContactResponse;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;

public abstract class RetrieveRequestsResponseProcessor {
	private static final String LAST_NAME = "LastName";
	private static final String FIRST_NAME = "FirstName";
	private static final String WORKFLOW_TASK_ID = "WorkflowTaskID";
	private static final String PLAN_NUMBER = "PlanNumber";
	private static final String TASK_TYPE = "TaskType";
	private static final String CLIENT_ID = "ClientID";
	private static final String CUSTOMER_NUMBER = "CustomerNumber";
	private static final Logger LOG = LoggerFactory.getLogger(RetrieveRequestsResponseProcessor.class);
	private ObjectFactory partyRequestObjectFactory = new ObjectFactory();
	private Jaxb2Marshaller servicerequestWorkflowJaxb2Marshaller;
	private ContactResponseProcessor contactResponseProcessor;
	protected PayloadInfoBuilder payloadInfoBuilder;

	public CaseInfo getCaseInfo(Element element) {
		DOMSource domSource2 = new DOMSource();
		domSource2.setNode(element);
		return (CaseInfo) servicerequestWorkflowJaxb2Marshaller.unmarshal(domSource2);
	}

	public UpdateRequests processResponse(UpdateCTHContext context, PartyRequestResponse partyRequestResponse) {
		long requestIdentifier = partyRequestResponse.getRequestIdentifier();
		LOG.debug("requestIdentifier:{}", requestIdentifier);
		RetrievePartyReqControlInfo retrievePartyReqControlInfo = partyRequestResponse.getPartyReqControlInfo();
		//
		UpdatePartyRequest updatePartyRequest = new UpdatePartyRequest();
		updatePartyRequest.setPartyReqControlInfo(mapRetrievePartyReqControlInfo(retrievePartyReqControlInfo));
		context.setCthOrchestrationId(partyRequestResponse.getOrchestrationID());
		context.setCthRequestId(requestIdentifier);
		updatePartyRequest.setRequestIdentifier(requestIdentifier);
		updatePartyRequest.setPayloadInfo(partyRequestResponse.getPayloadInfo());
		copyPartyIdentifiers(partyRequestResponse, updatePartyRequest);
		if (!isPartyIdentifierFound(partyRequestResponse, CUSTOMER_NUMBER)) {
			UpdatePartyIdentifiers partyIdentifiersList = updatePartyRequest.getPartyIdentifiers();
			List<UpdatePartyIdentifier> partyIdentifierList = partyIdentifiersList.getPartyIdentifiers();
			String customerNumber = context.getCustomerNumber();
			if (CommonUtil.isNotNullAndNotEmpty(customerNumber)) {
				partyIdentifierList.add(createUpdatePartyIdentifier(CUSTOMER_NUMBER, customerNumber));
				updateCustomerNumber(context, customerNumber);
			}
		}
		copyAdditonalIdentifiers(partyRequestResponse, updatePartyRequest);
		TaskInfo taskInfo = context.getTaskInfo();
		String taskType = taskInfo.getTaskType();
		if (!isAdditionalIdentifierFound(partyRequestResponse, TASK_TYPE) && !taskType.isEmpty()) {
			addUpdateAdditionalIdentifer(updatePartyRequest, TASK_TYPE, taskType);
		}
		String clientId = taskInfo.getClientId();
		if (!isAdditionalIdentifierFound(partyRequestResponse, CLIENT_ID) && !clientId.isEmpty()) {
			addUpdateAdditionalIdentifer(updatePartyRequest, CLIENT_ID, clientId);
		}
		context.setUpdatePartyRequest(updatePartyRequest);
		updateIdentifers(context);
		updateClob(context, retrievePartyReqControlInfo.getStatus());
		return createUpdatePartyRequestsPayload(updatePartyRequest);
	}

	public void setContactResponseProcessor(ContactResponseProcessor contactResponseProcessor) {
		this.contactResponseProcessor = contactResponseProcessor;
	}

	public void setPayloadInfoBuilder(PayloadInfoBuilder payloadInfoBuilder) {
		this.payloadInfoBuilder = payloadInfoBuilder;
	}

	public void setServicerequestWorkflowJaxb2Marshaller(Jaxb2Marshaller servicerequestWorkflowJaxb2Marshaller) {
		this.servicerequestWorkflowJaxb2Marshaller = servicerequestWorkflowJaxb2Marshaller;
	}

	protected DOMSource getDomSource(RequestInfo requestInfo) {
		Element any = requestInfo.getAny();
		DOMSource domSource = new DOMSource();
		domSource.setNode(any);
		return domSource;
	}

	protected RequestInfo getRequestInfo(UpdateCTHContext context) {
		UpdatePartyRequest updatePartyRequest = context.getUpdatePartyRequest();
		PayloadInfo payloadInfo = updatePartyRequest.getPayloadInfo();
		return payloadInfo.getRequestInfo();
	}

	protected Element toElement(Object obj) {
		return toElement(obj, servicerequestWorkflowJaxb2Marshaller);
	}

	protected Element toElement(Object obj, Jaxb2Marshaller jaxb2Marshaller) {
		DOMResult domResult = new DOMResult();
		jaxb2Marshaller.marshal(obj, domResult);
		org.w3c.dom.Document node = (org.w3c.dom.Document) domResult.getNode();
		return node.getDocumentElement();
	}

	protected abstract boolean updateClob(UpdateCTHContext context, String status);

	protected boolean updateCTH(UpdateCTHContext context, String status) {
		return payloadInfoBuilder.updateCTH(context, status);
	}

	private void addUpdateAdditionalIdentifer(UpdatePartyRequest updatePartyRequest, String key, String value) {
		List<UpdateAdditionalRequestIdentifier> additionalRequestIdentifiers = updatePartyRequest.getAdditionalRequestIdentifiers().getAdditionalRequestIdentifiers();
		additionalRequestIdentifiers.add(createUpdateAdditionalRequestIdentifier(key, value));
	}

	private UpdateAdditionalRequestIdentifier copy(org.tiaa.esb.partyrequest.types.ObjectFactory objectFactory, AdditionalRequestIdentifier additionalRequestIdentifier) {
		UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier = new UpdateAdditionalRequestIdentifier();
		updateAdditionalRequestIdentifier.setKey(additionalRequestIdentifier.getKey());
		boolean updated = false;
		if (!updated) {
			XMLGregorianCalendar dateValue = additionalRequestIdentifier.getDateValue();
			if (dateValue != null) {
				updateAdditionalRequestIdentifier.setDateValue(objectFactory.createUpdateAdditionalRequestIdentifierDateValue(dateValue));
				updated = true;
			}
		}
		if (!updated) {
			BigDecimal decimalValue = additionalRequestIdentifier.getDecimalValue();
			if (decimalValue != null) {
				updateAdditionalRequestIdentifier.setDecimalValue(objectFactory.createUpdateAdditionalRequestIdentifierDecimalValue(decimalValue));
				updated = true;
			}
		}
		if (!updated) {
			String value = additionalRequestIdentifier.getValue();
			if (value != null) {
				updateAdditionalRequestIdentifier.setValue(objectFactory.createUpdateAdditionalRequestIdentifierValue(value));
				updated = true;
			}
		}
		return updateAdditionalRequestIdentifier;
	}

	private void copyAdditonalIdentifiers(PartyRequestResponse partyRequestResponse, UpdatePartyRequest updatePartyRequest) {
		UpdateAdditionalRequestIdentifiers updateAdditionalRequestIdentifiers = new UpdateAdditionalRequestIdentifiers();
		List<UpdateAdditionalRequestIdentifier> updateAdditionalRequestIdentifiersList = updateAdditionalRequestIdentifiers.getAdditionalRequestIdentifiers();
		//
		AdditionalRequestIdentifiers additionalRequestIdentifiers = partyRequestResponse.getAdditionalRequestIdentifiers();
		for (AdditionalRequestIdentifier additionalRequestIdentifier : additionalRequestIdentifiers.getAdditionalRequestIdentifiers()) {
			updateAdditionalRequestIdentifiersList.add(copy(partyRequestObjectFactory, additionalRequestIdentifier));
		}
		updatePartyRequest.setAdditionalRequestIdentifiers(updateAdditionalRequestIdentifiers);
	}

	private void copyPartyIdentifiers(PartyRequestResponse partyRequestResponse, UpdatePartyRequest updatePartyRequest) {
		UpdatePartyIdentifiers updatePartyIdentifiers = new UpdatePartyIdentifiers();
		List<UpdatePartyIdentifier> updatePartyIdentifiersList = updatePartyIdentifiers.getPartyIdentifiers();
		//
		PartyIdentifiers partyIdentifiers = partyRequestResponse.getPartyIdentifiers();
		for (PartyIdentifier partyIdentifier : partyIdentifiers.getPartyIdentifiers()) {
			UpdatePartyIdentifier updatePartyIdentifier = new UpdatePartyIdentifier();
			updatePartyIdentifier.setKey(partyIdentifier.getKey());
			updatePartyIdentifier.setValue(partyIdentifier.getValue());
			updatePartyIdentifiersList.add(updatePartyIdentifier);
		}
		updatePartyRequest.setPartyIdentifiers(updatePartyIdentifiers);
	}

	private UpdateAdditionalRequestIdentifier createUpdateAdditionalRequestIdentifier(String key, String value) {
		UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier = new UpdateAdditionalRequestIdentifier();
		updateAdditionalRequestIdentifier.setKey(key);
		updateAdditionalRequestIdentifier.setValue(partyRequestObjectFactory.createUpdateAdditionalRequestIdentifierValue(value));
		return updateAdditionalRequestIdentifier;
	}

	private UpdateAdditionalRequestIdentifier createUpdateAdditionalRequestIdentifier(String key, Date date) {
		UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier = new UpdateAdditionalRequestIdentifier();
		updateAdditionalRequestIdentifier.setKey(key);
		updateAdditionalRequestIdentifier.setDateValue(partyRequestObjectFactory.createUpdateAdditionalRequestIdentifierDateValue(DateUtil.toXMLGregorianCalendar(date)));
		return updateAdditionalRequestIdentifier;
	}

	private UpdateAdditionalRequestIdentifier createUpdateAdditionalRequestIdentifier(String key, BigDecimal value) {
		UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier = new UpdateAdditionalRequestIdentifier();
		updateAdditionalRequestIdentifier.setKey(key);
		updateAdditionalRequestIdentifier.setDecimalValue(partyRequestObjectFactory.createUpdateAdditionalRequestIdentifierDecimalValue(value));
		return updateAdditionalRequestIdentifier;
	}

	private UpdatePartyIdentifier createUpdatePartyIdentifier(String key, String value) {
		UpdatePartyIdentifier updatePartyIdentifier = new UpdatePartyIdentifier();
		updatePartyIdentifier.setKey(key);
		updatePartyIdentifier.setValue(value);
		return updatePartyIdentifier;
	}

	private UpdateRequests createUpdatePartyRequestsPayload(UpdatePartyRequest updatePartyRequest) {
		UpdatePartyRequests updatePartyRequests = new UpdatePartyRequests();
		updatePartyRequests.getUpdatePartyRequests().add(updatePartyRequest);
		//
		UpdateRequests updateRequests = new UpdateRequests();
		updateRequests.setUpdatePartyRequests(updatePartyRequests);
		LOG.debug("updateRequests:{}", updateRequests);
		return updateRequests;
	}

	private String getPartyIdentifier(UpdatePartyRequest updatePartyRequest, String key) {
		UpdatePartyIdentifiers partyIdentifiers = updatePartyRequest.getPartyIdentifiers();
		for (UpdatePartyIdentifier updatePartyIdentifier : partyIdentifiers.getPartyIdentifiers()) {
			if (key.equals(updatePartyIdentifier.getKey())) {
				return updatePartyIdentifier.getValue();
			}
		}
		return "";
	}

	private boolean isAdditionalIdentifierFound(PartyRequestResponse partyRequestResponse, String key) {
		for (AdditionalRequestIdentifier additionalRequestIdentifier : partyRequestResponse.getAdditionalRequestIdentifiers().getAdditionalRequestIdentifiers()) {
			if (key.equals(additionalRequestIdentifier.getKey())) {
				return true;
			}
		}
		return false;
	}

	private boolean isPartyIdentifierFound(PartyRequestResponse partyRequestResponse, String key) {
		PartyIdentifiers partyIdentifiers = partyRequestResponse.getPartyIdentifiers();
		for (PartyIdentifier partyIdentifier : partyIdentifiers.getPartyIdentifiers()) {
			if (key.equals(partyIdentifier.getKey())) {
				return true;
			}
		}
		return false;
	}

	private PartyRequestControlInfo mapRetrievePartyReqControlInfo(RetrievePartyReqControlInfo retrievePartyReqControlInfo) {
		PartyRequestControlInfo partyRequestControlInfo = new PartyRequestControlInfo();
		partyRequestControlInfo.setChannel(retrievePartyReqControlInfo.getChannel());
		partyRequestControlInfo.setEffectiveDate(retrievePartyReqControlInfo.getEffectiveDate());
		partyRequestControlInfo.setStatus(retrievePartyReqControlInfo.getStatus());
		partyRequestControlInfo.setSubmitDateTime(retrievePartyReqControlInfo.getSubmitDateTime());
		partyRequestControlInfo.setSystemIdentifier(retrievePartyReqControlInfo.getSystemIdentifier());
		partyRequestControlInfo.setUpdatedBy(AppConstants.USER_REF);
		return partyRequestControlInfo;
	}

	protected boolean updateAdditionalRequestIdentifier(List<UpdateAdditionalRequestIdentifier> updateAdditionalRequestIdentifierList, String key, String value) {
		if (CommonUtil.isNullOrEmpty(value)) {
			return false;
		}
		boolean found = false;
		boolean updateValue = false;
		for (UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier : updateAdditionalRequestIdentifierList) {
			if (updateAdditionalRequestIdentifier.getKey().equals(key)) {
				JAXBElement<String> jaxbElementValue = updateAdditionalRequestIdentifier.getValue();
				String anotherValue = jaxbElementValue.getValue();
				found = true;
				updateValue = !value.equals(anotherValue);
				if (updateValue) {
					updateAdditionalRequestIdentifier.setValue(partyRequestObjectFactory.createUpdateAdditionalRequestIdentifierValue(value));
				}
				break;
			}
		}
		if (found) {
			return updateValue;
		}
		updateAdditionalRequestIdentifierList.add(createUpdateAdditionalRequestIdentifier(key, value));
		return true;
	}

	protected boolean updateAdditionalRequestIdentifier(List<UpdateAdditionalRequestIdentifier> updateAdditionalRequestIdentifierList, String key, Date value) {
		if (CommonUtil.isNull(value)) {
			return false;
		}
		boolean found = false;
		boolean updateValue = false;
		for (UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier : updateAdditionalRequestIdentifierList) {
			if (updateAdditionalRequestIdentifier.getKey().equals(key)) {
				JAXBElement<XMLGregorianCalendar> jaxbElementValue = updateAdditionalRequestIdentifier.getDateValue();
				XMLGregorianCalendar anotherValue = jaxbElementValue.getValue();
				found = true;
				updateValue = value.compareTo(anotherValue.toGregorianCalendar().getTime()) != 0;
				if (updateValue) {
					updateAdditionalRequestIdentifier.setDateValue(partyRequestObjectFactory.createUpdateAdditionalRequestIdentifierDateValue(DateUtil.toXMLGregorianCalendar(value)));
				}
				break;
			}
		}
		if (found) {
			return updateValue;
		}
		updateAdditionalRequestIdentifierList.add(createUpdateAdditionalRequestIdentifier(key, value));
		return true;
	}

	protected boolean updateAdditionalRequestIdentifier(List<UpdateAdditionalRequestIdentifier> updateAdditionalRequestIdentifierList, String key, BigDecimal value) {
		if (CommonUtil.isNull(value)) {
			return false;
		}
		boolean found = false;
		boolean updateValue = false;
		for (UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier : updateAdditionalRequestIdentifierList) {
			if (updateAdditionalRequestIdentifier.getKey().equals(key)) {
				JAXBElement<BigDecimal> jaxbElementValue = updateAdditionalRequestIdentifier.getDecimalValue();
				BigDecimal anotherValue = jaxbElementValue.getValue();
				found = true;
				updateValue = !value.equals(anotherValue);
				if (updateValue) {
					updateAdditionalRequestIdentifier.setDecimalValue(partyRequestObjectFactory.createUpdateAdditionalRequestIdentifierDecimalValue(value));
				}
				break;
			}
		}
		if (found) {
			return updateValue;
		}
		updateAdditionalRequestIdentifierList.add(createUpdateAdditionalRequestIdentifier(key, value));
		return true;
	}

	private void updateCustomerNumber(UpdateCTHContext context, String customerNumber) {
		context.setCustomerNumberUpdated(true);
		ContactResponse contactResponse = contactResponseProcessor.process(customerNumber);
		context.setContactResponse(contactResponse);
	}

	private void updateIdentifers(UpdateCTHContext context) {
		UpdatePartyRequest updatePartyRequest = context.getUpdatePartyRequest();
		TaskInfo taskInfo = context.getTaskInfo();
		String taskType = taskInfo.getTaskType();
		String clientId = taskInfo.getClientId();
		String planNumber = taskInfo.getPlanNumber();
		String taskId = taskInfo.getTaskId();
		String customerNumber = taskInfo.getCustomerNumber();
		String customerNumberFromCTH = getPartyIdentifier(updatePartyRequest, CUSTOMER_NUMBER);
		if (!customerNumber.equals(customerNumberFromCTH)) {
			updatePartyIdentifier(updatePartyRequest, CUSTOMER_NUMBER, customerNumber);
			updateCustomerNumber(context, customerNumber);
		}
		String firstName = context.getFirstName();
		String lastName = context.getLastName();
		if (LOG.isDebugEnabled()) {
			LOG.debug("ClientID: {}", clientId);
			LOG.debug("PlanNumber: {}", planNumber);
			LOG.debug("FirstName: {}", firstName);
			LOG.debug("LastName: {}", lastName);
			LOG.debug("WorkflowTaskID: {}", taskId);
			LOG.debug("TaskType: {}", taskType);
		}
		List<UpdateAdditionalRequestIdentifier> updateAdditionalRequestIdentifierList = updatePartyRequest.getAdditionalRequestIdentifiers().getAdditionalRequestIdentifiers();
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, CLIENT_ID, clientId);
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, PLAN_NUMBER, planNumber);
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, WORKFLOW_TASK_ID, taskId);
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, TASK_TYPE, taskType);
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, FIRST_NAME, firstName);
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, LAST_NAME, lastName);
	}

	private boolean updatePartyIdentifier(UpdatePartyRequest updatePartyRequest, String key, String value) {
		if (CommonUtil.isNullOrEmpty(value)) {
			return false;
		}
		UpdatePartyIdentifiers partyIdentifiers = updatePartyRequest.getPartyIdentifiers();
		for (UpdatePartyIdentifier updatePartyIdentifier : partyIdentifiers.getPartyIdentifiers()) {
			if (key.equals(updatePartyIdentifier.getKey())) {
				if (!value.equals(updatePartyIdentifier.getValue())) {
					updatePartyIdentifier.setValue(value);
					return true;
				}
				return false;
			}
		}
		return false;
	}
}
