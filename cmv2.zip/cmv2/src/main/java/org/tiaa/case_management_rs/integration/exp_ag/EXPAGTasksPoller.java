package org.tiaa.case_management_rs.integration.exp_ag;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.apache.log4j.MDC;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import org.tiaa.case_management_rs.domain.CMSPollerLog;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.domain.WorkflowSystem;
import org.tiaa.case_management_rs.poller.PollingContext;
import org.tiaa.case_management_rs.poller.WorkflowSystemPoller;

public abstract class EXPAGTasksPoller extends WorkflowSystemPoller {
	@Autowired
	protected JdbcTemplate processJdbcTemplate;
	//
	protected TaskHistoryEventRowMapper taskHistoryEventRowMapper = new TaskHistoryEventRowMapper();
	protected EXPAGTasksDAO expagTasksDAO;
	protected EXPAGTaskProcessor taskProcessor;

	protected EXPAGTasksPoller(WorkflowSystem workflowSystem) {
		super(workflowSystem);
	}

	protected void execute(CMSPollerLog pollerLog) {
		pollerLog.printInfo();
		PollingContext pollingContext = new PollingContext();
		pollingContext.setPollerLog(pollerLog);
		//
		Collection<String> taskIds = getTaskIds(pollingContext);
		//
		Collection<TaskInfo> tasks = expagTasksDAO.getTaskInfo(taskIds);
		Map<String, TaskInfo> tasksMap = new HashMap<String, TaskInfo>();
		for (TaskInfo taskInfo : tasks) {
			tasksMap.put(taskInfo.getTaskId(), taskInfo);
		}
		pollingContext.init(tasksMap);
		//
		log.info("Processing:" + tasks.size() + " tasks");
		//documents might be added for tasks after its completed/cancelled - not supported
		addDocumentsToTasks(pollingContext, expagTasksDAO.getAllDocumentsForInProgressTasks(pollingContext));
		if (!pollingContext.getTaskIdsCompletedOrCancelled().isEmpty()) {
			addDocumentsToTasks(pollingContext, expagTasksDAO.getAllDocumentsForCompletedTasks(pollingContext));
		}
		for (TaskInfo taskInfo : tasks) {
			MDC.put("X-INF-RequestID", taskInfo.getTaskId());
			try {
				taskProcessor.processTask(taskInfo);
			} catch (Exception e) {
				log.warn(e.getMessage(), e);
			} finally {
				MDC.remove("X-INF-RequestID");
			}
		}
	}

	private Collection<String> getTaskIds(PollingContext pollingContext) {
		TreeSet<String> uniqueTaskIds = new TreeSet<String>();
		for (TaskInfo taskInfo : expagTasksDAO.getTaskStatusForTaskTypesSince(pollingContext)) {
			uniqueTaskIds.add(taskInfo.getTaskId());
		}
		//
		final int minutesBack = 0;
		for (EXPAGDocument expagDocument : expagTasksDAO.getDocumentsSince(pollingContext, minutesBack)) {
			uniqueTaskIds.add(expagDocument.getTaskId());
		}
		Collection<String> missedTaskIds = processMissedEvents(pollingContext);
		uniqueTaskIds.addAll(missedTaskIds);
		return uniqueTaskIds;
	}

	protected boolean processEvent(List<TaskHistoryEvent> taskHistoryEventsFromAuditHistory, TaskHistoryEvent taskHistoryEventFromEXPAG) {
		for (TaskHistoryEvent taskHistoryEventFromProcessDB : taskHistoryEventsFromAuditHistory) {
			if (!taskHistoryEventFromEXPAG.getTaskId().equals(taskHistoryEventFromProcessDB.getTaskId())) {
				continue;
			}
			if (taskHistoryEventFromEXPAG.isLessThan(taskHistoryEventFromProcessDB)) {
				log.warn(String.format("event {} is outdated and will be ignored", taskHistoryEventFromEXPAG.toString()));
				return false;
			}
		}
		return true;
	}

	private void addDocumentsToTasks(PollingContext pollingContext, List<EXPAGDocument> documents) {
		Map<String, TaskInfo> taskInfoMap = pollingContext.getTaskInfoMap();
		for (EXPAGDocument expagDocument : documents) {
			String taskId = expagDocument.getTaskId();
			TaskInfo taskInfo = taskInfoMap.get(taskId);
			if (taskInfo == null) {
				//should never come here
				//can fetch tasks not listed....mmm
				log.warn("expagDocument:{}", expagDocument);
				taskInfo = new TaskInfo();
				taskInfo.setTaskId(expagDocument.getTaskId());
				taskInfo.setTaskType(expagDocument.getTaskType());
				taskInfo.setCreateOperator(expagDocument.getCreateOperator());
				taskInfo.setStartDate(expagDocument.getStartDate());
				taskInfo.setStartTime(expagDocument.getStartTime());
				//
				TaskInfo taskInfoFromDB = expagTasksDAO.getTaskInfo(taskId);
				if (taskInfoFromDB != null) {
					taskInfo = taskInfoFromDB;
				}
				taskInfoMap.put(taskInfo.getTaskId(), taskInfo);
			}
			taskInfo.addDocument(expagDocument);
		}
	}

	private Collection<String> processMissedEvents(PollingContext pollingContext) {
		List<TaskHistoryEvent> taskHistoryEventsFromEXPAG = expagTasksDAO.getTaskHistoryEventsInLastXMinutes(pollingContext);
		//
		String sql = "select TASK_ID, START_DATE, START_TIME,STATUS, ERROR_MESSAGE from CMS_AUDIT_HISTORY where CREATED_DATE_TS > (systimestamp - numtodsinterval(?,'MINUTE'))";
		final int minutes = 60;
		List<TaskHistoryEvent> taskHistoryEventsFromAuditHistory = processJdbcTemplate.query(sql, taskHistoryEventRowMapper, minutes);
		taskHistoryEventsFromEXPAG.removeAll(taskHistoryEventsFromAuditHistory);
		//
		log.debug("plausible taskHistoryEvents missed count:{}", taskHistoryEventsFromEXPAG.size());
		TreeSet<String> missedTaskIds = new TreeSet<String>();
		for (TaskHistoryEvent taskHistoryEvent : taskHistoryEventsFromEXPAG) {
			log.debug("missed taskHistoryEvent:{}", taskHistoryEvent);
			//get event details from exp-ag
			//check if the event is a past event, if there is a latest event in audit-history events
			if (!processEvent(taskHistoryEventsFromAuditHistory, taskHistoryEvent)) {
				continue;
			}
			if (taskHistoryEvent.isFailedStatus()) {
				//re-process failed event only if its cth record create
				log.debug("failed taskHistoryEvent:{}", taskHistoryEvent);
			}
			missedTaskIds.add(taskHistoryEvent.getTaskId());
		}
		return missedTaskIds;
	}

	public static class TaskHistoryEventRowMapper extends AbstractRowMapper<TaskHistoryEvent> {
		@Override
		public TaskHistoryEvent mapRow(ResultSet resultSet, int rowNum) throws SQLException {
			return new TaskHistoryEvent(//
					getStringTrimmed(resultSet, "TASK_ID"), //
					resultSet.getInt("START_DATE"), //
					resultSet.getInt("START_TIME"), //
					getStringTrimmed(resultSet, "STATUS"), //
					getStringTrimmed(resultSet, "ERROR_MESSAGE"));
		}
	}

}
