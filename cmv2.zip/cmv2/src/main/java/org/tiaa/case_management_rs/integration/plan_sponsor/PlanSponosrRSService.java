package org.tiaa.case_management_rs.integration.plan_sponsor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import org.tiaa.case_management_rs.common.ThreadLocalCustomerNumber;
import org.tiaa.esb.plansponsor.types.ContactResponse;
import org.tiaa.esb.plansponsor.types.UUPSearchResponse;

public class PlanSponosrRSService {
	private static final Logger LOG = LoggerFactory.getLogger(PlanSponosrRSService.class);
	private String baseUri;
	private RestTemplate planSponsorRestTemplate;

	public ContactResponse getContact(String id) {
		String url = baseUri + "/customers/{id}";
		ThreadLocalCustomerNumber.set(id);
		try {
			ContactResponse contactResponse = planSponsorRestTemplate.getForObject(url, ContactResponse.class, id);
			LOG.debug("contactResponse: {}", contactResponse);
			return contactResponse;
		} catch(HttpClientErrorException e) {
			LOG.error(e.getMessage(), e);
			return null;
		} catch(Exception e) {
			LOG.error(e.getMessage(), e);
			return null;
		} finally {
			ThreadLocalCustomerNumber.remove();
		}
	}

	public UUPSearchResponse searchUUP(String planNumber) {
		String url = baseUri + "/uup-search?login-id=CaseManagementRSV1&endeca-config-required=false&ldap-user-type=IE&plan-number={planNumber}";
		UUPSearchResponse uupSearchResponse = planSponsorRestTemplate.getForObject(url, UUPSearchResponse.class, planNumber);
		LOG.debug("uupSearchResponse: {}", uupSearchResponse);
		return uupSearchResponse;
	}

	public ContactResponse searchContact(String clientId) {
		String url = baseUri + "/contact-search?client-id={clientId}&ldap-user-type=IE-RE";
		ContactResponse contactResponse = planSponsorRestTemplate.getForObject(url, ContactResponse.class, clientId);
		LOG.debug("contactResponse: {}", contactResponse);
		return contactResponse;
	}

	public void setUri(String uri) {
		this.baseUri = uri;
	}

	public void setPlanSponsorRestTemplate(RestTemplate planSponsorRestTemplate) {
		this.planSponsorRestTemplate = planSponsorRestTemplate;
	}
}
