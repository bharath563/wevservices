package org.tiaa.case_management_rs.syncup.service_request;

import java.util.Collections;
import java.util.List;

import javax.xml.transform.dom.DOMSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.integration.cth.CTHPayloadJaxbMarshaller;
import org.tiaa.case_management_rs.integration.cth.ServiceRequestWorkflowJaxbMarshaller;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTaskType;
import org.tiaa.esb.partyrequest.types.PartyRequestResponse;
import org.tiaa.esb.partyrequest.types.RequestInfo;
import org.tiaa.esb.servicerequest.types.AnyXMLSkipType;
import org.tiaa.esb.servicerequest.types.CTHClob;
import org.tiaa.esb.servicerequest.types.OtherData;
import org.tiaa.esb.servicerequest.types.Request;
import org.tiaa.esb.servicerequest.types.ServiceRequest;
import org.tiaa.esb.servicerequest_workflow.types.CaseDetailsType;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;
import org.tiaa.esb.servicerequest_workflow.types.IdentifiersType;
import org.tiaa.esb.servicerequest_workflow.types.NameValuePairType;

@EXPAGTaskType(requestType = "ServiceRequest")
public class ServiceRequesJaxbMarshaller implements CTHPayloadJaxbMarshaller {
	private static final Logger LOG = LoggerFactory.getLogger(ServiceRequesJaxbMarshaller.class);
	private Jaxb2Marshaller serviceRequestJaxb2Marshaller;
	private ServiceRequestWorkflowJaxbMarshaller serviceRequestWorkflowJaxbMarshaller;

	public CaseInfo getCaseInfo(OtherData otherData) {
		if (otherData == null) {
			return null;
		}
		AnyXMLSkipType workFlowXML = otherData.getWorkFlowXML();
		Element any = workFlowXML.getAny();
		return serviceRequestWorkflowJaxbMarshaller.getCaseInfo(any);
	}

	public CTHClob getCTHClob(DOMSource domSource) {
		CTHClob cthClob = (CTHClob) serviceRequestJaxb2Marshaller.unmarshal(domSource);
		LOG.debug("cthClob:{}", cthClob);
		return cthClob;
	}

	public OtherData getOtherData(CTHClob cthClob) {
		OtherData otherData = null;
		if (cthClob != null) {
			LOG.debug("cthClob request:{}", cthClob.getRequest());
			otherData = cthClob.getOtherData();
		}
		return otherData;
	}

	public OtherData getOtherData(DOMSource domSource) {
		return getOtherData(getCTHClob(domSource));
	}

	@Override
	public String getTaskId(Element payload) {
		Element any = getWorkflowXml(payload);
		CaseInfo caseInfo = serviceRequestWorkflowJaxbMarshaller.getCaseInfo(any);
		return serviceRequestWorkflowJaxbMarshaller.getTaskid(caseInfo);
	}

	public Element toElement(DOMSource domSource) {
		return ServiceRequestWorkflowJaxbMarshaller.toElement(getCTHClob(domSource), serviceRequestJaxb2Marshaller);
	}

	private Element getWorkflowXml(Element payload) {
		CTHClob cthClob = getCTHClob(new DOMSource(payload));
		OtherData otherData = cthClob.getOtherData();
		AnyXMLSkipType workFlowXML = otherData.getWorkFlowXML();
		return workFlowXML.getAny();
	}

	public CTHClob getCTHClob(PartyRequestResponse partyRequestResponse) {
		RequestInfo requestInfo = partyRequestResponse.getPayloadInfo().getRequestInfo();
		DOMSource domSource = getDomSource(requestInfo);
		return getCTHClob(domSource);
	}

	public String getRequestDescription(CTHClob cthClob) {
		Request request = cthClob.getRequest();
		if (request == null) {
			return "";
		}
		ServiceRequest serviceRequest = request.getServiceRequest();
		if (serviceRequest == null) {
			return "";
		}
		String requestDescription = serviceRequest.getRequestDescription();
		if (requestDescription == null) {
			return "";
		}
		return requestDescription;
	}

	public List<NameValuePairType> getIdentifierTypes(CTHClob cthClob) {
		OtherData otherData = getOtherData(cthClob);
		if (otherData == null) {
			return Collections.emptyList();
		}
		CaseInfo caseInfo = getCaseInfo(otherData);
		if (caseInfo == null) {
			return Collections.emptyList();
		}
		CaseDetailsType caseDetails = caseInfo.getCaseDetails();
		if (caseDetails == null) {
			return Collections.emptyList();
		}
		IdentifiersType identifiers = caseDetails.getIdentifiers();
		if (identifiers == null) {
			return Collections.emptyList();
		}
		return identifiers.getIdentifierTypes();
	}

	public void setServiceRequestJaxb2Marshaller(Jaxb2Marshaller cthJaxb2WorkflowMarshaller) {
		this.serviceRequestJaxb2Marshaller = cthJaxb2WorkflowMarshaller;
	}

	public void setServiceRequestWorkflowJaxbMarshaller(ServiceRequestWorkflowJaxbMarshaller serviceRequestWorkflowJaxbMarshaller) {
		this.serviceRequestWorkflowJaxbMarshaller = serviceRequestWorkflowJaxbMarshaller;
	}

	public Jaxb2Marshaller getServiceRequestJaxb2Marshaller() {
		return serviceRequestJaxb2Marshaller;
	}

	public DOMSource getDomSource(RequestInfo requestInfo) {
		Element any = requestInfo.getAny();
		DOMSource domSource = new DOMSource();
		domSource.setNode(any);
		return domSource;
	}
}
