package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.case_management_rs.model.ExpagStatusHistory;

/**
 * Get Expag Task Status History
 * @author rudra
 *
 */
public class ExpagStatusHistoryRowMapper extends AbstractRowMapper<ExpagStatusHistory> implements RowMapper<ExpagStatusHistory> {

	@Override
	public ExpagStatusHistory mapRow(ResultSet rs, int rowNum) throws SQLException {

		ExpagStatusHistory statusHistory = new ExpagStatusHistory();

		statusHistory.setTaskId(getStringTrimmed(rs, "tskid"));
		statusHistory.setStartdatetime(getStringTrimmed(rs, "startdatetime"));
		statusHistory.setEnddatetime(getStringTrimmed(rs, "enddatetime"));
		statusHistory.setOperid(getStringTrimmed(rs, "operid"));
		statusHistory.setAssignedto(getStringTrimmed(rs, "assignedto"));
		statusHistory.setStatus(getStringTrimmed(rs, "status"));

		return statusHistory;
	}
}
