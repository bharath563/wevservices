package org.tiaa.case_management_rs.integration.case_manager;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import org.tiaa.case_management_rs.constants.FileTypes;
import org.tiaa.case_management_rs.integration.case_manager.domain.Case;
import org.tiaa.case_management_rs.integration.case_manager.domain.CaseManagerDocument;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.servicerequest_workflow.types.DocumentIDType;
import org.tiaa.esb.servicerequest_workflow.types.DocumentIDsType;

public class CaseDocumentRSExtractor extends CaseMapper implements ResultSetExtractor<Map<String, Case>> {
	private static final Logger LOG = LoggerFactory.getLogger(CaseDocumentRSExtractor.class);
	private final Map<String, Case> caseMap;

	public CaseDocumentRSExtractor(Map<String, Case> caseMap) {
		super();
		this.caseMap = caseMap;
	}

	@Override
	public Map<String, Case> extractData(ResultSet rs) throws SQLException, DataAccessException {
		while (rs.next()) {
			String caseId = rs.getString("case_id");
			if (!caseMap.containsKey(caseId)) {
				caseMap.put(caseId, mapCase(rs));
			}
			CaseManagerDocument document = mapDocument(rs);
			if (document != null) {
				caseMap.get(caseId).addDocument(document);
			}
		}
		for (Case kase : caseMap.values()) {
			kase.markPreviousVersionOfDocumentsAsDeletedForCase();
		}
		return caseMap;
	}

	public CaseManagerDocument mapDocument(ResultSet rs) throws SQLException {
		CaseManagerDocument document = new CaseManagerDocument();
		String docFolder = getStringTrimmed(rs, "corres_folder");
		if (docFolder != null) {
			String[] docCategory = docFolder.split("/");
			if (docCategory.length > 1) {
				document.setDocumentCategoryType(docCategory[0]);
				document.setDocumentType(docCategory[1]);
			}
		}
		if ("/PlanFocus/Inbound".equalsIgnoreCase(docFolder)) {
			document.setDocumentDirection("Inbound");
			document.setDocumentCategoryType("Correspondence - Inbound");
		} else if ("/PlanFocus/Outbound".equalsIgnoreCase(docFolder)) {
			document.setDocumentDirection("Outbound");
			document.setDocumentCategoryType("Correspondence - Outbound");
		} else {
			return null;
		}
		document.setDocumentType(rs.getString("corres_name"));
		document.setVersion(rs.getString("corres_ver"));
		try {
			document.setDocumentContainerId(rs.getString("document_container_id"));
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
		}
		String documentStatus = getStringTrimmed(rs, "corres_status");
		if ("Deleted".equalsIgnoreCase(documentStatus)) {
			documentStatus = "DELETED";
		} else if ("CheckedIn".equalsIgnoreCase(documentStatus) || "Uploaded".equalsIgnoreCase(documentStatus)) {
			documentStatus = "REQUIRED";
		}
		document.setName(getStringTrimmed(rs, "corres_name"));
		document.setDocumentVersion(2);//as per planfocus/mobius team version for retriving the document should always be 2
		document.setDocumentStatus(documentStatus);
		document.setBusinessUnit(getStringTrimmed(rs, "business_unit"));
		document.setDocumentCode(getStringTrimmed(rs, "doc_code"));
		document.setMimeType(getStringTrimmed(rs, "mime_type"));
		String documentStorageSystem = getStringTrimmed(rs, "archieved_in_sys");
		if (documentStorageSystem == null) {
			documentStorageSystem = "";
		}
		document.setDocumentStorageSystem(documentStorageSystem.toUpperCase());
		document.setDocumentIDs(createDocumentIds(rs.getString("dri_value")));
		Timestamp createdTS = rs.getTimestamp("doc_created_ts");
		document.setCreatedTS(createdTS);
		Timestamp updatedTS = rs.getTimestamp("doc_updated_ts");
		document.setUpdatedTS(updatedTS);
		Timestamp businessDate = createdTS;
		document.setBusinessDate(DateUtil.toXMLGregorianCalendar(businessDate));

		String documentType = document.getDocumentType();
		String fileExtension = documentType == null ? null : documentType.substring(documentType.lastIndexOf(".") + 1);
		Boolean hasValidFileType = fileExtension == null ? false : FileTypes.isValid(fileExtension);
		if(hasValidFileType){
			document.setDocumentUploadedDateTime(DateUtil.toXMLGregorianCalendar(createdTS));
			document.setDocumentRead(true);
		}

		return document;
	}

	private DocumentIDsType createDocumentIds(String documentId) {
		DocumentIDType documentIDType = new DocumentIDType();
		documentIDType.setValue(documentId);
		documentIDType.setType("DocumentRequestID");
		//
		DocumentIDsType documentIDsType = new DocumentIDsType();
		documentIDsType.getDocumentIDs().add(documentIDType);
		return documentIDsType;
	}
}
