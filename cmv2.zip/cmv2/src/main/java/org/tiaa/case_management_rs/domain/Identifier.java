package org.tiaa.case_management_rs.domain;

import java.io.Serializable;

public class Identifier implements Comparable<Identifier>, Serializable {
	private static final long serialVersionUID = 6834273640209732168L;
	private int displayOrder;
	private String formattedValue;
	private String label;
	private String name;
	private Object value;

	public Identifier() {
	}

	public Identifier(String name, Object value) {
		this.name = name;
		this.value = value;
	}

	@Override
	public int compareTo(Identifier o) {
		return (displayOrder < o.displayOrder) ? -1 : ((displayOrder == o.displayOrder) ? 0 : 1);
	}

	public int getDisplayOrder() {
		return displayOrder;
	}

	public String getFormattedValue() {
		return formattedValue;
	}

	public String getLabel() {
		return label;
	}

	public String getName() {
		return name;
	}

	public Object getValue() {
		return value;
	}

	public String getStringValue() {
		return value == null ? null : value.toString();
	}

	public void setDisplayOrder(int displayOrder) {
		this.displayOrder = displayOrder;
	}

	public void setFormattedValue(String formattedValue) {
		this.formattedValue = formattedValue;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return "NameValue [displayOrder=" + displayOrder + ", label=" + label + ", name=" + name + ", value=" + value + ", formattedValue=" + formattedValue + "]";
	}
}
