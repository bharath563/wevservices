package org.tiaa.case_management_rs.dao;

public class PIOperatorLocationAndMailDropTimes {

	private String locationCode;
	private String locationName;
	private String mailDropTime;
	
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getLocationName() {
		return locationName;
	}
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}
	public String getMailDropTime() {
		return mailDropTime;
	}
	public void setMailDropTime(String mailDropTime) {
		this.mailDropTime = mailDropTime;
	}
	
}
