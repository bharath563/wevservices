package org.tiaa.case_management_rs.integration.case_manager.domain;

import java.util.Comparator;
import java.util.Date;

import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.esb.servicerequest_workflow.types.DocumentType;

public class CaseManagerDocument extends DocumentType {
	public static final CompareByVersion COMPARE_BY_VERSION = new CompareByVersion();
	private static final long serialVersionUID = 4204680533185153587L;
	private String name;
	private String businessUnit;
	private String mimeType;
	private Date createdTS;
	private Date updatedTS;
	private String documentContainerId;
	private int version;

	public String getBusinessUnit() {
		return businessUnit;
	}

	public Date getCreatedTS() {
		return createdTS;
	}

	public String getMimeType() {
		return mimeType;
	}

	public String getName() {
		return name;
	}

	public Date getUpdatedTS() {
		return updatedTS;
	}

	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}

	public void setCreatedTS(Date createdTS) {
		this.createdTS = createdTS;
	}

	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setUpdatedTS(Date updatedTS) {
		this.updatedTS = updatedTS;
	}

	public String getDocumentContainerId() {
		return documentContainerId;
	}

	public void setDocumentContainerId(String documentContainerId) {
		this.documentContainerId = documentContainerId;
	}

	public int getVersion() {
		return version;
	}

	public void setVersion(String version) {
		if (CommonUtil.isNullOrEmpty(version)) {
			this.version = 1;
			return;
		}
		try {
			this.version = Integer.parseInt(version);
		} catch (Exception e) {
			this.version = 1;
		}
	}

	@Override
	public String toString() {
		return "CaseManagerDocument [name=" + name + ", businessUnit=" + businessUnit + ", mimeType=" + mimeType + ", createdTS=" + createdTS + ", updatedTS=" + updatedTS
				+ ", documentContainerId=" + documentContainerId + ", version=" + version + "]";
	}

	private static final class CompareByVersion implements Comparator<CaseManagerDocument> {
		@Override
		public int compare(CaseManagerDocument o1, CaseManagerDocument o2) {
			int version1 = o1.getVersion();
			int version2 = o2.getVersion();
			if (version1 < version2) {
				return -1;
			}
			if (version1 > version2) {
				return 1;
			}
			return 0;
		}
	}
}
