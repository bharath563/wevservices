package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.Event;


/**
 * Mapping Event element of a task 
 * @author yarlagn
 *
 */
public class EXPAGCaseWorkerTaskMapper extends AbstractRowMapper<Event> implements RowMapper<Event> {

	@Override
	public Event mapRow(ResultSet rs, int rowNum) throws SQLException {
		Event events= new Event();
		events.setTitle("DOC");
		events.setCreatedBy(getStringTrimmed(rs,"SHORTDESCRIPTION"));
		events.setDescription(getStringTrimmed(rs, "STATUS"));
		String source=getStringTrimmed(rs,"CREATEDATETIME");
		Calendar cal= Calendar.getInstance();
		DateFormat originaFormat=new SimpleDateFormat(DateUtil.DEFAULT_DATE_FORMAT_6);
		Date crDateTime=new Date();
		try {
			crDateTime=originaFormat.parse(source);
		} catch (java.text.ParseException e) {
			e.printStackTrace();
		}
		cal.setTime(crDateTime);
		XMLGregorianCalendar createDateTime=DateUtil.toXMLGregorianCalendarDateTime(cal.getTime());
		events.setCreateDateTime(createDateTime);
		return events;

	}
}