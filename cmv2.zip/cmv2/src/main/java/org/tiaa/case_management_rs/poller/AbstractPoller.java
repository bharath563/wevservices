package org.tiaa.case_management_rs.poller;

import static org.tiaa.case_management_rs.common.AppConstants.*;

import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.common.ExceptionHandler;
import org.tiaa.case_management_rs.email.EmailSender;
import org.tiaa.case_management_rs.utils.CommonUtil;

public abstract class AbstractPoller implements IPoller {
	protected final Logger log;
	protected final Logger statusLogger;
	private boolean busy = false;
	protected boolean disabled = false;
	private boolean stopped = false;
	@Autowired
	protected EmailSender emailSender;
	@Autowired
	protected ComponentSynchronizerService componentSynchronizerService;
	@Autowired
	protected ExceptionHandler exceptionHandler;
	private static Object monitor = new Object();
	protected final String instance;

	public AbstractPoller() {
		this.log = LoggerFactory.getLogger(this.getClass());
		this.statusLogger = LoggerFactory.getLogger(STATUS_PACKAGE + this.getClass().getSimpleName());
		this.instance = CommonUtil.getHostAndNodeName();
	}

	@PreDestroy
	public void destroy() {
		this.stopped = true;
	}

	public boolean isBusy() {
		return this.busy;
	}

	@Override
	public boolean isDisabled() {
		return this.disabled;
	}

	public boolean pollWithLock(IPoller poller) {
		boolean poll = false;
		synchronized (monitor) {
			final String name = poller.getClass().getName();
			this.statusLogger.debug("Start Attempt to run poller:{}", name);
			poll = poller.poll();
			this.statusLogger.debug("End Attempt to run poller:{}", name);
		}
		return poll;
	}

	@Override
	public boolean poll() {
		if (this.stopped) {
			this.log.info("polling stopped");
			return false;
		}
		if (this.disabled) {
			this.log.info("polling disabled");
			return false;
		}
		if (this.busy) {
			this.log.info("busy...");
			return false;
		}
		this.log.info("{} running...", this.getClass().getSimpleName());
		this.busy = true;
		try {
			this.exceptionHandler.run(this);
		} finally {
			this.busy = false;
		}
		return true;
	}

	@Override
	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	public void start() {
		this.stopped = false;
	}

	public void stop() {
		this.stopped = true;
	}

	protected void sleep(int interval) {
		final int oneSecond = 1000;
		try {
			Thread.sleep(oneSecond * interval);
		} catch (InterruptedException e) {
			this.log.warn(e.getMessage());
		}
	}
}