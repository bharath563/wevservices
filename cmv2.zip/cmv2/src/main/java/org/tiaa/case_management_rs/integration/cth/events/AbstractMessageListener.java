package org.tiaa.case_management_rs.integration.cth.events;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.xml.transform.StringSource;

import org.tiaa.cth.event.generated.jaxb.types.EventRequest;

public class AbstractMessageListener {
	protected final Logger log;
	@Autowired
	private CTHEventProcessor cthEventProcessor;
	@Autowired
	private Jaxb2Marshaller cthEventJaxb2Marshaller;

	public AbstractMessageListener() {
		super();
		log = LoggerFactory.getLogger(this.getClass());
		log.info("Message Listener up");
	}

	public void processEventMessage(String jmsMessage) {
		if (StringUtils.isEmpty(jmsMessage)) {
			log.debug("JMS message is null or empty:{}", jmsMessage);
			return;
		}
		log.warn("JMS message:{}", jmsMessage);
		EventRequest eventRequest = (EventRequest) cthEventJaxb2Marshaller.unmarshal(new StringSource(jmsMessage));
		cthEventProcessor.processEvent(eventRequest);
	}
}
