package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;
import org.tiaa.esb.case_management_rs_v2.type.SubField;
import org.tiaa.esb.case_management_rs_v2.type.SubFields;

public class EXPAGHelpVariablesMapper extends AbstractRowMapper<ConfigData> implements RowMapper<ConfigData> {

	@Override
	public ConfigData mapRow(ResultSet rs, int rowNum) throws SQLException {
		ConfigData helpVariables = new ConfigData();

		helpVariables.setShortDescription(getStringTrimmed(rs, "ShortDescription"));
		helpVariables.setLongDescription(getStringTrimmed(rs, "LongDescription"));
		
		SubFields subFields = new SubFields();
		SubField subField = new SubField();
		
		String fieldValueNewData = getString(rs, "FieldValue");
		if(fieldValueNewData!=null && fieldValueNewData.contains("<![CDATA[")){	
			fieldValueNewData = fieldValueNewData.replace("<![CDATA[", "").replace("]]>", "");
		}
		subField.setFieldValue("<![CDATA["+(fieldValueNewData) +"]]>");
		subFields.getSubFields().add(subField);

		helpVariables.setSubFields(subFields);
		
		return helpVariables;
	}

}