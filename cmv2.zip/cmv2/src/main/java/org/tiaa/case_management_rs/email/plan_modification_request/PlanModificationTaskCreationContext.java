package org.tiaa.case_management_rs.email.plan_modification_request;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Properties;
import java.util.TreeSet;

import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.esb.partyrequest.types.PartyRequestResponse;
import org.tiaa.esb.plansponsor.types.Plan;

public class PlanModificationTaskCreationContext {
	private Plan plan;
	private TaskInfo taskInfo;
	private CMSAuditHistory cmsAuditHistory;
	private Collection<ContactInfo> relationshipAndCaseManagers = new TreeSet<ContactInfo>();
	private Properties contactSheetAsProperties;
	private PartyRequestResponse partyRequestResponse;

	public ArrayList<ContactInfo> getRelationshipAndCaseManagersSortedByRole() {
		ArrayList<ContactInfo> relationshipAndCaseManagersSorted = new ArrayList<ContactInfo>(relationshipAndCaseManagers);
		Collections.sort(relationshipAndCaseManagersSorted, ContactInfo.COMPARATOR_BY_ROLE);
		return relationshipAndCaseManagersSorted;
	}

	public String[] getRMandCMEmailAddresses() {
		TreeSet<String> rmAndCMEmailAdddresses = new TreeSet<String>();
		for (ContactInfo contactInfo : relationshipAndCaseManagers) {
			rmAndCMEmailAdddresses.add(contactInfo.getEmailAddress());
		}
		return rmAndCMEmailAdddresses.toArray(new String[rmAndCMEmailAdddresses.size()]);
	}

	public String getPlanName() {
		return plan == null ? "" : plan.getPlanName();
	}

	public CMSAuditHistory getCmsAuditHistory() {
		return cmsAuditHistory;
	}

	public Properties getContactSheetAsProperties() {
		return contactSheetAsProperties;
	}

	public Plan getPlan() {
		return plan;
	}

	public String getPlanNumber() {
		return taskInfo.getPlanNumber();
	}

	public Collection<ContactInfo> getRelationshipAndCaseManagers() {
		return relationshipAndCaseManagers;
	}

	public TaskInfo getTaskInfo() {
		return taskInfo;
	}

	public void setCmsAuditHistory(CMSAuditHistory cmsAuditHistory) {
		this.cmsAuditHistory = cmsAuditHistory;
	}

	public void setContactSheetAsProperties(Properties contactSheetAsProperties) {
		this.contactSheetAsProperties = contactSheetAsProperties;
	}

	public void setPlan(Plan plan) {
		this.plan = plan;
	}

	public void setTaskInfo(TaskInfo taskInfo) {
		this.taskInfo = taskInfo;
	}

	public PartyRequestResponse getPartyRequestResponse() {
		return partyRequestResponse;
	}

	public void setPartyRequestResponse(PartyRequestResponse partyRequestResponse) {
		this.partyRequestResponse = partyRequestResponse;
	}

	@Override
	public String toString() {
		return "PlanModificationTaskCreationContext [plan=" + plan + ", taskInfo=" + taskInfo + ", cmsAuditHistory=" + cmsAuditHistory
						+ ", relationshipAndCaseManagers=" + relationshipAndCaseManagers + ", contactSheetAsProperties=" + contactSheetAsProperties
						+ ", partyRequestResponse=" + partyRequestResponse + "]";
	}

}
