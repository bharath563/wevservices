package org.tiaa.case_management_rs.constants;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.utils.DateUtil;

@Component
public class HolidaysCache {
	private static final Logger LOGGER = LoggerFactory.getLogger(HolidaysCache.class);
	
	@Value("${externalization-v2}")
    private java.lang.String externalizationURL;
	public static Map<Integer, Set<LocalDate>> holidaysMap = Collections.synchronizedMap(new HashMap<Integer, Set<LocalDate>>());
	
	public static Map<Integer, Set<LocalDate>> getHolidaysMap() {
		return holidaysMap;
	}

	public static void setHolidaysMap(Map<Integer, Set<LocalDate>> holidaysMap) {
		HolidaysCache.holidaysMap = holidaysMap;
	}
		
	@Scheduled(cron = "${cache.refresh.cron}")
    public void refreshCacheData() {
		LOGGER.info("Holidays Map Size before refresh->" + holidaysMap.size());
    	loadHolidays();
    	LOGGER.info("Holidays Map Size after refresh->" + holidaysMap.size());
    }

	public boolean isHoliday(Integer year, LocalDate date) {
		if(holidaysMap.containsKey(year)){
			if(holidaysMap.get(year).contains(date)){
				return true;
			}
		} /*else {
			//Check from business service if its business day or not.
			List<LocalDate> hDates = new ArrayList<LocalDate>();
			hDates.add(date);
			holidaysMap.put(year, hDates);
		}*/
		return false;
	}
	
	@PostConstruct
	public void loadHolidays() {
		try{
			org.tiaa.esb.externalization_v2.types.response.Holiday[] holidays= this.getHolidays();
		
			DateTimeFormatter dateFormatter = DateTimeFormat.forPattern(DateUtil.DEFAULT_SIMPLE_DATE_FORMAT);
		
			List<org.tiaa.esb.externalization_v2.types.response.Holiday> holidayList = Arrays.asList(holidays);
		
			if(holidayList != null && holidayList.size() > 0){
				LOGGER.info("Holidays List Size->" + holidayList.size());
				for(org.tiaa.esb.externalization_v2.types.response.Holiday holiday : holidayList){
					java.util.Calendar hDate = holiday.getHolidayDt();
					if(hDate != null){
						Date date = new Date(hDate.getTimeInMillis());
						SimpleDateFormat dateFormat = new SimpleDateFormat(DateUtil.DEFAULT_SIMPLE_DATE_FORMAT);
						String holidayDateString = dateFormat.format(date);
						LocalDate holidayDate = dateFormatter.parseLocalDate(holidayDateString);
						int year = holidayDate.getYear();
						if(holidaysMap.containsKey(year)){
							holidaysMap.get(year).add(holidayDate);
						}else {
							Set<LocalDate> hDates = new HashSet<LocalDate>();
							hDates.add(holidayDate);
							holidaysMap.put(year, hDates);
						}
					}
				}
			}
		} catch (Exception e){
			LOGGER.error("Error while loading Hoidays list --> " + e.getMessage());
		}
	}
	
	
	public org.tiaa.esb.externalization_v2.types.response.Holiday[] getHolidays() throws Exception {
        org.tiaa.esb.externalization_v2.wsdl.ExternalizationServiceSoapHttpBindingStub binding;
        LOGGER.info("Externalization URL->" + externalizationURL);
        try {
        	URL extServiceUrl = new URL(externalizationURL);
            binding = (org.tiaa.esb.externalization_v2.wsdl.ExternalizationServiceSoapHttpBindingStub)
                          new org.tiaa.esb.externalization_v2.wsdl.ExternalizationV2ServiceLocator().getExternalizationV2(extServiceUrl);
        }
        catch (javax.xml.rpc.ServiceException jre) {
            throw jre;
        }

        
        org.tiaa.esb.externalization_v2.types.request.FetchSpecification fetchSpecification = new org.tiaa.esb.externalization_v2.types.request.FetchSpecification();
        fetchSpecification.setTable("Holiday");
        org.tiaa.esb.externalization_v2.types.request.FetchSpecification[] fs = new org.tiaa.esb.externalization_v2.types.request.FetchSpecification[1];
        fs[0] =fetchSpecification;

        org.tiaa.esb.externalization_v2.types.response.holders.HolidaysHolder holidaysHolder = new org.tiaa.esb.externalization_v2.types.response.holders.HolidaysHolder();
        
        
        binding.getObjectsWithFetchSpecification(fs, 
		new org.tiaa.esb.externalization_v2.types.response.holders.AccountInfosHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.AssetAllocModelsDataHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.AnnuityOptionsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.AssetChargesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.AssetChargeCalendarsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.AssetClassesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.BillingCalcMethodsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.BusinessUnitsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.CalculationMethodsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.CalendarDaysHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.CategoryClassesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.CompaniesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.CompanyFundsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.CountriesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.CurrenciesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.CycleCodesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.DeductionsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.DeferralDaysHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.DestinationsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.DownloadAcctTypesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.DownloadTransTypesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.ErrorCodesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.ExpenseChargesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.FundDataHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.FundDescriptionsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.FundFamiliesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.FundSizesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.FundStatusesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.FundStylesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.GuaranteedPeriodsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.HoldCodesHolder(), 
		holidaysHolder, 
		new org.tiaa.esb.externalization_v2.types.response.holders.HolidayDescriptionsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.InsurancePlanTypesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.IRACntrbLimitsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.IRADestinationsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.IRAPPGsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.IRCSectionsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.MasterRecordKeepersHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.ModelPortfoliosDataHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.PaymentModesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.PeopleSoftProductsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.PortfolioLookThroughsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.PrefixTitlesHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.ProductsHolder(), 
		new org.tiaa.esb.externalization_v2.types.response.holders.ProductLinesHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.RateDataHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.RelationshipsHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.RollOverTypesHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.RollOverValidationsHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.ServicesHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.ServiceTypesHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.SimulationHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.SourceDestinationsHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.StateReaDollarCapsHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.StatesHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.StateRestrictionsHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.SubAssetClassesHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.SuffixTitlesHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.SystemSourcesHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.TransactionsHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.TransactionCategoriesHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.CountryInfosHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.CompanyInfosHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.FundsInfosHolder(), new org.tiaa.esb.externalization_v2.types.response.holders.ErrorsHolder());
        
        return holidaysHolder.value;
        
    }
    
}
