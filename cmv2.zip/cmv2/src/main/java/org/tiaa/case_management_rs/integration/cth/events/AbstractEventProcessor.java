package org.tiaa.case_management_rs.integration.cth.events;

import java.io.StringWriter;
import java.util.List;

import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.esb.partyrequest.types.PartyRequestResponse;
import org.tiaa.esb.partyrequest.types.PartyRequestResponses;
import org.tiaa.esb.partyrequest.types.RetrieveRequestsResp;
import org.tiaa.esb.partyrequest.types.RetrieveRequestsResponse;

public class AbstractEventProcessor {
	private static final Logger LOG = LoggerFactory.getLogger(AbstractEventProcessor.class);
	@Autowired
	private Jaxb2Marshaller cthJaxb2Marshaller;

	public static String toString(Element node) {
		try {
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");
			transformer.setOutputProperty(OutputKeys.METHOD, "xml");
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			//
			StringWriter stringWriter = new StringWriter();
			transformer.transform(new DOMSource(node), new StreamResult(stringWriter));
			return stringWriter.toString();
		} catch (TransformerConfigurationException ex) {
			LOG.warn(ex.getMessage(), ex);
		} catch (TransformerException ex) {
			LOG.warn(ex.getMessage(), ex);
		}
		return "";
	}

	protected PartyRequestResponse getPartyRequestResponse(DOMSource domSource) {
		RetrieveRequestsResponse retrieveRequestsResponse = (RetrieveRequestsResponse) cthJaxb2Marshaller.unmarshal(domSource);
		RetrieveRequestsResp retrieveRequestsResp = retrieveRequestsResponse.getRetrieveRequestsResp();
		PartyRequestResponses partyRequestResponses = retrieveRequestsResp.getPartyRequestResponses();
		List<PartyRequestResponse> partyRequestResponseList = partyRequestResponses.getPartyRequestResponses();
		return partyRequestResponseList.get(0);
	}
}
