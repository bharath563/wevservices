package org.tiaa.case_management_rs.integration.case_manager.cth;

import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;
import org.tiaa.esb.partyrequest.types.UpdatePartyRequest;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;

public class UpdateCaseCTHContext extends AbstractCTHCaseContext {
	private CaseInfo caseInfo;
	private CaseDetails caseDetails;
	private UpdatePartyRequest updatePartyRequest;
	private String cthOrchestrationId;
	private String cthRequestId;

	private String clientId;
	private String caseId;

	public UpdateCaseCTHContext() {
		super();
	}

	public UpdateCaseCTHContext(CaseDetails caseDetails) {
		super();
		this.caseDetails = caseDetails;
	}

	public CaseDetails getCaseDetails() {
		return caseDetails;
	}

	public String getCaseId() {
		return caseId;
	}

	public CaseInfo getCaseInfo() {
		return caseInfo;
	}

	public String getClientId() {
		return clientId;
	}

	public String getCthOrchestrationId() {
		return cthOrchestrationId;
	}

	public String getCthRequestId() {
		return cthRequestId;
	}


	public UpdatePartyRequest getUpdatePartyRequest() {
		return updatePartyRequest;
	}

	public void setCaseDetails(CaseDetails caseDetails) {
		this.caseDetails = caseDetails;
	}

	public void setCaseInfo(CaseInfo caseInfo) {
		this.caseInfo = caseInfo;
	}

	public void setCthOrchestrationId(String cthOrchestrationId) {
		this.cthOrchestrationId = cthOrchestrationId;
	}

	public void setCthRequestId(long requestIdentifier) {
		this.cthRequestId = String.valueOf(requestIdentifier);
	}

	public void setCthRequestId(String cthRequestId) {
		this.cthRequestId = cthRequestId;
	}

	public void setUpdatePartyRequest(UpdatePartyRequest updatePartyRequest) {
		this.updatePartyRequest = updatePartyRequest;
	}

	@Override
	public String toString() {
		return "UpdateCaseCTHContext [caseInfo=" + caseInfo + ", caseDetails=" + caseDetails + ", updatePartyRequest=" + updatePartyRequest + ", cthOrchestrationId="
				+ cthOrchestrationId + ", cthRequestId=" + cthRequestId + ", clientId=" + clientId + ", caseId=" + caseId + "]";
	}
}
