package org.tiaa.case_management_rs.activiti.helper;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Component;

import org.tiaa.esb.case_management_rs_v2.type.ConfigData;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItem;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItems;
import org.tiaa.esb.case_management_rs_v2.type.SubField;
import org.tiaa.esb.case_management_rs_v2.type.SubFields;
import org.tiaa.esb.icm.types.Configuration;
import org.tiaa.esb.icm.types.Properties;

@Component
public class ActivitiConfigHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(ActivitiConfigHelper.class);

	public ConfigItems getSolutionHeadersfromActiviti(Configuration configuration) {
		ConfigItems configItems = new ConfigItems();
		if (configuration != null && configuration.getSolutionHeaders() != null
				&& !configuration.getSolutionHeaders().isEmpty()) {
			Map<String, List<Map<String, Properties>>> solutionHeaders = configuration.getSolutionHeaders();

			for (Map.Entry<String, List<Map<String, Properties>>> solutionSet : solutionHeaders.entrySet()) {
				try {
					String type = solutionSet.getKey();
					ConfigItem configItem = new ConfigItem();
					ConfigData configData = new ConfigData();
					for (Map<String, Properties> columnHeader : solutionHeaders.get(type)) {
						SubFields subFields = new SubFields();
						for (Entry<String, Properties> columnEntry : columnHeader.entrySet()) {
							SubField subField = new SubField();
							subField.setFieldName(columnEntry.getKey());
							subField.setFieldEntryType(columnHeader.get(columnEntry.getKey()).getType());
							subFields.getSubFields().add(subField);
						}
						configData.setSubFields(subFields);
					}
					configItem.setItemName(type);
					configItem.getDataPairs().add(configData);
					configItems.getConfigItems().add(configItem);
				} catch (Exception exception) {
					LOGGER.error("Get Solution Headers from Activiti -->" + exception.getMessage());
				}

			}
		}
		LOGGER.debug("Solution Headers--> " + configItems);
		return configItems;
	}
}
