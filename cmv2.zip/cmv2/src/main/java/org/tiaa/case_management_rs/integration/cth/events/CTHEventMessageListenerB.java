package org.tiaa.case_management_rs.integration.cth.events;

import org.springframework.jms.annotation.JmsListener;

public class CTHEventMessageListenerB extends AbstractMessageListener {
	@JmsListener(destination = "APPL.CTH.CMUDRS.INPUT", containerFactory = "jmsListenerContainerFactoryB")
	public void processEventMessage(String jmsMessage) {
		super.processEventMessage(jmsMessage);
	}
}