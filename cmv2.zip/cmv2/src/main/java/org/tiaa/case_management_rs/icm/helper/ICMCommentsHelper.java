package org.tiaa.case_management_rs.icm.helper;
 
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.integration.icm.ICMService;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.Comment;
import org.tiaa.esb.case_management_rs_v2.type.Comments;
import org.tiaa.esb.icm.types.Response;
 
@Component
public class ICMCommentsHelper {
    
    private static ObjectMapper objectMapper = new ObjectMapper();
        
	@Autowired
	private ICMService icmService;
 
    public Comments icmCommentsToComments(List<LinkedHashMap<String,Object>> icmCommentList) {
        
        Comments comments = new Comments();
        List<Comment> commentsList = comments.getComments();
        if(icmCommentList!= null && !icmCommentList.isEmpty()){
            for(LinkedHashMap<String,Object> map : icmCommentList){

            	try {
                    String icmResponseJSONString = this.objectMapper.writeValueAsString(map);
                    this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                    org.tiaa.esb.icm.types.Comment  icmComment = this.objectMapper.readValue(icmResponseJSONString, org.tiaa.esb.icm.types.Comment.class);
                    
                    Comment comment = new Comment();
                    
                    comment.setId(icmComment.getId());// TO DO : need to discuss and change the task id to comment id in rsv2 xsd or not
                    comment.setMessage(icmComment.getComment());
                    
                    comment.setType(icmComment.getType());
                    if(icmComment.getCreatedOn() != null){
                    	comment.setCreateDate(DateUtil.toXMLGregorianCalendar(DateUtil.parseDateTimeWithMilliseconds(icmComment.getCreatedOn())));
                    	comment.setCreateTime(DateUtil.toXMLGregorianCalendar(DateUtil.parseDateTimeWithMilliseconds(icmComment.getCreatedOn())));
                    }
 
                    comment.setCreateOper(icmComment.getCreatedBy());
                    comment.setDesc(icmComment.getDescription());
                    
                    commentsList.add(comment);
                    
                } catch (JsonParseException e) {
                    e.printStackTrace();
                } catch (JsonMappingException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
       
        return comments;
    }
    
    public boolean addComment(String userId,String caseId,Comment commentRequest){
    	boolean uploadStatus = false;
			org.tiaa.esb.icm.types.Comment icmCommentRequest = new org.tiaa.esb.icm.types.Comment();
			icmCommentRequest.setComment(commentRequest.getMessage());
			Response response = this.icmService.addComment(icmCommentRequest, caseId, userId);
			
			if(response.getErrorCode()==null){
				uploadStatus= true;
			}
	    return uploadStatus;
        
    }
        
}