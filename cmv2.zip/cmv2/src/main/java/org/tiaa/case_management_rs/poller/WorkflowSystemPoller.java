package org.tiaa.case_management_rs.poller;

import static org.apache.commons.io.FileUtils.*;
import static org.apache.commons.lang3.time.DateFormatUtils.*;
import static org.tiaa.case_management_rs.utils.CommonUtil.*;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.domain.CMSPollerLog;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.domain.WorkflowSystem;
import org.tiaa.case_management_rs.repository.CMSPollerLogRepository;

public abstract class WorkflowSystemPoller extends AbstractPoller {
	private WorkflowSystem workflowSystem;
	@Autowired
	protected CMSPollerLogRepository cmsPollerLogRepository;

	protected WorkflowSystemPoller(WorkflowSystem workflowSystem) {
		super();
		this.workflowSystem = workflowSystem;
	}

	protected CMSPollerLog getPollerLog() {
		CMSPollerLog pollerLog = cmsPollerLogRepository.findByWorkflowSystemAndHostNameAndNodeName(workflowSystem, getHostName(), getNodeName());
		if (pollerLog == null) {
			pollerLog = new CMSPollerLog();
			pollerLog.setHostName(getHostName());
			pollerLog.setNodeName(getNodeName());
			pollerLog.setWorkflowSystem(workflowSystem);
			pollerLog.setLastProcessedDateTime(pollerLog.getLastProcessedDateTime());
			pollerLog.setActive(true);
			return cmsPollerLogRepository.save(pollerLog);
		}
		return pollerLog;
	}

	protected void pollForInterval(final int second) {
		log.debug("start poll " + workflowSystem + " tables");
		CMSPollerLog pollerLog = getPollerLog();
		//
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.SECOND, second);
		calendar.set(Calendar.MILLISECOND, 0);
		Date lastProcessedAt = calendar.getTime();
		if (pollerLog.isActive()) {
			final String name = this.getClass().getName();
			if (componentSynchronizerService.checkOwner()) {
				statusLogger.debug("Running poller {} job with instance:{}", name, instance);
				execute(pollerLog);
			} else {
				statusLogger.debug("Not Running poller {} job with instance:{}", name, instance);
			}
		} else {
			log.warn("poller is not active");
			return;
		}
		pollerLog.setLastProcessedDateTime(lastProcessedAt);
		cmsPollerLogRepository.save(pollerLog);
		//
		log.debug("end poll " + workflowSystem + " tables");
	}

	protected abstract void execute(CMSPollerLog pollerLog);

	protected void write2File(Collection<TaskInfo> tasks) {
		for (TaskInfo taskInfo : tasks) {
			log.debug(taskInfo.toString());
		}
		try {
			String fileName = format(new Date(), "yyyy-MM-dd HH-mm-ss") + ".txt";
			writeLines(new File(fileName), tasks);
		} catch (IOException e) {
			log.warn(e.getMessage(), e);
		}
	}
}
