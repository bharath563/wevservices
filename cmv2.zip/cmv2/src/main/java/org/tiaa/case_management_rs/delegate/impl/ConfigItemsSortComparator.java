package org.tiaa.case_management_rs.delegate.impl;


import java.util.Comparator;

import org.tiaa.case_management_rs.constants.ConfigItemSortBy;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;


public class ConfigItemsSortComparator implements Comparator<ConfigData> {

	private String sortBy;
	public ConfigItemsSortComparator(String sortBy) {
		this.sortBy = sortBy;
	}

	@Override
	public int compare(ConfigData c1, ConfigData c2) {

		int compareReturn = 0;
		
		if (this.sortBy != null) {
			if (ConfigItemSortBy.SHORT.value().equals(this.sortBy)) {
				if ((c1.getShortDescription() != null) && (c2.getShortDescription() != null)) {
					compareReturn = c1.getShortDescription().toLowerCase().compareTo(c2.getShortDescription().toLowerCase());
				}
			} else if (ConfigItemSortBy.LONG.value().equals(this.sortBy)) {
				if ((c1.getLongDescription() != null) && (c2.getLongDescription() != null)) {
					compareReturn = c1.getLongDescription().toLowerCase().compareTo(c2.getLongDescription().toLowerCase());
				}
			}
		}
		return compareReturn;

	}
}