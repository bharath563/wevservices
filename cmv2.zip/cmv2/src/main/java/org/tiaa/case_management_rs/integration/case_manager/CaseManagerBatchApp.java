package org.tiaa.case_management_rs.integration.case_manager;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.log4j.MDC;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;
import org.tiaa.case_management_rs.resource.MediaTypes;

@Component
public class CaseManagerBatchApp {
	private static final Logger log = LoggerFactory.getLogger(CaseManagerBatchApp.class);
	@Autowired
	private CaseManagerDAO caseManagerDAO;
	@Autowired
	private CaseManagerCaseProcessor caseManagerCaseProcessor;
	private boolean processCase = true;
	private static final int CHUNK_SIZE = 100;
	private boolean batchRunning = false;
	private boolean batchProcessed = false;

	@GET
	@Produces({ MediaTypes.TEXT_HTML })
	public Response get() {
		return Response.ok(new StreamingOutputStream()).build();
	}

	public void execute() throws IOException {
		execute(new StreamingOutputStream(new OutputStreamWriter(System.out)));
	}

	public void execute(OutputStream outputStream) throws IOException {
		execute(new StreamingOutputStream(new OutputStreamWriter(outputStream)));
	}

	public synchronized void execute(StreamingOutputStream stream) throws IOException {
		Writer writer = stream.getWriter();
		try {
			if (batchProcessed) {
				stream.write("Batch already processed");
				return;
			}
			if (batchRunning) {
				stream.write("Batch already running");
				return;
			}
			batchRunning = true;
			executeBatch(stream);
			batchProcessed = true;
		} catch (Exception e) {
			StringWriter out = new StringWriter();
			PrintWriter s = new PrintWriter(out);
			e.printStackTrace(s);
			writer.write(out.toString());
			s.close();
		} finally {
			writer.flush();
			writer.close();
			batchRunning = false;
		}
	}

	private synchronized void executeBatch(StreamingOutputStream stream) {
		stream.write("Start CaseManager Batch Application");
		Map<String, String> phaseNameToPhaseDescriptionMap = caseManagerDAO.getPhaseNameToPhaseDescriptionMap();
		ArrayList<String> failedCasesIds = new ArrayList<String>();
		//
		List<String> caseIdsProcessed = caseManagerDAO.getCaseIdsProcessed();
		//
		List<String> allCaseIdList = caseManagerDAO.getAllCaseIdsInProgress();
		allCaseIdList.removeAll(caseIdsProcessed);
		//
		int size = allCaseIdList.size();
		int noOfChunks = size / CHUNK_SIZE;
		if (size % CHUNK_SIZE > 0) {
			noOfChunks++;
		}
		int fromIndex = 0;
		for (int ii = 0; ii < noOfChunks; ii++) {
			int chunkNo = ii + 1;
			stream.write("Processing chunk# %s", chunkNo);
			int toIndex = fromIndex + CHUNK_SIZE;
			if (toIndex > size) {
				toIndex = size;
			}
			stream.write("fromIndex: %s, toIndex: %s", fromIndex, toIndex);
			List<String> caseIds = allCaseIdList.subList(fromIndex, toIndex);
			stream.write("CaseIds %s", caseIds);
			List<CaseDetails> caseDetailList = caseManagerDAO.getCaseDetailList(caseIds, phaseNameToPhaseDescriptionMap);
			processRecords(stream, caseDetailList, failedCasesIds);
			fromIndex += CHUNK_SIZE;
		}
		printSummary(stream, failedCasesIds, allCaseIdList);
	}

	private void printSummary(StreamingOutputStream stream, List<String> failedCasesIds, List<String> allCaseIds) {
		int totalCount = allCaseIds.size();
		if (failedCasesIds.isEmpty()) {
			stream.write("all case ids processed successfully, total count: %s", totalCount);
		} else {
			int failedCount = failedCasesIds.size();
			stream.write("total count %s", totalCount);
			stream.write("successfully processed count %s", totalCount - failedCount);
			stream.write("failed count: %s", failedCount);
			stream.write("failed case ids: %s", failedCasesIds);
		}
		stream.write("End CaseManager Batch Application");
	}

	private void processRecords(StreamingOutputStream stream, List<CaseDetails> caseDetailList, List<String> failedCasesIds) {
		List<CaseDetails> caseInfoList = caseDetailList;
		stream.write("Processing: %s cases", caseInfoList.size());
		//
		for (CaseDetails caseInfo : caseInfoList) {
			MDC.put("X-INF-RequestID", caseInfo.getCaseId());
			stream.write("Processing Case: %s ", caseInfo.getCaseId());
			try {
				if (processCase) {
					caseManagerCaseProcessor.processCase(caseInfo);
				}
				stream.write("Case %s processed successfully", caseInfo.getCaseId());
			} catch (Exception e) {
				stream.write("Case %s processing failed", caseInfo.getCaseId());
				log.warn(e.getMessage(), e);
				failedCasesIds.add(caseInfo.getCaseId());
			} finally {
				MDC.remove("X-INF-RequestID");
			}
		}
	}

	private class StreamingOutputStream implements StreamingOutput {
		private Writer writer;

		public StreamingOutputStream() {
			super();
		}

		public StreamingOutputStream(Writer writer) {
			super();
			this.writer = writer;
		}

		@Override
		public void write(OutputStream os) throws IOException, WebApplicationException {
			writer = new OutputStreamWriter(os);
			try {
				execute(this);
			} catch (Exception e) {
				StringWriter out = new StringWriter();
				PrintWriter s = new PrintWriter(out);
				e.printStackTrace(s);
				write(out.toString());
				s.close();
			} finally {
				writer.flush();
				writer.close();
			}
		}

		public void write(String format, Object... args) {
			write(String.format(format, args));
		}

		public void write(String str) {
			log.info(str);
			try {
				writer.write(str + "\r\n<br/>");
				writer.flush();
			} catch (IOException e) {
				log.warn(e.getMessage(), e);
			}
		}

		public Writer getWriter() {
			return writer;
		}
	}
}
