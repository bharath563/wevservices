package org.tiaa.case_management_rs.common;

public class ConfigurationException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public ConfigurationException() {
		super();
	}

	public ConfigurationException(String message) {
		super(message);
	}

	public ConfigurationException(String message, Throwable exception) {
		super(message, exception);
	}

	public ConfigurationException(Throwable exception) {
		super(exception);
	}
}
