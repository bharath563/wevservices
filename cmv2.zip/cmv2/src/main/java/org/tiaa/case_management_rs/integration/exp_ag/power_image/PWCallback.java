package org.tiaa.case_management_rs.integration.exp_ag.power_image;

import static org.tiaa.case_management_rs.utils.CommonUtil.*;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.ws.security.WSPasswordCallback;

import org.tiaa.case_management_rs.common.ConfigurationException;
import org.tiaa.infra.security.axis.tools.SecretKeyLoader;

public class PWCallback implements CallbackHandler {
	private final String applicationId;

	public PWCallback(String applicationId) {
		this.applicationId = applicationId;
	}

	public void handle(Callback[] callbacks) throws UnsupportedCallbackException {
		Callback callback = getCallback(callbacks);
		if (callback == null) {
			throw new ConfigurationException("WSPasswordCallback not found");
		}
		WSPasswordCallback passwordCallback = (WSPasswordCallback) callback;
		String user = passwordCallback.getIdentifer();
		if (isNullOrEmpty(user)) {
			throw new ConfigurationException("Exception in PWCallback! getIdentifer retuned null or empty string for user.");
		}
		String password = SecretKeyLoader.getSecretKey(applicationId);
		if (isNullOrEmpty(password)) {
			throw new ConfigurationException("Exception in PWCallback! getSecretKey retuned null or empty string for password.");
		}
		passwordCallback.setPassword(password);
	}

	private static Callback getCallback(Callback[] callbacks) {
		for (int ii = 0; ii < callbacks.length; ii++) {
			Callback callback = callbacks[ii];
			if (callback instanceof WSPasswordCallback) {
				return callback;
			}
		}
		return null;
	}
}
