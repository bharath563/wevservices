package org.tiaa.case_management_rs.dao;

import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.case_management_rs.model.IdentifierInfo;
import org.tiaa.esb.powerimage.createtask.types.Identifier;
import org.tiaa.esb.powerimage.createtask.types.Identifier.Fieldinfo;

public class EXPAGIdentifierMapper extends AbstractRowMapper<IdentifierInfo> implements RowMapper<IdentifierInfo> {
	@Override
	public IdentifierInfo mapRow(ResultSet rs, int rowNum) throws SQLException {

		IdentifierInfo identifierInfo = new IdentifierInfo();

		Identifier identifier = new Identifier();

		identifier.setIddesc(getStringTrimmed(rs, "IDDESC"));
		identifier.setId(BigInteger.valueOf(1));

		Fieldinfo fieldInfo = new Fieldinfo();

		fieldInfo.setFldnbr(rs.getInt("FLDNBR"));

		String fieldDesc = getStringTrimmed(rs, "FLDDESC");

		fieldInfo.setFieldname(fieldDesc);
		identifier.getFieldinfos().add(fieldInfo);

		identifierInfo.setFieldName(fieldDesc);
		identifierInfo.setIdentifier(identifier);

		return identifierInfo;

	}
}
