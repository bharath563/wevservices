package org.tiaa.case_management_rs.syncup.service_request;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.Marshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.common.ExceptionHandler;
import org.tiaa.case_management_rs.integration.cth.CTHRecordCreator;
import org.tiaa.case_management_rs.integration.cth.CTHRecordRetriever;
import org.tiaa.case_management_rs.integration.cth.CTHRecordUpdater;
import org.tiaa.case_management_rs.integration.cth.CTHWsConfig;
import org.tiaa.case_management_rs.integration.cth.CreateHierarchyPartyRequestBuilder;
import org.tiaa.case_management_rs.integration.cth.CreateRequestsProcessor;
import org.tiaa.case_management_rs.integration.cth.RetrieveRequestsBuilder;
import org.tiaa.case_management_rs.integration.cth.RetryableCTHRecordCreator;
import org.tiaa.case_management_rs.integration.cth.RetryableCTHRecordUpdater;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTasksDAO;
import org.tiaa.case_management_rs.integration.plan_sponsor.PlanSponosrRSConfig;

@Configuration
public class ServiceRequestConfig {
	@Autowired
	private CTHWsConfig cthWsConfig;
	@Autowired
	private PlanSponosrRSConfig planSponosrRSConfig;

	@Bean
	public RetryableCTHRecordUpdater serviceRequestRetryableCTHRecordUpdater() {
		return new RetryableCTHRecordUpdater(cthWsConfig.cthWSRetryTemplate(), cthRecordUpdater());
	}

	@Bean
	public Jaxb2Marshaller serviceRequestJaxb2Marshaller() {
		Map<String, Object> marshallerProperties = new HashMap<String, Object>();
		marshallerProperties.put(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		//
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		jaxb2Marshaller.setClassesToBeBound(org.tiaa.esb.servicerequest.types.ObjectFactory.class);
		ExceptionHandler.initalize(jaxb2Marshaller);
		return jaxb2Marshaller;
	}

	@Bean
	public CTHRecordUpdater cthRecordUpdater() {
		CTHRecordUpdater cthUpdater = new CTHRecordUpdater();
		cthUpdater.setCthWebService(cthWsConfig.cthWebService());
		cthUpdater.setRetrieveRequestsResponseProcessor(serviceRequestCTHClobProcessor());
		cthUpdater.setCthRecordRetriever(cthRecordRetriever());
		return cthUpdater;
	}

	@Bean
	public CTHRecordRetriever cthRecordRetriever() {
		CTHRecordRetriever cthRecordRetriever = new CTHRecordRetriever(new RetrieveRequestsBuilder("ServiceRequest", "InstitutionalWorkflowRequest"));
		cthRecordRetriever.setCthWebService(cthWsConfig.cthWebService());
		return cthRecordRetriever;
	}

	@Bean
	public ServiceRequestProcessor serviceRequestCTHClobProcessor() {
		ServiceRequestProcessor serviceRequestProcessor = new ServiceRequestProcessor();
		serviceRequestProcessor.setServiceRequesJaxb2Marshaller(serviceRequestJaxbMarshaller());
		serviceRequestProcessor.setServicerequestWorkflowJaxb2Marshaller(cthWsConfig.serviceRequestWorkflowJaxb2Marshaller());
		serviceRequestProcessor.setContactResponseProcessor(planSponosrRSConfig.contactResponseProcessor());
		serviceRequestProcessor.setServiceRequestPayloadBuilder(serviceRequestPayloadBuilder());
		serviceRequestProcessor.setPayloadInfoBuilder(serviceRequestPayloadBuilder());
		return serviceRequestProcessor;
	}

	@Bean
	public ServiceRequesJaxbMarshaller serviceRequestJaxbMarshaller() {
		ServiceRequesJaxbMarshaller serviceRequesJaxbMarshaller = new ServiceRequesJaxbMarshaller();
		serviceRequesJaxbMarshaller.setServiceRequestJaxb2Marshaller(serviceRequestJaxb2Marshaller());
		serviceRequesJaxbMarshaller.setServiceRequestWorkflowJaxbMarshaller(cthWsConfig.serviceRequestWorkflowJaxbMarshaller());
		return serviceRequesJaxbMarshaller;
	}

	///
	@Bean
	public CreateRequestsProcessor serviceRequestCreateRequestsProcessor() {
		CreateRequestsProcessor createRequestsProcessor = new CreateRequestsProcessor();
		createRequestsProcessor.setCreateHierarchyPartyRequestBuilder(serviceRequestCreateHierarchyPartyRequestBuilder());
		createRequestsProcessor.setContactResponseProcessor(planSponosrRSConfig.contactResponseProcessor());
		return createRequestsProcessor;
	}

	@Bean
	public CreateHierarchyPartyRequestBuilder serviceRequestCreateHierarchyPartyRequestBuilder() {
		CreateHierarchyPartyRequestBuilder createHierarchyPartyRequestBuilder = new CreateHierarchyPartyRequestBuilder();
		createHierarchyPartyRequestBuilder.setCthRequestBuilder(serviceRequestPayloadBuilder());
		return createHierarchyPartyRequestBuilder;
	}

	@Bean
	public CTHRecordCreator serviceRequestCthRecordCreator() {
		CTHRecordCreator requestRouter = new CTHRecordCreator();
		requestRouter.setCreateRequestsProcessor(serviceRequestCreateRequestsProcessor());
		requestRouter.setCthWebService(cthWsConfig.cthWebService());
		return requestRouter;
	}

	@Bean
	public ServiceRequestPayloadBuilder serviceRequestPayloadBuilder() {
		ServiceRequestPayloadBuilder payloadInfoBuilder = new ServiceRequestPayloadBuilder("service-request-1-0-clob.xsd", "1.0");
		payloadInfoBuilder.setCthJaxb2WorkflowMarshaller(cthWsConfig.cthJaxb2Marshaller());
		payloadInfoBuilder.setServicerequestWorkflowJaxb2Marshaller(cthWsConfig.serviceRequestWorkflowJaxb2Marshaller());
		payloadInfoBuilder.setServiceRequestJaxb2Marshaller(serviceRequestJaxb2Marshaller());
		return payloadInfoBuilder;
	}

	@Bean
	public RetryableCTHRecordCreator serviceRequestRetryableCTHRecordCreator() {
		return new RetryableCTHRecordCreator(cthWsConfig.cthWSRetryTemplate(), serviceRequestCthRecordCreator());
	}

	@Bean
	public EXPAGTasksDAO serviceRequestEXPAGTasksDAO() {
		EXPAGTasksDAO expagTasksDAO = new EXPAGTasksDAO();
		expagTasksDAO.setQueryProvider(serviceRequestEXPAGTaskQueryProvider());
		return expagTasksDAO;
	}

	@Bean
	public ServiceRequestEXPAGTaskQueryProvider serviceRequestEXPAGTaskQueryProvider() {
		return new ServiceRequestEXPAGTaskQueryProvider();
	}
	
	public void setCthWsConfig(CTHWsConfig cthWsConfig) {
		this.cthWsConfig = cthWsConfig;
	}

	public void setPlanSponosrRSConfig(PlanSponosrRSConfig planSponosrRSConfig) {
		this.planSponosrRSConfig = planSponosrRSConfig;
	}
}
