package org.tiaa.case_management_rs.integration.exp_ag;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.domain.CMSTaskType;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.repository.CMSTaskTypeRepository;

@Component
public class EXPAGTaskProcessorSupport implements ApplicationContextAware {
	private ApplicationContext applicationContext;
	private Map<String, EXPAGTaskProcessor> expagTaskProcessorMapBySchemaName = new HashMap<String, EXPAGTaskProcessor>();
	private Map<String, EXPAGTasksQueryProvider> expagTasksQueryProviderMapBySchemaName = new HashMap<String, EXPAGTasksQueryProvider>();
	@Autowired
	private CMSTaskTypeRepository cmsTaskTypeRepository;
	@Autowired
	private EXPAGTasksDAO serviceRequestEXPAGTasksDAO;
	@Autowired
	private EXPAGTasksDAO customerWebFormEXPAGTasksDAO;

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	@PostConstruct
	public void init() {
		for (EXPAGTaskProcessor expagTaskProcessor : applicationContext.getBeansOfType(EXPAGTaskProcessor.class).values()) {
			EXPAGTaskType annotation = expagTaskProcessor.getClass().getAnnotation(EXPAGTaskType.class);
			if (annotation != null) {
				expagTaskProcessorMapBySchemaName.put(annotation.schemaName(), expagTaskProcessor);
			}
		}
		for (EXPAGTasksQueryProvider expagTasksQueryProvider : applicationContext.getBeansOfType(EXPAGTasksQueryProvider.class).values()) {
			EXPAGTaskType annotation = expagTasksQueryProvider.getClass().getAnnotation(EXPAGTaskType.class);
			if (annotation != null) {
				expagTasksQueryProviderMapBySchemaName.put(annotation.schemaName(), expagTasksQueryProvider);
			}
		}
	}

	public EXPAGTasksQueryProvider getEXPAGTasksQueryProvider(TaskInfo taskInfo) {
		CMSTaskType cmsTaskType = cmsTaskTypeRepository.findByTaskType(taskInfo.getTaskType());
		return getEXPAGTasksQueryProvider(cmsTaskType.getCthRequestSchemaName());
	}

	public EXPAGTasksQueryProvider getEXPAGTasksQueryProvider(String cthRequestSchemaName) {
		if (cthRequestSchemaName == null) {
			return null;
		}
		cthRequestSchemaName = cthRequestSchemaName.trim();
		return expagTasksQueryProviderMapBySchemaName.get(cthRequestSchemaName);
	}

	public EXPAGTaskProcessor getEXPAGTaskProcessor(String taskType) {
		CMSTaskType cmsTaskType = cmsTaskTypeRepository.findByTaskType(taskType);
		return getEXPAGTaskProcessor(cmsTaskType);
	}

	public EXPAGTaskProcessor getEXPAGTaskProcessor(TaskInfo taskInfo) {
		CMSTaskType cmsTaskType = cmsTaskTypeRepository.findByTaskType(taskInfo.getTaskType());
		return getEXPAGTaskProcessor(cmsTaskType);
	}

	public EXPAGTaskProcessor getEXPAGTaskProcessor(CMSTaskType cmsTaskType) {
		return expagTaskProcessorMapBySchemaName.get(cmsTaskType.getCthRequestSchemaName());
	}

	public Map<String, EXPAGTaskProcessor> getExpagTaskProcessorMapBySchemaName() {
		return expagTaskProcessorMapBySchemaName;
	}

	public Map<String, EXPAGTasksQueryProvider> getExpagTasksQueryProviderMapBySchemaName() {
		return expagTasksQueryProviderMapBySchemaName;
	}

	public EXPAGTasksDAO getExpagTasksDAO(CMSTaskType cmsTaskType) {
		String cthRequestSchemaName = cmsTaskType.getCthRequestSchemaName();
		return "service-request-1-0-clob.xsd".equals(cthRequestSchemaName)? serviceRequestEXPAGTasksDAO : customerWebFormEXPAGTasksDAO;
	}
}
