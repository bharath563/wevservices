package org.tiaa.case_management_rs.integration.cth.events;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import org.tiaa.case_management_rs.common.LoggingResponseErrorHandler;
import org.tiaa.case_management_rs.email.EmailSender;
import org.tiaa.case_management_rs.email.EmailUtil;
import org.tiaa.case_management_rs.integration.cth.CTHPayloadJaxbMarshaller;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTaskType;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.PowerImageService;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.WorkflowException;
import org.tiaa.cth.event.EventClient;
import org.tiaa.cth.event.EventProcessor;
import org.tiaa.cth.event.model.Event;
import org.tiaa.cth.event.model.EventDefinition;
import org.tiaa.cth.event.model.EventPayLoadIncludes;
import org.tiaa.cth.event.model.EventPayloadIndicators;
import org.tiaa.cth.event.model.HTTPEventNotificationMethod;
import org.tiaa.cth.event.model.Subscription;
import org.tiaa.cth.event.model.SubscriptionRequest;

import org.tiaa.atom.core.support.rest.DefaultRestServiceESBSupport;
import org.tiaa.atom.core.support.rest.RestServiceESBSupport;

public class CTHEventConsumer implements EventProcessor, ApplicationContextAware {
	private static final Logger LOG = LoggerFactory.getLogger(CTHEventConsumer.class);
	private Map<String, CTHPayloadJaxbMarshaller> cthPayloadJaxb2MarshallerMapByRequestType = new HashMap<String, CTHPayloadJaxbMarshaller>();
	private ApplicationContext applicationContext;
	@Autowired
	private PowerImageService powerImageService;
	@Autowired
	private EmailSender emailSender;
	@Autowired
	private EventClient eventClient;
	@Autowired
	@Qualifier(RestServiceESBSupport.BEAN_NAME)
	private RestServiceESBSupport client;
	private boolean initialized = false;
	private String subscriptionId;
	private boolean localTesting = false;
	private String processType = "InstitutionalWorkflowRequest";

	@Value("${ctheventservice.callback.url}")
	private String callbackUrl;

	@Value("${ctheventservice.events.url}")
	private String eventCallbackUrl;
	private boolean subscribeToCTH = false;
	private boolean planSponsor;

	@PostConstruct
	public void init() {
		for (CTHPayloadJaxbMarshaller cthPayloadJaxbMarshaller : applicationContext.getBeansOfType(CTHPayloadJaxbMarshaller.class).values()) {
			EXPAGTaskType annotation = cthPayloadJaxbMarshaller.getClass().getAnnotation(EXPAGTaskType.class);
			cthPayloadJaxb2MarshallerMapByRequestType.put(annotation.requestType(), cthPayloadJaxbMarshaller);
		}
		if (initialized) {
			return;
		}
		DefaultRestServiceESBSupport defaultRestServiceESBSupport = (DefaultRestServiceESBSupport) client;
		defaultRestServiceESBSupport.setErrorHandler(new LoggingResponseErrorHandler());
		try {
			subscribe();
			initialized = true;
		} catch (HttpClientErrorException e) {
			LOG.warn(e.getResponseBodyAsString());
			LOG.warn(e.getMessage(), e);
		} catch (HttpServerErrorException e) {
			LOG.warn(e.getResponseBodyAsString());
			LOG.warn(e.getMessage(), e);
		}
	}

	@PreDestroy
	public void destroy() {
		LOG.info("unsubscribe subscriptionId:{}", subscriptionId);
		if (subscriptionId != null) {
			eventClient.unsubscribe(subscriptionId);
		}
	}

	@Override
	public void processEvent(Event event) {
		LOG.debug("event:{}", event);
		Element payload = event.getPayload();
		LOG.debug("payload:{}", payload);
		CTHPayloadJaxbMarshaller serviceRequesJaxb2Marshaller = cthPayloadJaxb2MarshallerMapByRequestType.get(event.getRequestType());
		String taskId = serviceRequesJaxb2Marshaller.getTaskId(payload);
		if (powerImageService != null) {
			try {
				powerImageService.cancelTask(taskId);
			} catch (WorkflowException e) {
				LOG.warn(e.getMessage(), e);
				emailSender.sendEmailToProdSupport("Error while updating CTH for Orchestration Id:" + event.getOrchestrationId(), EmailUtil.createEmail(e));
			}
		}
	}

	@Override
	public void confirmDelivery(String eventBroadcastId, String subscriptionIdValue) {
		LOG.debug("eventBroadcastId:{}", eventBroadcastId);
		LOG.debug("subscriptionId:{}", subscriptionIdValue);
	}
	
	private void subscribe() {
		if (subscribeToCTH) {
			subscribeToCTH();
		}
		raiseEvent();
	}

	private void subscribeToCTH() {
		List<SubscriptionRequest> subscriptionRequestPayload = createSubscriptionRequestPayload();
		List<Subscription> subscriptions = eventClient.subscribe(subscriptionRequestPayload);
		for (Subscription subscription : subscriptions) {
			subscriptionId = subscription.getSubscriptionId();
			LOG.debug(ReflectionToStringBuilder.toString(subscription, ToStringStyle.MULTI_LINE_STYLE));
		}
	}

	private List<SubscriptionRequest> createSubscriptionRequestPayload() {
		//
		SubscriptionRequest subscriptionRequest = new SubscriptionRequest();
		subscriptionRequest.setProcessType(processType);
		subscriptionRequest.setEventProducer("EX-PAG");
		subscriptionRequest.setEventNames(createEventDefinitions());
		//
		HTTPEventNotificationMethod method = new HTTPEventNotificationMethod();
		method.setCallbackUrl(callbackUrl);
		subscriptionRequest.setMethod(method);
		//
		ArrayList<SubscriptionRequest> subscriptionRequests = new ArrayList<SubscriptionRequest>();
		subscriptionRequests.add(subscriptionRequest);
		return subscriptionRequests;
	}

	private List<EventDefinition> createEventDefinitions() {
		ArrayList<EventDefinition> eventDefinitions = new ArrayList<EventDefinition>();
		EventPayLoadIncludes eventPayLoadIncludes = createEventPayLoadIncludes();
		addEventDefinitions("EX-PAG", eventDefinitions, eventPayLoadIncludes);
		if (planSponsor) {
			addEventDefinitions("PSSTrans", eventDefinitions, eventPayLoadIncludes);
		}
		return eventDefinitions;
	}

	private void addEventDefinitions(String eventProducer, List<EventDefinition> eventDefinitions, EventPayLoadIncludes eventPayLoadIncludes) {
		if (localTesting) {
			EventDefinition eventDefinition = new EventDefinition();
			eventDefinition.setEventName("CREATE_REQUEST");
			eventDefinition.setEventProducer(eventProducer);
			eventDefinition.setDoBroadcast(false);
			//
			eventDefinition.setEventPayLoadIncludes(eventPayLoadIncludes);
			eventDefinitions.add(eventDefinition);
		}
		{
			EventDefinition eventDefinition = new EventDefinition();
			eventDefinition.setEventName("UPDATE_REQUEST");
			eventDefinition.setEventProducer(eventProducer);
			eventDefinition.setDoBroadcast(false);
			//
			eventDefinition.setEventPayLoadIncludes(eventPayLoadIncludes);
			eventDefinitions.add(eventDefinition);
		}
	}

	private EventPayLoadIncludes createEventPayLoadIncludes() {
		EventPayloadIndicators payloadIndicators = new EventPayloadIndicators();
		payloadIndicators.setIncludeMetadata(true);
		payloadIndicators.setIncludePayload(true);
		payloadIndicators.setIncludePartyIdentifiers(true);
		payloadIndicators.setIncludeAdditionalIdentifiers(true);
		payloadIndicators.setIncludeFinalStatusIndicator(true);
		//
		EventPayLoadIncludes eventPayLoadIncludes = new EventPayLoadIncludes();
		eventPayLoadIncludes.setPayloadIndicators(payloadIndicators);
		return eventPayLoadIncludes;
	}

	private void raiseEvent() {
		if (localTesting) {
			Event event = new Event();
			event.setEventName("UPDATE_REQUEST");
			event.setEventProducer("CTHPowerManager");
			event.setOrchestrationId("C14LE2SA7");
			event.setProcessType(processType);
			event.setRequestType("ServiceRequest");
			//
			HTTPEventNotificationMethod httpEventNotificationMethod = new HTTPEventNotificationMethod();
			httpEventNotificationMethod.setCallbackUrl(eventCallbackUrl);
			eventClient.raiseEvent(event, httpEventNotificationMethod);
		}
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

}
