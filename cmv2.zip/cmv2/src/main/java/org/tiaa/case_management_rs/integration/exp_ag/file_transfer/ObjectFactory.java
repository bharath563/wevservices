
package org.tiaa.case_management_rs.integration.exp_ag.file_transfer;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the org.tiaa_cref.filetransferwebservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: org.tiaa_cref.filetransferwebservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link MoveFile }
     * 
     */
    public MoveFile createMoveFile() {
        return new MoveFile();
    }

    /**
     * Create an instance of {@link ReplaceFileContent }
     * 
     */
    public ReplaceFileContent createReplaceFileContent() {
        return new ReplaceFileContent();
    }

    /**
     * Create an instance of {@link AppendToTempFileResponse }
     * 
     */
    public AppendToTempFileResponse createAppendToTempFileResponse() {
        return new AppendToTempFileResponse();
    }

    /**
     * Create an instance of {@link AppendToTempFile }
     * 
     */
    public AppendToTempFile createAppendToTempFile() {
        return new AppendToTempFile();
    }

    /**
     * Create an instance of {@link MoveFileResponse }
     * 
     */
    public MoveFileResponse createMoveFileResponse() {
        return new MoveFileResponse();
    }

    /**
     * Create an instance of {@link ReplaceFileContentResponse }
     * 
     */
    public ReplaceFileContentResponse createReplaceFileContentResponse() {
        return new ReplaceFileContentResponse();
    }

}
