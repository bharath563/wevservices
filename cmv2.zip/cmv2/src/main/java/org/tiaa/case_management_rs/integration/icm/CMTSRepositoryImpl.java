package org.tiaa.case_management_rs.integration.icm;

import java.util.Arrays;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import org.tiaa.case_management_rs.delegate.TaskSearchDelegate;
import org.tiaa.esb.icm.types.ResponseList;
import org.tiaa.esb.icm.types.TaskSearch;

@Repository(value = "cmtsRespositoryImpl")
public class CMTSRepositoryImpl implements TaskSearchDelegate {

	private HttpHeaders headers = new HttpHeaders();
	private HttpEntity<String> entity = null;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private CMTSRepositoryLinkHelper cmtsRepositoryLinkHelper;
	private static final Logger LOGGER = LoggerFactory
			.getLogger(CMTSRepositoryImpl.class);

	@PostConstruct
	private void beanPostProcess() {
		if (this.restTemplate != null) {
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		}
	}

	@Override
	public ResponseList searchNigoTasks(TaskSearch taskSearchRequest, String userId) {

		HttpEntity<TaskSearch> searchEntity = new HttpEntity<TaskSearch>(
				taskSearchRequest, headers);

		ResponseList response = new ResponseList();
		try {
		 response = this.restTemplate.postForObject(
				cmtsRepositoryLinkHelper.getNigoTaskSearchURL(), searchEntity,
				ResponseList.class);
		} catch (Exception e){
			LOGGER.error("CMTSRSV1 tasksearch error message=" + e.getMessage());
		}
		
		return response;
	}

}

