package org.tiaa.case_management_rs.integration.cth;

public class CTHCreateRecordFailedException extends RuntimeException {

	public CTHCreateRecordFailedException() {
		super();
	}

	public CTHCreateRecordFailedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public CTHCreateRecordFailedException(String message, Throwable cause) {
		super(message, cause);
	}

	public CTHCreateRecordFailedException(String message) {
		super(message);
	}

	public CTHCreateRecordFailedException(Throwable cause) {
		super(cause);
	}

}
