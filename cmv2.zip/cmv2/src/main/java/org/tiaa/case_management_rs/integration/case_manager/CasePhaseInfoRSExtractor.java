package org.tiaa.case_management_rs.integration.case_manager;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import org.tiaa.case_management_rs.integration.case_manager.domain.Case;
import org.tiaa.case_management_rs.integration.case_manager.domain.CaseStatus;
import org.tiaa.case_management_rs.integration.case_manager.domain.Phase;
import org.tiaa.case_management_rs.integration.case_manager.domain.Phases;

public class CasePhaseInfoRSExtractor extends CaseMapper implements ResultSetExtractor<Map<String, Case>> {
	private static final Logger LOG = LoggerFactory.getLogger(CasePhaseInfoRSExtractor.class);
	private boolean printDuplcatePhase = false;
	
	@Override
	public Map<String, Case> extractData(ResultSet resultSet) throws SQLException, DataAccessException {
		Map<String, Case> caseMap = new HashMap<String, Case>();
		while (resultSet.next()) {
			String caseId = getStringTrimmed(resultSet, "case_id");
			if (!caseMap.containsKey(caseId)) {
				caseMap.put(caseId, mapCase(resultSet));
			}
			Case kase = caseMap.get(caseId);
			kase.addCaseStatus(new CaseStatus(getStringTrimmed(resultSet, "status_name"), resultSet.getTimestamp("status_updated_ts")));
			updatePhaseInfo(resultSet, kase);
		}
		// loop through cases
		caseMap = groupPhaseByStartAndCompletionTime(caseMap);
		updatePhaseCompletedAndTargetDate(caseMap);
		return caseMap;
	}

	private Map<String, Case> groupPhaseByStartAndCompletionTime(Map<String, Case> caseMap) {
		for (Case kase : caseMap.values()) {
			Map<String, Phase> phaseMap = new LinkedHashMap<String, Phase>();
			Phases phases = kase.getPhases();
			for (Phase phase : phases.getPhases()) {
				String phaseNameStartDateTime = new StringBuilder(phase.getName()).append(phase.getStartDateTime()).toString();
				if (!phaseMap.containsKey(phaseNameStartDateTime)) {
					phaseMap.put(phaseNameStartDateTime, phase);
				} else {
					if (printDuplcatePhase) {
						LOG.warn("duplicate phase found:" + phase);
					}
				}
			}
			phases.setPhases(new ArrayList<Phase>(phaseMap.values()));
		}
		return caseMap;
	}

	private void updatePhaseInfo(ResultSet resultSet, Case kase) throws SQLException {
		Phase phase = mapPhaseInfo(resultSet);
		if (phase != null) {
			kase.addPhase(phase);
		} else {
			String identifierName = getStringTrimmed(resultSet, "identifier_name");
			String identifierValue = resultSet.getString("identifier_value");
			if (isPhase1to6(identifierName)) {
				String phaseName = identifierName.substring(0, identifierName.indexOf(" Date"));
				kase.getPhaseTargetDateMap().put(phaseName, identifierValue);
			} else if ("Impl. Date".equalsIgnoreCase(identifierName)) {
				kase.setTargetImplDate(resultSet.getString("identifier_value"));
			} else if ("Assigned Transition Manager".equals(identifierName)) {
				kase.setTransitionManager(identifierValue);
			} else if ("RM".equals(identifierName)) {
				kase.setRelationshipManager(identifierValue);
			} else if ("Request Type".equals(identifierName)) {
				kase.setRequestType(identifierValue);
			}  else if ("Case Name".equals(identifierName)) {
				kase.setCaseName(identifierValue);
			} else if ("Client ID".equals(identifierName)) {
				kase.setClientId(identifierValue);
			} else {
				LOG.debug("identifierName:" + identifierName);
				LOG.debug("identifierValue:" + identifierValue);
			}
		}
	}

	private void updatePhaseCompletedAndTargetDate(Map<String, Case> caseMap) {
		for (Case casesDetails : caseMap.values()) {
			Phases phases2 = casesDetails.getPhases();
			List<Phase> phases = phases2.getPhases();
			Map<String, String> phaseTargetDateMap = casesDetails.getPhaseTargetDateMap();
			for (int index = 0; index < phases.size(); index++) {
				if (index > 0) {
					Phase previousPhase = phases.get(index - 1);
					Phase currentPhase = phases.get(index);
					previousPhase.setCompletedTS(currentPhase.getStartedTS());
					//
					String phaseValue = currentPhase.getName();
					if (phaseTargetDateMap.containsKey(phaseValue)) {
						String targetComplDate = phaseTargetDateMap.get(phaseValue);
						currentPhase.setTargetCompletionTS(targetComplDate);
					}
				}
			}
			addPhasesWithonlyTargetDate(phases, phaseTargetDateMap);
			phases2.getCurrentPhase();//trigger sorting
		}
	}

	private void addPhasesWithonlyTargetDate(List<Phase> phases, Map<String, String> phaseTargetDateMap) {
		HashMap<String, Phase> phasesByName = new HashMap<String, Phase>();
		for (Phase phase : phases) {
			phasesByName.put(phase.getName(), phase);
		}
		Set<Entry<String, String>> entrySet = phaseTargetDateMap.entrySet();
		for (Entry<String, String> entry : entrySet) {
			String phaseName = entry.getKey();
			if (!phasesByName.containsKey(phaseName)) {
				String targetComplDate = entry.getValue();
				Phase phase = new Phase();
				phase.setName(phaseName);
				phase.setTargetCompletionTS(targetComplDate);
				phases.add(phase);
			}
		}
	}

	private Phase mapPhaseInfo(ResultSet rs) throws SQLException {
		String identifierName = getStringTrimmed(rs, "identifier_name");
		if ("Phase".equalsIgnoreCase(identifierName)) {
			Phase phase = new Phase();
			phase.setName(getStringTrimmed(rs, "identifier_value"));
			phase.setStartedTS(rs.getTimestamp("identifier_updated_ts"));
			return phase;
		}
		return null;
	}

	private boolean isPhase1to6(String identifierName) {
		return "Phase 1 Date".equalsIgnoreCase(identifierName) || // 
				"Phase 2 Date".equalsIgnoreCase(identifierName) || //
				"Phase 3 Date".equalsIgnoreCase(identifierName) || //
				"Phase 4 Date".equalsIgnoreCase(identifierName) || //
				"Phase 5 Date".equalsIgnoreCase(identifierName) || //
				"Phase 6 Date".equalsIgnoreCase(identifierName);
	}
}
