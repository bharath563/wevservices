package org.tiaa.case_management_rs.integration.exp_ag;

import java.util.HashMap;
import java.util.Map;

import org.tiaa.esb.servicerequest_workflow.types.DocumentType;

public class EXPAGDocument extends DocumentType {
	private static final long serialVersionUID = -4579689219274905504L;
	private Map<String, Object> identifiers = new HashMap<String, Object>();
	private String taskId;
	private String taskType;
	private String createOperator;
	private int startDate;
	private int startTime;

	public void addIdentifier(String key, String value) {
		identifiers.put(key, value);
	}

	public void addIdentifiersFrom(EXPAGDocument expagDocument) {
		if (this == expagDocument) {
			return;
		}
		identifiers.putAll(expagDocument.identifiers);
	}

	public String getCreateOperator() {
		return createOperator;
	}

	public String getDocumentId() {
		return getDocumentIDs().getDocumentIDs().get(0).getValue();
	}

	public Map<String, Object> getIdentifiers() {
		return identifiers;
	}

	public String getIdentifierStringValue(String string) {
		Object object = identifiers.get(string);
		return object == null ? "" : object.toString();
	}

	public String getTaskId() {
		return taskId;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setCreateOperator(String createOperator) {
		this.createOperator = createOperator;
	}

	public void setIdentifiers(Map<String, Object> identifiers) {
		this.identifiers = identifiers;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public int getStartDate() {
		return startDate;
	}

	public void setStartDate(int startDate) {
		this.startDate = startDate;
	}

	public int getStartTime() {
		return startTime;
	}

	public void setStartTime(int startTime) {
		this.startTime = startTime;
	}

	@Override
	public String toString() {
		return "EXPAGDocument [identifiers=" + identifiers + ", taskId=" + taskId + ", taskType=" + taskType + ", createOperator=" + createOperator + ", startDate=" + startDate
				+ ", startTime=" + startTime + "]";
	}

}
