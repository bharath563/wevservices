package org.tiaa.case_management_rs.common;

public final class ThreadLocalCustomerNumber {
	private static final ThreadLocal<String> THREAD_LOCAL = new ThreadLocal<String>() {
		protected String initialValue() {
			return AppConstants.USER_REF;
		};
	};

	public static String get() {
		return THREAD_LOCAL.get();
	}

	public static void set(String customerNumber) {
		THREAD_LOCAL.set(customerNumber);
	}

	public static void remove() {
		THREAD_LOCAL.remove();
	}

	private ThreadLocalCustomerNumber() {
	}
}
