package org.tiaa.case_management_rs.syncup.customer_webform;

import javax.xml.transform.dom.DOMSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.case_management_rs.integration.cth.RetrieveRequestsResponseProcessor;
import org.tiaa.case_management_rs.integration.cth.UpdateCTHContext;
import org.tiaa.esb.customer_webform.types.CTHClob;
import org.tiaa.esb.customer_webform.types.OtherData;
import org.tiaa.esb.partyrequest.types.RequestInfo;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;

public class CustomerWebFormProcessor extends RetrieveRequestsResponseProcessor {
	private static final Logger LOG = LoggerFactory.getLogger(CustomerWebFormProcessor.class);
	private CustomerWebFormJaxbMarshaller customerWebFormJaxb2Marshaller;

	protected boolean updateClob(UpdateCTHContext context, String status) {
		LOG.info("CustomerWebFormProcessor updateClob");
		RequestInfo requestInfo = getRequestInfo(context);
		DOMSource domSource = getDomSource(requestInfo);
		CTHClob cthClob = customerWebFormJaxb2Marshaller.getCTHClob(domSource);
		OtherData otherData = customerWebFormJaxb2Marshaller.createOrGetOtherData(cthClob);
		CaseInfo caseInfo = customerWebFormJaxb2Marshaller.getCaseInfo(otherData);
		if (caseInfo == null) {
			caseInfo = payloadInfoBuilder.mapCaseInfo(context);
		}
		context.setCaseInfo(caseInfo);
		boolean updateCTH = updateCTH(context, status);
		//update WorkflowXml with CaseInfo
		otherData.getWebform().getWorkFlowXML().setAny(toElement(caseInfo));
		//update CTH CLOB
		requestInfo.setAny(toElement(cthClob, customerWebFormJaxb2Marshaller.getCustomerWebFormJaxb2Marshaller()));
		return updateCTH;
	}

	public void setCustomerWebFormJaxb2Marshaller(CustomerWebFormJaxbMarshaller customerWebFormJaxb2Marshaller) {
		this.customerWebFormJaxb2Marshaller = customerWebFormJaxb2Marshaller;
	}
}
