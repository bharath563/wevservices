package org.tiaa.case_management_rs.validator.impl;

import org.apache.commons.lang3.StringUtils;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.esb.case_management_rs_v2.type.Documents;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.ProcessesRequest;

/**
 * @author pamdama
 * This is a validator class for ProcessCreation along with document upload
 *
 */
public class CreateProcessesValidator extends BaseValidatorImpl {

	@Override
	public void doValidate(Request request) {

		String userid = (String) request.getAttribute(USER_ID);
		String appname = (String) request.getAttribute(APP_NAME);
	
		if (StringUtils.isBlank(userid)) {
			handleException(VALIDATION_USERID_IS_EMPTY);
		}
		
		if (StringUtils.isBlank(appname)) {
			handleException(VALIDATION_APPNAME_IS_EMPTY);
		}
		
		ProcessesRequest processesRequest = (ProcessesRequest) request.getAttribute(PROCESSES_REQUEST);
		Process process = processesRequest.getProcesses().getProcesses().get(0);
		Documents docs = process.getDocuments();
		
		if(docs != null){
			//doc content
			for( org.tiaa.esb.case_management_rs_v2.type.Document  document:docs.getDocuments()){
				if(document.getDocContent()==null){
					handleException(VALIDATION_DOC_CONTENT_IS_NULL);
				}
			}
		}
		
		
	}

}
