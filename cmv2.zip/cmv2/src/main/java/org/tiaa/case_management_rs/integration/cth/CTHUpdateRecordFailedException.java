package org.tiaa.case_management_rs.integration.cth;

public class CTHUpdateRecordFailedException extends RuntimeException {

	public CTHUpdateRecordFailedException() {
		super();
	}

	public CTHUpdateRecordFailedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public CTHUpdateRecordFailedException(String message, Throwable cause) {
		super(message, cause);
	}

	public CTHUpdateRecordFailedException(String message) {
		super(message);
	}

	public CTHUpdateRecordFailedException(Throwable cause) {
		super(cause);
	}

}
