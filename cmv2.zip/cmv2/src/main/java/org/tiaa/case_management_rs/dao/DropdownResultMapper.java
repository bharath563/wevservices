package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;

public class DropdownResultMapper extends AbstractRowMapper<ConfigData> implements RowMapper<ConfigData> {

	@Override
	public ConfigData mapRow(ResultSet rs, int rowNum) throws SQLException {

		ConfigData dropDown = new ConfigData();

		dropDown.setShortDescription(getStringTrimmed(rs, "ShortDescription"));
		dropDown.setLongDescription(getStringTrimmed(rs, "LongDescription"));

		return dropDown;
	}

}
