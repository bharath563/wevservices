package org.tiaa.case_management_rs.resource;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.container.ResourceContext;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.common.impl.RequestImpl;
import org.tiaa.case_management_rs.service.CaseManagementRestService;
import org.tiaa.esb.case_management_rs_v2.type.TaskRequest;

public class TaskResource {
	@Autowired
	private CaseManagementRestService caseManagmentRestService;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(TaskResource.class);

	@Context
	private ResourceContext resourceContext;

//	@PUT
//	@Produces({ MediaTypes.V2_XML, MediaTypes.V2_JSON })
//	@Consumes({ MediaTypes.V2_XML, MediaTypes.V2_JSON })
//	public String suspendTask(@QueryParam("userid") String userId,
//			@PathParam("processid") String processId,
//			ProcessRequest processRequest) {
//		LOGGER.debug("ProcessId : " + processId + " Userid : " + userId);
//		return "ProcessId : " + processId + " Userid : " + userId;
//	}

	@PUT
	@Produces({ MediaTypes.V2_XML, MediaTypes.V2_JSON })
	@Consumes({ MediaTypes.V2_XML, MediaTypes.V2_JSON })
	public Response updateTask(@PathParam("taskid") String taskId,@PathParam(PROCESS_ID) String processId,
			@QueryParam("userid") String userId,
			@QueryParam("appname") String appName,
			 TaskRequest taskRequest) {
		org.tiaa.case_management_rs.common.Request request = new RequestImpl();
		request.setAttribute(WOB_ID, taskId);
		request.setAttribute(APP_NAME, appName);
		request.setAttribute(USER_ID, userId);
		request.setAttribute(TASK_REQUEST, taskRequest);
		request.setAttribute(PROCESS_ID,processId);

		Response response = this.caseManagmentRestService.updateTask(request);
		return response;

	}

//	@Path("/tasks")
//	public TaskResource taskSubResourceSteps() {
//		return this.resourceContext.getResource(TaskResource.class);
//	}

	/*
	 * @PUT
	 * 
	 * @Produces({ MediaTypes.V2_XML, MediaTypes.V2_JSON })
	 * 
	 * @Consumes({ MediaTypes.V2_XML, MediaTypes.V2_JSON }) public String
	 * unsuspendTask(@QueryParam("userid") String userId,
	 * 
	 * @PathParam("processid") String processId, ProcessRequest processRequest)
	 * { LOGGER.debug("ProcessId : " + processId + " Userid : " + userId);
	 * return "ProcessId : " + processId + " Userid : " + userId; }
	 */

	@GET
	@Path("/comments")
	@Produces({ MediaTypes.V2_XML, MediaTypes.V2_JSON })
	public Response getTaskComments(@QueryParam(USER_ID) String userId,
			@PathParam(PROCESS_ID) String processId,
			@PathParam(TASK_ID) String taskId,
			@QueryParam(APP_NAME) String appName) {

		LOGGER.debug("Entering TaskComments");
		LOGGER.debug("Request Params");
		LOGGER.debug(USER_ID + SPACE_HYPEN_SAPCE + userId);
		LOGGER.debug(PROCESS_ID + SPACE_HYPEN_SAPCE + processId);
		LOGGER.debug(APP_NAME + SPACE_HYPEN_SAPCE + appName);
		LOGGER.debug(TASKID + SPACE_HYPEN_SAPCE + taskId);

		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		// Get all the request parameter string values
		request.setAttribute(APP_NAME, appName);
		request.setAttribute(USER_ID, userId);
		request.setAttribute(PROCESS_ID, processId);
		request.setAttribute(TASK_ID, taskId);

		Response response = this.caseManagmentRestService.getComments(request);

		LOGGER.debug("Exiting TaskComments");

		return response;
	}

	@GET
	@Produces({ MediaTypes.V2_XML, MediaTypes.V2_JSON })
	public Response getTaskById(@QueryParam(USER_ID) String userId,
			@PathParam(PROCESS_ID) String processId,
			@PathParam(TASK_ID) String taskId,
			@QueryParam(APP_NAME) String appName,
			@QueryParam(QUEUE_NAME) String queueName,
			@QueryParam(PROPERTY) String property) {

		LOGGER.debug("Entering TaskByID");
		LOGGER.debug("Request Params");
		LOGGER.debug(USER_ID + SPACE_HYPEN_SAPCE + userId);
		LOGGER.debug(PROCESS_ID + SPACE_HYPEN_SAPCE + processId);
		LOGGER.debug(APP_NAME + SPACE_HYPEN_SAPCE + appName);

		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		// Get all the request parameter string values
		request.setAttribute(APP_NAME, appName);
		request.setAttribute(USER_ID, userId);
		request.setAttribute(PROCESS_ID, processId);
		request.setAttribute(TASK_ID, taskId);
		request.setAttribute(QUEUE_NAME, queueName);
		request.setAttribute(PROPERTY, property);

		Response response = this.caseManagmentRestService.getTaskById(request);

		LOGGER.debug("Exiting TaskByID");

		return response;
	}

/*	@Path("/comments")
	public TaskResource taskSubResource() {
		return this.resourceContext.getResource(TaskResource.class);
	}*/

}
