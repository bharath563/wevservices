package org.tiaa.case_management_rs.common;

import java.io.IOException;
import java.util.UUID;

import javax.xml.soap.Name;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.TransformerException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.GuidUtility;

public class SInfoHeaderAdderWebServiceMessageCallback implements WebServiceMessageCallback {
	private static final Logger LOG = LoggerFactory.getLogger(SInfoHeaderAdderWebServiceMessageCallback.class);
	private final String appName;
	private final String userRef;
	private final String guid;
	private final String correlationID;

	public SInfoHeaderAdderWebServiceMessageCallback(String appName, String userRef) {
		this.appName = appName;
		this.userRef = userRef;
		this.guid = new GuidUtility().toString();
		this.correlationID = UUID.randomUUID().toString();
	}

	public SInfoHeaderAdderWebServiceMessageCallback(String appName, String userRef, String correlationID) {
		this.appName = appName;
		this.userRef = CommonUtil.isNullOrEmpty(userRef) ? AppConstants.USER_REF : userRef;
		this.guid = new GuidUtility().toString();
		this.correlationID = CommonUtil.isNullOrEmpty(correlationID) ? new GuidUtility().toString() : correlationID;
	}

	public SInfoHeaderAdderWebServiceMessageCallback(String appName, String userRef, String guid, String correlationID) {
		this.appName = appName;
		this.userRef = userRef;
		this.guid = guid;
		this.correlationID = correlationID;
	}

	public void addSInfoHeader(SaajSoapMessage saajSoapMessage) throws TransformerException {
		LOG.info("Enter addSInfoHeader");
		try {
			SOAPMessage saajMessage = saajSoapMessage.getSaajMessage();
			SOAPPart soapPart = saajMessage.getSOAPPart();
			SOAPEnvelope envelope = soapPart.getEnvelope();
			SOAPHeader soapHeader = saajMessage.getSOAPHeader();
			Name sinfo = envelope.createName("sinfo", "esb", "http://esb.tiaa.org");
			SOAPHeaderElement sinfoHeader = soapHeader.addHeaderElement(sinfo);
			sinfoHeader.addAttribute(envelope.createName("guid"), guid);
			sinfoHeader.addAttribute(envelope.createName("correlationID"), correlationID);
			sinfoHeader.addAttribute(envelope.createName("userRef"), userRef);
			sinfoHeader.addAttribute(envelope.createName("appname"), appName);
			sinfoHeader.addAttribute(envelope.createName("senderMachine"), CommonUtil.getHostName());
		} catch (SOAPException e) {
			throw new TransformerException(e);
		}
		LOG.info("Exit addSInfoHeader");
	}

	public void doWithMessage(WebServiceMessage message) throws IOException, TransformerException {
		addSInfoHeader((SaajSoapMessage) message);
	}

}