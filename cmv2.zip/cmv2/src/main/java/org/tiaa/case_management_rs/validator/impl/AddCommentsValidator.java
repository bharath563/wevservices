package org.tiaa.case_management_rs.validator.impl;

import java.util.List;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.apache.commons.lang3.StringUtils;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.case_management_rs.validator.BaseValidator;
import org.tiaa.case_management_rs.validator.impl.BaseValidatorImpl;
import org.tiaa.esb.case_management_rs_v2.type.Comment;
import org.tiaa.esb.case_management_rs_v2.type.CommentsRequest;

public class AddCommentsValidator extends BaseValidatorImpl implements
		BaseValidator {

	@Override
	public void doValidate(Request request) {
		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);
		CommentsRequest commentsReq = (CommentsRequest) request.getAttribute(COMMENT_REQUEST);

		 List<Comment> comments = commentsReq.getComments().getComments();
		 
		if (StringUtils.isBlank(userId)) {
			handleException(VALIDATION_USERID_IS_EMPTY);
		}

		if (StringUtils.isBlank(processId)) {
			handleException(VALIDATION_PROCESSID_IS_EMPTY);
		}
		
		if(comments!=null && !(comments.isEmpty())){
			Comment comment = comments.get(0);
			if (StringUtils.isBlank(comment.getMessage())) {
				handleException(VALIDATION_COMMENT_IS_EMPTY);
			}
		}else{
			handleException(VALIDATION_COMMENTSLIST_IS_EMPTY);
		}
		

	}

}
