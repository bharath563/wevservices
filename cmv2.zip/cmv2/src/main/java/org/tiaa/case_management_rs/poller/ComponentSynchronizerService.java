package org.tiaa.case_management_rs.poller;

public interface ComponentSynchronizerService {
	boolean checkOwner();

	String getOwner();
}