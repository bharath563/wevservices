package org.tiaa.case_management_rs.integration.case_manager.cth;

import org.tiaa.esb.partyrequest.types.PartyRequestResponse;
import org.tiaa.esb.partyrequest.types.UpdateRequests;
import org.tiaa.esb.partyrequest.types.UpdateRequestsResponse;

public class CTHCaseRecordUpdater {
	private RetrieveRequestsResponseProcessor retrieveRequestsResponseProcessor;
	private CTHCaseWebService cthCaseWebService;
	private CTHCaseRecordRetriever cthRecordRetriever;

	public UpdateRequestsResponse updateCTHRecord(UpdateCaseCTHContext context) {
		PartyRequestResponse partyRequestResponse = cthRecordRetriever.retrieveCTHRecord(context.getCaseDetails());
		if (partyRequestResponse == null) {
			return null;
		}
		UpdateRequests updateRequests = retrieveRequestsResponseProcessor.processResponse(context, partyRequestResponse);
		if (updateRequests == null) {
			return null;
		}
		return cthCaseWebService.updateCTHEntry(context, (UpdateRequests) updateRequests);
	}

	public void setRetrieveRequestsResponseProcessor(RetrieveRequestsResponseProcessor retrieveRequestsResponseProcessor) {
		this.retrieveRequestsResponseProcessor = retrieveRequestsResponseProcessor;
	}

	public void setCthCaseWebService(CTHCaseWebService cthWebService) {
		this.cthCaseWebService = cthWebService;
	}

	public void setCthRecordRetriever(CTHCaseRecordRetriever cthRecordRetriever) {
		this.cthRecordRetriever = cthRecordRetriever;
	}
}
