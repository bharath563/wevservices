package org.tiaa.case_management_rs.integration.exp_ag.power_image;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.HandlerRegistry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.axis.MessageContext;
import org.apache.axis.message.SOAPHeaderElement;
import org.apache.axis.transport.http.HTTPConstants;
import org.apache.ws.security.WSConstants;
import org.apache.ws.security.handler.WSHandlerConstants;
import org.apache.ws.security.message.token.UsernameToken;

import com.sungard.sws.pi.webservice.WebServiceBeanLocator;
import com.sungard.sws.pi.webservice.WebServiceBeanPortStub;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.integration.clients.SoapClientHandler;
import org.tiaa.case_management_rs.utils.CommonUtil;

@Component
public class PoweImageProxy {
	private static final Logger LOG = LoggerFactory.getLogger(PoweImageProxy.class);
	@Value("${powerImageURL}")
	private String powerImageURL;
	@Value("${atom.env-id}")
	private String envId;

	public PoweImageProxy() {
	}

	public PoweImageProxy(String powerImageURL) {
		this.powerImageURL = powerImageURL;
	}

	@PostConstruct
	public void init() {
		if ("dev-0".equals(envId)) {
			//powerImageURL = "http://ut-int3-dpw.ops.tiaa-cref.org/expag-powerimage-v1";
		}
	}

	public WebServiceBeanPortStub createEXPAGProxy() {
		try {
			return tryCreateEXPAGProxy();
		} catch (MalformedURLException e) {
			LOG.error(e.getMessage(), e);
			throw new WorkflowException("Bad URL for EXP AG service.", e);
		} catch (ServiceException e) {
			LOG.error(e.getMessage(), e);
			throw new WorkflowException("EXP AG Service Exception.", e);
		} catch (UnknownHostException e) {
			LOG.error(e.getMessage(), e);
			throw new WorkflowException("Unable to determing localhost name.", e);
		}
	}

	private WebServiceBeanPortStub tryCreateEXPAGProxy() throws MalformedURLException, ServiceException, UnknownHostException {
		URL expAGUrl = new URL(powerImageURL);
		LOG.debug("EXPAG URL: {}", expAGUrl);
		WebServiceBeanLocator expagLocator = new WebServiceBeanLocator();
		WebServiceBeanPortStub proxy = (WebServiceBeanPortStub) expagLocator.getWebServiceBeanPort(expAGUrl);
		
		//Add Handler to the SOAP call	
		List handlerList = new ArrayList();
		handlerList.add(new HandlerInfo(SoapClientHandler.class, null, null));		
		HandlerRegistry registry = expagLocator.getHandlerRegistry();
		registry.setHandlerChain(proxy.getPortName(), handlerList);
		
		proxy._setProperty(WSHandlerConstants.ACTION, WSHandlerConstants.USERNAME_TOKEN);
		proxy._setProperty(UsernameToken.PASSWORD_TYPE, WSConstants.PASSWORD_DIGEST);
		proxy._setProperty(WSHandlerConstants.USER, AppConstants.APPLICATION_NAME);
		proxy._setProperty(WSHandlerConstants.PW_CALLBACK_REF, new PWCallback(AppConstants.APPLICATION_NAME));
		proxy.setHeader(createHeader());
		// Use HTTP 1.1 - axis 1.2.1 uses HTTP 1.0 by default
		proxy._setProperty(MessageContext.HTTP_TRANSPORT_VERSION, HTTPConstants.HEADER_PROTOCOL_V11);
		proxy._setProperty(HTTPConstants.HEADER_TRANSFER_ENCODING, HTTPConstants.HEADER_TRANSFER_ENCODING_CHUNKED);
		proxy._setProperty(HTTPConstants.HEADER_EXPECT, HTTPConstants.HEADER_EXPECT_100_Continue);
		return proxy;
	}

	private SOAPHeaderElement createHeader() throws UnknownHostException {
		SOAPHeaderElement header = new SOAPHeaderElement(CaseManagementConstants.ESB_TIAA_NS, "sinfo");
		header.setActor(null);
		header.setMustUnderstand(false);
		//header.addAttribute("", "guid", new GuidUtility().toString());
		header.addAttribute("", "userRef", AppConstants.USER_REF);
		header.addAttribute("", "senderMachine", CommonUtil.getHostName());
		return header;
	}

	public void setPowerImageURL(String esbEXPagV1Link) {
		this.powerImageURL = esbEXPagV1Link;
	}

}
