package org.tiaa.case_management_rs.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="CMS_TASK_TYPE")
public class CMSTaskType implements Serializable {
	private static final long serialVersionUID = 5923071103278648253L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="CMS_TASK_TYPE_SEQ")
	@SequenceGenerator(name = "CMS_TASK_TYPE_SEQ", sequenceName = "CMS_TASK_TYPE_SEQ", allocationSize = 1)
	private long cmsTaskTypeId;
	private String taskType;
	private boolean active = true;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_DATE_TS")
	private Date createdDate;
	private String createdBy;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="UPDATED_DATE_TS")
	private Date updatedDate;
	private String updatedBy;
	@Column(name="CTH_REQUEST_SCHEMA_NAME")
	private String cthRequestSchemaName;
	@Column(name="CREATE_CTH_RECORD")
	private boolean createCTHRecord;
	@Column(name="PLAN_MODIFICATION_REQUEST_TASK")
	private boolean planModificationRequestTask;
	
	public long getCmsTaskTypeId() {
		return cmsTaskTypeId;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public String getTaskType() {
		return taskType;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setCmsTaskTypeId(long id) {
		this.cmsTaskTypeId = id;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getCthRequestSchemaName() {
		return cthRequestSchemaName;
	}

	public void setCthRequestSchemaName(String cthRequestSchemaName) {
		this.cthRequestSchemaName = cthRequestSchemaName;
	}

	public boolean isCreateCTHRecord() {
		return createCTHRecord;
	}

	public void setCreateCTHRecord(boolean createCTHRecord) {
		this.createCTHRecord = createCTHRecord;
	}

	public boolean isPlanModificationRequestTask() {
		return planModificationRequestTask;
	}

	public void setPlanModificationRequestTask(boolean planModificationRequestTask) {
		this.planModificationRequestTask = planModificationRequestTask;
	}

	@Override
	public String toString() {
		return "CMSTaskType [cmsTaskTypeId=" + cmsTaskTypeId + ", taskType=" + taskType + ", active=" + active + ", createdDate=" + createdDate + ", createdBy=" + createdBy
				+ ", updatedDate=" + updatedDate + ", updatedBy=" + updatedBy + ", cthRequestSchemaName=" + cthRequestSchemaName + ", createCTHRecord=" + createCTHRecord
				+ ", planModificationRequestTask=" + planModificationRequestTask + "]";
	}

}
