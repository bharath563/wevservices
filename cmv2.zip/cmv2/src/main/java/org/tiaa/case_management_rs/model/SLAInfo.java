package org.tiaa.case_management_rs.model;

import java.util.Date;

public class SLAInfo {

	private Date recievedDateTime;
	private Date startDateTime;
	private Date endDateTime;

	public Date getRecievedDateTime() {
		return this.recievedDateTime;
	}

	public void setRecievedDateTime(Date recievedDateTime) {
		this.recievedDateTime = recievedDateTime;
	}

	public Date getStartDateTime() {
		return this.startDateTime;
	}

	public void setStartDateTime(Date startDateTime) {
		this.startDateTime = startDateTime;
	}

	public Date getEndDateTime() {
		return this.endDateTime;
	}

	public void setEndDateTime(Date endDateTime) {
		this.endDateTime = endDateTime;
	}

}
