package org.tiaa.case_management_rs.constants;

public enum ConfigItemSortBy {
	
	SHORT("SHORT_DESCRIPTION"), LONG("LONG_DESCRIPTION") ;

    private final String value;

    ConfigItemSortBy(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }
	
}
