package org.tiaa.case_management_rs.delegate.impl;

import java.util.HashMap;

/**
 * Mapping class used for sorting data based on column
 * @author kumprad
 *
 */
public class ColumnsMapping {
	private static HashMap<String,String> UI_TO_EXPAG = new HashMap<String,String>();
	private static HashMap<String,String> UI_TO_ICM = new HashMap<String,String>();
	
	// Column names coming from UD for sorting request
	public static final String REQUEST_ID = "REQUEST ID";//"Request ID";
	public static final String REQUEST_TYPE = "REQUEST TYPE";//"Request Type";
	public static final String STATUS = "STATUS";//"Status";
	public static final String ASSIGNED_TO = "ASSIGNED TO";//"Assigned To";
	public static final String RECEIVED_DATE = "RECEIVED DATE";//"Received Date";
	public static final String CHANNEL = "CHANNEL";//"Channel";
	public static final String PIN = "PIN";//"Pin";
	public static final String NPIN = "NPIN";//"NPin";
	public static final String CREATED_DATE = "CREATED DATE";//"Received Date";
	
	static{

		UI_TO_EXPAG.put(REQUEST_TYPE, "TASKTYPE");
		UI_TO_EXPAG.put(STATUS, "STATUS");
		UI_TO_EXPAG.put(REQUEST_ID, "TASKID");
		UI_TO_EXPAG.put(RECEIVED_DATE, "DATERCVD");
		UI_TO_EXPAG.put(CHANNEL, "CHANNEL");
		UI_TO_EXPAG.put(ASSIGNED_TO, "ASSIGNEDTO");
		UI_TO_EXPAG.put(PIN, "PIN");
		UI_TO_EXPAG.put(NPIN, "NPIN");
		
		UI_TO_ICM.put(REQUEST_TYPE, "caseType");
		UI_TO_ICM.put(STATUS, "caseStatus");
		UI_TO_ICM.put(REQUEST_ID, "confirmation");
		UI_TO_ICM.put(RECEIVED_DATE, "requestReceivedDate");
		UI_TO_ICM.put(CHANNEL, "channel");
		//dummy value not implemented in ICM
		UI_TO_ICM.put(ASSIGNED_TO, "assignedTo");
		
		UI_TO_ICM.put(PIN, "pin");
		
		//dummy value not implemented in ICM
		UI_TO_ICM.put(NPIN, "npin");

	}

	/**
	 * Return EXPAG column names corresponding to UI column name
	 * If not mapping found, return RECEIVED_DATE
	 * @param inputColumn
	 * @return
	 */
	public static String getEXPAGColumn(String inputColumn){
		String columnName = UI_TO_EXPAG.get(inputColumn.toUpperCase());
		
		if(columnName!=null){
			return columnName;
		}else{
			return UI_TO_EXPAG.get(RECEIVED_DATE);
		}
	}
	/**
	 * Return ICM column names corresponding to UI column name
	 * If not mapping found, return RECEIVED_DATE
	 * @param inputColumn
	 * @return
	 */
	public static String getICMColumn(String inputColumn){
		String columnName = UI_TO_ICM.get(inputColumn.toUpperCase());
		
		if(columnName!=null){
			return columnName;
		}else{
			return UI_TO_ICM.get(RECEIVED_DATE);
		}
	}

}
