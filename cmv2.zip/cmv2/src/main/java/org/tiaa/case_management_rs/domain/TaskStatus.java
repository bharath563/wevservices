package org.tiaa.case_management_rs.domain;

public enum TaskStatus {
	Recieved("Submitted"), InProgress("In Process"), Completed("Platform Complete"), Cancelled("Cancel In Process");

	private TaskStatus(String status) {
		this.cthStatus = status;
	}

	private final String cthStatus;

	public String getCthStatus() {
		return cthStatus;
	}

}
