package org.tiaa.case_management_rs.integration.icm;
 
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.tiaa.esb.icm.types.Case;
import org.tiaa.esb.icm.types.CaseSearch;
import org.tiaa.esb.icm.types.Comment;
import org.tiaa.esb.icm.types.Configuration;
import org.tiaa.esb.icm.types.Document;
import org.tiaa.esb.icm.types.Response;
import org.tiaa.esb.icm.types.ResponseList;
 
@Service
public class ICMServiceImpl implements ICMService {
 
    @Autowired
    private ICMRepository icmRepository;
    
    @Override
    public ResponseList searchICMCases(CaseSearch icmCaseSearchRequest,String userId) {
        return icmRepository.searchICMCases(icmCaseSearchRequest,userId);
    }
 
    @Override
    public Case getICMProcess(String processId, String userId) {
        return icmRepository.getICMProcess(processId, userId);
    }
    
    @Override
    public ResponseList getICMtasks(String processId, String userId, String start) {
        return icmRepository.getICMtasks(processId, userId, start);
    }
    
    @Override
    public ResponseList getICMDocuments(String processId, String userId){
        return icmRepository.getICMDocuments(processId, userId);
    }
    
    @Override
    public ResponseList getICMcomments(String processId, String userId) {
        return icmRepository.getICMcomments(processId, userId);
    }
 
    @Override
    public Configuration getICMConfigItem(String property) {
        return icmRepository.getICMConfigItem(property);
    }
    //added for ICM entitled department
    @Override
    public List<String> getICMSolutions(String property, String userId) {
        return icmRepository.getICMSolutions(property,userId);
    }
    
    @Override
    public Response addComment(Comment icmCommentRequest,String caseId,String userId) {
         return icmRepository.addICMComment(icmCommentRequest,caseId,userId);
    }
    
    @Override
    public Response addDocument(Document icmDocumentRequest,String caseId,String userId) {
         return icmRepository.addICMDocument(icmDocumentRequest,caseId,userId);
     }

	@Override
	public ResponseList getICMRelatedCase(String processId, String userId,String solutionName) {
		return icmRepository.getICMRelatedCase(processId, userId,solutionName);	
	}
	
	@Override
	public Configuration getICMSolutionHeaders(String dept, String userId,  String tableheader) {
		return icmRepository.getICMSolutionHeaders(dept, userId, tableheader);
	
	}

	@Override
	public Configuration getICMRequestTypesForBA(String property, String dept) {
		return icmRepository.getICMRequestTypesForBA(property, dept);
	}

	@Override
	public void deleteICMDocument(String caseId, String docTemplateCode, String userId) {
		// TODO Auto-generated method stub
		 this.icmRepository.deleteICMDocument(caseId, docTemplateCode, userId);
	}
 
 
}
 
 
