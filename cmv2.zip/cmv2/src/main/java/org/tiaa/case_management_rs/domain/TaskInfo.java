package org.tiaa.case_management_rs.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.servicerequest_workflow.types.DocumentIDType;
import org.tiaa.esb.servicerequest_workflow.types.DocumentIDsType;
import org.tiaa.esb.servicerequest_workflow.types.DocumentType;

public class TaskInfo implements Serializable {
	private static final Logger LOG = LoggerFactory.getLogger(TaskInfo.class);
	private static final long serialVersionUID = 811343866927281262L;
	private String actcode = "";
	private Date completedDateTime;
	private String customerNumber = "";
	private String departmentCode = "";
	private String operatorId = "";
	private String priority = "";
	private Date recievedDateTime;
	private String statusCode = "";
	private String statusDescription = "";
	private String taskcode = "";
	private String taskId = "";
	private Date taskLastUpdated;
	private String taskName = "";
	private TaskStatus taskStatus = TaskStatus.Recieved;
	private String taskType = "";
	private String vipIndicator = "";
	private String workBasket = "";
	private String workpacketId = "";
	private String cthOrchestrationId = "";
	private String system;
	private String channel = "";
	private String processType = "";
	private String requestType = "";
	private String createOperator = "";
	private String systemIdentifier = "EX-PAG";
	private String updatedBy = "CaseManagementRSV1";
	//
	private List<DocumentType> documents = new ArrayList<DocumentType>();
	private Map<String, Object> identifiers = new HashMap<String, Object>();
	private String cthRequestId;
	private int startDate;
	private int startTime;
	private boolean cthOrchIdEnabled = false;

	public TaskInfo() {
	}

	public void addIdentifier(String key, String value) {
		identifiers.put(key, value);
	}

	public void addIdentifiersFrom(TaskInfo taskInfo) {
		if (this == taskInfo) {
			return;
		}
		identifiers.putAll(taskInfo.identifiers);
		setCthOrchId();
	}

	public String getActcode() {
		return actcode;
	}

	public String getChannel() {
		return channel;
	}

	public String getClientId() {
		return getIdentifierStringValue("INST PPG ID");
	}

	public Date getCompletedDateTime() {
		return completedDateTime;
	}

	public String getCthOrchestrationId() {
		return cthOrchestrationId;
	}

	public String getCthRequestId() {
		return cthRequestId;
	}

	public String getCthStatus() {
		return (!isServiceRequest() && isCompleted()) ? getTaskStatus().toString() : getTaskStatus().getCthStatus();
	}

	public String getCreateOperator() {
		return createOperator;
	}

	public String getCustomerNumber() {
		return customerNumber == null ? "" : customerNumber;
	}

	public String getDepartmentCode() {
		return departmentCode;
	}

	public List<DocumentType> getDocuments() {
		return documents;
	}

	public Map<String, Object> getIdentifiers() {
		return identifiers;
	}

	public String getOperatorId() {
		return operatorId;
	}

	public String getPlanNumber() {
		return getIdentifierStringValue("PLAN");
	}

	public String getPriority() {
		return priority;
	}

	public String getProcessType() {
		return processType;
	}

	public String getRecievedDateAsStr() {
		XMLGregorianCalendar xmlGregorianCalendar = DateUtil.toXMLGregorianCalendar(getRecievedDateTime());
		if (xmlGregorianCalendar == null) {
			xmlGregorianCalendar = DateUtil.getCurrentDate();
		}
		return xmlGregorianCalendar.toXMLFormat();
	}

	public Date getRecievedDateTime() {
		return recievedDateTime;
	}

	public XMLGregorianCalendar getRecievedDateTimeAsXMLGregorianCalendar() {
		return DateUtil.toXMLGregorianCalendarDateOnly(recievedDateTime);
	}

	public String getRequestType() {
		return requestType;
	}

	public String getServiceRequestTopic() {
		return taskType;
	}

	public int getStartDate() {
		return startDate;
	}

	public int getStartTime() {
		return startTime;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public String getStatusDescription() {
		return statusDescription;
	}

	public String getSystem() {
		return system;
	}

	public String getSystemIdentifier() {
		return systemIdentifier;
	}

	public String getTaskcode() {
		return taskcode;
	}

	public String getTaskId() {
		return taskId;
	}

	public Date getTaskLastUpdated() {
		return taskLastUpdated;
	}

	public String getTaskName() {
		return taskName;
	}

	public TaskStatus getTaskStatus() {
		if (taskStatus != null) {
			return taskStatus;
		}
		taskStatus = computeTaskStatus();
		return taskStatus;
	}

	public String getTaskStatusAsStr() {
		return (!isServiceRequest() && isCompleted()) ? getTaskStatus().toString() : getTaskStatus().getCthStatus();
	}

	public String getTaskType() {
		return taskType == null ? "" : taskType;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public String getVipIndicator() {
		return vipIndicator;
	}

	public String getWorkBasket() {
		return workBasket;
	}

	public String getWorkpacketId() {
		return workpacketId;
	}

	public boolean hasDocuments() {
		return !getDocuments().isEmpty();
	}

	public void init() {
		setCthOrchId();
		setCustomerNumber();
		LOG.debug("identifiers: {}", identifiers);
	}

	public boolean isCancelledStatus() {
		return "J".equals(statusCode) || "C".equals(statusCode);
	}

	public boolean isCompleted() {
		return completedDateTime != null;
	}

	public boolean isInRecievedStatus() {
		return getTaskStatus() == TaskStatus.Recieved;
	}

	public boolean isNotInRecievedStatus() {
		return getTaskStatus() != TaskStatus.Recieved;
	}

	public boolean isNotSameTaskStatus(String status) {
		return !getCthStatus().equalsIgnoreCase(status);
	}

	public boolean isReopened(String status) {
		return isInRecievedStatus() && isNotSameTaskStatus(status);
	}

	public void setActcode(String actcode) {
		this.actcode = actcode;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public void setCompletedDateTime(Date completedDateTime) {
		this.completedDateTime = completedDateTime;
	}

	public void setCthOrchestrationId(String cthOrchestrationId) {
		this.cthOrchestrationId = cthOrchestrationId;
	}

	public void setCthRequestId(String cthRequestId) {
		this.cthRequestId = cthRequestId;
	}

	public void setDptcode(String dptcode) {
		this.departmentCode = dptcode;
	}

	public void setIdentifiers(Map<String, Object> identifiers) {
		this.identifiers = identifiers;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

	public void setPktid(String pktid) {
		this.workpacketId = pktid;
	}

	public void setPktid(String pktid, String completedTaskPktId) {
		this.workpacketId = pktid;
		if (completedTaskPktId != null) {
			this.workpacketId = completedTaskPktId;
		}
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public void setRecievedDateTime(Date recievedDateTime) {
		this.recievedDateTime = recievedDateTime;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public void setStartDate(int startDate) {
		this.startDate = startDate;
	}

	public void setStartTime(int startTime) {
		this.startTime = startTime;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public void setStatusDescription(String statusDescription) {
		this.statusDescription = statusDescription;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public void setSystemIdentifier(String systemIdentifier) {
		this.systemIdentifier = systemIdentifier;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public void setTaskLastUpdated(Date taskLastUpdated) {
		this.taskLastUpdated = taskLastUpdated;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public void setTaskStatus() {
		setTaskStatus(computeTaskStatus());
	}

	public void setTaskStatus(TaskStatus taskStatus) {
		this.taskStatus = taskStatus;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public void setTskcode(String tskcode) {
		this.taskcode = tskcode;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public void setViptsk(String viptsk) {
		this.vipIndicator = viptsk;
	}

	public void setWrkbskt(String wrkbskt) {
		this.workBasket = wrkbskt;
	}

	public void setCreateOperator(String createOperator) {
		this.createOperator = createOperator;
	}

	public boolean updateTaskStatusInCTH(String status) {
		return isNotInRecievedStatus() && isNotSameTaskStatus(status);
	}

	private TaskStatus computeTaskStatus() {
		if (isCompleted()) {
			return isCancelledStatus() ? TaskStatus.Cancelled : TaskStatus.Completed;
		}
		return CommonUtil.isNullOrEmptyAfterTrim(statusCode) ? TaskStatus.Recieved : TaskStatus.InProgress;
	}

	private String getIdentifierStringValue(String string) {
		Object object = identifiers.get(string);
		return object == null ? "" : object.toString();
	}

	private void setCthOrchId() {
		Object orchId = identifiers.get("ORCHESTRATION");
		if (cthOrchIdEnabled && orchId != null) {
			cthOrchestrationId = (String) orchId;
		}
	}

	private void setCustomerNumber() {
		Object pin = identifiers.get("ADMIN CUST #");
		if (pin != null && !"".equals(pin)) {
			customerNumber = (String) pin;
		}
	}

	public void addDocument(DocumentType documentTypeToAdd) {
		for (DocumentType documentType : documents) {
			if (getDocumentId(documentType).equals(getDocumentId(documentTypeToAdd))) {
				LOG.debug("document already exists");
				return;
			}
		}
		documents.add(documentTypeToAdd);
	}

	@Override
	public String toString() {
		return "TaskInfo [actcode=" + actcode + ", completedDateTime=" + completedDateTime + ", customerNumber=" + customerNumber + ", departmentCode=" + departmentCode
				+ ", operatorId=" + operatorId + ", priority=" + priority + ", recievedDateTime=" + recievedDateTime + ", statusCode=" + statusCode + ", statusDescription="
				+ statusDescription + ", taskcode=" + taskcode + ", taskId=" + taskId + ", taskLastUpdated=" + taskLastUpdated + ", taskName=" + taskName + ", taskStatus="
				+ taskStatus + ", taskType=" + taskType + ", vipIndicator=" + vipIndicator + ", workBasket=" + workBasket + ", workpacketId=" + workpacketId
				+ ", cthOrchestrationId=" + cthOrchestrationId + ", system=" + system + ", channel=" + channel + ", processType=" + processType + ", requestType=" + requestType
				+ ", createOperator=" + createOperator + ", systemIdentifier=" + systemIdentifier + ", updatedBy=" + updatedBy + ", documents=" + documents + ", identifiers="
				+ identifiers + ", cthRequestId=" + cthRequestId + ", startDate=" + startDate + ", startTime=" + startTime + "]";
	}

	public boolean isServiceRequest() {
		return !"dffweb".equals(createOperator);
	}

	public static String getDocumentId(DocumentType documentType) {
		DocumentIDsType documentIDs = documentType.getDocumentIDs();
		if (documentIDs == null) {
			return "";
		}
		List<DocumentIDType> documentIDList = documentIDs.getDocumentIDs();
		if (documentIDList == null || documentIDList.isEmpty()) {
			return "";
		}
		DocumentIDType documentIDType = documentIDList.get(0);
		if (documentIDType == null) {
			return "";
		}
		return documentIDType.getValue();
	}

	public void setDocuments(List<DocumentType> documents) {
		this.documents = documents;
	}
}
