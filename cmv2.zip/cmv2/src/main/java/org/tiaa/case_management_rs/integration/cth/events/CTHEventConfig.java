package org.tiaa.case_management_rs.integration.cth.events;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.Marshaller;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.common.ExceptionHandler;

@Configuration
public class CTHEventConfig {
	@Bean
	public CTHEventConsumer cthEventConsumer() {
		return new CTHEventConsumer();
	}

	@Bean
	public CTHEventProcessor cthEventProcessor() {
		return new CTHEventProcessor();
	}

	@Bean
	public Jaxb2Marshaller cthEventJaxb2Marshaller() {
		Map<String, Object> marshallerProperties = new HashMap<String, Object>();
		marshallerProperties.put(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		//
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		jaxb2Marshaller.setClassesToBeBound(new Class<?>[] { org.tiaa.cth.event.generated.jaxb.types.ObjectFactory.class });
		ExceptionHandler.initalize(jaxb2Marshaller);
		return jaxb2Marshaller;
	}

//	@Bean
//	public CTHEventMessageListenerA cthEventMessageListener() {
//		return new CTHEventMessageListenerA();
//	}
//
//	@Bean
//	public CTHEventMessageListenerB cthEventMessageListener2() {
//		return new CTHEventMessageListenerB();
//	}
}
