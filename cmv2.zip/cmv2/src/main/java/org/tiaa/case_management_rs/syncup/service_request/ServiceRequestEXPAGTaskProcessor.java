package org.tiaa.case_management_rs.syncup.service_request;

import javax.annotation.PostConstruct;
import javax.validation.ValidationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.common.CMSTaskTypeService;
import org.tiaa.case_management_rs.domain.CMRSEvent;
import org.tiaa.case_management_rs.domain.CMSAudit;
import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.CMSTaskType;
import org.tiaa.case_management_rs.domain.TaskDetails;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.email.EmailSender;
import org.tiaa.case_management_rs.email.EmailUtil;
import org.tiaa.case_management_rs.email.plan_modification_request.PlanModificationTaskCreationProcessor;
import org.tiaa.case_management_rs.integration.cth.CTHCreateRecordFailedException;
import org.tiaa.case_management_rs.integration.cth.CTHRecordNotFoundException;
import org.tiaa.case_management_rs.integration.cth.CTHRecordRetriever;
import org.tiaa.case_management_rs.integration.cth.CTHUpdateRecordFailedException;
import org.tiaa.case_management_rs.integration.cth.CreateCTHContext;
import org.tiaa.case_management_rs.integration.cth.RetryableCTHRecordCreator;
import org.tiaa.case_management_rs.integration.cth.RetryableCTHRecordUpdater;
import org.tiaa.case_management_rs.integration.exp_ag.AbstractEXPAGTaskProcessor;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTaskProcessor;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTaskType;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.esb.partyrequest.types.PartyRequestResponse;

@Component
@EXPAGTaskType(schemaName = "service-request-1-0-clob.xsd")
public class ServiceRequestEXPAGTaskProcessor extends AbstractEXPAGTaskProcessor implements EXPAGTaskProcessor {
	private static final Logger LOG = LoggerFactory.getLogger(ServiceRequestEXPAGTaskProcessor.class);
	@Autowired
	private RetryableCTHRecordCreator retryableCTHRecordCreator;
	@Autowired
	private CMSTaskTypeService cmsTaskTypeService;
	@Autowired
	private CTHRecordRetriever cthRecordRetriever;
	@Autowired
	private EmailSender emailSender;
	@Autowired
	private RetryableCTHRecordUpdater serviceRequestRetryableCTHRecordUpdater;
	private boolean sendEmailOnCreationFailure;
	@Autowired
	private PlanModificationTaskCreationProcessor planModificationTaskCreationProcessor;

	@PostConstruct
	public void init() {
		retryableCTHRecordUpdater = serviceRequestRetryableCTHRecordUpdater;
	}

	public void processTask(TaskInfo taskInfo) {
		CMSAuditHistory cmsAuditHistory = cmsAuditService.createCMSAuditHistory(taskInfo);
		try {
			processTask(taskInfo, cmsAuditHistory);
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
			cmsAuditService.markAsFailed(cmsAuditHistory, e);
		}
	}

	public void processTask(TaskInfo taskInfo, CMSAuditHistory cmsAuditHistory) {
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		boolean cthRecordExists = cmsAudit.hasCthOrchestrationId();
		PartyRequestResponse partyRequestResponse = null;
		if (!cthRecordExists) {
			try {
				partyRequestResponse = cthRecordRetriever.retrieveCTHRecord(taskInfo);
				cthRecordExists = true;
			} catch (CTHRecordNotFoundException e) {
				//record not found
				LOG.debug(e.getMessage());
			}
		}
		CMSAuditHistory planModificationTaskRequestCMSAuditHistory = processPlanModificationTaskRequest(taskInfo, cmsAudit, partyRequestResponse);
		if (planModificationTaskRequestCMSAuditHistory != null) {
			cmsAuditHistory.setCmsAudit(planModificationTaskRequestCMSAuditHistory.getCmsAudit());
		}

		taskInfo.setRequestType("ServiceRequest");
		taskInfo.setProcessType("InstitutionalWorkflowRequest");
		taskInfo.setChannel("Call Center");
		LOG.debug("Processing Task: {} : {} : {}", taskInfo.getTaskId(), taskInfo.getTaskStatusAsStr(), taskInfo.getDocuments().size());
		if (!cthRecordExists) {
			createCTHRecord(taskInfo, cmsAuditHistory);
		} else {
			updateCTHRecord(taskInfo, cmsAuditHistory);
		}
	}

	private CMSAuditHistory processPlanModificationTaskRequest(TaskInfo taskInfo, CMSAudit cmsAudit, PartyRequestResponse partyRequestResponse) {
		try {
			String taskType = taskInfo.getTaskType();
			CMSTaskType cmsTaskType = cmsTaskTypeService.getCMSTaskType(taskType);
			if (cmsTaskType.isPlanModificationRequestTask()) {
				LOG.debug("plan modification request task");
				if (cmsAudit.isEmailSent()) {
					LOG.debug("Email already sent for Task: {}", taskInfo.getTaskId());
					return null;
				}
				cmsAudit.setSendEmail(true);
				LOG.debug("send email for plan modification request task");
				return planModificationTaskCreationProcessor.processTask(taskInfo, partyRequestResponse);
			}
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
		}
		return null;
	}

	private void createCTHRecord(TaskInfo taskInfo, CMSAuditHistory cmsAuditHistory) {
		cmsAuditHistory.setEvent(CMRSEvent.CREATE_CTH_RECORD);
		LOG.debug("attempting to create cth record for task id:{}", taskInfo.getTaskId());
		try {
			if (CommonUtil.isNullOrEmpty(taskInfo.getCustomerNumber())) {
				throw new ValidationException(AppConstants.CUSTOMER_NUMBER_REQUIRED);
			}
			CreateCTHContext context = createCTHContext(taskInfo);
			retryableCTHRecordCreator.createCTHRecord(context);
			CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
			cmsAudit.setCthRequestId(context.getCthRequestId());
			cmsAudit.setCthOrchestrationId(context.getCthOrchestrationId());
			cmsAuditService.markAsSuccessful(cmsAuditHistory);
			LOG.debug("successfully created cth record for task id:{}", taskInfo.getTaskId());
		} catch (ValidationException e) {
			LOG.debug("failed to create cth record for task id:{}", taskInfo.getTaskId());
			LOG.warn(e.getMessage(), e);
			//cmsAuditService.markAsFailed(cmsAuditHistory, e);
			cmsAuditService.markAsIgnore(cmsAuditHistory, e);
		} catch (CTHCreateRecordFailedException e) {
			LOG.debug("failed to create cth record for task id:{}", taskInfo.getTaskId());
			LOG.warn(e.getMessage(), e);
			cmsAuditService.markAsFailed(cmsAuditHistory, e);
			if (sendEmailOnCreationFailure && cmsAuditHistory.getRetryAttempt() < 1) {
				emailSender.sendEmailToProdSupport("Error while creating CTH Record for Task Id:" + taskInfo.getTaskId(), EmailUtil.createEmail(cmsAuditHistory, e));
			}
		}
	}

	private void updateCTHRecord(TaskInfo taskInfo, CMSAuditHistory cmsAuditHistory) {
		cmsAuditHistory.setEvent(CMRSEvent.UPDATE_CTH_RECORD);
		LOG.debug("attempting to update cth record for task id:{}", taskInfo.getTaskId());
		try {
			tryUpdateCTHRecord(taskInfo, cmsAuditHistory);
			LOG.debug("successfully updated cth record for task id:{}", taskInfo.getTaskId());
		} catch (CTHRecordNotFoundException e) {
			LOG.warn(e.getMessage());
			createCTHRecord(taskInfo, cmsAuditHistory);
		} catch (CTHUpdateRecordFailedException e) {
			LOG.debug("failed to update cth record for task id:{}", taskInfo.getTaskId());
			LOG.warn(e.getMessage(), e);
			cmsAuditService.markAsFailed(cmsAuditHistory, e);
			emailSender.sendEmailToProdSupport("Error while updating CTH Record for Task Id:" + taskInfo.getTaskId(), EmailUtil.createEmail(cmsAuditHistory, e));
		}
	}

	private CreateCTHContext createCTHContext(TaskInfo taskInfo) {
		TaskDetails taskDetails = new TaskDetails();
		taskDetails.setTaskInfo(taskInfo);
		//
		CreateCTHContext context = new CreateCTHContext();
		context.setTaskDetails(taskDetails);
		context.setCmsTaskType(cmsTaskTypeService.getCMSTaskType(taskInfo.getTaskType()));
		return context;
	}

}