package org.tiaa.case_management_rs.common;

import java.io.IOException;

import javax.ws.rs.core.MediaType;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import org.tiaa.case_management_rs.utils.CryptUtility;
import org.tiaa.case_management_rs.utils.GuidUtility;

import sun.misc.BASE64Encoder;


//@Repository(value="activitiHeaderAdderInterceptor")
public class ActivitiHeaderAdderInterceptor implements ClientHttpRequestInterceptor{
	/*
	@Value("${activitiUserName}")
	private String activitiUserName;
	@Value("${activitiPassword}")
	private String activitiPassword;
	*/
	private String activitiUserName;
	private String activitiPassword;
	
	private HttpHeaders headers;
	private String userId;//="tenantAdmn";
	private String authorization;
	private BASE64Encoder base64Encoder;
	
	
	public ActivitiHeaderAdderInterceptor(HttpHeaders headers,BASE64Encoder base64Encoder, String activitiUserName, String activitiPassword,String userId){
		this.headers= headers;
		this.base64Encoder = base64Encoder;
		this.activitiUserName = activitiUserName;
		this.activitiPassword = activitiPassword;
		this.userId = userId;
		authorization= getActivitiAuthorizationHeader();
	}
	/*public ActivitiHeaderAdderInterceptor(HttpHeaders headers, String tiaa_user, String Authorization){
		this.tiaa_user= tiaa_user;
		this.authorization= Authorization;
		this.headers= headers;
	}*/
	
	
	@Override
	public ClientHttpResponse intercept(HttpRequest paramHttpRequest,
			byte[] paramArrayOfByte,
			ClientHttpRequestExecution paramClientHttpRequestExecution)
			throws IOException {
		
		setHeaders(paramHttpRequest.getHeaders());
		return paramClientHttpRequestExecution.execute(paramHttpRequest, paramArrayOfByte);
	}
	
	public void setHeaders(HttpHeaders headers) {
		String guid = new GuidUtility().toString();
		headers.set("Accept", MediaType.APPLICATION_XML);
		headers.set("ContentType", MediaType.APPLICATION_XML);
		headers.set("tiaa_user", this.userId);
		headers.set("Authorization", getActivitiAuthorizationHeader());
		
	}
	
	

	public String getActivitiAuthorizationHeader(){
		String userpass=activitiUserName+":"+CryptUtility.decrypt(activitiPassword);
		String encString=base64Encoder.encode(userpass.getBytes());
		return "Basic "+encString; 
		
	}

}
