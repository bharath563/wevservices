package org.tiaa.case_management_rs.integration.cth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.support.RetryTemplate;

public class RetryableCTHRecordCreator {
	private static final Logger LOG = LoggerFactory.getLogger(RetryableCTHRecordCreator.class);
	private RetryTemplate retryTemplate;
	private CTHRecordCreator cthRecordCreator;

	public RetryableCTHRecordCreator(RetryTemplate retryTemplate, CTHRecordCreator cthRecordCreator) {
		super();
		this.retryTemplate = retryTemplate;
		this.cthRecordCreator = cthRecordCreator;
	}

	public Object createCTHRecord(final CreateCTHContext context) {
		try {
			return retryTemplate.execute(new RetryCallback<Object>() {
				@Override
				public Object doWithRetry(RetryContext retryContext) {
					return cthRecordCreator.createCTHRecord(context);
				}
			});
		} catch (Exception e) {
			LOG.warn(e.getMessage());
			throw new CTHCreateRecordFailedException(e.getMessage(), e);
		}
	}

}
