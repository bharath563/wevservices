package org.tiaa.case_management_rs.integration.cth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.support.RetryTemplate;

public class RetryableCTHRecordUpdater {
	private static final Logger LOG = LoggerFactory.getLogger(RetryableCTHRecordUpdater.class);
	private RetryTemplate retryTemplate;
	private CTHRecordUpdater cthRecordUpdater;

	public RetryableCTHRecordUpdater(RetryTemplate retryTemplate, CTHRecordUpdater cthRecordUpdater) {
		super();
		this.retryTemplate = retryTemplate;
		this.cthRecordUpdater = cthRecordUpdater;
	}

	public Object updateCTHRecord(final UpdateCTHContext context) {
		try {
			return retryTemplate.execute(new RetryCallback<Object>() {
				@Override
				public Object doWithRetry(RetryContext retryContext) {
					return cthRecordUpdater.updateCTHRecord(context);
				}
			});
		} catch (CTHRecordNotFoundException e) {
			LOG.warn(e.getMessage());
			throw e;
		} catch (Exception e) {
			LOG.warn(e.getMessage());
			throw new CTHUpdateRecordFailedException(e);
		}
	}
}
