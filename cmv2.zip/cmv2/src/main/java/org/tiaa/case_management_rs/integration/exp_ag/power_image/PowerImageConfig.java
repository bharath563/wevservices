package org.tiaa.case_management_rs.integration.exp_ag.power_image;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.Marshaller;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.common.ExceptionHandler;

@Configuration
public class PowerImageConfig {

	@Bean
	public PowerImageService powerImageService() {
		return new PowerImageService();
	}

	@Bean
	public PoweImageProxy poweImageProxy() {
		return new PoweImageProxy();
	}

	@Bean
	public Jaxb2Marshaller powerImageJaxb2Marshaller() {
		Map<String, Object> marshallerProperties = new HashMap<String, Object>();
		marshallerProperties.put(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		//
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		//
		jaxb2Marshaller.setClassesToBeBound(org.tiaa.esb.powerimage.types.ObjectFactory.class, //
				org.tiaa.esb.ping.types.ObjectFactory.class, //
				org.tiaa.esb.stats.types.ObjectFactory.class, //
				org.tiaa.esb.sinfo.types.ObjectFactory.class);
		ExceptionHandler.initalize(jaxb2Marshaller);
		return jaxb2Marshaller;
	}

	@Bean
	public Jaxb2Marshaller powerImageCreateTaskJaxb2Marshaller() {
		Map<String, Object> marshallerProperties = new HashMap<String, Object>();
		marshallerProperties.put(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		//
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		//
		jaxb2Marshaller.setClassesToBeBound(org.tiaa.esb.powerimage.createtask.types.ObjectFactory.class, //
				org.tiaa.esb.ping.types.ObjectFactory.class, //
				org.tiaa.esb.stats.types.ObjectFactory.class, //
				org.tiaa.esb.sinfo.types.ObjectFactory.class);
		ExceptionHandler.initalize(jaxb2Marshaller);
		return jaxb2Marshaller;
	}

	@Bean
	public Jaxb2Marshaller powerImageTaskSearchJaxb2Marshaller() {
		Map<String, Object> marshallerProperties = new HashMap<String, Object>();
		marshallerProperties.put(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		//
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		//
		jaxb2Marshaller.setClassesToBeBound(org.tiaa.esb.powerimage.tasksearch.types.ObjectFactory.class, //
				org.tiaa.esb.ping.types.ObjectFactory.class, //
				org.tiaa.esb.stats.types.ObjectFactory.class, //
				org.tiaa.esb.sinfo.types.ObjectFactory.class);
		ExceptionHandler.initalize(jaxb2Marshaller);
		return jaxb2Marshaller;
	}
}
