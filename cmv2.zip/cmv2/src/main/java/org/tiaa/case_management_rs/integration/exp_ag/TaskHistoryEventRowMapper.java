package org.tiaa.case_management_rs.integration.exp_ag;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TaskHistoryEventRowMapper extends AbstractRowMapper<TaskHistoryEvent> {
	@Override
	public TaskHistoryEvent mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		return new TaskHistoryEvent(getStringTrimmed(resultSet, "tskid"), resultSet.getInt("pidate"), resultSet.getInt("starttime"));
	}
}