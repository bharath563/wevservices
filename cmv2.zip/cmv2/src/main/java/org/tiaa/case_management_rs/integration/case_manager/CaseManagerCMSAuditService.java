package org.tiaa.case_management_rs.integration.case_manager;

import java.util.Date;

import org.jvnet.hk2.annotations.Service;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.domain.CMSAudit;
import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.ProcessingStatus;
import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;
import org.tiaa.case_management_rs.repository.CMSAuditHistoryRepository;
import org.tiaa.case_management_rs.repository.CMSAuditRepository;
import org.tiaa.case_management_rs.repository.CMSAuditService;

@Service
public class CaseManagerCMSAuditService extends CMSAuditService {
	@Autowired
	private CMSAuditRepository cmsAuditRepository;
	@Autowired
	private CMSAuditHistoryRepository cmsAuditHistoryRepository;

	public CMSAuditHistory createCMSAuditHistory(CaseDetails caseDetails) {
		return createCMSAuditHistory(caseDetails, false);
	}

	public CMSAuditHistory createCMSAuditHistory(CaseDetails caseDetails, boolean cthEvent) {
		CMSAudit cmsAudit = cmsAuditRepository.findByTaskId(caseDetails.getCaseId());
		if (cmsAudit == null) {
			cmsAudit = createAuditEntry(caseDetails);
			cmsAudit = cmsAuditRepository.saveAndFlush(cmsAudit);
		}
		CMSAuditHistory cmsAuditHistory = createCMSAuditHistoryInternal(caseDetails);
		cmsAuditHistory.setCthEvent(cthEvent);
		cmsAuditHistory.setCmsAudit(cmsAudit);
		cmsAudit.getCmsAuditHistories().add(cmsAuditHistory);
		//
		return cmsAuditHistoryRepository.saveAndFlush(cmsAuditHistory);
	}

	private CMSAuditHistory createCMSAuditHistoryInternal(CaseDetails caseDetails) {
		CMSAuditHistory cmsAuditHistory = new CMSAuditHistory();
		cmsAuditHistory.setCreatedDate(new Date());
		cmsAuditHistory.setComments("");
		cmsAuditHistory.setCthRequestStatus(caseDetails.getCthStatus());
		cmsAuditHistory.setTaskStatus(caseDetails.getCaseStatus());
		//
		cmsAuditHistory.setStatus(ProcessingStatus.InProgress.name());
		cmsAuditHistory.setRetryAttempt(0);
		cmsAuditHistory.setTaskId(caseDetails.getCaseId());
		cmsAuditHistory.setStartDate(caseDetails.getStartDate());
		cmsAuditHistory.setStartTime(caseDetails.getStartTime());
		return cmsAuditHistory;
	}

	private CMSAudit createAuditEntry(CaseDetails caseDetails) {
		CMSAudit cmsAudit = new CMSAudit();
		cmsAudit.setCaseId(caseDetails.getCaseId());
		cmsAudit.setTaskType(caseDetails.getCaseType());
		cmsAudit.setTaskId(caseDetails.getCaseId());
		cmsAudit.setCthOrchestrationId(caseDetails.getCthOrchestrationId());
		cmsAudit.setSystem(caseDetails.getSystem());
		cmsAudit.setCreatedDate(new Date());
		return cmsAudit;
	}
}
