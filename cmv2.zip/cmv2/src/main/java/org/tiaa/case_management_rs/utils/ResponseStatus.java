package org.tiaa.case_management_rs.utils;

import javax.ws.rs.core.Response.Status;

public enum ResponseStatus {

	INFO(Status.OK), ERROR(Status.OK), WARNING(Status.OK), VALIDATION(Status.BAD_REQUEST);

	private final Status value;

	ResponseStatus(Status v) {
		this.value = v;
	}

	public Status value() {
		return this.value;
	}
}
