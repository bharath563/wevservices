package org.tiaa.case_management_rs.model;

import org.tiaa.esb.powerimage.createtask.types.Identifier;

public class IdentifierInfo {

	private String fieldName;
	private Identifier identifier;

	public String getFieldName() {
		return this.fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public Identifier getIdentifier() {
		return this.identifier;
	}

	public void setIdentifier(Identifier identifier) {
		this.identifier = identifier;
	}

}
