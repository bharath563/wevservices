package org.tiaa.case_management_rs.integration.icm.binding;

import javax.xml.bind.annotation.XmlAttribute;

public class ElementListType {

	@XmlAttribute
	public String element;
}
