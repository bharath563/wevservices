package org.tiaa.case_management_rs.integration.exp_ag;

import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.TaskInfo;

public interface EXPAGTaskProcessor {
	void processTask(TaskInfo taskInfo);
	void processTask(TaskInfo taskInfo, CMSAuditHistory cmsAuditHistory);
}
