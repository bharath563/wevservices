package org.tiaa.case_management_rs.integration.cth;

import org.tiaa.case_management_rs.domain.TaskDetails;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.esb.partyrequest.types.UpdatePartyRequest;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;

public class UpdateCTHContext extends AbstractContext implements CTHContext {
	private CaseInfo caseInfo;
	private UpdatePartyRequest updatePartyRequest;
	private String cthOrchestrationId;
	private String cthRequestId;
	private boolean customerNumberUpdated = false;

	public UpdateCTHContext() {
		super();
	}

	public UpdateCTHContext(TaskInfo taskInfo) {
		super();
		setTaskDetails(new TaskDetails(taskInfo));
	}

	public CaseInfo getCaseInfo() {
		return caseInfo;
	}

	public UpdatePartyRequest getUpdatePartyRequest() {
		return updatePartyRequest;
	}

	public void setCaseInfo(CaseInfo caseInfo) {
		this.caseInfo = caseInfo;
	}

	public void setUpdatePartyRequest(UpdatePartyRequest updatePartyRequest) {
		this.updatePartyRequest = updatePartyRequest;
	}

	public String getCthOrchestrationId() {
		return cthOrchestrationId;
	}

	public void setCthOrchestrationId(String cthOrchestrationId) {
		this.cthOrchestrationId = cthOrchestrationId;
	}

	public void setCthRequestId(long requestIdentifier) {
		this.cthRequestId = String.valueOf(requestIdentifier);
	}

	public String getCthRequestId() {
		return cthRequestId;
	}

	public void setCthRequestId(String cthRequestId) {
		this.cthRequestId = cthRequestId;
	}

	@Override
	public String toString() {
		return "UpdateCTHContext [caseInfo=" + caseInfo + ", updatePartyRequest=" + updatePartyRequest + ", cthOrchestrationId=" + cthOrchestrationId + ", cthRequestId="
				+ cthRequestId + "]";
	}

	public boolean isCustomerNumberUpdated() {
		return customerNumberUpdated;
	}

	public void setCustomerNumberUpdated(boolean customerNumberUpdated) {
		this.customerNumberUpdated = customerNumberUpdated;
	}
}
