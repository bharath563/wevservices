package org.tiaa.case_management_rs.integration.plan_sponsor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.case_management_rs.common.Processor;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.esb.plansponsor.types.ContactResponse;

public class ContactResponseProcessor implements Processor<String, ContactResponse> {
	private static final Logger LOG = LoggerFactory.getLogger(ContactResponseProcessor.class);
	private PlanSponosrRSService planSponosrRSService;

	public ContactResponse process(String customerNumber) {
		if (CommonUtil.isNullOrEmptyAfterTrim(customerNumber)) {
			LOG.error("customerNumber is null");
			return null;
		}
		LOG.debug("customerNumber:{}", customerNumber);
		return planSponosrRSService.getContact(customerNumber);
	}

	public void setPlanSponosrRSService(PlanSponosrRSService planSponosrRSService) {
		this.planSponosrRSService = planSponosrRSService;
	}
}