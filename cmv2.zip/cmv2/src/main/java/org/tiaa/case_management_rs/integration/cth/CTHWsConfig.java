package org.tiaa.case_management_rs.integration.cth;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.Marshaller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.retry.RetryException;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.ws.FaultAwareWebServiceMessage;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.soap.security.xwss.XwsSecurityInterceptor;
import org.springframework.ws.soap.security.xwss.callback.SimpleUsernamePasswordCallbackHandler;
import org.springframework.ws.transport.WebServiceConnection;
import org.springframework.ws.transport.http.HttpComponentsMessageSender;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.common.CMSTaskTypeService;
import org.tiaa.case_management_rs.common.ClientEndpointInterceptor;
import org.tiaa.case_management_rs.common.ExceptionHandler;
import org.tiaa.case_management_rs.common.PropertiesProvider;

import org.tiaa.atom.core.security.SecretKeyLoader;

@Configuration
public class CTHWsConfig {
	private static final Logger LOG = LoggerFactory.getLogger(CTHWsConfig.class);
	private static final String GLOBAL_SERVICE_TIMEOUT = "60000";// default value
	private static final String MAX_SERVICE_CONNECTIONS = "20";// default value
	private boolean bindClasses = true;
	//
	@Value("${cthWSURL}")
	private String cthWSURL = "cth.ws.url";
	private boolean setMaxConnectionPerHost;

	@Bean
	public PropertiesProvider propertiesProvider() {
		return new PropertiesProvider();
	}

	@Bean
	public CMSTaskTypeService cmsTaskTypeService() {
		return new CMSTaskTypeService();
	}

	@Bean
	public WebServiceGatewaySupport cthWebServiceGatewaySupport() {
		WebServiceGatewaySupport webServiceGatewaySupport = new ESBWebServiceGatewaySupport();
		Jaxb2Marshaller jaxb2Marshaller = cthJaxb2Marshaller();
		webServiceGatewaySupport.setMarshaller(jaxb2Marshaller);
		webServiceGatewaySupport.setUnmarshaller(jaxb2Marshaller);
		ExceptionHandler.initalize(webServiceGatewaySupport);
		return webServiceGatewaySupport;
	}

	public HttpComponentsMessageSender commonsHttpMessageSender() {
		Map<String, String> connections = new HashMap<String, String>();
		connections.put("*", MAX_SERVICE_CONNECTIONS);
		//
		HttpComponentsMessageSender httpComponentsMessageSender = new HttpComponentsMessageSender();
		httpComponentsMessageSender.setConnectionTimeout(Integer.parseInt(GLOBAL_SERVICE_TIMEOUT));
		httpComponentsMessageSender.setReadTimeout(Integer.parseInt(GLOBAL_SERVICE_TIMEOUT));
		httpComponentsMessageSender.setMaxTotalConnections(Integer.parseInt(MAX_SERVICE_CONNECTIONS));
		if (setMaxConnectionPerHost) {
			try {
				httpComponentsMessageSender.setMaxConnectionsPerHost(connections);
			} catch (URISyntaxException e) {
				LOG.error("Error setting Max Connections Per Host: " + e.getMessage(), e);
			}
		}
		return httpComponentsMessageSender;
	}

	@Bean
	public WebServiceTemplate cthWebServiceTemplate() {
		final boolean checkConnectionForError = true;
		final boolean checkConnectionForFault = false;
		WebServiceTemplate webServiceTemplate = new WebServiceTemplate() {
			@Override
			protected boolean hasFault(WebServiceConnection connection, WebServiceMessage response) throws IOException {
				if (response instanceof FaultAwareWebServiceMessage) {
					FaultAwareWebServiceMessage faultMessage = (FaultAwareWebServiceMessage) response;
					return faultMessage.hasFault();
				} else {
					return false;
				}
			}
		};
		LOG.debug("cthWSURL:{}", cthWSURL);
		Jaxb2Marshaller jaxb2Marshaller = cthJaxb2Marshaller();
		webServiceTemplate.setDefaultUri(cthWSURL);
		webServiceTemplate.setMarshaller(jaxb2Marshaller);
		webServiceTemplate.setUnmarshaller(jaxb2Marshaller);
		webServiceTemplate.setMessageSender(commonsHttpMessageSender());
		webServiceTemplate.setInterceptors(clientInterceptors());
		webServiceTemplate.setCheckConnectionForError(checkConnectionForError);
		webServiceTemplate.setCheckConnectionForFault(checkConnectionForFault);
		ExceptionHandler.initalize(webServiceTemplate);
		return webServiceTemplate;
	}

	public ClientInterceptor[] clientInterceptors() {
		ClientInterceptor[] clientInterceptors = new ClientInterceptor[2];
		clientInterceptors[0] = xwsSecurityInterceptor();
		clientInterceptors[1] = clientEndpointInterceptor();
		return clientInterceptors;
	}

	@Bean
	public CTHWebService cthWebService() {
		CTHWebService cthWebService = new CTHWebService();
		cthWebService.setCthWebServiceTemplate(cthWebServiceTemplate());
		return cthWebService;
	}

	public CTHWebServiceLogger cthWebServiceLogger() {
		CTHWebServiceLogger cthWebServiceLogger = new CTHWebServiceLogger(cthJaxb2Marshaller());
		cthWebServiceLogger.setCthWebServiceTemplate(cthWebServiceTemplate());
		return cthWebServiceLogger;
	}

	public ClientEndpointInterceptor clientEndpointInterceptor() {
		return new ClientEndpointInterceptor();
	}

	//@Bean
	public XwsSecurityInterceptor xwsSecurityInterceptor() {
		ClassPathResource classPathResource = new ClassPathResource("ESBPolicy.xml", CTHWsConfig.class);
		XwsSecurityInterceptor xwsSecurityInterceptor = new XwsSecurityInterceptor();
		xwsSecurityInterceptor.setPolicyConfiguration(classPathResource);
		xwsSecurityInterceptor.setCallbackHandler(simpleUsernamePasswordCallbackHandlerForCTH());
		ExceptionHandler.initalize(xwsSecurityInterceptor, true);
		return xwsSecurityInterceptor;
	}

	@Bean
	public SimpleUsernamePasswordCallbackHandler simpleUsernamePasswordCallbackHandlerForCTH() {
		SimpleUsernamePasswordCallbackHandler springUsernamePasswordCallbackHandler = new SimpleUsernamePasswordCallbackHandler();
		springUsernamePasswordCallbackHandler.setUsername(AppConstants.APPLICATION_NAME);
		springUsernamePasswordCallbackHandler.setPassword(SecretKeyLoader.getSecretKey(AppConstants.APPLICATION_NAME));
		return springUsernamePasswordCallbackHandler;
	}

	@Bean
	public Jaxb2Marshaller cthJaxb2Marshaller() {
		Map<String, Object> marshallerProperties = new HashMap<String, Object>();
		marshallerProperties.put(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		//
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		bindClasses(jaxb2Marshaller, //
				org.tiaa.esb.partyrequest.types.ObjectFactory.class, //
				org.tiaa.esb.ping.types.ObjectFactory.class, //
				org.tiaa.esb.stats.types.ObjectFactory.class, //
				org.tiaa.esb.sinfo.types.ObjectFactory.class);
		ExceptionHandler.initalize(jaxb2Marshaller);
		return jaxb2Marshaller;
	}

	@Bean
	public ServiceRequestWorkflowJaxbMarshaller serviceRequestWorkflowJaxbMarshaller() {
		ServiceRequestWorkflowJaxbMarshaller serviceRequestWorkflowJaxbMarshaller = new ServiceRequestWorkflowJaxbMarshaller();
		serviceRequestWorkflowJaxbMarshaller.setServiceRequestWorkflowJaxb2Marshaller(serviceRequestWorkflowJaxb2Marshaller());
		return serviceRequestWorkflowJaxbMarshaller;
	}
	
	@Bean
	public Jaxb2Marshaller serviceRequestWorkflowJaxb2Marshaller() {
		Map<String, Object> marshallerProperties = new HashMap<String, Object>();
		marshallerProperties.put(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		//
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		jaxb2Marshaller.setClassesToBeBound(org.tiaa.esb.servicerequest_workflow.types.ObjectFactory.class);
		ExceptionHandler.initalize(jaxb2Marshaller);
		return jaxb2Marshaller;
	}

	@Bean
	public CTHWSRetryConfiguration cthWSRetryConfiguration() {
		return new CTHWSRetryConfiguration(propertiesProvider());
	}

	@Bean
	public RetryTemplate cthWSRetryTemplate() {
		HashMap<Class<? extends Throwable>, Boolean> retryableExceptionMap = new HashMap<Class<? extends Throwable>, Boolean>();
		retryableExceptionMap.put(RetryException.class, Boolean.TRUE);
		//
		CTHWSRetryConfiguration config = cthWSRetryConfiguration();
		SimpleRetryPolicy simpleRetryPolicy = new SimpleRetryPolicy(config.getRetryAttempts(), retryableExceptionMap);
		//
		FixedBackOffPolicy fixedBackOffPolicy = new FixedBackOffPolicy();
		fixedBackOffPolicy.setBackOffPeriod(config.getBackOffPeriod());
		//
		RetryTemplate retryTemplate = new RetryTemplate();
		retryTemplate.setBackOffPolicy(fixedBackOffPolicy);
		retryTemplate.setRetryPolicy(simpleRetryPolicy);
		return retryTemplate;
	}

	private void bindClasses(Jaxb2Marshaller jaxb2Marshaller, Class<?>... classes) {
		if (bindClasses) {
			jaxb2Marshaller.setClassesToBeBound(classes);
		} else {
			String[] names = new String[classes.length];
			for (int ii = 0; ii < names.length; ii++) {
				names[ii] = classes[ii].getPackage().getName();
			}
			jaxb2Marshaller.setContextPaths(names);
		}
	}

	private static class ESBWebServiceGatewaySupport extends WebServiceGatewaySupport {
	}
}
