package org.tiaa.case_management_rs.integration.plan_sponsor;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.Marshaller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.xml.MarshallingHttpMessageConverter;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.web.client.RestTemplate;

import org.tiaa.case_management_rs.common.CustomRestTemplate;
import org.tiaa.case_management_rs.common.ExceptionHandler;
import org.tiaa.case_management_rs.common.SInfoHeaderAdderClientHttpRequestInterceptor;

@Configuration
public class PlanSponosrRSConfig {
	@Value("${planSponosrRsServiceURL}")
	private String planSponosrRsServiceURL;
	@Value("${atom.env-id}")
	private String envId;
	private boolean formatJaxbOutput = true;

	@Bean
	public PlanSponosrRSService planSponosrRsService() {
		if ("dev-0".equals(envId)) {
			planSponosrRsServiceURL = "http://ut-rs-int5-dpw.ops.tiaa-cref.org/plan-sponsor-rs-v1";
		}
		PlanSponosrRSService planSponosrRsService = new PlanSponosrRSService();
		planSponosrRsService.setUri(planSponosrRsServiceURL);
		planSponosrRsService.setPlanSponsorRestTemplate(planSponsorRestTemplate());
		return planSponosrRsService;
	}

	@Bean
	public Jaxb2Marshaller planSponsorJaxb2Marshaller() {
		Map<String, Object> marshallerProperties = new HashMap<String, Object>();
		marshallerProperties.put(Marshaller.JAXB_FORMATTED_OUTPUT, formatJaxbOutput);
		//
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		jaxb2Marshaller.setClassesToBeBound(org.tiaa.esb.plansponsor.types.ObjectFactory.class);
		ExceptionHandler.initalize(jaxb2Marshaller);
		return jaxb2Marshaller;
	}

	@Bean
	public RestTemplate planSponsorRestTemplate() {
		Jaxb2Marshaller planSponsorJaxb2Marshaller = planSponsorJaxb2Marshaller();
		//
		MarshallingHttpMessageConverter marshallingHttpMessageConverter = new PlanSponsorMarshallingHttpMessageConverter();
		marshallingHttpMessageConverter.setMarshaller(planSponsorJaxb2Marshaller);
		marshallingHttpMessageConverter.setUnmarshaller(planSponsorJaxb2Marshaller);
		//
		ArrayList<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		messageConverters.add(marshallingHttpMessageConverter);
		//
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new SInfoHeaderAdderClientHttpRequestInterceptor("application/vnd.tiaa.plan-sponsor-rs-v1.0+xml"));
		//
		RestTemplate restTemplate = new CustomRestTemplate();
		restTemplate.setInterceptors(clientHttpRequestInterceptors);
		restTemplate.setMessageConverters(messageConverters);
		return restTemplate;
	}

	@Bean
	public ContactResponseProcessor contactResponseProcessor() {
		ContactResponseProcessor contactResponseProcessor = new ContactResponseProcessor();
		contactResponseProcessor.setPlanSponosrRSService(planSponosrRsService());
		return contactResponseProcessor;
	}

	public static class PlanSponsorMarshallingHttpMessageConverter extends MarshallingHttpMessageConverter {
		@Override
		public boolean canRead(Class<?> clazz, MediaType mediaType) {
			return canRead(mediaType);
		}

		@Override
		protected boolean canRead(MediaType mediaType) {
			if (mediaType == null) {
				return false;
			}
			String type = mediaType.getType();
			if ("application/vnd.tiaa.plan-sponsor-rs-v1.0+xml;profile=plan-sponsor-rs-v1.0.xsd".equals(type)) {
				return true;
			}
			if (MediaType.APPLICATION_XML.getType().equals(type)) {
				return true;
			}
			return false;
		}
	}
}
