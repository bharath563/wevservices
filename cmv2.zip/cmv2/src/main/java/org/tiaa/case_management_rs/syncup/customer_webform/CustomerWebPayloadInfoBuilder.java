package org.tiaa.case_management_rs.syncup.customer_webform;

import org.w3c.dom.Element;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.integration.cth.CreateCTHContext;
import org.tiaa.case_management_rs.integration.cth.PayloadInfoBuilder;
import org.tiaa.esb.customer_webform.types.AnyXMLSkipType;
import org.tiaa.esb.customer_webform.types.CTHClob;
import org.tiaa.esb.customer_webform.types.Documents;
import org.tiaa.esb.customer_webform.types.OtherData;
import org.tiaa.esb.customer_webform.types.Request;
import org.tiaa.esb.customer_webform.types.Webform;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;

public class CustomerWebPayloadInfoBuilder extends PayloadInfoBuilder {
	private Jaxb2Marshaller customerWebFormJaxb2Marshaller;

	public CustomerWebPayloadInfoBuilder(String requestSchemaName, String requestSchemaVersion) {
		super(requestSchemaName, requestSchemaVersion);
	}

	@Override
	protected Element setRequestInfoAnyElement(CreateCTHContext context) {
		return toElement(createCTHClobType(context), customerWebFormJaxb2Marshaller);
	}

	private CTHClob createCTHClobType(CreateCTHContext context) {
		CTHClob cthClobType = new CTHClob();
		Request request = new Request();
		cthClobType.setRequest(request);
		if (setDocuments) {
			cthClobType.setDocuments(new Documents());
		}
		CaseInfo caseInfoType = mapCaseInfo(context);
		//
		AnyXMLSkipType value = new AnyXMLSkipType();
		value.setAny(toElement(caseInfoType, servicerequestWorkflowJaxb2Marshaller));
		//
		Webform webform = new Webform();
		webform.setWorkFlowXML(value);
		//
		OtherData otherDataType = new OtherData();
		otherDataType.setWebform(webform);
		//
		cthClobType.setOtherData(otherDataType);
		return cthClobType;
	}

	public void setCustomerWebFormJaxb2Marshaller(Jaxb2Marshaller customerWebFormJaxb2Marshaller) {
		this.customerWebFormJaxb2Marshaller = customerWebFormJaxb2Marshaller;
	}
}