package org.tiaa.case_management_rs.poller;

public class SchedulerConfiguration {
	private static final int RETRY_CORE_POOL_SIZE = 5;
	private static final int RETRY_MAX_POOL_SIZE = 10;
	private static final int RETRY_QUEUE_CAPACITY = 20;
	private static final int TASK_SCHEDULER_POOL_SIZE = 10;

	public int getRetryCorePoolSize() {
		return RETRY_CORE_POOL_SIZE;
	}

	public int getRetryMaxPoolSize() {
		return RETRY_MAX_POOL_SIZE;
	}

	public int getRetryQueueCapacity() {
		return RETRY_QUEUE_CAPACITY;
	}

	public int getTaskSchedulerPoolSize() {
		return TASK_SCHEDULER_POOL_SIZE;
	}
}
