package org.tiaa.case_management_rs.cmts.helper;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.Properties;
import org.tiaa.esb.case_management_rs_v2.type.Status;
import org.tiaa.esb.case_management_rs_v2.type.Statuses;
import org.tiaa.esb.case_management_rs_v2.type.Task;
import org.tiaa.esb.case_management_rs_v2.type.Tasks;
import org.tiaa.esb.icm.types.NigoTask;

@Component
public class NigoTaskResponseHelper {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(NigoTaskResponseHelper.class);

	private static ObjectMapper objectMapper = new ObjectMapper();

	public Processes nigoTasksToProcesses(List<NigoTask> nigoTasks) {
		Processes processes = new Processes();
		if (!nigoTasks.isEmpty()) {
			for (Object nigoTaskResponseJSON : nigoTasks) {

				try {
					String taskResponseJSONString = this.objectMapper
							.writeValueAsString(nigoTaskResponseJSON);
					this.objectMapper.configure(
							DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
							false);
					NigoTask nigoTaskResponse = this.objectMapper.readValue(
							taskResponseJSONString, NigoTask.class);

					Process process = new Process();
					Tasks tasks = new Tasks();
					Task task = new Task();

					Statuses statuses = new Statuses();
					Status status = new Status();
					// Properties nigoProperties = new Properties();
					Properties taskProperties = new Properties();

					process.setAppName(nigoTaskResponse.getAppName());
					process.setProcessId(nigoTaskResponse.getProcessId());
					process.setProcessType(nigoTaskResponse.getRequestType());

					HashMap<String, Object> additionalIdentifiers = nigoTaskResponse
							.getProcessIdentifiers();

					if (additionalIdentifiers != null) {
						for (String key : additionalIdentifiers.keySet()) {
							NameValue nameValue = new NameValue();
							nameValue.setName(key);
							Object entryValue = additionalIdentifiers.get(key);
							if (String.class.isInstance(entryValue)) {
								nameValue.setValue((String) entryValue);
							} else if (Integer.class.isInstance(entryValue)) {
								((Integer) entryValue).longValue();
								nameValue.getNumValue().add(
										BigInteger
												.valueOf(((Integer) entryValue)
														.longValue()));
							} else if (Boolean.class.isInstance(entryValue)) {
								nameValue.setBooleanValue((Boolean) entryValue);
							} else if (Float.class.isInstance(entryValue)) {
								nameValue.setDecimalValue(BigDecimal
										.valueOf(((Float) entryValue)
												.floatValue()));
							} else if (Date.class.isInstance(entryValue)) {
								nameValue
								.setDateValue(DateUtil
										.toXMLGregorianCalendar(((Date) entryValue)));
							}
							taskProperties.getProperties().add(nameValue);
						}
					}

					HashMap<String, Object> taskDetails = nigoTaskResponse
							.getTaskDetails();
					for (String key : taskDetails.keySet()) {

						if (key.equalsIgnoreCase("taskId") && taskDetails.get(key) != null) {
							task.setID(taskDetails.get(key).toString());
						} else if (key.equalsIgnoreCase("taskName") && taskDetails.get(key) != null) {
							task.setName(taskDetails.get(key).toString());
						} else if (key.equalsIgnoreCase("taskType")
								&& taskDetails.get(key) != null) {
							task.setType(taskDetails.get(key).toString());
						} else if (key.equalsIgnoreCase("assignedTo")
								&& taskDetails.get(key) != null) {
							task.setAssignedTo(taskDetails.get(key).toString());
						}

						else if (key.equalsIgnoreCase("taskCreatedDate") 
								&& taskDetails.get(key) != null) {
							task.setCreateDate(DateUtil.toXMLGregorianCalendarDateOnly(DateUtil
									.parseDateTimeWithoutMilliseconds(taskDetails
											.get(key).toString())));
							task.setCreateTime(DateUtil.toXMLGregorianCalendarTimeOnly(DateUtil
									.parseDateTimeWithoutMilliseconds(taskDetails
											.get(key).toString())));
						} else if (key.equalsIgnoreCase("taskReceivedDate")
								&& taskDetails.get(key) != null) {
							task.setReceivedDate(DateUtil.toXMLGregorianCalendarDateOnly(DateUtil
									.parseDateTimeWithoutMilliseconds(taskDetails
											.get(key).toString())));
							task.setReceivedTime(DateUtil.toXMLGregorianCalendarTimeOnly(DateUtil
									.parseDateTimeWithoutMilliseconds(taskDetails
											.get(key).toString())));
						} else if (key.equalsIgnoreCase("taskLastUpdatedDate")
								&& taskDetails.get(key) != null) {
							task.setLastUpdatedDate(DateUtil.toXMLGregorianCalendarDateOnly(DateUtil
									.parseDateTimeWithoutMilliseconds(taskDetails
											.get(key).toString())));
							task.setLastUpdatedTime(DateUtil.toXMLGregorianCalendarTimeOnly(DateUtil
									.parseDateTimeWithoutMilliseconds(taskDetails
											.get(key).toString())));
						} else if (key.equalsIgnoreCase("taskCompletedDate")
								&& taskDetails.get(key) != null) {
							task.setCompleteDate(DateUtil.toXMLGregorianCalendarDateOnly(DateUtil
									.parseDateTimeWithoutMilliseconds(taskDetails
											.get(key).toString())));
							task.setCompleteTime(DateUtil.toXMLGregorianCalendarTimeOnly(DateUtil
									.parseDateTimeWithoutMilliseconds(taskDetails
											.get(key).toString())));
						} else if (key.equalsIgnoreCase("status")
								&& taskDetails.get(key) != null) {
							status.setSts(taskDetails.get(key).toString());
							statuses.getSts().add(status);

						}

					}

					NameValue nameValuePin = new NameValue();
					nameValuePin.setName("PIN");
					nameValuePin.setValue(nigoTaskResponse.getPin());
					taskProperties.getProperties().add(nameValuePin);

					NameValue nameValueDept = new NameValue();
					nameValueDept.setName("Department");
					nameValueDept.setValue(nigoTaskResponse.getDepartment());
					taskProperties.getProperties().add(nameValueDept);

					NameValue nameValueDeptDesc = new NameValue();
					nameValueDeptDesc.setName("DepartmentDescription");
					nameValueDeptDesc.setValue(nigoTaskResponse
							.getDepartmentDescription());
					taskProperties.getProperties().add(nameValueDeptDesc);

					task.setTaskProperties(taskProperties);

					task.setStatusHistory(statuses);
					tasks.getTasks().add(task);
					process.setTasks(tasks);
					processes.getProcesses().add(process);

				} catch (Exception e) {
					LOGGER.error("Exception while converting NIGO tasks to Processes:"
							+ e.getMessage());
				}
			}
		}

		return processes;
	}
}

