package org.tiaa.case_management_rs.integration.exp_ag;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.common.CMSTaskTypeService;
import org.tiaa.case_management_rs.domain.CMSPollerLog;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.poller.PollingContext;
import org.tiaa.case_management_rs.utils.CommonUtil;

public class EXPAGTasksDAO {
	private static final Logger LOG = LoggerFactory.getLogger(EXPAGTasksDAO.class);
	@Autowired
	private JdbcTemplate expagJdbcTemplate;
	@Autowired
	private CMSTaskTypeService cmsTaskTypeService;
	private boolean debugSql;
	//
	private EXPAGTaskInfoMapper taskInfoMapper = new EXPAGTaskInfoMapper();
	private EXPAGDocumentMapper documentMapper = new EXPAGDocumentMapper();
	private TaskHistoryEventRowMapper taskHistoryEventRowMapper = new TaskHistoryEventRowMapper();
	private EXPAGTasksQueryProvider queryProvider;
	private static Object[] emptyQueryParams = new Object[] {};

	public List<EXPAGDocument> getAllDocumentsForInProgressTasks(PollingContext pollingContext) {
		List<String> taskIdsInProgress = pollingContext.getTaskIdsInProgress();
		if (taskIdsInProgress.isEmpty()) {
			return Collections.emptyList();
		}
		String taskIdsInProgressCommaSeparated = CommonUtil.toStringSingleQuoted(taskIdsInProgress);
		return getAllDocumentsForInProgressTasks(taskIdsInProgressCommaSeparated);
	}

	public List<EXPAGDocument> getAllDocumentsForInProgressTasks(String taskIdsInProgressCommaSeparated) {
		LOG.debug("taskIdsInProgressCommaSeparated:{}", taskIdsInProgressCommaSeparated);
		if (CommonUtil.isNullOrEmpty(taskIdsInProgressCommaSeparated)) {
			return Collections.emptyList();
		}
		String sql = queryProvider.getAllDocumentsUploadedThroughEXPAGUI().replace(":taskIds", taskIdsInProgressCommaSeparated);
		sql = getTaskTypesCommaSeparatedSql(sql);
		debugSQL(sql);
		return uniqueDocuments(query(sql, documentMapper));
	}

	public List<EXPAGDocument> getAllDocumentsForCompletedTasks(PollingContext pollingContext) {
		List<String> taskIdsCompletedOrCancelled = pollingContext.getTaskIdsCompletedOrCancelled();
		if (taskIdsCompletedOrCancelled.isEmpty()) {
			return Collections.emptyList();
		}
		String taskIdsCompletedOrCancelledCommaSeparated = CommonUtil.toStringSingleQuoted(taskIdsCompletedOrCancelled);
		return getAllDocumentsForCompletedTasks(taskIdsCompletedOrCancelledCommaSeparated);
	}

	public List<EXPAGDocument> getAllDocumentsForCompletedTasks(String taskIdsCompletedOrCancelledCommaSeparated) {
		LOG.debug("taskIdsCompletedOrCancelledCommaSeparated:{}", taskIdsCompletedOrCancelledCommaSeparated);
		if (CommonUtil.isNullOrEmpty(taskIdsCompletedOrCancelledCommaSeparated)) {
			return Collections.emptyList();
		}
		String sql = queryProvider.getAllDocumentsUploadedDuringTaskCompletionThroughEXPAGUI().replace(":taskIds", taskIdsCompletedOrCancelledCommaSeparated);
		sql = getTaskTypesCommaSeparatedSql(sql);
		debugSQL(sql);
		return uniqueDocuments(query(sql, documentMapper));
	}

	public List<EXPAGDocument> getDocumentsForCompletedTasks(PollingContext pollingContext) {
		String taskIdsCompletedOrCancelledCommaSeparated = pollingContext.getTaskIdsCompletedOrCancelledCommaSeparated();
		LOG.debug("taskIdsCompletedOrCancelledCommaSeparated:{}", taskIdsCompletedOrCancelledCommaSeparated);
		if (CommonUtil.isNullOrEmpty(taskIdsCompletedOrCancelledCommaSeparated)) {
			return Collections.emptyList();
		}
		String sql = queryProvider.getNewDocumentsUploadedDuringTaskCompletionThroughEXPAGUI().replace(":taskIds", taskIdsCompletedOrCancelledCommaSeparated);
		sql = getTaskTypesCommaSeparatedSql(sql);
		debugSQL(sql);
		return uniqueDocuments(query(sql, documentMapper, pollingContext));
	}

	public List<EXPAGDocument> getDocumentsSince(PollingContext pollingContext, int minutesBack) {
		String sql = getTaskTypesCommaSeparatedSql(queryProvider.getNewDocumentsUploadedThroughEXPAGUI());
		return uniqueDocuments(query(sql, documentMapper, getQueryParamsXMinutesBack(pollingContext, minutesBack)));
	}

	public List<TaskHistoryEvent> getTaskHistoryEventsInLastXMinutes(PollingContext pollingContext) {
		String sql = getTaskTypesCommaSeparatedSql(queryProvider.getTaskEventsForTaskTypes());
		return query(sql, taskHistoryEventRowMapper, pollingContext);
	}

	public TaskInfo getTaskInfo(TaskHistoryEvent taskHistoryEvent) {
		final String taskId = taskHistoryEvent.getTaskId();
		Object[] args = new Object[] { taskHistoryEvent.getStartDate(), taskHistoryEvent.getStartTime(), taskId };
		List<TaskInfo> list = query(queryProvider.getTaskStatusForTaskIdOccurredAt(), taskInfoMapper, args);
		Map<String, TaskInfo> taskStatusMap = getTaskInfoMap(list);
		TaskInfo taskInfo = taskStatusMap.get(taskId);
		if (taskInfo != null) {
			taskInfo.init();
		}
		return taskInfo;
	}

	public TaskInfo getTaskInfo(TaskHistoryEvent taskHistoryEvent, EXPAGTasksQueryProvider expagTasksQueryProvider) {
		final String taskId = taskHistoryEvent.getTaskId();
		Object[] args = new Object[] { taskHistoryEvent.getStartDate(), taskHistoryEvent.getStartTime(), taskId };
		List<TaskInfo> list = query(expagTasksQueryProvider.getTaskStatusForTaskIdOccurredAt(), taskInfoMapper, args);
		Map<String, TaskInfo> taskStatusMap = getTaskInfoMap(list);
		TaskInfo taskInfo = taskStatusMap.get(taskId);
		if (taskInfo != null) {
			taskInfo.init();
		}
		return taskInfo;
	}

	public Map<String, TaskInfo> getTaskStatusMapSince(PollingContext pollingContext) {
		List<TaskInfo> taskStatusSince = getTaskStatusForTaskTypesSince(pollingContext);
		return getTaskInfoMap(taskStatusSince);
	}

	public Map<String, TaskInfo> getPlanModificationTasksInReceivedStatusSince(PollingContext pollingContext) {
		String sql = getPlanModificationTaskTypesCommaSeparatedSql(queryProvider.getTaskStatusForTaskTypesSql());
		List<TaskInfo> taskStatusSince = query(sql, taskInfoMapper, pollingContext);
		return getTaskInfoMap(taskStatusSince);
	}

	public Map<String, TaskInfo> getTaskInfoMap(Collection<TaskInfo> taskStatusSince) {
		Map<String, List<TaskInfo>> tasksByTaskId = groupByTaskId(taskStatusSince);
		Map<String, TaskInfo> taskInfoMap = new LinkedHashMap<String, TaskInfo>();
		for (Entry<String, List<TaskInfo>> entry : tasksByTaskId.entrySet()) {
			String taskId = entry.getKey();
			LOG.debug("taskId:{}", taskId);
			List<TaskInfo> tasksWithSameTaskId = entry.getValue();
			taskInfoMap.put(taskId, getLastestTaskInfo(tasksWithSameTaskId));
		}
		return taskInfoMap;
	}

	private TaskInfo getLastestTaskInfo(List<TaskInfo> tasksWithSameTaskId) {
		if (CommonUtil.isNullOrEmpty(tasksWithSameTaskId)) {
			return null;
		}
		sortByDateTime(tasksWithSameTaskId);
		for (TaskInfo taskInfo : tasksWithSameTaskId) {
			LOG.debug("taskInfo:{}", taskInfo);
		}
		//task updates sorted by date, time
		//example: 3 instances of same task at different date and time...
		Map<Date, TaskInfo> taskByDateTime = groupByDateTime(tasksWithSameTaskId);
		TaskInfo taskInfoFromMap = null;
		TaskInfo lastTask = null;
		for (Entry<Date, TaskInfo> entry : taskByDateTime.entrySet()) {
			TaskInfo taskInfo = entry.getValue();
			LOG.debug("Date:{}", entry.getKey());
			LOG.debug("taskInfo:{}", taskInfo);
			if (taskInfoFromMap == null) {
				taskInfoFromMap = taskInfo;
			} else {
				taskInfoFromMap.addIdentifiersFrom(taskInfo);
			}
			lastTask = taskInfo;
		}
		lastTask.setIdentifiers(taskInfoFromMap.getIdentifiers());
		LOG.debug("lastTask:{}", lastTask);
		LOG.debug("lastTask getIdentifiers:{}", lastTask.getIdentifiers());
		return lastTask;
	}

	public List<TaskInfo> getTaskStatusForTaskTypesSince(PollingContext pollingContext) {
		String sql = getTaskTypesCommaSeparatedSql(queryProvider.getTaskStatusForTaskTypesSql());
		return query(sql, taskInfoMapper, pollingContext);
	}

	protected String getTaskTypesCommaSeparatedSql(String sqlQuery) {
		String taskTypesCommaSeparated = cmsTaskTypeService.getCMSTaskTypesCommaSeparated(queryProvider.getCthRequestSchemaName());
		LOG.trace("taskTypesCommaSeparated:{}", taskTypesCommaSeparated);
		String sql = sqlQuery.replace(":taskTypes", "(" + taskTypesCommaSeparated + ")");
		debugSQL(sql);
		return sql;
	}

	protected String getPlanModificationTaskTypesCommaSeparatedSql(String sqlQuery) {
		String taskTypesCommaSeparated = cmsTaskTypeService.getPlanModificationCMSTaskTypesCommaSeparated();
		LOG.trace("taskTypesCommaSeparated:{}", taskTypesCommaSeparated);
		String sql = sqlQuery.replace(":taskTypes", "(" + taskTypesCommaSeparated + ")");
		debugSQL(sql);
		return sql;
	}

	private Map<Date, TaskInfo> groupByDateTime(Collection<TaskInfo> taskInfoList) {
		Map<Date, TaskInfo> taskInfoMapByDate = new LinkedHashMap<Date, TaskInfo>();
		for (TaskInfo taskInfo : taskInfoList) {
			Date taskLastUpdated = taskInfo.getTaskLastUpdated();
			TaskInfo taskInfoFromMap = taskInfoMapByDate.get(taskLastUpdated);
			if (taskInfoFromMap == null) {
				taskInfoMapByDate.put(taskLastUpdated, taskInfo);
			} else {
				taskInfoFromMap.addIdentifiersFrom(taskInfo);
			}
		}
		return taskInfoMapByDate;
	}

	private Map<String, List<TaskInfo>> groupByTaskId(Collection<TaskInfo> taskStatusSince) {
		Map<String, List<TaskInfo>> taskInfosMap = new LinkedHashMap<String, List<TaskInfo>>();
		for (TaskInfo taskInfo : taskStatusSince) {
			String taskId = taskInfo.getTaskId();
			if (!taskInfosMap.containsKey(taskId)) {
				taskInfosMap.put(taskId, new ArrayList<TaskInfo>());
			}
			taskInfosMap.get(taskId).add(taskInfo);
		}
		return taskInfosMap;
	}

	private void sortByDateTime(List<TaskInfo> taskInfoList) {
		Collections.sort(taskInfoList, new Comparator<TaskInfo>() {
			@Override
			public int compare(TaskInfo o1, TaskInfo o2) {
				Date taskLastUpdated1 = o1.getTaskLastUpdated();
				Date taskLastUpdated2 = o2.getTaskLastUpdated();
				return taskLastUpdated1.compareTo(taskLastUpdated2);
			}
		});
	}

	protected List<EXPAGDocument> uniqueDocuments(Collection<EXPAGDocument> documentsFromDB) {
		HashMap<String, EXPAGDocument> documentsMap = new HashMap<String, EXPAGDocument>();
		for (EXPAGDocument expagDocument : documentsFromDB) {
			String documentId = expagDocument.getDocumentId();
			if (!documentsMap.containsKey(documentId)) {
				documentsMap.put(documentId, expagDocument);
			} else {
				documentsMap.get(documentId).addIdentifiersFrom(expagDocument);
			}
		}
		List<EXPAGDocument> documents = new ArrayList<EXPAGDocument>(documentsMap.values());
		LOG.debug("documents:{}", documents.size());
		return documents;
	}

	protected <T> List<T> query(String sql, RowMapper<T> rowMapper) {
		return query(sql, rowMapper, emptyQueryParams);
	}

	protected <T> List<T> query(String sql, RowMapper<T> rowMapper, PollingContext pollingContext) {
		return query(sql, rowMapper, getQueryParams(pollingContext));
	}

	protected <T> List<T> query(String sql, RowMapper<T> rowMapper, Object[] args) {
		try {
			List<T> rows = expagJdbcTemplate.query(sql, args, rowMapper);
			LOG.debug("rows:{}", rows.size());
			return rows;
		} catch (DataAccessException e) {
			LOG.warn("sql:{}", sql);
			for (Object object : args) {
				LOG.warn("arg:{}", object);
			}
			LOG.warn(e.getMessage(), e);
		}
		return Collections.emptyList();
	}

	private Object[] getQueryParams(PollingContext pollingContext) {
		CMSPollerLog processingInfo = pollingContext.getPollerLog();
		int startDate = processingInfo.getLastProcessedDate();
		int startTime = processingInfo.getLastProcessedTime();
		return new Object[] { startDate, startDate, startTime };
	}

	private Object[] getQueryParamsXMinutesBack(PollingContext pollingContext, final int xMinutes) {
		CMSPollerLog processingInfo = pollingContext.getPollerLog();
		int startDate = processingInfo.getLastProcessedDate();
		final int milliSecondsPerMinute = 10000;//example: 00 05 00 00 = 5 mins
		int startTime = processingInfo.getLastProcessedTime() - (xMinutes * milliSecondsPerMinute);
		return new Object[] { startDate, startDate, startTime };
	}

	protected void debugSQL(String sql) {
		if (debugSql) {
			LOG.debug("sql: {}", sql);
		}
	}

	public void setQueryProvider(EXPAGTasksQueryProvider queryProvider) {
		this.queryProvider = queryProvider;
	}

	public TaskInfo getTaskInfo(String taskId) {
		return getTaskInfo(taskId, queryProvider);
	}

	public TaskInfo getTaskInfo(String taskId, EXPAGTasksQueryProvider queryProvider) {
		List<TaskInfo> taskInfoList = getTaskInfo(Collections.singletonList(taskId), queryProvider);
		if (taskInfoList.isEmpty()) {
			return null;
		}
		TaskInfo lastestTaskInfo = getLastestTaskInfo(taskInfoList);
		lastestTaskInfo.init();
		return lastestTaskInfo;
	}

	public List<TaskInfo> getTaskInfo(Collection<String> taskIdList) {
		return getTaskInfo(taskIdList, queryProvider);
	}

	public List<TaskInfo> getTaskInfo(Collection<String> taskIdList, EXPAGTasksQueryProvider queryProvider) {
		if (taskIdList.isEmpty()) {
			return Collections.emptyList();
		}
		String sql = getTaskIdsCommaSeparatedSql(queryProvider.getTaskStatusForTaskIdsSql(), taskIdList);
		List<TaskInfo> taskList = query(sql, taskInfoMapper);
		Map<String, TaskInfo> taskInfoMap = getTaskInfoMap(taskList);
		Collection<TaskInfo> uniqueTasks = taskInfoMap.values();
		for (TaskInfo taskInfo : uniqueTasks) {
			taskInfo.init();
		}
		return new ArrayList<TaskInfo>(uniqueTasks);
	}

	private String getTaskIdsCommaSeparatedSql(String sqlQuery, Collection<String> taskIdList) {
		String taskIdsCommaSeparated = CommonUtil.toStringSingleQuoted(taskIdList);
		LOG.trace("taskIdsCommaSeparated:{}", taskIdsCommaSeparated);
		String sql = sqlQuery.replace(":taskIds", "(" + taskIdsCommaSeparated + ")");
		debugSQL(sql);
		return sql;
	}

}
