package org.tiaa.case_management_rs.integration.exp_ag;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.domain.CMSAudit;
import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.integration.cth.RetryableCTHRecordUpdater;
import org.tiaa.case_management_rs.integration.cth.UpdateCTHContext;
import org.tiaa.case_management_rs.repository.CMSAuditService;
import org.tiaa.case_management_rs.utils.CommonUtil;

public class AbstractEXPAGTaskProcessor {
	protected RetryableCTHRecordUpdater retryableCTHRecordUpdater;
	@Autowired
	protected CMSAuditService cmsAuditService;

	protected void tryUpdateCTHRecord(TaskInfo taskInfo, CMSAuditHistory cmsAuditHistory) {
		UpdateCTHContext updateCTHContext = new UpdateCTHContext(taskInfo);
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		String cthOrchestrationId = cmsAudit.getCthOrchestrationId();
		taskInfo.setCthOrchestrationId(cthOrchestrationId);
		String cthRequestId = cmsAudit.getCthRequestId();
		taskInfo.setCthRequestId(cthRequestId);
		updateCTHContext.setCthOrchestrationId(cthOrchestrationId);
		updateCTHContext.setCthRequestId(cthRequestId);
		Object updateCTH = retryableCTHRecordUpdater.updateCTHRecord(updateCTHContext);
		if (updateCTH != null) {
			if (CommonUtil.isNullOrEmpty(cthOrchestrationId)) {
				cmsAudit.setCthOrchestrationId(updateCTHContext.getCthOrchestrationId());
			}
			if (CommonUtil.isNullOrEmpty(cthRequestId)) {
				cmsAudit.setCthRequestId(updateCTHContext.getCthRequestId());
			}
			if (cmsAudit.getCaseId() == null) {
				cmsAudit.setCaseId(taskInfo.getWorkpacketId());
			}
			cmsAuditService.markAsSuccessful(cmsAuditHistory);
		} else {
			cmsAuditService.markAsSameStatus(cmsAuditHistory);
		}
	}
}
