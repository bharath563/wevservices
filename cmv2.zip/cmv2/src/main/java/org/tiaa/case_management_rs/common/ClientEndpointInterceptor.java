package org.tiaa.case_management_rs.common;

import java.io.StringWriter;

import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.stream.StreamResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptor;
import org.springframework.ws.context.MessageContext;
import org.springframework.ws.soap.SoapMessage;
import org.springframework.xml.transform.TransformerHelper;

/**
 * The Class ClientEndpointInterceptor.
 */
public class ClientEndpointInterceptor implements ClientInterceptor {

	/** The LOG. */
	private static final Logger LOG = LoggerFactory.getLogger(ClientEndpointInterceptor.class);

	/** The log request. */
	private boolean logRequest = true;

	/** The log response. */
	private boolean logResponse = true;

	/** The log fault. */
	private boolean logFault = true;

	/** The transformer helper. */
	TransformerHelper transformerHelper = new TransformerHelper();

	/**
	 * Creates the non indenting transformer.
	 *
	 * @return the transformer
	 * @throws TransformerConfigurationException
	 *             the transformer configuration exception
	 */
	private Transformer createNonIndentingTransformer() throws TransformerConfigurationException {
		Transformer transformer = createTransformer();
		transformer.setOutputProperty("omit-xml-declaration", "yes");
		transformer.setOutputProperty("indent", "no");
		return transformer;
	}

	/**
	 * Creates the transformer.
	 *
	 * @return the transformer
	 * @throws TransformerConfigurationException
	 *             the transformer configuration exception
	 */
	protected final Transformer createTransformer() throws TransformerConfigurationException {
		return transformerHelper.createTransformer();
	}

	/**
	 * Gets the source.
	 *
	 * @param message
	 *            the message
	 * @return the source
	 */
	protected Source getSource(WebServiceMessage message) {
		if (message instanceof SoapMessage) {
			SoapMessage soapMessage = (SoapMessage) message;
			return soapMessage.getEnvelope().getSource();
		} else {
			return null;
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.ws.client.support.interceptor.ClientInterceptor#
	 * handleFault(org.springframework.ws.context.MessageContext)
	 */
	public boolean handleFault(MessageContext messageContext) throws WebServiceClientException {
		if (logFault) {
			LOG.debug("handle fault");
			try {
				logMessageSource("Fault: ", getSource(messageContext.getResponse()));
			} catch (TransformerException e) {
				LOG.warn(e.getMessage(), e);
			}
		}
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.ws.client.support.interceptor.ClientInterceptor#
	 * handleRequest(org.springframework.ws.context.MessageContext)
	 */
	public boolean handleRequest(MessageContext messageContext) throws WebServiceClientException {
		if (logRequest) {
			LOG.debug("handle request");
			try {
				logMessageSource("Request: ", getSource(messageContext.getRequest()));
			} catch (TransformerException e) {
				LOG.warn(e.getMessage(), e);
			}
		}
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.springframework.ws.client.support.interceptor.ClientInterceptor#
	 * handleResponse(org.springframework.ws.context.MessageContext)
	 */
	public boolean handleResponse(MessageContext messageContext) throws WebServiceClientException {
		if (logResponse) {
			LOG.debug("handle response");
			try {
				logMessageSource("Response: ", getSource(messageContext.getResponse()));
			} catch (TransformerException e) {
				LOG.warn(e.getMessage(), e);
			}
		}
		return false;
	}

	/**
	 * Checks if is log request.
	 *
	 * @return true, if is log request
	 */
	public boolean isLogRequest() {
		return logRequest;
	}

	/**
	 * Checks if is log response.
	 *
	 * @return true, if is log response
	 */
	public boolean isLogResponse() {
		return logResponse;
	}

	/**
	 * Log message.
	 *
	 * @param message
	 *            the message
	 */
	protected void logMessage(String message) {
		LOG.debug(message);
	}

	/**
	 * Log message source.
	 *
	 * @param logMessage
	 *            the log message
	 * @param source
	 *            the source
	 * @throws TransformerException
	 *             the transformer exception
	 */
	protected void logMessageSource(String logMessage, Source source) throws TransformerException {
		if (source != null) {
			Transformer transformer = createNonIndentingTransformer();
			StringWriter writer = new StringWriter();
			transformer.transform(source, new StreamResult(writer));
			String message = (new StringBuilder()).append(logMessage).append(writer.toString()).toString();
			logMessage(message);
		}
	}

	/**
	 * Sets the log request.
	 *
	 * @param logRequest
	 *            the new log request
	 */
	public void setLogRequest(boolean logRequest) {
		this.logRequest = logRequest;
	}

	/**
	 * Sets the log response.
	 *
	 * @param logResponse
	 *            the new log response
	 */
	public void setLogResponse(boolean logResponse) {
		this.logResponse = logResponse;
	}

	@Override
	public void afterCompletion(MessageContext messageContext, Exception ex) throws WebServiceClientException {

	}
}
