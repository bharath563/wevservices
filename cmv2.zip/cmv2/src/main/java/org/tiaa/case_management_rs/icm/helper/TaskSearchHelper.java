package org.tiaa.case_management_rs.icm.helper;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.cmts.helper.NigoTaskResponseHelper;
import org.tiaa.case_management_rs.common.Request;
import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.delegate.TaskSearchDelegate;
import org.tiaa.case_management_rs.integration.activiti.ActivitiRepositoryImpl;
import org.tiaa.case_management_rs.integration.icm.CMTSRepositoryImpl;
import org.tiaa.esb.case_management_rs_v2.type.BPMPlatforms;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;
import org.tiaa.esb.icm.types.NigoTask;
import org.tiaa.esb.icm.types.ResponseList;
import org.tiaa.esb.icm.types.TaskSearch;

@Component
public class TaskSearchHelper {

	@Autowired
	CMTSRepositoryImpl cmtsRepositoryImpl;

	@Autowired
	private NigoTaskResponseHelper nigoTaskResponseHelper;

	@Autowired
	private ActivitiRepositoryImpl activitiRepositoryImpl;

	@Autowired
	@Qualifier("activitiRepositoryImpl")
	private TaskSearchDelegate activitiDelegateImpl;

	@Autowired
	@Qualifier("cmtsRespositoryImpl")
	private TaskSearchDelegate cmtsDelegateImpl;

	private static final Logger LOGGER = LoggerFactory
			.getLogger(TaskSearchHelper.class);

	public Processes doTaskSearch(Request request) throws ExecutionException,
	InterruptedException {
		SearchRequest searchRequest = (SearchRequest) request
				.getAttribute(SEARCH_REQUEST);
		String userId = (String) request.getAttribute(USER_ID);

		TaskSearch taskSearchRequest = new TaskSearch();

		if (searchRequest.getTaskStatus() != null) {
			taskSearchRequest.setTaskStatus(searchRequest.getTaskStatus()
					.getSts());
		}

		if (searchRequest.getBPMPlatforms() != null) {
			List<String> appNames = new ArrayList<String>();
			for (String bpmPlatForm : searchRequest.getBPMPlatforms()
					.getBPMPlatforms()) {
				appNames.add(bpmPlatForm);
			}
			appNames.remove(CaseManagementConstants.APP_ACTIVITI);
			taskSearchRequest.setAppNames(appNames);
		}
		if (searchRequest.getProperties() != null
				&& searchRequest.getProperties().getProperties().size() > 0) {
			for (NameValue nameValue : searchRequest.getProperties()
					.getProperties()) {
				if (nameValue.getName().equalsIgnoreCase("PIN")) {
					List<String> pins = new ArrayList<String>();
					for (String value : nameValue.getValueList().getItems()) {
						pins.add(value);
					}
					taskSearchRequest.setPins(pins);
				}
				if (nameValue.getName().equalsIgnoreCase("NoOfDays")) {
					taskSearchRequest.setDays(nameValue.getValue());
				}
			}
		}

		List<Callable<List<NigoTask>>> searchCases = new ArrayList<Callable<List<NigoTask>>>();
		BPMPlatforms bpmPlatforms = searchRequest.getBPMPlatforms();

		if (bpmPlatforms != null && bpmPlatforms.getBPMPlatforms() != null
				&& bpmPlatforms.getBPMPlatforms().size() > 0) {
			List<String> bpmPlatformList = bpmPlatforms.getBPMPlatforms();
			boolean delegateFlag = true;

			for (String bpmPlatform : bpmPlatformList) {
				SearchInvoker searchInvoker = null;
				if ((bpmPlatform.equalsIgnoreCase("EXPAG") || bpmPlatform
						.equalsIgnoreCase("ICM")) && delegateFlag == true) {
					searchInvoker = new SearchInvoker(cmtsDelegateImpl,
							taskSearchRequest, userId);
					delegateFlag = false;
					searchCases.add(searchInvoker);
				} else if (bpmPlatform.equalsIgnoreCase("ACTIVITI")) {
					searchInvoker = new SearchInvoker(activitiDelegateImpl,
							taskSearchRequest, userId);
					searchCases.add(searchInvoker);
				}
			}
		} 
		
		List<NigoTask> combinedSearchResults = new ArrayList<NigoTask>();
		List<Future<List<NigoTask>>> results = null;
		List<NigoTask> taskList = null;

		ExecutorService executor = Executors.newFixedThreadPool(searchCases
				.size());
		try {

			results = executor.invokeAll(searchCases);
			for (Future<List<NigoTask>> future : results) {
				try {
					if (future != null) {
						taskList = future.get();
					}
				} catch (CancellationException e) {
					LOGGER.error("CancellationException: " + future.toString()
							+ " didnot return results within configured time");
				}

				if ((taskList != null) && (!taskList.isEmpty())) {
					combinedSearchResults.addAll(taskList);
				}
			}
		} catch (InterruptedException e) {
			LOGGER.error("InterruptedException: " + e.getMessage());
			throw e;
		} catch (NullPointerException e) {
			LOGGER.error("NullPointerException: " + e.getMessage());
			throw e;
		} finally {
			if (executor != null) {
				executor.shutdown();
			}
		}
		
		Processes nigoProcesses = nigoTaskResponseHelper
				.nigoTasksToProcesses(combinedSearchResults);

		return nigoProcesses;

	}

	private class SearchInvoker implements Callable<List<NigoTask>> {
		private TaskSearchDelegate taskSearchDelegate;
		private TaskSearch taskSearchRequest;
		private String userId;

		public SearchInvoker(TaskSearchDelegate taskSearchDelegate,
				TaskSearch taskSearchRequest, String userId) {
			this.taskSearchDelegate = taskSearchDelegate;
			this.taskSearchRequest = taskSearchRequest;
			this.userId = userId;
		}

		@SuppressWarnings("unchecked")
		@Override
		public List<NigoTask> call() throws Exception {
			LOGGER.debug("Invoking tasksearch for appName:"
					+ taskSearchDelegate.toString());
			ResponseList taskList = taskSearchDelegate
					.searchNigoTasks(taskSearchRequest, userId);
			return (List<NigoTask>) taskList.getResults();

		}
	}
}
