package org.tiaa.case_management_rs.syncup.customer_webform;

import javax.xml.transform.dom.DOMSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.integration.cth.CTHPayloadJaxbMarshaller;
import org.tiaa.case_management_rs.integration.cth.ServiceRequestWorkflowJaxbMarshaller;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTaskType;
import org.tiaa.esb.customer_webform.types.AnyXMLSkipType;
import org.tiaa.esb.customer_webform.types.CTHClob;
import org.tiaa.esb.customer_webform.types.OtherData;
import org.tiaa.esb.customer_webform.types.Webform;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;

@EXPAGTaskType(requestType = "CustomerWebform")
public class CustomerWebFormJaxbMarshaller implements CTHPayloadJaxbMarshaller {
	private static final Logger LOG = LoggerFactory.getLogger(CustomerWebFormJaxbMarshaller.class);
	private Jaxb2Marshaller customerWebFormJaxb2Marshaller;
	private ServiceRequestWorkflowJaxbMarshaller serviceRequestWorkflowJaxbMarshaller;

	public CaseInfo getCaseInfo(OtherData otherData) {
		Element any = getWorkflowXML(otherData);
		return serviceRequestWorkflowJaxbMarshaller.getCaseInfo(any);
	}

	public OtherData getOtherData(DOMSource domSource) {
		CTHClob cthClob = getCTHClob(domSource);
		return createOrGetOtherData(cthClob);
	}

	@Override
	public String getTaskId(Element payload) {
		Element any = getWorkflowXml(payload);
		CaseInfo caseInfo = serviceRequestWorkflowJaxbMarshaller.getCaseInfo(any);
		return serviceRequestWorkflowJaxbMarshaller.getTaskid(caseInfo);
	}

	public Element toElement(DOMSource domSource) {
		return ServiceRequestWorkflowJaxbMarshaller.toElement(getCTHClob(domSource), customerWebFormJaxb2Marshaller);
	}

	public void setCustomerWebFormJaxb2Marshaller(Jaxb2Marshaller cthJaxb2WorkflowMarshaller) {
		this.customerWebFormJaxb2Marshaller = cthJaxb2WorkflowMarshaller;
	}

	private Element getWorkflowXML(OtherData otherData) {
		return otherData.getWebform().getWorkFlowXML().getAny();
	}

	public CTHClob getCTHClob(DOMSource domSource) {
		CTHClob cthClob = (CTHClob) customerWebFormJaxb2Marshaller.unmarshal(domSource);
		LOG.debug("cthClob: {}", cthClob);
		return cthClob;
	}

	public OtherData createOrGetOtherData(CTHClob cthClob) {
		if (cthClob == null) {
			LOG.warn("cthClob is null");
			return null;
		}
		OtherData otherData = cthClob.getOtherData();
		if (otherData == null) {
			otherData = new OtherData();
			cthClob.setOtherData(otherData);
		}
		Webform webform = otherData.getWebform();
		if (webform == null) {
			webform = new Webform();
			otherData.setWebform(webform);
		}
		AnyXMLSkipType workFlowXML = webform.getWorkFlowXML();
		if (workFlowXML == null) {
			workFlowXML = new AnyXMLSkipType();
			webform.setWorkFlowXML(workFlowXML);
		}
		return otherData;
	}

	private Element getWorkflowXml(Element payload) {
		CTHClob cthClob = getCTHClob(new DOMSource(payload));
		OtherData otherData = cthClob.getOtherData();
		return getWorkflowXML(otherData);
	}

	public void setServiceRequestWorkflowJaxbMarshaller(ServiceRequestWorkflowJaxbMarshaller serviceRequestWorkflowJaxbMarshaller) {
		this.serviceRequestWorkflowJaxbMarshaller = serviceRequestWorkflowJaxbMarshaller;
	}

	public Jaxb2Marshaller getCustomerWebFormJaxb2Marshaller() {
		return customerWebFormJaxb2Marshaller;
	}
}