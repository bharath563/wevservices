package org.tiaa.case_management_rs.expag.helper;

import org.springframework.stereotype.Service;

@Service
public class ExpagCommentHelper {

	
	
}
