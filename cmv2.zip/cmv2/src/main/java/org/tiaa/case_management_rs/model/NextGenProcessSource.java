package org.tiaa.case_management_rs.model;

import java.io.Serializable;

public class NextGenProcessSource implements Serializable {

	private static final long serialVersionUID = -6768840647724931846L;
	private int processCode;
	private String processName;
	private String sourceSystem;
	private boolean nxtGenSystem;
	private boolean legacySystem;
	
	/**
	 * @return the processCode
	 */
	public int getProcessCode() {
		return processCode;
	}
	/**
	 * @param processCode the processCode to set
	 */
	public void setProcessCode(int processCode) {
		this.processCode = processCode;
	}
	/**
	 * @return the processName
	 */
	public String getProcessName() {
		return processName;
	}
	/**
	 * @param processName the processName to set
	 */
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	/**
	 * @return the sourceSystem
	 */
	public String getSourceSystem() {
		return sourceSystem;
	}
	/**
	 * @param sourceSystem the sourceSystem to set
	 */
	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}
	/**
	 * @return the nxtGenSystem
	 */
	public boolean isNxtGenSystem() {
		return nxtGenSystem;
	}
	/**
	 * @param nxtGenSystem the nxtGenSystem to set
	 */
	public void setNxtGenSystem(boolean nxtGenSystem) {
		this.nxtGenSystem = nxtGenSystem;
	}
	/**
	 * @return the legacySystem
	 */
	public boolean isLegacySystem() {
		return legacySystem;
	}
	/**
	 * @param legacySystem the legacySystem to set
	 */
	public void setLegacySystem(boolean legacySystem) {
		this.legacySystem = legacySystem;
	}
	
}
