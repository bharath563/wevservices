package org.tiaa.case_management_rs.integration.case_manager.cth;

import org.springframework.ws.client.core.WebServiceTemplate;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.common.SInfoHeaderAdderWebServiceMessageCallback;
import org.tiaa.esb.partyrequest.types.CreateRequests;
import org.tiaa.esb.partyrequest.types.CreateRequestsResponse;
import org.tiaa.esb.partyrequest.types.RetrieveRequests;
import org.tiaa.esb.partyrequest.types.RetrieveRequestsResponse;
import org.tiaa.esb.partyrequest.types.UpdateRequests;
import org.tiaa.esb.partyrequest.types.UpdateRequestsResponse;

public class CTHCaseWebService {
	private WebServiceTemplate cthWebServiceTemplate;
	private ResponseProcessor responseProcessor = new ResponseProcessor();

	public CreateRequestsResponse createCTHEntry(CreateCTHCaseContext context, CreateRequests createRequests) {
		CreateRequestsResponse createRequestsResponse = (CreateRequestsResponse) cthWebServiceTemplate.marshalSendAndReceive(createRequests, createSInfoHeaderAdder(context.getClientId(), context.getCaseId()));
		responseProcessor.processCreateResponse(context, createRequestsResponse);
		return createRequestsResponse;
	}

	public UpdateRequestsResponse updateCTHEntry(CreateCTHCaseContext context, UpdateRequests updateRequests) {
		UpdateRequestsResponse updateRequestsResponse = (UpdateRequestsResponse) cthWebServiceTemplate.marshalSendAndReceive(updateRequests, createSInfoHeaderAdder(context.getClientId(), context.getCaseId()));
		responseProcessor.processUpdateResponse(updateRequestsResponse);
		return updateRequestsResponse;
	}

	public UpdateRequestsResponse updateCTHEntry(UpdateCaseCTHContext context, UpdateRequests updateRequests) {
		UpdateRequestsResponse updateRequestsResponse = (UpdateRequestsResponse) cthWebServiceTemplate.marshalSendAndReceive(updateRequests, createSInfoHeaderAdder(context.getClientId(), context.getCaseId()));
		responseProcessor.processUpdateResponse(updateRequestsResponse);
		return updateRequestsResponse;
	}

	private SInfoHeaderAdderWebServiceMessageCallback createSInfoHeaderAdder(String user, String caseId) {
		return new SInfoHeaderAdderWebServiceMessageCallback(AppConstants.APPLICATION_NAME, user, caseId);
	}

	public void setCthWebServiceTemplate(WebServiceTemplate cthWebServiceTemplate) {
		this.cthWebServiceTemplate = cthWebServiceTemplate;
	}

	public RetrieveRequestsResponse retrieveRequests(RetrieveRequests retrieveRequests, String user, String caseId) {
		return (RetrieveRequestsResponse) cthWebServiceTemplate.marshalSendAndReceive(retrieveRequests, createSInfoHeaderAdder(user, caseId));
	}
}
