package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class DocumentRoutingResultMapper implements RowMapper<String> {

	@Override
	public String mapRow(ResultSet rs, int rowNum) throws SQLException {

		String typeVal = new String();

		typeVal = rs.getString("type").trim();

		return typeVal;
	}
}
