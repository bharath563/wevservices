package org.tiaa.case_management_rs.poller;

public interface IPoller extends Runnable {
	String EVERY_MINUTE = "0 */1 * * * ?";
	String EVERY_MINUTE_AT_45TH_SECOND = "45 */1 * * * ?";
	String EVERY_MINUTE_AT_30TH_SECOND = "30 */1 * * * ?";
	String EVERY_5_MINUTES_AT_15TH_SECOND = "15 */5 * * * ?";

	boolean isDisabled();

	void setDisabled(boolean disabled);

	boolean poll();
}
