package org.tiaa.case_management_rs.integration.case_manager.cth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.support.RetryTemplate;

import org.tiaa.case_management_rs.integration.cth.CTHRecordNotFoundException;
import org.tiaa.case_management_rs.integration.cth.CTHUpdateRecordFailedException;

public class RetryableCTHCaseRecordUpdater {
	private static final Logger LOG = LoggerFactory.getLogger(RetryableCTHCaseRecordUpdater.class);
	private RetryTemplate retryTemplate;
	private CTHCaseRecordUpdater cthRecordUpdater;

	public RetryableCTHCaseRecordUpdater(RetryTemplate retryTemplate, CTHCaseRecordUpdater cthRecordUpdater) {
		super();
		this.retryTemplate = retryTemplate;
		this.cthRecordUpdater = cthRecordUpdater;
	}

	public Object updateCTHRecord(final UpdateCaseCTHContext context) {
		try {
			return retryTemplate.execute(new RetryCallback<Object>() {
				@Override
				public Object doWithRetry(RetryContext retryContext) {
					return cthRecordUpdater.updateCTHRecord(context);
				}
			});
		} catch (CTHRecordNotFoundException e) {
			LOG.warn(e.getMessage());
			throw e;
		} catch (Exception e) {
			LOG.warn(e.getMessage());
			throw new CTHUpdateRecordFailedException(e);
		}
	}
}
