package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;
import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;

public class RoutingRulesMapper extends AbstractRowMapper<NameValue> implements RowMapper<NameValue> {

	@Override
	public NameValue mapRow(ResultSet rs, int rowNum) throws SQLException {

		NameValue nameValue = new NameValue();
		
		nameValue.setID(getStringTrimmed(rs, "RULENUMBER"));
		nameValue.setDesc(getStringTrimmed(rs, "RULEDESCRIPTION"));
		
		NameValue childNameValueForStatus = new NameValue();
		childNameValueForStatus.setName(CHILD_PROPERTY_NAME_STATUS);
		childNameValueForStatus.setValue(getStringTrimmed(rs, "STATUS"));
		
		NameValue childNameValueForStartDate = new NameValue();
		childNameValueForStartDate.setName(CHILD_PROPERTY_NAME_START_DATE);
		childNameValueForStartDate.setValue(getStringTrimmed(rs, "STARTDATE"));
		
		NameValue childNameValueForStartTime = new NameValue();
		childNameValueForStartTime.setName(CHILD_PROPERTY_NAME_START_TIME);
		childNameValueForStartTime.setValue(getStringTrimmed(rs, "STARTTIME"));
		
		NameValue childNameValueForEndTime = new NameValue();
		childNameValueForEndTime.setName(CHILD_PROPERTY_NAME_END_TIME);
		childNameValueForEndTime.setValue(getStringTrimmed(rs, "ENDTIME"));
		
		nameValue.getChildrenNameValues().add(childNameValueForStatus);
		nameValue.getChildrenNameValues().add(childNameValueForStartDate);
		nameValue.getChildrenNameValues().add(childNameValueForStartTime);
		nameValue.getChildrenNameValues().add(childNameValueForEndTime);


		return nameValue;
	}
}
