package org.tiaa.case_management_rs.integration.exp_ag;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.servicerequest_workflow.types.DocumentIDType;
import org.tiaa.esb.servicerequest_workflow.types.DocumentIDsType;
import org.tiaa.esb.servicerequest_workflow.types.OriginatorType;

public class EXPAGDocumentMapper extends AbstractRowMapper<EXPAGDocument> implements RowMapper<EXPAGDocument> {
	@Override
	public EXPAGDocument mapRow(ResultSet rs, int rowNum) throws SQLException {
		EXPAGDocument document = new EXPAGDocument();
		String documentId = getStringTrimmed(rs, "documentID");
		String originator = getStringTrimmed(rs, "originator");
		String documentCategoryType = getStringTrimmed(rs, "documentCategoryType");
		//
		document.setDocumentDirection("Other");
		document.setDocumentVersion(1);
		document.setDocumentStorageSystem("EXP_AG");
		document.setTaskType(getStringTrimmed(rs, "tskdesc"));
		document.setCreateOperator(getStringTrimmed(rs, "createoper"));
		document.setDocumentType(documentCategoryType);
		document.setDocumentCategoryType(documentCategoryType);
		//
		OriginatorType originatorType = new OriginatorType();
		originatorType.setRole(originator);
		document.setOriginator(originatorType);
		//
		DocumentIDType documentIDType = new DocumentIDType();
		documentIDType.setType("EXPAG-DOCUMENT-ID");
		documentIDType.setValue(documentId);
		//
		DocumentIDsType documentIDsType = new DocumentIDsType();
		documentIDsType.getDocumentIDs().add(documentIDType);
		document.setDocumentIDs(documentIDsType);
		//
		document.setOriginalDocumentStorageSystem("EXP_AG");
		document.setOriginalDocumentID(documentId);
		//
		Date createDateTime = DateUtil.parseDateTime(getStringTrimmed(rs, "createDate"), getStringTrimmed(rs, "createTime"));
		document.setBusinessDate(DateUtil.toXMLGregorianCalendar(createDateTime));
		//
		document.setTaskId(getStringTrimmed(rs, "taskID"));
		document.setStartDate(rs.getInt("createDate"));
		document.setStartTime(rs.getInt("createTime"));
		//
		document.setMailType(getStringTrimmed(rs, "mailType"));
		document.setPageRange(getStringTrimmed(rs, "begpage") + "-" + getStringTrimmed(rs, "endPage"));
		document.setTotalPages(getStringTrimmed(rs, "totalPages"));
		document.setExternalDocumentKey(getStringTrimmed(rs, "externalSystemDocumentKey"));
		document.addIdentifier(getStringTrimmed(rs, "iddesc").trim(), getStringTrimmed(rs, "fieldvalue").trim());
		return document;
	}
}