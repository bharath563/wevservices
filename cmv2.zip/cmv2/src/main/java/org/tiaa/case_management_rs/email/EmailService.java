package org.tiaa.case_management_rs.email;

public interface EmailService {
	boolean sendEmailToProdSupport(String subject, String emailText);

	boolean sendEmail(String from, String toEmail, String subject, String emailText);

	boolean sendEmail(String from, String toEmail, String ccEmail, String subject, String emailText);

	boolean sendEmail(String from, String[] toEmail, String ccEmail, String subject, String emailText);

	boolean sendEmail(String from, String[] toEmail, String subject, String emailText);

}