package org.tiaa.case_management_rs.common;

import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.io.IOUtils;

import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

public final class LoggingResponseErrorHandler implements ResponseErrorHandler {
	private static final Logger LOG = LoggerFactory.getLogger(LoggingResponseErrorHandler.class);

	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException {
		logResponse(response);
		return true;
	}

	@Override
	public void handleError(ClientHttpResponse response) throws IOException {
		logResponse(response);
	}

	private void logResponse(ClientHttpResponse response) throws IOException {
		InputStream body = response.getBody();
		String string = IOUtils.toString(body);
		LOG.debug(string);
	}
}