package org.tiaa.case_management_rs.model;

public class ExpagWorkItem {

	private String taskId;
	private String packetId;
	private String lockOper;
	private String suspendOper;
	private String createOper;
	private String planId;
	private String planName;
	private String pin;
	private String npin;
	private String assignedTo;
	private String actionStep;
	private String department;
	private String taskType;
	private String departmentDescription;
	private String taskTypeDescription;
	private String createDateTime;
	private String receivedDateTime;
	private String updatedDateTime;
	private String awakeDateTime;
	private String lockOperatorFullName;
	private String tradeDate;
	private String checkAmount;

	public String getCheckAmount() {
		return checkAmount;
	}
	public void setCheckAmount(String checkAmount) {
		this.checkAmount = checkAmount;
	}
	public String getTaskId() {
		return this.taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getPacketId() {
		return this.packetId;
	}
	public void setPacketId(String packetId) {
		this.packetId = packetId;
	}
	public String getLockOper() {
		return this.lockOper;
	}
	public void setLockOper(String lockOper) {
		this.lockOper = lockOper;
	}
	public String getSuspendOper() {
		return this.suspendOper;
	}
	public void setSuspendOper(String suspendOper) {
		this.suspendOper = suspendOper;
	}
	public String getCreateOper() {
		return this.createOper;
	}
	public void setCreateOper(String createOper) {
		this.createOper = createOper;
	}
	public String getPlanId() {
		return this.planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getPlanName() {
		return this.planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getPin() {
		return this.pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getNpin() {
		return npin;
	}
	public void setNpin(String npin) {
		this.npin = npin;
	}
	public String getAssignedTo() {
		return this.assignedTo;
	}
	public void setAssignedTo(String assignedTo) {
		this.assignedTo = assignedTo;
	}
	public String getActionStep() {
		return this.actionStep;
	}
	public void setActionStep(String actionStep) {
		this.actionStep = actionStep;
	}
	public String getDepartment() {
		return this.department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getTaskType() {
		return this.taskType;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}
	public String getDepartmentDescription() {
		return this.departmentDescription;
	}
	public void setDepartmentDescription(String departmentDescription) {
		this.departmentDescription = departmentDescription;
	}
	public String getTaskTypeDescription() {
		return this.taskTypeDescription;
	}
	public void setTaskTypeDescription(String taskTypeDescription) {
		this.taskTypeDescription = taskTypeDescription;
	}
	public String getCreateDateTime() {
		return this.createDateTime;
	}
	public void setCreateDateTime(String createDateTime) {
		this.createDateTime = createDateTime;
	}
	public String getReceivedDateTime() {
		return this.receivedDateTime;
	}
	public void setReceivedDateTime(String receivedDateTime) {
		this.receivedDateTime = receivedDateTime;
	}
	public String getUpdatedDateTime() {
		return this.updatedDateTime;
	}
	public void setUpdatedDateTime(String updatedDateTime) {
		this.updatedDateTime = updatedDateTime;
	}
	public String getAwakeDateTime() {
		return awakeDateTime;
	}
	public void setAwakeDateTime(String awakeDateTime) {
		this.awakeDateTime = awakeDateTime;
	}
	public String getLockOperatorFullName() {
		return lockOperatorFullName;
	}
	public void setLockOperatorFullName(String lockOperatorFullName) {
		this.lockOperatorFullName = lockOperatorFullName;
	}
	public String getTradeDate() {
		return tradeDate;
	}
	public void setTradeDate(String tradeDate) {
		this.tradeDate = tradeDate;
	}
	
}
