package org.tiaa.case_management_rs.poller;

import static org.tiaa.case_management_rs.common.AppConstants.*;
import static org.tiaa.case_management_rs.utils.CommonUtil.*;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

//import javax.annotation.PostConstruct;
//import javax.annotation.PreDestroy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import org.tiaa.case_management_rs.common.ConfigurationException;
import org.tiaa.case_management_rs.common.ExceptionHandler;
import org.tiaa.case_management_rs.domain.CMSActivePoller;
import org.tiaa.case_management_rs.domain.CMSPollerLog;
import org.tiaa.case_management_rs.email.EmailService;
import org.tiaa.case_management_rs.email.EmailUtil;
import org.tiaa.case_management_rs.repository.CMSPollerLogRepository;
import org.tiaa.case_management_rs.utils.CommonUtil;

public class ComponentSynchronizerServiceImpl implements ComponentSynchronizerService {
	private static final int MINUTE_IN_MILLI_SECONDS = 60 * 1000;
	private static final int TWO_MINUTES_IN_MILLI_SECONDS = 2 * MINUTE_IN_MILLI_SECONDS;
	private static final int DEFAULT_PERIOD_IN_MINUTES = 5;
	private static Logger logger = LoggerFactory.getLogger(ComponentSynchronizerServiceImpl.class);
	private Logger statusLogger;
	@Autowired
	private CMSActivePollerDAO activePollerDAO;
	@Autowired
	private EmailService emailService;
	@Autowired
	private ScheduledThreadPoolExecutor scheduledThreadPoolExecutor;
	private String component;
	private String instance;
	private int initialDelay = 0;
	private int period = DEFAULT_PERIOD_IN_MINUTES;
	private TimeUnit timeUnit = TimeUnit.SECONDS;
	private String supportGroupEmail;
	private long proactiveProcessorPollerMaxAgeInMillis = TWO_MINUTES_IN_MILLI_SECONDS;
	@Autowired
	private CMSPollerLogRepository cmsPollerLogRepository;

	public ComponentSynchronizerServiceImpl() {
		statusLogger = LoggerFactory.getLogger(STATUS_PACKAGE + this.getClass().getSimpleName());
	}

	public String getInstance() {
		return instance;
	}

	public void setInstance(String instance) {
		this.instance = instance;
	}

	public String getComponent() {
		return component;
	}

	public void setComponent(String component) {
		this.component = component;
	}

	/**
	 * Acquire lock and update db.
	 *
	 * @return true, if successful
	 */
	public boolean acquireLockAndUpdateDB() {
		return activePollerDAO.updateOwner(component, instance);
	}

	public boolean checkOwner() {
		String owner = getOwner();
		statusLogger.debug("owner name is :{}", owner);
		return owner != null ? owner.equals(instance) : false;
	}

	public String getOwner() {
		CMSActivePoller activePoller = getActivePoller();
		return activePoller == null ? null : activePoller.getOwner();
	}

	public CMSActivePoller getActivePoller() {
		try {
			return activePollerDAO.getActivePoller(component);
		} catch (Exception e) {
			logger.warn(e.getMessage(), e);
			return null;
		}
	}

	/**
	 * release lock "id" held by "owner".
	 */
	public void release() {
		if (instance == null) {
			throw new IllegalArgumentException("instance is null");
		}
		CMSActivePoller activePoller = activePollerDAO.findById(component);
		//if we are the owner
		if (activePoller != null && instance.equals(activePoller.getOwner())) {
			//release the lock
			activePollerDAO.updateOwner(component, null);
		}
	}

	/**
	 * Try to lock "id" for "owner" If the lock is held by someone else, but is
	 * older than maxAge, break it.
	 *
	 * @return true, if successful
	 */
	public boolean tryAcquireLockAndUpdateDB() {
		return tryLockImpl();
	}

	/**
	 * Try lock impl.
	 *
	 * @return true, if successful
	 */
	@Transactional(readOnly = false, isolation = Isolation.SERIALIZABLE)
	private boolean tryLockImpl() {
		if (component == null) {
			throw new IllegalStateException("component is null");
		}
		CMSActivePoller activePoller = null;
		try {
			activePoller = activePollerDAO.findById(component);
		} catch(Exception e) {
			logger.warn(e.getMessage(), e);
		}
		if (activePoller == null) {
			activePoller = new CMSActivePoller();
			activePoller.setOwner(instance);
			activePoller.setComponent(component);
			activePoller.setLastUpdatedTimestamp(new Date());
			return activePollerDAO.insertPoller(activePoller);
		}
		// found a activePoller, let's see who owns it
		String owner = activePoller.getOwner();
		if (owner != null && owner.equals(instance) && activePoller.getComponent().equals(component)) {
			// refresh
			return true;
		}
		if (owner == null) {
			// activePoller is not held by anyone, safe to grab it
			return activePollerDAO.updateOwner(component, instance);
		}
		return false;
	}

	/**
	 * Initialize.
	 */
	
	/*
	 * *******************************************************************************************************
	 * DISABLING CM POLLER FOR OCT 2016 POLLER, commented @PostConstruct
	 * ********************************************************************************************************
	 */
	//@PostConstruct
	public void init() {
		if (instance == null) {
			instance = CommonUtil.getHostAndNodeName();
		}
		List<CMSPollerLog> pollerLogs = cmsPollerLogRepository.findByHostNameAndActive(getHostName(), true);
		logger.debug("pollerLogs size:{}", pollerLogs.size());
		if (pollerLogs.isEmpty()) {
			logger.debug("no poller active for host:{}", getHostName());
			return;
		}
		Assert.notNull(supportGroupEmail, "supportGroupEmail has to be set");
		//Get the support group email as the email should be CCed to support group too
		logger.debug("supportGroupEmail:{}", supportGroupEmail);
		try {
			logger.debug("setting instance :{}", instance);
			logger.debug("trying to acquire lock inside init method");
			if (instance == null) {
				throw new IllegalArgumentException("Instance cannot be null");
			}
			boolean ownerHasLock = tryAcquireLockAndUpdateDB();
			logger.debug("For {}, lock acuired for instance {} is :{}", component, instance, ownerHasLock);
			logger.debug("starting thread.. Owner has lock is :{}", ownerHasLock);
			Runnable command = ExceptionHandler.createSafeRunnable(new HealthCheckImpl(ownerHasLock));
			scheduledThreadPoolExecutor.scheduleAtFixedRate(command, initialDelay, period, timeUnit);
		} catch (IllegalArgumentException e) {
			logger.warn(e.getMessage(), e);
			throw new ConfigurationException(e);
		}
	}

	/*
	 * *******************************************************************************************************
	 * DISABLING CM POLLER FOR OCT 2016 POLLER, commented @PreDestroy
	 * ********************************************************************************************************
	 */
	
	
//	@PreDestroy
		public void destroy() {
		
		logger.debug("Attempting to release resource..by instance:{}", instance);
		scheduledThreadPoolExecutor.shutdown();
		//wait for 10 seconds...
		final int seconds = 10;
		try {
			scheduledThreadPoolExecutor.awaitTermination(seconds, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			logger.warn(e.getMessage(), e);
		}
		logger.debug("scheduler shutdown properly...");
		release();
	}

	public void updateHeartBeat() {
		activePollerDAO.updateHeartBeat(component, instance);
	}

	public int getInitialDelay() {
		return initialDelay;
	}

	public void setInitialDelay(int initialDelay) {
		this.initialDelay = initialDelay;
	}

	public int getPeriod() {
		return period;
	}

	public void setPeriod(int period) {
		this.period = period;
	}

	public TimeUnit getTimeUnit() {
		return timeUnit;
	}

	public void setTimeUnit(TimeUnit timeUnit) {
		this.timeUnit = timeUnit;
	}

	public String getSupportGroupEmail() {
		return supportGroupEmail;
	}

	public void setSupportGroupEmail(String supportGroupEmail) {
		this.supportGroupEmail = supportGroupEmail;
	}

	public long getProactiveProcessorPollerMaxAgeInMillis() {
		return proactiveProcessorPollerMaxAgeInMillis;
	}

	public void setProactiveProcessorPollerMaxAgeInMillis(long proactiveProcessorPollerMaxAgeInMillis) {
		this.proactiveProcessorPollerMaxAgeInMillis = proactiveProcessorPollerMaxAgeInMillis;
	}

	public ScheduledThreadPoolExecutor getScheduledThreadPoolExecutor() {
		return scheduledThreadPoolExecutor;
	}

	public void setScheduledThreadPoolExecutor(ScheduledThreadPoolExecutor scheduledThreadPoolExecutor) {
		this.scheduledThreadPoolExecutor = scheduledThreadPoolExecutor;
	}

	private final class HealthCheckImpl implements Runnable {
		private boolean ownerHasLock;

		private HealthCheckImpl(boolean ownerHasLock) {
			this.ownerHasLock = ownerHasLock;
		}

		/*
		 * *******************************************************************************************************
		 * Since PostConstruct is commented in this java file, the following run would never get invoked
		 * ********************************************************************************************************
		 */
		
		@Override
		public void run() {
			statusLogger.debug("Thread is running...for instance: {}", instance);
			if (ownerHasLock) {
				statusLogger.debug("Instance {} has lock for {}. Updating heartbeat..", instance, component);
				updateHeartBeat();
			} else {
				statusLogger.debug("Instance {} doesn't have lock. Getting active poller details..", instance);
				// check if owner has updated the timestamp
				CMSActivePoller activePoller = getActivePoller();
				statusLogger.debug("Active poller is :{}", activePoller);
				statusLogger.debug("activePoller.getTime() is {}, System.currentTimeMillis is :{}",activePoller.getTime(), System.currentTimeMillis());
				// if owner has not updated timestamp in say 2 minutes
				long diff = System.currentTimeMillis() - activePoller.getTime();
				statusLogger.debug("Diff between current timestamp and last updated ts by active poller is :{} and configured is {} and greater?:{}", diff,proactiveProcessorPollerMaxAgeInMillis,diff > proactiveProcessorPollerMaxAgeInMillis);
				if (diff > proactiveProcessorPollerMaxAgeInMillis) {
					logger.warn("Instance {} is trying to acquire lock as the last updated timestamp is greater than {}", instance, proactiveProcessorPollerMaxAgeInMillis);
					// acquire lock and become owner. if
					// lock acquired, owner.haslock will be true
					ownerHasLock = acquireLockAndUpdateDB();
					//send email
					sendEmail(activePoller.getOwner(), instance, activePoller.getTime());
					logger.info("Instance {} hasLock is :{}", instance, ownerHasLock);
				}
			}
		}

		private void sendEmail(String oldActivePoller, String newActivePoller, long oldActivePollerUpdatedTime) {
			String subject = component + " switch happened";
			String emailText = composeEmail(oldActivePoller, newActivePoller, oldActivePollerUpdatedTime);
			boolean result = emailService.sendEmail(supportGroupEmail, supportGroupEmail, subject, emailText);
			logger.info("Email sent to notify the switch of the active poller. Result is :{}", result);
		}

		private String composeEmail(String oldActivePoller, String newActivePoller, long oldActivePollerUpdatedTime) {
			StringBuilder emailMessageBuffer = new StringBuilder();
			emailMessageBuffer.append(EmailUtil.getServerNameDetails());
			emailMessageBuffer.append("For " + component + ", " + newActivePoller + " has become the active poller. Last active poller was '" + oldActivePoller + "'. "
					+ oldActivePoller + " last updated timestamp is :" + oldActivePollerUpdatedTime);
			emailMessageBuffer.append(EmailUtil.getEmailBodyFooterText());
			return emailMessageBuffer.toString();
		}
	}

}