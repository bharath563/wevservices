package org.tiaa.case_management_rs.utils;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.esb.case_management_rs_v2.type.ResponseStatus;
import org.tiaa.j2eeinfra.exception.TiaaRuntimeException;

/**
 * This class is used for
 */
public final class CaseManagementUtil {

	/**
	 * Default constructor. This is for restricting instantiation
	 */
	private CaseManagementUtil() {

	}

	/**
	 * @param list
	 * @return result
	 */
	public static boolean isEmptyList(@SuppressWarnings("rawtypes") List list) {
		boolean result = false;
		if (isNull(list) || (list.size() < 1)) {
			result = true;
		}
		return result;
	}

	/**
	 * @param list
	 * @return result
	 */
	public static boolean isEmptySet(@SuppressWarnings("rawtypes") Set set) {
		boolean result = false;
		if (isNull(set) || (set.size() < 1)) {
			result = true;
		}
		return result;
	}

	/**
	 * @param obj
	 * @return result
	 */
	public static boolean isNull(Object obj) {
		boolean result = false;
		if (obj == null) {
			result = true;
		}
		return result;
	}

	/**
	 * @param aMap
	 * @return mapToList
	 *
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static List mapToList(Map aMap) {
		if (aMap != null) {
			return new ArrayList(aMap.values());
		}
		return null;
	}

	public static ResponseStatus getESBSuccessResponseStaus() {
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setStatus(CaseManagementConstants.SUCCESS_TEXT);
		responseStatus.setStatusText(CaseManagementConstants.SUCCESS_TEXT);
		return responseStatus;
	}

	public static ResponseStatus getESBFailureResponseStaus() {
		ResponseStatus responseStatus = new ResponseStatus();
		responseStatus.setStatus(CaseManagementConstants.FAILURE);
		responseStatus.setStatusText(CaseManagementConstants.FAILURE_TEXT);
		return responseStatus;
	}

	/**
	 * @param xmlCal
	 * @return date
	 */
	public static Date convertToDate(XMLGregorianCalendar xmlCal) {
		Date date = null;
		if (!isNull(xmlCal)) {
			GregorianCalendar c = xmlCal.toGregorianCalendar();
			date = c.getTime();
		}
		return date;
	}

	/**
	 * @param xmlCal
	 * @return timestamp
	 */
	public static Timestamp convertToTimeStamp(XMLGregorianCalendar xmlCal) {
		Timestamp timestamp = null;
		if (!isNull(xmlCal)) {
			GregorianCalendar c = xmlCal.toGregorianCalendar();
			timestamp = new Timestamp(c.getTimeInMillis());
		}
		return timestamp;
	}

	/**
	 * Used to convert XMLGregorianCalendar to Date without time and timezone.
	 *
	 * @param date
	 * @return XMLGregorianCalendar
	 */
	public static XMLGregorianCalendar convertDateToXMLGregorianCalendarWithoutTime(Date date) {
		XMLGregorianCalendar xmlGregorianCalendar = null;
		if (date != null) {
			GregorianCalendar gc = (GregorianCalendar) GregorianCalendar.getInstance();
			gc.setTime(date);
			DatatypeFactory dataTypeFactory = null;
			try {
				dataTypeFactory = DatatypeFactory.newInstance();
			} catch (DatatypeConfigurationException datatypeConfigurationException) {
				throw new TiaaRuntimeException(datatypeConfigurationException);
			}
			xmlGregorianCalendar = dataTypeFactory.newXMLGregorianCalendar(gc);
			/* Removing time section from XMLGregorianCalendar - start */
			xmlGregorianCalendar.setTimezone(DatatypeConstants.FIELD_UNDEFINED);

			xmlGregorianCalendar.setTime(DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED, DatatypeConstants.FIELD_UNDEFINED);
			/* Removing time section from XMLGregorianCalendar - end */
		}

		return xmlGregorianCalendar;
	}

	/**
	 * @param obj
	 * @return result
	 */
	public static boolean isTrue(Boolean obj) {
		boolean result = false;
		if (Boolean.TRUE.equals(obj)) {
			result = true;
		}
		return result;
	}

}
