package org.tiaa.case_management_rs.delegate.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.case_management_rs.exception.CaseManagementRuntimeException;
import org.tiaa.case_management_rs.icm.helper.ICMCommentsHelper;
import org.tiaa.case_management_rs.icm.helper.ICMDocumentHelper;
import org.tiaa.case_management_rs.icm.helper.ICMJsonUnmarshaller;
import org.tiaa.case_management_rs.icm.helper.ICMSearchHelper;
import org.tiaa.case_management_rs.icm.helper.ICMTaskHelper;
import org.tiaa.case_management_rs.icm.helper.RequestSummaryHelper;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.WorkflowException;
import org.tiaa.case_management_rs.integration.icm.ICMRepository;
import org.tiaa.case_management_rs.integration.icm.ICMService;
import org.tiaa.esb.case_management_rs_v2.type.Comments;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItem;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItems;
import org.tiaa.esb.case_management_rs_v2.type.Document;
import org.tiaa.esb.case_management_rs_v2.type.Documents;
import org.tiaa.esb.case_management_rs_v2.type.ESBMessage;
import org.tiaa.esb.case_management_rs_v2.type.ESBMessages;
import org.tiaa.esb.case_management_rs_v2.type.Metrics;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.ProcessesRequest;
import org.tiaa.esb.case_management_rs_v2.type.Properties;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;
import org.tiaa.esb.case_management_rs_v2.type.TaskRequest;
import org.tiaa.esb.case_management_rs_v2.type.TaskResponse;
import org.tiaa.esb.case_management_rs_v2.type.Tasks;
import org.tiaa.esb.icm.types.Case;
import org.tiaa.esb.icm.types.CaseSearch;
import org.tiaa.esb.icm.types.RelatedCase;
import org.tiaa.esb.icm.types.ResponseList;
import org.tiaa.esb.icm.types.Step;
import org.tiaa.esb.icm.types.StepList;
import org.tiaa.esb.case_management_rs_v2.type.Task;

@Repository(value="icmAdapter")
public class ICMAdapter extends ExpAGAdapter {
	
	@Autowired
	private ICMService icmService;

	@Autowired
	private ICMSearchHelper icmSearchHelper;

	@Autowired
	private  ICMRepository icmRepository;
	
	@Autowired
	private ICMCommentsHelper icmCommentsHelper;
	
	@Autowired
	private ICMDocumentHelper icmDocumentHelper;
	
	@Autowired
	private ICMTaskHelper icmTaskHelper;

	@Autowired
	private ICMJsonUnmarshaller jsonUnmarshaller;
	
	@Autowired
	private RequestSummaryHelper requestSummaryHelper;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ICMAdapter.class);
	
	@Override
	public Processes doSearch(Request request) throws Exception{

		Processes icmProcesses = new Processes();
		boolean icmCaseSearchRequired = true;

		String userId = (String) request.getAttribute(USER_ID);
		SearchRequest searchRequest = (SearchRequest) request.getAttribute(SEARCH_REQUEST);

		// If task id starts with "t", no need to search in ICM
		if (searchRequest.getTaskId() != null && searchRequest.getTaskId().startsWith("t")) {
			icmCaseSearchRequired = false;
		}

		if (StringUtils.isNotBlank(searchRequest.getAssignedTo())) {
			icmCaseSearchRequired = false;
		}
		// If child properties are having search property rather than the ICM identifiers, ignore ICM search call		

		if (icmCaseSearchRequired) {			
			CaseSearch icmSearchRequest = this.icmSearchHelper.rsvSearchRequestToICMRequest(searchRequest);

			// if sort fields are either "Assigned To" or "NPIN", don't
			// perform ICM search.
			
		
			if (!icmSearchRequest.getSortField().equalsIgnoreCase(ColumnsMapping.getICMColumn(ColumnsMapping.ASSIGNED_TO))
					&& !icmSearchRequest.getSortField().equalsIgnoreCase(ColumnsMapping.getICMColumn(ColumnsMapping.NPIN))) {
				try {
					ResponseList icmSearchResponse  = this.icmRepository.searchICMCases(icmSearchRequest, userId);
					List<Case> icmCases = (List<Case>) icmSearchResponse.getResults();
					icmProcesses = this.icmSearchHelper.icmCasesToProcesses(icmCases);
					if(icmProcesses != null && icmProcesses.getProcesses()!=null){
						LOGGER.debug("searchResults size from ICM-->:" + icmProcesses.getProcesses().size());
					}
					
				} catch (Exception e) {
					LOGGER.error("Error while searching in ICM: "+e.getMessage());
				}
				
			}
		}
		return icmProcesses;
	}

	@Override
	public Processes getProcesses(Request request) {
		Processes processes = new Processes();
		String userId = (String) request.getAttribute(USER_ID);
		String department = (String) request.getAttribute(DEPARTMENT);
		String type = (String) request.getAttribute(TYPE);
		String start = (String) request.getAttribute(START);

		if (type != null && department != null && userId != null) {
				if(ICM_SUSPENDED.equalsIgnoreCase(type)){
					type = ICM_PENDED;
				}else if(ICM_ASSIGNED.equalsIgnoreCase(type)){
					type = ICM_ALLASSIGNED;
				}
			List<StepList> icmProcessResponseList = icmRepository.getICMSteps(userId, department, type, start);
			if (icmProcessResponseList != null && icmProcessResponseList.size() > 0) {
				processes = this.jsonUnmarshaller.icmStepsToProcesses(icmProcessResponseList);
			}
		}
			
		return processes;
	}
	
	
	@Override
	public Documents getDocuments(Request request){
		String userId = (String) request.getAttribute(USER_ID);
		String caseId = (String) request.getAttribute(PROCESS_ID);
		Documents documents = new Documents();
		
			ResponseList icmDocumentsResponse = this.icmRepository.getICMDocuments(caseId, userId);
			if(icmDocumentsResponse != null){
				documents  = this.jsonUnmarshaller.icmDocumentsToCM(caseId, icmDocumentsResponse);
			}
		return documents;
	}
	

	@Override
	public Process getProcess(Request request) {
			String userId = (String) request.getAttribute(USER_ID);
			String processId = (String) request.getAttribute(PROCESS_ID);
			String type = (String) request.getAttribute(TYPE);

			String solutionName = request.getAttribute(SOLUTION_NAME) != null ? (String) request.getAttribute(SOLUTION_NAME) : null;
			String section = request.getAttribute(SECTION) != null ?  (String)request.getAttribute(SECTION) : null;
			String groupId = request.getAttribute(GROUP_ID) != null ?  (String)request.getAttribute(GROUP_ID) : null;
			String tableName = request.getAttribute(TABLE_NAME) != null ?  (String)request.getAttribute(TABLE_NAME) : null;
			String start = request.getAttribute(START) != null ?  (String)request.getAttribute(START) : null;
			String sortOrder = request.getAttribute(SORT_ORDER) != null ?  (String)request.getAttribute(SORT_ORDER) : null;
			String sortBy = request.getAttribute(SORT_BY) != null ?  (String)request.getAttribute(SORT_BY) : null;
			String taskId = request.getAttribute(TASK_ID) != null ?  (String)request.getAttribute(TASK_ID) : null;
			
			// Converting ICM CASE RESPONSE to CMS RSV Process Response
			Process process = new Process();
			Properties icmProperties = new Properties();
			Case icmCaseResponse = null;
			
			// if solutionName, section exist - it is infocaddy
			//either get infocaddy or case detail
			if (StringUtils.isNotBlank(solutionName) && StringUtils.isNotBlank(section)) {
				
				LOGGER.info("Calling ICM for Reporting Data --> for section " + section + ", Solution " + solutionName + ", Group Id " + (groupId != null ? groupId:"[NULL]") + ", Table Name " + (tableName != null ? tableName:"[NULL]") + ", Start " + (start != null ? start:"[NULL]") + ", Sort Order " + (sortOrder != null ? sortOrder:"[NULL]") + ", Sort By " + (sortBy != null ? sortBy:"[NULL]"));
				
				List<Object> infoCaddyResponse = this.icmRepository.getCaseAdditionalInfo(processId, userId, solutionName, section, groupId, tableName, start, sortOrder, sortBy, taskId);
				
				LOGGER.info("Got ICM for Reporting Data --> for section " + section + ", Solution " + solutionName + ", Group Id " + (groupId != null ? groupId:"[NULL]") + ", Table Name " + (tableName != null ? tableName:"[NULL]") + ", Start " + (start != null ? start:"[NULL]") + ", Sort Order " + (sortOrder != null ? sortOrder:"[NULL]") + ", Sort By " + (sortBy != null ? sortBy:"[NULL]"));
				
				if (infoCaddyResponse != null && infoCaddyResponse.size() > 0) {
					NameValue caddyNameValue = this.requestSummaryHelper.mergeInfocaddyResponse(infoCaddyResponse, section);
					icmProperties.getProperties().add(caddyNameValue);
					process.setProcessProperties(icmProperties);
				}
				
			} else {
				Case caseResponse = this.icmRepository.getICMProcess(processId, userId);
				if(caseResponse != null){
					icmCaseResponse = this.jsonUnmarshaller.icmCaseToProcess(caseResponse, process);
				}
				
			//if type is not passed as summary, fetch Documents, Comments , Tasks & Related Cases
				if(StringUtils.isBlank(type)){
					
					Documents documents = getDocuments(request);
					process.setDocuments(documents);
				
					Comments comments = getComments(request);
					process.setComments(comments);
					
					Tasks tasks = getTasks(request);
					process.setTasks(tasks);
					
					/*// ICM History Call
					History history = new History();
					history.getEvents().addAll(this.getHistory(request));
					process.setHistory(history);*/
					
					if(icmCaseResponse != null){
						solutionName = (String) icmCaseResponse.getAdditionalIdentifiers().get("Solution Name");
						request.setAttribute(SOLUTION_NAME, solutionName);
					}
					
					LOGGER.debug("solutionName to get Related Cases is:" + request.getAttribute(SOLUTION_NAME));
					
					if(! StringUtils.isEmpty(solutionName) ){
						Process relatedTasksProcess = getRelatedProcesses(request);
						if (relatedTasksProcess != null
								&& relatedTasksProcess.getRelatedTasks() != null) {
							process.setRelatedTasks(relatedTasksProcess.getRelatedTasks());
							}
						}
					}
				}
			return process;
		}
	
	@Override
	public Comments getComments(Request request) {
		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);

		ResponseList icmCommentsResponse = this.icmRepository.getICMcomments(processId, userId);
		List<LinkedHashMap<String, Object>> icmComments = new ArrayList<LinkedHashMap<String, Object>>();
		if(icmCommentsResponse != null){
			icmComments = (List<LinkedHashMap<String, Object>>) icmCommentsResponse.getResults();
		}

		return this.icmCommentsHelper.icmCommentsToComments(icmComments);
	}
	
	@Override
	public Process getRelatedProcesses(Request request) {
		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);
		String solutionName = (String) request.getAttribute(SOLUTION_NAME);
		
		ResponseList reponseList = this.icmRepository.getICMRelatedCase(processId, userId, solutionName);

		List<RelatedCase> relatedCasesList = new ArrayList<RelatedCase>();
		if(reponseList != null){
			relatedCasesList = (List<RelatedCase>) reponseList.getResults();
		}
		return this.jsonUnmarshaller.icmRelatedCasesToRelatedTasks(relatedCasesList);
	}
	
	@Override
	public Tasks getTasks(Request request) {
		
		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);
		String startOmniTasks = (String)request.getAttribute(START_OMNI_TASKS);
		String start = (String)request.getAttribute(START);
		String plan = (String)request.getAttribute(OMNI_TASK_PLAN);
		String subPlan = (String)request.getAttribute(OMNI_TASK_SUBPLAN);
		
		if(StringUtils.isBlank(start)){
			start = "0";
		}

		
		ResponseList icmTasksResponse = null;
		
		
		if(StringUtils.isNotBlank(startOmniTasks) && StringUtils.isNotBlank(plan) && StringUtils.isNotBlank(subPlan)){
			icmTasksResponse = this.icmRepository.getIcmOmniTasks(processId, userId, startOmniTasks, plan, subPlan);
		}else{		
			icmTasksResponse = this.icmRepository.getICMtasks(processId, userId, start);
		}
		
		List<org.tiaa.esb.icm.types.Task> icmtasks = new ArrayList<org.tiaa.esb.icm.types.Task>();
		if(icmTasksResponse != null){
			icmtasks = (List<org.tiaa.esb.icm.types.Task>) icmTasksResponse.getResults();
		}
		
		return this.icmTaskHelper.icmCasesToTasks(icmtasks, icmTasksResponse.getTotalRecords());
	}
	
	@Override
	public Process getHistory(Request request) {
		Process process = new Process();
		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);
		String start = (String) request.getAttribute(START);
		String type = (String) request.getAttribute(TYPE);
		start = start == null ? "0" : start;
		type = type == null ? "all" : type;
		ResponseList icmEventsResponse = this.icmRepository.getICMHistory(processId, userId, start, type);
		List<org.tiaa.esb.icm.types.Event> icmEvents = new ArrayList<org.tiaa.esb.icm.types.Event>();
		if(icmEventsResponse != null){
			icmEvents = (List<org.tiaa.esb.icm.types.Event>) icmEventsResponse.getResults();
			process = this.jsonUnmarshaller.icmEventToHistory(icmEvents,icmEventsResponse.getTotalRecords());
		}

		 return process;
	}


	@Override
	public Document getDocument(Request request) throws JAXBException {
			return this.icmDocumentHelper.getDocument(request);
	}

	@Override
	public Process createProcess(Request request) {
		
		return super.createProcess(request);
	}

	@Override
	public Process updateProcess(Request request) {
		return super.updateProcess(request);
	}

	@Override
	public ConfigItems getConfigItems(Request request) {
		return super.getConfigItems(request);
	}

	@Override
	public Metrics getMetrics(Request request) {
		
		String userId = (String) request.getAttribute(USER_ID);
		String solutionName = (String) request.getAttribute(SOLUTION_NAME);
		ResponseList icmMetricsResponse = this.icmRepository.getMetrics(userId, solutionName);
		Metrics metrics = null;

		if(icmMetricsResponse != null && icmMetricsResponse.getResults() != null ){
			Map<String, Map<String, Integer>> icmResponse = (Map<String, Map<String, Integer>>)icmMetricsResponse.getResults();
			if(icmResponse != null && !icmResponse.isEmpty()){
				metrics = this.jsonUnmarshaller.icmMetricsToMetrics(icmResponse);
			}
		}
		return metrics;
	}

	@Override
	public Document createDocument(Request request) {
		return super.createDocument(request);
	}

	@Override
	public Documents createDocuments(Request request) {
		return super.createDocuments(request);
	}

	@Override
	public Process createRelatedTask(Request request) {
		return super.createRelatedTask(request);
	}

	@Override
	public Processes createProcesses(Request request) {
		String userId = (String) request.getAttribute(USER_ID);
		ProcessesRequest processesRequest = (ProcessesRequest) request.getAttribute(PROCESSES_REQUEST);
		Case caseObj = jsonUnmarshaller.processToICMCase(processesRequest.getProcesses().getProcesses().get(0));
		
		org.tiaa.esb.icm.types.Response response = this.icmRepository.createCase(caseObj, userId);
		if (StringUtils.isNotBlank(response.getStatus()) && SUCCESS.equalsIgnoreCase(response.getStatus())) {
			return new Processes();
		}

		return null;
	}

	@Override
	public Processes doDatabaseSearch(Request request) throws Exception {
		return super.doDatabaseSearch(request);
	}

	/*@Override
	public TaskResponse getTaskById(Request request) {
		return super.getTaskById(request);
	}*/

	@Override
	public Processes getTasksClaimable(Request request) {
		return super.getTasksClaimable(request);
	}

	@Override
	public ConfigItems getIcmConfigItems(Request request) {
		return super.getIcmConfigItems(request);
	}

	@Override
	public Comments addComment(Request request) {
		return super.addComment(request);
	}

	@Override
	public Processes updateProcesses(Request request) throws Exception {
		Processes returnProcesses = new Processes();
		String action = (String) request.getAttribute(ACTION);
		if (ACTION_ASSIGN.equalsIgnoreCase(action)) {
			final List<java.util.concurrent.Callable<org.tiaa.esb.icm.types.Response>> callables = new ArrayList<Callable<org.tiaa.esb.icm.types.Response>>();
			ProcessesRequest processRequest = (ProcessesRequest) request
					.getAttribute(PROCESSES_REQUEST);
			String userId = (String) request.getAttribute(USER_ID);
			if(processRequest.getProcesses() == null || processRequest.getProcesses().getProcesses() == null || 
					processRequest.getProcesses().getProcesses().size() == 0){
				return null;
			}
			int sizeOfProcesses = processRequest.getProcesses().getProcesses()
					.size();

			for (Process process : processRequest.getProcesses().getProcesses()) {
				Tasks taskRequest = process.getTasks();
				for(Task taskInfo : taskRequest.getTasks()){
					Step step = jsonUnmarshaller.tasksToIcmSteps(taskInfo);
					callables.add(new IcmAssignedTask(step, userId));
				}
			}
		
			ExecutorService executor = Executors.newFixedThreadPool(maxBulkAssignmentThreadPoolSize);

			org.tiaa.esb.icm.types.Response processedProcess;
			try {
				for (Future<org.tiaa.esb.icm.types.Response> results : executor.invokeAll(callables)) {
					processedProcess = results.get();
					if(!SUCCESS.equalsIgnoreCase(processedProcess.getStatus())){
						for (Process process : processRequest.getProcesses().getProcesses()) {
							Tasks taskRequest = process.getTasks();
							for(Task taskInfo : taskRequest.getTasks()){
								if(taskInfo.getWobId().equalsIgnoreCase(processedProcess.getId())){
									Process succeedProcess = new Process();
									Tasks tasks = new Tasks();
									Task task = new Task();
									task.setTaskProperties(taskInfo.getTaskProperties());
									tasks.getTasks().add(task);
									succeedProcess.setTasks(tasks);
									returnProcesses.getProcesses().add(succeedProcess);
								}
							}
						}
					
					}
				}
			
				if (returnProcesses.getProcesses().size() == sizeOfProcesses){
					ESBMessages esbMessages = new ESBMessages();
					ESBMessage esbMessage = new ESBMessage();
					esbMessage.setCode("CMS10000");
					esbMessage.setText("All Task Assignment Failed");
					esbMessage.setType("ERROR");
					esbMessages.getMessages().add(esbMessage);
					CaseManagementRuntimeException cre = new CaseManagementRuntimeException("All Task Assignment Failed");
					cre.setEsbMessages(esbMessages);
					throw cre;
				}

			} catch (ExecutionException exception) {
				Throwable throwable = exception.getCause();
				if (throwable instanceof CaseManagementRuntimeException) {
					String message = throwable.getMessage();
					throw new CaseManagementRuntimeException(message);
				}
			} finally {
				if (executor != null) {
					executor.shutdown();
				}
			}
		}
		return returnProcesses;
	}

	@Override
	public TaskResponse getTaskById(Request request) {
		TaskResponse taskResponse = new TaskResponse();
		String userId = (String) request.getAttribute(USER_ID);
		//String caseId = (String) request.getAttribute(PROCESS_ID);
		String wobId = (String) request.getAttribute(TASK_ID);
		String queueName = (String)  request.getAttribute(QUEUE_NAME);
		String property = (String) request.getAttribute(PROPERTY);
		if (queueName != null && wobId != null) {
			Step icmStepDetails = icmRepository.getICMStepDetails(wobId, queueName, userId, property);
			if(null != icmStepDetails){
				taskResponse = jsonUnmarshaller.icmStepToTask(icmStepDetails);
			}
		}		
		return taskResponse;
	}
	@Override
	public org.tiaa.esb.case_management_rs_v2.type.Task updateTask(Request request) {
		TaskRequest taskRequest = (TaskRequest) request
				.getAttribute(TASK_REQUEST);
		String wobId = (String) request.getAttribute(WOB_ID);
		String userId = (String) request.getAttribute(USER_ID);
		org.tiaa.esb.case_management_rs_v2.type.Task task = taskRequest.getTask();
		
		String actionName = task.getAction().getItems().get(0);
		String queueName = task.getQueues().getItems().get(0);
		org.tiaa.esb.case_management_rs_v2.type.Task taskResponse=new org.tiaa.esb.case_management_rs_v2.type.Task();
		org.tiaa.esb.icm.types.Response response = new org.tiaa.esb.icm.types.Response();
		Step step = null;
		if (!actionName.equalsIgnoreCase(ACTION_UNLOCK)) {
			step = jsonUnmarshaller.tasksToIcmSteps(task);
		}

		if (actionName.equalsIgnoreCase(ICM_ACTION_REASSIGN)) {
			response = icmRepository.reAssignIcmTask(wobId, userId, queueName, step);
		} else if (actionName.equalsIgnoreCase(ACTION_UNLOCK)) {

			response = icmRepository.unLockIcmTask(wobId, userId, queueName);
		} else {
			response = icmRepository.actionIcmTask(wobId, userId, queueName,
					step);

		}
		if(response == null){
			throw new WorkflowException("Issue while updating Step in ICM");
		}else if(response.getStatus().equalsIgnoreCase(FAILURE) || response.getStatus().equalsIgnoreCase(ERROR)){
			throw new WorkflowException(response.getErrorMessage());
		}
		return taskResponse;
	}
	
	@Override
	public Task createTask(Request request) {
		
		TaskRequest taskRequest = (TaskRequest) request
				.getAttribute(TASK_REQUEST);
		String caseId = (String) request.getAttribute(PROCESS_ID);
		String userId = (String) request.getAttribute(USER_ID);
		org.tiaa.esb.case_management_rs_v2.type.Task task = taskRequest.getTask();
		org.tiaa.esb.icm.types.Response response = new org.tiaa.esb.icm.types.Response();
	    
		org.tiaa.esb.icm.types.Task icmTask = jsonUnmarshaller.tasksToIcmTask(task);
		response = icmRepository.createIcmTask(caseId,icmTask, userId);
		
		if (StringUtils.isNotBlank(response.getStatus()) && SUCCESS.equalsIgnoreCase(response.getStatus())) {
			return new org.tiaa.esb.case_management_rs_v2.type.Task();
		}

		return null;
	}
	
	private class IcmAssignedTask implements
			Callable<org.tiaa.esb.icm.types.Response> {
		private Step stepElement;
		private String userId;

		public IcmAssignedTask(Step stepElement, String userId) {
			this.stepElement = stepElement;
			this.userId = userId;
		}

		@Override
		public org.tiaa.esb.icm.types.Response call() {
			org.tiaa.esb.icm.types.Response response = new org.tiaa.esb.icm.types.Response();
			try{
				response =  icmRepository.reAssignIcmTask(stepElement.getWobId(), userId, stepElement.getQueueName(), stepElement);
			} catch (Exception e) {
				response.setStatus(ERROR);
			}
			response.setId(stepElement.getWobId());
			return response;
		}

	}
	
	@Override
	public ConfigItems searchConfigItems(Request request) {
		String userId = (String) request.getAttribute(USER_ID);
		SearchRequest searchRequest = (SearchRequest) request.getAttribute(SEARCH_REQUEST);
		String property = (String) request.getAttribute(PROPERTY);
		
		StepList stepList = jsonUnmarshaller.searchReqToStepList(searchRequest);
		Map<String, String> configMap = icmRepository.searchConfigItems(stepList, userId, property);
		
		ConfigItems items = new ConfigItems();
		ConfigItem item = new ConfigItem();
		item.setItemName(property);
		if(configMap != null && configMap.size() > 0){
			for(String key : configMap.keySet()){
				ConfigData data = new ConfigData();
				data.setShortDescription(key);
				data.setLongDescription(configMap.get(key));
				item.getDataPairs().add(data);
			}
		}
		items.getConfigItems().add(item);
		
		return items;
	}
	
	@Override
	public String toString(){
		return "ICM";
	}
	
	public void deleteDocument(Request request) {

		String caseId = (String) request.getAttribute(PROCESS_ID);
		String docTemplateCode = (String) request.getAttribute(DOCUMENT_ID);
		String userId = (String) request.getAttribute(USER_ID);

		this.icmService.deleteICMDocument(caseId, docTemplateCode, userId);

	}
}
