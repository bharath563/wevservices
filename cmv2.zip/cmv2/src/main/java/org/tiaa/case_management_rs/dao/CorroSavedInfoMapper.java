package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;
import org.tiaa.esb.case_management_rs_v2.type.SubField;
import org.tiaa.esb.case_management_rs_v2.type.SubFields;

public class CorroSavedInfoMapper extends AbstractRowMapper<ConfigData>
implements RowMapper<ConfigData> {

	@Override
	public ConfigData mapRow(ResultSet rs, int rowNum) throws SQLException {
		ConfigData corrSaveInfo = new ConfigData();

		corrSaveInfo.setShortDescription(getStringTrimmed(rs, "ShortDescription"));
		corrSaveInfo.setLongDescription(getStringTrimmed(rs, "LongDescription"));
		
		SubFields subFields = new SubFields();
		
		SubField nameSubField = new SubField();
		nameSubField.setFieldName("Name");
		nameSubField.setFieldValue(getStringTrimmed(rs, "NAME"));
		subFields.getSubFields().add(nameSubField);
		
		SubField address1SubField = new SubField();
		address1SubField.setFieldName("Address1");
		address1SubField.setFieldValue(getStringTrimmed(rs, "ADDRESS1"));
		subFields.getSubFields().add(address1SubField);
		
		SubField address2SubField = new SubField();
		address2SubField.setFieldName("Address2");
		address2SubField.setFieldValue(getStringTrimmed(rs, "ADDRESS2"));
		subFields.getSubFields().add(address2SubField);
		
		SubField address3SubField = new SubField();
		address3SubField.setFieldName("Address3");
		address3SubField.setFieldValue(getStringTrimmed(rs, "ADDRESS3"));
		subFields.getSubFields().add(address3SubField);
		
		SubField citySubField = new SubField();
		citySubField.setFieldName("City");
		citySubField.setFieldValue(getStringTrimmed(rs, "CITY"));
		subFields.getSubFields().add(citySubField);
		
		SubField stateZipSubField = new SubField();
		stateZipSubField.setFieldName("StateZip");
		stateZipSubField.setFieldValue(getStringTrimmed(rs, "STATEZIP"));
		subFields.getSubFields().add(stateZipSubField);

		SubField salutationSubField = new SubField();
		salutationSubField.setFieldName("Salutation");
		salutationSubField.setFieldValue(getStringTrimmed(rs, "SALUTATION"));
		subFields.getSubFields().add(salutationSubField);
		
		corrSaveInfo.setSubFields(subFields);
		
		return corrSaveInfo;
	}

}
