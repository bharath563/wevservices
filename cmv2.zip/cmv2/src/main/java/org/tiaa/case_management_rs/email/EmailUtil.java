package org.tiaa.case_management_rs.email;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.domain.CMSAudit;
import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.utils.CommonUtil;

public final class EmailUtil {
	public static final String PROD_SUPPORT_SIGNATURE = " " + AppConstants.APPLICATION_DESCRIPTION + " Prod Support";
	public static final String AUTOMATED_EMAIL_TEXT = "&nbsp;&nbsp;&nbsp;&nbsp;***" + PROD_SUPPORT_SIGNATURE + " auto-generated email notification***";
	public static final String PROD_SUPPORT = " Prod Support";
	public static final String SUPPORT_EMAIL = "support.email";
	public static final String HTML_LINE_BREAK = "<br />";
	public static final String SERVER_REPORT_NAME_IN_ERROR_REPORT_EMAIL = "Server Name - ";
	public static final String THANKS_TEXT = "Thanks,";
	private static String emailBodyFooterText;
	private static String serverNameDetails;

	private EmailUtil() {
	}

	public static String getEmailBodyFooterText() {
		return emailBodyFooterText;
	}

	public static String getServerNameDetails() {
		return serverNameDetails;
	}

	private static String getEmailBodyFooterTextInternal() {
		StringBuilder emailMessageBuffer = new StringBuilder();
		emailMessageBuffer.append(HTML_LINE_BREAK);
		emailMessageBuffer.append(HTML_LINE_BREAK);
		emailMessageBuffer.append("Thanks,");
		emailMessageBuffer.append(HTML_LINE_BREAK);
		emailMessageBuffer.append(" Prod Support");
		emailMessageBuffer.append(HTML_LINE_BREAK);
		emailMessageBuffer.append(HTML_LINE_BREAK);
		emailMessageBuffer.append(HTML_LINE_BREAK);
		emailMessageBuffer.append(AUTOMATED_EMAIL_TEXT);
		return emailMessageBuffer.toString();
	}

	private static String getServerNameDetailsInternal() {
		String[] hostNameIpAddress = CommonUtil.getHostNameIpAddress();
		StringBuilder emailMessageBuilder = new StringBuilder();
		emailMessageBuilder.append("Server Name - ");
		emailMessageBuilder.append(hostNameIpAddress[0]);
		emailMessageBuilder.append(HTML_LINE_BREAK);
		emailMessageBuilder.append(HTML_LINE_BREAK);
		return emailMessageBuilder.toString();
	}

	private static void init() {
		emailBodyFooterText = getEmailBodyFooterTextInternal();
		serverNameDetails = getServerNameDetailsInternal();
	}

	static {
		init();
	}

	public static String createEmail(String emailContents) {
		HashMap<String, Object> variables = new HashMap<String, Object>();
		variables.put("emailContents", emailContents);
		variables.put("env", "");
		return new EmailBuilder("EmailTemplate3.html").executeTemplate(variables);
	}

	public static String createEmail(CMSAuditHistory cmsAuditHistory, Exception ex) {
		HashMap<String, Object> variables = new HashMap<String, Object>();
		variables.put("rosterId", String.valueOf(cmsAuditHistory.getCmsAuditHistoryId()));
		variables.put("cthStatus", cmsAuditHistory.getCthRequestStatus());
		variables.put("retryAttempt", cmsAuditHistory.getRetryAttempt());
		
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		variables.put("requestId", cmsAudit.getCthRequestId());
		variables.put("orchestrationId", cmsAudit.getCthOrchestrationId());
		variables.put("taskId", cmsAudit.getTaskId());
		variables.put("taskType", cmsAudit.getTaskType());
		
		variables.put("errorDate", new SimpleDateFormat("MM/dd/yyyy hh:mm:ss").format(new Date()));
		variables.put("errorMessage", ex.getMessage());
	
		String exceptionStackTrace = CommonUtil.exceptionStackTrace(ex);
		exceptionStackTrace = exceptionStackTrace.replaceAll("\r\n", "<br/>");
		variables.put("errorStack", exceptionStackTrace);
		
		variables.put("env", "");
		return new EmailBuilder().executeTemplate(variables);
	}

	public static String createEmail(Exception ex) {
		HashMap<String, Object> variables = new HashMap<String, Object>();
		variables.put("errorDate", new SimpleDateFormat("MM/dd/yyyy hh:mm:ss").format(new Date()));
		variables.put("errorMessage", ex.getMessage());
		String exceptionStackTrace = CommonUtil.exceptionStackTrace(ex);
		exceptionStackTrace = exceptionStackTrace.replaceAll("\r\n", "<br/>");
		variables.put("errorStack", exceptionStackTrace);
		variables.put("env", "");
		return new EmailBuilder("EmailTemplate2.html").executeTemplate(variables);
	}
}
