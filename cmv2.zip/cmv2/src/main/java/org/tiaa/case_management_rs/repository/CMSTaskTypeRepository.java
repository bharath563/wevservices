package org.tiaa.case_management_rs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import org.tiaa.case_management_rs.domain.CMSTaskType;

@Repository
public interface CMSTaskTypeRepository extends JpaRepository<CMSTaskType, Long> {
	CMSTaskType findByTaskType(String taskType);
	List<CMSTaskType> findByCthRequestSchemaName(String cthRequestSchemaName);
	List<CMSTaskType> findByPlanModificationRequestTask(boolean planModificationRequestTask);
	List<CMSTaskType> findByPlanModificationRequestTaskAndCthRequestSchemaNameIsNull(boolean planModificationRequestTask);
}
