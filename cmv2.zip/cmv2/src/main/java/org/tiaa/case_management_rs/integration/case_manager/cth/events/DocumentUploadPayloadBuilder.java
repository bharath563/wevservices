package org.tiaa.case_management_rs.integration.case_manager.cth.events;

import java.io.StringWriter;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.integration.federeated_document.MimeTypeHelper;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.add_document.types.CommentType;
import org.tiaa.esb.add_document.types.CommentsType;
import org.tiaa.esb.add_document.types.FederatedDocumentType;
import org.tiaa.esb.add_document.types.FileCorrespondenceDocumentType;
import org.tiaa.esb.add_document.types.FileCorrespondenceRequest;
import org.tiaa.esb.add_document.types.IdType;
import org.tiaa.esb.add_document.types.ObjectFactory;
import org.tiaa.esb.add_document.types.RequestControlDataType;
import org.tiaa.esb.add_document.types.RequestTransactionDataType;
import org.tiaa.esb.add_document.types.TaskRequestType;
import org.tiaa.esb.add_document.types.TransactionRequest;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;
import org.tiaa.esb.servicerequest_workflow.types.DocumentType;
import org.tiaa.esb.servicerequest_workflow.types.PersonNameType;

@Component
public class DocumentUploadPayloadBuilder {
	private static ObjectFactory objectFactory = new ObjectFactory();
	private static final String PATH_TYPE_PLAN_FOCUS_INBOUND = "PlanFocus/Inbound";
	@Autowired
	private Jaxb2Marshaller transactionRequestJaxbMarshaller;

	public String process(CaseInfo caseInfo, CaseInRosterItem caseInRosterItem, DocumentType documentType) {
		TransactionRequest transactionRequest = createTransactionRequest(caseInfo, caseInRosterItem, documentType);
		return toString(transactionRequest);
	}

	private String toString(TransactionRequest transactionRequest) {
		try {
			Marshaller jaxbMarshaller = this.transactionRequestJaxbMarshaller.getJaxbContext().createMarshaller();
			//
			StringWriter payload = new StringWriter();
			jaxbMarshaller.marshal(transactionRequest, payload);
			return payload.toString();
		} catch (JAXBException e) {
			throw new RuntimeException(e);
		}
	}

	private TransactionRequest createTransactionRequest(CaseInfo caseInfo, CaseInRosterItem caseInRosterItem, DocumentType documentType) {
		RequestControlDataType requestControlDataType = constructRequestControlDataType(caseInRosterItem);
		TaskRequestType taskRequestType = constructTaskRequestType(caseInfo, documentType);
		//
		RequestTransactionDataType requestTransactionDataType = new RequestTransactionDataType();
		requestTransactionDataType.setRequestDataObject(taskRequestType(taskRequestType));
		//
		TransactionRequest transactionRequest = new TransactionRequest();
		transactionRequest.setControlData(requestControlDataType);
		transactionRequest.setTransactionData(requestTransactionDataType);
		return transactionRequest;
	}

	private TaskRequestType constructTaskRequestType(CaseInfo caseInfo, DocumentType documentType) {
		FileCorrespondenceRequest.Documents fileCorrespondenceRequestDocuments = new FileCorrespondenceRequest.Documents();
		FileCorrespondenceDocumentType fileCorrespondenceDocumentType = mapDocument(documentType);
		fileCorrespondenceRequestDocuments.getDocuments().add(fileCorrespondenceDocumentType);
		//
		FileCorrespondenceRequest fileCorrespondenceRequest = new FileCorrespondenceRequest();
		fileCorrespondenceRequest.setDocuments(fileCorrespondenceRequestDocuments);
		//
		TaskRequestType taskRequestType = new TaskRequestType();
		PersonNameType uploadedBy = documentType.getUploadedBy();
		taskRequestType.setActionedBy(uploadedBy.getFirstName() + " " + uploadedBy.getLastName());
		taskRequestType.setActionedOn(documentType.getBusinessDate());
		//
		fileCorrespondenceDocumentType.setComments(mapComments(taskRequestType, documentType));
		taskRequestType.setTaskRequestObjectGroup(objectFactory.createFileCorrespondenceRequest(fileCorrespondenceRequest));
		return taskRequestType;
	}

	private FileCorrespondenceDocumentType mapDocument(DocumentType documentType) {
		FederatedDocumentType federatedDocumentType = new FederatedDocumentType();
		String businessUnit = documentType.getBusinessUnit();
		String businessUnitValue = businessUnit != null ? businessUnit: "PENSION";
		federatedDocumentType.setBusinessUnit(businessUnitValue);
		federatedDocumentType.setVersion(documentType.getDocumentVersion().toString());
		federatedDocumentType.setDocID(documentType.getDocumentIDs().getDocumentIDs().get(0).getValue());
		federatedDocumentType.setIdType(IdType.DRI);
		String documentCode = documentType.getDocumentCode();
		String docCode = documentCode != null? documentCode : "INST_DOCS";
		federatedDocumentType.setDocCode(docCode);
		federatedDocumentType.setDocumentName(documentType.getDocumentType());
		federatedDocumentType.setPathType(PATH_TYPE_PLAN_FOCUS_INBOUND);
		federatedDocumentType.setMimeType(getMimeType(documentType));
		//
		FileCorrespondenceDocumentType fileCorrespondenceDocumentType = new FileCorrespondenceDocumentType();
		fileCorrespondenceDocumentType.setFederatedDocument(objectFactory.createFederatedDocument(federatedDocumentType));
		return fileCorrespondenceDocumentType;
	}

	private CommentsType mapComments(TaskRequestType taskRequestType, DocumentType documentType) {
		CommentsType commentsType = new CommentsType();
		List<CommentType> comments = commentsType.getComments();
		if (documentType.getComments() != null) {
			for (org.tiaa.esb.servicerequest_workflow.types.CommentType commentType : documentType.getComments().getComments()) {
				CommentType addDocCommentType = new CommentType();
				addDocCommentType.setMessage(commentType.getComment());
				comments.add(addDocCommentType);
				//
			}
		}
		return commentsType;
	}

	private RequestControlDataType constructRequestControlDataType(CaseInRosterItem caseInRosterItem) {
		RequestControlDataType requestControlDataType = new RequestControlDataType();
		requestControlDataType.setRequestID(caseInRosterItem.getRequestId());
		requestControlDataType.setCaseID(caseInRosterItem.getCaseId());
		requestControlDataType.setCaseType(caseInRosterItem.getCaseType());
		requestControlDataType.setCorrelationID(caseInRosterItem.getCorrelationId());
		requestControlDataType.setOrchestrationId(caseInRosterItem.getOrchestrationId());
		requestControlDataType.setSolution(caseInRosterItem.getSolutionType());
		requestControlDataType.setTaskOperation(caseInRosterItem.getTaskOperation());
		requestControlDataType.setChannel(caseInRosterItem.getChannel());
		requestControlDataType.setSlowLane(null);
		requestControlDataType.setResponseRequired(caseInRosterItem.getResponseRequired());
		requestControlDataType.setOriginatorID(caseInRosterItem.getOriginatorId());
		requestControlDataType.setRequestedAt(DateUtil.toXMLGregorianCalendar(new Date()));
		return requestControlDataType;
	}

	private JAXBElement<TaskRequestType> taskRequestType(TaskRequestType taskRequestType) {
		QName name = new QName("urn:tiaa-cref:schema:filenet:icm:case:operations:2:0", "TaskRequest");
		return new JAXBElement<TaskRequestType>(name, TaskRequestType.class, null, taskRequestType);
	}

	private String getMimeType(DocumentType documentType) {
		String extension = documentType.getDocumentType().substring(documentType.getDocumentType().lastIndexOf(".") + 1);
		return MimeTypeHelper.getMimeTypeFromExtension(extension);
	}
}
