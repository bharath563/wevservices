package org.tiaa.case_management_rs.integration.exp_ag;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public abstract class AbstractRowMapper<T> implements RowMapper<T> {
	protected String getString(ResultSet resultSet, String key) throws SQLException {
		return resultSet.getString(key);
	}

	protected String getStringTrimmed(ResultSet resultSet, String key) throws SQLException {
		return trim(resultSet.getString(key));
	}

	protected String trim(String string) {
		return string == null ? "" : string.trim();
	}
	
	protected int getInteger(ResultSet resultSet, String key) throws SQLException {
		return resultSet.getInt(key);
	}

}
