package org.tiaa.case_management_rs.integration.cth;

import java.util.concurrent.TimeUnit;

import org.tiaa.case_management_rs.common.PropertiesProvider;

public class CTHWSRetryConfiguration {
	private static final int DEFAULT_RETRY_CTHWS_INITIAL_DELAY = 0;
	private static final int DEFAULT_RETRY_CTHWS_PERIOD = 65;
	private final TimeUnit retryCTHWSTimeUnit = TimeUnit.MINUTES;
	private final long retryCTHWSMaxAgeInMillis = TimeUnit.MINUTES.toMillis(70);
	private final int retryCorePoolSize;
	private final int retryMaxPoolSize;
	private final int retryQueueCapacity;
	//
	private final int backOffPeriod;
	private final int retryAttempts;
	private final int taskSchedulerPoolSize;

	public CTHWSRetryConfiguration(PropertiesProvider propertiesProvider) {
		final int defaultSchedulerPoolSize = 5;
		retryCorePoolSize = propertiesProvider.getIntProperty("retry.core.pool.size");
		retryMaxPoolSize = propertiesProvider.getIntProperty("retry.max.pool.size");
		retryQueueCapacity = propertiesProvider.getIntProperty("retry.queue.capacity");
		//
		backOffPeriod = propertiesProvider.getIntProperty("retry.backOff.period");
		retryAttempts = propertiesProvider.getIntProperty("retry.attempts");
		taskSchedulerPoolSize = propertiesProvider.getIntProperty("task.scheduler.pool.size", defaultSchedulerPoolSize);
	}

	public int getRetryCTHWSInitialDelay() {
		return DEFAULT_RETRY_CTHWS_INITIAL_DELAY;
	}

	public int getRetryCTHWSPeriod() {
		return DEFAULT_RETRY_CTHWS_PERIOD;
	}

	public TimeUnit getRetryCTHWSTimeUnit() {
		return retryCTHWSTimeUnit;
	}

	public long getRetryCTHWSMaxAgeInMillis() {
		return retryCTHWSMaxAgeInMillis;
	}

	public int getRetryCorePoolSize() {
		return retryCorePoolSize;
	}

	public int getRetryMaxPoolSize() {
		return retryMaxPoolSize;
	}

	public int getRetryQueueCapacity() {
		return retryQueueCapacity;
	}

	public int getBackOffPeriod() {
		return backOffPeriod;
	}

	public int getRetryAttempts() {
		return retryAttempts;
	}

	public int getTaskSchedulerPoolSize() {
		return taskSchedulerPoolSize;
	}
}
