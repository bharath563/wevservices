package org.tiaa.case_management_rs.integration.icm;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ICMRepositoryLinkHelper {
	
	@Value("${icmSearchURL}")
	private String icmSearchURL;
	
	@Value("${icmProcessRestURL}")
	private String icmProcessRestURL;
	
	@Value("${icmCaseAdditionalInfo}")
	private String icmCaseAdditionalInfoURL;
	
	@Value("${icmTasksURL}")
	private String icmTasksURL;
	
	@Value("${icmDocumentsURL}")
	private String icmDocumentsURL;
	
	@Value("${icmCommentsURL}")
	private String icmCommentsURL;

	@Value("${icmConfigURL}")
	private String icmConfigURL;
	
	@Value("${icmSolutionURL}")
	private String icmSolutionURL;

	@Value("${icmRelatedCasesURL}")
	private String icmRelatedCasesURL;

	@Value("${icmSolutionHeadersURL}")
	private String icmSolutionHeadersURL;

	@Value("${icmGetStepsURL}")
	private String icmGetStepsURL;
	
	@Value("${icmStepURL}")
	private String icmStepURL;
	
	@Value("${icmGetHistoryURL}")
	private String icmGetHistoryURL;

	public String getIcmSearchURL() {
		return this.icmSearchURL;
	}

	public String getIcmProcessRestURL() {
		return this.icmProcessRestURL;
	}

	public String getIcmTasksURL() {
		return icmTasksURL;
	}

	public String getIcmDocumentsURL() {
		return icmDocumentsURL;
	}

	public String getIcmCommentsURL() {
		return icmCommentsURL;
	}

	public String getIcmConfigURL() {
		return icmConfigURL;
	}

	// added for ICM entitled solutions
	public String getIcmSolutionsURL() {
		return icmSolutionURL;
	}

	/**
	 * This function return URL for Related Cases of ICM
	 * 
	 * @return
	 */
	public String getIcmRelatedCasesURL(){
		return icmRelatedCasesURL;
	}
	
	public String getIcmSolutionHeadersURL() {
		return icmSolutionHeadersURL;
	}

	/* to get the processurl of ICM */
	public String getIcmStepsURL() {
		return icmGetStepsURL;
	}

	public String getIcmCaseAdditionalInfoURL() {
		return icmCaseAdditionalInfoURL;
	}
	
	public String getStepURL() {
		return icmStepURL;
	}

	public String getIcmGetHistoryURL() {
		return icmGetHistoryURL;
	}
	
}
