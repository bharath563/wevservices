package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.Event;
import org.tiaa.esb.case_management_rs_v2.type.EventType;

public class EXPAGTaskHistoryMapper  extends AbstractRowMapper<Event> implements RowMapper<Event> {
	
	private static final String HYPHEN_CONST = "-";

	@Override
	public Event mapRow(ResultSet rs, int rowNum) throws SQLException {
		Event event= new Event();
		event.setProcessId(getStringTrimmed(rs,"EVENT_PROCESSID"));
		event.setTitle(getStringTrimmed(rs,"EVENTTITLE"));
		//event.setDescription(getStringTrimmed(rs,"EVENT_DESC"));
		event.setEventType(EventType.TASK);
		event.setBizUnit(getStringTrimmed(rs,"EVENT_BIZUNIT"));
		event.setActionStep(getStringTrimmed(rs,"EVENT_ACTIONSTEP"));
		event.setCreatedBy(getStringTrimmed(rs,"EVENT_CREATEDBY"));

		String eventCreateDateTime = getStringTrimmed(rs,"CREATE_DATETIME");
		String eventCompleteDateTime = getStringTrimmed(rs,"COMPLETE_DATETIME");
		Calendar cal = Calendar.getInstance();
		DateFormat originaFormat = new SimpleDateFormat(DateUtil.DEFAULT_DATE_FORMAT_6);
		Date createDateTime = new Date();
		Date completeDateTime = new Date();
		try {
			createDateTime = originaFormat.parse(eventCreateDateTime);
			completeDateTime= originaFormat.parse(eventCompleteDateTime);
		} catch (java.text.ParseException e) {
			e.printStackTrace();
		}
		cal.setTime(createDateTime);
		XMLGregorianCalendar gregorianCreateDateTime=DateUtil.toXMLGregorianCalendarDateTime(cal.getTime());
		event.setCreateDateTime(gregorianCreateDateTime);
		
		cal.setTime(completeDateTime);
		XMLGregorianCalendar gregorianCompleteDateTime=DateUtil.toXMLGregorianCalendarDateTime(cal.getTime());
		event.setCompleteTime(gregorianCompleteDateTime);
		
		
		String eventDesc = getStringTrimmed(rs,"EVENT_DESC");
		if("Edit defaults".equals(eventDesc)){
			String actionStep = (getStringTrimmed(rs,"ACTION_STEP"));
			String workBasket = (getStringTrimmed(rs,"WORK_BASKET"));
			String priority = (getStringTrimmed(rs,"PRIORITY"));
			StringBuffer postEventDesc = new StringBuffer(": "); 
			
			if ((!actionStep.equals("") && !actionStep.equals("-1"))
					|| getStringTrimmed(rs, "QAINDIC").equals("0")) {
				postEventDesc.append("Action Step").append(CaseManagementConstants.SPACE_COMMA_SAPCE);
			}

			if (!workBasket.equals("")) {
				postEventDesc.append("Workbasket").append(CaseManagementConstants.SPACE_COMMA_SAPCE);
			}
			if (!priority.equals("") && !priority.equals("-1")) {
				postEventDesc.append("Priority").append(CaseManagementConstants.SPACE_COMMA_SAPCE);
			}

			if (!postEventDesc.toString().trim().equals(":")) {
				eventDesc = eventDesc + postEventDesc.substring(0, postEventDesc.length() - 3);
			}
		}
		event.setDescription(eventDesc);
		
		return event;

	}
}
