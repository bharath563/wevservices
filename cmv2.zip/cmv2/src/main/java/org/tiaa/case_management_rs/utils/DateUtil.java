package org.tiaa.case_management_rs.utils;

import static org.tiaa.case_management_rs.utils.CommonUtil.*;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.StringUtils;

public final class DateUtil {
	private static final Logger LOG = LoggerFactory.getLogger(DateUtil.class);
	public static final String DEFAULT_DATE_FORMAT = "yyyy-MM-dd hh:mm:ss";
	public static final String DEFAULT_DATE_FORMAT_6 = "yyyy-MM-dd HH:mm:ss";
	public static final String DEFAULT_DATE_FORMAT_2 = "yyyy-MM-dd hh:mm:ss aa";
	public static final String DEFAULT_DATE_FORMAT_3 = "yyyy-MM-dd hh:mm:ss";
	public static final String DEFAULT_DATE_FORMAT_4 = "yyyy/MM/dd HH:mm:ss";
	public static final String DEFAULT_DATE_FORMAT_5 = "MM/dd/YYYY";
	public static final String MONTH_YEAR_DATE_HOUR_MINUTE = "MM/dd/yyyy hh:mm a";
	public static final String DATE_FORMAT_WITH_MILLISECONDS = "MM/dd/yyyy hh:mm:ss.SSS a";
	public static final String DATE_FORMAT_WITHOUT_MILLISECONDS = "MM/dd/yyyy hh:mm:ss a";
	public static final String DATE_FORMAT_FOR_MOBIUSEMAIL="MMM dd, yyyy hh:mm:ss a";
	public static final String XML_GREGORIAN_CALENDAR_DATE_FORMAT="yyyy-MM-dd'T'HH:mm:ss";
	public static final String YEAR_MONTH_DAY_FORMAT="yyMMdd";
	
	public static final DateFormat DATE_FORMAT_YYYYMMDD = new SimpleDateFormat("yyyyMMdd");
	public static final DateFormat DATE_FORMAT_HHmmss = new SimpleDateFormat("HHmmss");
	
	public static final DateFormat DF_WITH_MILLISECONDS = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss.SSS a");
	public static final DateFormat DF_WITHOUT_MILLISECONDS = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
	/**
	 * Default date format to be use with SimpleDateFormat class
	 */
	public static final String DEFAULT_SIMPLE_DATE_FORMAT = "yyyy-MM-dd";
	private static DatatypeFactory datatypeFactory;

	private DateUtil() {
	}

	public static String toXmlFormat(Date completedDateTime) {
		return toXMLGregorianCalendar(completedDateTime).toXMLFormat();
	}

	public static String toFormat(XMLGregorianCalendar cal, String format) {
		if (cal == null) {
			return "";
		}
		long timeInMillis = cal.toGregorianCalendar().getTimeInMillis();
		return new SimpleDateFormat(format).format(new Date(timeInMillis));
	}

	public static XMLGregorianCalendar getCurrentDate() {
		GregorianCalendar instance = (GregorianCalendar) GregorianCalendar.getInstance();
		return getDatatypeFactory().newXMLGregorianCalendar(instance);
	}

	public static Date getStartOfDay() {
		Calendar instance = Calendar.getInstance();
		instance.set(Calendar.HOUR, 0);
		instance.set(Calendar.MINUTE, 0);
		instance.set(Calendar.SECOND, 0);
		instance.set(Calendar.MILLISECOND, 0);
		instance.set(Calendar.AM_PM, Calendar.AM);
		instance.set(Calendar.DATE, instance.get(Calendar.DATE));
		return instance.getTime();
	}

	public static Date beginningOfDay() {
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE), 0, 0, 0);
		return new Date(calendar.getTimeInMillis());
	}

	public static String getHourIn12HourFormat(String hour) {
		final int midDayHour = 12;
		int hourAsInt = Integer.parseInt(hour);
		if (hourAsInt == 0) {
			return "12 am";
		}
		if (hourAsInt == midDayHour) {
			return "12 pm";
		}
		DecimalFormat decimalFormat = new DecimalFormat("00");
		if (hourAsInt > midDayHour) {
			return decimalFormat.format(hourAsInt - midDayHour) + " pm";
		}
		return (decimalFormat.format(hourAsInt)) + " am";
	}

	public static String format(Timestamp timestamp) {
		if (timestamp == null) {
			return "";
		}
		return new SimpleDateFormat(DEFAULT_DATE_FORMAT).format(new Date(timestamp.getTime()));
	}

	public static String hour(Timestamp timestamp) {
		if (timestamp == null) {
			return "";
		}
		return new SimpleDateFormat("hh").format(new Date(timestamp.getTime()));
	}

	public static String amOrPm(Timestamp timestamp) {
		if (timestamp == null) {
			return "";
		}
		return new SimpleDateFormat("aa").format(new Date(timestamp.getTime()));
	}

	public static String time(Timestamp timestamp) {
		if (timestamp == null) {
			return "";
		}
		return new SimpleDateFormat("hh:mm aa").format(new Date(timestamp.getTime()));
	}

	public static String minutes(Timestamp timestamp) {
		if (timestamp == null) {
			return "";
		}
		return new SimpleDateFormat("mm").format(new Date(timestamp.getTime()));
	}

	public static int hourOfDay(Timestamp timestamp) {
		if (timestamp == null) {
			return 0;
		}
		String format = new SimpleDateFormat("hh").format(new Date(timestamp.getTime()));
		return Integer.parseInt(format);
	}

	public static String date(Timestamp timestamp) {
		if (timestamp == null) {
			return "";
		}
		return new SimpleDateFormat("yyyy-MM-dd").format(new Date(timestamp.getTime()));
	}

	public static String format(SimpleDateFormat simpleDateFormat, Timestamp timestamp) {
		if (timestamp == null) {
			return "";
		}
		return simpleDateFormat.format(new Date(timestamp.getTime()));
	}

	public static SimpleDateFormat createSimpleDateFormat() {
		return new SimpleDateFormat(DEFAULT_DATE_FORMAT);
	}

	public static String hourOfDay() {
		return new SimpleDateFormat("HH").format(new Date());
	}

	public static String today() {
		return new SimpleDateFormat("yyyyMMdd").format(new Date());
	}

	public static boolean outsideBusinessHours() {
		return !withinBusinessHours();
	}

	public static boolean withinBusinessHours() {
		final int startOfBusinessHours = 8;
		final int endOfBusinessHours = 19;
		Calendar today = Calendar.getInstance();
		int hourOfDay = today.get(Calendar.HOUR_OF_DAY);
		return (hourOfDay > startOfBusinessHours) && (hourOfDay < endOfBusinessHours);
	}

	public static boolean weekday(String dateStr) throws ParseException {
		final int sunday = 1;
		final int saturday = 7;
		Date date = new SimpleDateFormat("dd/MM/yyyy").parse(dateStr);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
		return (dayOfWeek > sunday) && (dayOfWeek < saturday);
	}

	public static boolean weekend() {
		return !weekday();
	}

	public static boolean weekday() {
		final int sunday = 1;
		final int saturday = 7;
		Calendar today = Calendar.getInstance();
		int dayOfWeek = today.get(Calendar.DAY_OF_WEEK);
		return (dayOfWeek > sunday) && (dayOfWeek < saturday);
	}

	public static void main(String[] args) throws ParseException {
		Date parseDateTime = parseDateTime("20160105", "13191200");
		LOG.info(parseDateTime.toString());
		LOG.info(toXMLGregorianCalendarDateOnly(parseDateTime).toString());
		assert (!weekday("08/12/2013"));
		assert (weekday("09/12/2013"));
		assert (weekday("10/12/2013"));
		assert (weekday("11/12/2013"));
		assert (weekday("12/12/2013"));
		assert (weekday("13/12/2013"));
		assert (!weekday("14/12/2013"));
		LOG.info(String.valueOf(withinBusinessHours()));
	}

	public static Date parseTime(String time) throws ParseException {
		String format = "HHmmssSS";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
		final int length = format.length();
		String str = time.length() < length ? StringUtils.leftPad(time, length, '0') : time;
		return simpleDateFormat.parse(str);
	}

	public static Date parseDateTime(String date, String time) {
		return parseDateTime(date,time,"yyyyMMddHHmmssSS");
			
	}
	
	public static Date parseDateTime(String date, String time,String format) {
		if ((date == null) && (time == null)) {
			return null;
		}
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
			final int length = 8;// HHmmssSS length
			String timeStr = time.length() < length ? StringUtils.leftPad(time, length, '0') : time;
			return simpleDateFormat.parse(date + timeStr);
		} catch (ParseException e) {
			throw new ParsingException(e);
		}
	}

	public static XMLGregorianCalendar toXMLGregorianCalendar(Date date) {
		if (date == null) {
			return null;
		}
		GregorianCalendar instance = (GregorianCalendar) GregorianCalendar.getInstance();
		instance.setTime(date);
		return datatypeFactory.newXMLGregorianCalendar(instance);
	}

	public static XMLGregorianCalendar toXMLGregorianCalendarDateOnly(Date date) {
		if (date == null) {
			return null;
		}
		GregorianCalendar instance = (GregorianCalendar) GregorianCalendar.getInstance();
		instance.setTime(date);
		XMLGregorianCalendar xmlGregorianCalendarForDate = datatypeFactory.newXMLGregorianCalendar();
		xmlGregorianCalendarForDate.setYear(instance.get(Calendar.YEAR));
		xmlGregorianCalendarForDate.setMonth(instance.get(Calendar.MONTH) + 1);
		xmlGregorianCalendarForDate.setDay(instance.get(Calendar.DATE));
		return xmlGregorianCalendarForDate;
	}

	/**
	 * Date + Time without time zone
	 * @param date
	 * @return
	 */
	public static XMLGregorianCalendar toXMLGregorianCalendarDateTime(Date date) {
		if (date == null) {
			return null;
		}
		GregorianCalendar instance = (GregorianCalendar) GregorianCalendar.getInstance();
		instance.setTime(date);
		XMLGregorianCalendar xmlGregorianCalendarForDate = datatypeFactory.newXMLGregorianCalendar();
		xmlGregorianCalendarForDate.setYear(instance.get(Calendar.YEAR));
		xmlGregorianCalendarForDate.setMonth(instance.get(Calendar.MONTH) + 1);
		xmlGregorianCalendarForDate.setDay(instance.get(Calendar.DATE));
		xmlGregorianCalendarForDate.setTime(instance.get(Calendar.HOUR_OF_DAY), instance.get(Calendar.MINUTE), instance.get(Calendar.SECOND));
		return xmlGregorianCalendarForDate;
	}
	
	public static Calendar toCalendarDateOnly(XMLGregorianCalendar gregorianCalender) {
		if (gregorianCalender == null) {
			return null;
		}
		//Calendar calendar = Calendar.getInstance();
		
		/*calendar.set(Calendar.YEAR, gregorianCalender.getYear());
		calendar.set(Calendar.MONTH, gregorianCalender.getMonth() - 1);
		calendar.set(Calendar.DATE, gregorianCalender.getDay());*/
		return DateUtils.toCalendar(gregorianCalender.toGregorianCalendar().getTime());
	}

	public static String getTimeElapsed(Date startDate, Date endDate) {

		// milliseconds
		long different = endDate.getTime() - startDate.getTime();
		long secondsInMilli = 1000;
		long minutesInMilli = secondsInMilli * 60;
		long hoursInMilli = minutesInMilli * 60;
		long daysInMilli = hoursInMilli * 24;

		long elapsedDays = different / daysInMilli;
		different = different % daysInMilli;

		long elapsedHours = different / hoursInMilli;
		different = different % hoursInMilli;

		long elapsedMinutes = different / minutesInMilli;
		different = different % minutesInMilli;

		long elapsedSeconds = different / secondsInMilli;

		String timeElapsed = String.format("%dd, %dh, %dm ,%ds", elapsedDays, elapsedHours, elapsedMinutes, elapsedSeconds);

		return timeElapsed;

	}

	public static String getTimeElapsedInDays(Date startDate, Date endDate) {

		// milliseconds
		long different = endDate.getTime() - startDate.getTime();
		long secondsInMilli = 1000;
		long minutesInMilli = secondsInMilli * 60;
		long hoursInMilli = minutesInMilli * 60;
		long daysInMilli = hoursInMilli * 24;

		long elapsedDays = different / daysInMilli;
		different = different % daysInMilli;

		String timeElapsed = String.format("%dd", elapsedDays);

		return timeElapsed;

	}

	public static int getTotalDays(List<String> dates) {

		int totalDays = 0;
		int totalHours = 0;
		int totalMinutes = 0;
		int totalSeconds = 0;

		for (String date : dates) {
			String[] currDate = date.split(",");

			int days = extractNumber(currDate[0]);
			int hours = extractNumber(currDate[1]);
			int minutes = extractNumber(currDate[2]);
			int seconds = extractNumber(currDate[3]);

			totalSeconds = totalSeconds + seconds;
			totalMinutes = totalMinutes + minutes;
			totalHours = totalHours + hours;
			totalDays = totalDays + days;

			if (totalSeconds >= 60) {
				totalMinutes = totalMinutes + 1;
				totalSeconds = totalSeconds - 60;
			}

			if (totalMinutes >= 60) {
				totalHours = totalHours + 1;
				totalMinutes = totalMinutes - 60;
			}

			if (totalHours >= 24) {
				totalDays = totalDays + 1;
				totalHours = totalHours - 24;
			}
		}

		return totalDays;
	}

	private static void init() {
		try {
			datatypeFactory = DatatypeFactory.newInstance();
		} catch (DatatypeConfigurationException e) {
			throw new FatalException(e);
		}
	}

	static {
		init();
	}

	public static DatatypeFactory getDatatypeFactory() {
		return datatypeFactory;
	}

	public static XMLGregorianCalendar toXMLGregorianCalendarCurrentDateOnly(Date date) {
		if (date == null) {
			return null;
		}
		GregorianCalendar instance = (GregorianCalendar) GregorianCalendar.getInstance();
		instance.setTime(date);
		XMLGregorianCalendar xmlGregorianCalendarForDate = datatypeFactory.newXMLGregorianCalendar();
		xmlGregorianCalendarForDate.setYear(instance.get(Calendar.YEAR));
		xmlGregorianCalendarForDate.setMonth(instance.get(Calendar.MONTH) + 1);
		xmlGregorianCalendarForDate.setDay(instance.get(Calendar.DATE));
		return xmlGregorianCalendarForDate;
	}

	public static XMLGregorianCalendar toXMLGregorianCalendarCurrentTimeOnly(Date date) {
		if (date == null) {
			return null;
		}
		GregorianCalendar instance = (GregorianCalendar) GregorianCalendar.getInstance();
		instance.setTime(date);
		XMLGregorianCalendar xmlGregorianCalendarForDate = datatypeFactory.newXMLGregorianCalendar();
		xmlGregorianCalendarForDate.setHour(instance.get(Calendar.HOUR));
		xmlGregorianCalendarForDate.setMinute(instance.get(Calendar.MINUTE));
		xmlGregorianCalendarForDate.setSecond(instance.get(Calendar.SECOND));
		return xmlGregorianCalendarForDate;
	}

	public static XMLGregorianCalendar currentDate() {
		// get current date time with Date()
		Date date = new Date();
		return toXMLGregorianCalendarCurrentDateOnly(date);

	}

	public static XMLGregorianCalendar currentTime() {
		// get current date time with Calendar()
		Calendar cal = Calendar.getInstance();
		return toXMLGregorianCalendarCurrentTimeOnly(cal.getTime());
	}

	public static String getCurrentDateInDateTime() {
		return new SimpleDateFormat(DEFAULT_DATE_FORMAT_4).format(new Date());
	}

	public static XMLGregorianCalendar toXMLGregorianCalendarTimeOnly(Date date) {
		if (date == null) {
			return null;
		}
		GregorianCalendar instance = (GregorianCalendar) GregorianCalendar.getInstance();
		instance.setTime(date);
		XMLGregorianCalendar xmlGregorianCalendarForDate = datatypeFactory.newXMLGregorianCalendar();
		xmlGregorianCalendarForDate.setHour(instance.get(Calendar.HOUR_OF_DAY));
		xmlGregorianCalendarForDate.setMinute(instance.get(Calendar.MINUTE));
		xmlGregorianCalendarForDate.setSecond(instance.get(Calendar.SECOND));
		return xmlGregorianCalendarForDate;
	}
	
	public static XMLGregorianCalendar getDateOnly(XMLGregorianCalendar date) {
		if (date == null) {
			return null;
		}

		XMLGregorianCalendar xmlGregorianCalendarForDate = datatypeFactory.newXMLGregorianCalendar();
		xmlGregorianCalendarForDate.setDay(date.getDay());
		xmlGregorianCalendarForDate.setMonth(date.getMonth());
		xmlGregorianCalendarForDate.setYear(date.getYear());
		return xmlGregorianCalendarForDate;
	}
	
	public static XMLGregorianCalendar getTimeOnly(XMLGregorianCalendar date) {
		if (date == null) {
			return null;
		}

		XMLGregorianCalendar xmlGregorianCalendarForDate = datatypeFactory.newXMLGregorianCalendar();
		xmlGregorianCalendarForDate.setHour(date.getHour());
		xmlGregorianCalendarForDate.setMinute(date.getMinute());
		xmlGregorianCalendarForDate.setSecond(date.getSecond());
		xmlGregorianCalendarForDate.setMillisecond(date.getMillisecond());
		return xmlGregorianCalendarForDate;
	}

	public static XMLGregorianCalendar convertTime(String timeString) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");
		Date date;
		try {
			date = simpleDateFormat.parse(timeString);
			return DateUtil.toXMLGregorianCalendarTimeOnly(date);
		} catch (ParseException e) {

		}

		return null;
	}
	
	public static XMLGregorianCalendar convertDate(String dateString) {
		return convertDate(dateString,"yyyy-MM-dd");
	}

	public static XMLGregorianCalendar convertDate(String dateString,String dateFormat) {

		DateFormat df = new SimpleDateFormat(dateFormat);
		Date date;
		try {
			date = df.parse(dateString);
			return DateUtil.toXMLGregorianCalendarDateOnly(date);
		} catch (ParseException e) {
		}

		return null;
	}
	
	public static XMLGregorianCalendar convertDateTime(String dateString,String dateFormat) {

		DateFormat df = new SimpleDateFormat(dateFormat);
		Date date;
		try {
			date = df.parse(dateString);
			return DateUtil.toXMLGregorianCalendarDateTime(date);
		} catch (ParseException e) {
		}

		return null;
	}

	public static String getCurrentDateInMMDDYYYY() {
		return new SimpleDateFormat(DEFAULT_DATE_FORMAT_5).format(new Date());
	}
	
	public static Date parseDateTimeWithoutMilliseconds(String date) {	 
        try {
            return new SimpleDateFormat(DATE_FORMAT_WITHOUT_MILLISECONDS).parse(date);	   
        } catch (ParseException e) {
            throw new ParsingException(e);
        }
    }
	
	 public static Date parseDateTimeWithMilliseconds(String date) {	 
	        try {
	            return new SimpleDateFormat(DATE_FORMAT_WITH_MILLISECONDS).parse(date);	   
	        } catch (ParseException e) {
	            throw new ParsingException(e);
	        }
	    }
	 
	 public static Date parseDateTimeForMobiusFormat(String date) {	 
	        try {
	        	return new SimpleDateFormat(DATE_FORMAT_FOR_MOBIUSEMAIL).parse(date);
	           
	        } catch (ParseException e) {
	            throw new ParsingException(e);
	        } 
	    }
	
	public static XMLGregorianCalendar getCurrentESTDate() {
		GregorianCalendar instance = (GregorianCalendar) GregorianCalendar.getInstance();
		instance.setTime(new Date());
		instance.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		XMLGregorianCalendar xmlGregorianCalendarForDate = datatypeFactory.newXMLGregorianCalendar();
		xmlGregorianCalendarForDate.setYear(instance.get(Calendar.YEAR));
		xmlGregorianCalendarForDate.setMonth(instance.get(Calendar.MONTH) + 1);
		xmlGregorianCalendarForDate.setDay(instance.get(Calendar.DATE));
		return xmlGregorianCalendarForDate;
	}

	public static XMLGregorianCalendar getCurrentESTTime() {
		GregorianCalendar instance = (GregorianCalendar) GregorianCalendar.getInstance();
		instance.setTime(new Date());
		instance.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		XMLGregorianCalendar xmlGregorianCalendarForDate = datatypeFactory.newXMLGregorianCalendar();
		xmlGregorianCalendarForDate.setHour(instance.get(Calendar.HOUR_OF_DAY));
		xmlGregorianCalendarForDate.setMinute(instance.get(Calendar.MINUTE));
		xmlGregorianCalendarForDate.setSecond(instance.get(Calendar.SECOND));
		return xmlGregorianCalendarForDate;
	}
	
	public static XMLGregorianCalendar getCurrentESTTimeIncludingMilliSec() {
		GregorianCalendar instance = (GregorianCalendar) GregorianCalendar.getInstance();
		instance.setTime(new Date());
		instance.setTimeZone(TimeZone.getTimeZone("America/New_York"));
		XMLGregorianCalendar xmlGregorianCalendarForDate = datatypeFactory.newXMLGregorianCalendar();
		xmlGregorianCalendarForDate.setHour(instance.get(Calendar.HOUR_OF_DAY));
		xmlGregorianCalendarForDate.setMinute(instance.get(Calendar.MINUTE));
		xmlGregorianCalendarForDate.setSecond(instance.get(Calendar.SECOND));
		xmlGregorianCalendarForDate.setMillisecond(instance.get(Calendar.MILLISECOND));
		return xmlGregorianCalendarForDate;
	}
		
	public static Date fromXMLGregorianDateToDate(String xmlGregDate) throws DatatypeConfigurationException{
		XMLGregorianCalendar xmlCalendar = convertDateTime(xmlGregDate,"yyyy-MM-dd'T'HH:mm:ss");
		Date date =null;
				if(xmlCalendar!=null){
					date = xmlCalendar.toGregorianCalendar().getTime();
				}
		return date;
	}
	
	public static String getStringDatefromXMLGregorianDate(XMLGregorianCalendar xmlCalenderDate){

		SimpleDateFormat sdf = new SimpleDateFormat(XML_GREGORIAN_CALENDAR_DATE_FORMAT);
		
		try {
			java.util.Date d = sdf.parse(xmlCalenderDate.toString());
			sdf.applyPattern(YEAR_MONTH_DAY_FORMAT);
			return sdf.format(d);
		} catch (ParseException e) {
			throw new ParsingException(e);
		}
	}
	
	public static String getStringDatefromXMLGregorianDate(XMLGregorianCalendar xmlCalenderDate, String pattern){

		SimpleDateFormat sdf = new SimpleDateFormat(XML_GREGORIAN_CALENDAR_DATE_FORMAT);
		
		try {
			java.util.Date d = sdf.parse(xmlCalenderDate.toString());
			sdf.applyPattern(pattern);
			return sdf.format(d);
		} catch (ParseException e) {
			throw new ParsingException(e);
		}
	}
}
