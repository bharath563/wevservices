package org.tiaa.case_management_rs.exception;

import java.util.Arrays;

import org.tiaa.case_management_rs.constants.CaseManagmentKeys;
import org.tiaa.case_management_rs.utils.Messages;
import org.tiaa.esb.case_management_rs_v2.type.ESBMessage;
import org.tiaa.esb.case_management_rs_v2.type.ESBMessages;
import org.tiaa.j2eeinfra.exception.TiaaRuntimeException;

/**
 * This class extends TiaaRuntimeException and used to create application
 * exception using ESBMessages that will be sent to the service consumer.
 */
@SuppressWarnings("serial")
public class CaseManagementRuntimeException extends TiaaRuntimeException {

	private String errorCode = Messages.getMessage(CaseManagmentKeys.GENERAL_EXCEPTION_CODE);
	private String severityType = Messages.getMessage(CaseManagmentKeys.GENERAL_EXCEPTION_TYPE);
	/**
	 * Holds ESBMessages that will be sent to the service consumer.
	 */
	private ESBMessages esbMessages;

	/**
	 * Holds the messageParams
	 */
	private Object[] messageParams;

	/**
	 * Construct this Exception by using ESBMessages that will sent to the
	 * service consumer.
	 *
	 * @param esbMessages
	 *            ESBMessages
	 */
	public CaseManagementRuntimeException(ESBMessages esbMessages) {
		super();
		this.esbMessages = esbMessages;
	}

	public CaseManagementRuntimeException(String message) {
		super(message);
		this.errorCode = message;
	}

	/**
	 * @param message
	 * @param objArray
	 */
	public CaseManagementRuntimeException(String message, Object[] objArray) {
		super(message);
		this.errorCode = message;
		if (objArray == null) {
			this.messageParams = new Object[0];
		} else {
			this.messageParams = Arrays.copyOf(objArray, objArray.length);
		}
	}

	/**
	 * Construct this Exception specifying exception message and corresponding
	 * ESBMessages that should be sent to the service consumer.
	 *
	 * @param message
	 *            exception message
	 * @param esbMessages
	 *            ESBMessages
	 */
	public CaseManagementRuntimeException(String message, ESBMessages esbMessages) {
		super(message);
		this.esbMessages = esbMessages;
	}

	public CaseManagementRuntimeException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public CaseManagementRuntimeException(String errorCode, String severityType, String arg0) {
		super(arg0);
		this.errorCode = errorCode;
		this.severityType = severityType;
	}

	/**
	 * Constructs this Exception using a nested exception and corresponding
	 * ESBMessages that should be sent to the service consumer.
	 *
	 * @param throwable
	 *            the nested exception.
	 * @param esbMessages
	 *            ESBMessages
	 */
	public CaseManagementRuntimeException(Throwable throwable, ESBMessages esbMessages) {
		super(throwable);
		this.esbMessages = esbMessages;
	}

	/**
	 * Construct this Exception specifying exception message, a nested exception
	 * and corresponding ESBMessages that should be sent to the service
	 * consumer.
	 *
	 * @param message
	 *            The message.
	 * @param throwable
	 *            The nested exception.
	 * @param esbMessages
	 *            ESBMessages
	 */
	public CaseManagementRuntimeException(String message, Throwable throwable, ESBMessages esbMessages) {
		super(message, throwable);
		this.esbMessages = esbMessages;
	}

	/**
	 * Construct this Exception by using ESBMessage that will sent to the
	 * service consumer.
	 *
	 * @param esbMessage
	 *            ESBMessage
	 */
	public CaseManagementRuntimeException(ESBMessage esbMessage) {
		super();
		this.esbMessages = new ESBMessages();
		this.esbMessages.getMessages().add(esbMessage);
	}

	/**
	 * Construct this Exception specifying exception message and corresponding
	 * ESBMessage that should be sent to the service consumer.
	 *
	 * @param message
	 *            exception message
	 * @param esbMessage
	 *            ESBMessage
	 */
	public CaseManagementRuntimeException(String message, ESBMessage esbMessage) {
		super(message);
		this.esbMessages = new ESBMessages();
		this.esbMessages.getMessages().add(esbMessage);
	}

	/**
	 * Constructs this Exception using a nested exception and corresponding
	 * ESBMessage that should be sent to the service consumer.
	 *
	 * @param throwable
	 *            the nested exception.
	 * @param esbMessage
	 *            ESBMessage
	 */
	public CaseManagementRuntimeException(Throwable throwable, ESBMessage esbMessage) {
		super(throwable);
		this.esbMessages = new ESBMessages();
		this.esbMessages.getMessages().add(esbMessage);
	}

	/**
	 * Construct this Exception specifying exception message, a nested exception
	 * and corresponding ESBMessage that should be sent to the service consumer.
	 *
	 * @param message
	 *            The message.
	 * @param throwable
	 *            The nested exception.
	 * @param esbMessage
	 *            ESBMessage
	 */
	public CaseManagementRuntimeException(String message, Throwable throwable, ESBMessage esbMessage) {
		super(message, throwable);
		this.esbMessages = new ESBMessages();
		this.esbMessages.getMessages().add(esbMessage);
	}

	/**
	 * Getter method for esbMessages
	 *
	 * @return the esbMessages
	 */
	public ESBMessages getEsbMessages() {
		return this.esbMessages;
	}

	/**
	 * Setter method for esbMessages
	 *
	 * @param esbMessages
	 *            the esbMessages to set
	 */
	public void setEsbMessages(ESBMessages esbMessages) {
		this.esbMessages = esbMessages;
	}

	/**
	 * Getter method for messageParams
	 *
	 * @return the messageParams
	 */
	public Object[] getMessageParams() {
		return this.messageParams;
	}

	/**
	 * Setter method for messageParams
	 *
	 * @param messageParams
	 *            the messageParams to set
	 */
	public void setMessageParams(Object[] objArray) {
		if (objArray == null) {
			this.messageParams = new Object[0];
		} else {
			this.messageParams = Arrays.copyOf(objArray, objArray.length);
		}
	}

	/**
	 * Setter method for errorCode
	 *
	 * @param errorCode
	 *            the errorCode to set
	 */
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * Getter method for errorCode
	 *
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return this.errorCode;
	}

	/**
	 * Setter method for severityType
	 *
	 * @param severityType
	 *            the severityType to set
	 */
	public void setSeverityType(String severityType) {
		this.severityType = severityType;
	}

	/**
	 * Getter method for severityType
	 *
	 * @return the severityType
	 */
	public String getSeverityType() {
		return this.severityType;
	}
}
