package org.tiaa.case_management_rs.resource;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.common.impl.RequestImpl;
import org.tiaa.case_management_rs.service.CaseManagementRestService;
import org.tiaa.esb.case_management_rs_v2.type.ProcessRequest;

public class RelatedTaskResource {

	private static final Logger LOGGER = LoggerFactory.getLogger(RelatedTaskResource.class);

	@Autowired
	private CaseManagementRestService caseManagmentRestService;

	@POST
	@Produces({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	@Consumes({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	public Response createRelatedTask(@QueryParam("userid") String userId, @QueryParam("caseid") String caseId,@QueryParam(APP_NAME) String appName, @PathParam(PROCESS_ID) String processId, ProcessRequest processRequest) {

		LOGGER.debug("Entering createRelatedTask");
		LOGGER.debug("Request Params");
		LOGGER.debug(USER_ID + SPACE_HYPEN_SAPCE + userId);

		Response response = null;
		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		// Get all the request parameter string values
		request.setAttribute(USER_ID, userId);
		request.setAttribute(CASE_ID, caseId);
		request.setAttribute(APP_NAME, appName);
		request.setAttribute(PROCESS_ID, processId);
		request.setAttribute(PROCESS_REQUEST, processRequest);
		

		response = this.caseManagmentRestService.createRelatedTask(request);

		LOGGER.debug("Exiting createRelatedTask");

		return response;

	}

}
