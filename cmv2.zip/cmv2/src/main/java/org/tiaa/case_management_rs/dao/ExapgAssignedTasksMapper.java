package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.case_management_rs.model.ExpagWorkItem;

public class ExapgAssignedTasksMapper extends AbstractRowMapper<ExpagWorkItem> implements RowMapper<ExpagWorkItem> {

	@Override
	public ExpagWorkItem mapRow(ResultSet rs, int rowNum) throws SQLException {

		ExpagWorkItem expagWorkItem = new ExpagWorkItem();

		expagWorkItem.setTaskId(getStringTrimmed(rs, "TASKID"));
		expagWorkItem.setPacketId(getStringTrimmed(rs, "packetid"));
		expagWorkItem.setSuspendOper(getStringTrimmed(rs, "suspendoper"));
		expagWorkItem.setLockOper(getStringTrimmed(rs, "lockoper"));
		expagWorkItem.setCreateOper(getStringTrimmed(rs, "createoper"));
		expagWorkItem.setLockOperatorFullName(getStringTrimmed(rs, "lockoperatorfullname"));

		// Identifiers
		expagWorkItem.setPlanId(getStringTrimmed(rs, "planid"));
		expagWorkItem.setPlanName(getStringTrimmed(rs, "planname"));
		expagWorkItem.setPin(getStringTrimmed(rs, "pin"));
		expagWorkItem.setNpin(getStringTrimmed(rs, "npin"));
		expagWorkItem.setTradeDate(getStringTrimmed(rs, "tradedate"));
		expagWorkItem.setCheckAmount(getStringTrimmed(rs, "checkamount"));

		// DateFields
		expagWorkItem.setCreateDateTime(getStringTrimmed(rs, "createdatetime"));
		expagWorkItem.setReceivedDateTime(getStringTrimmed(rs, "receiveddatetime"));
		expagWorkItem.setUpdatedDateTime(getStringTrimmed(rs, "updateddatetime"));
		expagWorkItem.setAwakeDateTime(getStringTrimmed(rs, "awakedatetime"));

		// Other fields
		expagWorkItem.setAssignedTo(getStringTrimmed(rs, "assignedto"));
		expagWorkItem.setActionStep(getStringTrimmed(rs, "actionstep"));
		expagWorkItem.setDepartment(getStringTrimmed(rs, "department"));
		expagWorkItem.setTaskType(getStringTrimmed(rs, "tasktype"));

		// Descritpion fields
		expagWorkItem.setDepartmentDescription(getStringTrimmed(rs, "tasktypedescription"));
		expagWorkItem.setTaskTypeDescription(getStringTrimmed(rs, "departmentdescription"));

		return expagWorkItem;
	}
}
