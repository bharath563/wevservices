package org.tiaa.case_management_rs.syncup.service_request;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.delegate.CaseManagementDelegate;

@Configuration
public class BPMAppConfig {

	@Value("${bpm.apps}")
	private String uwApps;
	
	@Autowired
	@Qualifier("activitiAdapter")
	private CaseManagementDelegate activitiDelegate;

	@Autowired
	@Qualifier("expagAdapter")
	private CaseManagementDelegate expagDelegate;
	
	@Autowired
	@Qualifier("icmAdapter")
	private CaseManagementDelegate icmDelegate;
	
	@Value("${filterConvertedTasks}")
	private String filterConvertedExpagTasks;

	@Bean
	public Map<String, CaseManagementDelegate> appConfigs() {

		Map<String, CaseManagementDelegate> appConfigs = new HashMap<String, CaseManagementDelegate>();

		String[] apps = uwApps.split(",");
		for (String appName : apps) {
			if (CaseManagementConstants.APP_ACTIVITI.equalsIgnoreCase(appName)) {
				appConfigs.put(appName, activitiDelegate);
			} else if (CaseManagementConstants.APP_EXPAG.equalsIgnoreCase(appName)) {
				appConfigs.put(appName, expagDelegate);
			} else if (CaseManagementConstants.APP_ICM.equalsIgnoreCase(appName)) {
				appConfigs.put(appName, icmDelegate);
			}

		}

		return appConfigs;
	}
}
