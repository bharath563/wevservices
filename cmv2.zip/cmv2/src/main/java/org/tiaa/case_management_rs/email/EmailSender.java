package org.tiaa.case_management_rs.email;

public interface EmailSender extends EmailService {
	String NEW_LINE = "\r\n";
	String NEW_LINE_HTML = "<br/>";

	void sendHtmlEmail(String subject, String html);

	void sendTextEmail(String subject, String text);

	boolean isEmailEnabled();

	void setEmailEnabled(boolean enableEmail);
}