package org.tiaa.case_management_rs.integration.clients;

import java.io.IOException;

import javax.xml.soap.Name;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPFactory;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.TransformerException;





import org.slf4j.Logger;
import org.slf4j.LoggerFactory;





import org.apache.ws.security.WSConstants;
import org.apache.ws.security.handler.WSHandlerConstants;

import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.soap.saaj.SaajSoapMessage;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.GuidUtility;
import org.tiaa.infra.security.axis.tools.SecretKeyLoader;

@Component(value = "jaxWsCallbackHandler")
public class JaxWsCallbackHandler implements WebServiceMessageCallback {

	private static final Logger LOG = LoggerFactory.getLogger(JaxWsCallbackHandler.class);
			
	@Override
	public void doWithMessage(WebServiceMessage message) throws IOException,
			TransformerException {
		
		try {
			
			SaajSoapMessage saajSoapMessage = (SaajSoapMessage)message;					
			
			//addSoapHeaders
			createSOAPHeaders(saajSoapMessage.getSaajMessage());
			
			//add ESB Related Headers
			Name esbQName = SOAPFactory.newInstance().createName("sinfo", "esb", CaseManagementConstants.ESB_TIAA_NS);
			Name guid = SOAPFactory.newInstance().createName("guid");
			Name userRef = SOAPFactory.newInstance().createName("userRef");
			Name senderMachine = SOAPFactory.newInstance().createName("senderMachine");
			
			SOAPElement sinfo = saajSoapMessage.getSaajMessage().getSOAPHeader().addChildElement(esbQName);
			sinfo.addAttribute(guid, new GuidUtility().toString());
			sinfo.addAttribute(userRef, AppConstants.USER_REF);
			sinfo.addAttribute(senderMachine, CommonUtil.getHostName());
			saajSoapMessage.getSaajMessage().saveChanges();
			
		}catch (Exception ex) {
			LOG.error("Exception in adding ESB info headers" + ex.getMessage());
		}	

	}
	
	
	private void createSOAPHeaders(SOAPMessage message) throws Exception {
		
		if (message != null) {
			SOAPPart part = message.getSOAPPart();
			SOAPElement env = part.getEnvelope();
			SOAPHeader header = message.getSOAPHeader();
			env.addNamespaceDeclaration(WSConstants.WSSE_PREFIX, WSConstants.WSSE_NS);
			env.addNamespaceDeclaration(WSConstants.WSU_PREFIX, WSConstants.WSU_NS);
			
			SOAPElement security = header.addChildElement("Security",
					WSConstants.WSSE_PREFIX);
			
			Name mustUnderstand = SOAPFactory.newInstance().createName("SOAP-ENV:mustUnderstand");
			security.addAttribute(mustUnderstand, "1");
			
			SOAPElement userNameToken = security.addChildElement(
					WSHandlerConstants.USERNAME_TOKEN, WSConstants.WSSE_PREFIX);
			userNameToken.addChildElement(WSConstants.USERNAME_LN, WSConstants.WSSE_PREFIX).setTextContent(AppConstants.APPLICATION_NAME);
			
			SOAPElement password = userNameToken.addChildElement(WSConstants.PASSWORD_LN, WSConstants.WSSE_PREFIX);
			password.setTextContent(SecretKeyLoader.getSecretKey(AppConstants.APPLICATION_NAME));
			
			SOAPElement nonce = userNameToken.addChildElement(WSConstants.NONCE_LN, WSConstants.WSSE_PREFIX);
			nonce.setAttribute("EncodingType", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-soap-message-security-1.0#Base64Binary");
			nonce.setTextContent(new GuidUtility().toString());		
			message.saveChanges();	
			
		} else {
			//TODO log the error here
			LOG.error("SOAPMessage not available, header cannot be added");
		}
	}

}
