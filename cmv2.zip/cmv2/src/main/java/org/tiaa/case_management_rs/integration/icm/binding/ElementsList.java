package org.tiaa.case_management_rs.integration.icm.binding;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlJavaTypeAdapter(AdditionalIdentifiersMapAdapter.class)

public class ElementsList extends ArrayList {

	/**
	 *
	 */
	public List<ElementListType> entry = new ArrayList<ElementListType>();
	private static final long serialVersionUID = 1L;

}