package org.tiaa.case_management_rs.integration.clients;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;

import org.tiaa.esb.externalization_v2.types.ExternalizationResponse;
import org.tiaa.esb.externalization_v2.types.GetObjectsWithFetchSpecification;
import org.tiaa.esb.externalization_v2.types.Holidays;


@Service(value = "externalization-V2")
public class ExternalizationV2JaxWsClient implements JaxWsClient<ExternalizationResponse> {
	
	private static final Logger LOG = LoggerFactory.getLogger(ExternalizationV2JaxWsClient.class);
	
	private WebServiceTemplate webServiceTemplate;
	
	@Value("${externalization-v2}")
	private String defaultURI; 
	
	@PostConstruct
	public void init(){
		try {
			
			Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
			marshaller.setClassesToBeBound(GetObjectsWithFetchSpecification.class, Holidays.class, ExternalizationResponse.class);
			
			webServiceTemplate = new WebServiceTemplate();
			webServiceTemplate.setMarshaller(marshaller);
		    webServiceTemplate.setUnmarshaller(marshaller);
		    
		} catch(Exception ex) {
			LOG.error("Exception in creating WebServiceTemplate" + ex.getMessage());
		}
	}
	
	@Override
	public ExternalizationResponse marshallSendAndReceive(Object requestPayload, WebServiceMessageCallback jaxWsCallback) {
		
		if (requestPayload == null || jaxWsCallback == null) {
			LOG.error("Missing required Objects to call the service");
			return null;
		}
			
		return (ExternalizationResponse) this.webServiceTemplate.marshalSendAndReceive(defaultURI, requestPayload, jaxWsCallback);
		
	}
}
