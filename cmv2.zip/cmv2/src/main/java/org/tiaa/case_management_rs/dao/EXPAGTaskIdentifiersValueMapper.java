package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.case_management_rs.model.TaskIdentifiersValue;

public class EXPAGTaskIdentifiersValueMapper extends AbstractRowMapper<TaskIdentifiersValue> implements RowMapper<TaskIdentifiersValue> {

	@Override
	public TaskIdentifiersValue mapRow(ResultSet rs, int rowNum)
			throws SQLException {
		// TODO Auto-generated method stub
	
		TaskIdentifiersValue tiValue = new TaskIdentifiersValue();
		tiValue.setFieldValue(getStringTrimmed(rs, "fieldvalue"));
		tiValue.setIdDesc(getStringTrimmed(rs, "iddesc"));
		
		
		return tiValue;
	}

}
