package org.tiaa.case_management_rs.poller;

import java.util.Map;

import org.tiaa.case_management_rs.domain.TaskInfo;

public interface TaskStatusProvider {
	Map<String, TaskInfo> getTaskStatusMapSince(PollingContext pollingContext);
}
