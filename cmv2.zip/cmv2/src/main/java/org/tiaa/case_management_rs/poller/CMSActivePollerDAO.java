package org.tiaa.case_management_rs.poller;

import org.tiaa.case_management_rs.domain.CMSActivePoller;

public interface CMSActivePollerDAO {
	boolean updateOwner(String s, String s1);
	boolean insertPoller(CMSActivePoller activepoller);
	CMSActivePoller getActivePoller(String s);
	void updateHeartBeat(String s, String s1);
	CMSActivePoller findById(String component);

	String UPDATE_OWNER_SQL = "Update ActivePoller activePoller set activePoller.owner = :owner, activePoller.lastUpdatedTimestamp = :lastUpdatedTimestamp where activePoller.name = :componentName";
	String UPDATE_HEART_BEAT_SQL = "Update ActivePoller activePoller  set activePoller.lastUpdatedTimestamp = :lastUpdatedTimestamp where activePoller.name = :componentName and activePoller.owner = :instance";
	String SELECT_ACTIVE_POLLER_BY_COMPONENT_NAME_SQL = "Select activePoller from ActivePoller activePoller where activePoller.name = :component";
}
