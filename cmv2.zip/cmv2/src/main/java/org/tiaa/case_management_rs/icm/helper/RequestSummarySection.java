package org.tiaa.case_management_rs.icm.helper;

public enum RequestSummarySection {

	GENERAL("General"),
	OMNI("OMNI"),
	FILEINFO("FileInfo"),
	QC("QC");
	
	private String section;
	
	RequestSummarySection(String section) {
		this.section = section;
	}
	
	public String getSection() {
		return this.section;
	}
}
