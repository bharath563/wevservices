package org.tiaa.case_management_rs.integration.case_manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.common.CMSTaskTypeService;
import org.tiaa.case_management_rs.domain.CMRSEvent;
import org.tiaa.case_management_rs.domain.CMSAudit;
import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.email.EmailSender;
import org.tiaa.case_management_rs.email.EmailUtil;
import org.tiaa.case_management_rs.integration.case_manager.cth.CreateCTHCaseContext;
import org.tiaa.case_management_rs.integration.case_manager.cth.RetryableCTHCaseRecordCreator;
import org.tiaa.case_management_rs.integration.case_manager.cth.RetryableCTHCaseRecordUpdater;
import org.tiaa.case_management_rs.integration.case_manager.cth.UpdateCaseCTHContext;
import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;
import org.tiaa.case_management_rs.integration.cth.CTHCreateRecordFailedException;
import org.tiaa.case_management_rs.integration.cth.CTHRecordNotFoundException;
import org.tiaa.case_management_rs.integration.cth.CTHUpdateRecordFailedException;
import org.tiaa.case_management_rs.utils.CommonUtil;

@Component
public class CaseManagerCaseProcessorImpl implements CaseManagerCaseProcessor {
	private static final Logger LOG = LoggerFactory.getLogger(CaseManagerCaseProcessorImpl.class);
	@Autowired
	protected RetryableCTHCaseRecordUpdater retryableCTHCaseRecordUpdater;
	@Autowired
	protected CaseManagerCMSAuditService cmsAuditService;
	@Autowired
	private RetryableCTHCaseRecordCreator retryableCTHCaseRecordCreator;
	@Autowired
	private CMSTaskTypeService cmsTaskTypeService;
	@Autowired
	private EmailSender emailSender;

	@Override
	public void processCase(CaseDetails caseDetails) {
		CMSAuditHistory cmsAuditHistory = cmsAuditService.createCMSAuditHistory(caseDetails);
		processCase(caseDetails, cmsAuditHistory);
	}

	@Override
	public void processCase(CaseDetails caseDetails, CMSAuditHistory cmsAuditHistory) {
		caseDetails.setRequestType("ServiceRequest");
		caseDetails.setProcessType("InstitutionalImplementationRequest");
		LOG.debug("Processing Task: {} : {} : {}", caseDetails.getCaseId(), caseDetails.getCaseStatus(), caseDetails.getDocuments().size());
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		if (!cmsAudit.hasCthOrchestrationId()) {
			LOG.debug("create record");
			createCTHRecord(caseDetails, cmsAuditHistory);
		} else {
			LOG.debug("update record:" + cmsAudit.getCthOrchestrationId());
			updateCTHRecord(caseDetails, cmsAuditHistory);
		}
	}

	private CreateCTHCaseContext createCTHContext(CaseDetails caseDetails) {
		LOG.debug("caseDetails:" + caseDetails);
		CreateCTHCaseContext context = new CreateCTHCaseContext();
		context.setCaseDetails(caseDetails);
		context.setCmsTaskType(cmsTaskTypeService.getCMSTaskType(caseDetails.getCaseType()));
		return context;
	}

	private void createCTHRecord(CaseDetails caseDetails, CMSAuditHistory cmsAuditHistory) {
		cmsAuditHistory.setEvent(CMRSEvent.CREATE_CTH_RECORD);
		String caseId = caseDetails.getCaseId();
		LOG.debug("attempting to create cth record for case id:{}", caseId);
		try {
			CreateCTHCaseContext context = createCTHContext(caseDetails);
			retryableCTHCaseRecordCreator.createCTHRecord(context);
			CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
			cmsAudit.setCthRequestId(context.getCthRequestId());
			cmsAudit.setCthOrchestrationId(context.getCthOrchestrationId());
			cmsAuditService.markAsSuccessful(cmsAuditHistory);
			LOG.debug("successfully created cth record for case id:{}", caseId);
		} catch (CTHCreateRecordFailedException e) {
			LOG.debug("failed to create cth record for case id:{}", caseId);
			LOG.warn(e.getMessage(), e);
			cmsAuditService.markAsFailed(cmsAuditHistory, e);
			if (cmsAuditHistory.getRetryAttempt() < 1) {
				emailSender.sendEmailToProdSupport("Error while creating CTH Record for case Id:" + caseId, EmailUtil.createEmail(cmsAuditHistory, e));
			}
		}
	}

	private void updateCTHRecord(CaseDetails caseDetails, CMSAuditHistory cmsAuditHistory) {
		cmsAuditHistory.setEvent(CMRSEvent.UPDATE_CTH_RECORD);
		String caseId = caseDetails.getCaseId();
		LOG.debug("attempting to update cth record for case id:{}", caseId);
		try {
			tryUpdateCTHRecord(caseDetails, cmsAuditHistory);
			LOG.debug("successfully updated cth record for case id:{}", caseId);
		} catch (CTHRecordNotFoundException e) {
			LOG.warn(e.getMessage());
			createCTHRecord(caseDetails, cmsAuditHistory);
		} catch (CTHUpdateRecordFailedException e) {
			LOG.debug("failed to update cth record for case id:{}", caseId);
			LOG.warn(e.getMessage(), e);
			cmsAuditService.markAsFailed(cmsAuditHistory, e);
			emailSender.sendEmailToProdSupport("Error while updating CTH Record for case Id:" + caseId, EmailUtil.createEmail(cmsAuditHistory, e));
		}
	}

	protected void tryUpdateCTHRecord(CaseDetails caseDetails, CMSAuditHistory cmsAuditHistory) {
		UpdateCaseCTHContext updateCTHContext = new UpdateCaseCTHContext();
		updateCTHContext.setCaseDetails(caseDetails);
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		//
		String cthOrchestrationId = cmsAudit.getCthOrchestrationId();
		caseDetails.setCthOrchestrationId(cthOrchestrationId);
		//
		String cthRequestId = cmsAudit.getCthRequestId();
		caseDetails.setCthRequestId(cthRequestId);
		//
		updateCTHContext.setCthOrchestrationId(cthOrchestrationId);
		updateCTHContext.setCthRequestId(cthRequestId);
		//
		Object updateCTH = retryableCTHCaseRecordUpdater.updateCTHRecord(updateCTHContext);
		if (updateCTH != null) {
			if (CommonUtil.isNullOrEmpty(cthOrchestrationId)) {
				cmsAudit.setCthOrchestrationId(updateCTHContext.getCthOrchestrationId());
			}
			if (CommonUtil.isNullOrEmpty(cthRequestId)) {
				cmsAudit.setCthRequestId(updateCTHContext.getCthRequestId());
			}
			cmsAudit.setCaseId(caseDetails.getCaseId());
			cmsAuditService.markAsSuccessful(cmsAuditHistory);
		} else {
			cmsAuditService.markAsSameStatus(cmsAuditHistory);
		}
	}
}
