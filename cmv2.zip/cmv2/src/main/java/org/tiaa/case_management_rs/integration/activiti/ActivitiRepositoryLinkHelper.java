package org.tiaa.case_management_rs.integration.activiti;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ActivitiRepositoryLinkHelper {

	@Value("${activitiProcessRestURL}")
	private String activitiProcessRestURL;

	@Value("${activitiDocumentsURL}")
	private String activitiDocumentsURL;

	@Value("${activitiGetDocumentsURL}")
	private String activitiGetDocumentsURL;

	@Value("${activitiGetDocumentURL}")
	private String activitiGetDocumentURL;

	@Value("${activitiAddCommentURL}")
	private String activitiAddCommentURL;

	@Value("${activitiGetCommentsURL}")
	private String activitiGetCommentsURL;

	@Value("${activitiGetTaskCommentsURL}")
	private String activitiGetTaskCommentsURL;

	@Value("${activitiGetTasksURL}")
	private String activitiGetTasksURL;

	@Value("${activitiGetTaskByIdURL}")
	private String activitiGetTaskByIdURL;

	@Value("${activitiGetTasksClaimableURL}")
	private String activitiGetTasksClaimableURL;
	
	@Value("${activitiSearchURL}")
	private String activitiSearchURL;
	
	@Value("${activitiUpdateProcessURL}")
	private String activitiUpdateProcessURL;

	@Value("${activitiConfigItemsURL}")
	private String activitiConfigItemsURL;
	
	@Value("${activitiConfigItemsURLforDept}")
	private String activitiConfigItemsURLforDept;
	
	@Value("${activitiCreateProcessURL}")
	private String activitiCreateProcessURL;
	
	@Value("${activitiGetMetricsURL}")
	private String activitiGetMetricsURL;
	
	@Value("${activitiGetProcessInfocaddyURL}")
	private String activitiGetProcessInfocaddyURL;
	
	@Value("${activitiUpdateTaskURL}")
	private String activitiUpdateTaskURL;
	
	@Value("${activitiGetCaseworkersURL}")
	private String activitiGetCaseworkersURL;
	
	@Value("${activitiAssginTaskURL}")
	private String activitiGetAssginTaskURL;
	
	@Value("${activitiTaskSearchURL}")
	private String activitiTaskSearchURL;
	
	@Value("${activitiCreateRelatedTaskURL}")
	private String activitiCreateRelatedTask;
	
	
	@Value("${activitiGetTaskAdditionalDetailsURL}")
	private String activitiTaskAdditionalDetails;
	
	public String getActivitiProcessRestURL() {
		return activitiProcessRestURL;
	}

	public String getActivitiDocumentsURL() {
		return this.activitiDocumentsURL;
	}

	public String getActivitiGetDocumentsURL() {
		return this.activitiGetDocumentsURL;
	}

	public String getActivitiGetDocumentURL() {
		return activitiGetDocumentURL;
	}

	public String getActivitiAddCommentURL() {
		return activitiAddCommentURL;
	}

	public String getActivitiGetCommentsURL() {
		return this.activitiGetCommentsURL;
	}

	public String getActivitiGetTaskCommentsURL() {
		return activitiGetTaskCommentsURL;
	}

	public String getActivitiGetTasksURL() {
		return activitiGetTasksURL;
	}

	public String getActivitiGetTaskByIdURL() {
		return activitiGetTaskByIdURL;
	}

	public String getActivitiGetTasksClaimableURL() {
		return activitiGetTasksClaimableURL;
	}

	public String getActivitiSearchURL() {
		return activitiSearchURL;
	}
	
	public String getActivitiUpdateProcessURL() {
		return activitiUpdateProcessURL;
	}
	public String getActivitiConfigItemsURL() {
		return activitiConfigItemsURL;
	}
	public String getActivitiConfigItemsURLforDept() {
		return activitiConfigItemsURLforDept;
	}

	public String getActivitiCreateProcessURL() {
		return activitiCreateProcessURL;
	}
	
	public String getActivitiGeMetricsURL() {
		return activitiGetMetricsURL;
	}
	
	public String getActivitiGetProcessInfocaddyURL(){
		return activitiGetProcessInfocaddyURL;
	}
	
	public String getActivitiUpdateTaskURL(){
		return activitiUpdateTaskURL;
	}
	
	public String getActivitiCaseworkersURL(){
		return activitiGetCaseworkersURL;
	}
	
	public String getActivitiAssginTaskURL(){
		return activitiGetAssginTaskURL;
	}
	
	public String getActivitiTaskSearchURL() {
		return activitiTaskSearchURL;
	}

	public String getActivitiCreateRelatedTask() {
		return activitiCreateRelatedTask;
	}

	public void setActivitiCreateRelatedTask(String activitiCreateRelatedTask) {
		this.activitiCreateRelatedTask = activitiCreateRelatedTask;
	}

	public String getActivitiTaskAdditionalDetails() {
		return activitiTaskAdditionalDetails;
	}

	public void setActivitiTaskAdditionalDetails(String activitiTaskAdditionalDetails) {
		this.activitiTaskAdditionalDetails = activitiTaskAdditionalDetails;
	}


	
	
	
}
