package org.tiaa.case_management_rs.integration.exp_ag.file_transfer;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.io.IOException;
import java.io.InputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.io.IOUtils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import org.tiaa.case_management_rs.exception.CaseManagementRuntimeException;
import org.tiaa.case_management_rs.utils.CryptUtility;
import org.tiaa.case_management_rs.utils.ResponseStatus;
import org.tiaa.esb.case_management_rs_v2.type.ESBMessage;
import org.tiaa.esb.case_management_rs_v2.type.ESBMessages;

import com.github.sardine.Sardine;
import com.github.sardine.SardineFactory;
import com.github.sardine.impl.SardineException;

@Service
public class WebDAVClient {
	
	@Value("${expag.webdav.url.docs}")
	private String webDAVDocsUrl;
	
	@Value("${expag.webdav.url.predocs}")
	private String webDAVPredocsUrl;

	@Value("AD\\"+"${expag.webdav.username}")
	private String webDAVUserName;
	
	@Value("${expag.webdav.password}")
	private String webDAVPassword;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(WebDAVClient.class);
	
	public void moveFile(String fromDirectory, String toDirectory, String fileName) throws IOException {
		
		String from =fromDirectory + BACKWARD_SLASH+ fileName;
		String to = toDirectory + BACKWARD_SLASH + fileName;
		Sardine sardine = SardineFactory.begin(webDAVUserName, CryptUtility.decrypt(webDAVPassword));
		try {
			sardine.move(from, to);
		} catch (SardineException e) {
				createDirectory(sardine,toDirectory);
				sardine.move(from, to);
			}
		}

	private void createDirectory(Sardine sardine, String toDirectory) throws IOException {
		try {
			sardine.getResources(toDirectory);
		} catch (SardineException e) {
			if ((e.getStatusCode() == 404)) {
				sardine.createDirectory(toDirectory);
			}else{
				LOGGER.error("Exception while creating directory "+ toDirectory +" : "+ e.getMessage());
			}
		}
	}
	
	public void updateFile(String folderPath, String fileName, byte[] documentContent) throws Exception{
		
		String fileLocation = folderPath + BACKWARD_SLASH + fileName;
		Sardine sardine = SardineFactory.begin(webDAVUserName, CryptUtility.decrypt(webDAVPassword));
		if(sardine.exists(fileLocation)){
			sardine.delete(fileLocation);
			sardine.put(fileLocation, documentContent);
		}else{
			ESBMessages esbMessages = new ESBMessages();
			ESBMessage esbMessage = new ESBMessage();
			String errorMessage = "Update Failed - Correspondence File:"+ fileName;
			esbMessage.setText(errorMessage);
			esbMessage.setType(ResponseStatus.ERROR.toString());
			esbMessages.getMessages().add(esbMessage);
			CaseManagementRuntimeException cmre = new CaseManagementRuntimeException(errorMessage);
			
			cmre.setEsbMessages(esbMessages);
			throw cmre;
		}
		
	}
	
	public byte[] getDocContent(String folder, String fileName) {
		
		Sardine sardine = SardineFactory.begin(webDAVUserName, CryptUtility.decrypt(webDAVPassword));
		String fileLocationDoc = webDAVDocsUrl + BACKWARD_SLASH + folder + BACKWARD_SLASH + fileName;

		InputStream is = null;
		byte[] content = null;

		try {
			try {
				is = sardine.get(fileLocationDoc);
			} catch (SardineException se) {
				if (se.getStatusCode() == 404) {
					fileLocationDoc = webDAVPredocsUrl + BACKWARD_SLASH + folder + BACKWARD_SLASH + fileName;
					is = sardine.get(fileLocationDoc);
				}
			}

			if (is != null) {
				content = IOUtils.toByteArray(is);
			}

		} catch (IOException e) {
			LOGGER.error("Error to read doc content of document : " + fileName + " Error: "+e.getLocalizedMessage());
			ESBMessages esbMessages = new ESBMessages();
			ESBMessage esbMessage = new ESBMessage();
			String errorMessage = "Error to read Document Content "+ fileName;
			esbMessage.setText(errorMessage);
			esbMessage.setType(ResponseStatus.ERROR.toString());
			esbMessages.getMessages().add(esbMessage);
			CaseManagementRuntimeException cmre = new CaseManagementRuntimeException(errorMessage);
			
			cmre.setEsbMessages(esbMessages);
			throw cmre;
		} finally {
			IOUtils.closeQuietly(is);
		}

		return content;
	}
}