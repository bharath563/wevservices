package org.tiaa.case_management_rs.syncup.customer_webform;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.Marshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.common.ExceptionHandler;
import org.tiaa.case_management_rs.integration.cth.CTHRecordRetriever;
import org.tiaa.case_management_rs.integration.cth.CTHRecordUpdater;
import org.tiaa.case_management_rs.integration.cth.CTHWsConfig;
import org.tiaa.case_management_rs.integration.cth.RetrieveRequestsBuilder;
import org.tiaa.case_management_rs.integration.cth.RetryableCTHRecordUpdater;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTasksDAO;
import org.tiaa.case_management_rs.integration.plan_sponsor.PlanSponosrRSConfig;

@Configuration
public class CustomerWebFormConfig {
	@Autowired
	private CTHWsConfig cthWsConfig;
	@Autowired
	private PlanSponosrRSConfig planSponosrRSConfig;

	@Bean
	public Jaxb2Marshaller customerWebFormJaxb2Marshaller() {
		Map<String, Object> marshallerProperties = new HashMap<String, Object>();
		marshallerProperties.put(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		//
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		jaxb2Marshaller.setClassesToBeBound(org.tiaa.esb.customer_webform.types.ObjectFactory.class);
		ExceptionHandler.initalize(jaxb2Marshaller);
		return jaxb2Marshaller;
	}

	@Bean
	public CTHRecordUpdater customerWebFormCthRecordUpdater() {
		CTHRecordUpdater cthUpdater = new CTHRecordUpdater();
		cthUpdater.setCthWebService(cthWsConfig.cthWebService());
		cthUpdater.setRetrieveRequestsResponseProcessor(customerWebFormCTHClobProcessor());
		cthUpdater.setCthRecordRetriever(customerWebFormCthRecordRetriever());
		return cthUpdater;
	}

	@Bean
	public RetryableCTHRecordUpdater customerWebFormRetryableCTHRecordUpdater() {
		return new RetryableCTHRecordUpdater(cthWsConfig.cthWSRetryTemplate(), customerWebFormCthRecordUpdater());
	}

	@Bean
	public CTHRecordRetriever customerWebFormCthRecordRetriever() {
		CTHRecordRetriever cthRecordRetriever = new CTHRecordRetriever(new RetrieveRequestsBuilder("CustomerWebform", "DigitalFormFactory"));
		cthRecordRetriever.setCthWebService(cthWsConfig.cthWebService());
		return cthRecordRetriever;
	}

	@Bean
	public CustomerWebFormProcessor customerWebFormCTHClobProcessor() {
		CustomerWebFormProcessor customerWebFormProcessor = new CustomerWebFormProcessor();
		customerWebFormProcessor.setCustomerWebFormJaxb2Marshaller(customerWebFormJaxbMarshaller());
		customerWebFormProcessor.setServicerequestWorkflowJaxb2Marshaller(cthWsConfig.serviceRequestWorkflowJaxb2Marshaller());
		customerWebFormProcessor.setPayloadInfoBuilder(customerWebPayloadInfoBuilder());
		customerWebFormProcessor.setContactResponseProcessor(planSponosrRSConfig.contactResponseProcessor());
		return customerWebFormProcessor;
	}

	@Bean
	public CustomerWebPayloadInfoBuilder customerWebPayloadInfoBuilder() {
		CustomerWebPayloadInfoBuilder payloadInfoBuilder = new CustomerWebPayloadInfoBuilder("customer-webform-1-0-clob.xsd", "3.0");
		payloadInfoBuilder.setCthJaxb2WorkflowMarshaller(cthWsConfig.cthJaxb2Marshaller());
		payloadInfoBuilder.setServicerequestWorkflowJaxb2Marshaller(cthWsConfig.serviceRequestWorkflowJaxb2Marshaller());
		payloadInfoBuilder.setCustomerWebFormJaxb2Marshaller(customerWebFormJaxb2Marshaller());
		return payloadInfoBuilder;
	}

	@Bean
	public CustomerWebFormJaxbMarshaller customerWebFormJaxbMarshaller() {
		CustomerWebFormJaxbMarshaller customerWebFormJaxb2Marshaller = new CustomerWebFormJaxbMarshaller();
		customerWebFormJaxb2Marshaller.setCustomerWebFormJaxb2Marshaller(customerWebFormJaxb2Marshaller());
		customerWebFormJaxb2Marshaller.setServiceRequestWorkflowJaxbMarshaller(cthWsConfig.serviceRequestWorkflowJaxbMarshaller());
		return customerWebFormJaxb2Marshaller;
	}

	@Bean
	public EXPAGTasksDAO customerWebFormEXPAGTasksDAO() {
		EXPAGTasksDAO expagTasksDAO = new EXPAGTasksDAO();
		expagTasksDAO.setQueryProvider(customerWebFormEXPAGTaskQueryProvider());
		return expagTasksDAO;
	}

	@Bean
	public CustomerWebFormEXPAGTasksQueryProvider customerWebFormEXPAGTaskQueryProvider() {
		return new CustomerWebFormEXPAGTasksQueryProvider();
	}

}
