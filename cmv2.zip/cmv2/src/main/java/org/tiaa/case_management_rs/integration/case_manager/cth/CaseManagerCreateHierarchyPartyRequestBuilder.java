package org.tiaa.case_management_rs.integration.case_manager.cth;

import java.util.Date;
import java.util.List;

import javax.validation.ValidationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.partyrequest.types.AdditionalRequestIdentifier;
import org.tiaa.esb.partyrequest.types.AdditionalRequestIdentifiers;
import org.tiaa.esb.partyrequest.types.CreateHierarchyPartyRequest;
import org.tiaa.esb.partyrequest.types.CreateHierarchyPartyRequests;
import org.tiaa.esb.partyrequest.types.CreateRequests;
import org.tiaa.esb.partyrequest.types.DisplayField;
import org.tiaa.esb.partyrequest.types.DisplayFields;
import org.tiaa.esb.partyrequest.types.PartyIdentifier;
import org.tiaa.esb.partyrequest.types.PartyIdentifiers;
import org.tiaa.esb.partyrequest.types.PartyReqControlInfo;
import org.tiaa.esb.partyrequest.types.PayloadInfo;
import org.tiaa.esb.partyrequest.types.YesNo;

public class CaseManagerCreateHierarchyPartyRequestBuilder {
	private static final Logger LOG = LoggerFactory.getLogger(CaseManagerCreateHierarchyPartyRequestBuilder.class);
	private static final String CLIENT_ID_REQUIRED = "ClientId is missing in the identifiers. Cannot create CTH Record";
	private PayloadInfoBuilder cthRequestBuilder;

	public CreateRequests build(CreateCTHCaseContext context) {
		PayloadInfo payloadInfo = cthRequestBuilder.build(context);
		//
		CreateHierarchyPartyRequest createHierarchyPartyRequest = new CreateHierarchyPartyRequest();
		createHierarchyPartyRequest.setAdditionalRequestIdentifiers(createAdditionalIdentifiers(context));
		createHierarchyPartyRequest.setDisplayFields(createDisplayFields(context));
		createHierarchyPartyRequest.setPartyIdentifiers(createPartyIdentifiers(context));
		createHierarchyPartyRequest.setPartyReqControlInfo(createPartyReqControlInfo(context));
		createHierarchyPartyRequest.setPayloadInfo(payloadInfo);
		//
		CreateHierarchyPartyRequests createHierarchyPartyRequests = new CreateHierarchyPartyRequests();
		createHierarchyPartyRequests.getCreateHierarchyPartyRequests().add(createHierarchyPartyRequest);
		//
		CreateRequests createRequests = new CreateRequests();
		createRequests.setCreateHierarchyPartyRequests(createHierarchyPartyRequests);
		return createRequests;
	}

	public PartyReqControlInfo createPartyReqControlInfo(CreateCTHCaseContext context) {
		CaseDetails caseDetails = context.getCaseDetails();
		//
		PartyReqControlInfo partyReqControlInfo = new PartyReqControlInfo();
		partyReqControlInfo.setEffectiveDate(caseDetails.getRecievedDateTimeAsXMLGregorianCalendarAsDate());
		partyReqControlInfo.setSubmitDateTime(caseDetails.getRecievedDateTimeAsXMLGregorianCalendar());
		partyReqControlInfo.setChannel(caseDetails.getChannel());
		partyReqControlInfo.setStatus(caseDetails.getCthStatus());
		partyReqControlInfo.setSystemIdentifier(caseDetails.getSystemIdentifier());
		partyReqControlInfo.setUpdatedBy(caseDetails.getUpdatedBy());
		partyReqControlInfo.setProcessType(caseDetails.getProcessType());
		partyReqControlInfo.setRequestType(caseDetails.getRequestType());
		partyReqControlInfo.setTrackingRequestIndicator(YesNo.N);
		return partyReqControlInfo;
	}

	public PartyIdentifiers createPartyIdentifiers(CreateCTHCaseContext context) {
		CaseDetails caseDetails = context.getCaseDetails();
		//
		PartyIdentifiers partyIdentifiers = new PartyIdentifiers();
		List<PartyIdentifier> partyIdentifierList = partyIdentifiers.getPartyIdentifiers();
		LOG.debug("ClientId: {}", caseDetails.getClientId());
		addPartyIdentifier(partyIdentifierList, "ClientId", caseDetails.getClientId());
		if (partyIdentifierList.isEmpty()) {
			throw new ValidationException(CLIENT_ID_REQUIRED);
		}
		return partyIdentifiers;
	}

	private void addPartyIdentifier(List<PartyIdentifier> partyIdentifierList, String key, String value) {
		if (value != null && !value.isEmpty()) {
			partyIdentifierList.add(createPartyIdentifier(key, value));
		}
	}

	public PartyIdentifier createPartyIdentifier(String name, String value) {
		PartyIdentifier partyIdentifier = new PartyIdentifier();
		partyIdentifier.setKey(name);
		partyIdentifier.setValue(value);
		return partyIdentifier;
	}

	public AdditionalRequestIdentifiers createAdditionalIdentifiers(CreateCTHCaseContext context) {
		CaseDetails caseDetails = context.getCaseDetails();
		String caseType = caseDetails.getCaseType();
		//
		AdditionalRequestIdentifiers updateAdditionalRequestIdentifiers = new AdditionalRequestIdentifiers();
		List<AdditionalRequestIdentifier> additionalRequestIdentifierList = updateAdditionalRequestIdentifiers.getAdditionalRequestIdentifiers();
		//
		if (LOG.isDebugEnabled()) {
			LOG.debug("ClientID: {}", caseDetails.getClientId());
			LOG.debug("CaseId: {}", caseDetails.getCaseId());
			LOG.debug("CaseType: {}", caseType);
		}
		addAdditionalRequestIdentifier(additionalRequestIdentifierList, "ClientId", caseDetails.getClientId());
		addAdditionalRequestIdentifier(additionalRequestIdentifierList, "WorkflowTaskID", caseDetails.getWorkflowTaskID());
		addAdditionalRequestIdentifier(additionalRequestIdentifierList, "TransitionManager", caseDetails.getTransitionManager());
		addAdditionalRequestIdentifier(additionalRequestIdentifierList, "Phase", caseDetails.getCurrentPhaseName());
		addAdditionalRequestIdentifier(additionalRequestIdentifierList, "TaskType", caseType);
		//
		addAdditionalRequestIdentifier(additionalRequestIdentifierList, "PhaseTargetImplementationDate", caseDetails.getPhaseTargetImplementationDate());
		addAdditionalRequestIdentifier(additionalRequestIdentifierList, "TargetImplementationDate", caseDetails.getTargetImplementationDate());
		addAdditionalRequestIdentifier(additionalRequestIdentifierList, "ActualImplementationDate", caseDetails.getActualImplementationDate());
		return updateAdditionalRequestIdentifiers;
	}

	private DisplayFields createDisplayFields(CreateCTHCaseContext context) {
		DisplayField displayField = new DisplayField();
		displayField.setFieldName("PhaseDescription");
		displayField.setValue(context.getCaseDetails().getCurrentPhaseDescription());
		//
		DisplayFields displayFields = new DisplayFields();
		displayFields.getDisplayFields().add(displayField);
		return displayFields;
	}

	private void addAdditionalRequestIdentifier(List<AdditionalRequestIdentifier> additionalRequestIdentifierList, String key, String value) {
		if (value != null && !value.isEmpty()) {
			additionalRequestIdentifierList.add(createAdditionalRequestIdentifier(key, value));
		}
	}

	private void addAdditionalRequestIdentifier(List<AdditionalRequestIdentifier> additionalRequestIdentifierList, String key, Date date) {
		if (date != null) {
			additionalRequestIdentifierList.add(createAdditionalRequestIdentifier(key, date));
		}
	}

	public AdditionalRequestIdentifier createAdditionalRequestIdentifier(String name, Date date) {
		AdditionalRequestIdentifier additionalRequestIdentifier = new AdditionalRequestIdentifier();
		additionalRequestIdentifier.setKey(name);
		additionalRequestIdentifier.setDateValue(DateUtil.toXMLGregorianCalendar(date));
		return additionalRequestIdentifier;
	}

	public AdditionalRequestIdentifier createAdditionalRequestIdentifier(String name, String value) {
		AdditionalRequestIdentifier additionalRequestIdentifier = new AdditionalRequestIdentifier();
		additionalRequestIdentifier.setKey(name);
		additionalRequestIdentifier.setValue(value);
		return additionalRequestIdentifier;
	}

	public void setCthRequestBuilder(PayloadInfoBuilder cthRequestBuilder) {
		this.cthRequestBuilder = cthRequestBuilder;
	}
}
