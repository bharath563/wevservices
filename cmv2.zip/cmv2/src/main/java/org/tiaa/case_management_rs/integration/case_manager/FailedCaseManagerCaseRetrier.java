package org.tiaa.case_management_rs.integration.case_manager;

import org.tiaa.case_management_rs.domain.CMSAuditHistory;

public interface FailedCaseManagerCaseRetrier {
	 void retryFailedCaseManagerCase(CMSAuditHistory cmsAuditHistory);
}
