package org.tiaa.case_management_rs.poller;

public class AsyncAnnotationConfiguration {
	public static final String ASYNC_TASK_EXECUTOR_CORE_POOL_SIZE = "async.taskexecutor.core.pool.size";
	public static final String ASYNC_TASK_EXECUTOR_MAX_POOL_SIZE = "async.taskexecutor.max.pool.size";
	public static final String ASYNC_TASK_EXECUTOR_QUEUE_CAPACITY = "async.taskexecutor.queue.capacity";
	//
	private static final int ASYNC_TASK_EXECUTOR_CORE_POOL_SIZE_VALUE = 5;
	private static final int ASYNC_TASK_EXECUTOR_MAX_POOL_SIZE_VALUE = 10;
	private static final int ASYNC_TASK_EXECUTOR_QUEUE_CAPACITY_VALUE = 20;

	public AsyncAnnotationConfiguration() {
	}

	public int getAsyncTaskExecutorCorePoolSize() {
		return ASYNC_TASK_EXECUTOR_CORE_POOL_SIZE_VALUE;
	}

	public int getAsyncTaskExecutorMaxPoolSize() {
		return ASYNC_TASK_EXECUTOR_MAX_POOL_SIZE_VALUE;
	}

	public int getAsyncTaskExecutorQueueCapacity() {
		return ASYNC_TASK_EXECUTOR_QUEUE_CAPACITY_VALUE;
	}
}
