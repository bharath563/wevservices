package org.tiaa.case_management_rs.constants;

public final class CaseManagmentKeys {
	/**
	 * Default constructor. This is for restricting instantiation
	 */
	private CaseManagmentKeys() {

	}
	public static final String GENERAL_EXCEPTION_CODE = "ERROR.GENERAL.EXCEPTION.CODE";
	public static final String GENERAL_EXCEPTION_TYPE = "ERROR.GENERAL.EXCEPTION.TYPE";
	public static final String GENERAL_EXCEPTION_TEXT = "ERROR.GENERAL.EXCEPTION.TEXT";
	
	public static final String TIME_OUT = "ERROR.PLAN.ADMIN.TIME.OUT";
	public static final String DSV_CALL_FAILED = "ERROR.PLAN.ADMIN.DSV.SERVICE.FAILED";
	public static final String INVALID_DSV_RESPONSE = "ERROR.PLAN.ADMIN.INVALID.DSV.RESPONSE";
	public static final String DATABASE_CALL_FAILED = "ERROR.PLAN.ADMIN.DATABASE_CALL_FAILED";

	public static final String MDM_CALL_FAILED = "ERROR.PLAN.ADMIN.MDM.SERVICE.FAILED";
	public static final String MVAS_CALL_FAILED = "ERROR.PLAN.ADMIN.MVAS.SERVICE.FAILED";
	public static final String ODS_CALL_FAILED = "ERROR.PLAN.ADMIN.ODS.SERVICE.FAILED";
	public static final String AWC_DS_CALL_FAILED = "ERROR.PLAN.ADMIN.AWCDS.SERVICE.FAILED";
	public static final String DSV_SERVICE_FAILED = "ERROR.DSV.SERVICE.FAILED";
}
