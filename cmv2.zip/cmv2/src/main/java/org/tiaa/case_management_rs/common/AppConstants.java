package org.tiaa.case_management_rs.common;

public interface AppConstants {
	String APPLICATION_NAME = "CaseManagementRSV2";
	String APPLICATION_DESCRIPTION = "Case Management";
	String USER_REF = "CaseManagementRSV2";
	String TASK_ID_NOT_AVAILABLE_IN_CTH_AT_THE_TIME_OF_CANCELLATION = "org.tiaa.case_management_rs.integration.cth.CTHRecordNotFoundException";
	String CUSTOMER_NUMBER_REQUIRED = "CustomerNumber is missing in the identifiers. Cannot create CTH Record";
	String CTH_RECORD_NOT_FOUND = "NO_MATCHING_REQUEST_FOUND:No matching transactions found for the search parameters provided";
	String STATUS_PACKAGE = "org.tiaa.case_management_rs.status.";
}
