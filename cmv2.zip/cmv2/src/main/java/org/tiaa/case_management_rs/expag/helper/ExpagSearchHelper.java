package org.tiaa.case_management_rs.expag.helper;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.util.ArrayList;
import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.delegate.impl.ColumnsMapping;
import org.tiaa.case_management_rs.model.SearchItemsVO;
import org.tiaa.case_management_rs.model.SortCriteriaVO;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.DateType;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;
import org.tiaa.esb.case_management_rs_v2.type.SortCriteria;
import org.tiaa.esb.case_management_rs_v2.type.SortOrder;

@Component
public class ExpagSearchHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExpagSearchHelper.class);

//	public QuickSerachByIdentVO singleIdentiferSearchRequest(String userId, SearchRequest searchRequest) {
//
//		QuickSerachByIdentVO quickSearchByIdent = new QuickSerachByIdentVO();
//
//		quickSearchByIdent.setUserId(userId);
//
//		if (searchRequest.getTaskStatus() != null) {
//
//			if (Status.SUSPENDED.toString().equalsIgnoreCase(searchRequest.getTaskStatus().toString())) {
//				quickSearchByIdent.setTaskstatus("S");
//			} else if (Status.COMPLETED.toString().equalsIgnoreCase(searchRequest.getTaskStatus().toString())) {
//				quickSearchByIdent.setTaskstatus("C");
//			} else if (Status.OPEN.toString().equalsIgnoreCase(searchRequest.getTaskStatus().toString())) {
//				quickSearchByIdent.setTaskstatus("O");
//			} else {
//				quickSearchByIdent.setTaskstatus("A");
//			}
//		} else {
//			quickSearchByIdent.setTaskstatus("A");
//		}
//
//		if ((searchRequest.getRowCount() != null) && (searchRequest.getRowCount() > 0)) {
//			quickSearchByIdent.setRowcount(searchRequest.getRowCount());
//		}
//
//		// Begin date and EndDate range is based on createdate if supplied
//		if ((searchRequest.getFilterType() != null) && (searchRequest.getFilterType().equals(DateType.CREATED_DATE))) {
//
//			quickSearchByIdent.setBeginDate(DateUtil.toCalendarDateOnly(searchRequest.getStartDate()));
//			quickSearchByIdent.setEndDate(DateUtil.toCalendarDateOnly(searchRequest.getEndDate()));
//			quickSearchByIdent.setUsecreatedate(true);
//
//		} else if ((searchRequest.getFilterType() != null) && (searchRequest.getFilterType().equals(DateType.RECEIVED_DATE))) {
//
//			quickSearchByIdent.setBeginDate(DateUtil.toCalendarDateOnly(searchRequest.getStartDate()));
//			quickSearchByIdent.setEndDate(DateUtil.toCalendarDateOnly(searchRequest.getEndDate()));
//			quickSearchByIdent.setUsecreatedate(false);
//		} else {
//			quickSearchByIdent.setUsecreatedate(false);
//		}
//
//		if ((searchRequest.getIdentifiers() != null) && (searchRequest.getIdentifiers().getIdentifiers().size() > 0)) {
//
//			quickSearchByIdent.setUserId(userId);
//
//			Identifier cmsIndIdentifier1 = searchRequest.getIdentifiers().getIdentifiers().get(0);
//
//			// First identifier set
//			quickSearchByIdent.setIddesc1(cmsIndIdentifier1.getDesc());
//
//			if (cmsIndIdentifier1.getSubFields() != null) {
//
//				for (int i = 0; i < cmsIndIdentifier1.getSubFields().getSubFields().size(); i++) {
//
//					SubField subField = cmsIndIdentifier1.getSubFields().getSubFields().get(i);
//					if (subField != null) {
//						if (subField.getFieldNumber() == 1) {
//							quickSearchByIdent.setField11(subField.getFieldValue());
//						} else if (subField.getFieldNumber() == 2) {
//							quickSearchByIdent.setField12(subField.getFieldValue());
//						} else if (subField.getFieldNumber() == 3) {
//							quickSearchByIdent.setField13(subField.getFieldValue());
//						} else if (subField.getFieldNumber() == 4) {
//							quickSearchByIdent.setField14(subField.getFieldValue());
//						}
//					}
//
//				}
//			}
//		}
//
//		return quickSearchByIdent;
//	}

	public SearchItemsVO multiSearchRequest(String userId, SearchRequest searchRequest) {

		SearchItemsVO searchItemsVO = new SearchItemsVO();

		// Set straight forward values
		searchItemsVO.setUserId(userId);

		if (StringUtils.isNotBlank(searchRequest.getTaskId())) {
			searchItemsVO.setTaskid(searchRequest.getTaskId());
		}

		if (StringUtils.isNotBlank(searchRequest.getTaskType())) {
			searchItemsVO.setTasktype(searchRequest.getTaskType());
		}

		if (StringUtils.isNotBlank(searchRequest.getDepartment())) {
			searchItemsVO.setDeptdesc(searchRequest.getDepartment());
		}

		if (StringUtils.isNotBlank(searchRequest.getAssignedTo())) {
			searchItemsVO.setWorkbasket(searchRequest.getAssignedTo());
		}

		if (StringUtils.isNotBlank(searchRequest.getAction())) { 
			searchItemsVO.setActdesc(searchRequest.getAction());
		}

		if (searchRequest.getTaskStatus() != null) {

			if (TASK_STATUS_SUSPENDED.equalsIgnoreCase(searchRequest.getTaskStatus().getSts())) {
				searchItemsVO.setTaskstatus("S");
			} else if (TASK_STATUS_COMPLETED.equalsIgnoreCase(searchRequest.getTaskStatus().getSts())) {
				searchItemsVO.setTaskstatus("C");
				searchItemsVO.setCompletedStatus(true);
			} else if (TASK_STATUS_OPEN.equalsIgnoreCase(searchRequest.getTaskStatus().getSts())) {
				searchItemsVO.setTaskstatus("O");
			} else if (TASK_STATUS_OUTSTANDING.equalsIgnoreCase(searchRequest.getTaskStatus().getSts())) {
				searchItemsVO.setTaskstatus("U");
			} else if (TASK_STATUS_CLOSED.equalsIgnoreCase(searchRequest.getTaskStatus().getSts())){
				searchItemsVO.setTaskstatus("C");
				searchItemsVO.setClosedStatus(true);
			} 	else {
				searchItemsVO.setTaskstatus("A");
			}
		} else {
			searchItemsVO.setTaskstatus("A");
		}

		if ((searchRequest.getRowCount() != null) && (searchRequest.getRowCount() > 0)) {
			searchItemsVO.setRowcount(searchRequest.getRowCount());
		}

		// Searches only those tasks not assigned to a caseworker(workbasket)
		if (StringUtils.isNotBlank(searchRequest.getAssignedTo())) {
			searchItemsVO.setEmptyworkbasket(true);
		} else {
			searchItemsVO.setEmptyworkbasket(false);
		}

		// Begin date and EndDate range is based on createdate if supplied
		if ((searchRequest.getFilterType() != null) && (searchRequest.getFilterType().equals(DateType.CREATED_DATE))) {

			searchItemsVO.setBeginDate(DateUtil.toCalendarDateOnly(searchRequest.getStartDate()));
			searchItemsVO.getBeginDate().set(Calendar.HOUR_OF_DAY,searchItemsVO.getBeginDate().getMinimum(Calendar.HOUR_OF_DAY));
			searchItemsVO.getBeginDate().set(Calendar.MINUTE,searchItemsVO.getBeginDate().getMinimum(Calendar.MINUTE));
			searchItemsVO.getBeginDate().set(Calendar.SECOND,searchItemsVO.getBeginDate().getMinimum(Calendar.SECOND));
			searchItemsVO.getBeginDate().set(Calendar.MILLISECOND,searchItemsVO.getBeginDate().getMinimum(Calendar.MILLISECOND));
			
			searchItemsVO.setEndDate(DateUtil.toCalendarDateOnly(searchRequest.getEndDate()));
			searchItemsVO.getEndDate().set(Calendar.HOUR_OF_DAY, searchItemsVO.getEndDate().getMaximum(Calendar.HOUR_OF_DAY));
			searchItemsVO.getEndDate().set(Calendar.MINUTE,      searchItemsVO.getEndDate().getMaximum(Calendar.MINUTE));
			searchItemsVO.getEndDate().set(Calendar.SECOND,      searchItemsVO.getEndDate().getMaximum(Calendar.SECOND));
			searchItemsVO.getEndDate().set(Calendar.MILLISECOND, searchItemsVO.getEndDate().getMaximum(Calendar.MILLISECOND));
			searchItemsVO.setUsecreatedate(true);

		} else if ((searchRequest.getFilterType() != null) && (searchRequest.getFilterType().equals(DateType.RECEIVED_DATE))) {

			searchItemsVO.setBeginDate(DateUtil.toCalendarDateOnly(searchRequest.getStartDate()));
			searchItemsVO.getBeginDate().set(Calendar.HOUR_OF_DAY,searchItemsVO.getBeginDate().getMinimum(Calendar.HOUR_OF_DAY));
			searchItemsVO.getBeginDate().set(Calendar.MINUTE,searchItemsVO.getBeginDate().getMinimum(Calendar.MINUTE));
			searchItemsVO.getBeginDate().set(Calendar.SECOND,searchItemsVO.getBeginDate().getMinimum(Calendar.SECOND));
			searchItemsVO.getBeginDate().set(Calendar.MILLISECOND,searchItemsVO.getBeginDate().getMinimum(Calendar.MILLISECOND));
			
			searchItemsVO.setEndDate(DateUtil.toCalendarDateOnly(searchRequest.getEndDate()));
			searchItemsVO.getEndDate().set(Calendar.HOUR_OF_DAY, searchItemsVO.getEndDate().getMaximum(Calendar.HOUR_OF_DAY));
			searchItemsVO.getEndDate().set(Calendar.MINUTE,      searchItemsVO.getEndDate().getMaximum(Calendar.MINUTE));
			searchItemsVO.getEndDate().set(Calendar.SECOND,      searchItemsVO.getEndDate().getMaximum(Calendar.SECOND));
			searchItemsVO.getEndDate().set(Calendar.MILLISECOND, searchItemsVO.getEndDate().getMaximum(Calendar.MILLISECOND));
			
			searchItemsVO.setUsecreatedate(false);
		} else {
			searchItemsVO.setUsecreatedate(false);
		}

		if ((searchRequest.getProperties() != null) && (searchRequest.getProperties().getProperties().size() > 0)) { 

			NameValue nameValue1 = searchRequest.getProperties().getProperties().get(0);

			// First identifier set
			searchItemsVO.setIddesc1(nameValue1.getDesc());

			if (nameValue1.getChildrenNameValues() != null) {

				for (int i = 0; i < nameValue1.getChildrenNameValues().size(); i++) { 

					NameValue childNameValue = nameValue1.getChildrenNameValues().get(i);
					if (childNameValue != null) { 
						if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 1)) { 
							searchItemsVO.setField11(childNameValue.getValue());
						} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 2)) {
							searchItemsVO.setField12(childNameValue.getValue());
						} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 3)) {
							searchItemsVO.setField13(childNameValue.getValue());
						} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 4)) {
							searchItemsVO.setField14(childNameValue.getValue());
						}
					}

				}
			}
			
			if ((searchRequest.getProperties() != null) && (searchRequest.getProperties().getProperties().size() > 1)) {

				NameValue nameValue2 = searchRequest.getProperties().getProperties().get(1);
				searchItemsVO.setIddesc2(nameValue2.getDesc());
				// Second identifier set

				if (nameValue2.getChildrenNameValues() != null) {

					for (int i = 0; i < nameValue2.getChildrenNameValues().size(); i++) {

						NameValue childNameValue = nameValue2.getChildrenNameValues().get(i);

						if (childNameValue != null) {
							if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 1)) {
								searchItemsVO.setField21(childNameValue.getValue());
							} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 2)) {
								searchItemsVO.setField22(childNameValue.getValue());
							} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 3)) {
								searchItemsVO.setField23(childNameValue.getValue());
							} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 4)) {
								searchItemsVO.setField24(childNameValue.getValue());
							}

						}
					}
				}

				if ((searchRequest.getProperties() != null) && (searchRequest.getProperties().getProperties().size() > 2)) {
					NameValue nameValue3 = searchRequest.getProperties().getProperties().get(2);

					// Third identifier set
					searchItemsVO.setIddesc3(nameValue3.getDesc());

					if (nameValue3.getChildrenNameValues() != null) {

						for (int i = 0; i < nameValue3.getChildrenNameValues().size(); i++) {

							NameValue childNameValue = nameValue3.getChildrenNameValues().get(i);
							if (childNameValue != null) {
								if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 1)) {
									searchItemsVO.setField31(childNameValue.getValue());
								} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 2)) {
									searchItemsVO.setField32(childNameValue.getValue());
								} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 3)) {
									searchItemsVO.setField33(childNameValue.getValue());
								} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 4)) {
									searchItemsVO.setField34(childNameValue.getValue());
								}
							}

						}
					}
				}

			}

		}
		
		searchItemsVO.setSortCriteria(new ArrayList<SortCriteriaVO>());
		SortCriteriaVO sortCriteriaVO = new SortCriteriaVO();
		if(searchRequest.getSortCriteriaInfo() != null && searchRequest.getSortCriteriaInfo().getSortCriterias() != null && searchRequest.getSortCriteriaInfo().getSortCriterias().size()>0 ){
			SortCriteria sortCriteria = searchRequest.getSortCriteriaInfo().getSortCriterias().get(0);
			String sortField = sortCriteria.getSortField();

			if(StringUtils.isNotBlank(sortField)){
				sortCriteriaVO.setCriteriaName(ColumnsMapping.getEXPAGColumn(sortField));
			}else{
				sortCriteriaVO.setCriteriaName("DATERCVD");
			}
			if(sortCriteria.getSortOrder() != null){
				sortCriteriaVO.setDesc(sortCriteria.getSortOrder().value().equalsIgnoreCase(SortOrder.DESC.value()));
			}
			searchItemsVO.getSortCriteria().add(sortCriteriaVO);

		}else{
			//default values
			sortCriteriaVO.setCriteriaName("DATERCVD");
			sortCriteriaVO.setDesc(true);
		}
		
		

		return searchItemsVO;

	}
	

}
