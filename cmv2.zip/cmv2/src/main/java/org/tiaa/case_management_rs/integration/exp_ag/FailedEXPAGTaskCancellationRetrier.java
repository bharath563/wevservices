package org.tiaa.case_management_rs.integration.exp_ag;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.common.ExceptionHandler;
import org.tiaa.case_management_rs.domain.CMSAudit;
import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.CMRSEvent;
import org.tiaa.case_management_rs.email.EmailSender;
import org.tiaa.case_management_rs.email.EmailUtil;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.PowerImageService;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.WorkflowException;
import org.tiaa.case_management_rs.repository.CMSAuditHistoryRepository;
import org.tiaa.case_management_rs.repository.CMSAuditRepository;
import org.tiaa.case_management_rs.repository.CMSAuditService;
import org.tiaa.case_management_rs.utils.CommonUtil;

@Service
public class FailedEXPAGTaskCancellationRetrier {
	private static final Logger log = LoggerFactory.getLogger(FailedEXPAGTaskCancellationRetrier.class);
	@Autowired
	private CMSAuditRepository cmsAuditRepository;
	@Autowired
	private CMSAuditHistoryRepository cmsAuditHistoryRepository;
	@Autowired
	private PowerImageService powerImageService;
	@Autowired
	private CMSAuditService cmsAuditService;
	@Autowired
	private EmailSender emailSender;

	public void retryFailedEXPAGTaskCancellation(final CMSAuditHistory cmsAuditHistory) {
		if (CommonUtil.isNullOrEmpty(cmsAuditHistory.getTaskId())) {
			ExceptionHandler.runSafe(new Runnable() {
				@Override
				public void run() {
					updateTaskIdForCancelledEvent(cmsAuditHistory);
				}
			});
		}
		cancelCTHRecord(cmsAuditHistory, cmsAuditHistory.getTaskId());
	}

	private void updateTaskIdForCancelledEvent(CMSAuditHistory cmsAuditHistory) {
		//cth payload didnt have task id
		String comments = cmsAuditHistory.getComments();
		String[] keyValue = comments.split("=");
		if (keyValue.length <= 1) {
			log.warn("comment: {}", comments);
			return;
		}
		String key = keyValue[0];
		log.info("value:{}", keyValue[1]);
		if ("orchId".equals(key)) {
			String orchId = keyValue[1];
			log.info("orchestrationId:{}", orchId);
			CMSAudit cmsAudit = cmsAuditRepository.findByCthOrchestrationId(orchId);
			if (cmsAudit != null) {
				cmsAuditHistory.setTaskId(cmsAudit.getTaskId());
				cmsAuditHistory.setCmsAudit(cmsAudit);
				cmsAuditHistory.setLastUpdatedTs(new Date());
				cmsAuditHistoryRepository.saveAndFlush(cmsAuditHistory);
			} else {
				log.warn("cmsAudit is null for :{}", orchId);
			}
		} else {
			log.warn("unknown key type:{}", key);
		}
	}

	private void cancelCTHRecord(CMSAuditHistory cmsAuditHistory, String taskId) {
		if (taskId == null) {
			log.warn("task id is still null");
			int retryAttempt = cmsAuditHistory.getRetryAttempt();
			cmsAuditHistory.setRetryAttempt(retryAttempt + 1);
			cmsAuditService.markAsFailed(cmsAuditHistory, AppConstants.TASK_ID_NOT_AVAILABLE_IN_CTH_AT_THE_TIME_OF_CANCELLATION);
			return;
		}
		try {
			powerImageService.cancelTask(taskId);
			cmsAuditService.markAsSuccessful(cmsAuditHistory);
		} catch (WorkflowException e) {
			log.debug("failed to cancel task:{}", taskId);
			log.warn(e.getMessage(), e);
			cmsAuditService.markAsFailed(cmsAuditHistory, e);
			emailSender.sendEmailToProdSupport("Error while cancelling EXPAG Task with Task Id:" + taskId, EmailUtil.createEmail(cmsAuditHistory, e));
		}
	}

	public static boolean isCancelEXPAGTaskRecord(CMSAuditHistory cmsAuditHistory) {
		if (CMRSEvent.EXPAG_CANCEL_TASK.name().equals(cmsAuditHistory.getEventName())) {
			return true;
		}
		return cmsAuditHistory.isCthEvent() && "Cancelled".equals(cmsAuditHistory.getCthRequestStatus());
	}
}
