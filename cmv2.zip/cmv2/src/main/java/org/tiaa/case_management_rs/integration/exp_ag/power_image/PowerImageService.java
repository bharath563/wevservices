package org.tiaa.case_management_rs.integration.exp_ag.power_image;

import java.io.StringReader;
import java.io.StringWriter;
import java.rmi.RemoteException;
import java.util.Calendar;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBException;

import org.jvnet.hk2.annotations.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sungard.sws.pi.webservice.WebServiceBeanPortStub;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.model.AddDocumentExVO;
import org.tiaa.case_management_rs.model.AddDocumentVO;
import org.tiaa.case_management_rs.model.CreateWork;
import org.tiaa.case_management_rs.model.ProcessTaskVO;
import org.tiaa.case_management_rs.model.QuickSerachByIdentVO;
import org.tiaa.case_management_rs.model.SearchCasesVO;
import org.tiaa.case_management_rs.model.SearchDocumentsVO;
import org.tiaa.case_management_rs.model.SearchItemsVO;
import org.tiaa.esb.powerimage.types.Case;
import org.tiaa.esb.powerimage.types.Cases;
import org.tiaa.esb.powerimage.types.Comments;
import org.tiaa.esb.powerimage.types.Document;
import org.tiaa.esb.powerimage.types.Document.Docstream;
import org.tiaa.esb.powerimage.types.DocumentActivities;
import org.tiaa.esb.powerimage.types.Documents;
import org.tiaa.esb.powerimage.types.Faxes;
import org.tiaa.esb.powerimage.types.GetWorkItem;
import org.tiaa.esb.powerimage.types.PIAcknowledge;
import org.tiaa.esb.powerimage.types.PIError;
import org.tiaa.esb.powerimage.types.ProcessTask;
import org.tiaa.esb.powerimage.types.ProcessTaskResult;
import org.tiaa.esb.powerimage.types.Task;
import org.tiaa.esb.powerimage.types.TaskActivities;
import org.tiaa.esb.powerimage.types.Tasks;
import org.tiaa.esb.powerimage.types.WorkPacket;

@Service
public class PowerImageService {

	private static final Logger LOG = LoggerFactory.getLogger(PowerImageService.class);

	private String defaultUserId = "isvoper";// or plansponsor or the user who
	// took the action??
	@Autowired
	private PoweImageProxy poweImageProxy;

	@Autowired
	private Jaxb2Marshaller powerImageJaxb2Marshaller;

	@Autowired
	private Jaxb2Marshaller powerImageCreateTaskJaxb2Marshaller;

	@Autowired
	private Jaxb2Marshaller powerImageTaskSearchJaxb2Marshaller;

	private WebServiceBeanPortStub powerImageProxyStub;

	public PowerImageService() {
	}

	public PowerImageService(PoweImageProxy poweImageProxy) {
		this.poweImageProxy = poweImageProxy;
	}

	@PostConstruct
	public void init() {
		this.powerImageProxyStub = this.poweImageProxy.createEXPAGProxy();
	}

	public boolean addComment(String taskId, String userId, String addHistFlg, String commentTxt) {
		try {
			return this.powerImageProxyStub.addComment(taskId, userId.toLowerCase(), addHistFlg, commentTxt);
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return false;
	}

	public boolean addDocument(AddDocumentVO document) {
		try {
			return this.powerImageProxyStub.addDocument(document.getUserId().toLowerCase(), document.getTaskId(), document.getPacketId(), document.getStorage(), document.getExtDocKey(), document.getExtSysName(), document.getUrlDocPath(), document.getNotes(), document.getWrkStationId(), document.getPageTotal(), document.getMailDesc(), document.getMailId(), document.getArchBox(), document.getMagFldName(), document.getFileSize(), document.getFileType(), document.getPiDocType(), document.getFaxNumber());
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return false;
	}

	public boolean addDocumentEx(AddDocumentExVO document) {
		try {
			return this.powerImageProxyStub.addDocumentEx(document.getUserId().toLowerCase(), document.getTaskId(), document.getPacketId(), document.getStorage(), document.getExtDocKey(), document.getExtSysName(), document.getUrlDocPath(), document.getNotes(), document.getWrkStationId(), document.getPageTotal(), document.getMailDesc(), document.getMailId(), document.getArchBox(), document.getMagFldName(), document.getFileSize(), document.getFileType(), document.getPiDocType(), document.getFaxNumber(), document.getContType(), document.getStartPage(), document.getEndPage(), document.isTaskOnlyFlag());
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return false;
	}

	public PIAcknowledge addTasksToPacket(String userId, org.tiaa.esb.powerimage.types.AddTasksToPacket expagTasksPacket) {

		PIAcknowledge expagAck = new PIAcknowledge();

		try {

			String request = marshal(expagTasksPacket);

			String response = this.powerImageProxyStub.addTasksToPacket(userId.toLowerCase(), request);

			LOG.debug("addTasksToPacket EXP AG response: " + response);

			Object obj = unmarshal(response);

			if (obj instanceof PIAcknowledge) {
				expagAck = (PIAcknowledge) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}

		return expagAck;
	}

	public boolean addXMLData(String userId, String taskId, String createOper, String xsltFile, String xml) {
		try {
			return this.powerImageProxyStub.addXMLData(userId.toLowerCase(), taskId, createOper, xsltFile, xml);
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return false;
	}

	public boolean cancelTask(String taskId) {
		try {
			return this.powerImageProxyStub.cancelTask(this.defaultUserId.toLowerCase(), taskId);
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return false;
	}

	public boolean cancelTask(String userId, String taskId) {
		try {
			return this.powerImageProxyStub.cancelTask(userId.toLowerCase(), taskId);
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return false;
	}

	public boolean cancelTaskEx(String userId, String taskId, String useCommentsNotes, String commentsNotes) {
		try {
			return this.powerImageProxyStub.cancelTaskEx(userId.toLowerCase(), taskId, useCommentsNotes, commentsNotes);
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return false;
	}

	public PIAcknowledge createWork(CreateWork work) {
		PIAcknowledge expagAck = new PIAcknowledge();

		try {

			String response = this.powerImageProxyStub.createWork(work.getUserId().toLowerCase(), work.getDepartment(), work.getTaskType(), work.getActionStep(), work.getCreateOper(), work.getReceivedDate(), work.getVip(), work.getWorkBasket(), work.getPriority(), work.getScanMode(), work.isByPassArcIdent(), work.getComments(), work.getWrkStationId(), work.getIdDesc(), work.getField1(), work.getField2(), work.getField3(), work.getField4(), work.getStorage(), work.getExtDocKey(), work.getExtSysName(), work.getUrlDocPath(), work.getNotes(), work.getPageTotal(), work.getMailDesc(), work.getMailId(), work.getArchBox(), work.getMagFldName(), work.getFileSize(), work.getFileType(), work.getPiDocType(), work.getFaxNumber());

			LOG.debug("createWork EXP AG response: " + response);

			Object obj = unmarshal(response);

			if (obj instanceof PIAcknowledge) {
				expagAck = (PIAcknowledge) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return expagAck;
	}

	public PIAcknowledge createWorkEx(String userId, org.tiaa.esb.powerimage.createtask.types.WorkPacket work) {
		PIAcknowledge expagAck = new PIAcknowledge();

		try {

			String request = createTaskMarshal(work);

			LOG.debug("Request xml : " + request);

			String response = this.powerImageProxyStub.createWorkEx(userId.toLowerCase(), request);

			LOG.debug("createWorkEx EXP AG response: " + response);

			Object obj = unmarshal(response);

			if (obj instanceof PIAcknowledge) {
				expagAck = (PIAcknowledge) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return expagAck;
	}

	public Case getCaseDetails(String userId, String caseDesc, String caseId) {
		Case expagCase = new Case();
		try {
			String response = this.powerImageProxyStub.getCaseDetails(userId.toLowerCase(), caseDesc, caseId);
			LOG.debug("CaseDetails Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof Case) {
				expagCase = (Case) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return expagCase;
	}

	public Document getDocument(String userId, String docId) {
		Document expagDocument = new Document();
		try {
			String response = this.powerImageProxyStub.getDocument(userId.toLowerCase(), docId);
			LOG.debug("GetDocument Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof Document) {
				expagDocument = (Document) obj;
				Docstream docstream = expagDocument.getDocstream();
				if (docstream != null) {
					String value = docstream.getValue();
					LOG.debug("DocStream encoded value : " + value);
				} else {
					LOG.warn("DocStream is null");
				}				
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			LOG.error("Document not availabe in exp ag for document id : " + docId);
			handleRemoteException(e);
		}
		return expagDocument;
	}

	public Document getDocumentDetails(String userId, String docId) {
		Document expagDocument = new Document();
		try {
			String response = this.powerImageProxyStub.getDocumentDetails(userId.toLowerCase(), docId);
			LOG.debug("GetDocumentmentDetails Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof Document) {
				expagDocument = (Document) obj;
				Docstream docstream = expagDocument.getDocstream();
				if (docstream != null) {
					String value = docstream.getValue();
					LOG.debug("DocStream encoded value : " + value);
				} else {
					LOG.warn("DocStream is null");
				}				
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException rmie) {
			LOG.warn("DocumentDetails not availabe in exp ag for document id : " + docId);
		}
		return expagDocument;
	}

	public GetWorkItem getWorkItem(String userId, String taskId, Calendar lastHist) {
		GetWorkItem getWorkItem = new GetWorkItem();
		try {
			String response = this.powerImageProxyStub.getWorkItem(userId.toLowerCase(), taskId, lastHist);
			LOG.debug("GetWorkItem Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof GetWorkItem) {
				getWorkItem = (GetWorkItem) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return getWorkItem;
	}

	public WorkPacket getWorkPacketDetails(String userId, String pktId) {
		WorkPacket expagWorkPacket = new WorkPacket();
		try {
			String response = this.powerImageProxyStub.getWorkPacketDetails(userId.toLowerCase(), pktId);
			LOG.debug("GetWorkPacketDetails Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof WorkPacket) {
				expagWorkPacket = (WorkPacket) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return expagWorkPacket;
	}

	public String getXmlData(String userId, String taskId, Calendar created) {
		try {
			return this.powerImageProxyStub.getXmlData(userId.toLowerCase(), taskId, created);
		} catch (RemoteException e) {
			handleRemoteException(e);
			return null;
		}
	}

	public ProcessTaskResult processTask(ProcessTaskVO updatedTask) {
		ProcessTaskResult processedTask = new ProcessTaskResult();
		try {
			String response = this.powerImageProxyStub.processTask(updatedTask.getUserId().toLowerCase(), updatedTask.getTaskId(), updatedTask.getPacketId(), updatedTask.getReceiveDate(), updatedTask.getDepartment(), updatedTask.getTaskType(), updatedTask.getActionDesc(), updatedTask.getWorkBasket(), updatedTask.getVip(), updatedTask.getPriority(), updatedTask.getCaseDesc(), updatedTask.getCaseId(), updatedTask.getStatus(), updatedTask.getCommentsnotes(), updatedTask.getUsecommentsnotes(), updatedTask.getWakeOperId(), updatedTask.getWakeDate(), updatedTask.getReviewOperId(), updatedTask.getStartDate(), updatedTask.getCdReason1(), updatedTask.getCdReason2(), updatedTask.getCdReason3(), updatedTask.getCdReason4(), updatedTask.getCdReason5(), updatedTask.getUpdatedXml());
			LOG.debug("ProcessTask Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof ProcessTaskResult) {
				processedTask = (ProcessTaskResult) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return processedTask;
	}

	public ProcessTaskResult processTaskEx(String userId, ProcessTask processExpagTask) {

		ProcessTaskResult processedTask = new ProcessTaskResult();
		try {

			String updateTaskXML = marshal(processExpagTask);

			LOG.debug("Updated Task xml : " + updateTaskXML);

			String response = this.powerImageProxyStub.processTaskEx(userId.toLowerCase(), updateTaskXML);

			LOG.debug("processTaskEx Exp Ag response : " + response);

			Object obj = unmarshal(response);
			if (obj instanceof ProcessTaskResult) {
				processedTask = (ProcessTaskResult) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return processedTask;
	}

	public GetWorkItem releaseTask(String userId, String taskId, boolean lockTask) {
		GetWorkItem getWorkItem = new GetWorkItem();
		try {
			String response = this.powerImageProxyStub.releaseTask(userId.toLowerCase(), taskId, lockTask);
			LOG.debug("ReleaseTask Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof GetWorkItem) {
				getWorkItem = (GetWorkItem) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return getWorkItem;
	}

	public boolean unlockTask(String userId, String taskId, Calendar start) {
		try {
			return this.powerImageProxyStub.unLockTask(userId.toLowerCase(), taskId, start);
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return false;
	}

	public DocumentActivities getDocumentActivities(String userId, String docId) {
		DocumentActivities docActivities = new DocumentActivities();
		try {
			String response = this.powerImageProxyStub.getDocumentActivities(userId.toLowerCase(), docId);
			LOG.debug("GetDocumentActivities Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof DocumentActivities) {
				docActivities = (DocumentActivities) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return docActivities;
	}

	public Task getTaskDetails(String userId, String taskId) {
		Task task = new Task();
		try {
			String response = this.powerImageProxyStub.getTaskDetails(userId.toLowerCase(), taskId);
			LOG.debug("GetTaskDetails Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof Task) {
				task = (Task) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return task;
	}

	public TaskActivities getTaskActivities(String userId, String taskId) {
		TaskActivities taskActivities = new TaskActivities();
		try {
			String response = this.powerImageProxyStub.getTaskActivities(userId.toLowerCase(), taskId);
			LOG.debug("GetTaskActivities Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof TaskActivities) {
				taskActivities = (TaskActivities) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return taskActivities;
	}

	public Tasks getWorkItems(String userId, int count, String lockItemsFlag) {
		Tasks tasks = new Tasks();
		try {
			String response = this.powerImageProxyStub.getWorkItems(userId.toLowerCase(), count, lockItemsFlag);
			LOG.debug("GetWorkItems Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof Tasks) {
				tasks = (Tasks) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return tasks;
	}

	public org.tiaa.esb.powerimage.tasksearch.types.Tasks quickSearchByIdent(QuickSerachByIdentVO identifierSearch) {

		org.tiaa.esb.powerimage.tasksearch.types.Tasks tasks = new org.tiaa.esb.powerimage.tasksearch.types.Tasks();

		try {
			String response = this.powerImageProxyStub.quickSearchByIdent(identifierSearch.getUserId().toLowerCase(), identifierSearch.getBeginDate(), identifierSearch.getEndDate(), identifierSearch.getTaskstatus(), identifierSearch.getRowcount(), identifierSearch.isUsecreatedate(), identifierSearch.getIddesc1(), identifierSearch.getField11(), identifierSearch.getField12(), identifierSearch.getField13(), identifierSearch.getField14());

			LOG.debug("quickSearchByIdent Exp Ag response : " + response);

			Object obj = unMarshalSearchTask(response);

			if (obj instanceof org.tiaa.esb.powerimage.tasksearch.types.Tasks) {
				tasks = (org.tiaa.esb.powerimage.tasksearch.types.Tasks) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}

		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return tasks;
	}

	public Cases searchCases(SearchCasesVO caseSearch) {
		Cases expagCases = new Cases();
		try {
			String response = this.powerImageProxyStub.searchCases(caseSearch.getUserId().toLowerCase(), caseSearch.getCaseId(), caseSearch.getCaseType(), caseSearch.getBeginDate(), caseSearch.getEndDate(), caseSearch.getFirstName(), caseSearch.getMiddleName(), caseSearch.getLastName(), caseSearch.getWakeDate());
			LOG.debug("searchCases Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof Cases) {
				expagCases = (Cases) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return expagCases;
	}

	public Documents searchDocuments(SearchDocumentsVO documentSearch) {
		Documents expagDocuments = new Documents();
		try {
			String response = this.powerImageProxyStub.searchDocuments(documentSearch.getUserId().toLowerCase(), documentSearch.getDocId(), documentSearch.getBeginDate(), documentSearch.getEndDate(), documentSearch.getMailType(), documentSearch.getMailId());
			LOG.debug("searchDocuments Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof Documents) {
				expagDocuments = (Documents) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return expagDocuments;
	}

	public Faxes searchFax(String userId, Calendar beginDate, Calendar endDate, String faxNumber, String faxServer, String operId, String status) {
		Faxes expagFaxs = new Faxes();
		try {
			String response = this.powerImageProxyStub.searchFax(userId.toLowerCase(), beginDate, endDate, faxNumber, faxServer, operId, status);
			LOG.debug("GetDocument Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof Documents) {
				expagFaxs = (Faxes) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return expagFaxs;
	}

	public org.tiaa.esb.powerimage.tasksearch.types.Tasks searchTaskItems(SearchItemsVO taskSearch) {

		org.tiaa.esb.powerimage.tasksearch.types.Tasks tasks = new org.tiaa.esb.powerimage.tasksearch.types.Tasks();

		try {
			String response = this.powerImageProxyStub.searchTaskItems(taskSearch.getUserId().toLowerCase(), taskSearch.getBeginDate(), taskSearch.getEndDate(), taskSearch.getTaskstatus(), taskSearch.getTaskid(), taskSearch.getDeptdesc(), taskSearch.getTasktype(), taskSearch.getActdesc(), taskSearch.getWorkbasket(), taskSearch.getRowcount(), taskSearch.isUsecreatedate(), taskSearch.isEmptyworkbasket(), taskSearch.getIddesc1(), taskSearch.getField11(), taskSearch.getField12(), taskSearch.getField13(), taskSearch.getField14(), taskSearch.getIddesc2(), taskSearch.getField21(), taskSearch.getField22(), taskSearch.getField23(), taskSearch.getField24(), taskSearch.getIddesc3(), taskSearch.getField31(), taskSearch.getField32(), taskSearch.getField33(), taskSearch.getField34());
			LOG.debug("searchTaskItems Exp Ag response : " + response);
			Object obj = unMarshalSearchTask(response);

			if (obj instanceof org.tiaa.esb.powerimage.tasksearch.types.Tasks) {
				tasks = (org.tiaa.esb.powerimage.tasksearch.types.Tasks) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}

		} catch (RemoteException e) {
			handleRemoteException(e);
		}

		return tasks;
	}

	public Comments viewComments(String userId, String taskId) {
		Comments expagComments = new Comments();
		try {
			String response = this.powerImageProxyStub.viewComments(taskId, userId.toLowerCase(), null, null);
			LOG.debug("GetComments Exp Ag response : " + response);
			Object obj = unmarshal(response);
			if (obj instanceof Comments) {
				expagComments = (Comments) obj;
			} else if (obj instanceof PIError) {
				PIError err = (PIError) obj;
				logError(err);
			}
		} catch (RemoteException e) {
			handleRemoteException(e);
		}
		return expagComments;
	}

	private Object unmarshal(String response) {
		try {
			return this.powerImageJaxb2Marshaller.getJaxbContext().createUnmarshaller().unmarshal(new StringReader(response));
		} catch (JAXBException e) {
			LOG.error(e.getMessage(), e);
			throw new WorkflowException(e);
		}
	}

	private String marshal(Object input) {

		String output;

		try {
			StringWriter stringWriter = new StringWriter();
			this.powerImageJaxb2Marshaller.getJaxbContext().createMarshaller().marshal(input, stringWriter);
			output = stringWriter.toString();
		} catch (JAXBException e) {
			LOG.error(e.getMessage(), e);
			throw new WorkflowException(e);
		}

		return output;
	}

	private String createTaskMarshal(Object input) {

		String output;

		try {

			StringWriter stringWriter = new StringWriter();
			this.powerImageCreateTaskJaxb2Marshaller.getJaxbContext().createMarshaller().marshal(input, stringWriter);
			output = stringWriter.toString();

		} catch (JAXBException e) {
			LOG.error(e.getMessage(), e);
			throw new WorkflowException(e);
		}

		return output;

	}

	private Object unMarshalSearchTask(String response) {

		try {
			return this.powerImageTaskSearchJaxb2Marshaller.getJaxbContext().createUnmarshaller().unmarshal(new StringReader(response));
		} catch (JAXBException e) {
			LOG.error(e.getMessage(), e);
			throw new WorkflowException(e);
		}
	}

	private void logError(PIError err) {
		LOG.error("Error reponse received from Exp Ag.");
		LOG.error("Error Code : " + err.getErrorcode());
		LOG.error("Error desc : " + err.getErrordesc());

		throw new WorkflowException(err.getErrordesc());
	}

	private void handleRemoteException(RemoteException e) {
		LOG.error(e.getMessage(), e);
		throw new WorkflowException(e);
	}

	public void setPoweImageProxy(PoweImageProxy poweImageProxy) {
		this.poweImageProxy = poweImageProxy;
	}
}
