package org.tiaa.case_management_rs.expag.helper;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.axis.utils.StringUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.dao.EXPAGDAO;
import org.tiaa.case_management_rs.exception.CaseManagementRuntimeException;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItem;
import org.tiaa.esb.case_management_rs_v2.type.SubField;
import org.tiaa.esb.case_management_rs_v2.type.SubFields;

@Component
public class ExpagCorrespondenceHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExpagCorrespondenceHelper.class);

	@Value("${expag.corres.template.folderpath}")
	private String corresTemplateFolderPath;

	@Value("${expag.corres.paragraph.folderpath}")
	private String corresParagraphsFolderPath;

	@Autowired
	private EXPAGDAO expagdao;

	public ConfigItem getCorresTemplateParagraphsContent(String property, String templateName, String paragraphValues) {

		ConfigItem configItem = new ConfigItem();

		configItem.setItemName(property);

		String[] paragraphNames = StringUtils.split(paragraphValues, ',');

		try {

			File templateDirectory = new File(this.corresTemplateFolderPath);
			File paragraphDirectory = new File(this.corresParagraphsFolderPath);

			LOGGER.debug("Getting all template files in " + templateDirectory.getCanonicalPath());
			LOGGER.debug("Getting all paragraph files in " + paragraphDirectory.getCanonicalPath());

			List<File> templatefiles = (List<File>) FileUtils.listFiles(templateDirectory, TrueFileFilter.INSTANCE, null);
			List<File> paragraphfiles = (List<File>) FileUtils.listFiles(paragraphDirectory, TrueFileFilter.INSTANCE, null);

			ConfigData configData = new ConfigData();
			SubFields subFields = new SubFields();

			if (templatefiles != null && !templatefiles.isEmpty()) {

				for (File templateFile : templatefiles) {

					LOGGER.debug("template file: " + templateFile.getCanonicalPath());

					String[] result = templateFile.getName().split("\\.", 2);
					String corrsTemplateName = result[0];

					if (templateName.equals(corrsTemplateName)) {

						// Read all the bytes from a file.
						byte[] bFile = Files.readAllBytes(Paths.get(templateFile.getPath()));
						String encodedCorrsTemplate = org.apache.commons.codec.binary.Base64.encodeBase64URLSafeString(bFile);

						configData.setShortDescription(corrsTemplateName);
						configData.setLongDescription(encodedCorrsTemplate);

						// For Paragraphs content
						if (paragraphNames != null && paragraphfiles != null) {

							for (String paragraph : paragraphNames) {

								for (File paragraphfile : paragraphfiles) {

									LOGGER.debug("paragraph file: " + paragraphfile.getCanonicalPath());

									String[] resultArray = paragraphfile.getName().split("\\.", 2);
									String corrsParagraphName = resultArray[0];

									if (paragraph.equals(corrsParagraphName)) {

										// Read all the bytes from a paragraph
										// File.
										byte[] byteFile = Files.readAllBytes(Paths.get(paragraphfile.getPath()));
										String encodedCorrsParagraph = org.apache.commons.codec.binary.Base64.encodeBase64URLSafeString(byteFile);

										SubField subField = new SubField();

										subField.setFieldName(corrsParagraphName);
										subField.setFieldValue(encodedCorrsParagraph);

										// Code for Paragraph Long Name
										String paragraphFullName = this.expagdao.getExpagCorresParagraphName(paragraph);
										subField.setFieldType(paragraphFullName);

										subFields.getSubFields().add(subField);

									}

								}
								configData.setSubFields(subFields);
							}
						}
					}
				}
			}
			configItem.getDataPairs().add(configData);

		} catch (Exception e) {

			throw new CaseManagementRuntimeException("IOException occured while loading the Correspondence temaplates& Paragraphs from the directory" + e.toString());

		}
		return configItem;

	}



}
