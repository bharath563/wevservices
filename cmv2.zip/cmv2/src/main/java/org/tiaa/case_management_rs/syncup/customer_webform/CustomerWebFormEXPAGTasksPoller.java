package org.tiaa.case_management_rs.syncup.customer_webform;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;

import org.tiaa.case_management_rs.domain.WorkflowSystem;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTasksDAO;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTasksPoller;
import org.tiaa.case_management_rs.poller.Poller;

@Poller
public class CustomerWebFormEXPAGTasksPoller extends EXPAGTasksPoller {
	@Autowired
	private EXPAGTasksDAO customerWebFormEXPAGTasksDAO;
	@Autowired
	private CustomerWebFormEXPAGTaskProcessor customerWebFormEXPAGTaskProcessor;

	public CustomerWebFormEXPAGTasksPoller() {
		super(WorkflowSystem.EXP_AG_CustomerWebForm);
	}

	@PostConstruct
	public void init() {
		expagTasksDAO = customerWebFormEXPAGTasksDAO;
		taskProcessor = customerWebFormEXPAGTaskProcessor;
	}

	/*
	 * *******************************************************************************************************
	 * DISABLING CM POLLER FOR OCT 2016 POLLER, by commenting @Scheduled
	 * ********************************************************************************************************
	 */
//	@Scheduled(cron = EVERY_MINUTE_AT_30TH_SECOND)
	public void pollDatabase() {
		pollWithLock(this);
	}

	public void run() {
		final int secondStartingAtThirty = 30;
		pollForInterval(secondStartingAtThirty);
	}
}
