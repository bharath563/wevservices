package org.tiaa.case_management_rs.common;

import java.util.Map;

/**
 * Service interaction layer will use this interface to get response attributes
 * from business processing layer.
 */
public interface Response {

	/**
	 * This method is used to get an object from the response based on a key.
	 *
	 * @param key
	 *            Key to get the object from response
	 * @return Object Object that was stored in response for the given key; Null
	 *         if there is no object exists.
	 */
	Object getAttribute(String key);

	/**
	 * This method is used to set the object in the response using the given
	 * key.
	 *
	 * @param key
	 *            Key to set the object in response
	 * @param value
	 *            Object to be added in the response
	 */
	void setAttribute(String key, Object value);

	/**
	 * @return getMap
	 */
	Map<String, Object> getMap();

	/**
	 * @param map
	 */
	void putAll(Map<String, Object> map);

}
