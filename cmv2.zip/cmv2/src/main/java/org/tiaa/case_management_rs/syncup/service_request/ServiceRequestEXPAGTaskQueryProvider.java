package org.tiaa.case_management_rs.syncup.service_request;

import org.springframework.beans.factory.annotation.Value;

import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTaskType;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTasksQueryProvider;

@EXPAGTaskType(schemaName="service-request-1-0-clob.xsd")
public class ServiceRequestEXPAGTaskQueryProvider implements EXPAGTasksQueryProvider {
	@Value("${EXPAGTaskStatusForTaskTypes}")
	private String taskStatusForTaskTypesSql;
	@Value("${EXPAGNewDocumentsUploadedThroughEXPAGUI}")
	private String newDocumentsUploadedThroughEXPAGUI;
	@Value("${EXPAGNewDocumentsUploadedDuringTaskCompletionThroughEXPAGUI}")
	private String newDocumentsUploadedDuringTaskCompletionThroughEXPAGUI;
	@Value("${EXPAGTaskEventsForTaskTypes}")
	private String taskEventsForTaskTypes;
	@Value("${EXPAGTaskStatusForTaskIdOccurredAt}")
	private String taskStatusForTaskIdOccurredAt;
	@Value("${EXPAGAllDocumentsUploadedThroughEXPAGUI}")
	private String allDocumentsUploadedThroughEXPAGUI;
	@Value("${EXPAGAllDocumentsUploadedDuringTaskCompletionThroughEXPAGUI}")
	private String allDocumentsUploadedDuringTaskCompletionThroughEXPAGUI;
	@Value("${EXPAGTaskStatusForTaskIds}")
	private String taskStatusForTaskIdsSql;

	public String getTaskStatusForTaskTypesSql() {
		return taskStatusForTaskTypesSql;
	}

	public String getNewDocumentsUploadedThroughEXPAGUI() {
		return newDocumentsUploadedThroughEXPAGUI;
	}

	public String getNewDocumentsUploadedDuringTaskCompletionThroughEXPAGUI() {
		return newDocumentsUploadedDuringTaskCompletionThroughEXPAGUI;
	}

	public String getTaskEventsForTaskTypes() {
		return taskEventsForTaskTypes;
	}

	public String getTaskStatusForTaskIdOccurredAt() {
		return taskStatusForTaskIdOccurredAt;
	}

	@Override
	public String getCthRequestSchemaName() {
		return "service-request-1-0-clob.xsd";
	}

	public String getAllDocumentsUploadedThroughEXPAGUI() {
		return allDocumentsUploadedThroughEXPAGUI;
	}

	public String getAllDocumentsUploadedDuringTaskCompletionThroughEXPAGUI() {
		return allDocumentsUploadedDuringTaskCompletionThroughEXPAGUI;
	}

	@Override
	public String getTaskStatusForTaskIdsSql() {
		return taskStatusForTaskIdsSql;
	}
}
