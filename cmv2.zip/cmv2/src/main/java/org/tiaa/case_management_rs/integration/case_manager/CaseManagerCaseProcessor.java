package org.tiaa.case_management_rs.integration.case_manager;

import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;

public interface CaseManagerCaseProcessor {
	void processCase(CaseDetails caseDetails);

	void processCase(CaseDetails caseDetails, CMSAuditHistory cmsAuditHistory);
}
