package org.tiaa.case_management_rs.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StopWatch;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

public class CustomRestTemplate extends RestTemplate {
	private static final Logger LOG = LoggerFactory.getLogger(CustomRestTemplate.class);

	@Override
	public <T> ResponseEntity<T> exchange(String url, HttpMethod method, HttpEntity<?> requestEntity, Class<T> responseType, Object... uriVariables) throws RestClientException {
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		try {
			return super.exchange(url, HttpMethod.POST, requestEntity, responseType, uriVariables);
		} finally {
			stopWatch.stop();
			LOG.info("exchange took:{} milliseconds", stopWatch.getTotalTimeMillis());
		}
	}
}