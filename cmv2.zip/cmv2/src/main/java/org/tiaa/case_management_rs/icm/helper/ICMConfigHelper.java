package org.tiaa.case_management_rs.icm.helper;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.stereotype.Component;

import org.tiaa.esb.case_management_rs_v2.type.ConfigData;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItem;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItems;
import org.tiaa.esb.case_management_rs_v2.type.SubField;
import org.tiaa.esb.case_management_rs_v2.type.SubFields;
import org.tiaa.esb.icm.types.Configuration;
import org.tiaa.esb.icm.types.Properties;

@Component
public class ICMConfigHelper {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ICMConfigHelper.class);
	
	private static ObjectMapper objectMapper = new ObjectMapper();

	public ConfigItem icmConfiguration(Configuration configuration , String property) {

		ConfigItem configItem = new ConfigItem();
		
		if (configuration != null) {

			String icmResponseJSONString;
			
			try {
				icmResponseJSONString = this.objectMapper.writeValueAsString(configuration);
				this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				Configuration configurationObject = objectMapper.readValue(icmResponseJSONString, Configuration.class);
				
				if(null != configurationObject.getCasestatus()  && !configurationObject.getCasestatus().isEmpty() && property.equalsIgnoreCase("casestatus")) {
					configItem.setItemName(property);
					for(String caseStatus: configurationObject.getCasestatus()) {
						ConfigData configData = new ConfigData();
						configData.setLongDescription(caseStatus);
						configData.setShortDescription(caseStatus);
						
						configItem.getDataPairs().add(configData);
					}
					
				} else if(null != configurationObject.getChannel()  && !configurationObject.getChannel().isEmpty() && property.equalsIgnoreCase("channel")) {				
					configItem.setItemName(property);
					for(String channel : configurationObject.getChannel()){
						ConfigData configData = new ConfigData();
						configData.setLongDescription(channel);
						configData.setShortDescription(channel);
						configItem.getDataPairs().add(configData);
					}
				} 
				
				else if(null != configurationObject.getCasetype()  && !configurationObject.getCasetype().isEmpty() && property.equalsIgnoreCase("casetype") || property.equalsIgnoreCase("REQUESTTYPES")) {
					configItem.setItemName(property);
					for(String caseType: configurationObject.getCasetype()) {
						ConfigData configData = new ConfigData();
						configData.setLongDescription(caseType);
						configData.setShortDescription(caseType);
							
						configItem.getDataPairs().add(configData);
					}
				} else if(null != configurationObject.getSolution()  && !configurationObject.getSolution().isEmpty() && property.equalsIgnoreCase("solution")) {
					configItem.setItemName(property);
					for (String solution : configurationObject.getSolution()) {
						ConfigData configData = new ConfigData();
						configData.setLongDescription(solution);
						configData.setShortDescription(solution);
	
						configItem.getDataPairs().add(configData);
					}
				} else if(null != configurationObject.getRequesttypesForBusinessArea() && !configurationObject.getRequesttypesForBusinessArea().isEmpty() && property.equalsIgnoreCase("requesttypesforbusinessarea")) {
					configItem.setItemName(property);
					for (String requestType : configurationObject.getRequesttypesForBusinessArea()) {
						ConfigData configData = new ConfigData();
						configData.setLongDescription(requestType);
						configData.setShortDescription(requestType);
	
						configItem.getDataPairs().add(configData);
					}
				} else if(null != configurationObject.getIcmCeDropDown() && !configurationObject.getIcmCeDropDown().isEmpty() && (PLATFORM.equalsIgnoreCase(property) || REPAYMENT_MODE.equalsIgnoreCase(property) || MOC.equalsIgnoreCase(property))) {
					configItem.setItemName(property);
					if (configurationObject.getIcmCeDropDown().get(property).isEmpty()) {
						return configItem;
					}
					for (String requestType : configurationObject.getIcmCeDropDown().get(property)) {
						ConfigData configData = new ConfigData();
						configData.setLongDescription(requestType);
						configData.setShortDescription(requestType);
	
						configItem.getDataPairs().add(configData);
					}
				}
			
			} catch (JsonParseException e) {
				LOGGER.error("Config Item Failed For Property" +  property,  e.getMessage());
			} catch (JsonMappingException e) {
				LOGGER.error("Config Item Failed For Property" +  property,  e.getMessage());
			} catch (IOException e) {
				LOGGER.error("Config Item Failed For Property" +  property,  e.getMessage());
			}

		}
		
		return configItem;
	}


	public ConfigItems icmConfigurationToAllConfigItems(Configuration configuration) {

		ConfigItems configItems = new ConfigItems();
		
		List<ConfigItem> configItemList = configItems.getConfigItems();
		
		configItemList.add(icmConfiguration(configuration, "casestatus"));
		configItemList.add(icmConfiguration(configuration, "channel"));
		configItemList.add(icmConfiguration(configuration, "casetype"));
		configItemList.add(icmConfiguration(configuration, "solution"));
		
		return configItems;
	}
	
	public ConfigItems icmConfigurationToCEDropDowns(Configuration configuration) {

		ConfigItems configItems = new ConfigItems();
		
		List<ConfigItem> configItemList = configItems.getConfigItems();
		
		configItemList.add(icmConfiguration(configuration, PLATFORM));
		configItemList.add(icmConfiguration(configuration, MOC));
		configItemList.add(icmConfiguration(configuration, REPAYMENT_MODE));
		
		return configItems;
	}

	public ConfigItems icmConfigurationToSolutionHeadersConfig(Configuration configuration) {
		ConfigItems configItems =  new ConfigItems();
		if (configuration != null) {
			try {
				if(null != configuration.getSolutionHeaders()  && !configuration.getSolutionHeaders().isEmpty()){
					Map<String, List<Map<String, Properties>>> solutionHeaders = configuration.getSolutionHeaders();
					
					for (Map.Entry<String, List<Map<String, Properties>>> entry : solutionHeaders.entrySet()) {
						String type = entry.getKey();
						ConfigItem configItem = new ConfigItem();
						ConfigData configData = new ConfigData();
						SubFields subFields = new SubFields();
						
						for(Map<String, Properties> columnHeader: solutionHeaders.get(type)){		
							for(Entry<String, Properties>  columnEntry : columnHeader.entrySet()){
								SubField subField = new SubField();
								subField.setFieldName(columnEntry.getKey());
								subField.setFieldEntryType(columnHeader.get(columnEntry.getKey()).getType());
								subFields.getSubFields().add(subField);
							}
							configData.setSubFields(subFields);
						}
						
						if(ICM_PENDED.equalsIgnoreCase(type)){
							type = ICM_SUSPENDED;
						}else if(ICM_ALLASSIGNED.equalsIgnoreCase(type)){
							type = ICM_ASSIGNED;
						}
						
						configItem.setItemName(type);
						configItem.getDataPairs().add(configData);
						configItems.getConfigItems().add(configItem);
					}	
				}
			}  catch (Exception e) {
				LOGGER.error("Exception while converting configuration object from ICM :"+e.getMessage());
			}
				
		}
	return configItems;	
	}
}
