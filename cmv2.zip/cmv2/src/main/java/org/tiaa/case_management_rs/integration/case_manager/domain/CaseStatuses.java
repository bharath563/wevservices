package org.tiaa.case_management_rs.integration.case_manager.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

public class CaseStatuses implements Serializable {
	private static final long serialVersionUID = -7864283129671049028L;
	private List<CaseStatus> caseStatuses;

	public List<CaseStatus> getCaseStatuses() {
		if (caseStatuses == null) {
			caseStatuses = new ArrayList<CaseStatus>();
		}
		return this.caseStatuses;
	}

	public String getLatestCaseStatus() {
		Collections.sort(getCaseStatuses(), new Comparator<CaseStatus>() {
			@Override
			public int compare(CaseStatus o1, CaseStatus o2) {
				Date statusUpdatedTS1 = o1.getStatusUpdatedTS();
				Date statusUpdatedTS2 = o2.getStatusUpdatedTS();
				return statusUpdatedTS2.compareTo(statusUpdatedTS1);
			}
		});
		return caseStatuses.isEmpty() ? null : caseStatuses.get(0).getCaseStatus();
	}

	@Override
	public String toString() {
		return "CaseStatuses [caseStatuses=" + caseStatuses + "]";
	}
}
