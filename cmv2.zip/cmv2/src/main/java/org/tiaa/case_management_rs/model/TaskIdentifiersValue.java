package org.tiaa.case_management_rs.model;

public class TaskIdentifiersValue {
	
	private String fieldValue;
	private String idDesc;
	
	public String getFieldValue() {
		return fieldValue;
	}
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}
	public String getIdDesc() {
		return idDesc;
	}
	public void setIdDesc(String idDesc) {
		this.idDesc = idDesc;
	}


}
