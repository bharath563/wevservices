package org.tiaa.case_management_rs.dao;

public class CMSTaskTypeSla {

	private Integer sla;
	private String taskType;
	public Integer getSla() {
		return sla;
	}
	public String getTaskType() {
		return taskType;
	}
	public void setSla(Integer sla) {
		this.sla = sla;
	}
	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

}
