package org.tiaa.case_management_rs.integration.cth;

import org.tiaa.esb.partyrequest.types.PartyRequestResponse;
import org.tiaa.esb.partyrequest.types.UpdateRequests;
import org.tiaa.esb.partyrequest.types.UpdateRequestsResponse;

public class CTHRecordUpdater {
	private RetrieveRequestsResponseProcessor retrieveRequestsResponseProcessor;
	private CTHWebService cthWebService;
	private CTHRecordRetriever cthRecordRetriever;

	public UpdateRequestsResponse updateCTHRecord(UpdateCTHContext context) {
		PartyRequestResponse partyRequestResponse = cthRecordRetriever.retrieveCTHRecord(context.getTaskInfo());
		if (partyRequestResponse == null) {
			return null;
		}
		UpdateRequests updateRequests = retrieveRequestsResponseProcessor.processResponse(context, partyRequestResponse);
		if (updateRequests == null) {
			return null;
		}
		return cthWebService.updateCTHEntry(context, (UpdateRequests) updateRequests);
	}

	public void setRetrieveRequestsResponseProcessor(RetrieveRequestsResponseProcessor retrieveRequestsResponseProcessor) {
		this.retrieveRequestsResponseProcessor = retrieveRequestsResponseProcessor;
	}

	public void setCthWebService(CTHWebService cthWebService) {
		this.cthWebService = cthWebService;
	}

	public void setCthRecordRetriever(CTHRecordRetriever cthRecordRetriever) {
		this.cthRecordRetriever = cthRecordRetriever;
	}
}
