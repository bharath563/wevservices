package org.tiaa.case_management_rs.dao;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.math.BigInteger;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.datatype.XMLGregorianCalendar;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.model.ExpagStatusHistory;
import org.tiaa.case_management_rs.model.ExpagWorkItem;
import org.tiaa.case_management_rs.model.SLAInfo;
import org.tiaa.case_management_rs.model.SearchItemsVO;
import org.tiaa.case_management_rs.model.TaskIdentifiersValue;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItem;
import org.tiaa.esb.case_management_rs_v2.type.Document;
import org.tiaa.esb.case_management_rs_v2.type.Event;
import org.tiaa.esb.case_management_rs_v2.type.Metric;
import org.tiaa.esb.case_management_rs_v2.type.Metrics;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.Properties;
import org.tiaa.esb.case_management_rs_v2.type.Reason;
import org.tiaa.esb.case_management_rs_v2.type.Reasons;
import org.tiaa.esb.case_management_rs_v2.type.Status;
import org.tiaa.esb.case_management_rs_v2.type.Statuses;
import org.tiaa.esb.case_management_rs_v2.type.SubField;
import org.tiaa.esb.case_management_rs_v2.type.SubFields;
import org.tiaa.esb.case_management_rs_v2.type.Task;
import org.tiaa.esb.case_management_rs_v2.type.Tasks;

@Repository
public class EXPAGDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(EXPAGDAO.class);

	private boolean debugSql;

	// Expag Dropdown sql's

	@Autowired
	private JdbcTemplate expagJdbcTemplate;

	@Value("${EXPAGDepartmentDropdown}")
	private String departmentDropdownSql;
	
	/*
	@Value("${EXPAGSelectTaskXMLContent}")
    private String selectTaskXMLContent;
	
	@Value("${EXPAGSelectTaskXMLMetadata}")
	private String selectTaskXMLMetadata;
	*/
	
	@Value("${EXPAGAllDepartmentsDropdown}")
	private String alldepartmentsDropdownSql;
	
	@Value("${EXPAGInactiveDepartmentsDropdown}")
	private String inactiveDepartmentsDropdownSql;
	
	@Value("${EXPAGFirstActionForTask}")
	private String firstActionForTask;

	@Value("${EXPAGTaskTypeDropdown}")
	private String taskTypeDropdownSql;
	
	@Value("${EXPAGAllTaskTypeDropdown}")
	private String alltaskTypeDropdownSql;
	
	@Value("${EXPAGInactiveTaskTypeDropdown}")
	private String inactiveTaskTypeDropdownSql;

	@Value("${EXPAGCaseWorkerDropdown}")
	private String caseWorkerDropdownSql;

	@Value("${EXPAGDocContentTypeDropdown}")
	private String docContentTypeDropdownSql;

	@Value("${EXPAGNotesTypeDropdown}")
	private String notesTypeDropdownSql;

	@Value("${EXPAGIdentifiersDropdown}")
	private String identifiersDropdownSql;
	
	@Value("${EXPAGCatalogIdentifiers}")
	private String catalogIdentifiersDropdown;

	@Value("${EXPAGTaskTypesForDepartment}")
	private String taskTypesForDepartmentSql;

	@Value("${EXPAGDepartmentsForTaskType}")
	private String departmentsForTaskTypeSql;

	@Value("${EXPAGDepartmentForCaseWorker}")
	private String departmentsForCaseworkerSql;

	@Value("${EXPAGCaseWorkerForDepartment}")
	private String caseWorkerForDepartmentSql;
	
	@Value("${EXPAG_QM_ASSIGNED_UNASSIGNED_METRICS}")
	private String deptQMAssignedUnassignedMetricsSql;	
	
	@Value("${EXPAG_QM_SUSPENDED_METRICS}")
	private String deptQMSuspendedMetricsSql;	
	
	@Value("${EXPAG_MYWORKITEMS_METRICS}")
	private String myWorkItemsMetricsSql;

	@Value("${planSponosrRsServiceURL}")
	private String planSponosrRsServiceURL;

	// Other sql's
	@Value("${EXPAGOutboundDocTypes}")
	private String outboundDocTypesSql;

	@Value("${EXPREMAININGASLA}")
	private String remainingSlaSql;

	@Value("${EXPAGTASKSTATUS}")
	private String taskStatusSql;

	@Value("${EXPAGDEPARTMENTSUSPENDEDTASKS}")
	private String suspendedDepartmentTasksSql;
	
	@Value("${EXPAGDEPARTMENTUNASSIGNEDTASKS}")
	private String unassignedDepartmentTasksSql;
	
	@Value("${EXPAGDEPARTMENTASSIGNEDNOTSUSPENDEDTASKS}")
	private String assignedNotSuspendedDepartmentTasksSql;
	
	@Value("${EXPAGOPENMYWORKITEMS}")
	private String myOpenWorkItemsSql;
	
	@Value("${EXPAGSUSPENDEDMYWORKITEMS}")
	private String mySuspendedWorkItemsSql;
	
	// @Value("${EXPAGDEPARTMENTMETRICS}")
	private String departmentMetricsSql;	

	@Value("${EXPAGCASEWORKERFORTASK}")
	private String caseworkerforTaskSql;
	
	@Value("${FAILCODESOMNI}")
	private String omniFailCodeSql;
	
	@Value("${EXPAGOMNITRANSTYPE}")
	private String taskOmniTransType;

	@Value("${maxEXPAGWorkItems}")
	private int maxEXPAGWorkItems;
	
	@Value("${filterConvertedTasks}")
	private String filterConvertedExpagTasks;

	@Value("${QCFAILREASONSSQL}")
	private String qcFailReasonsSql;
	
	@Value("${EXPAGTaskActions}")
	private String taskActionsSql;
	
	@Value("${EXPAGOperatorName}")
	private String operatorNameSql;
	
	@Value("${ExpagEntitledCaseWorkers}")
	private String entitledCaseWorkerSql;
	
	@Value("${EXPAGActionStepsForTaskType}")
	private String actionStepsForTaskTypeSql;
	
	@Value("${EXPAGEntitlementOfCaseWorker}")
	private String entitlementOfCaseWorker;
	
	@Value("${ExpagRequiredIdentifiers}")
	private String expagRequiredIdentifiersSql;
	
	@Value("${EXPAGFirstActionStepForTaskType}")
	private String expagFirstActionStepForTaskTypeSql;	

	@Value("${EXPAGHelpVariables}")
	private String expagHelpVariablessql;

	@Value("${EXPAGHelpVariablesSpecific}")
	private String expagHelpVariablesSpecificsql;

	@Value("${EXPAGHelpMessages}")
	private String expagHelpMessagessql;

	@Value("${EXPAGHelpMessageCodes}")
	private String expagHelpMessagesCodessql;
	
	@Value("${EXPAGGetInstitutionNames}")
	private String getInstitutionNamesSql;
	
	@Value("${EXPAGGetPlanInfoForInstitutionName}")
	private String getPlanInfoForInstitutionName;
	
	@Value("${ExpagEntitledTaskTypes}")
	private String expagEntitledTaskTypesSql;
	
	@Value("${ExpagCorresTemplates}")
	private String getExpagCorresTemplatesSql;
	
	@Value("${ExpagCorresTemplateAndParagraphs}")
	private String getExpagCorresTemplateAndParagraphsSql;
	
	@Value("${ExpagCorresParagraphName}")
	private String getExpagCorresParagraphSql;
	
	@Value("${ExpagCorrSavedInfo}")
	private String expagCorrSavedInfoSql;
	
	@Value("${EXPAGCorrspondenceDocInfo}")
	private String expagCorrDocInfoSql;
	
	
	@Value("${EXPAGInsertCorro}")
	private String expagInsertCorro;
	
	
	@Value("${EXPAGCorrDocDtl}")
	private String expagCorrDocDtl;
	
	@Value("${EXPAGInsertPara}")
	private String expagInsertPara;
	
	@Value("${ExpagFirstActionStepWithIntegrationForTaskType}")
	private String expagFirstActionStepWithIntegrationForTaskTypeSql;
	
	@Value("${ExpagRoutingRulesForTask}")
	private String expagRoutingRulesForTask;
	
	@Value("${EXPAGTaskHistory}")	
	private String expagTaskHistorySql;	
	
	@Value("${EXPAGEvalRuleReqStatus}")	
	private String expagEvalRuleReqStatus;	
	
	@Value("${EXPAGUpdateTaskHistory}")	
	private String expagUpdateTskHist;
	
	@Value("${EXPAGInsertTskHistEditDefault}")	
	private String insertTskHistEditDefault;

	@Value("${EXPAGDocCreateDate}")	
	private String expagDocCreateDateSql;
	
	@Value("${EXPAGUpdateLastAccessDate}")	
	private String expagUpdateLastAccessDate;
	
	@Value("${EXPAGUpdateContentCode}")	
	private String expagUpdateContentCode;
	
	@Value("${EXPAGSelectContentTypeInfo}")	
	private String selectContentTypeInfo;
	
	@Value("${EXPAGSelectDocInfo}")	
	private String selectDocInfo;
	
	@Value("${EXPAGInsertDocContent}")	
	private String insertDocCnt;
	
	@Value("${ExpagMethodOfCommunicationSql}")
	private String getExpagMethodOfCommunicationSql;
	
	@Value("${EXPAGLocationAndMailDropTimesForOperator}")	
	private String expagLocationAndMailDropTimesForOperator;
	
	@Value("${EXPAGNextSequenceNumberForBatchNo}")	
	private String expagNextSequenceNumber;
	
	@Value("${EXPAGInsertBatchInfo}")	
	private String insertBatchInfo;

	@Value("${EXPAGLocationCodeForOperator}")	
	private String expagLocationCodeForOperatorSql;
	
	/*SQL for fetching identifiers value and it's 
	 * corresponding Routing rule flag
	 */
	@Value("${EXPAGTASKIDENTIFIERSVALUE}")
	private String taskIdentifiersValueSql;
	
	@Value("${EXPAGRemoveExcludedOperSQL}")	
	private String removeExcludedOperFromTask;
	
	@Value("${paginationBound}")
	private String paginationBound;
	
	@Value("${EXPAGSuspendedTaskHistory}")
	private String suspendHistoryQuery;
	
	public static final int MAX_COUNT = 999;
	
	@Value("${closedInternalStatuses}")
	private String closedInternalStatuses;
	
	@Value("${EXPAGUpdateIdentifiers}")
	private String updateIdentifiers;
	
	@Value("${EXPAGUpdateRecvdDateTime}")
	private String updateRecvdDateTime;

	@Value("${EXPAGTaskTypeForTaskId}")
	private String expagTaskTypeForTaskIdQuery;
	
	/**
	 * Returns list of caseWorkers/status/create time for given taskId
	 * @param taskId String 
	 * @return List of Event
	 */
	public List<Event> getCaseWorkersonTask(String taskId){
		String sql =null;
		List<Event> eventList = new ArrayList<Event>();
		Object[] args = new Object[]{taskId};

		if(!StringUtils.isBlank(taskId)){
			sql=this.caseworkerforTaskSql;
			EXPAGCaseWorkerTaskMapper caseTaskMapper= new EXPAGCaseWorkerTaskMapper();
			eventList= this.query(sql,caseTaskMapper, args);
			return eventList;
		}
		return eventList;
	}
	
	/**
	 * Method to fetch the timeline history of an EXPAG Task.
	 * @param taskId
	 * @return List of Events
	 */
	public List<Event> getExpagProcessHistory(String taskId){
		String sql =null;
		List<Event> eventList = new ArrayList<Event>();
		Object[] args = new Object[]{taskId,taskId};

		if(!StringUtils.isBlank(taskId)){
			sql=this.expagTaskHistorySql;
			EXPAGTaskHistoryMapper expagTaskHistoryMapper= new EXPAGTaskHistoryMapper();
			eventList= this.query(sql,expagTaskHistoryMapper, args);
			return eventList;
		}
		return eventList;
	}	

	public ConfigItem getConfigItem(String dropDownName) {
		DropdownResultMapper dropDownMapper = new DropdownResultMapper();

		ConfigItem configItem = new ConfigItem();
		String sql = null;

		Object[] args = new Object[]{};

		if (EXPAG_DEPARTMENTS.equalsIgnoreCase(dropDownName) || DEPARTMENT.equalsIgnoreCase(dropDownName)) {
			sql = this.departmentDropdownSql;
		}	else if (EXPAG_ALL_DEPARTMENTS.equalsIgnoreCase(dropDownName) ) {
				sql = this.alldepartmentsDropdownSql;
		} else if (EXPAG_TASK_TYPES.equalsIgnoreCase(dropDownName) || REQUEST_TYPES.equalsIgnoreCase(dropDownName)) {
			sql = this.taskTypeDropdownSql;
		} else if (EXPAG_ALL_TASK_TYPES.equalsIgnoreCase(dropDownName) ) {
			sql = this.alltaskTypeDropdownSql;
		} else if (EXPAG_INACTIVE_DEPARTMENTS.equalsIgnoreCase(dropDownName) ) {
			sql = this.inactiveDepartmentsDropdownSql;
		} else if (EXPAG_INACTIVE_TASK_TYPES.equalsIgnoreCase(dropDownName) ) {
			sql = this.inactiveTaskTypeDropdownSql;
		} else if (EXPAG_CASE_WORKERS.equalsIgnoreCase(dropDownName)) {
			sql = this.caseWorkerDropdownSql;
		} else if (EXPAG_DOC_CONTENT_TYPES.equalsIgnoreCase(dropDownName)) {
			sql = this.docContentTypeDropdownSql;
		} else if (EXPAG_NOTE_TYPES.equalsIgnoreCase(dropDownName)) {
			sql = this.notesTypeDropdownSql;
		}
		LOGGER.info("Before executing query for dropDownName:"+ dropDownName);
		List<ConfigData> configData = this.query(sql, dropDownMapper, args);
		LOGGER.info("After executing query for dropDownName:"+ dropDownName);
		configItem.setItemName(dropDownName);
		configItem.getDataPairs().addAll(configData);

		return configItem;

	}

	public ConfigItem getConfigItem(String dropDownName, String filterValue) {
		DropdownResultMapper dropDownMapper = new DropdownResultMapper();
		Boolean useQueryForObject = Boolean.FALSE;

		ConfigItem configItem = new ConfigItem();
		String sql = null;

		Object[] args = new Object[]{filterValue};

		if (EXPAG_TASK_TYPES_FOR_DEPARTMENT.equalsIgnoreCase(dropDownName)) {
			sql = this.taskTypesForDepartmentSql;
		} else if (EXPAG_DEPARTMENTS_FOR_TASK_TYPE.equalsIgnoreCase(dropDownName)) {
			sql = this.departmentsForTaskTypeSql;
		} else if (EXPAG_CASE_WORKER_FOR_DEPARTMENT.equalsIgnoreCase(dropDownName)) {
			sql = this.caseWorkerForDepartmentSql;
		} else if (EXPAG_DEPARTMENTS_FOR_CASEWORKER.equalsIgnoreCase(dropDownName)
				|| ENTITLED_DEPARTMENTS.equalsIgnoreCase(dropDownName)) {
			sql = this.departmentsForCaseworkerSql;
		} else if (EXPAG_ACTIONSTEPS_FOR_TASK_TYPE.equalsIgnoreCase(dropDownName)) {
			sql = this.actionStepsForTaskTypeSql;
		} else if (EXPAG_FIRSTACTIONSTEP_FOR_TASK_TYPE.equalsIgnoreCase(dropDownName)) {
			sql = this.expagFirstActionStepForTaskTypeSql;
			//sql = this.firstActionForTask;
			useQueryForObject = Boolean.TRUE;
		} else if (EXPAG_FIRSTACTIONSTEP_INTEGRATION_FOR_TASK_TYPE.equalsIgnoreCase(dropDownName)) {
			sql = this.expagFirstActionStepWithIntegrationForTaskTypeSql;
			useQueryForObject = Boolean.TRUE;
		} 
		
		List<ConfigData> queryResult = this.query(sql, dropDownMapper, args);
		
		if(useQueryForObject){
			configItem.setItemName(dropDownName.concat(SPACE_HYPEN_SAPCE).concat(filterValue));
		} else if (ENTITLED_DEPARTMENTS.equalsIgnoreCase(dropDownName)){
			if(queryResult.size() > 0){
				configItem.setItemName(APP_EXPAG);
			}
		} else {
			configItem.setItemName(dropDownName);			
		}
		
		configItem.getDataPairs().addAll(queryResult);
		return configItem;
	}

	/*public Metrics getMetrics(List<String> departments) {
		MetricsResultMapper metricsResultMapper = new MetricsResultMapper();

		Metrics metrics = new Metrics();
		Object[] args = new Object[]{departments};
		String sql = this.departmentMetricsSql;

		List<Metric> metricsData = this.query(sql, metricsResultMapper, args);
		metrics.getMetrics().addAll(metricsData);

		return metrics;
	}*/
	
	public Metrics getMetrics(String department, String userId) {
		MetricsResultMapper metricsResultMapper = new MetricsResultMapper();

		Metrics metrics = new Metrics();
		List<Metric> metricsData = null;
		String sql = null;
		if(department != null){
			Object[] args = new Object[]{StringUtils.rightPad(department,10), StringUtils.rightPad(userId, 8)};
			
			sql = this.deptQMAssignedUnassignedMetricsSql;
			metricsData = this.query(sql, metricsResultMapper, args);
			 
			sql = this.deptQMSuspendedMetricsSql;
			metricsData.addAll(this.query(sql, metricsResultMapper, args));
		}else{
			Object[] args = new Object[]{StringUtils.rightPad(userId, 8), StringUtils.rightPad(userId, 8), StringUtils.rightPad(userId, 8)};
			
			sql = this.myWorkItemsMetricsSql;
			metricsData = this.query(sql, metricsResultMapper, args);
			
		}
		
		//to populate SUSPENDED with SUSPENDED+AWAKETODAY
		populateSuspended(metricsData);
		
		metrics.getMetrics().addAll(metricsData);
		
		return metrics;
	}

	private void populateSuspended(List<Metric> metricsData) {
		int suspIndex = -1;
		int awakeTodayCount = -1;
		//loop through all metrics and find the index of suspended metric.
		// also find the awaketoday count
		for(int i = 0; i<metricsData.size(); i++){
			Metric metric = metricsData.get(i);
			if(metric.getFieldName() != null){
				if(CaseManagementConstants.TASK_STATUS_SUSPENDED.equalsIgnoreCase(metric.getFieldName())){
					suspIndex = i;
				} else if(CaseManagementConstants.AWAKETODAY.equalsIgnoreCase(metric.getFieldName())){
					if(metric.getFieldValue() != null){
						awakeTodayCount = Integer.parseInt(metric.getFieldValue());
					}
				}
		}
		}
			
			//if suspended is found in the list create new
			//add awakeTodayCount to suspended
			Metric suspMetric = new Metric();
			if(suspIndex == -1){
				suspMetric.setFieldName(TASK_STATUS_SUSPENDED);
				suspMetric.setFieldValue("0");
				metricsData.add(suspMetric);
				suspIndex = metricsData.size();
			} else {
				suspMetric = metricsData.get(suspIndex);
			}
			if(suspMetric.getFieldValue() != null && awakeTodayCount > 0){
				suspMetric.setFieldValue(String.valueOf(Integer.parseInt(suspMetric.getFieldValue()) + awakeTodayCount));
				}
				
			//if suspended is found and awakeToday not found in the list, it implies AwakeToday is 0
		/*	if(awakeTodayCount < 0 && suspIndex >= 0){
				Metric awakeTodayMetric = new Metric();
				
				awakeTodayMetric.setFieldName(CaseManagementConstants.AWAKETODAY);
				awakeTodayMetric.setFieldValue("0");
				metricsData.add(awakeTodayMetric);
				}*/
			
	}


	public List<String> getOutboundDocumentTypes() {
		OutboundDocTypesMapper docTypeMapper = new OutboundDocTypesMapper();
		String sql = this.outboundDocTypesSql;
		Object[] args = new Object[]{};
		List<String> docTypeList = this.query(sql, docTypeMapper, args);

		return docTypeList;
	}

	public ConfigItem getConfigItemWithSubfields(String dropDownName) {
		DropdownWithSubfieldsResultMapper dropDownMapper = new DropdownWithSubfieldsResultMapper();

		ConfigItem configItem = new ConfigItem();
		String sql = null;
		Object[] args = new Object[]{};

		if (IDENTIFIERS.equalsIgnoreCase(dropDownName) || EXPAG_IDENTIFIERS.equalsIgnoreCase(dropDownName)) {
			sql = this.identifiersDropdownSql;
		}

		List<ConfigData> configData = this.query(sql, dropDownMapper, args);
		configItem.setItemName(dropDownName);
		configItem.getDataPairs().addAll(configData);

		return configItem;
	}
	
	public ConfigItem getOmniTransTypeConfig(String taskType, String actionType){

		ConfigItem configItem = new ConfigItem();
		List<String> omniTransTypeList = executeOmniTranTypeQuery(taskType,actionType);
		
		if(omniTransTypeList != null && omniTransTypeList.size() > 0){
			configItem.setItemName(OMNI_TRANS_TYPE);
			ConfigData cd = new ConfigData();
			cd.setLongDescription(omniTransTypeList.get(0));
			cd.setShortDescription(omniTransTypeList.get(0));
			configItem.getDataPairs().add(cd);
		}	
		
		return configItem;
	}
	
	public ConfigItem getCatalogConfigItemValues(int idcode, int fldNumber) {
		CatalogFieldResultMapper dropDownMapper = new CatalogFieldResultMapper();

		ConfigItem configItem = new ConfigItem();
		String sql = null;
		
		String fieldNumber = (new Integer(fldNumber)).toString();

		Object[] args = new Object[]{idcode, fldNumber};
		sql = this.catalogIdentifiersDropdown;		

		List<ConfigData> configData = this.query(sql, dropDownMapper, args);
		
		if(configData != null && configData.size() > 0){
			ConfigData cd = configData.get(0);			
			configItem.setItemName(cd.getLongDescription());
		}		
		configItem.getDataPairs().addAll(configData);

		return configItem;

	}
	
	/**
	 * Get the ExpAG Task Status History for Suspend/ Unsuspend
	 * @param taskIdSet
	 * @return
	 */
	public List<ExpagStatusHistory> getExpagWorkItemSuspendedHistory(Set<String> taskIdSet) {
		if (taskIdSet == null || taskIdSet.size() == 0) {
			return Collections.emptyList();
		}
		String taskIds = taskIdSet.toString();		
		taskIds = taskIds.replaceAll("\\s", "");		
		//replace the leading and trailing [, ]
		taskIds = new StringBuilder(taskIds).deleteCharAt(taskIds.length() - 1).deleteCharAt(0).toString();
		Object[] args = taskIds.split(",");
		String sqlQuery = this.buildSuspendHistoryQuery(taskIdSet);
		
		List<ExpagStatusHistory> rows = new ArrayList<ExpagStatusHistory>();
		try {
			rows = this.expagJdbcTemplate.query(sqlQuery, args, new ExpagStatusHistoryRowMapper());
		} catch (DataAccessException ex) {
			LOGGER.error("Exception while calculation SLA", ex);
		}
		return rows;
	}
	
	/**
	 * Build the query condition dynamically
	 * since the list of taskId may exceed 1000 while search
	 * eg., where ( s.tskid in (..) or s.tskid in (...) ...)
	 * @param taskIdSet
	 * @return
	 */
	private String buildSuspendHistoryQuery(Set<String> taskIdSet) {
		final String QUERY_TSK_ID = "s.tskid in (*) or ";
		String queryParams = "?,";
		int taskIdSize = taskIdSet.size();
		int loop = taskIdSize / MAX_COUNT + 1;		
		String tskConditionQuery = "";
		for (int i = 1; i <= loop; i++) {
			int queryParamSize = taskIdSize - (MAX_COUNT * i);
			if (queryParamSize >= 0) {
				queryParamSize = MAX_COUNT;
			} else if (queryParamSize < 0 && loop == 1) {
				queryParamSize = taskIdSize;
			} else {
				queryParamSize = taskIdSize - (MAX_COUNT * (i - 1));
			}
			if (queryParamSize > 0) {
				queryParams = StringUtils.repeat("?,", queryParamSize);
				//replace the training ,
				queryParams = new StringBuilder(queryParams).deleteCharAt(queryParams.length() - 1).toString();
				tskConditionQuery = tskConditionQuery + QUERY_TSK_ID.replace("*", queryParams);
			}
		}
		//remove the final or
		tskConditionQuery = new StringBuilder(tskConditionQuery).delete(tskConditionQuery.lastIndexOf("or"), tskConditionQuery.length()).toString();
		String finalSqlQuery = this.suspendHistoryQuery.replace("[]", tskConditionQuery);
		return finalSqlQuery;
	}
	
	private String applyExpAgFilterOnQuery(String sql) {
		final String QUERY_JOIN_TSK_Type = "JOIN PIMITEK.CMF_NXTGEN_DELEGATE_PROCESS cnp on Trim(Lower(cnp.PROCESS_NAME)) = Trim(Lower(tt.tskdesc)) and cnp.source_system = 'EXPAG'";
		String finalSqlQuery = sql;
		if (YES.equalsIgnoreCase(filterConvertedExpagTasks)) {
			finalSqlQuery = sql.replace("[]", QUERY_JOIN_TSK_Type);
		} else {
			finalSqlQuery = sql.replace("[]", "");
		}
		return finalSqlQuery;
	}
	
	public List<ExpagWorkItem> getExpagDepartmentWorkItems(String userId, String type, String department, int start) {
		List<ExpagWorkItem> expagWorkItems = new ArrayList<ExpagWorkItem>();
		
		Object[] args = null;
		String sql = null;
		
		if ("Unassigned".equalsIgnoreCase(type)) {
			args = new Object[] {StringUtils.rightPad(department, 10), userId, start,paginationBound};
			sql = applyExpAgFilterOnQuery(this.unassignedDepartmentTasksSql);
			expagWorkItems = this.query(sql, new ExapgOpenTasksMapper(), args);
		} else if ("Suspended".equalsIgnoreCase(type)) {
			args = new Object[] {StringUtils.rightPad(department, 10), userId, start,paginationBound};
			sql = applyExpAgFilterOnQuery(this.suspendedDepartmentTasksSql);
			expagWorkItems = this.query(sql, new ExapgSuspendTasksMapper(), args);
		} else if ("Assigned".equalsIgnoreCase(type)) {
			args = new Object[] {StringUtils.rightPad(department, 10), userId, start,paginationBound};
			sql = applyExpAgFilterOnQuery(this.assignedNotSuspendedDepartmentTasksSql);
			expagWorkItems = this.query(sql, new ExapgOpenTasksMapper(), args);
		} else if ("MyWorkItems".equalsIgnoreCase(type)) {
			args = new Object[] {userId, start,paginationBound};
			sql = applyExpAgFilterOnQuery(this.myOpenWorkItemsSql);
			List<ExpagWorkItem> expagOpenWorkItems = this.query(sql, new ExapgOpenTasksMapper(), args);
			args = new Object[] {userId, start,paginationBound};
			sql = applyExpAgFilterOnQuery(this.mySuspendedWorkItemsSql);
			List<ExpagWorkItem> expagSuspendedWorkItems = this.query(sql, new ExapgSuspendTasksMapper(), args);
			if (expagOpenWorkItems != null) {
				expagWorkItems.addAll(expagOpenWorkItems);
			}
			if (expagSuspendedWorkItems != null) {
				expagWorkItems.addAll(expagSuspendedWorkItems);
			}			
		}
		return expagWorkItems;
	}
	

	//TODO : create one more overloaded method which would return object
	protected <T> List<T> query(String sql, RowMapper<T> rowMapper, Object[] args) {
		try {
			List<T> rows = this.expagJdbcTemplate.query(sql, args, rowMapper);
			LOGGER.debug("rows:{}", rows.size());
			return rows;
		} catch (DataAccessException e) {
			LOGGER.warn("sql:{}", sql);
			LOGGER.warn(e.getMessage(), e);
             if (args != null && args.length > 0) {
				for (Object object : args) {
					LOGGER.warn("arg:{}", object);
				}
             }
			LOGGER.warn(e.getMessage(), e);
		}
		return Collections.emptyList();
	}

	protected void debugSQL(String sql) {
		if (this.debugSql) {
			LOGGER.debug("sql: {}", sql);
		}
	}

	public List<SLAInfo> getSLAInfoList(String taskid) {
		List<SLAInfo> slaInfoList = null;

		SLAInfoMapper slaInfoMapper = new SLAInfoMapper();
		Object[] args = new Object[]{taskid};

		slaInfoList = query(this.remainingSlaSql, slaInfoMapper, args);

		return slaInfoList;
	}

	public String getCompletedTaskSubStatus(String taskId) {
		String expagTaskStatus = null;

		Object[] args = new Object[]{taskId};
		TaskStatusMapper taskStatusMapper = new TaskStatusMapper();

		List<String> taskStatusList = query(this.taskStatusSql, taskStatusMapper, args);

		if ((taskStatusList.size() > 0) && (taskStatusList.get(0) != "")) {
			expagTaskStatus = taskStatusList.get(0);
		}

		return expagTaskStatus;
	}

	/*
	 * This method calls the search stored procedure in the EXP AG database
	 * directly.
	 */
	public Processes getSearchResults(SearchItemsVO searchItemsVO) throws SQLException {

		boolean limitSearch = false;
		String[] closedStatuses = closedInternalStatuses.split(",");
		
		Processes processes = new Processes();
		searchItemsVO.getBeginDate().set(Calendar.HOUR_OF_DAY, 0);
		searchItemsVO.getBeginDate().set(Calendar.MINUTE, 0);
		searchItemsVO.getBeginDate().set(Calendar.SECOND, 0);

		searchItemsVO.getEndDate().set(Calendar.HOUR_OF_DAY, 23);
		searchItemsVO.getEndDate().set(Calendar.MINUTE, 59);
		searchItemsVO.getEndDate().set(Calendar.SECOND, 59);

		Connection con = null;
		CallableStatement call = null;
		ResultSet rs = null;
		try {
			con = this.expagJdbcTemplate.getDataSource().getConnection();

			call = con.prepareCall("BEGIN PIMITEK.tiaa_full_search_v18_3(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?); END;");

			call.setDate(1, new java.sql.Date(searchItemsVO.getBeginDate().getTime().getTime()));

			call.setDate(2, new java.sql.Date(searchItemsVO.getEndDate().getTime().getTime()));

			call.setString(3, searchItemsVO.getTaskstatus());// TaskStatus length 1


			if(StringUtils.isNotBlank(searchItemsVO.getIddesc1())){
				if(PLAN.equalsIgnoreCase(searchItemsVO.getIddesc1())){
					limitSearch = true;
				}
				call.setString(4, StringUtils.substring(searchItemsVO.getIddesc1().toUpperCase(), 0, 15));// iddesc1 length 15
			}else {
				call.setString(4, searchItemsVO.getIddesc1());// iddesc1
			}
			call.setString(5, searchItemsVO.getField11());// fieldvalue11
			call.setString(6, searchItemsVO.getField12());// fieldvalue12
			call.setString(7, searchItemsVO.getField13());// fieldvalue13
			call.setString(8, searchItemsVO.getField14());// fieldvalue14
			call.setString(9, StringUtils.substring(searchItemsVO.getDeptdesc(),0,10));// deptdesc length 10

			String taskType = StringUtils.substring(searchItemsVO.getTasktype(),0,10);

			call.setString(10, taskType);// tskdesc length 10
			call.setString(11, searchItemsVO.getActdesc());// actdesc length 11
			if(searchItemsVO.getTaskid() != null){
				call.setString(12, StringUtils.substring(searchItemsVO.getTaskid().toLowerCase(),0,11));// taskid length 11
			}else{
				call.setString(12, StringUtils.substring(searchItemsVO.getTaskid(),0,11));// taskid length 11
			}
			call.setString(13, StringUtils.substring(searchItemsVO.getWorkbasket(),0,8));// workbasket length 8
			if(StringUtils.isNotBlank(searchItemsVO.getIddesc2())){
				if(PLAN.equalsIgnoreCase(searchItemsVO.getIddesc2())){
					limitSearch = true;
				}
				call.setString(14, StringUtils.substring(searchItemsVO.getIddesc2().toUpperCase(),0,15));// iddesc2 length 15
			}else{
				call.setString(14, searchItemsVO.getIddesc2());// iddesc2
			}
			call.setString(15, searchItemsVO.getField21());// fieldvalue21
			call.setString(16, searchItemsVO.getField22());// fieldvalue22
			call.setString(17, searchItemsVO.getField23());// fieldvalue23
			call.setString(18, searchItemsVO.getField24());// fieldvalue24
			if(StringUtils.isNotBlank(searchItemsVO.getIddesc3())){
				if(PLAN.equalsIgnoreCase(searchItemsVO.getIddesc3())){
					limitSearch = true;
				}
				call.setString(19, StringUtils.substring(searchItemsVO.getIddesc3().toUpperCase(),0,15));// iddesc3 length 15
			}else{
				call.setString(19, searchItemsVO.getIddesc3());// iddesc3
			}
			call.setString(20, searchItemsVO.getField31());// fieldvalue31
			call.setString(21, searchItemsVO.getField32());// fieldvalue32
			call.setString(22, searchItemsVO.getField33());// fieldvalue33
			call.setString(23, searchItemsVO.getField34());// fieldvalue34
			call.setString(24, StringUtils.substring(searchItemsVO.getUserId(),0,8));// operid
			call.setString(25, "N");// RuleBasedEngine
			if(limitSearch){
				call.setInt(26, 150);// searchmaxrowcount
			}else{
				call.setInt(26, 10000);// searchmaxrowcount
			}
			int createDateFlag = 0;
			if (!searchItemsVO.isUsecreatedate()) {
				createDateFlag = 1;
			}
			call.setInt(27, createDateFlag);// dateCode

			String orderby = null;
			//defaulting to descending
			String desc = "T";

			//getting sort criteria and sort field
			if(searchItemsVO.getSortCriteria() != null && !searchItemsVO.getSortCriteria().isEmpty() && searchItemsVO.getSortCriteria().get(0)!=null){
				orderby = searchItemsVO.getSortCriteria().get(0).getCriteriaName();
				if(!searchItemsVO.getSortCriteria().get(0).isDesc()){
					desc = "F";
				}
			}

			call.setString(28, orderby);//orderby
			call.setString(29, desc);//desc
			call.setInt(30, 0);// retCode
			call.registerOutParameter(31, oracle.jdbc.OracleTypes.NUMBER);// totalcount
			call.registerOutParameter(32, oracle.jdbc.OracleTypes.CURSOR);// search_recordset

			long tStart = System.currentTimeMillis();

			call.execute();
			int resultcount = (int) call.getInt(31);
			rs = (ResultSet) call.getObject(32);
			searchItemsVO.setresult(resultcount + searchItemsVO.getresult());
			if (rs != null) {


				while (rs.next()) {
					
					if(searchItemsVO.isClosedStatus()) {
						if(rs.getString("completedsts") != null) {
							String taskCompletedStatus = rs.getString("completedsts");
							if(!Arrays.asList(closedStatuses).contains(taskCompletedStatus)) {
								continue;
							}
						}
					} else if (searchItemsVO.isCompletedStatus()){
						if(rs.getString("completedsts") != null) {
							String taskCompletedStatus = rs.getString("completedsts");
							if(Arrays.asList(closedStatuses).contains(taskCompletedStatus)) {
								continue;
							}
						}
					}
					
					Properties properties = new Properties();

					if (rs.getString("npin") != null) {
						NameValue nameValue = new NameValue();
						nameValue = createNameValue("NPIN", "NPIN", StringUtils.trim(rs.getString("npin")), null, null, null, null, null, null);	
						properties.getProperties().add(nameValue);
					}
					Process process = new Process();
					Task task = new Task();
					Tasks tasks = new Tasks();

					org.tiaa.esb.case_management_rs_v2.type.List actionList = new org.tiaa.esb.case_management_rs_v2.type.List();
					String actionStep = rs.getString("actionstep");
					if(actionStep != null) {
						actionList.getItems().add(actionStep.trim());
						task.setAction(actionList);
						task.setActionStep(actionStep.trim());
					}

					String assignedTo = StringUtils.trim(rs.getString("assignedto"));

					if(assignedTo != null && StringUtils.isNumeric(assignedTo))
					{
						task.setAssignedTo("");
					}
					else
					{
						task.setAssignedTo(assignedTo);
					}

					String createTimeStr = String.format("%08d", rs.getInt("createtime"));

					createTimeStr = createTimeStr.substring(0, createTimeStr.length() - 2);


					SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd HHmmss");
					DateTime createDate = new DateTime(dateFormat.parse(new Integer(rs.getInt("createdate")).toString() + " " + createTimeStr));


					XMLGregorianCalendar createXmlDate = DateUtil.toXMLGregorianCalendarDateOnly(createDate.toDate());
					XMLGregorianCalendar createXmlTime = DateUtil.toXMLGregorianCalendarTimeOnly(createDate.toDate());

					task.setCreateDate(createXmlDate);
					task.setCreateTime(createXmlTime);

					String lastmodifiedTimeStr = null;
					if(!StringUtils.isEmpty(rs.getString("lastmodifiedtime"))){
						lastmodifiedTimeStr = String.format("%08d", new Integer(rs.getString("lastmodifiedtime")).intValue());
					}else{
						lastmodifiedTimeStr = "00000000";
					}

					lastmodifiedTimeStr = lastmodifiedTimeStr.substring(0, lastmodifiedTimeStr.length() - 2);

					DateTime lastUpdated = new DateTime(dateFormat.parse(new Integer(rs.getString("lastmodified")) + " " + lastmodifiedTimeStr));


					XMLGregorianCalendar lastXmlDate = DateUtil.toXMLGregorianCalendarDateOnly(lastUpdated.toDate());
					XMLGregorianCalendar lastXmlTime = DateUtil.toXMLGregorianCalendarTimeOnly(lastUpdated.toDate());

					task.setLastUpdatedDate(lastXmlDate);
					task.setLastUpdatedTime(lastXmlTime);


					String wakeTimeStr = null;
					if(!StringUtils.isEmpty(rs.getString("waketime"))){
						wakeTimeStr = String.format("%08d", new Integer(rs.getString("waketime")).intValue());
					}else{
						wakeTimeStr = "00000000";
					}
					
					/*
					 * Code for the excoper identifier:
					if(!StringUtils.isEmpty(rs.getString("excoper"))){
						NameValue nameValue = new NameValue();
						nameValue = createNameValue("EXCOPER", "EXCOPER", StringUtils.trim(rs.getString("excoper")), null, null, null, null, null, null);
						properties.getProperties().add(nameValue);
					}
					*/
					wakeTimeStr = wakeTimeStr.substring(0, wakeTimeStr.length() - 2);

					if(!StringUtils.isEmpty(rs.getString("wakedate"))){
						DateTime wakeDate = new DateTime(dateFormat.parse(new Integer(rs.getString("wakedate")) + " " + wakeTimeStr));


						XMLGregorianCalendar wakeXmlDate = DateUtil.toXMLGregorianCalendarDateOnly(wakeDate.toDate());
						XMLGregorianCalendar wakeXmlTime = DateUtil.toXMLGregorianCalendarTimeOnly(wakeDate.toDate());

						task.setAwakeDate(wakeXmlDate);
						task.setAwakeTime(wakeXmlTime);

					}

					if (rs.getString("channel") != null) {
						NameValue nameValue = new NameValue();
						nameValue = createNameValue("CHANNEL", "CHANNEL", StringUtils.trim(rs.getString("channel")), null, null, null, null, null, null);
						properties.getProperties().add(nameValue);

					}

					if (rs.getString("clientid") != null) {
						NameValue nameValue = new NameValue();
						nameValue = createNameValue("CLIENT ID", "CLIENT ID", StringUtils.trim(rs.getString("clientid")), null, null, null, null, null, null);
						properties.getProperties().add(nameValue);						
					}

					if (rs.getString("planid") != null) {
						NameValue nameValue = new NameValue();
						nameValue = createNameValue("PLAN", "PLAN", StringUtils.trim(rs.getString("planid")), null, null, null, null, null, null);
						properties.getProperties().add(nameValue);
					}

					if (rs.getString("planname") != null) {
						NameValue nameValue = new NameValue();
						nameValue = createNameValue("PLAN NAME", "PLAN NAME", StringUtils.trim(rs.getString("planname")), null, null, null, null, null, null);	
						properties.getProperties().add(nameValue);
					}

					if (rs.getString("pin") != null) {
						NameValue nameValue = new NameValue();
						nameValue = createNameValue("PIN", "PIN", StringUtils.trim(rs.getString("pin")), null, null, null, null, null, null);	
						properties.getProperties().add(nameValue);
					}
					
					
					task.setDepartment(StringUtils.trim(rs.getString("department")));
					task.setID(StringUtils.trim(rs.getString("TSKID")));

					String dbStatus = StringUtils.trim(rs.getString("PITABLE"));

					Statuses statuses = new Statuses();
					Status status = new Status();
					String cmsTaskStatus = "Open";

					if ("open".equalsIgnoreCase(dbStatus)) {
						cmsTaskStatus = "Open";
					} else if ("suspend".equalsIgnoreCase(dbStatus)) {
						cmsTaskStatus = "Suspended";
					} else if ("complete".equalsIgnoreCase(dbStatus)) {
						
						String taskCompletedStatus = rs.getString("completedsts");
						
						if(Arrays.asList(closedStatuses).contains(taskCompletedStatus)) {
							cmsTaskStatus = "Closed";
						}else{
							cmsTaskStatus = "Completed";
						}
						
					} else if ("EVAL QUEUE".equalsIgnoreCase(dbStatus)){
						cmsTaskStatus = "Eval Queue";
					} else if ("AWAIT EVAL".equalsIgnoreCase(dbStatus)){
						cmsTaskStatus = "Await Eval";
					}

					status.setSts(cmsTaskStatus);
					statuses.getSts().add(status);
					task.setStatusHistory(statuses);


					String recvdTimeStr = String.format("%08d", rs.getInt("timercvd"));

					recvdTimeStr = recvdTimeStr.substring(0, recvdTimeStr.length() - 2);

					DateTime receivedDate = new DateTime(dateFormat.parse(new Integer(rs.getInt("datercvd")).toString() + " " + recvdTimeStr));




					XMLGregorianCalendar receivedXmlDate = DateUtil.toXMLGregorianCalendarDateOnly(receivedDate.toDate());
					XMLGregorianCalendar receivedXmlTime = DateUtil.toXMLGregorianCalendarTimeOnly(receivedDate.toDate());

					task.setReceivedDate(receivedXmlDate);
					task.setReceivedTime(receivedXmlTime);

					task.setType(StringUtils.trim(rs.getString("tasktype")));
					task.setTaskProperties(properties);

					tasks.getTasks().add(task);
					process.setTasks(tasks);
					
					//This is a temporary measure- we're setting the caseid in the processid field,
					//this will likely be altered in the future
					if (StringUtils.isNotBlank(rs.getString("pktid"))) {
						process.setProcessId(rs.getString("pktid"));
					}
					
					process.setAppName("EXPAG");
					processes.getProcesses().add(process);

				}

			} else {
				return processes;
			}

			long tEnd = System.currentTimeMillis();
			long tDelta = tEnd - tStart;
			double elapsedSeconds = tDelta / 1000.0;

			LOGGER.debug("Search took " + elapsedSeconds + " seconds.");

		} catch (SQLException e) {
			LOGGER.error("Exception in sqlPackageSearch " + e.getMessage());
			throw e;
		} catch (ParseException pe) {
			LOGGER.error("Exception in sqlPackageSearch " + pe.getMessage());
			throw new SQLException(pe);
		} finally {
			if (call != null) {
				call.close();
			}
			if (con != null) {
				con.close();
			}
			if (rs != null) {
				rs.close();
			}
		}

		return processes;
	}

//	private Identifier createIdentifier(String iddesc, String fieldName1, String field1, String fieldName2, String field2, String fieldName3, String field3, String fieldName4, String field4) {
//		Identifier identifier = new Identifier();
//		identifier.setDesc(iddesc);
//
//		SubFields subFields = new SubFields();
//		SubField subField1 = new SubField();
//		SubField subField2 = new SubField();
//		SubField subField3 = new SubField();
//		SubField subField4 = new SubField();
//
//		if (fieldName1 != null) {
//			subField1.setFieldName(fieldName1);
//			subField1.setFieldValue(field1);
//			subField1.setFieldNumber(new Integer(1));
//			subFields.getSubFields().add(subField1);
//		}
//		if (fieldName2 != null) {
//			subField2.setFieldName(fieldName2);
//			subField2.setFieldValue(field2);
//			subField2.setFieldNumber(new Integer(2));
//			subFields.getSubFields().add(subField2);
//		}
//		if (fieldName3 != null) {
//			subField3.setFieldName(fieldName3);
//			subField3.setFieldValue(field3);
//			subField3.setFieldNumber(new Integer(3));
//			subFields.getSubFields().add(subField3);
//		}
//		if (fieldName4 != null) {
//			subField4.setFieldName(fieldName4);
//			subField4.setFieldValue(field4);
//			subField4.setFieldNumber(new Integer(4));
//			subFields.getSubFields().add(subField4);
//		}
//
//		identifier.setSubFields(subFields);
//
//		return identifier;
//	}
	
	private NameValue createNameValue(String iddesc, String fieldName1, String field1, String fieldName2, String field2, String fieldName3, String field3, String fieldName4, String field4) {
		NameValue nameValue = new NameValue();
		nameValue.setDesc(iddesc);

		NameValue childNameValue1 = new NameValue();
		NameValue childNameValue2 = new NameValue();
		NameValue childNameValue3 = new NameValue();
		NameValue childNameValue4 = new NameValue();

		if (fieldName1 != null) {
			childNameValue1.setName(fieldName1);
			childNameValue1.setValue(field1);
			childNameValue1.setDsplSqncNbr(BigInteger.ONE);
			nameValue.getChildrenNameValues().add(childNameValue1);
		}
		if (fieldName2 != null) {
			childNameValue2.setName(fieldName2);
			childNameValue2.setValue(field2);
			childNameValue2.setDsplSqncNbr(BigInteger.valueOf(2));
			nameValue.getChildrenNameValues().add(childNameValue2);
		}
		if (fieldName3 != null) {
			childNameValue3.setName(fieldName3);
			childNameValue3.setValue(field3);
			childNameValue3.setDsplSqncNbr(BigInteger.valueOf(3));
			nameValue.getChildrenNameValues().add(childNameValue3);
		}
		if (fieldName4 != null) {
			childNameValue4.setName(fieldName4);
			childNameValue4.setValue(field4);
			childNameValue4.setDsplSqncNbr(BigInteger.valueOf(4));
			nameValue.getChildrenNameValues().add(childNameValue4);
		}

		return nameValue;
	}
	
	/**
	 * Return fail codes for are a particular taskType
	 * 
	 * @param taskType
	 *            TaskType for which we need to get Fail Codes
	 * @return ConfigItem containing failCode and Description
	 */
	public ConfigItem getFailCodes(String taskType) {
		OmniFailCodeMapper failCodeMapper = new OmniFailCodeMapper();
		ConfigItem configItem = new ConfigItem();
		String sql = null;

		Object[] args = new Object[] { StringUtils.rightPad(taskType, 10) };

		sql = this.omniFailCodeSql;
		List<ConfigData> configData = this.query(sql, failCodeMapper, args);
		configItem.setItemName(taskType);
		configItem.getDataPairs().addAll(configData);

		return configItem;
	}
	
	/*public  Document getXMLDocMetaDataFromDB(String taskId){
		Object[] args = new Object[] {taskId};
		Document document = new Document();
		try {
				document = this.expagJdbcTemplate.queryForObject(this.selectTaskXMLMetadata,args,new DocumentMetaDataRowMapper());
			    Calendar cal= Calendar.getInstance();
				DateFormat originaFormat=new SimpleDateFormat(DateUtil.DEFAULT_DATE_FORMAT_6);
			    Date crDateTime=new Date();
				try {
					crDateTime=originaFormat.parse(document.getDocDesc());
				} catch (java.text.ParseException e) {
					LOGGER.error("Exception in getXMLDocMetaDataFromDB " + e.getMessage());
				}
				cal.setTime(crDateTime);
				XMLGregorianCalendar createDateTime=DateUtil.toXMLGregorianCalendarDateTime(cal.getTime());
				document.setDocCreateDateTime(createDateTime);
				document.setDocDesc(null);
			} catch(Exception exp) {
				if(exp instanceof EmptyResultDataAccessException){
					LOGGER.warn("There is no XML data for this Request"+exp.getMessage());
				}
			}
		return document;
	}
	
	public Document getXMLDocContentFromDB(String XMLTaskId){
		Object[] args = new Object[]{XMLTaskId};
		Document document = new Document();
		try {
			document = this.expagJdbcTemplate.queryForObject(this.selectTaskXMLContent,args,new DocumentContentXMLRowMapper());
		} catch (Exception e) {
			if(e instanceof EmptyResultDataAccessException) {
				LOGGER.warn("There is no XML data for this Request"+e.getMessage());
			}
		}
		 return document;
	} */

	public String getOmniTransType(String taskType,String actionType) {
		String omniTransType = null;
		
		List<?> omniTransTypeList = executeOmniTranTypeQuery(taskType, actionType);
		if ((omniTransTypeList.size() > 0) && (omniTransTypeList.get(0) != "")) {
			omniTransType = (String)omniTransTypeList.get(0);
		}

		return omniTransType;
	}
	
	private <T> List<T> executeOmniTranTypeQuery(String taskType,
			String actionType) {
		OmniTransTypeResultMapper omniTransTypeMapper = new OmniTransTypeResultMapper();
		Object[] args = new Object[]{taskType,actionType};
		return  (List<T>) this.query(this.taskOmniTransType, omniTransTypeMapper, args);
	}

	/**
	 * This function returns QC fail Reasons
	 * @param taskID
	 * @return
	 */
	public Reasons getQCReasons(String taskId) {
		String sql = null;
		QCReasonsMapper qcReasonMapper = new QCReasonsMapper();
		Reasons reasons = new Reasons();
		
		List<Reason> listOfReason = new ArrayList<Reason>();
		Object[] args = new Object[] { taskId };
		
		sql = this.qcFailReasonsSql;
		listOfReason = this.query(sql, qcReasonMapper, args);	
		
		reasons.getReasons().addAll(listOfReason);
		return reasons;
	}
	
	/**
	 * Return Task Actions of task action step
	 * 
	 * @param actionStep
	 *            
	 * @return List of actions
	 */
	public List<String> getTaskActions(String actionStep) {
		String arg = StringUtils.trim(actionStep);
		
		Object[] args = new Object[]{arg};
		TaskActionMapper taskActionMapper = new TaskActionMapper();

		List<String> actionList = query(this.taskActionsSql, taskActionMapper, args);		

		return actionList;
	}
	
	public String getOperatorName(String operCode) {
		
		Object[] args = new Object[]{operCode};
		OperatorNameMapper operatorNameMapper = new OperatorNameMapper();
		String operatorName = null;

		List<String> operators = query(this.operatorNameSql, operatorNameMapper, args);
		
		if ((operators.size() > 0) && (operators.get(0) != "")) {
			operatorName = operators.get(0);
		}

		return operatorName;
	}
	
	/**
	 * This function return only single value
	 * It should be used when query return 1 row
	 * @param sql
	 * @param rowMapper
	 * @param args
	 * @return T
	 */
	protected  <T> T queryForObject(String sql, RowMapper<T> rowMapper, Object[] args) {
		T resultRow= null;
		try {
			resultRow = this.expagJdbcTemplate.queryForObject(sql, rowMapper, args);
			return resultRow;
		} catch (DataAccessException e) {
			LOGGER.warn("sql:{}", sql);
			LOGGER.warn(e.getMessage(), e);
			if (args != null && args.length > 0) {
				for (Object object : args) {
					LOGGER.warn("arg:{}", object);
				}
			}
			LOGGER.warn(e.getMessage(), e);
		}
		return resultRow;
	}


	public String getFirstActionStepForTask(String taskDesc){
		DropdownResultMapper dropDownMapper = new DropdownResultMapper();
		Object[] args = new Object[]{StringUtils.rightPad(taskDesc, 10)};
		//return this.queryForObject(this.firstActionForTask, new ActionMapper(), args);
		return this.queryForObject(this.expagFirstActionStepForTaskTypeSql, dropDownMapper, args).getLongDescription();
		
	}
	
	/**
	 * Return list of case worker based on department, tasktype and action step
	 * @param property - property name EXPAGCaseWorkerForDepartment
	 * @param dept -  department name
	 * @param taskType -  task type
	 * @param actionStep - action step
	 * @return 	ConfigItem
	 */
	public ConfigItem getEntitledCaseWorkers(String property, String dept, String taskType, String actionStep){
		//re-using existing mapper
		OmniFailCodeMapper failCodeMapper = new OmniFailCodeMapper();

		ConfigItem configItem = new ConfigItem();
		String sql = null;
		if(actionStep==null){
			actionStep = getFirstActionStepForTask(taskType);
		}
		Object[] args = new Object[] { StringUtils.rightPad(dept, 10),StringUtils.rightPad(taskType, 10),StringUtils.rightPad(actionStep, 10)  };

		sql = this.entitledCaseWorkerSql;
		List<ConfigData> configData = this.query(sql, failCodeMapper, args);
		configItem.setItemName(property);
		configItem.getDataPairs().addAll(configData);

		return configItem;
	}
	
	/**
	 * Returns ConfigItem with boolean value if user is entitled to any function category and function description
	 * @param property - property name ExpagUserEntitledToFunction
	 * @param funcCategory -  function category
	 * @param funcDesc -  function description
	 * @param userId - user id
	 * @return 	ConfigItem
	 */
	public ConfigItem getUserEntitlementToFunction(String property, String funcCategory, String funcDesc, String userId){
		ConfigItem configItem = new ConfigItem();
		configItem.setItemName(property);
		ConfigData data = new ConfigData();
		data.setShortDescription(funcCategory);
		data.setLongDescription(funcDesc);
		SubFields fields = new SubFields();
		SubField field = new SubField();
		field.setFieldNumber(1);
		field.setFieldName(CONFIG_ITEM_ENTITLEMENT);		
		field.setFieldValue(isUserEntitledToFunction(funcCategory, funcDesc, userId)?"true":"false");
		field.setFieldType("boolean");
		fields.getSubFields().add(field);
		data.setSubFields(fields);
		configItem.getDataPairs().add(data);
		return configItem;
	}
	
	/**
	 * Returns boolean value if user is entitled to any function category and function description
	 * @param funcCategory -  function category
	 * @param funcDesc -  function description
	 * @param userId - user id
	 * @return 	boolean
	 */
	public boolean isUserEntitledToFunction(String funcCategory, String funcDesc, String userId) {

		if (funcCategory != null && funcDesc != null && userId != null) {
			Object[] args = new Object[] { StringUtils.trim(funcCategory), StringUtils.trim(funcDesc), StringUtils.rightPad(userId, 8) };
			AccessFlagMapper accessFlagMapper = new AccessFlagMapper();

			List<Integer> accessflags = query(this.entitlementOfCaseWorker, accessFlagMapper, args);

			// If user is entitled only for access flag ==2 (i.e. available) then return true else false
			if (accessflags != null && (accessflags.size() > 0)
					&& (accessflags.get(0) == ACCESS_FLAG_AVAILABLE)) {
				return true;
			}
		}

		return false;
	}
	
	public ConfigItem getExpagRequiredIdentifiers(String property, String requestType, String actionStep){

		DropdownWithSubfieldsResultMapper dropDownMapper = new DropdownWithSubfieldsResultMapper();

		ConfigItem configItem = new ConfigItem();
		String sql = null;
		Object[] args =  new Object[] { StringUtils.rightPad(requestType, 10),StringUtils.rightPad(actionStep, 10)  };

		sql = this.expagRequiredIdentifiersSql;

		List<ConfigData> configData = this.query(sql, dropDownMapper, args);
		configItem.setItemName(property.concat(SPACE_HYPEN_SAPCE).concat(requestType).concat(SPACE_HYPEN_SAPCE).concat(actionStep));
		configItem.getDataPairs().addAll(configData);

		return configItem;
	}

	/**
	 * Return Expag help variable data
	 * @param property 
	 * @param parameter - optional
	 * @return ConfigItem
	 */
	public ConfigItem getExpagHelpVariables(String property, String parameter){
		ConfigItem configItem = new ConfigItem();
		EXPAGHelpVariablesMapper helpVariablesMapper = new EXPAGHelpVariablesMapper();
		Object[] args;
		List<ConfigData> configData;
		if(parameter == null){
			args =  new Object[] {};
			configData = this.query(this.expagHelpVariablessql, helpVariablesMapper, args);
		}else{
			args =  new Object[] {parameter};
			configData = this.query(this.expagHelpVariablesSpecificsql, helpVariablesMapper, args);
		}
		configItem.setItemName(property);
		configItem.getDataPairs().addAll(configData);
		return configItem;
	}

	/**
	 * Return Expag Help messages data
	 * @param property
	 * @return ConfigItem
	 */
	public ConfigItem getExpagHelpMessages(String property){
		ConfigItem configItem = new ConfigItem();
		EXPAGHelpVariablesMapper helpMessageMapper = new EXPAGHelpVariablesMapper();
		Object[] args =  new Object[] {};
		List<ConfigData> configData = this.query(this.expagHelpMessagessql, helpMessageMapper, args);			
		configItem.setItemName(property);
		configItem.getDataPairs().addAll(configData);

		return configItem;
	}

	/**
	 * Return Message code based on request type and action step
	 * @param property property name
	 * @param requestType Request Type
	 * @param actionStep Action Step
	 * @return ConfigItem
	 */
	public ConfigItem getExpagHelpMessagesCodes(String property, String requestType, String actionStep){
		ConfigItem configItem = new ConfigItem();
		EXPAGHelpMessageCodeMapper helpMessageCodeMapper = new EXPAGHelpMessageCodeMapper();

		Object[] args =  new Object[] { StringUtils.rightPad(requestType, 10),StringUtils.rightPad(actionStep, 10)};

		List<ConfigData> configData = this.query(this.expagHelpMessagesCodessql, helpMessageCodeMapper, args);

		configItem.setItemName(property);
		configItem.getDataPairs().addAll(configData);		

		return configItem;
	}

	public ConfigItem getExpagInstitutionNames(String property) {
		ConfigItem configItem = new ConfigItem();
		LongDescCDataMapper institutionNameMapper = new LongDescCDataMapper();
		Object[] args = new Object[] {};
		List<ConfigData> configData = this.query(this.getInstitutionNamesSql,
				institutionNameMapper, args);
		configItem.setItemName(property);
		configItem.getDataPairs().addAll(configData);
		return configItem;
	}

	public ConfigItem getExpagPlanInfoInstutionName(String property,
			String institutionName) {

		ConfigItem configItem = new ConfigItem();
		if (institutionName != null && institutionName.length() > 0) {
			PlanInfoMapper planInfoMapper = new PlanInfoMapper();
			Object[] args = new Object[] { institutionName };

			List<ConfigData> configData = this.query(
					this.getPlanInfoForInstitutionName, planInfoMapper, args);
			configItem.getDataPairs().addAll(configData);
		}
		configItem.setItemName(property);
		return configItem;
	}
	
	/**
	 * Get Task type and task description entited to user and department
	 * @param property propery name
	 * @param userId user id
	 * @param department department description
	 * @return ConfigItem
	 */
	public ConfigItem getExpagEntitledTaskTypes(String property, String userId, String department){
		ConfigItem configItem = new ConfigItem();
		OmniFailCodeMapper entitledTaskTypesMapper = new OmniFailCodeMapper();
		
		Object[] args = new Object[] {StringUtils.rightPad(department, 10), StringUtils.rightPad(userId, 8)};
		
		List<ConfigData> configData = this.query(this.expagEntitledTaskTypesSql,
				entitledTaskTypesMapper, args);
		
		configItem.setItemName(property);
		configItem.getDataPairs().addAll(configData);
		
		return configItem;
	}
	
	/** EXPAG Correspondence templates **/
	public ConfigItem getExpagCorresTemplates(String property) {
		ConfigItem configItem = new ConfigItem();
		DropdownResultMapper dropdownResultMapper = new DropdownResultMapper();
		Object[] args = new Object[]{};
			List<ConfigData>  configData =this.query(this.getExpagCorresTemplatesSql, dropdownResultMapper, args);
			configItem.setItemName(property);
			configItem.getDataPairs().addAll(configData);
			LOGGER.debug("configData from getExpagCorresTemplates:"+configData);
			return configItem;
		}
	
	/** EXPAG Correspondence Paragraphs for given template **/
	public ConfigItem getExpagCorresParagraphsForTemplate(String property,String templateName) {
		ConfigItem configItem = new ConfigItem();
		DropdownResultMapper dropdownResultMapper = new DropdownResultMapper();
		Object[] args = new Object[]{ StringUtils.rightPad(templateName, 8) };
			List<ConfigData>  configData =this.query(this.getExpagCorresTemplateAndParagraphsSql, dropdownResultMapper, args);
			configItem.setItemName(property + "~" + templateName);
			configItem.getDataPairs().addAll(configData);
			LOGGER.debug("configData from getExpagCorresParagraphsForTemplate:"+configData);
			return configItem;
		}
	
	/** Code for EXPAG Correspondence Paragraph Long name for given short name **/
	public String getExpagCorresParagraphName(String paragraphShortName) {

		ParagraphNameMapper paragraphNameMapper = new ParagraphNameMapper();
		Object[] args = new Object[]{StringUtils.rightPad(paragraphShortName, 8)};

		String paragraphLongName = this.queryForObject(this.getExpagCorresParagraphSql, paragraphNameMapper, args);
		LOGGER.debug("getExpagCorresParagraph FullName:" + paragraphLongName);
		return paragraphLongName;
	}
	
	
	/**
	 * This function return correspondence saved info such as template name, paragraph name,
	 * Name, address, city and state info
	 * @param property config property name
	 * @param corrsDocId correspondence doc id
	 * @return ConfigItem
	 */
	public ConfigItem getExpagCorrSavedInfo(String property, String corrsDocId){
		ConfigItem configItem = new ConfigItem();
		CorroSavedInfoMapper corroSavedInfoMapper = new CorroSavedInfoMapper();
		
		Object[] args = new Object[] {corrsDocId};
		
		List<ConfigData> configData = this.query(this.expagCorrSavedInfoSql,
				corroSavedInfoMapper, args);
		
		configItem.setItemName(property);
		configItem.getDataPairs().addAll(configData);
				
		return configItem;
	}
	
	
	public String getExpagCorrDocId(String taskId, String guid) {
		
		String corroDocId = null;
		try {
		EXPAGCorrespondenceMapper expagCorrespondenceMapper = new EXPAGCorrespondenceMapper();
		Object[] args = new Object[]{taskId,"CMSUD : " + guid};

		corroDocId = this.queryForObject(this.expagCorrDocInfoSql, expagCorrespondenceMapper, args);
		} catch (Exception e) {
			LOGGER.error("Exception getting expagCorrDocInfo for taskId:" + taskId + ", guid:"+guid + " : " + e.getMessage());
		}
		return corroDocId;
	}


	public String getNextCorroId() {
		Connection con = null;
		CallableStatement call = null;
		String nextCorroId = null;
		try {
			con = this.expagJdbcTemplate.getDataSource().getConnection();

			call = con.prepareCall("BEGIN GETNEXTCORROID(?,?); END;");
			call.registerOutParameter(1, oracle.jdbc.OracleTypes.VARCHAR);
			call.registerOutParameter(2, oracle.jdbc.OracleTypes.INTEGER);

			call.execute();

			nextCorroId = call.getString(1);
		} catch (Exception e) {
			LOGGER.error("Exception getting nextCorroId:" + e.getMessage());
		} finally {
			try {
				if (call != null) {
					call.close();				
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				call = null;
				con = null;
				LOGGER.error("Error while closing DB connection for getNextCorroId: "+e.getMessage());
			}
		}
		return nextCorroId;
	}
	
	public boolean insertExpagCorro(String userId, String taskId,
			Document document, String corroId, String corroDocId,
			String currentDate, String currentTime) {
		boolean insertSuccess = false;
		String addressLine3 = null;
		String addressLine4 = null;
		try {
			
			addressLine3 = document.getDocumentsDeliveries().getDocDlvries().get(0)
			.getContact().getAddr().getAddrLine3();
			addressLine3 = (addressLine3==null || addressLine3.equals("")) ? " ": addressLine3;

			addressLine4 = document.getDocumentsDeliveries().getDocDlvries().get(0)
					.getContact().getAddr().getAddrLine4();
					addressLine4 = (addressLine4==null || addressLine4.equals("")) ? " ": addressLine4;

			Object[] args = new Object[] {
					corroId,
					taskId,
					" ",
					corroDocId,
					document.getDocumentsDeliveries().getDocDlvries().get(0)
							.getContact().getAddr().getAddrLine1(),
					document.getDocumentsDeliveries().getDocDlvries().get(0)
							.getContact().getAddr().getAddrLine2(),
							addressLine3,
							addressLine4,
					document.getDocumentsDeliveries().getDocDlvries().get(0)
							.getContact().getAddr().getAddrLine5(),
					document.getDocumentsDeliveries().getDocDlvries().get(0)
							.getContact().getAddr().getAddrLine6(), userId,0,0,
					currentDate, currentDate, currentTime," ",
					document.getSalutation(), "N","N",0,document.getDocTemplateCd() };

			int numOfRecordsInserted = this.expagJdbcTemplate.update(this.expagInsertCorro, args);
			if(numOfRecordsInserted == 1){
				insertSuccess = true;
			}
		//	this.query(this.expagInsertCorro, null, args);

		} catch (Exception e) {
			LOGGER.error("Insert into CORRO table failed for values corroId:"
					+ corroId
					+ ", taskId:"+ taskId
					+ ", corroDocId:"+ corroDocId
					+ ", AddressLine1:" + document.getDocumentsDeliveries().getDocDlvries().get(0).getContact().getAddr().getAddrLine1()
					+ ", AddressLine2:" + document.getDocumentsDeliveries().getDocDlvries().get(0).getContact().getAddr().getAddrLine2()
					+ ", AddressLine3:" + addressLine3
					+ ", AddressLine4:" + addressLine4
					+ ", AddressLine5" + document.getDocumentsDeliveries().getDocDlvries().get(0).getContact().getAddr().getAddrLine5()
					+ ", AddressLine6" + document.getDocumentsDeliveries().getDocDlvries().get(0).getContact().getAddr().getAddrLine6()
					+ ", currentDate:" + currentDate
					+ ", currentTime:" + currentTime
					+ ", document.getSalutation():" + document.getSalutation()
					+ ", document.getDocTemplateCd():" + document.getDocTemplateCd() 
					+ ". Error Message: "+e.getMessage());
		}
		return insertSuccess;
	}
	
	public boolean updateExpagDocDetail(String corroDocId) {
		boolean updateSuccess = false;
		Object[] args = new Object[] { corroDocId };
		try {
			int numOfRecordsUpdated = this.expagJdbcTemplate.update(this.expagCorrDocDtl, args);
			if(numOfRecordsUpdated==1){
				updateSuccess = true;
			}
		} catch (Exception e) {
			LOGGER.error("Update into DOCDETAIL table failed:" + e.getMessage());
		}
		return updateSuccess;
	}
	
	public boolean insertExpagCorroPara(String corroId,String paraId,String seqNum) {
		boolean updateSuccess = false;
		Object[] args = new Object[] { corroId, seqNum, paraId };
		try {
			int numOfRecordsInserted = this.expagJdbcTemplate.update(this.expagInsertPara, args);
			if(numOfRecordsInserted == 1){
				updateSuccess = true;
			}
		} catch (Exception e) {
			LOGGER.error("Update into CORROPARA table failed with values corroId:" + corroId + ", seqNum:" + seqNum + ", paraId:" + paraId + ". Error Msg : " + e.getMessage());
		}
		return updateSuccess;
	}
	
	/**
	 * This function returns routing rules triggered for a task
	 * @param tskId
	 * @return NameValue
	 */
	public NameValue getRoutingRulesForTask(String tskId){
		RoutingRulesMapper routingRulesMapper = new RoutingRulesMapper();
		Object[] args = new Object[] {tskId};
		List<NameValue> childNameValues = this.query(this.expagRoutingRulesForTask, routingRulesMapper, args);
		
		if(childNameValues != null && !childNameValues.isEmpty()){
			NameValue nameValue = new NameValue();
			nameValue.setName(PROPERTY_NAME_ROUTING_RULES);
			nameValue.setDesc(PROPERTY_DESC_ROUTING_RULES);
			nameValue.getChildrenNameValues().addAll(childNameValues);
			return nameValue;
		}
				
		return null;
	}
	
	public String getEvalRuleReqStatus(String taskId) {

		Object[] args = new Object[]{taskId};
		TaskStatusMapper taskStatusMapper = new TaskStatusMapper();
		String evalTaskStatus = null;
		try{
			evalTaskStatus = this.expagJdbcTemplate.queryForObject(this.expagEvalRuleReqStatus, taskStatusMapper, args);
		}catch(Exception e){
			if(!(e instanceof EmptyResultDataAccessException)){
				LOGGER.error("SQL error to fetch status of task : "+taskId+" from EVALRULEREQ table"+ e.getMessage());
			}
		}
		return evalTaskStatus; 
	}
	
	public boolean updateExpagTskHist(String tskId, String piDate, String startTime){
		
		boolean updateSuccess = false;
		Object[] args = new Object[] { tskId,piDate,startTime };
		try {
			int numOfRecordsInserted = this.expagJdbcTemplate.update(this.expagUpdateTskHist, args);
			if(numOfRecordsInserted==1){
				updateSuccess = true;
			}
		} catch (Exception e) {
			LOGGER.error("Update into TSKHIST table failed:tskId"+tskId+",piDate:"+piDate+",startTime:"+startTime);
			LOGGER.error("Update into TSKHIST table failed:" + e.getMessage());
		}
		return updateSuccess;
	}
	
	
	public boolean insertTskHistEditDefault(String tskId, String piDate, String startTime, int actCode, String wrkBskt,int priority){
			
			boolean updateSuccess = false;
			Object[] args = new Object[] { tskId,piDate,startTime,actCode,wrkBskt,priority };
			try {
				int numOfRecordsInserted = this.expagJdbcTemplate.update(this.insertTskHistEditDefault, args);
				if(numOfRecordsInserted==1){
					updateSuccess = true;
				}
			} catch (Exception e) {
				LOGGER.error("Insert into TSKHISTEDITDEFAULT table failed:tskId"+tskId+",piDate:"+piDate+",startTime:"+startTime+",actCode"+actCode+",wrkBskt:"+wrkBskt+",priority:"+priority);
				LOGGER.error("Insert into TSKHISTEDITDEFAULT table failed:" + e.getMessage());
			}
			return updateSuccess;
	}

	public String getDocCreateDate(String docId) {
	
		Object[] args = new Object[]{docId};
		EXPAGDocCreateDateMapper expagDocCreateDateMapper = new EXPAGDocCreateDateMapper();
		return this.queryForObject(this.expagDocCreateDateSql, expagDocCreateDateMapper, args);	
	}
public boolean updateLastAccessDate(String lastAccessDate, String docId){
		
		boolean updateSuccess = false;
		Object[] args = new Object[] { lastAccessDate, docId };
		
		try {
			
				int numOfRecordsUpdated = this.expagJdbcTemplate.update(this.expagUpdateLastAccessDate, args);
				if(numOfRecordsUpdated == 1){
					updateSuccess = true;
				}
				
		} catch (Exception e) {
			
			LOGGER.error("Update into DOCDETAIL table failed:docId " + docId +",lastAccessDate: " + lastAccessDate);
			LOGGER.error("Update into DOCDETAIL table failed:" + e.getMessage());
			
		}
		
		return updateSuccess;
	}
	
	public boolean updateContentCode(String contCode, String docId){
		
		boolean updateSuccess = false;
		Object[] args = new Object[] { StringUtils.rightPad(contCode, 30), docId };
		
		try {
			
				int numOfRecordsUpdated = this.expagJdbcTemplate.update(this.expagUpdateContentCode, args);
				if(numOfRecordsUpdated == 1){
					updateSuccess = true;
				}
				
		} catch (Exception e) {
			
			LOGGER.error("Update into DOCCNT table failed:docId " + docId +",contCode: " + contCode);
			LOGGER.error("Update into DOCCNT table failed:" + e.getMessage());
			
		}
		
		return updateSuccess;
	}
	
	public boolean selectContentCode(String docId) {
		Object[] args = new Object[] { docId };
		boolean entryExists = false;
		try {
			Map<String, Object> docTypeInfo = this.expagJdbcTemplate.queryForMap(this.selectContentTypeInfo, args);
			if(docTypeInfo != null && docTypeInfo.size() > 0){
				entryExists = true;
			}
		} catch (Exception e){
			if(!(e instanceof EmptyResultDataAccessException)){
				LOGGER.error("Select for "+ docId +" in DOCCNT table failed with"+ e.getMessage());
			}
		}
		return entryExists;
	}
	
	public Map<String, Object> getDocInfo(String docId) {
		Object[] args = new Object[] { docId };
		Map<String, Object> docTypeInfo = new HashMap<String, Object>();
		try {
			docTypeInfo = this.expagJdbcTemplate.queryForMap(this.selectDocInfo, args);
		} catch (Exception e){
			if(!(e instanceof EmptyResultDataAccessException)){
				LOGGER.error("Select for "+ docId +" in DOC table failed with"+ e.getMessage());
			}
		}
		return docTypeInfo;
	}

	public boolean insertContentCode(String contCode, String docId,String tskId, int begPage, int endPage) {
		boolean updateSuccess = false;
		contCode = StringUtils.rightPad(contCode, 30);
		Object[] args = new Object[] {docId, contCode, begPage, endPage, tskId};
		try {
			int numOfRecordsInserted = this.expagJdbcTemplate.update(this.insertDocCnt, args);
			if(numOfRecordsInserted == 1){
				updateSuccess = true;
			}
		} catch (Exception e) {
			LOGGER.error("Insert into TSKHISTEDITDEFAULT table failed:" + e.getMessage());
			LOGGER.error("contCode:"+ contCode +", docId:"+ docId +",begPage:"+ begPage +",endPage:"+ endPage +",tskId:"+ tskId);
		}
		return updateSuccess;
		
	}
	
	/** EXPAG MehtodOfCommunication  **/
	public ConfigItem getExpagMehtodOfCommunication(String property) {
		ConfigItem configItem = new ConfigItem();
		MOCMapper mocMapper = new MOCMapper();
		Object[] args = new Object[]{};
			List<ConfigData>  configData =this.query(this.getExpagMethodOfCommunicationSql, mocMapper, args);
			configItem.setItemName(property);
			configItem.getDataPairs().addAll(configData);
			LOGGER.debug("configData from getExpagMethodOfComunication:"+configData);
			return configItem;
		}
	
	
	/**
	 * This function returns location and Mail Drop Times configured for user
	 * @param property
	 * @param userId
	 * @return ConfigItem
	 */
	public ConfigItem getLocationAndMailDropTimes(String property, String userId){
		ConfigItem configItem = new ConfigItem();
		configItem.setItemName(property);
		ConfigData data = new ConfigData();
		SubFields fields = new SubFields();
		LocationAndMailDropTimeMapper lamdMapper = new LocationAndMailDropTimeMapper();
		Object[] args = new Object[] {userId};
		
		List<PIOperatorLocationAndMailDropTimes> locDataList = this.query(this.expagLocationAndMailDropTimesForOperator, lamdMapper, args);
		
		if(locDataList != null && locDataList.size() > 0){
			if(locDataList.get(0).getLocationCode() != null){
				data.setShortDescription(locDataList.get(0).getLocationCode());
			}
			if(locDataList.get(0).getLocationName() != null){
				data.setLongDescription(locDataList.get(0).getLocationName());
			}
			for(PIOperatorLocationAndMailDropTimes locData : locDataList) {
				SubField field = new SubField();
				field.setFieldValue(locData.getMailDropTime());
				fields.getSubFields().add(field);
			}
		}
		
		data.setSubFields(fields);
		configItem.getDataPairs().add(data);
		return configItem;
	}
	
	/**
	 * This function returns next sequence number for BATCHINFO table
	 * @param locationCd
	 * @param createDate
	 * @return String
	 */
	public String getNextBatchInfoSequenceNumber(String locationCd, String createDate){
		
		Object[] args = new Object[] {StringUtils.rightPad(locationCd, 3), createDate};
		String nextSeqNo = null;
		try {
			nextSeqNo = this.expagJdbcTemplate.queryForObject(this.expagNextSequenceNumber, String.class, args);
		} catch (Exception e) {
			LOGGER.error("Get Next Sequence Number failed for location code: "+ locationCd +" and create date: "+ createDate + " failed with"+ e.getMessage());
		}
		
		return nextSeqNo;
	}
	
	
	/**
	 * This function inserts record in BATCHINFO table
	 * @param locationCode
	 * @param createDate
	 * @param seqNo
	 * @return boolean
	 */
	public boolean insertBatchInfo(String locationCode, String createDate, String seqNo){
		
		boolean updateSuccess = false;
		Object[] args = new Object[] {locationCode, createDate, seqNo};
		try {
			int numOfRecordsInserted = this.expagJdbcTemplate.update(this.insertBatchInfo, args);
			if(numOfRecordsInserted == 1){
				updateSuccess = true;
			}
		} catch (Exception e) {
			LOGGER.error("Insert into BATCHINFO table failed: locationCd"+ locationCode +", createDate:"+ createDate +", seqNo:"+ seqNo +". Error Message"+ e.getMessage());
		}
		return updateSuccess;
	}
	
	
	/**	This function return the LocationCode based on userId passed
	 * @param property
	 * @param userId
	 * @return ConfigItem
	 */
	public ConfigItem getLocationCodeBasedOnUserId(String property, String userId){
        LOGGER.debug("getLocationCodeBasedOnUserId(): UserID : "+userId);
        Object[] args = new Object[] { userId };
        
        ConfigItem configItem = new ConfigItem();
        configItem.setItemName(property);
        String locationCode = null;
        try {
               locationCode = this.expagJdbcTemplate.queryForObject(this.expagLocationCodeForOperatorSql, String.class, args);
        } catch (Exception e) {
               LOGGER.error("Failed to get location code for user: "+ userId, e.getMessage());
        }

        if (locationCode != null) {
               ConfigData configData = new ConfigData();
               configData.setShortDescription(locationCode);
               configItem.getDataPairs().add(configData);
        }

        return configItem;
  }
	
	public List<TaskIdentifiersValue> getTaskIdentifiersValue(String Taskid){
		String sql = null;
		List<TaskIdentifiersValue> tivalueList = new ArrayList<TaskIdentifiersValue>();
		Object[] args = new Object[]{Taskid};
		LOGGER.debug("In getTaskIdentifiersValue method");
		
		if(!StringUtils.isBlank(Taskid)){
			sql = this.taskIdentifiersValueSql;
			EXPAGTaskIdentifiersValueMapper tiValueMapper = new EXPAGTaskIdentifiersValueMapper();
			tivalueList = this.query(sql, tiValueMapper, args);
		}
		return tivalueList;
	
	}
	
	public void getRoutingRuleAlgorithm(String userId, String taskId) {
		Connection con = null;
		CallableStatement call = null;
		
		try {
			con = this.expagJdbcTemplate.getDataSource().getConnection();
			call = con.prepareCall("BEGIN PIMITEK.MOVETSKREQTOEVALRULEREQ(?,?,?,?); END;");
			call.setString(1, userId);
			call.setString(2, taskId);
			call.registerOutParameter(3, oracle.jdbc.OracleTypes.NUMBER);
			call.registerOutParameter(4, oracle.jdbc.OracleTypes.VARCHAR);

			call.execute();

			if(call.getInt(3) != 0){
				LOGGER.debug("The return code for Stored proc is "+call.getInt(3));
				LOGGER.debug("The return description for Stored proc is "+call.getString(4));
			}
		} catch (Exception e) {
			LOGGER.error("Exception getting MoveTskreqToEvalRuleReq:" + e.getMessage());
		} finally {
			try {
				if (call != null) {
					call.close();				
				}
				if (con != null) {
					con.close();
				}
			} catch (SQLException e) {
				call = null;
				con = null;
				LOGGER.error("Error while closing DB connection for MOVETSKREQTOEVALRULEREQ: "+e.getMessage());
			}
		}
	}
	
	public ConfigItem getConfigItemWithSubfieldValue(String dropDownName, String filterValue) {
		DropdownWithSubfieldValueResultMapper dropDownMapper = new DropdownWithSubfieldValueResultMapper();

		ConfigItem configItem = new ConfigItem();
		String sql = null;
		Object[] args = new Object[]{filterValue};

		if (EXPAG_TASK_TYPES_FOR_DEPARTMENT.equalsIgnoreCase(dropDownName)) {
			sql = this.taskTypesForDepartmentSql;
		}

		List<ConfigData> configData = this.query(sql, dropDownMapper, args);
		configItem.setItemName(dropDownName);
		configItem.getDataPairs().addAll(configData);

		return configItem;
	}
	
	public void removeExcludedOperFromTask(String taskId){
		
		Object[] args = new Object[]{taskId};		
		try {
				int numOfRecordsUpdated = this.expagJdbcTemplate.update(this.removeExcludedOperFromTask, args);
				if(numOfRecordsUpdated != 1){
					LOGGER.error("Excluded oper has not been removed correctly for task id "+taskId);
				}				
		} catch (Exception e) {			
			LOGGER.error("Update into tskreq table failed to remove excluded oper : task id " + taskId +" with error: " + e.getMessage());			
		}
		
	}

	public void updateEXPAGIdentifiers(String fieldValue, BigInteger nbrSeq, String idDesc, BigInteger fieldNbr, String tskId) {
		
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		String todaysDate = dateFormat.format(Calendar.getInstance().getTime());
		BigInteger dateRcvd = new BigInteger(todaysDate);

		Object[] args = new Object[] { fieldValue, fieldNbr, dateRcvd, tskId, nbrSeq, StringUtils.rightPad(idDesc, 15) };
		
		try {
			
				int numOfRecordsUpdated = this.expagJdbcTemplate.update(this.updateIdentifiers, args);
				if(numOfRecordsUpdated == 0){
					LOGGER.error("No records updated in TSKIDENT table for task id: " + tskId + " and identifier " +  idDesc);
				}
			
		} catch (Exception e) {
			LOGGER.error("Update TSKIDENT table failed:" + e.getMessage());
		}			
	
	}
	
	public void updateReceivedDateTime(String receivedDate, String receivedTime, String tskId ) {
    	
		Object[] args = new Object[] { receivedDate, receivedTime, tskId };
		
		try {
			int numOfRecordsUpdated = this.expagJdbcTemplate.update(this.updateRecvdDateTime, args);
			if(numOfRecordsUpdated == 0) {
				LOGGER.warn("No records updated in TSKREQ table for task id: " + tskId );
			}
			
		} catch (Exception e) {
			LOGGER.error("Update into TSKREQ table failed:tskId"+tskId+",receivedDate:"+receivedDate+",receivedTime:"+receivedTime);
			LOGGER.error("Update TSKREQ table failed:" + e.getMessage());
		}	
		
	}
	//EXPAG conversion changes//
	public String getExpagTaskTypeForTaskId(String taskId) {

		EXPAGTaskTypeMapper expagTaskTypeMapper = new EXPAGTaskTypeMapper();
		Object[] args = new Object[]{StringUtils.rightPad(taskId, 11)};

		String taskType = this.queryForObject(this.expagTaskTypeForTaskIdQuery, expagTaskTypeMapper, args);
		LOGGER.debug("getExpagTaskTypeForTaskId:" + taskType);
		return taskType;
	}
	
}
