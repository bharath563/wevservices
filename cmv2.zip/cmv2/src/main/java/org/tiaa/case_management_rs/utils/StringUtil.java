package org.tiaa.case_management_rs.utils;

public final class StringUtil {
	private StringUtil() {
	}

	public static String toTitleCase(String string) {
		final int additionalCapacity = 5;
		char[] charArray = string.toCharArray();
		boolean oldLower = false;
		StringBuilder stringBuilder = new StringBuilder(charArray.length + additionalCapacity);
		for (int ii = 0; ii < charArray.length; ii++) {
			char ch = charArray[ii];
			boolean lower = Character.isLowerCase(ch);
			boolean upper = Character.isUpperCase(ch);
			if (ii == 0) {
				stringBuilder.append(Character.toUpperCase(ch));
			} else {
				if (ch == '_') {
					stringBuilder.append(" ");
				} else if (upper && oldLower) {
					stringBuilder.append(" ");
					stringBuilder.append(ch);
				} else {
					stringBuilder.append(ch);
				}
			}
			oldLower = lower;
		}
		return stringBuilder.toString();
	}

	public static void singleQuote(StringBuilder query, String id) {
		query.append("'").append(id).append("'");
	}

	public static String singleQuote(String string) {
		return "'" + string + "'";
	}

}
