package org.tiaa.case_management_rs.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

public class CMSTaskDocumentType implements Serializable {
	private static final long serialVersionUID = 5923071103278648253L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="CMS_TASK_DOCUMENT_TYPE_SEQ")
	@SequenceGenerator(name = "CMS_TASK_DOCUMENT_TYPE_SEQ", sequenceName = "CMS_TASK_DOCUMENT_TYPE_SEQ", allocationSize = 1)
	private long cmsTaskDocumentTypeId;
	private String contentType;
	private String documentDisplayName;
	private String documentDirection;
	private boolean active;
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate;
	private String createdBy;
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedDate;
	private String updatedBy;

	public long getCmsTaskDocumentTypeId() {
		return cmsTaskDocumentTypeId;
	}

	public String getContentType() {
		return contentType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public String getDocumentDirection() {
		return documentDirection;
	}

	public String getDocumentDisplayName() {
		return documentDisplayName;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setCmsTaskDocumentTypeId(long id) {
		this.cmsTaskDocumentTypeId = id;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public void setDocumentDirection(String documentDirection) {
		this.documentDirection = documentDirection;
	}

	public void setDocumentDisplayName(String documentDisplayName) {
		this.documentDisplayName = documentDisplayName;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String toString() {
		return String
				.format("CMSTaskDocumentType [cmsTaskDocumentTypeId=%s, contentType=%s, documentDisplayName=%s, documentDirection=%s, active=%s, createdDate=%s, createdBy=%s, updatedDate=%s, updatedBy=%s]",
						cmsTaskDocumentTypeId, contentType, documentDisplayName, documentDirection, active, createdDate, createdBy, updatedDate, updatedBy);
	}
}
