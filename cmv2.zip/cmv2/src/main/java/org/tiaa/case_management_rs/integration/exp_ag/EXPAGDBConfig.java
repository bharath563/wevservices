package org.tiaa.case_management_rs.integration.exp_ag;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class EXPAGDBConfig {
	@Autowired
	private DataSource expagDataSource;

	@Bean
	public JdbcTemplate expagJdbcTemplate() {
		return new JdbcTemplate(expagDataSource);
	}

	@Bean
	public EXPAGTasksDAO retryFailedTasksEXPAGTasksDAO() {
		return new EXPAGTasksDAO();
	}
}