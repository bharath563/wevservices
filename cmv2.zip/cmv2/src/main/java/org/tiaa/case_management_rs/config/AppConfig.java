package org.tiaa.case_management_rs.config;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import com.google.common.cache.CacheBuilder;

import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.guava.GuavaCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.jms.annotation.EnableJms;

import org.tiaa.case_management_rs.email.EmailServiceConfig;
import org.tiaa.case_management_rs.integration.case_manager.CTHCaseManagerConfig;
import org.tiaa.case_management_rs.integration.case_manager.CaseManagerDBConfig;
import org.tiaa.case_management_rs.integration.case_manager.cth.events.CaseInRosterDBConfig;
import org.tiaa.case_management_rs.integration.cth.CTHWsConfig;
import org.tiaa.case_management_rs.integration.cth.events.CTHEventConfig;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGDBConfig;
import org.tiaa.case_management_rs.integration.exp_ag.NextGenDBConfig;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.PowerImageConfig;
import org.tiaa.case_management_rs.integration.plan_sponsor.PlanSponosrRSConfig;
import org.tiaa.case_management_rs.poller.PollerConfig;
import org.tiaa.case_management_rs.syncup.customer_webform.CustomerWebFormConfig;
import org.tiaa.case_management_rs.syncup.service_request.BPMAppConfig;
import org.tiaa.case_management_rs.syncup.service_request.ICMServiceRequestConfig;
import org.tiaa.case_management_rs.syncup.service_request.ServiceRequestConfig;

import sun.misc.BASE64Encoder;
@Configuration
@EnableJms
@EnableCaching
@Import({EXPAGDBConfig.class, //
	ProcessDBConfig.class, //
	PollerConfig.class, //
	PlanSponosrRSConfig.class, //
	EmailServiceConfig.class, //
	CTHWsConfig.class, //
	ServiceRequestConfig.class, //
	CustomerWebFormConfig.class, //
	CTHEventConfig.class, //
	CaseManagerDBConfig.class, //
	CTHCaseManagerConfig.class, //
	CaseInRosterDBConfig.class, //
	PowerImageConfig.class,//
	ICMServiceRequestConfig.class,
	NextGenDBConfig.class,
	BPMAppConfig.class})
@PropertySources(value = {@PropertySource({"classpath:expag_service_request_task_queries.xml"}), //
		@PropertySource({"classpath:expag_customer_web_form_task_queries.xml"}), //
		@PropertySource({"classpath:expag_casemanagement_ui_queries.xml"}), //
		@PropertySource({"classpath:Defaults.properties"}), //
		@PropertySource(value = "classpath:appconfigs/casemanagementrsv2/app.properties")})
@ComponentScan(basePackages = {"org.tiaa.case_management_rs.integration.exp_ag", //
		"org.tiaa.case_management_rs.integration.case_manager", //
		"org.tiaa.cth", //
		"org.tiaa.case_management_rs.syncup.service_request", //
"org.tiaa.case_management_rs.syncup.customer_webform",
"org.tiaa.case_management_rs.resource"})
public class AppConfig {
	@Bean
    public BASE64Encoder base64Encoder() {
		BASE64Encoder base64Encoder = new BASE64Encoder();
        return base64Encoder;
	}
	
	@Bean(name="cmrsCacheManager")
	public CacheManager cache() {
		GuavaCache nxtGenCache = new GuavaCache("nxtGenDelegator", CacheBuilder.newBuilder().expireAfterWrite(5, TimeUnit.DAYS).initialCapacity(1000).build());
		SimpleCacheManager simpleCacheManager = new SimpleCacheManager();
		simpleCacheManager.setCaches(Arrays.asList(nxtGenCache));
		return simpleCacheManager;
	}
}