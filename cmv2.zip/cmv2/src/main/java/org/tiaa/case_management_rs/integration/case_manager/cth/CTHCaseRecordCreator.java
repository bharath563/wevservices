package org.tiaa.case_management_rs.integration.case_manager.cth;

import org.tiaa.esb.partyrequest.types.CreateRequests;
import org.tiaa.esb.partyrequest.types.CreateRequestsResponse;

public class CTHCaseRecordCreator {
	private CTHCaseWebService cthCaseWebService;
	private CaseManagerCreateHierarchyPartyRequestBuilder createHierarchyPartyRequestBuilder;

	public CreateRequestsResponse createCTHRecord(CreateCTHCaseContext context) {
		CreateRequests createRequests = createHierarchyPartyRequestBuilder.build(context);
		return cthCaseWebService.createCTHEntry(context, (CreateRequests) createRequests);
	}

	public void setCthCaseWebService(CTHCaseWebService cthWebService) {
		this.cthCaseWebService = cthWebService;
	}

	public void setCreateHierarchyPartyRequestBuilder(CaseManagerCreateHierarchyPartyRequestBuilder createHierarchyPartyRequestBuilder) {
		this.createHierarchyPartyRequestBuilder = createHierarchyPartyRequestBuilder;
	}
}
