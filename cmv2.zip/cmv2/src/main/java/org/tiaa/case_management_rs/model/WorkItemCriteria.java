package org.tiaa.case_management_rs.model;

public class WorkItemCriteria {

	private String userId;
	private String department;
	private String clientId;
	private int workItemCount;
	private String condition;
	private String taskId;
	private String docId;
	private String pktId;
	private String property;
	private String extDocKey;
	private String parameter;

	public String getTaskId() {
		return this.taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDepartment() {
		return this.department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getClientId() {
		return this.clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getCondition() {
		return this.condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public int getWorkItemCount() {
		return this.workItemCount;
	}

	public void setWorkItemCount(int workItemCount) {
		this.workItemCount = workItemCount;
	}

	public String getDocId() {
		return this.docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getPktId() {
		return this.pktId;
	}

	public void setPktId(String pktId) {
		this.pktId = pktId;
	}

	public String getProperty() {
		return this.property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getParameter() {
		return this.parameter;
	}

	public void setParameter(String parameter) {
		this.parameter = parameter;
	}

	public String getExtDocKey() {
		return this.extDocKey;
	}

	public void setExtDocKey(String extDocKey) {
		this.extDocKey = extDocKey;
	}

}
