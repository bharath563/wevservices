package org.tiaa.case_management_rs.integration.federeated_document;

public class DocumentArchivalFailedException extends RuntimeException {
	public DocumentArchivalFailedException() {
		super();
	}

	public DocumentArchivalFailedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public DocumentArchivalFailedException(String message, Throwable cause) {
		super(message, cause);
	}

	public DocumentArchivalFailedException(String message) {
		super(message);
	}

	public DocumentArchivalFailedException(Throwable cause) {
		super(cause);
	}
}
