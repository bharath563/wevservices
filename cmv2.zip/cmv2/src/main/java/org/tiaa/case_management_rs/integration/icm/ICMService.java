package org.tiaa.case_management_rs.integration.icm;
 
import java.util.List;

import org.tiaa.esb.icm.types.Case;
import org.tiaa.esb.icm.types.CaseSearch;
import org.tiaa.esb.icm.types.Comment;
import org.tiaa.esb.icm.types.Configuration;
import org.tiaa.esb.icm.types.Document;
import org.tiaa.esb.icm.types.Response;
import org.tiaa.esb.icm.types.ResponseList;
 
public interface ICMService {
    
	public ResponseList searchICMCases(CaseSearch icmCaseSearchRequest, String userId);
    
    public Case getICMProcess(String processId, String userId);
    
    public ResponseList getICMtasks(String processId, String userId, String start);
    
    public ResponseList getICMDocuments(String processId, String userId);
    
    public ResponseList getICMcomments(String processId, String userId);
    
    public Configuration getICMConfigItem(String property);
    
    public Configuration getICMRequestTypesForBA(String property, String dept);
 
    public Response addComment(Comment icmCommentRequest, String caseId,
            String userId);
    
    public Response addDocument(Document icmDocumentRequest, String caseId,
            String userId);
    
    public void deleteICMDocument(String caseId,String docTemplateCode,String userId);
    
    public ResponseList getICMRelatedCase(String processId, String userId,String solutionName);
    
    public List<String> getICMSolutions(String property, String userId);
    
	public Configuration getICMSolutionHeaders(String dept, String userId, String tableheader);

}