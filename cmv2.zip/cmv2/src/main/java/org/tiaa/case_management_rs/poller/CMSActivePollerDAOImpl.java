package org.tiaa.case_management_rs.poller;

import static org.tiaa.case_management_rs.common.AppConstants.*;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.transaction.annotation.Transactional;

import org.tiaa.case_management_rs.domain.CMSActivePoller;

@Transactional
public class CMSActivePollerDAOImpl implements CMSActivePollerDAO {
	private static Logger logger = LoggerFactory.getLogger(CMSActivePollerDAOImpl.class);
	private static Logger statusLogger = LoggerFactory.getLogger(STATUS_PACKAGE + CMSActivePollerDAOImpl.class.getSimpleName());
	@PersistenceContext(unitName = "entityManagerFactory")
	protected EntityManager entityManager;

	@Override
	public CMSActivePoller findById(String component) {
		return (CMSActivePoller) getEntityManager().find(CMSActivePoller.class, component);
	}

	public CMSActivePoller getActivePoller(String component) {
		final String sql = "Select activePoller from CMSActivePoller activePoller where activePoller.name = :component";
		Query query = entityManager.createQuery(sql);
		query.setParameter("component", component);
		return (CMSActivePoller) query.getSingleResult();
	}

	public boolean insertPoller(CMSActivePoller ap) {
		getEntityManager().persist(ap);
		return true;
	}

	public void updateHeartBeat(String component, String instance) {
		final String sql = "Update CMSActivePoller activePoller  set activePoller.lastUpdatedTimestamp = :lastUpdatedTimestamp where activePoller.name = :componentName and activePoller.owner = :instance";
		Query query = entityManager.createQuery(sql);
		query.setParameter("lastUpdatedTimestamp", new Date());
		query.setParameter("componentName", component);
		query.setParameter("instance", instance);
		int countofRecUpdated = query.executeUpdate();
		if (countofRecUpdated > 0) {
			statusLogger.debug("Heartbeat updated by instance: {} for component :", instance, component);
		}
	}

	public boolean updateOwner(String component, String owner) {
		logger.debug("Updating owner as :{}  for instance :{}", owner, component);
		final String sql = "Update CMSActivePoller activePoller set activePoller.owner = :owner, activePoller.lastUpdatedTimestamp = :lastUpdatedTimestamp where activePoller.name = :componentName";
		Query query = entityManager.createQuery(sql);
		query.setParameter("owner", owner);
		query.setParameter("lastUpdatedTimestamp", new Date());
		query.setParameter("componentName", component);
		int countofRecordsUpdated = query.executeUpdate();
		logger.debug("Number of records updated are :{}", countofRecordsUpdated);
		return countofRecordsUpdated > 0;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}
}
