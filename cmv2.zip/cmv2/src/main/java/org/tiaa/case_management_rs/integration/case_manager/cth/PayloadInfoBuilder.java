package org.tiaa.case_management_rs.integration.case_manager.cth;

import static org.tiaa.case_management_rs.domain.TaskInfo.*;

import java.util.Date;
import java.util.List;

import javax.xml.transform.dom.DOMResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.constants.FileTypes;
import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;
import org.tiaa.case_management_rs.integration.case_manager.domain.Phase;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.partyrequest.types.PartyRequestControlInfo;
import org.tiaa.esb.partyrequest.types.PayloadInfo;
import org.tiaa.esb.partyrequest.types.RequestInfo;
import org.tiaa.esb.partyrequest.types.UpdatePartyRequest;
import org.tiaa.esb.servicerequest.types.AnyXMLSkipType;
import org.tiaa.esb.servicerequest.types.CTHClob;
import org.tiaa.esb.servicerequest.types.Documents;
import org.tiaa.esb.servicerequest.types.ImplementationPlanType;
import org.tiaa.esb.servicerequest.types.ImplementationPlansType;
import org.tiaa.esb.servicerequest.types.OtherData;
import org.tiaa.esb.servicerequest.types.Request;
import org.tiaa.esb.servicerequest.types.ServiceRequest;
import org.tiaa.esb.servicerequest_workflow.types.CaseDetailsType;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;
import org.tiaa.esb.servicerequest_workflow.types.DocumentType;
import org.tiaa.esb.servicerequest_workflow.types.DocumentsType;

public class PayloadInfoBuilder {
	private static final Logger LOG = LoggerFactory.getLogger(PayloadInfoBuilder.class);
	private Jaxb2Marshaller servicerequestWorkflowJaxb2Marshaller;
	private String requestSchemaName = "";
	private String requestSchemaVersion = "";
	private Jaxb2Marshaller serviceRequestJaxb2Marshaller;
	private boolean setDocuments;

	public PayloadInfoBuilder(String requestSchemaName, String requestSchemaVersion) {
		super();
		this.requestSchemaName = requestSchemaName;
		this.requestSchemaVersion = requestSchemaVersion;
	}

	public PayloadInfo build(CreateCTHCaseContext context) {
		RequestInfo requestInfo = new RequestInfo();
		requestInfo.setAny(setRequestInfoAnyElement(context));
		//
		PayloadInfo payloadInfo = new PayloadInfo();
		payloadInfo.setRequestInfo(requestInfo);
		payloadInfo.setRequestSchemaName(requestSchemaName);
		payloadInfo.setRequestSchemaVersion(requestSchemaVersion);
		return payloadInfo;
	}

	public CaseInfo ensureValidCaseInfo(UpdateCaseCTHContext context) {
		CaseInfo caseInfo = context.getCaseInfo();
		if (caseInfo == null) {
			caseInfo = new CaseInfo();
			context.setCaseInfo(caseInfo);
		}
		if (caseInfo.getCaseDetails() == null) {
			caseInfo.setCaseDetails(new CaseDetailsType());
		}
		DocumentsType documents = caseInfo.getDocuments();
		if (documents == null) {
			documents = new DocumentsType();
			caseInfo.setDocuments(documents);
		}
		return caseInfo;
	}

	public CaseInfo mapCaseInfo(AbstractCTHCaseContext context) {
		CaseInfo caseInfo = new CaseInfo();
		caseInfo.setDocuments(mapDocuments(context));
		CaseDetailsType caseDetailsType = new CaseDetailsType();
		updateCaseDetails(context, caseDetailsType);
		caseInfo.setCaseDetails(caseDetailsType);
		return caseInfo;
	}

	public boolean updateCTH(UpdateCaseCTHContext context, String status) {
		CaseInfo caseInfo = ensureValidCaseInfo(context);
		final String cthStatus = getCthStatus(context, status);
		updateStatus(context, cthStatus);
		if (context.getCaseDetails().hasDocuments()) {
			LOG.debug("update document info");
			updateDocumentsType(context, caseInfo);
		}
		updateCaseDetails(context, caseInfo.getCaseDetails());
		return true;
	}

	protected Element setRequestInfoAnyElement(CreateCTHCaseContext context) {
		return toElement(createCTHClobType(context), serviceRequestJaxb2Marshaller);
	}

	private CTHClob createCTHClobType(CreateCTHCaseContext context) {
		CTHClob cthClobType = new CTHClob();
		cthClobType.setRequest(createRequestType(context));
		if (setDocuments) {
			cthClobType.setDocuments(new Documents());
		}
		//
		CaseInfo caseInfoType = mapCaseInfo(context);
		//
		AnyXMLSkipType anyXMLSkipType = new AnyXMLSkipType();
		anyXMLSkipType.setAny(toElement(caseInfoType, servicerequestWorkflowJaxb2Marshaller));
		//
		OtherData otherDataType = new OtherData();
		otherDataType.setWorkFlowXML(anyXMLSkipType);
		//
		mapPhaseInfo(context, otherDataType);
		//
		cthClobType.setOtherData(otherDataType);
		return cthClobType;
	}

	private void mapPhaseInfo(CreateCTHCaseContext context, OtherData otherDataType) {
		ImplementationPlansType implementationPlansType = new ImplementationPlansType();
		otherDataType.setImplementationPlansType(implementationPlansType);
		//
		List<ImplementationPlanType> implementationPlens = implementationPlansType.getImplementationPlen();
		for (Phase phase : context.getCaseDetails().getPhases()) {
			LOG.debug("phase:" + phase);
			ImplementationPlanType implementationPlanType = new ImplementationPlanType();
			implementationPlanType.setName(phase.getName());
			implementationPlanType.setDescription(phase.getDescription());
			implementationPlanType.setStartDate(phase.getStartDateTime());
			implementationPlanType.setActualCompletionDate(phase.getCompletedDateTime());
			implementationPlanType.setTargetCompletionDate(DateUtil.toXMLGregorianCalendar(phase.getTargetCompletionDateTime()));
			implementationPlens.add(implementationPlanType);
		}
	}

	private Request createRequestType(CreateCTHCaseContext context) {
		Request requestType = new Request();
		ServiceRequest requestServiceRequestType = new ServiceRequest();
		requestType.setServiceRequest(requestServiceRequestType);
		return requestType;
	}

	protected Element toElement(Object obj, Jaxb2Marshaller jaxb2Marshaller) {
		DOMResult domResult = new DOMResult();
		jaxb2Marshaller.marshal(obj, domResult);
		org.w3c.dom.Document node = (org.w3c.dom.Document) domResult.getNode();
		return node.getDocumentElement();
	}

	public static DocumentType findDocument(DocumentType documentToFind, List<DocumentType> documentList) {
		for (DocumentType documentType : documentList) {
			String documentId = getDocumentId(documentType);
			if (documentId.equals(getDocumentId(documentToFind))) {
				LOG.debug("docuemnt already exists: {}", documentId);
				return documentType;
			}
		}
		return null;
	}

	private String getCthStatus(UpdateCaseCTHContext context, String status) {
		CaseDetails taskInfo = context.getCaseDetails();
		if (taskInfo.updateTaskStatusInCTH(status)) {
			return context.getCaseDetails().getCthStatus();
		}
		return status;
	}

	private org.tiaa.esb.servicerequest_workflow.types.DocumentsType mapDocuments(AbstractCTHCaseContext context) {
		org.tiaa.esb.servicerequest_workflow.types.DocumentsType documentsType = new org.tiaa.esb.servicerequest_workflow.types.DocumentsType();
		List<DocumentType> documentList = documentsType.getDocuments();
		for (DocumentType documentType : context.getCaseDetails().getDocuments()) {
			documentList.add(documentType);
		}
		return documentsType;
	}

	private CaseDetailsType updateCaseDetails(AbstractCTHCaseContext context, CaseDetailsType caseDetailsType) {
		CaseDetails taskInfo = context.getCaseDetails();
		caseDetailsType.setCaseId(taskInfo.getCaseId());
		caseDetailsType.setCaseType(taskInfo.getCaseType());
		caseDetailsType.setCreateDate(DateUtil.toXMLGregorianCalendar(new Date()));
		caseDetailsType.setStatus(taskInfo.getCaseStatus());
		return caseDetailsType;
	}

	public static void updateDocumentsType(AbstractCTHCaseContext context, CaseInfo caseInfo) {
		List<DocumentType> documentList = caseInfo.getDocuments().getDocuments();
		Boolean hasValidFileType = false;
		for (DocumentType document : context.getCaseDetails().getDocuments()) {
			DocumentType foundDocument = findDocument(document, documentList);
			String documentType = document.getDocumentType();
			String fileExtension = documentType == null ? null : documentType.substring(documentType.lastIndexOf(".") + 1);
			hasValidFileType = fileExtension == null ? false : FileTypes.isValid(fileExtension);
			if (foundDocument == null) {
				LOG.debug("add document");
				if(document.getDocumentStatus().equals("REQUIRED") && hasValidFileType){
					document.setDocumentRead(false);
				}
				documentList.add(document);
			} else {
				//if status has changed update
				String currentDocumentStatus = document.getDocumentStatus();
				String statusInCTH = foundDocument.getDocumentStatus();
				if (!currentDocumentStatus.equals(statusInCTH)) {
					foundDocument.setDocumentStatus(currentDocumentStatus);
				}
				//If DocumentUploadedDateTime/DocumentRead are not available in CTH Response CLOB
				/*if((foundDocument.getDocumentUploadedDateTime() == null || foundDocument.isDocumentRead() == null)  && hasValidFileType){
					XMLGregorianCalendar currentDocumentUploadedDateTime = document.getDocumentUploadedDateTime();
					Boolean currentDocumentRead = document.isDocumentRead();
					foundDocument.setDocumentUploadedDateTime(currentDocumentUploadedDateTime);
					foundDocument.setDocumentRead(currentDocumentRead);
				}else{*/
				//if Document is still unread in CTH
				if(foundDocument.getDocumentUploadedDateTime() != null && foundDocument.isDocumentRead() != null  && hasValidFileType){
					Boolean isCurrentDocumentRead = document.isDocumentRead();
					Boolean isDocumentReadInCTH = foundDocument.isDocumentRead();
					if (hasValidFileType && !isCurrentDocumentRead.equals(isDocumentReadInCTH)) {
						foundDocument.setDocumentRead(isDocumentReadInCTH);
					}
				}

				if(!CommonUtil.isNull(document.getDocumentStatus()) && document.getDocumentStatus().equals("DELETED") && !CommonUtil.isNull(foundDocument.isDocumentRead()) && foundDocument.isDocumentRead() == false && hasValidFileType){
					foundDocument.setDocumentRead(true);
				}
			}
		}

		//If DocumentUploadedDateTime/DocumentRead are not available in CTH Response CLOB
		/*for(DocumentType document : documentList){
			if(document.getDocumentUploadedDateTime() == null || document.isDocumentRead() == null)	{
				Date date = document.getBusinessDate().toGregorianCalendar().getTime();
				document.setDocumentUploadedDateTime(DateUtil.toXMLGregorianCalendar(date));
				document.setDocumentRead(true);
			}
		}*/

		LOG.debug("documentList:" + documentList.size());
	}

	private void updateStatus(UpdateCaseCTHContext updateCTHContext, String status) {
		UpdatePartyRequest updatePartyRequest = updateCTHContext.getUpdatePartyRequest();
		PartyRequestControlInfo partyRequestControlInfo = updatePartyRequest.getPartyReqControlInfo();
		partyRequestControlInfo.setStatus(status);
	}

	public void setServiceRequestJaxb2Marshaller(Jaxb2Marshaller serviceRequestJaxb2Marshaller) {
		this.serviceRequestJaxb2Marshaller = serviceRequestJaxb2Marshaller;
	}

	public void setServicerequestWorkflowJaxb2Marshaller(Jaxb2Marshaller servicerequestWorkflowJaxb2Marshaller) {
		this.servicerequestWorkflowJaxb2Marshaller = servicerequestWorkflowJaxb2Marshaller;
	}
}
