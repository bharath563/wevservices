package org.tiaa.case_management_rs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import org.tiaa.case_management_rs.domain.CMSPollerLog;
import org.tiaa.case_management_rs.domain.WorkflowSystem;

@Repository
public interface CMSPollerLogRepository extends JpaRepository<CMSPollerLog, Long> {
	boolean ACTIVE = true;
	boolean IN_ACTIVE = false;
	CMSPollerLog findByWorkflowSystem(WorkflowSystem workflowSystem);
	CMSPollerLog findByWorkflowSystemAndHostName(WorkflowSystem workflowSystem, String hostName);
	CMSPollerLog findByWorkflowSystemAndHostNameAndNodeName(WorkflowSystem workflowSystem, String hostName, String nodeName);
	CMSPollerLog findByWorkflowSystemAndHostNameAndActive(WorkflowSystem workflowSystem, String hostName, boolean active);
	List<CMSPollerLog> findByHostNameAndActive(String hostName, boolean active);
}
