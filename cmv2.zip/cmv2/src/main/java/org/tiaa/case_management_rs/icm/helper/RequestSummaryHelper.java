package org.tiaa.case_management_rs.icm.helper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.integration.icm.ICMRepositoryLinkHelper;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.icm.types.infocaddy.NigoInfo;
import org.tiaa.esb.icm.types.infocaddy.OmniProcess;
import org.tiaa.esb.icm.types.infocaddy.RecentCases;
import org.tiaa.esb.icm.types.infocaddy.RepaymentDetails;
import org.tiaa.esb.icm.types.infocaddy.Type;

@Component
public class RequestSummaryHelper {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RequestSummaryHelper.class);

	@Autowired
	private ICMJsonUnmarshaller icmJsonMarshaller;
	
	@Autowired
    private ICMRepositoryLinkHelper iCMRepositoryLinkHelper;
	
	public NameValue mergeInfocaddyResponse(List<?> infoCaddyResponseList, String section) {
		
		LOGGER.info("Entering mergeInfocaddyResponse(List<?> infoCaddyResponseList, String section) ");
		
		NameValue nameValueCaddy = new NameValue();
		nameValueCaddy.setName(getSectionName(section));
		
		try {
				Type[] infoCaddyDetails = null;
				
				if (infoCaddyResponseList.get(0) instanceof List) {
					infoCaddyDetails = icmJsonMarshaller.icmInfoCaddyToType(infoCaddyResponseList.get(0));
				} else {
					infoCaddyDetails = icmJsonMarshaller.icmInfoCaddyToType(infoCaddyResponseList);
				}
				
				for (Type infoCaddyResponseType : infoCaddyDetails) {
										
					NameValue childrenNameValue = new NameValue();
					
					if (!StringUtils.isBlank(infoCaddyResponseType.getType()) && "group".equalsIgnoreCase(infoCaddyResponseType.getType())) {
						
						//Parse for Group
						addNameValueGroupEntry(nameValueCaddy, childrenNameValue, infoCaddyResponseType);
						
					} else	if (!StringUtils.isBlank(infoCaddyResponseType.getType()) && "propertyGroup".equalsIgnoreCase(infoCaddyResponseType.getType())) {
						
						childrenNameValue.setDesc("PropertyGroup");

						//Parse for PropertyGroup
						List<Type> propertyContentList = infoCaddyResponseType.getContent();
						
						
						if (propertyContentList != null && propertyContentList.size() > 0) {
							
							if (/*propertyContentList.size() == 1 && (*/"NIGO Info".equalsIgnoreCase(propertyContentList.get(0).getName()) /*|| "NIGO Reason(s)".equalsIgnoreCase(propertyContentList.get(0).getName()))*/) {
								addNameValueEntry(nameValueCaddy, childrenNameValue, propertyContentList.get(0));
							
							} else {
								
								for (Type propertyContent : propertyContentList) {
									NameValue propertyGroupChildrenNameValue = new NameValue();
									addNameValueEntry(childrenNameValue, propertyGroupChildrenNameValue, propertyContent);
								}
								
								//Add propertyGroup - properties
								nameValueCaddy.getChildrenNameValues().add(childrenNameValue);
							}
						}
						
					} else if (!StringUtils.isBlank(infoCaddyResponseType.getType()) && "property".equalsIgnoreCase(infoCaddyResponseType.getType())) {
											
							addNameValueEntry(nameValueCaddy, childrenNameValue, infoCaddyResponseType);
					}
			}
		} catch (Exception ex) {
			
			LOGGER.error("Error oruccred while processing InfoCaddy response", ex);
			throw new RuntimeException(ex);
		}
		
		LOGGER.info("Exiting mergeInfocaddyResponse(List<?> infoCaddyResponseList, String section) ");
		
		return nameValueCaddy;
	}
	

	private void addNameValueEntry(NameValue nameValue, NameValue childrenNameValue, Type type) throws Exception {
		
		LOGGER.info("Entering addNameValueEntry(NameValue nameValue, NameValue childrenNameValue, Type type) ");
		
		childrenNameValue.setName(type.getName());
		
		if (!StringUtils.isBlank(type.getName()) && (type.getName().equalsIgnoreCase("NIGO Info") || type.getName().equalsIgnoreCase("NIGO Reason(s)"))) {
			
			populateNigoInfo(nameValue, childrenNameValue, type);				
					
		}  else if ("Recent Cases".equalsIgnoreCase(type.getName())) {
			
			populateRecentCases(nameValue, childrenNameValue, type);				
					
		}  else if ("Repayment Details".equalsIgnoreCase(type.getName())) {
			
			populateRepaymentDetails(nameValue, childrenNameValue, type);				
					
		}  else if ("Omni Details".equalsIgnoreCase(type.getName())) {
			
			populateOmniDetails(nameValue, childrenNameValue, type);				
					
		}  else if ("File History".equalsIgnoreCase(type.getName())) {
			
			populateFileHistory(nameValue, childrenNameValue, type);				
					
		}  else if (type.getValue() != null && type.getValue() instanceof List) {
			
			List<String> listValues = this.icmJsonMarshaller.icmTypeValueToString(type.getValue());
			
			NameValue listChildNameValue = new NameValue();
			List<String> childValueList = new ArrayList<String>();
			
			if (listValues != null && listValues.size() > 0) {
				
				for (String str : listValues) {
					childValueList.add(str);
				}
				
				org.tiaa.esb.case_management_rs_v2.type.List nameValueList = new org.tiaa.esb.case_management_rs_v2.type.List();
				nameValueList.getItems().addAll(childValueList);
				listChildNameValue.setValueList(nameValueList);
			}				
			childrenNameValue.getChildrenNameValues().add(listChildNameValue);
			
		} else if (type.getValue() != null) {
					
			childrenNameValue.setValue(type.getValue().toString());
					
		}

		nameValue.getChildrenNameValues().add(childrenNameValue);
		
		LOGGER.info("Exiting addNameValueEntry(NameValue nameValue, NameValue childrenNameValue, Type type) ");
	}
	

	private void addNameValueGroupEntry(NameValue nameValueCaddy, NameValue childrenNameValue, Type type) throws Exception {
		
		LOGGER.info("Entering addNameValueGroupEntry(NameValue nameValueCaddy, NameValue childrenNameValue, Type type) ");
		
		childrenNameValue.setName(type.getName());
		childrenNameValue.setDesc("Group");
		if (type.getValue() != null) {
			childrenNameValue.setValue(type.getValue().toString());
		}
		
		List<Type> contentList = type.getContent();
		
		if (contentList != null && contentList.size() > 0) {
			for (Type content : contentList) {
				
				NameValue groupChildrenNameValue = new NameValue();
				
				if ("group".equalsIgnoreCase(content.getType())) {
					addNameValueGroupEntry(childrenNameValue, groupChildrenNameValue, content);
				
				} else	if ("property".equalsIgnoreCase(content.getType())) {
					addNameValueEntry(childrenNameValue, groupChildrenNameValue, content);
				
				} else	if ("propertyGroup".equalsIgnoreCase(content.getType())) {
					groupChildrenNameValue.setDesc("PropertyGroup");
					List<Type> propertyContentList = content.getContent();

					if (propertyContentList != null && propertyContentList.size() > 0) {
						for (Type propertyContent : propertyContentList) {
							NameValue propertyGroupChildrenNameValue = new NameValue();

							addNameValueEntry(groupChildrenNameValue, propertyGroupChildrenNameValue, propertyContent);
						}
						//Add group - propertyGroup if Content is present
						childrenNameValue.getChildrenNameValues().add(groupChildrenNameValue);
					}
				}
			}
		}
		//Add Group
		nameValueCaddy.getChildrenNameValues().add(childrenNameValue);
		
		LOGGER.info("Exiting addNameValueGroupEntry(NameValue nameValueCaddy, NameValue childrenNameValue, Type type) ");
	}
	
	
	/******* Processing Logics for special properties *****/
	/**
	 * NIGO Info Processing Logic
	 * @param nameValue
	 * @param childrenNameValue
	 * @param type
	 * @throws Exception
	 */
	private void populateNigoInfo(NameValue nameValue, NameValue childrenNameValue, Type type) throws Exception{

		//Set description null.
		//For PO, Nigo Info comes in PropertyGroup
		if (childrenNameValue != null && "propertyGroup".equalsIgnoreCase(childrenNameValue.getDesc())) {
			childrenNameValue.setDesc(null);
		} else {
			nameValue.setDesc(null);
		}
		
		//if(type.getName().equalsIgnoreCase("NIGO Reason(s)")){
		//	nameValue.setName("NIGO Info");
		//}
		
		childrenNameValue.setName(type.getName());
		
		Object value = type.getValue();
		
		List<NigoInfo> nigoInfoList = icmJsonMarshaller.icmTypeValueObjectToNigoInfo(value);
		
		String nigoedBy = null;
		String nigoedOn = null;
		
		if (nigoInfoList != null && nigoInfoList.size() > 0) {
			
			for (NigoInfo nigoInfo : nigoInfoList) {
				
				NameValue nigoChildrenNameValue = new NameValue();
				
				Map<String, List<String>> nigoReasons = nigoInfo.getReasons();
				nigoedBy = nigoInfo.getNigoedBy();
				nigoedOn = nigoInfo.getNigoedOn();
				
				if (nigoReasons != null && nigoReasons.size() > 0) {
					
					for (Map.Entry<String, List<String>> entry : nigoReasons.entrySet()) {
						NameValue nigoReasonsChildrenNameValue = new NameValue();
						
						//TBD: Need to check with UI for headers
						nigoReasonsChildrenNameValue.setName(entry.getKey());
//						if (!"noheader".equalsIgnoreCase(entry.getKey())) {
//							nigoReasonsChildrenNameValue.setName(entry.getKey());
//						}
						
						List<String> reasonList = entry.getValue();
						List<String> reasonItemList = new ArrayList<String>();
						
						if (reasonList != null && reasonList.size() > 0) {
							for (String reason: reasonList) {
								reasonItemList.add(reason);
							}
							
							org.tiaa.esb.case_management_rs_v2.type.List reasonNameValueList = new org.tiaa.esb.case_management_rs_v2.type.List();
							reasonNameValueList.getItems().addAll(reasonList);
							nigoReasonsChildrenNameValue.setValueList(reasonNameValueList);
							nigoChildrenNameValue.getChildrenNameValues().add(nigoReasonsChildrenNameValue);
						}
					}
				}
				
				//if(!type.getName().equalsIgnoreCase("NIGO Reason(s)")){
					
					NameValue nigoByChildrenNameValue = new NameValue();
					nigoByChildrenNameValue.setName("Nigo'ed By");
					if (nigoedBy != null) {

						org.tiaa.esb.case_management_rs_v2.type.List nigoByNameValueList = new org.tiaa.esb.case_management_rs_v2.type.List();
						nigoByNameValueList.getItems().addAll(Arrays.asList(nigoedBy));
						
						nigoByChildrenNameValue.setValueList(nigoByNameValueList);
					}
					
					nigoChildrenNameValue.getChildrenNameValues().add(nigoByChildrenNameValue);
					
					NameValue nigoOnChildrenNameValue = new NameValue();
					nigoOnChildrenNameValue.setName("Nigo'ed On");
					if (nigoedOn != null) {
						org.tiaa.esb.case_management_rs_v2.type.List nigoOnNameValueList = new org.tiaa.esb.case_management_rs_v2.type.List();
						nigoOnNameValueList.getItems().addAll(Arrays.asList(nigoedOn));
						
						nigoOnChildrenNameValue.setValueList(nigoOnNameValueList);
					}
					nigoChildrenNameValue.getChildrenNameValues().add(nigoOnChildrenNameValue);
					
				//}
				childrenNameValue.getChildrenNameValues().add(nigoChildrenNameValue);
			}
		}
	}
	
	/**
	 * Recent Cases Processing Logic
	 * @param nameValue
	 * @param childrenNameValue
	 * @param type
	 * @throws IOException
	 */
	private void populateRecentCases(NameValue nameValue, NameValue childrenNameValue, Type type) throws IOException {
		
		if (type.getValue() != null && type.getValue() instanceof List) {
			populateRecentCasesNameValue(childrenNameValue, type.getValue());
		} else {
			@SuppressWarnings("unchecked")
			Map<String, Object> recentCasesMap = (Map<String, Object>) icmJsonMarshaller.convertJsonToObject(type.getValue(), Map.class);
			if (recentCasesMap != null && recentCasesMap.size() > 0) {
				
				//childrenNameValue.getChildrenNameValues().add(prepareNameValue("Start", recentCasesMap.get("start") != null ? String.valueOf(recentCasesMap.get("start")) : ""));
				//childrenNameValue.getChildrenNameValues().add(prepareNameValue("End", recentCasesMap.get("end") != null ? String.valueOf(recentCasesMap.get("end")) : ""));
				childrenNameValue.getChildrenNameValues().add(prepareNameValue(CaseManagementConstants.TOTAL_RECORDS_COUNT, recentCasesMap.get("totalRecords") != null ? String.valueOf(recentCasesMap.get("totalRecords")) : "0"));
				populateRecentCasesNameValue(childrenNameValue, recentCasesMap.get("results"));
			}
		}
	}
	
	private void populateRecentCasesNameValue(NameValue childrenNameValue, Object recentCasesObj) throws IOException {
		
		List<RecentCases> recentCasesList = icmJsonMarshaller.icmInfoCaddyToRecentCases(recentCasesObj);
		if (recentCasesList != null && recentCasesList.size() > 0) {
			for (RecentCases recentCases : recentCasesList) {
				NameValue recentCasesNameValue = new NameValue();
				
				recentCasesNameValue.getChildrenNameValues().add(prepareNameValue("Case Id", recentCases.getCaseId()));
				recentCasesNameValue.getChildrenNameValues().add(prepareNameValue("Last Processed By", recentCases.getProcessed()));
				recentCasesNameValue.getChildrenNameValues().add(prepareNameValue("Status", recentCases.getStatus()));
				recentCasesNameValue.getChildrenNameValues().add(prepareNameValue("Date Created", recentCases.getCreated()));
				recentCasesNameValue.getChildrenNameValues().add(prepareNameValue("File Name", recentCases.getFileName()));
				
				childrenNameValue.getChildrenNameValues().add(recentCasesNameValue);
			}
		}
	}
	
	/**
	 * Repayment Details processing logic
	 * @param nameValue
	 * @param childrenNameValue
	 * @param type
	 * @throws IOException
	 */
	private void populateRepaymentDetails(NameValue nameValue, NameValue childrenNameValue, Type type) throws IOException {
		if (type.getValue() instanceof List) {
			parseRepaymentDetails(childrenNameValue, type.getValue());
			
		} else if (type.getValue() instanceof Map) {
			Map<String, Object> repaymentDetailsMap = icmJsonMarshaller.icmInfoCaddyToMap(type.getValue());
			
			if (repaymentDetailsMap != null && repaymentDetailsMap.size() > 0) {
				String key = "";
				for (Map.Entry<String, Object> entry : repaymentDetailsMap.entrySet()) {
					//NameValue key = new NameValue();
					//key.setDesc(entry.getKey());
					//childrenNameValue.getChildrenNameValues().add(key);
					key = entry.getKey();
					Map<String, Object> repaymentDetailMap = icmJsonMarshaller.icmInfoCaddyToMap(entry.getValue());
					if (repaymentDetailMap != null && repaymentDetailMap.size() > 0) {
						NameValue repaymentDetailMapNameValue = new NameValue();
						repaymentDetailMapNameValue.setName(key);
						repaymentDetailMapNameValue.getChildrenNameValues().add(prepareNameValue("Start", repaymentDetailMap.get("start") != null ? String.valueOf(repaymentDetailMap.get("start")) : ""));
						repaymentDetailMapNameValue.getChildrenNameValues().add(prepareNameValue("End", repaymentDetailMap.get("end") != null ? String.valueOf(repaymentDetailMap.get("end")) : ""));
						repaymentDetailMapNameValue.getChildrenNameValues().add(prepareNameValue("Total Records", repaymentDetailMap.get("totalRecords") != null ? String.valueOf(repaymentDetailMap.get("totalRecords")) : ""));
						
						parseRepaymentDetails(repaymentDetailMapNameValue, repaymentDetailMap.get("results"));
						
						childrenNameValue.getChildrenNameValues().add(repaymentDetailMapNameValue);
					}
				}
			}
		}		
	}
	
	private void parseRepaymentDetails(NameValue childrenNameValue, Object repaymentDetailsObj) throws IOException {
		if (repaymentDetailsObj != null) {
			List<RepaymentDetails> repaymentDetailsList = icmJsonMarshaller.icmInfoCaddyToRepaymentDetails(repaymentDetailsObj);
			
			if (repaymentDetailsList != null && repaymentDetailsList.size() > 0) {
				for (RepaymentDetails repaymentDetails : repaymentDetailsList) {
					NameValue repaymentDetailsNameValue = new NameValue();
					
					repaymentDetailsNameValue.getChildrenNameValues().add(prepareNameValue("Date", repaymentDetails.getDate()));
					repaymentDetailsNameValue.getChildrenNameValues().add(prepareNameValue("Amount", repaymentDetails.getAmount()));
					repaymentDetailsNameValue.getChildrenNameValues().add(prepareNameValue("Status", repaymentDetails.getStatus()));
					repaymentDetailsNameValue.getChildrenNameValues().add(prepareNameValue("Method", repaymentDetails.getMethod()));
					repaymentDetailsNameValue.getChildrenNameValues().add(prepareNameValue("OMNI Post Date", repaymentDetails.getOmniPostDate()));
					repaymentDetailsNameValue.getChildrenNameValues().add(prepareNameValue("Amount Big Decimal", repaymentDetails.getAmountBigDecimal()));
					repaymentDetailsNameValue.getChildrenNameValues().add(prepareNameValue("OMNI Info URL", prepareOmniInfoUrl(repaymentDetails.getOmniInfoUrl())));
					
					childrenNameValue.getChildrenNameValues().add(repaymentDetailsNameValue);
				}
			}
		}
	}
	
	/**
	 * OMNI Details Processing Logic
	 * @param nameValue
	 * @param childrenNameValue
	 * @param type
	 * @throws IOException
	 */
	private void populateOmniDetails(NameValue nameValue, NameValue childrenNameValue, Type type) throws IOException {
		List<OmniProcess> omniDetailsList = icmJsonMarshaller.icmInfoCaddyToOmniProcessDetails(type.getValue());
		
		if (omniDetailsList != null && omniDetailsList.size() > 0) {
			for (OmniProcess omniDetails : omniDetailsList) {
				NameValue omniDetailsNameValue = new NameValue();
				
				omniDetailsNameValue.getChildrenNameValues().add(prepareNameValue("Folder Name", omniDetails.getOmniFolderName()));
				omniDetailsNameValue.getChildrenNameValues().add(prepareNameValue("Trade Date", omniDetails.getOmniTradeDate()));
				omniDetailsNameValue.getChildrenNameValues().add(StringUtils.isNotBlank(omniDetails.getOmniSequenceNum()) ? prepareNameValue("Sequence Number", omniDetails.getOmniSequenceNum()) : null);
				omniDetailsNameValue.getChildrenNameValues().add(prepareNameValue("Status", omniDetails.getOmniStatus()));
				omniDetailsNameValue.getChildrenNameValues().add(prepareNameValue("Error Code", omniDetails.getOmniErrorCode()));
				
				omniDetailsNameValue.getChildrenNameValues().add(StringUtils.isNotBlank(omniDetails.getOmniRejectedBy()) ? prepareNameValue("RejectedBy", omniDetails.getOmniRejectedBy()) : null);
				omniDetailsNameValue.getChildrenNameValues().add(StringUtils.isNotBlank(omniDetails.getOmniRejectedOn()) ? prepareNameValue("RejectedOn", omniDetails.getOmniRejectedOn()) : null);
				omniDetailsNameValue.getChildrenNameValues().add(StringUtils.isNotBlank(omniDetails.getOmniRejectionReasons()) ? prepareNameValue("Rejection Reason(s)", omniDetails.getOmniRejectionReasons()) : null);
				omniDetailsNameValue.getChildrenNameValues().add(prepareNameValue("Fail Reason(s)", omniDetails.getFailReasons()));
				omniDetailsNameValue.getChildrenNameValues().add(StringUtils.isNotBlank(omniDetails.getDepartment()) ? prepareNameValue("Department", omniDetails.getDepartment()) : null);
				
				childrenNameValue.getChildrenNameValues().add(omniDetailsNameValue);
			}
		}
	}
	
	private void populateFileHistory(NameValue nameValue, NameValue childrenNameValue, Type type) throws IOException {
		Map<String, Object> fileHistoryMap = icmJsonMarshaller.icmInfoCaddyToMap(type.getValue());
		
		if (fileHistoryMap != null && fileHistoryMap.size() > 0) {
			for (Map.Entry<String, Object> entry : fileHistoryMap.entrySet()) {
				Object value = entry.getValue();
				if (value != null && value instanceof List) {
					childrenNameValue.getChildrenNameValues().add(prepareNameValueList(entry.getKey(), value));
				} else {
					childrenNameValue.getChildrenNameValues().add(prepareNameValue(entry.getKey(), String.valueOf(value)));
				}
			}
		}
	}
	
	private String getSectionName(String section){
		String sectionName = "";
		if (RequestSummarySection.GENERAL.getSection().equalsIgnoreCase(section)) {
			sectionName = RequestSummarySection.GENERAL.getSection();
		} else if (RequestSummarySection.OMNI.getSection().equalsIgnoreCase(section)) {
			sectionName = RequestSummarySection.OMNI.getSection();
		} else if (RequestSummarySection.QC.getSection().equalsIgnoreCase(section)) {
			sectionName = RequestSummarySection.QC.getSection();
		} else if (RequestSummarySection.FILEINFO.getSection().equalsIgnoreCase(section)) {
			sectionName = RequestSummarySection.FILEINFO.getSection();
		}
		return sectionName;
	}
	
	private NameValue prepareNameValue(String name, Object value) {
		NameValue nameValue = new NameValue();
		nameValue.setName(name);
		if (value != null) {
			nameValue.setValue(String.valueOf(value));
		}
		return nameValue;
	}
	
	private NameValue prepareNameValueList(String name, Object value) {
		@SuppressWarnings("unchecked")
		List<String> valueList = (List) icmJsonMarshaller.convertJsonToObject(value, List.class);
		NameValue nameValue = new NameValue();
		nameValue.setName(name);
		List<String> reasonItemList = new ArrayList<String>();
		if (valueList != null && valueList.size() > 0) {
			for (String reason: valueList) {
				reasonItemList.add(reason);
			}
			
			org.tiaa.esb.case_management_rs_v2.type.List nameValueList = new org.tiaa.esb.case_management_rs_v2.type.List();
			nameValueList.getItems().addAll(valueList);
			nameValue.setValueList(nameValueList);
		}
		return nameValue;
	}
	
	private String prepareOmniInfoUrl(String omniInfoUrl) {
		String omniLink = new StringBuilder(omniInfoUrl).delete(0, 6).toString();
		return new StringBuilder("/processes").append(omniLink).toString();
	}

}
