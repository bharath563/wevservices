package org.tiaa.case_management_rs.icm.helper;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.BooleanList;
import org.tiaa.esb.case_management_rs_v2.type.Document;
import org.tiaa.esb.case_management_rs_v2.type.Document.DocOriginator;
import org.tiaa.esb.case_management_rs_v2.type.Documents;
import org.tiaa.esb.case_management_rs_v2.type.Duration;
import org.tiaa.esb.case_management_rs_v2.type.EmailAttributes;
import org.tiaa.esb.case_management_rs_v2.type.Event;
import org.tiaa.esb.case_management_rs_v2.type.EventType;
import org.tiaa.esb.case_management_rs_v2.type.FromEmail;
import org.tiaa.esb.case_management_rs_v2.type.History;
import org.tiaa.esb.case_management_rs_v2.type.IntegerList;
import org.tiaa.esb.case_management_rs_v2.type.Metric;
import org.tiaa.esb.case_management_rs_v2.type.Metrics;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.ProcessID;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.Properties;
import org.tiaa.esb.case_management_rs_v2.type.RelatedTasks;
import org.tiaa.esb.case_management_rs_v2.type.RetentionType;
import org.tiaa.esb.case_management_rs_v2.type.SLADetail;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;
import org.tiaa.esb.case_management_rs_v2.type.Status;
import org.tiaa.esb.case_management_rs_v2.type.Statuses;
import org.tiaa.esb.case_management_rs_v2.type.Task;
import org.tiaa.esb.case_management_rs_v2.type.TaskResponse;
import org.tiaa.esb.case_management_rs_v2.type.Tasks;
import org.tiaa.esb.case_management_rs_v2.type.TimeList;
import org.tiaa.esb.case_management_rs_v2.type.ToEmail;
import org.tiaa.esb.icm.types.Case;
import org.tiaa.esb.icm.types.FormatType;
import org.tiaa.esb.icm.types.IntegrationLink;
import org.tiaa.esb.icm.types.RelatedCase;
import org.tiaa.esb.icm.types.ResponseList;
import org.tiaa.esb.icm.types.Step;
import org.tiaa.esb.icm.types.StepElementDataField;
import org.tiaa.esb.icm.types.StepElementHeaderField;
import org.tiaa.esb.icm.types.StepList;
import org.tiaa.esb.icm.types.infocaddy.NigoInfo;
import org.tiaa.esb.icm.types.infocaddy.OmniProcess;
import org.tiaa.esb.icm.types.infocaddy.RecentCases;
import org.tiaa.esb.icm.types.infocaddy.RepaymentDetails;
import org.tiaa.esb.icm.types.infocaddy.Type;


/*this controller is build to get the process from ICM layer*/
@Component
public class ICMJsonUnmarshaller {
	private static ObjectMapper objectMapper = new ObjectMapper();
	
	public ICMJsonUnmarshaller(){
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		objectMapper.setDateFormat(DateUtil.DF_WITH_MILLISECONDS);
	}
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ICMJsonUnmarshaller.class);

	public Processes icmStepsToProcesses(List<StepList> icmResponseList){
		Processes processes = new Processes();

			for (Object objectJSON : icmResponseList) {
				StepList stepList = (StepList) convertJsonToObject(objectJSON, StepList.class);

				if (stepList != null && stepList.getSteps() != null) {
					for (Step step : stepList.getSteps()) {
						try{
							Process process = new Process();
							process.setProcessId(step.getCaseId());
							
							Task task = new Task();
							task.setID(step.getTaskId());
							task.setWobId(step.getWobId());
							task.setLocked(step.isLocked());
							task.setLockedBy(step.getLockedby());
							
							//setting create date time
							task.setCreateDate(DateUtil.toXMLGregorianCalendarDateOnly(step.getStepCreateTime()));
							task.setCreateTime(DateUtil.toXMLGregorianCalendarTimeOnly(step.getStepCreateTime()));
							
							org.tiaa.esb.case_management_rs_v2.type.List queueNames = new org.tiaa.esb.case_management_rs_v2.type.List();
							queueNames.getItems().add(step.getQueueName());
							task.setQueues(queueNames);
	
							Statuses statuses = new Statuses();
							Status status = new Status();
							status.setSts(step.getStatus().getStatus());
							statuses.getSts().add(status);
							task.setStatusHistory(statuses);
							
							if(step.getStatus().getStatus() != null && step.getStatus().getStatus().equalsIgnoreCase(CaseManagementConstants.ICM_SUSPENDED)){
								if(step.getWakeDateTime() != null){
									try{
										String[] awakeDateTime = step.getWakeDateTime().split("\\s", 2);
										String awakeDate = awakeDateTime[0];
										String awakeTime = awakeDateTime[1];
										task.setAwakeDate(DateUtil.convertDate(awakeDate,"MM/dd/yyyy"));
										task.setAwakeTime(DateUtil.convertTime(awakeTime));
									}catch(Exception e){
										LOGGER.error("Exception while converting Awake Date Time:"+ step.getWakeDateTime());
									}
								}else{
									LOGGER.error("Invalid awake date time from ICM:"+ step.getWakeDateTime());
								}
							}
							
							Properties properties = new Properties();
							for (StepElementHeaderField headerFields : step.getHeaderFields()) {
								NameValue nameValue = new NameValue();
								nameValue.setName(headerFields.getName());
								nameValue.setValue(headerFields.getValue());
	
								properties.getProperties().add(nameValue);
							}
							task.setTaskProperties(properties);
							Tasks tasks = new Tasks();
							tasks.getTasks().add(task);
							process.setTasks(tasks);
							process.setAppName(CaseManagementConstants.APP_ICM);
							
							if(step.getSlaDetail() != null){
								SLADetail stepSLA = new SLADetail();
								
								if(step.getSlaDetail().getOriginalSla() != null){
									Duration origSLADur = new Duration();
									origSLADur.setDays(step.getSlaDetail().getOriginalSla().getDays());
									origSLADur.setHours(step.getSlaDetail().getOriginalSla().getHours());
									origSLADur.setMinutes(step.getSlaDetail().getOriginalSla().getMinutes());
									stepSLA.setOriginalSLA(origSLADur);
								}
								
								if(step.getSlaDetail().getRemainingSla() != null){
									Duration remainingSLADur = new Duration();
									remainingSLADur.setDays(step.getSlaDetail().getRemainingSla().getDays());
									remainingSLADur.setHours(step.getSlaDetail().getRemainingSla().getHours());
									remainingSLADur.setMinutes(step.getSlaDetail().getRemainingSla().getMinutes());
									stepSLA.setRemainingSLA(remainingSLADur);
								}
								
								if(step.getSlaDetail().getTimeElapsed() != null){
									stepSLA.setTimeElaspsed(step.getSlaDetail().getTimeElapsed());
								}
								process.setSLADetail(stepSLA);
							}
							processes.getProcesses().add(process);
						}catch(Exception e){
							LOGGER.error("Exception while creating Process from Step:"+e.getMessage());
						}
					}
				}
			}
		
		return processes;
	}
	
	public Documents icmDocumentsToCM(String caseId, ResponseList icmDocumentsResponse) {
		Documents cmrsDocuments = new Documents();
		List<Document> rsvDocumentList = new ArrayList<Document>();
		
		List<org.tiaa.esb.icm.types.Document> icmDocumentsList = (List<org.tiaa.esb.icm.types.Document>) icmDocumentsResponse.getResults();
	
		if(icmDocumentsList != null && icmDocumentsList.size() > 0){
			for (Object icmDocumentsResponseJSON : icmDocumentsList) {
				org.tiaa.esb.icm.types.EmailDocument documentFromICM = (org.tiaa.esb.icm.types.EmailDocument) 
						convertJsonToObject(icmDocumentsResponseJSON, org.tiaa.esb.icm.types.EmailDocument.class);
				try{
					if(documentFromICM != null){
						Document rsvDocument = new Document();
						if(documentFromICM.getDocInstanceId() !=null){
							rsvDocument.setDocTemplateCd(documentFromICM.getDocInstanceId());
						}
						rsvDocument.setRetentionType(RetentionType.fromValue(documentFromICM.getRetentionType()));
						rsvDocument.setDocBizUnit(documentFromICM.getBusinessUnit());
						rsvDocument.setDocTyp(documentFromICM.getDocCode());
						rsvDocument.setDocName(documentFromICM.getDocumentName());
						rsvDocument.setLgcFold(documentFromICM.getFolder());
						rsvDocument.setFrmtTyp(documentFromICM.getFormatType());
			
						// Populate EmailAttributes if format type is MobiusEmail
						if (documentFromICM.getFormatType() != null
								&& documentFromICM.getFormatType().equalsIgnoreCase(FormatType.MobiusEmail.toString())) {
							
							EmailAttributes emailAttributes = new EmailAttributes();
							FromEmail fromEmail = new FromEmail();
							ToEmail toEmail = new ToEmail();
			
							fromEmail.getEmails().add(documentFromICM.getFromEmailAddress());
							toEmail.getEmails().add(documentFromICM.getToEmailAddress());
							emailAttributes.setFromEmail(fromEmail);
							emailAttributes.setToEmail(toEmail);
							emailAttributes.setSubj(documentFromICM.getSubjectLine());
							rsvDocument.setEmailAttributes(emailAttributes);
			
							if (CommonUtil.isNotNullAndNotEmpty(documentFromICM.getSentOn())) {
								rsvDocument.setSentDTTM(DateUtil.toXMLGregorianCalendar(
										DateUtil.parseDateTimeForMobiusFormat(documentFromICM.getSentOn())));
							}
						}
						rsvDocument.setDocID(documentFromICM.getId());
						rsvDocument.setDocIDTyp(documentFromICM.getIdtype());
						rsvDocument.setMimeTyp(documentFromICM.getMimeType());
						rsvDocument.setDocURL(documentFromICM.getDocUrl());
			
						if (CommonUtil.isNotNullAndNotEmpty(documentFromICM.getVersion())) {
							rsvDocument.setDocVrsn(Integer.valueOf(documentFromICM.getVersion()));
						}
			
						DocOriginator docOriginator = new DocOriginator();
						docOriginator.setDocOrigName(documentFromICM.getCreatedBy());
						rsvDocument.setDocOriginator(docOriginator);
						rsvDocument.setDocCreateDateTime(DateUtil.toXMLGregorianCalendar(
								DateUtil.parseDateTimeWithMilliseconds(documentFromICM.getCreatedDate())));
			
						ProcessID processID = new ProcessID();
						processID.setRqstID(caseId);
						rsvDocument.setProcessID(processID);
			
						rsvDocumentList.add(rsvDocument);
					}
				}catch(Exception e){
					LOGGER.error("Exception while creating CMRSV2 Document from ICM Document:"+e.getMessage());
				}
			}
			cmrsDocuments.getDocuments().addAll(rsvDocumentList);
		}
		return cmrsDocuments;
	}

	public Case icmCaseToProcess(Case caseResponse, Process process){
		Properties icmProperties = new Properties();

		Case icmCaseResponse = (Case) convertJsonToObject(caseResponse, Case.class);
		try{
			if(icmCaseResponse != null){
				Statuses statuses = new Statuses();
				Status status = new Status();
		
				process.setAppName("ICM");
				process.setProcessId(icmCaseResponse.getId());
				process.setProcessType(icmCaseResponse.getType());
				status.setSts(icmCaseResponse.getStatus());
				statuses.getSts().add(status);
				process.setStatusHistory(statuses);
		
				NameValue nameValueChannel = new NameValue();
				nameValueChannel.setDesc("channel");
				nameValueChannel.setValue(icmCaseResponse.getChannel());
				icmProperties.getProperties().add(nameValueChannel);
		
				NameValue nameValuePathName = new NameValue();
				nameValuePathName.setDesc("pathName");
				nameValuePathName.setValue(icmCaseResponse.getPathName());
				icmProperties.getProperties().add(nameValuePathName);
		
				if (StringUtils.isNotBlank(icmCaseResponse.getCreatedDate())) {
					NameValue nameValueCreatedDateTime = new NameValue();
					nameValueCreatedDateTime.setDesc("createdDate");
					nameValueCreatedDateTime.setDateValue(DateUtil
							.toXMLGregorianCalendar(DateUtil
									.parseDateTimeWithoutMilliseconds(icmCaseResponse
											.getCreatedDate())));
		
					icmProperties.getProperties().add(nameValueCreatedDateTime);
				}
		
				if (StringUtils.isNotBlank(icmCaseResponse.getRequestReceivedDate())) {
					NameValue nameValueRequestReceivedDateTime = new NameValue();
					nameValueRequestReceivedDateTime.setDesc("requestReceivedDate");
					nameValueRequestReceivedDateTime.setDateValue(DateUtil
							.toXMLGregorianCalendar(DateUtil
									.parseDateTimeWithoutMilliseconds(icmCaseResponse.getRequestReceivedDate())));
		
					icmProperties.getProperties().add(nameValueRequestReceivedDateTime);
				}
		
				if (StringUtils.isNotBlank(icmCaseResponse.getModifiedDate())) {
					NameValue nameValueModifiedDateTime = new NameValue();
					nameValueModifiedDateTime.setDesc("modifiedDate");
					nameValueModifiedDateTime.setDateValue(DateUtil
							.toXMLGregorianCalendar(DateUtil
									.parseDateTimeWithoutMilliseconds(icmCaseResponse.getModifiedDate())));
		
					icmProperties.getProperties().add(nameValueModifiedDateTime);
				}
		
				// Map all the additional identifiers.
		
				HashMap<String, Object> additionalIdentifiers = icmCaseResponse.getAdditionalIdentifiers();
		
				if (additionalIdentifiers != null) {
					for (String key : additionalIdentifiers.keySet()) {
						NameValue nameValue = new NameValue();
						nameValue.setDesc(key);
						Object entryValue = additionalIdentifiers.get(key);
						if (String.class.isInstance(entryValue)) {
							nameValue.setValue((String) entryValue);
						} else if (Integer.class.isInstance(entryValue)) {
							nameValue.getNumValue().add(BigInteger.valueOf(((Integer) entryValue).longValue()));
						} else if (Boolean.class.isInstance(entryValue)) {
							nameValue.setBooleanValue((Boolean) entryValue);
						} else if (Float.class.isInstance(entryValue)) {
							nameValue.setDecimalValue(BigDecimal.valueOf(((Float) entryValue).floatValue()));
						} else if (Date.class.isInstance(entryValue)) {
							nameValue.setDateValue(DateUtil.toXMLGregorianCalendar(((Date) entryValue)));
						} else if (Double.class.isInstance(entryValue)) {
							nameValue.setDecimalValue(BigDecimal.valueOf(((Double) entryValue)));
						}
						icmProperties.getProperties().add(nameValue);
					}
				}
			}
		}catch(Exception e){
			LOGGER.error("Exception while creating Process from Case:"+e.getMessage());
		}
		process.setProcessProperties(icmProperties);
		return icmCaseResponse;

	}
	
	public Process icmRelatedCasesToRelatedTasks(List<RelatedCase> relatedCasesList){
		Process process = new Process();
		RelatedTasks relatedTasks = new RelatedTasks();
		
		if (relatedCasesList != null && !relatedCasesList.isEmpty()) {
			for (Object icmTaskResponseJSON : relatedCasesList) {
				RelatedCase icmRelatedCaseResponse = (org.tiaa.esb.icm.types.RelatedCase) convertJsonToObject(icmTaskResponseJSON, RelatedCase.class);

				try{
					if(icmRelatedCaseResponse != null){
						Task cmsTask = new Task();
		
						cmsTask.setID(icmRelatedCaseResponse.getCaseId());
						cmsTask.setType(icmRelatedCaseResponse.getCaseType());
		
						if (icmRelatedCaseResponse.getCreatedDate() != null) {
							cmsTask.setCreateDate(DateUtil.toXMLGregorianCalendarDateOnly(DateUtil
									.parseDateTimeWithMilliseconds((DateUtil.DF_WITH_MILLISECONDS
											.format(icmRelatedCaseResponse.getCreatedDate())))));
							
							cmsTask.setCreateTime(DateUtil.toXMLGregorianCalendarTimeOnly(DateUtil
									.parseDateTimeWithMilliseconds((DateUtil.DF_WITH_MILLISECONDS
											.format(icmRelatedCaseResponse.getCreatedDate())))));
						}
						if (icmRelatedCaseResponse.getCompletedDate() != null) {
							cmsTask.setCompleteDate(DateUtil.toXMLGregorianCalendarDateOnly(DateUtil
									.parseDateTimeWithMilliseconds((DateUtil.DF_WITH_MILLISECONDS
											.format(icmRelatedCaseResponse.getCompletedDate())))));
							
							cmsTask.setCompleteTime(DateUtil.toXMLGregorianCalendarTimeOnly(DateUtil
									.parseDateTimeWithMilliseconds((DateUtil.DF_WITH_MILLISECONDS
											.format(icmRelatedCaseResponse.getCompletedDate())))));
						}
		
						Statuses statuses = new Statuses();
						Status status = new Status();
						status.setSts(icmRelatedCaseResponse.getCaseStatus());
						statuses.getSts().add(status);
						cmsTask.setStatusHistory(statuses);
		
						Properties icmProperties = new Properties();
						NameValue nameValueChannel = new NameValue();
						nameValueChannel.setDesc("confirmation");
						nameValueChannel.setValue(icmRelatedCaseResponse.getConfirmation());
						icmProperties.getProperties().add(nameValueChannel);
		
						// NameValue nameValueChannel2 = new NameValue();
						// nameValueChannel2.setDesc("pathName");
						// nameValueChannel2.setValue(icmRelatedCaseResponse.getPathName());
						// icmProperties.getProperties().add(nameValueChannel2);
		
						cmsTask.setTaskProperties(icmProperties);
		
						relatedTasks.getRelatedTasks().add(cmsTask);
						process.setRelatedTasks(relatedTasks);
					}
				}catch(Exception e){
					LOGGER.error("Exception while creating Related Task from ICM Related Case:"+e.getMessage());
				}
			}
			
		}

		return process;
	}
	
	@SuppressWarnings("unchecked")
	public Object convertJsonToObject(Object icmResponseJSON, Class toClass) {
		Object convertedObject = new Object();
		try {
			convertedObject = objectMapper.convertValue(icmResponseJSON, toClass);
		} catch (Exception e) {
			LOGGER.debug("Exception while converting Object received from ICM to Object Model, Exception:" + e.getMessage());
		}
		return convertedObject;
	}
	


	public TaskResponse icmStepToTask(Step icmStep) {
		TaskResponse taskResponse = new TaskResponse();		
		try {
				Properties properties = new Properties();
				Task task = new Task();
				task.setID(icmStep.getTaskId());
				task.setWobId(icmStep.getWobId());
				task.setLocked(icmStep.isLocked());
				task.setLockedBy(icmStep.getLockedby());
				task.setMode(icmStep.getMode());
				org.tiaa.esb.case_management_rs_v2.type.List queueNames = new org.tiaa.esb.case_management_rs_v2.type.List();
				queueNames.getItems().add(icmStep.getQueueName());
				task.setQueues(queueNames);
				
				if(icmStep.getAction() != null && !icmStep.getAction().isEmpty()){
					org.tiaa.esb.case_management_rs_v2.type.List actionList = new org.tiaa.esb.case_management_rs_v2.type.List();
					for(String action: icmStep.getAction()){
						actionList.getItems().add(action);
					}
					task.setAction(actionList);
				}
				
				Statuses statuses = new Statuses();
				Status status = new Status();
				if(icmStep.getStatus() != null){
					status.setSts(icmStep.getStatus().getStatus());
				}
				statuses.getSts().add(status);
				task.setStatusHistory(statuses);
				
				if(null != icmStep.getFields()){
					for (StepElementDataField dataField : icmStep.getFields()) {
						NameValue nameValue = populateNameValues(dataField);			
						properties.getProperties().add(nameValue);
					}
				}
				
				if(icmStep.getIntegrationLinks() != null && icmStep.getIntegrationLinks().size() > 0){
					for(IntegrationLink iLink : icmStep.getIntegrationLinks()){
						NameValue nameValue = new NameValue();
						nameValue.setID(iLink.getId());
						nameValue.setName(iLink.getName());
						if(!StringUtils.isEmpty(iLink.getValue())){
							nameValue.setValue("<![CDATA[" + iLink.getValue() + "]]>");
						}
						properties.getProperties().add(nameValue);
					}
				}
				task.setTaskProperties(properties);
				taskResponse.setTask(task);
		} catch (Exception e) {
			LOGGER.debug("Exception while converting Step to Task, Exception: "+ e.getMessage());
		}
		return taskResponse;
	}

	private NameValue populateNameValues(StepElementDataField dataField) {
		NameValue nameValue = new NameValue();
		try{
			if(!StringUtils.isEmpty(dataField.getMode()) && dataField.getMode().equalsIgnoreCase("Read/Write")){
				nameValue.setValUpdtFlg(true);
			}else{
				nameValue.setValUpdtFlg(false);
			}
			
			nameValue.setDesc(dataField.getName());
			nameValue.setName(dataField.getName());
			nameValue.setID(dataField.getId());
			switch (dataField.getType()) {
				case "String":
					nameValue.setValue((String) getValue(dataField));
					break;
				case "Integer":
					nameValue.setNumValue(BigInteger.valueOf(Long.parseLong((String) getValue(dataField))));
					break;
				case "Boolean":
					nameValue.setBooleanValue(new Boolean((String)getValue(dataField)));
					break;
				case "Float":
					String value = (String) getValue(dataField);
					nameValue.setDecimalValue(new BigDecimal(value.replaceAll(",", "")));
					break;
				case "Time":
					XMLGregorianCalendar xmlGregDate = null;
					if(getValue(dataField) != null){
						String date = (String) getValue(dataField);
						if(!StringUtils.isEmpty(date)){
							xmlGregDate = DateUtil
								.toXMLGregorianCalendar(DateUtil
										.parseDateTimeWithoutMilliseconds(date));
						}
					}
					nameValue.setDateValue(xmlGregDate);
					break;
				case "String[]":
					List<String> strList = (List<String>) getValueList(dataField);
					org.tiaa.esb.case_management_rs_v2.type.List stringsList = new org.tiaa.esb.case_management_rs_v2.type.List();
					stringsList.getItems().addAll(strList);
					nameValue.setValueList(stringsList);
					break;
				case "Integer[]":
					List<String> list = (List<String>) getValueList(dataField);
					IntegerList integersList = new IntegerList();
					for(String str: list){
						integersList.getItems().add(BigInteger.valueOf(Long.parseLong(str)));
					}
					nameValue.setIntegerList(integersList);
					break;
				case "Boolean[]":
					List<String> boolList = (List<String>) getValueList(dataField);
					BooleanList booleanList = new BooleanList();
					for(String str: boolList){
						booleanList.getItems().add(new Boolean(str));
					}
					nameValue.setBoolList(booleanList);
					break;
				case "Time[]":
					List<String> datesList = (List<String>) getValueList(dataField);	
					TimeList timeList = null;
					if(datesList != null){
						timeList = new TimeList();
						for(String inputDate : datesList){
							timeList.getItems().add(DateUtil
									.toXMLGregorianCalendar(DateUtil
											.parseDateTimeWithoutMilliseconds(inputDate)));
						}
					}
					nameValue.setTimeList(timeList);
					break;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return nameValue;
	}

	private List<?> getValueList(StepElementDataField dataField) {
		List<?> valueList = dataField.getValue();
		List<Object> objectList = new ArrayList<Object>();
		if(valueList != null && valueList.size() > 0){
			for(Object object:valueList){
				objectList.add(object);
			}
		}
		
		return objectList;
	}

	private Object getValue(StepElementDataField dataField) {
		List<?> valuesList = getValueList(dataField);
		Object object = null;
		if(valuesList != null && valuesList.size() > 0){
			object = valuesList.get(0);
		}
		return object;
	}
	
	public Process icmEventToHistory(List<org.tiaa.esb.icm.types.Event> icmEvents, int totalRecords) {

		Process process = new Process();
		History history = null;

		if (icmEvents != null && !icmEvents.isEmpty()) {
			List<Event> eventList = new ArrayList<Event>();
			history = new History();
			
			NameValue nameValue = new NameValue();
			nameValue.setName(CaseManagementConstants.TOTAL_RECORDS_COUNT);
			nameValue.setValue(""+totalRecords);
			Properties properties = new Properties();
			properties.getProperties().add(nameValue);
			process.setProcessProperties(properties);
			for (Object icmHistoryResponseJSON : icmEvents) {
				try {
					org.tiaa.esb.icm.types.Event icmEventResponse = (org.tiaa.esb.icm.types.Event) convertJsonToObject(icmHistoryResponseJSON, org.tiaa.esb.icm.types.Event.class);
					
					EventType type = EventType.fromValue(icmEventResponse.getType());
					
					Event event = new Event();
					event.setEventType(type);
					event.setTitle(icmEventResponse.getTitle());
					event.setDescription(icmEventResponse.getDescription());
					event.setCreatedBy(icmEventResponse.getCreatedBy());
			 		
					if(icmEventResponse.getCreatedOn() != null){
						event.setCreateDateTime(DateUtil.toXMLGregorianCalendarDateTime(DateUtil
								.parseDateTimeWithMilliseconds((DateUtil.DF_WITH_MILLISECONDS
										.format(icmEventResponse.getCreatedOn())))));
					}
					
					eventList.add(event);
				} catch (Exception e) {
					LOGGER.debug("Exception while converting ICMEvents to CMRSV2 History Events:"+ e.getMessage());
				}
			}
			history.getEvents().addAll(eventList);
			process.setHistory(history);
		}
		return process;
	}	
	
	public List<NigoInfo> icmTypeValueObjectToNigoInfo(Object value){
		
		List<NigoInfo> nigoInfoList = new ArrayList<NigoInfo>();
		NigoInfo nigoinfo = null;
		
		if(value != null){
			
			List<NigoInfo> icmNigoInfoList = (List<NigoInfo>) value;
			
			for(Object nigoInfoJSON : icmNigoInfoList){
				
				try{
						nigoinfo = (NigoInfo) convertJsonToObject(nigoInfoJSON, NigoInfo.class);
						nigoInfoList.add(nigoinfo);
						
				}catch (Exception e) {
					
						LOGGER.debug("Exception while converting ICMNigoObjects to NIGO Object:"+ e.getMessage());
						
				}
				
			}
		}

		return nigoInfoList;
		
	}
	
	public Type[] icmInfoCaddyToType(Object object){		
		return (Type[]) convertJsonToObject(object, Type[].class);
		
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, Object> icmInfoCaddyToMap(Object object) {
		return (Map) convertJsonToObject(object, Map.class);

	}
	
	@SuppressWarnings("unchecked")
	public List<RecentCases> icmInfoCaddyToRecentCases(Object recentCasesObj) throws IOException {
		List<RecentCases> recentCasesList = new ArrayList<RecentCases>();
		RecentCases recentCases = null;
		
		if (recentCasesObj != null) {
			List<RecentCases> icmRecentCasesList = (List<RecentCases>) recentCasesObj;
			for (Object recentCasesJSON : icmRecentCasesList) {
				try{
					recentCases = (RecentCases) convertJsonToObject(recentCasesJSON, RecentCases.class);
					recentCasesList.add(recentCases);					
				} catch (Exception e) {
					LOGGER.error("Exception while converting recentCasesObj to RecentCases Object:"+ e.getMessage());
					throw e;
				}
			}
		}
		return recentCasesList;
	}
	
	@SuppressWarnings("unchecked")
	public List<RepaymentDetails> icmInfoCaddyToRepaymentDetails(Object repaymentDetailsObj) throws IOException {
		List<RepaymentDetails> repaymentDetailsList = new ArrayList<RepaymentDetails>();
		RepaymentDetails repaymentDetails = null;
		
		if (repaymentDetailsObj != null) {
			List<RepaymentDetails> icmRepaymentDetailsList = (List<RepaymentDetails>) repaymentDetailsObj;
			for (Object repaymentDetailsJSON : icmRepaymentDetailsList) {
				try{
					repaymentDetails = (RepaymentDetails) convertJsonToObject(repaymentDetailsJSON, RepaymentDetails.class);
					repaymentDetailsList.add(repaymentDetails);					
				} catch (Exception e) {
					LOGGER.error("Exception while converting repaymentDetailsObj to RepaymentDetails Object:"+ e.getMessage());
					throw e;
				}
			}
		}
		return repaymentDetailsList;
		//String recentCasesJSONString = ICMJsonUnmarshaller.objectMapper.writeValueAsString(repaymentDetails);
		//return ICMJsonUnmarshaller.objectMapper.readValue(recentCasesJSONString, org.tiaa.esb.icm.types.infocaddy.RepaymentDetails[].class);
	}
	
	@SuppressWarnings("unchecked")
	public List<OmniProcess> icmInfoCaddyToOmniProcessDetails(Object omniDetailsObj) throws IOException {
		List<OmniProcess> omniDetailsList = new ArrayList<OmniProcess>();
		OmniProcess omniDetails = null;
		
		if (omniDetailsObj != null) {
			List<OmniProcess> icmOmniDetailsList = (List<OmniProcess>) omniDetailsObj;
			for (Object repaymentDetailsJSON : icmOmniDetailsList) {
				try{
					omniDetails = (OmniProcess) convertJsonToObject(repaymentDetailsJSON, OmniProcess.class);
					omniDetailsList.add(omniDetails);					
				} catch (Exception e) {
					LOGGER.error("Exception while converting omniDetailsObj to OmniProcess Object:"+ e.getMessage());
					throw e;
				}
			}
		}
		return omniDetailsList;
		//String omniDetailsJSONString = ICMJsonUnmarshaller.objectMapper.writeValueAsString(omniDetails);
		//return ICMJsonUnmarshaller.objectMapper.readValue(omniDetailsJSONString, org.tiaa.esb.icm.types.infocaddy.OmniProcess[].class);
	}
	
	public List<String> icmTypeValueToString(Object value){
		
		List<String> valueList = new ArrayList<String>();
		
		if(null != value){
			valueList = (List<String>) convertJsonToObject(value, List.class);
		}
		
		return valueList;
	}

	public Metrics icmMetricsToMetrics(Map<String, Map<String, Integer>> icmMetrics) {
		Metrics metrics = new Metrics();
		try{
		 for (Entry<String, Map<String, Integer>> entry : icmMetrics.entrySet()){
			 String metricName = entry.getKey();
		 	Map<String, Integer> metricMap = entry.getValue();
			List<Metric> metricList = new ArrayList<Metric>();
			for (Entry<String, Integer> metricEntry : metricMap.entrySet()){
				Metric metric = new Metric();
				String fieldName = metricEntry.getKey();
				Integer count = metricEntry.getValue();
				LOGGER.debug("Metric Name :" + metricName + ",fieldName :"+ fieldName +",Count : " + count);
				if(fieldName != null && fieldName.equalsIgnoreCase("AwakeToday")){
					metric.setFieldName(fieldName);
				}else{
					metric.setFieldName(metricName);
				}
				
				if(count != null){
					metric.setFieldValue(String.valueOf(count));
				}
				metricList.add(metric);
			}
			metrics.getMetrics().addAll(metricList);
		}
		}catch(Exception e){
			LOGGER.error("Exception while converting ICM metrics to CMRSV2 Metrics:"+e.getMessage());
		}
		return metrics;
	}
	public Step tasksToIcmSteps(Task task) {
		Step step = new Step();
		if (task != null) {

			step.setTaskId(task.getID());
			step.setWobId(task.getWobId());
			
			boolean assignFlag = false;
			if(task.getAction().getItems() != null && task.getAction().getItems().size() > 0){
				String action = task.getAction().getItems().get(0);
				if("assign".equalsIgnoreCase(action)){
					assignFlag = true;
					step.setReassignRacfId(task.getAssignedTo());
				}
				step.setAction(Arrays.asList(action));
			}

			String queuName = task.getQueues().getItems().get(0);
			step.setQueueName(queuName);

			if ((!assignFlag) && (task.getTaskProperties() != null) && (task.getTaskProperties().getProperties() != null)){
				List<StepElementDataField> fieldList = new ArrayList<StepElementDataField>();
				List<NameValue> nameValuesList = task.getTaskProperties().getProperties();
				for (NameValue nameValue : nameValuesList) {
					StepElementDataField field = new StepElementDataField();
					field.setId(nameValue.getID());
					field.setName(nameValue.getName());
					if(nameValue.isValUpdtFlg()){
						field.setMode(CaseManagementConstants.ICM_CASE_READ_WRITE_MODE);
					}else{
						field.setMode(CaseManagementConstants.ICM_CASE_READ_MODE);
					}
					if(!StringUtils.isEmpty(nameValue.getValue())){
						List<String> valueList=new ArrayList<String>();
						field.setType("String");
						valueList.add(nameValue.getValue().toString());
						field.setValue(valueList);
					} else if(null != nameValue.getNumValue()){
						List<String> valueList=new ArrayList<String>();
						field.setType("Integer");
						valueList.add(nameValue.getNumValue().toString());
						field.setValue(valueList);
					} else if(null!=nameValue.isBooleanValue()){
						List<String> valueList=new ArrayList<String>();
						field.setType("Boolean");
						valueList.add(nameValue.isBooleanValue().toString());
						field.setValue(valueList);
					}else if(null!=nameValue.getDecimalValue()){
						field.setType("Float");
						List<String> valueList=new ArrayList<String>();
						valueList.add(nameValue.getDecimalValue().toString());
						field.setValue(valueList);
					} else if(null!=nameValue.getDateValue()){
						List<String> valueList=new ArrayList<String>();
						field.setType("Time");
						valueList
						.add(DateUtil.getStringDatefromXMLGregorianDate(
								nameValue.getDateValue(),
								DateUtil.DATE_FORMAT_WITHOUT_MILLISECONDS));
	
						field.setValue(valueList);
					} else if(null!=nameValue.getValueList()){
						List<String> valueList=new ArrayList<String>();
						field.setType("String[]");
						org.tiaa.esb.case_management_rs_v2.type.List listOfValues = nameValue.getValueList();
						List<String> strList = listOfValues.getItems();
						if(strList != null && strList.size() > 0){
							for(String str: strList){
								valueList.add(str);
							}
						}
						field.setValue(valueList);
					}else if(null != nameValue.getIntegerList()){
						List<String> valueList=new ArrayList<String>();
						field.setType("Integer[]");
						org.tiaa.esb.case_management_rs_v2.type.IntegerList listOfValues = nameValue.getIntegerList();
						List<BigInteger> bigIntList = listOfValues.getItems();
						if(bigIntList != null && bigIntList.size() > 0){
							for(BigInteger bigInt: bigIntList){
								valueList.add(String.valueOf(bigInt));
							}
						}
						field.setValue(valueList);
					} else if(null != nameValue.getBoolList()){
						List<String> valueList=new ArrayList<String>();
						field.setType("Boolean[]");
						org.tiaa.esb.case_management_rs_v2.type.BooleanList listOfBoolValues = nameValue.getBoolList();
						List<Boolean> boolList = listOfBoolValues.getItems();
						if(boolList != null && boolList.size() > 0){
							for(Boolean bool: boolList){
								valueList.add(String.valueOf(bool));
							}
						}
						field.setValue(valueList);
					} else if(null != nameValue.getTimeList()){
						List<String> valueList=new ArrayList<String>();
						field.setType("Time[]");
						org.tiaa.esb.case_management_rs_v2.type.TimeList listOfDateValues = nameValue.getTimeList();
						List<XMLGregorianCalendar> datesList = listOfDateValues.getItems();
						if(datesList != null && datesList.size() > 0){
							for(XMLGregorianCalendar date: datesList){
								valueList
								.add(DateUtil.getStringDatefromXMLGregorianDate(
										date,
										DateUtil.DATE_FORMAT_WITHOUT_MILLISECONDS));
			
							}
						}
						field.setValue(valueList);
					}

					fieldList.add(field);	
				}
				
				step.setFields(fieldList);
			}
			

		}
		return step;

	}
	
	public Case processToICMCase(Process process){
		Case caseObj = new Case();
		if(process != null){
			HashMap<String, Object> caseProperties = new HashMap<String, Object>();
			Properties processProperties = process.getProcessProperties();
			if(processProperties != null && processProperties.getProperties().size() > 0){
				for(NameValue property : processProperties.getProperties()){
					String key = property.getDesc();
					Object value = null;
					if(StringUtils.isNoneBlank(property.getValue())){
						value = property.getValue();
					}else if(null != property.getNumValue()){
						value = property.getNumValue();
					}else if(null != property.isBooleanValue()){
						value = property.isBooleanValue();
					}else if(null != property.getDecimalValue()){
						value = property.getDecimalValue();
					}else if(null != property.getDateValue()){
						value = property.getDateValue();
					}else if(null != property.getValueList()){
						value = property.getValueList();
					}else if(null != property.getIntegerList()){
						value = property.getIntegerList();
					}else if(null != property.getBoolList()){
						value = property.getBoolList();
					}else if(null != property.getTimeList()){
						value = property.getTimeList();
					}
					caseProperties.put(key, value);
				}
			}
			caseObj.setAdditionalIdentifiers(caseProperties);
			if(process.getDocuments() != null){
				List<Document> cmsDocuments = process.getDocuments().getDocuments();
				if(cmsDocuments != null && cmsDocuments.size() > 0){
					List<org.tiaa.esb.icm.types.Document> icmDocuments = new ArrayList<org.tiaa.esb.icm.types.Document>();
					for(Document cmsDocument : cmsDocuments){
						org.tiaa.esb.icm.types.Document icmDocument = new org.tiaa.esb.icm.types.Document();
						
						String mimeType = cmsDocument.getMimeTyp();
						if (null != mimeType) {
							mimeType = mimeType.trim();
						}
						icmDocument.setMimeType(mimeType);
						
						icmDocument.setDocumentName(cmsDocument.getDocName());
						if(cmsDocument.getDocContent() != null){
							icmDocument.setDocContent(org.apache.commons.codec.binary.Base64.encodeBase64(cmsDocument.getDocContent()));
						}
						icmDocuments.add(icmDocument);
					}
					caseObj.setDocuments(icmDocuments);
				}	
			}
		}
		return caseObj;
	}
	
	public org.tiaa.esb.icm.types.Task tasksToIcmTask(org.tiaa.esb.case_management_rs_v2.type.Task task) {
		org.tiaa.esb.icm.types.Task icmtask = new org.tiaa.esb.icm.types.Task();			
			if(task!=null){
				
				icmtask.setName(task.getName());
				icmtask.setType(task.getType());
				Step taskstep = new Step();
				
				if (task.getTaskProperties().getProperties() != null){
					
					List<StepElementDataField> fieldList = new ArrayList<StepElementDataField>();
					if(task.getReasons().getReasons()!=null){
						List<String> reasons = new ArrayList<String>();
						reasons.add(task.getReasons().getReasons().get(0).getReasonDesc());
						StepElementDataField dataField = new StepElementDataField();
						dataField.setId("Reasons");
						dataField.setName("Reasons");
						dataField.setValue(reasons);
						dataField.setType("String");
						fieldList.add(dataField);
					}
					
					for (NameValue nameValue : task.getTaskProperties()
							.getProperties()) {
						StepElementDataField field=new StepElementDataField();
						field.setId(nameValue.getID());
						field.setName(nameValue.getName());

						if(!StringUtils.isEmpty(nameValue.getValue())){
							List<String> valueList=new ArrayList<String>();
							field.setType("String");
							valueList.add(nameValue.getValue().toString());
							field.setValue(valueList);
						} else if(null != nameValue.getNumValue()){
							List<String> valueList=new ArrayList<String>();
							field.setType("Integer");
							valueList.add(nameValue.getNumValue().toString());
							field.setValue(valueList);
						} else if(null!=nameValue.isBooleanValue()){
							List<String> valueList=new ArrayList<String>();
							field.setType("Boolean");
							valueList.add(nameValue.isBooleanValue().toString());
							field.setValue(valueList);
						}else if(null!=nameValue.getDecimalValue()){
							field.setType("Float");
							List<String> valueList=new ArrayList<String>();
							valueList.add(nameValue.getDecimalValue().toString());
							field.setValue(valueList);
						} else if(null!=nameValue.getDateValue()){
							List<String> valueList=new ArrayList<String>();
							field.setType("Time");
							valueList
							.add(DateUtil.getStringDatefromXMLGregorianDate(
									nameValue.getDateValue(),
									DateUtil.DATE_FORMAT_WITHOUT_MILLISECONDS));
		
							field.setValue(valueList);
						} else if(null!=nameValue.getValueList()){
							List<String> valueList=new ArrayList<String>();
							field.setType("String[]");
							org.tiaa.esb.case_management_rs_v2.type.List listOfValues = nameValue.getValueList();
							List<String> strList = listOfValues.getItems();
							if(strList != null && strList.size() > 0){
								for(String str: strList){
									valueList.add(str);
								}
							}
							field.setValue(valueList);
						}else if(null != nameValue.getIntegerList()){
							List<String> valueList=new ArrayList<String>();
							field.setType("Integer[]");
							org.tiaa.esb.case_management_rs_v2.type.IntegerList listOfValues = nameValue.getIntegerList();
							List<BigInteger> bigIntList = listOfValues.getItems();
							if(bigIntList != null && bigIntList.size() > 0){
								for(BigInteger bigInt: bigIntList){
									valueList.add(String.valueOf(bigInt));
								}
							}
							field.setValue(valueList);
						} else if(null != nameValue.getBoolList()){
							List<String> valueList=new ArrayList<String>();
							field.setType("Boolean[]");
							org.tiaa.esb.case_management_rs_v2.type.BooleanList listOfBoolValues = nameValue.getBoolList();
							List<Boolean> boolList = listOfBoolValues.getItems();
							if(boolList != null && boolList.size() > 0){
								for(Boolean bool: boolList){
									valueList.add(String.valueOf(bool));
								}
							}
							field.setValue(valueList);
						} else if(null != nameValue.getTimeList()){
							List<String> valueList=new ArrayList<String>();
							field.setType("Time[]");
							org.tiaa.esb.case_management_rs_v2.type.TimeList listOfDateValues = nameValue.getTimeList();
							List<XMLGregorianCalendar> datesList = listOfDateValues.getItems();
							if(datesList != null && datesList.size() > 0){
								for(XMLGregorianCalendar date: datesList){
									valueList
									.add(DateUtil.getStringDatefromXMLGregorianDate(
											date,
											DateUtil.DATE_FORMAT_WITHOUT_MILLISECONDS));
				
								}
							}
							field.setValue(valueList);
						}
						fieldList.add(field);
					}
					
					taskstep.setFields(fieldList);
					icmtask.setTaskStep(taskstep);
				}
			}
			
		return icmtask;
		
	}
	
	public StepList searchReqToStepList(SearchRequest searchReq) {

		StepList stepList = new StepList();
		List<Step> steps = new ArrayList<Step>();

		if (searchReq != null) {

			if (searchReq.getProperties().getProperties() != null) {
				List<NameValue> propertiesList = searchReq.getProperties()
						.getProperties();
				List<StepElementDataField> stepElementList = new ArrayList<StepElementDataField>();
				for (NameValue properties : propertiesList) {
					Step step = new Step();
					StepElementDataField stepElement = new StepElementDataField();

					step.setWobId(properties.getID());
					stepElement.setName("Step Name");
					List<String> stepNameList = new ArrayList<String>();
					stepNameList.add(properties.getName());
					stepElement.setValue(stepNameList);
					stepElementList.add(stepElement);
					if (properties.getChildrenNameValues() != null) {
						for (NameValue childProperty : properties
								.getChildrenNameValues()) {
							if (childProperty.getName().equalsIgnoreCase(
									"Segment")) {
								StepElementDataField stepElementSegment = new StepElementDataField();
								stepElementSegment.setName(childProperty
										.getName());
								List<String> segmentList = new ArrayList<String>();
								segmentList.add(childProperty.getValue());
								stepElementSegment.setValue(segmentList);
								stepElementList.add(stepElementSegment);
							}

							if (childProperty.getName().equalsIgnoreCase(
									"QueueName")) {
								step.setQueueName(childProperty.getValue());
							}
						}

					}
					step.setFields(stepElementList);
					steps.add(step);
				}
			}
		}
		stepList.setSteps(steps);
		return stepList;
	}
	
}
