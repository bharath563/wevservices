package org.tiaa.case_management_rs.integration.icm;
 
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import org.tiaa.case_management_rs.exception.CaseManagementRuntimeException;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.esb.case_management_rs_v2.type.ESBMessage;
import org.tiaa.esb.case_management_rs_v2.type.ESBMessages;
import org.tiaa.esb.icm.types.Case;
import org.tiaa.esb.icm.types.CaseSearch;
import org.tiaa.esb.icm.types.Comment;
import org.tiaa.esb.icm.types.Configuration;
import org.tiaa.esb.icm.types.Document;
import org.tiaa.esb.icm.types.Response;
import org.tiaa.esb.icm.types.ResponseList;
import org.tiaa.esb.icm.types.Step;
import org.tiaa.esb.icm.types.StepList;
import org.tiaa.esb.icm.types.Task;
 
 
@Repository
public class ICMRepositoryImpl implements ICMRepository {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(ICMRepositoryImpl.class);
    
    @Autowired
	private RestTemplate restTemplate; //use new RestTemplate
    
    private HttpHeaders headers = new HttpHeaders();
    private HttpEntity<String> entity = null;
    
    @Autowired
    private ICMRepositoryLinkHelper iCMRepositoryLinkHelper;
    
	@Value("${icm.root}")
    private String icmRoot;
    
    @PostConstruct
    private void beanPostProcess() {
    	if (this.restTemplate != null) {
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));			
		}
    }
 
    @Override
    public ResponseList searchICMCases(CaseSearch icmCaseSearchRequest,String userId) {
        
    	this.headers.set("racfId", userId);
    	HttpEntity<CaseSearch> searchEntity = new HttpEntity<CaseSearch>(icmCaseSearchRequest, headers);

    	ResponseList response = this.restTemplate.postForObject(iCMRepositoryLinkHelper.getIcmSearchURL(), searchEntity, ResponseList.class);
    					
    	return response;
    }
 
    @Override
    public Case getICMProcess(String processId, String userId) {
        
        String icmProcessURL=iCMRepositoryLinkHelper.getIcmProcessRestURL().replace("{caseid}", processId);
        this.headers.set("racfId", userId);
        this.entity = new HttpEntity<String>("parameters", headers);
 
        ResponseEntity<Case> result =  this.restTemplate.exchange(icmProcessURL, org.springframework.http.HttpMethod.GET, entity, Case.class, processId);
        
        Case caseResponse = result.getBody();
        return caseResponse;
    }
    
    @Override
    public List<Object> getCaseAdditionalInfo(String processId, String userId, String solutionName, String section, String groupId, String tableName, String start, String sortOrder, String sortBy, String taskId) {
    	
    	Map<String, String> uriParams = new HashMap<String, String>();
		uriParams.put("solution", solutionName);
		uriParams.put("section", section);
		uriParams.put("caseid", processId);
		
    	String icmProcessURL=iCMRepositoryLinkHelper.getIcmCaseAdditionalInfoURL();
    	
    	if (StringUtils.isNotEmpty(groupId) && StringUtils.isNotEmpty(tableName)) {
    		//Omni Info URL
    		icmProcessURL=new StringBuilder(icmProcessURL).append("&groupId={groupId}&tableName={tableName}").toString();
    		uriParams.put("groupId", groupId);
    		uriParams.put("tableName", tableName);
    	} else if (StringUtils.isNotEmpty(start) && StringUtils.isNotEmpty(sortOrder) && StringUtils.isNotEmpty(sortBy)) {
    		//IS Pagination URL
    		icmProcessURL=new StringBuilder(icmProcessURL).append("&start={start}&sortBy={sortBy}&sortOrder={sortOrder}").toString();
    		uriParams.put("start", start);
    		uriParams.put("sortOrder", sortOrder);
    		uriParams.put("sortBy", sortBy);
    	} else if (StringUtils.isNotEmpty(taskId)) {
    		//File History Info URL
    		icmProcessURL=new StringBuilder(icmProcessURL).append("&taskId={taskId}").toString();
    		uriParams.put("taskId", taskId);
    	}
    	//icmProcessURL="http://localhost:8080/ICMClientRSV1/cases/{caseid}?solution={solution}&section={section}";

		URI uriForRestTemplate = CommonUtil.buildUrlWithParams(icmProcessURL, uriParams);
    	
    	this.headers.set("racfId", userId);
    	this.entity = new HttpEntity<String>("parameters", headers);
    	
    	ResponseEntity<Case> result =  this.restTemplate.exchange(uriForRestTemplate, org.springframework.http.HttpMethod.GET, entity, Case.class);
    	
    	Case infoCaddyResponseMap = result.getBody();
    	
    	List<Object> infoCaddyResponse = infoCaddyResponseMap.getInfoCaddyDetails();
    	
    	return infoCaddyResponse;
    }
 
    @Override
    public ResponseList getICMtasks(String processId, String userId, String start) {
        
    	Map<String, String> uriParams = new HashMap<String, String>();
		uriParams.put("start", start);
		uriParams.put("caseid", processId);
		
		String icmTasksURL=iCMRepositoryLinkHelper.getIcmTasksURL() + "?start={start}";
		URI uriForRestTemplate = CommonUtil.buildUrlWithParams(icmTasksURL, uriParams);
    	this.headers.set("racfId", userId);
    	this.entity = new HttpEntity<String>("parameters", headers);
    	
    	ResponseEntity<?> responseEntity = this.restTemplate.exchange(
    			uriForRestTemplate, org.springframework.http.HttpMethod.GET, entity, ResponseList.class); 
    	
    	ResponseList  results =(ResponseList) responseEntity.getBody();
        return results;
    }
    
    @Override
    public ResponseList getICMDocuments(String processId, String userId){
        
        String icmDocumentsURL=iCMRepositoryLinkHelper.getIcmDocumentsURL().replace("{caseid}", processId);
        this.headers.set("racfId", userId);
        this.entity = new HttpEntity<String>("parameters", headers);

        ResponseEntity<ResponseList> result =  this.restTemplate.exchange(icmDocumentsURL, org.springframework.http.HttpMethod.GET, entity, ResponseList.class, processId);
        
        ResponseList icmDocuments = result.getBody();
        
        return icmDocuments;
    }
    
    public ResponseList getICMcomments(String processId, String userId){
        String icmCommentsURL=iCMRepositoryLinkHelper.getIcmCommentsURL().replace("{caseid}", processId);
        this.headers.set("racfId", userId);
        this.entity = new HttpEntity<String>("parameters", headers);
 
        ResponseEntity<?> responseEntity =  this.restTemplate.exchange(icmCommentsURL, org.springframework.http.HttpMethod.GET, entity, ResponseList.class, processId);
        
        ResponseList  results =(ResponseList) responseEntity.getBody();
        
        return  results;
        
    }
 
    @Override
    public Configuration getICMConfigItem(String property) {
        String icmConfigURL=iCMRepositoryLinkHelper.getIcmConfigURL().replace("casestatus", property);
        this.entity = new HttpEntity<String>("parameters", headers);
        ResponseEntity<?> responseEntity =  this.restTemplate.exchange(icmConfigURL, org.springframework.http.HttpMethod.GET, entity, Configuration.class);
 
        Configuration configuration =(Configuration) responseEntity.getBody();
        return configuration;
    }
    
  //added for ICM entitled department
    @Override
    public List<String> getICMSolutions(String property,String userId) {
        String icmSolutionURL=iCMRepositoryLinkHelper.getIcmSolutionsURL().replace("userId", userId);
        this.entity = new HttpEntity<String>("parameters", headers);
        ResponseEntity<?> responseEntity =  this.restTemplate.exchange(icmSolutionURL, org.springframework.http.HttpMethod.GET, entity, List.class);
        List<String> solutions = (List<String>) responseEntity.getBody();
        return solutions;
    } 
 
    
    @Override
    public Response addICMComment(Comment comment, String caseId,String userId) {
        String icmCommentsURL = iCMRepositoryLinkHelper.getIcmCommentsURL().replace("{caseid}", caseId);
        this.headers.set("racfId", userId);
        HttpEntity<Comment> entity = new HttpEntity<Comment>(comment, headers);
        ResponseEntity<?> responseEntity = this.restTemplate.exchange(icmCommentsURL, org.springframework.http.HttpMethod.POST, entity, Response.class,caseId);
        Response commentResponse =(Response) responseEntity.getBody();
        return commentResponse;
    }
 
    @Override
    public Response addICMDocument(Document document, String caseId,String userId) {
        String icmDocumentsURL = iCMRepositoryLinkHelper.getIcmDocumentsURL().replace("{caseid}", caseId);
        this.headers.set("racfId", userId);
        HttpEntity<Document> entity = new HttpEntity<Document>(document, headers);
        ResponseEntity<?> responseEntity = this.restTemplate.exchange(icmDocumentsURL, org.springframework.http.HttpMethod.POST, entity, Response.class,caseId);
        Response documentResponse = (Response) responseEntity.getBody();
        return documentResponse;
    }

    @Override
    public ResponseList getICMRelatedCase(String processId, String userId,String solutionName) {
    	String realtedCaseURL = iCMRepositoryLinkHelper.getIcmRelatedCasesURL().replace("{caseid}", processId);
    	headers.set("racfId", userId);

    	UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(realtedCaseURL)
    	        .queryParam("solutionName", solutionName);
    	
    	entity = new HttpEntity<String>("parameters", headers);
//    	String decodecaseId = null;
//    	try {
//    		decodecaseId = URLDecoder.decode(processId, "UTF-8");
//    	} catch (UnsupportedEncodingException e) {
//    		e.printStackTrace();
//    	}
    	ResponseEntity<?> responseEntity =  this.restTemplate.exchange(builder.build().encode().toUri(), org.springframework.http.HttpMethod.GET, entity, ResponseList.class);
    	ResponseList  results =(ResponseList) responseEntity.getBody();
    	return results;
    }
 
 
	@Override
	public Configuration getICMSolutionHeaders(String dept, String userId,  String tableheader) {
		String icmSolutionHeadersURL = iCMRepositoryLinkHelper.getIcmSolutionHeadersURL().replace("{solution}", dept).replace("{tableheader}", tableheader);
		this.headers.set("racfId", userId);
        this.entity = new HttpEntity<String>("parameters", headers);
        ResponseEntity<?> responseEntity =  this.restTemplate.exchange(icmSolutionHeadersURL, org.springframework.http.HttpMethod.GET, entity, Configuration.class);
        
        Configuration configuration = (Configuration) responseEntity.getBody();
        return configuration;
	}
	
	@Override
	public List<StepList> getICMSteps(String userId, String department,
			String type, String start) {
		List<StepList> processResponse = new ArrayList<StepList>();
		
		if(StringUtils.isEmpty(start)){
			start="0";
		}
		String icmProcessUrl = iCMRepositoryLinkHelper.getIcmStepsURL().replace("{userId}", userId).replace("{solution}", department).replace("{type}", type).replace("{start}",start);
		this.headers.set("racfId", userId);
		this.entity = new HttpEntity<String>("parameters", headers);
		try{
			ResponseEntity<?> responseEntity = this.restTemplate.exchange(icmProcessUrl, org.springframework.http.HttpMethod.GET, entity, ResponseList.class);
			ResponseList response = (ResponseList) responseEntity.getBody();
			processResponse = (List<StepList>) response.getResults();
		}catch(Exception e){
			LOGGER.error("Exception while getting steps from ICM:"+e.getMessage());
			//throw e;
		}
		return processResponse;
	}

	@Override
	public Step getICMStepDetails(String wobId, String queueName, String userId, String property) {
		String icmStepDetailUrl = icmRoot +"/steps/{wobid}?queueName={queueName}&property={property}";
		Map<String, String> uriParams = new HashMap<String, String>();
		uriParams.put("wobid", wobId);
		uriParams.put("queueName", queueName);
		uriParams.put("property", property);
		
		this.headers.set("racfId", userId);
		this.entity = new HttpEntity<String>("parameters", headers);
		
		Step stepResponse = null;
		try{
			URI uriForRestTemplate = CommonUtil.buildUrlWithParams(icmStepDetailUrl, uriParams);
			ResponseEntity<Step> responseEntity = this.restTemplate.exchange(uriForRestTemplate, org.springframework.http.HttpMethod.GET, entity, Step.class);
			stepResponse =  responseEntity.getBody();
		}catch(HttpClientErrorException e){
			if(e.getStatusCode() == HttpStatus.NOT_FOUND){
				ESBMessages esbMessages = new ESBMessages();
				ESBMessage esbMessage = new ESBMessage();
				esbMessage.setCode("404");
				esbMessage.setText("Step with wobId:"+ wobId  +" and queueName:"+queueName +" not found");
				esbMessage.setType("ERROR");
				esbMessages.getMessages().add(esbMessage);
				CaseManagementRuntimeException cre = new CaseManagementRuntimeException("Step with wobId:"+ wobId  +" and queueName:"+queueName +" not found");
				cre.setEsbMessages(esbMessages);
				throw cre;
			}
		}
		
		
		return stepResponse;
	}
	
	@Override
	public ResponseList getICMHistory(String processId, String userId, String start, String type) {
		String icmHistoryURL=iCMRepositoryLinkHelper.getIcmGetHistoryURL().replace("{caseid}", processId).replace("{start}", start).replace("{type}", type);
        this.headers.set("racfId", userId);
        this.entity = new HttpEntity<String>("parameters", headers);
        ResponseList icmHistory = new ResponseList();
        try{
        	ResponseEntity<?> result =  this.restTemplate.exchange(icmHistoryURL, org.springframework.http.HttpMethod.GET, entity, ResponseList.class, processId);
        	icmHistory = (ResponseList) result.getBody();
        }catch(Exception e){
			LOGGER.error("Exception while getting steps from ICM:"+e.getMessage());
			throw e;
		}
		return icmHistory;
	}
	
	@Override
	public ResponseList getMetrics(String userId, String solutionName){
		String icmMetricsURL = icmRoot + "/solutions/" + solutionName + "/metrics";
		this.headers.set("racfId", userId);
        this.entity = new HttpEntity<String>("parameters", headers);
        ResponseList icmMetrics = new ResponseList();
        LOGGER.debug("icmMetricsURL:" + icmMetricsURL);
        try{
        	ResponseEntity<?> result =  this.restTemplate.exchange(icmMetricsURL, org.springframework.http.HttpMethod.GET, entity, ResponseList.class, solutionName);
        	icmMetrics = (ResponseList) result.getBody();
        }catch(Exception e){
			LOGGER.error("Exception while getting steps from ICM:"+e.getMessage());
			throw e;
		}
		return icmMetrics;
		
	}
	@Override
	public Response actionIcmTask(String wobId, String userId, String queueName, Step stepElement) {
		String icmActionUrl = icmRoot +"/steps/{wobid}/action?queueName={queueName}";
		Map<String, String> uriParams = new HashMap<String, String>();
		uriParams.put("wobid", wobId);
		uriParams.put("queueName", queueName);
		
		this.headers.set("racfId", userId);
		Response response = null;
		HttpEntity<Step> entity = new HttpEntity<Step>(stepElement, headers);
		try {
			URI uriForRestTemplate = CommonUtil.buildUrlWithParams(icmActionUrl, uriParams);
	    	ResponseEntity<?> result =  this.restTemplate.exchange(uriForRestTemplate, org.springframework.http.HttpMethod.PUT, entity, Response.class);
			response = (Response) result.getBody();
		} catch (Exception e) {
			LOGGER.error("Exception while action on task in ICM:"
					+ e.getMessage());
			throw e;
		}
		return response;
	
		
	}

	@Override
	public Response unLockIcmTask(String wobId, String userId, String queueName) {
		Response response = null;
		String icmUnlockTaskUrl = icmRoot + "/steps/{wobid}/unlock?queueName={queueName}";
		
	    Map<String, String> uriParams = new HashMap<String, String>();
		uriParams.put("wobid", wobId);
		uriParams.put("queueName", queueName);
			
		this.headers.set("racfId", userId);
	    this.entity = new HttpEntity<String>("parameters", headers);
	    try {
	    	URI uriForRestTemplate = CommonUtil.buildUrlWithParams(icmUnlockTaskUrl, uriParams);
	    	ResponseEntity<?> result =  this.restTemplate.exchange(uriForRestTemplate, org.springframework.http.HttpMethod.PUT, entity, Response.class);
			response=(Response) result.getBody();
		} catch (Exception e) {
			LOGGER.error("Exception while unlocking task in ICM:" + e.getMessage());
			throw e;
		}
		return response;
	}

	@Override
	public Response reAssignIcmTask(String wobId, String userId, String queueName, Step stepElement) {
		Response response=new Response();
		 
		String icmReassignUrl= icmRoot + "/steps/{wobid}/reassign?queueName={queueName}";
		Map<String, String> uriParams = new HashMap<String, String>();
		uriParams.put("wobid", wobId);
		uriParams.put("queueName", queueName);
		this.headers.set("racfId", userId);
		
		HttpEntity<Step> entity = new HttpEntity<Step>(stepElement, headers);
		try {
			URI uriForRestTemplate = CommonUtil.buildUrlWithParams(icmReassignUrl, uriParams);
			ResponseEntity<?> result =  this.restTemplate.exchange(uriForRestTemplate, org.springframework.http.HttpMethod.PUT, entity, Response.class);
			response = (Response) result.getBody();
		} catch (Exception e) {
			LOGGER.error("Exception while re assign a task in ICM:" + e.getMessage());
			throw e;
		}
		return response;
	}

	
	@Override
	public Response createCase(Case caseObj, String userId) {
		Response response = new Response();
		
		String icmCreateCaseUrl = icmRoot + "/cases";
		this.headers.set("racfId", userId);
    	HttpEntity<Case> entity = new HttpEntity<Case>(caseObj, headers);
		
		try {
			URI uriForRestTemplate = CommonUtil.buildUrlWithParams(icmCreateCaseUrl, null);
			ResponseEntity<?> result =  this.restTemplate.exchange(uriForRestTemplate, org.springframework.http.HttpMethod.POST, entity, Response.class);
			response = (Response) result.getBody();
		} catch (Exception e) {
			LOGGER.error("Exception while creating case: " + e.getMessage());
			throw e;
		}
		return response;
	}
	
	@Override
	public Response createIcmTask(String caseId, Task task, String userId) {
		
		Response response=new Response();
		 
		String icmReassignUrl= icmRoot + "/cases/{caseid}/tasks";
		Map<String, String> uriParams = new HashMap<String, String>();
		uriParams.put("caseid", caseId);
		
		this.headers.set("racfId", userId);
		HttpEntity<org.tiaa.esb.icm.types.Task> entity = new HttpEntity<org.tiaa.esb.icm.types.Task>(task, headers);
		
		try {
			URI uriForRestTemplate = CommonUtil.buildUrlWithParams(icmReassignUrl, uriParams);
			ResponseEntity<?> result =  this.restTemplate.exchange(uriForRestTemplate, org.springframework.http.HttpMethod.POST, entity, Response.class);
			response = (Response) result.getBody();
		} catch (Exception e) {
			LOGGER.error("Exception while creating a task in ICM:" + e.getMessage());
			throw e;
		}
		return response;
	}

	@Override
	public Configuration getICMRequestTypesForBA(String property, String dept) {
		Configuration configuration = new Configuration();

		String icmConfigURL = icmRoot
				+ "/config?type=requesttypesforbusinessarea&solution={solution}";
		Map<String, String> uriParams = new HashMap<String, String>();
		uriParams.put("solution", dept);

		this.entity = new HttpEntity<String>("parameters", headers);
		try {
			URI uriForRestTemplate = CommonUtil.buildUrlWithParams(
					icmConfigURL, uriParams);
			ResponseEntity<?> result = this.restTemplate.exchange(uriForRestTemplate,
					org.springframework.http.HttpMethod.GET, entity,
					Configuration.class);
			configuration = (Configuration) result.getBody();
		} catch (Exception e) {
			LOGGER.error("Exception while creating a task in ICM:"
					+ e.getMessage());
			throw e;
		}
		return configuration;
	}
	
	@Override
    public Map<String, String> searchConfigItems(StepList stepList, String userId, String property) {
		String searchConfigUrl= icmRoot + "/searchconfig?type={property}";
		Map<String, String> uriParams = new HashMap<String, String>();
		uriParams.put("property", property);
		
		Map<String, String> response = null;
		this.headers.set("racfId", userId);
		HttpEntity<org.tiaa.esb.icm.types.StepList> entity = new HttpEntity<org.tiaa.esb.icm.types.StepList>(stepList, headers);
		
		try {
			URI uriForRestTemplate = CommonUtil.buildUrlWithParams(searchConfigUrl, uriParams);
			ResponseEntity<?> result =  this.restTemplate.exchange(uriForRestTemplate, org.springframework.http.HttpMethod.POST, entity, Map.class);
			response = (Map) result.getBody();
			return response;
		} catch (Exception e) {
			LOGGER.error("Exception to fetch config values" + e.getMessage());
			throw e;
		}

    }

	@Override
	public ResponseList getIcmOmniTasks(String processId, String userId, String startOmniTasks, String plan, String subPlan) {
		
    	Map<String, String> uriParams = new HashMap<String, String>();
		uriParams.put("startOmniTasks", startOmniTasks);
		uriParams.put("caseid", processId);
		uriParams.put("plan", plan);
		uriParams.put("subPlan", subPlan);
		
		String icmTasksURL=iCMRepositoryLinkHelper.getIcmTasksURL() + "?startOmniTasks={startOmniTasks}&plan={plan}&subPlan={subPlan}";
		URI uriForRestTemplate = CommonUtil.buildUrlWithParams(icmTasksURL, uriParams);
    	this.headers.set("racfId", userId);
    	this.entity = new HttpEntity<String>("parameters", headers);
    	
    	ResponseEntity<?> responseEntity = this.restTemplate.exchange(
    			uriForRestTemplate, org.springframework.http.HttpMethod.GET, entity, ResponseList.class); 
    	
    	ResponseList  results =(ResponseList) responseEntity.getBody();
        return results;
	} 
	
	
	@Override
	public void deleteICMDocument(String caseId, String docTemplateCode, String userId) {
		try {
			String deleteIcmDocumentURL =  icmRoot +"/documents/"+ docTemplateCode;
			this.headers.set("racfId", userId);
			this.entity = new HttpEntity<String>("parameters", headers);
			// icm delete service call
			ResponseEntity<Response> responseEntity = this.restTemplate.exchange(deleteIcmDocumentURL, org.springframework.http.HttpMethod.DELETE, entity, Response.class, docTemplateCode);
			Response result = responseEntity.getBody();

			if (result.getErrorCode() != null) {
				ESBMessages esbMessages = new ESBMessages();
				ESBMessage esbMessage = new ESBMessage();
				esbMessage.setText(result.getErrorMessage());
				esbMessage.setType(result.getStatus());
				esbMessages.getMessages().add(esbMessage);
				CaseManagementRuntimeException cre = new CaseManagementRuntimeException((result.getErrorMessage()));
				cre.setEsbMessages(esbMessages);
				throw cre;
			}

		} catch (Exception e) {
			LOGGER.error("Delete Document Service Call Failed in ICM " + e.getMessage());
			throw e;
		}
	}
}