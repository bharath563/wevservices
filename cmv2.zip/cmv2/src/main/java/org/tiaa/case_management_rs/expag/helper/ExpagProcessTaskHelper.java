package org.tiaa.case_management_rs.expag.helper;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.dao.EXPAGDAO;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.ProcessRequest;
import org.tiaa.esb.case_management_rs_v2.type.Properties;
import org.tiaa.esb.case_management_rs_v2.type.Reason;
import org.tiaa.esb.case_management_rs_v2.type.Task;
import org.tiaa.esb.powerimage.types.ProcessTask;



@Component
public class ExpagProcessTaskHelper {

	//private static final Logger LOGGER = LoggerFactory.getLogger(ExpagProcessTaskHelper.class);

	@Autowired
	private ExpagTaskHelper expagTaskHelper;
	
	@Autowired
	private EXPAGDAO expagdao;

	/**
	 * create Process request
	 * @param processRequest
	 * @return org.tiaa.esb.powerimage.types.ProcessTask
	 */
	public org.tiaa.esb.powerimage.types.ProcessTask constructProcessRequest(ProcessRequest processRequest, org.tiaa.esb.powerimage.types.ProcessTask processExpagTask) {

		//	  if ((processRequest != null) && (processRequest.getProcess() != null)) {
		//			Task cmsTask = processRequest.getProcess().getTasks().getTasks().get(0);
		//		}
		return processExpagTask;
	}

	/**
	 * Create Suspend request
	 * @param processRequest
	 * @return org.tiaa.esb.powerimage.types.ProcessTask
	 */
	public org.tiaa.esb.powerimage.types.ProcessTask constructSuspendRequest(org.tiaa.esb.case_management_rs_v2.type.Task cmsTask, org.tiaa.esb.powerimage.types.Task expagTask) {
		org.tiaa.esb.powerimage.types.ProcessTask processExpagTask = new org.tiaa.esb.powerimage.types.ProcessTask();

		if (cmsTask != null) { //(workItemRequest != null) && (workItemRequest.getWorkItem() != null)
			processExpagTask.setTaskid(cmsTask.getID());
			processExpagTask.setStatus(EXPAG_STATUS_DESC_SUSPEND);
			processExpagTask.setWakedate(cmsTask.getCompleteDate());
			processExpagTask.setWaketime(cmsTask.getCompleteTime());
			processExpagTask.setWakeoper(cmsTask.getAssignedTo());

			if (StringUtils.isNotBlank(cmsTask.getAssignedTo())) {
				processExpagTask.setWrkbskt(cmsTask.getAssignedTo());
			}
		}
		return processExpagTask;
	}

	/**
	 * 
	 * @param processRequest
	 * @return
	 */
	public org.tiaa.esb.powerimage.types.ProcessTask constructUnsuspendRequest(ProcessRequest processRequest) {
		Task cmsTask = processRequest.getProcess().getTasks().getTasks().get(0);

		org.tiaa.esb.powerimage.types.ProcessTask processExpagTask = new org.tiaa.esb.powerimage.types.ProcessTask();

		if ((processRequest != null) && (processRequest.getProcess() != null)) {
			processExpagTask.setTaskid(cmsTask.getID());
			processExpagTask.setPktid(processRequest.getProcess().getProcessId());
			processExpagTask.setStatus(EXPAG_STATUS_DESC_NONE);
		}
		return processExpagTask;
	}

	/**
	 * Create Review Request
	 * @param processRequest
	 * @return org.tiaa.esb.powerimage.types.ProcessTask
	 */
	public org.tiaa.esb.powerimage.types.ProcessTask constructReviewRequest(ProcessRequest processRequest, org.tiaa.esb.powerimage.types.ProcessTask processExpagTask) {
		if ((processRequest != null) && (processRequest.getProcess() != null)) {
			Task cmsTask = processRequest.getProcess().getTasks().getTasks().get(0);
			processExpagTask.setReviewoper(cmsTask.getAssignedTo());

			if (StringUtils.isNotBlank(cmsTask.getAssignedTo())) {
				processExpagTask.setWrkbskt(cmsTask.getAssignedTo());
			}
		}
		return processExpagTask;
	}

	/**
	 * Create Reject Request
	 * @param processRequest
	 * @return org.tiaa.esb.powerimage.types.ProcessTask
	 */
	public org.tiaa.esb.powerimage.types.ProcessTask constructRejectRequest(ProcessRequest processRequest) {
		Task cmsTask = processRequest.getProcess().getTasks().getTasks().get(0);

		org.tiaa.esb.powerimage.types.ProcessTask processExpagTask = new org.tiaa.esb.powerimage.types.ProcessTask();

		if ((processRequest != null) && (processRequest.getProcess() != null)) {
			processExpagTask.setTaskid(cmsTask.getID());
			processExpagTask.setPktid(processRequest.getProcess().getProcessId());
			processExpagTask.setStatus(EXPAG_STATUS_DESC_REJECT);
		}
		return processExpagTask;
	}
	
	

	/**
	 * Create Edit request summary request
	 * @param processRequest
	 * @param expagTask
	 * @return org.tiaa.esb.powerimage.types.ProcessTask
	 */
	public org.tiaa.esb.powerimage.types.ProcessTask constructCommonRequest(ProcessRequest processRequest, org.tiaa.esb.powerimage.types.Task expagTask, 
							String action, String useIdentifiersId, String userId) {
		org.tiaa.esb.powerimage.types.ProcessTask processExpagTask = new org.tiaa.esb.powerimage.types.ProcessTask();
		List<org.tiaa.esb.powerimage.types.ProcessIdentifier> expagidIdentifiers = new ArrayList<org.tiaa.esb.powerimage.types.ProcessIdentifier>();

		if (processRequest != null) {
			Task cmsTask = processRequest.getProcess().getTasks().getTasks().get(0);
			
			processExpagTask.setTaskid(cmsTask.getID());
			processExpagTask.setPktid(processRequest.getProcess().getProcessId());

			// If task type is not null then override the existing one
			if (StringUtils.isNotBlank(cmsTask.getType())) {
				processExpagTask.setTasktype(cmsTask.getType());
			}

			// If department is not null then override the existing one
			if (StringUtils.isNotBlank(cmsTask.getDepartment())) {
				processExpagTask.setDepartment(cmsTask.getDepartment());
			}
					
			boolean isUserEntitledToEditDefaults = this.expagdao.isUserEntitledToFunction(FUNCTION_CATEGORY_EDIT_DEFAULTS, FUNCTION_DESC_ACTION_TYPE, userId);		
			if (isUserEntitledToEditDefaults) {
				String recvdDate = DateUtil.toFormat(cmsTask.getReceivedDate(), CaseManagementConstants.YYYYMMDD);
				String recvdTime = DateUtil.toFormat(cmsTask.getReceivedTime(), CaseManagementConstants.HHMMSSSSS);
				
				recvdTime = recvdTime.substring(0, recvdTime.length() - 1);
				expagdao.updateReceivedDateTime(recvdDate, recvdTime, expagTask.getTaskid()); 					
			
			} else {
				
				processExpagTask.setDatereceived(expagTask.getDatereceived());
				processExpagTask.setTimereceived(expagTask.getTimereceived());
				
			}
	
			// If Assignedto is not null then override the existing one
			if (StringUtils.isNotBlank(cmsTask.getAssignedTo())) {
				processExpagTask.setWrkbskt(cmsTask.getAssignedTo());
			}

			// If the VIPIndicator is given then override the vip indicator value
			if (StringUtils.isNotBlank(cmsTask.getVIPIndicator())) {

				processExpagTask.setVip(cmsTask.getVIPIndicator());
			}
			
			processExpagTask.setStatus(action);
			
			if(cmsTask.getActionStep() != null){
				processExpagTask.setActiondesc(cmsTask.getActionStep());
			}

			// Identifier processing
			Properties finalExpagProperties = null;	
						
			//Check for useEXPAGIdentifiersId parameter
			if(null != useIdentifiersId && TRUE.equalsIgnoreCase(useIdentifiersId)){
				finalExpagProperties = convertCMSIdentifiersToExpagIdentifiers(cmsTask, expagTask);
			} else{
				finalExpagProperties = cmsIdentifiersToFinalExpagIdentifiers(cmsTask, expagTask);
			}	
			expagidIdentifiers = this.cmsPropertiesToexpagProcessTaskIdentifiers(finalExpagProperties.getProperties(), useIdentifiersId);
			processExpagTask.getProcessIdentifiers().addAll(expagidIdentifiers);

		}
		return processExpagTask;
	}
	
	/**
	 * Construct assignment request
	 * @param cmsTask
	 * @param expagTask
	 * @return
	 */
	public org.tiaa.esb.powerimage.types.ProcessTask constructAssignRequest(org.tiaa.esb.case_management_rs_v2.type.Task cmsTask, org.tiaa.esb.powerimage.types.Task expagTask) {

		org.tiaa.esb.powerimage.types.ProcessTask processExpagTask = new org.tiaa.esb.powerimage.types.ProcessTask();
		if (cmsTask != null) {
			processExpagTask.setTaskid(cmsTask.getID());
			if (StringUtils.isNotBlank(cmsTask.getAssignedTo())) {
				processExpagTask.setWrkbskt(cmsTask.getAssignedTo());
			}
			processExpagTask.setStatus(EXPAG_STATUS_DESC_NONE);
		}
		return processExpagTask;
	}
	
	
	/**
	 * Create Authorize Request
	 * @param processRequest
	 * @return org.tiaa.esb.powerimage.types.ProcessTask
	 */
	public org.tiaa.esb.powerimage.types.ProcessTask constructAuthorizeRequest(ProcessRequest processRequest) {
		Task cmsTask = processRequest.getProcess().getTasks().getTasks().get(0);

		org.tiaa.esb.powerimage.types.ProcessTask processExpagTask = new org.tiaa.esb.powerimage.types.ProcessTask();

		if ((processRequest != null) && (processRequest.getProcess() != null)) {
			processExpagTask.setTaskid(cmsTask.getID());
			processExpagTask.setPktid(processRequest.getProcess().getProcessId());
			processExpagTask.setStatus(EXPAG_STATUS_DESC_AUTHORIZE);
		}
		return processExpagTask;
	}
	
	/**
	 * Create Reindex Request
	 * @param processRequest
	 * @return org.tiaa.esb.powerimage.types.ProcessTask
	 */
	public org.tiaa.esb.powerimage.types.ProcessTask constructReindexRequest(ProcessRequest processRequest) {
		Task cmsTask = processRequest.getProcess().getTasks().getTasks().get(0);

		org.tiaa.esb.powerimage.types.ProcessTask processExpagTask = new org.tiaa.esb.powerimage.types.ProcessTask();

		if ((processRequest != null) && (processRequest.getProcess() != null)) {
			processExpagTask.setTaskid(cmsTask.getID());
			processExpagTask.setPktid(processRequest.getProcess().getProcessId());
			processExpagTask.setStatus(EXPAG_STATUS_DESC_REINDEX);
		}
		return processExpagTask;
	}
	
	/**
	 * Create Review2 Request
	 * @param processRequest
	 * @return org.tiaa.esb.powerimage.types.ProcessTask
	 */
	public org.tiaa.esb.powerimage.types.ProcessTask constructReview2Request(ProcessRequest processRequest) {
		Task cmsTask = processRequest.getProcess().getTasks().getTasks().get(0);

		org.tiaa.esb.powerimage.types.ProcessTask processExpagTask = new org.tiaa.esb.powerimage.types.ProcessTask();

		if ((processRequest != null) && (processRequest.getProcess() != null)) {
			processExpagTask.setTaskid(cmsTask.getID());
			processExpagTask.setPktid(processRequest.getProcess().getProcessId());
			processExpagTask.setStatus(EXPAG_STATUS_DESC_REVIEW2);
		}
		return processExpagTask;
	}	
	
	/**
	 * Create Fail Request
	 * @param processRequest
	 * @return org.tiaa.esb.powerimage.types.ProcessTask
	 */
	public org.tiaa.esb.powerimage.types.ProcessTask constructFailRequest(ProcessRequest processRequest, org.tiaa.esb.powerimage.types.ProcessTask processExpagTask) {
		Task cmsTask = processRequest.getProcess().getTasks().getTasks().get(0);

		if ((processRequest != null) && (processRequest.getProcess() != null)) {
			if (cmsTask.getReasons() != null){
				List<Reason> reasonList = cmsTask.getReasons().getReasons();
				processExpagTask.setReasoncode(new ProcessTask.Reasoncode()); 
				for(int i=0;i<reasonList.size();i++){				
					String reasonCode = reasonList.get(i).getReasonCode();

					switch(i){
					case 0:
						if(StringUtils.isNotBlank(reasonCode) && StringUtils.isNumeric(reasonCode)){
							processExpagTask.getReasoncode().setCdreason1(new Integer(reasonCode));
						}
						break;

					case 1:
						if(StringUtils.isNotBlank(reasonCode) && StringUtils.isNumeric(reasonCode)){
							processExpagTask.getReasoncode().setCdreason2(new Integer(reasonCode));
						}
						break;

					case 2:
						if(StringUtils.isNotBlank(reasonCode) && StringUtils.isNumeric(reasonCode)){
							processExpagTask.getReasoncode().setCdreason3(new Integer(reasonCode));
						}
						break;

					case 3:
						if(StringUtils.isNotBlank(reasonCode) && StringUtils.isNumeric(reasonCode)){
							processExpagTask.getReasoncode().setCdreason4(new Integer(reasonCode));
						}
						break;

					case 4:
						if(StringUtils.isNotBlank(reasonCode) && StringUtils.isNumeric(reasonCode)){
							processExpagTask.getReasoncode().setCdreason5(new Integer(reasonCode));
						}
						break;

					}
				}
			}

		}
		return processExpagTask;
	}


	/**
	 * Create a List of final Identifiers that need to send it to powerImage Service
	 * For update/delete/remove 
	 * @param cmsTask - Data which we are getting from UI
	 * @param expagExistingTask - Data which we get it from PowerImage Service call
	 * @return Properties of final identifiers
	 */
	public Properties cmsIdentifiersToFinalExpagIdentifiers(Task cmsTask, org.tiaa.esb.powerimage.types.Task expagExistingTask) {
		Properties currentExpagProperties = new Properties();
		Properties existingExpagProperties = new Properties();
		Properties finalExpagProperties = new Properties();

		if ((cmsTask.getTaskProperties() != null) && (cmsTask.getTaskProperties().getProperties().size() > 0)) {
			currentExpagProperties = cmsTask.getTaskProperties();
		}

		if ((expagExistingTask.getIdentifiers() != null) && (expagExistingTask.getIdentifiers().getCount() > 0)) {
			existingExpagProperties = this.expagTaskHelper.expagIdentifiersTocmsProcessProperties(expagExistingTask.getIdentifiers().getIdentifiers());
		}

		// Loop and populate the ADD the new identifier
		for (NameValue currentNameValue : currentExpagProperties.getProperties()) {
			boolean isNew = true;
			for (NameValue existingNameValue : existingExpagProperties.getProperties()) {
				/*
				 * If the current identifier doesn't match with any of the
				 * existing identifier, then it should be added freshly.
				 */
				if ((currentNameValue != null) && (existingNameValue != null)) {
					if (currentNameValue.getDesc().equalsIgnoreCase(existingNameValue.getDesc())) {
						isNew = false;
						break;
					}
				}

			}

			if (isNew) {
				for (NameValue nameValue : currentNameValue.getChildrenNameValues()) {
					nameValue.setValUpdtFlg(true);
				}
				finalExpagProperties.getProperties().add(currentNameValue);
			}

		}

		// Loop and populate the REMOVE the existing identifier
		for (NameValue existingNameValue : existingExpagProperties.getProperties()) {
			boolean isRemove = true;
			for (NameValue currentNameValue : currentExpagProperties.getProperties()) {
				/*
				 * If an existing identifier doesn't match with any of the
				 * current identifier, then it should be removed.
				 */
				if ((existingNameValue != null) && (currentNameValue != null)) {

					if (existingNameValue.getDesc().equalsIgnoreCase(currentNameValue.getDesc())) {
						isRemove = false;
						break;
					}
				}

			}

			if (isRemove) {

				for (NameValue nameValue : existingNameValue.getChildrenNameValues()) { 
					nameValue.setValUpdtFlg(false);
				}
				finalExpagProperties.getProperties().add(existingNameValue);
			}
		}

		// Loop and populate the UPDATE the existing identifier
		for (NameValue existingNameValue : existingExpagProperties.getProperties()) {

			for (NameValue currentNameValue : currentExpagProperties.getProperties()) {

				boolean isUpdate = false;

				if ((currentNameValue != null) && (existingNameValue != null)) {

					if (currentNameValue.getDesc().equalsIgnoreCase(existingNameValue.getDesc())) {

						isUpdate = false;

						for (NameValue newChildNameValue : currentNameValue.getChildrenNameValues()) {

							for (NameValue existingChildNameValue : existingNameValue.getChildrenNameValues()) {

								if ((newChildNameValue != null) && newChildNameValue.getName().equalsIgnoreCase(existingChildNameValue.getName())) {

									if( newChildNameValue.getValue() != null){
										if ( !newChildNameValue.getValue().equalsIgnoreCase(existingChildNameValue.getValue()==null?"":existingChildNameValue.getValue())) {
											isUpdate = true;
											break;
										}
									}
								}
							}
						}

					}
				}

				if (isUpdate) {
					// Delete the existing identifier
					for (NameValue nameValue : existingNameValue.getChildrenNameValues()) {
						nameValue.setValUpdtFlg(false);
					}
					finalExpagProperties.getProperties().add(existingNameValue);

					// ADD the new identifier
					for (NameValue nameValue : currentNameValue.getChildrenNameValues()) {
						nameValue.setValUpdtFlg(true);
					}

					finalExpagProperties.getProperties().add(currentNameValue);
				}
			}
		}
		return finalExpagProperties;
	}
	
	/**
	 * Create a List of final Identifiers that need to send it to powerImage Service
	 * For update/delete/remove 
	 * @param cmsTask - Data which we are getting from UI
	 * @param expagExistingTask - Data which we get it from PowerImage Service call
	 * @return Properties of final identifiers
	 * TBD: Remove cmsIdentifiersToFinalExpagIdentifiers later after getting ID from UW. 
	 */
	public Properties convertCMSIdentifiersToExpagIdentifiers(Task cmsTask, org.tiaa.esb.powerimage.types.Task expagExistingTask) {
		Properties currentExpagProperties = new Properties();
		Properties existingExpagProperties = new Properties();
		Properties finalExpagProperties = new Properties();
		

		if ((cmsTask.getTaskProperties() != null) && (cmsTask.getTaskProperties().getProperties().size() > 0)) {
			currentExpagProperties = cmsTask.getTaskProperties();
		}

		if ((expagExistingTask.getIdentifiers() != null) && (expagExistingTask.getIdentifiers().getCount() > 0)) {
			existingExpagProperties = this.expagTaskHelper.expagIdentifiersTocmsProcessProperties(expagExistingTask.getIdentifiers().getIdentifiers());
		}

		// Loop and populate the ADD the new identifier
		for (NameValue currentNameValue : currentExpagProperties.getProperties()) {
			boolean isNew = true;
			
			for (NameValue existingNameValue : existingExpagProperties.getProperties()) {
				/*
				 * If the current identifier doesn't match with any of the
				 * existing identifier, then it should be added freshly.
				 */
				
				if ((currentNameValue != null) && (existingNameValue != null)) {
					
					String currentId = currentNameValue.getID() != null ? currentNameValue.getID() : "";
					if(currentNameValue.getID() == null){
						isNew = false;
						break;
					} else if (currentNameValue.getDesc().equalsIgnoreCase(existingNameValue.getDesc()) 
							&& currentId.equalsIgnoreCase(existingNameValue.getID())) {
						isNew = false;
						break;
					} else if (!currentNameValue.getDesc().equalsIgnoreCase(existingNameValue.getDesc()) 
							&& currentId.equalsIgnoreCase(existingNameValue.getID())) {
						isNew = true;
						break;
					}
					
				}

			}

			if (isNew) {
				for (NameValue nameValue : currentNameValue.getChildrenNameValues()) {
					nameValue.setValUpdtFlg(true);
				}
				finalExpagProperties.getProperties().add(currentNameValue);
			}

		}

		// Loop and populate the REMOVE the existing identifier
		for (NameValue existingNameValue : existingExpagProperties.getProperties()) {
			boolean isRemove = true;
			for (NameValue currentNameValue : currentExpagProperties.getProperties()) {
				/*
				 * If an existing identifier doesn't match with any of the
				 * current identifier, then it should be removed.
				 */
				if ((existingNameValue != null) && (currentNameValue != null)) {

					String currentId = currentNameValue.getID() != null ? currentNameValue.getID() : "";
					
					if (existingNameValue.getDesc().equalsIgnoreCase(currentNameValue.getDesc()) 
							&& existingNameValue.getID().equalsIgnoreCase(currentId)) {
						isRemove = false;
						break;
					}
				}

			}

			if (isRemove) {

				for (NameValue nameValue : existingNameValue.getChildrenNameValues()) { 
					nameValue.setValUpdtFlg(false);
				}
				finalExpagProperties.getProperties().add(existingNameValue);
			}
			
		}

		// Loop and populate the UPDATE the existing identifier
		for (NameValue existingNameValue : existingExpagProperties.getProperties()) {

			for (NameValue currentNameValue : currentExpagProperties.getProperties()) {

				boolean isUpdate = false;
				String newValue = "";
				String idDesc = "";
				BigInteger dispSeqNumber = BigInteger.valueOf(0);
				BigInteger id = BigInteger.valueOf(0);

					if ((currentNameValue != null) && (existingNameValue != null)) {
						
						String currentId = currentNameValue.getID() != null ? currentNameValue.getID() : "";
							
						if(currentNameValue.getID() == null){
							isUpdate = false;
							break;
						}else if (currentNameValue.getDesc().equalsIgnoreCase(existingNameValue.getDesc()) 
								&& currentId.equalsIgnoreCase(existingNameValue.getID())) {
	
							isUpdate = false;
	
							for (NameValue newChildNameValue : currentNameValue.getChildrenNameValues()) {
	
								for (NameValue existingChildNameValue : existingNameValue.getChildrenNameValues()) {
	
									if ((newChildNameValue != null) && newChildNameValue.getName().equalsIgnoreCase(existingChildNameValue.getName())) {
	
										if( newChildNameValue.getValue() != null){
											if ( !newChildNameValue.getValue().equalsIgnoreCase(existingChildNameValue.getValue()==null?"":existingChildNameValue.getValue())) {
												isUpdate = true;
												
												newValue = newChildNameValue.getValue();
												dispSeqNumber = newChildNameValue.getDsplSqncNbr();
												idDesc = currentNameValue.getDesc();
												id = new BigInteger(currentId);
												
												break;
											}
										}
									}
								}
							}
	
						}
					}

					if (isUpdate) {
						//Use SQL query to update EXPAG identifiers
						expagdao.updateEXPAGIdentifiers(newValue, id, idDesc, dispSeqNumber, expagExistingTask.getTaskid());
					}
					
				}
			}
		return finalExpagProperties;
	}
	

	/**
	 * Convert CMS properties to EXPAG Task Identifiers
	 * @param cmsProperties - List of NameValue
	 * @param useIdentifiersId 
	 * @return List of ProcessIdentifier
	 */
	public List<org.tiaa.esb.powerimage.types.ProcessIdentifier> cmsPropertiesToexpagProcessTaskIdentifiers(List<NameValue> cmsProperties, String useIdentifiersId) {
		List<org.tiaa.esb.powerimage.types.ProcessIdentifier> expagIdentifiers = new ArrayList<org.tiaa.esb.powerimage.types.ProcessIdentifier>();
		
		for (int i = 0; i < cmsProperties.size(); i++) {

			//Identifier cmsIdentifier = cmsIdentifiers.get(i);
			NameValue cmsNameValue = cmsProperties.get(i);
				
			org.tiaa.esb.powerimage.types.ProcessIdentifier expagIdentifier = new org.tiaa.esb.powerimage.types.ProcessIdentifier();
			
			if(useIdentifiersId != null && TRUE.equalsIgnoreCase(useIdentifiersId)){
				expagIdentifier.setId(BigInteger.valueOf(Integer.parseInt(cmsNameValue.getID())));
			} else {
				expagIdentifier.setId(BigInteger.valueOf(i + 1));
			}

			expagIdentifier.setIddesc(cmsNameValue.getDesc());

			if (cmsNameValue.getChildrenNameValues() != null) {
				for (NameValue childNameValue : cmsNameValue.getChildrenNameValues()) { //SubField subField : cmsIdentifier.getSubFields().getSubFields()

					org.tiaa.esb.powerimage.types.ProcessIdentifier.Fieldinfo fieldinfo = new org.tiaa.esb.powerimage.types.ProcessIdentifier.Fieldinfo();
					fieldinfo.setFldnbr(childNameValue.getDsplSqncNbr().intValue());
					fieldinfo.setFieldname(childNameValue.getName());
					fieldinfo.setFieldvalue(childNameValue.getValue());

					//	expagIdentifier.setStatus(subField.getFieldStatus());
					//	expagIdentifier.setStatus(cmsNameValue.getStatus());//TODO: get this field in NameValue -  isValUpdtFlg is used instead
					if(childNameValue.isValUpdtFlg()){
						expagIdentifier.setStatus("ADD");
					}
					if(!childNameValue.isValUpdtFlg()){
						expagIdentifier.setStatus("DEL");
					}
					// Add each fieldinfo to the expag identifier after parsing
					expagIdentifier.getFieldinfos().add(fieldinfo);
				}

				// Finally add each identifier to the cmsidentifiers list
				expagIdentifiers.add(expagIdentifier);
			}
		}

		return expagIdentifiers;
	}

}
