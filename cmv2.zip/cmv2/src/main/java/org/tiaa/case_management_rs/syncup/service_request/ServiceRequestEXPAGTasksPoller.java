package org.tiaa.case_management_rs.syncup.service_request;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;

import org.tiaa.case_management_rs.domain.WorkflowSystem;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTasksDAO;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTasksPoller;
import org.tiaa.case_management_rs.poller.Poller;

@Poller
public class ServiceRequestEXPAGTasksPoller extends EXPAGTasksPoller {
	@Autowired
	private EXPAGTasksDAO serviceRequestEXPAGTasksDAO;
	@Autowired
	private ServiceRequestEXPAGTaskProcessor serviceRequestEXPAGTaskProcessor;

	public ServiceRequestEXPAGTasksPoller() {
		super(WorkflowSystem.EXP_AG_ServiceRequest);
	}

	@PostConstruct
	public void init() {
		expagTasksDAO = serviceRequestEXPAGTasksDAO;
		taskProcessor = serviceRequestEXPAGTaskProcessor;
	}

	/*
	 * *******************************************************************************************************
	 * DISABLING CM POLLER FOR OCT 2016 POLLER, by commenting @Scheduled
	 * ********************************************************************************************************
	 */
//	@Scheduled(cron = EVERY_MINUTE)
	public void pollDatabase() {
		pollWithLock(this);
	}

	public void run() {
		int secondStartingAtZero = 0;
		pollForInterval(secondStartingAtZero);
	}
}
