package org.tiaa.case_management_rs.integration.activiti;

import org.tiaa.esb.case_management_rs_v2.type.CommentsRequest;
import org.tiaa.esb.case_management_rs_v2.type.CommentsResponse;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItems;
import org.tiaa.esb.case_management_rs_v2.type.DocumentRequest;
import org.tiaa.esb.case_management_rs_v2.type.DocumentResponse;
import org.tiaa.esb.case_management_rs_v2.type.DocumentsResponse;
import org.tiaa.esb.case_management_rs_v2.type.Metrics;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.ProcessRequest;
import org.tiaa.esb.case_management_rs_v2.type.ProcessResponse;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.ProcessesRequest;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;
import org.tiaa.esb.case_management_rs_v2.type.SearchResponse;
import org.tiaa.esb.case_management_rs_v2.type.Task;
import org.tiaa.esb.case_management_rs_v2.type.TaskRequest;
import org.tiaa.esb.case_management_rs_v2.type.TaskResponse;


public interface ActivitiRepository {
	public ProcessResponse getActivitiProcess(String processId, String userId, String lockMode, String section, String convertedEXPAGTask);

	public DocumentsResponse getActivitiDocuments(String processId, String userId, String convertedExpag);

	public DocumentResponse getActivitiDocument(String processId,
			String userId, String documentId, String convertedExpag);

	public CommentsResponse getActivitiComments(String processId, String userId);

	public CommentsResponse getActivitiTaskComments(String processId, String userId,
			String taskId);

	 public CommentsResponse addActivitiComment(String processId, String
	 userId,CommentsRequest commentRequest);

	public ProcessResponse getActivitiTasks(String processId, String userId);

	public TaskResponse getActivitiTaskById(String processId, String userId,
			String taskId);

	public Processes getActivitiTasksClaimable(String userId, String dept, String type, String convertedExpagTask);

	public DocumentResponse addActivitiDocument(DocumentRequest documentRequest,
			String taskId, String userId, String convertedExpag);

	public Process updateActivitiProcess(ProcessRequest processRequest, String userId, String processId, String convertedEXPAGTask);
	
	public SearchResponse search(SearchRequest searchRequest,
			String userId);
	
	public ConfigItems getActivitiConfigItems(String property, String userId,String department);
	
	/**
	 * This method invokes the createProcesses in Activiti.
	 * @param processRequest
	 * @param userId
	 * @return
	 */
	public Processes createActivitiProcesses(ProcessesRequest processesRequest, String userId, String convertedEXPAGTask);
	
	
	public Metrics getActivitiMetrics(String userId,String department);
	
	public Task updateActivitiTask(TaskRequest taskRequest, String userId, String processId,String taskId);
	
	public ConfigItems getActivitiSolutionHeaders(String department, String userId, String tableheader) ;
	
	public ConfigItems getActivitiCaseWorkers(String userId, String property, SearchRequest srchRequest);
	
	public Processes updateActivitiProcesses(String userId, ProcessesRequest processesReq,String convertedEXPAGTask);
	
	public Processes getActivitiRelatedProcesses(String userId, String processId);
	
	public void deleteActivitiDocument(String processId, String documentId, String userId);

	public Process createActivitiRelatedTask(ProcessRequest processReq, String userId, String processId,String caseId);
	
	public DocumentResponse updateActivitiDocument(DocumentRequest activitiDocumentReq, String taskId, String userId, String convertedExpag);

	public ProcessResponse getActivitiTaskAdditionalDetails(String processId, String userId);
}
