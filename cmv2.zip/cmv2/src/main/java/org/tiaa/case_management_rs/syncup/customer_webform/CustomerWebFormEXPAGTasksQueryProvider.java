package org.tiaa.case_management_rs.syncup.customer_webform;

import org.springframework.beans.factory.annotation.Value;

import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTaskType;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTasksQueryProvider;

@EXPAGTaskType(schemaName="customer-webform-1-0-clob.xsd")
public class CustomerWebFormEXPAGTasksQueryProvider implements EXPAGTasksQueryProvider {
	@Value("${CustomerWebFormEXPAGTaskStatusForTaskTypes}")
	private String taskStatusForTaskTypesSql1;
	@Value("${CustomerWebFormEXPAGNewDocumentsUploadedThroughEXPAGUI}")
	private String newDocumentsUploadedThroughEXPAGUI1;
	@Value("${CustomerWebFormEXPAGNewDocumentsUploadedDuringTaskCompletionThroughEXPAGUI}")
	private String newDocumentsUploadedDuringTaskCompletionThroughEXPAGUI1;
	@Value("${CustomerWebFormEXPAGTaskEventsForTaskTypes}")
	private String taskEventsForTaskTypes1;
	@Value("${CustomerWebFormEXPAGTaskStatusForTaskIdOccurredAt}")
	private String taskStatusForTaskIdOccurredAt1;
	@Value("${CustomerWebFormEXPAGAllDocumentsUploadedThroughEXPAGUI}")
	private String allDocumentsUploadedThroughEXPAGUI1;
	@Value("${CustomerWebFormEXPAGAllDocumentsUploadedDuringTaskCompletionThroughEXPAGUI}")
	private String allDocumentsUploadedDuringTaskCompletionThroughEXPAGUI1;
	@Value("${EXPAGTaskStatusForTaskIds}")
	private String taskStatusForTaskIdsSql;

	@Override
	public String getTaskStatusForTaskTypesSql() {
		return taskStatusForTaskTypesSql1;
	}

	@Override
	public String getNewDocumentsUploadedThroughEXPAGUI() {
		return newDocumentsUploadedThroughEXPAGUI1;
	}

	@Override
	public String getNewDocumentsUploadedDuringTaskCompletionThroughEXPAGUI() {
		return newDocumentsUploadedDuringTaskCompletionThroughEXPAGUI1;
	}

	@Override
	public String getTaskEventsForTaskTypes() {
		return taskEventsForTaskTypes1;
	}

	@Override
	public String getTaskStatusForTaskIdOccurredAt() {
		return taskStatusForTaskIdOccurredAt1;
	}

	@Override
	public String getCthRequestSchemaName() {
		return "customer-webform-1-0-clob.xsd";
	}

	public String getAllDocumentsUploadedThroughEXPAGUI() {
		return allDocumentsUploadedThroughEXPAGUI1;
	}

	public String getAllDocumentsUploadedDuringTaskCompletionThroughEXPAGUI() {
		return allDocumentsUploadedDuringTaskCompletionThroughEXPAGUI1;
	}

	@Override
	public String getTaskStatusForTaskIdsSql() {
		return taskStatusForTaskIdsSql;
	}
}
