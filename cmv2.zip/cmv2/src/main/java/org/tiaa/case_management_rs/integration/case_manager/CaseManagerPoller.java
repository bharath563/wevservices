package org.tiaa.case_management_rs.integration.case_manager;

import java.util.List;

import org.apache.log4j.MDC;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Scheduled;

import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.CMSPollerLog;
import org.tiaa.case_management_rs.domain.WorkflowSystem;
import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;
import org.tiaa.case_management_rs.poller.IPoller;
import org.tiaa.case_management_rs.poller.Poller;
import org.tiaa.case_management_rs.poller.PollingContext;
import org.tiaa.case_management_rs.poller.WorkflowSystemPoller;

@Poller
public class CaseManagerPoller extends WorkflowSystemPoller implements FailedCaseManagerCaseRetrier {
	@Autowired
	private CaseManagerDAO caseManagerDAO;
	@Autowired
	private CaseManagerCaseProcessor caseManagerCaseProcessor;
	private static Object monitor = new Object();

	protected CaseManagerPoller() {
		super(WorkflowSystem.CaseManager);
	}

	public boolean pollWithLock(IPoller poller) {
		boolean poll = false;
		synchronized (monitor) {
			final String name = poller.getClass().getName();
			this.statusLogger.debug("Start Attempt to run poller:{}", name);
			poll = poller.poll();
			this.statusLogger.debug("End Attempt to run poller:{}", name);
		}
		return poll;
	}

	protected void execute(CMSPollerLog pollerLog) {
		log.debug("Poll CaseManager");
		pollerLog.printInfo();
		PollingContext pollingContext = new PollingContext();
		pollingContext.setPollerLog(pollerLog);
		List<CaseDetails> caseDetailsList = caseManagerDAO.retrieveCaseDetailList(pollingContext);
		log.info("Processing:" + caseDetailsList.size() + " cases");
		for (CaseDetails caseDetails : caseDetailsList) {
			MDC.put("X-INF-RequestID", caseDetails.getCaseId());
			try {
				caseManagerCaseProcessor.processCase(caseDetails);
			} catch (Exception e) {
				log.warn(e.getMessage(), e);
			} finally {
				MDC.remove("X-INF-RequestID");
			}
		}
	}

	public void execute(CMSAuditHistory cmsAuditHistory) {
		String caseId = cmsAuditHistory.getCmsAudit().getCaseId();
		CaseDetails caseDetails = caseManagerDAO.getCaseDetails(caseId);
		if (caseDetails != null) {
			caseManagerCaseProcessor.processCase(caseDetails, cmsAuditHistory);
		} else {
			log.warn("unable to retrieve case details for case id:" + caseId);
		}
	}

	public void executeWithLock(CMSAuditHistory cmsAuditHistory) {
		synchronized (monitor) {
			execute(cmsAuditHistory);
		}
	}

	/*
	 * *******************************************************************************************************
	 * DISABLING CM POLLER FOR OCT 2016 POLLER, by commenting @Scheduled
	 * ********************************************************************************************************
	 */
//	@Scheduled(cron = EVERY_MINUTE_AT_45TH_SECOND)
	public void pollDatabase() {
		pollWithLock(this);
	}

	public void run() {
		int secondStartingAtFortyFive = 45;
		pollForInterval(secondStartingAtFortyFive);
	}

	@Override
	public void retryFailedCaseManagerCase(final CMSAuditHistory cmsAuditHistory) {
		this.exceptionHandler.run(new Runnable() {
			@Override
			public void run() {
				executeWithLock(cmsAuditHistory);
			}
		});
	}
}
