package org.tiaa.case_management_rs.validator.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.apache.commons.lang3.StringUtils;

import org.tiaa.case_management_rs.common.Request;

public class GetDocumentValidator extends BaseValidatorImpl {

	@Override
	public void doValidate(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		String docId = (String) request.getAttribute(DOCUMENT_ID);
		String appName = (String) request.getAttribute(APP_NAME);
		String extDocKey = (String) request.getAttribute(EXT_DOC_KEY);
		String businessUnitCode = (String) request.getAttribute(BUSINESS_UNIT_CODE);
		String docCode = (String) request.getAttribute(DOC_CODE);
		String version = (String) request.getAttribute(VERSION);
		String idType = (String) request.getAttribute(ID_TYPE);


		if (StringUtils.isBlank(userId)) {
			handleException(VALIDATION_USERID_IS_EMPTY);
		}
		if (StringUtils.isBlank(appName)) {
			handleException(VALIDATION_APPNAME_IS_EMPTY);
		}

		if (StringUtils.isBlank(docId) && StringUtils.isBlank(extDocKey)) {
			handleException(VALIDATION_BOTH_TASKID_CASID_IS_EMPTY);
		}

		if(appName!=null && appName.equalsIgnoreCase(APP_ICM)){
			if (StringUtils.isBlank(businessUnitCode)) {
				handleException(VALIDATION_BUSINESS_UNIT_CODE_IS_EMPTY);
			}
			if (StringUtils.isBlank(docCode)) {
				handleException(VALIDATION_DOC_CODE_IS_EMPTY);
			}
			if (StringUtils.isBlank(version)) {
				handleException(VALIDATION_VERSION_VALUE_IS_EMPTY);
			}
			if (StringUtils.isBlank(idType)) {
				handleException(VALIDATION_ID_TYPE_IS_EMPTY);
			}
		}

	}
}
