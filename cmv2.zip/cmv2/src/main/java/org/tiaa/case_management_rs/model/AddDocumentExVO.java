package org.tiaa.case_management_rs.model;

public class AddDocumentExVO {
	private String userId;
	private String taskId; // Optional
	private String packetId;
	private String storage;
	private String extDocKey; // Optional
	private String extSysName; // Optional
	private String urlDocPath; // Optional
	private String notes; // Optional
	private String wrkStationId;
	private int pageTotal;
	private String mailDesc; // Optional
	private String mailId; // Optional
	private String archBox; // Optional
	private String magFldName; // Optional
	private float fileSize;
	private String fileType; // Optional
	private String piDocType;
	private String faxNumber; // Optional
	private String contType; // Optional
	private int startPage; // Optional
	private int endPage; // Optional
	private boolean taskOnlyFlag; // Optional

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTaskId() {
		return this.taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getPacketId() {
		return this.packetId;
	}

	public void setPacketId(String packetId) {
		this.packetId = packetId;
	}

	public String getStorage() {
		return this.storage;
	}

	public void setStorage(String storage) {
		this.storage = storage;
	}

	public String getExtDocKey() {
		return this.extDocKey;
	}

	public void setExtDocKey(String extDocKey) {
		this.extDocKey = extDocKey;
	}

	public String getExtSysName() {
		return this.extSysName;
	}

	public void setExtSysName(String extSysName) {
		this.extSysName = extSysName;
	}

	public String getUrlDocPath() {
		return this.urlDocPath;
	}

	public void setUrlDocPath(String urlDocPath) {
		this.urlDocPath = urlDocPath;
	}

	public String getNotes() {
		return this.notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getWrkStationId() {
		return this.wrkStationId;
	}

	public void setWrkStationId(String wrkStationId) {
		this.wrkStationId = wrkStationId;
	}

	public int getPageTotal() {
		return this.pageTotal;
	}

	public void setPageTotal(int pageTotal) {
		this.pageTotal = pageTotal;
	}

	public String getMailDesc() {
		return this.mailDesc;
	}

	public void setMailDesc(String mailDesc) {
		this.mailDesc = mailDesc;
	}

	public String getMailId() {
		return this.mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getArchBox() {
		return this.archBox;
	}

	public void setArchBox(String archBox) {
		this.archBox = archBox;
	}

	public String getMagFldName() {
		return this.magFldName;
	}

	public void setMagFldName(String magFldName) {
		this.magFldName = magFldName;
	}

	public float getFileSize() {
		return this.fileSize;
	}

	public void setFileSize(float fileSize) {
		this.fileSize = fileSize;
	}

	public String getFileType() {
		return this.fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getPiDocType() {
		return this.piDocType;
	}

	public void setPiDocType(String piDocType) {
		this.piDocType = piDocType;
	}

	public String getFaxNumber() {
		return this.faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getContType() {
		return this.contType;
	}

	public void setContType(String contType) {
		this.contType = contType;
	}

	public int getStartPage() {
		return this.startPage;
	}

	public void setStartPage(int startPage) {
		this.startPage = startPage;
	}

	public int getEndPage() {
		return this.endPage;
	}

	public void setEndPage(int endPage) {
		this.endPage = endPage;
	}

	public boolean isTaskOnlyFlag() {
		return this.taskOnlyFlag;
	}

	public void setTaskOnlyFlag(boolean taskOnlyFlag) {
		this.taskOnlyFlag = taskOnlyFlag;
	}

}
