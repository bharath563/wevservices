package org.tiaa.case_management_rs.integration.case_manager;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import org.tiaa.case_management_rs.domain.CMSPollerLog;
import org.tiaa.case_management_rs.integration.case_manager.domain.Case;
import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;
import org.tiaa.case_management_rs.poller.PollingContext;
import org.tiaa.case_management_rs.utils.CommonUtil;

@Repository
public class CaseManagerDAO {
	private static final Logger LOG = LoggerFactory.getLogger(CaseManagerDAO.class);
	public static final Object[] EMPTY_ARGS = new Object[] {};
	@Autowired
	private JdbcTemplate caseManagerJdbcTemplate;
	@Value("${CaseManagerCasePhaseInfoDetails}")
	private String casePhaseInfoDetails;
	@Value("${CaseManagerCasePhaseInfoDetailsForCaseIds}")
	private String caseManagerCasePhaseInfoDetailsForCaseIds;
	@Value("${CaseManagerCaseDocumentInfoDetails}")
	private String caseDocumentInfoDetails;
	@Value("${CaseManagerCaseDocumentInfoDetailsForCaseIds}")
	private String caseDocumentInfoDetailsForCaseIds;
	private CasePhaseInfoRSExtractor casePhaseInfoRSExtractor = new CasePhaseInfoRSExtractor();
	private CaseIdsExtractor caseIdsExtractor = new CaseIdsExtractor();
	private static final int CHUNK_SIZE = 100;
	@Value("${casesInProgress}")
	private String casesInProgress;
	@Value("${casesProcessed}")
	private String casesProcessed;
	//
	public List<CaseDetails> retrieveCaseDetailList(PollingContext pollingContext) {
		Object[] queryParams = getQueryParams(pollingContext);
		Object[] queryParamsForDocuments = getQueryParamsForDocuments(pollingContext);
		List<String> caseIdsWithPhaseInfo = queryList(casePhaseInfoDetails, queryParams, caseIdsExtractor);
		List<String> caseIdsWithNewDocuments = queryList(caseDocumentInfoDetails, queryParamsForDocuments, caseIdsExtractor);
		//
		TreeSet<String> allCaseIds = new TreeSet<String>(caseIdsWithPhaseInfo);
		allCaseIds.addAll(caseIdsWithNewDocuments);
		//
		LOG.debug("caseIds:" + allCaseIds);
		if (allCaseIds.isEmpty()) {
			return Collections.emptyList();
		}
		Map<String, String> phaseNameToPhaseDescriptionMap = getPhaseNameToPhaseDescriptionMap();
		if (allCaseIds.size() <= CHUNK_SIZE) {
			return getCaseDetailList(allCaseIds, phaseNameToPhaseDescriptionMap);
		}
		ArrayList<String> allCaseIdList = new ArrayList<String>(allCaseIds);
		int size = allCaseIdList.size();
		int noOfChunks = size / CHUNK_SIZE;
		if (size % CHUNK_SIZE > 0) {
			noOfChunks++;
		}
		int fromIndex = 0;
		List<CaseDetails> caseDetailList = new ArrayList<CaseDetails>(size);
		for (int ii = 0; ii < noOfChunks; ii++) {
			int toIndex = fromIndex + CHUNK_SIZE;
			if (toIndex > size) {
				toIndex = size;
			}
			LOG.debug("fromIndex: {}, toIndex: {}", fromIndex, toIndex);
			List<String> caseIdSubList = allCaseIdList.subList(fromIndex, toIndex);
			List<CaseDetails> caseDetailSubList = getCaseDetailList(caseIdSubList, phaseNameToPhaseDescriptionMap);
			caseDetailList.addAll(caseDetailSubList);
			fromIndex += CHUNK_SIZE;
		}
		return caseDetailList;
	}

	public CaseDetails getCaseDetails(String caseId) {
		List<CaseDetails> caseDetailList = getCaseDetailList(Collections.singletonList(caseId));
		return caseDetailList.isEmpty() ? null : caseDetailList.get(0);
	}

	public List<CaseDetails> getCaseDetailList(Collection<String> caseIds) {
		Map<String, String> phaseNameToPhaseDescriptionMap = getPhaseNameToPhaseDescriptionMap();
		return getCaseDetailList(caseIds, phaseNameToPhaseDescriptionMap);
	}

	public List<CaseDetails> getCaseDetailList(Collection<String> caseIds, Map<String, String> phaseNameToPhaseDescriptionMap) {
		String caseIdsCommaSeparated = "(" + CommonUtil.toStringSingleQuoted(caseIds) + ")";
		LOG.debug("caseIdsCommaSeparated:" + caseIdsCommaSeparated);
		//
		String sqlPhaseInfoQuery = caseManagerCasePhaseInfoDetailsForCaseIds.replace("?", caseIdsCommaSeparated);
		Map<String, Case> caseMap = query(sqlPhaseInfoQuery, EMPTY_ARGS, casePhaseInfoRSExtractor);
		if (caseMap == null) {
			caseMap = new HashMap<String, Case>();
		}
		//
		String sqlDocumentQuery = caseDocumentInfoDetailsForCaseIds.replace("?", caseIdsCommaSeparated);
		query(sqlDocumentQuery, EMPTY_ARGS, new CaseDocumentRSExtractor(caseMap));
		//
		ArrayList<CaseDetails> caseDetailList = new ArrayList<CaseDetails>();
		for (Case kase : caseMap.values()) {
			kase.getPhases().setPhaseNameToPhaseDescriptionMap(phaseNameToPhaseDescriptionMap);
			caseDetailList.add(new CaseDetails(kase));
		}
		LOG.debug("caseDetailList:" + caseDetailList.size());
		return caseDetailList;
	}

	public Map<String, String> getPhaseNameToPhaseDescriptionMap() {
		return caseManagerJdbcTemplate.query("select PHASE_NAME, PHASE_DESCRIPTION from ICS_PHASE_KEY", new ResultSetExtractor<Map<String, String>>() {
			@Override
			public Map<String, String> extractData(ResultSet rs) throws SQLException, DataAccessException {
				Map<String, String> phaseNameToPhaseDescriptionMap = new HashMap<String, String>();
				while (rs.next()) {
					phaseNameToPhaseDescriptionMap.put(rs.getString(1), rs.getString(2));
				}
				return phaseNameToPhaseDescriptionMap;
			}
		});
	}

	public <T> List<T> queryList(String query, Object[] queryParams, ResultSetExtractor<List<T>> resultSetExtractor) {
		List<T> results = query(query, queryParams, resultSetExtractor);
		if (results != null) {
			return results;
		}
		return Collections.emptyList();
	}

	public List<String> getAllCaseIdsInProgress() {
		return query(casesInProgress, CaseManagerDAO.EMPTY_ARGS, caseIdsExtractor);
	}

	public List<String> getCaseIdsProcessed() {
		return query(casesProcessed, CaseManagerDAO.EMPTY_ARGS, caseIdsExtractor);
	}

	public <T> T query(String sql, Object[] args, ResultSetExtractor<T> resultSetExtractor) {
		try {
			T rows = caseManagerJdbcTemplate.query(sql, resultSetExtractor, args);
			return rows;
		} catch (DataAccessException e) {
			LOG.warn("sql:{}", sql);
			for (Object object : args) {
				LOG.warn("arg:{}", object);
			}
			LOG.warn(e.getMessage(), e);
		}
		return null;
	}

	private Object[] getQueryParams(PollingContext pollingContext) {
		CMSPollerLog processingInfo = pollingContext.getPollerLog();
		Date lastProcessedDateTime = processingInfo.getLastProcessedDateTime();
		return new Object[] { lastProcessedDateTime, lastProcessedDateTime, lastProcessedDateTime, lastProcessedDateTime };
	}

	private Object[] getQueryParamsForDocuments(PollingContext pollingContext) {
		CMSPollerLog processingInfo = pollingContext.getPollerLog();
		Date lastProcessedDateTime = processingInfo.getLastProcessedDateTime();
		return new Object[] { lastProcessedDateTime, lastProcessedDateTime, lastProcessedDateTime };
	}

	private static class CaseIdsExtractor implements ResultSetExtractor<List<String>> {
		@Override
		public List<String> extractData(ResultSet rs) throws SQLException, DataAccessException {
			TreeSet<String> caseIds = new TreeSet<String>();
			while (rs.next()) {
				caseIds.add(rs.getString("case_id"));
			}
			return new ArrayList<String>(caseIds);
		}
	}

}