package org.tiaa.case_management_rs.integration.case_manager;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.Marshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.common.ExceptionHandler;
import org.tiaa.case_management_rs.integration.case_manager.cth.CTHCaseRecordCreator;
import org.tiaa.case_management_rs.integration.case_manager.cth.CTHCaseRecordRetriever;
import org.tiaa.case_management_rs.integration.case_manager.cth.CTHCaseRecordUpdater;
import org.tiaa.case_management_rs.integration.case_manager.cth.CTHCaseWebService;
import org.tiaa.case_management_rs.integration.case_manager.cth.CTHCaseWebServiceLogger;
import org.tiaa.case_management_rs.integration.case_manager.cth.CaseManagerCreateHierarchyPartyRequestBuilder;
import org.tiaa.case_management_rs.integration.case_manager.cth.PayloadInfoBuilder;
import org.tiaa.case_management_rs.integration.case_manager.cth.RetrieveRequestsBuilder;
import org.tiaa.case_management_rs.integration.case_manager.cth.RetrieveRequestsResponseProcessor;
import org.tiaa.case_management_rs.integration.case_manager.cth.RetryableCTHCaseRecordCreator;
import org.tiaa.case_management_rs.integration.case_manager.cth.RetryableCTHCaseRecordUpdater;
import org.tiaa.case_management_rs.integration.cth.CTHWsConfig;

@Configuration
public class CTHCaseManagerConfig {
	@Autowired
	private CTHWsConfig cthWsConfig;

	@Bean
	public RetryableCTHCaseRecordCreator retryableCTHCaseRecordCreator() {
		return new RetryableCTHCaseRecordCreator(cthWsConfig.cthWSRetryTemplate(), caseManagerCthRecordCreator());
	}

	@Bean
	public RetryableCTHCaseRecordUpdater retryableCTHCaseRecordUpdater() {
		return new RetryableCTHCaseRecordUpdater(cthWsConfig.cthWSRetryTemplate(), caseManagerCthRecordUpdater());
	}

	@Bean
	public CTHCaseWebService cthCaseWebService() {
		CTHCaseWebService cthWebService = new CTHCaseWebService();
		cthWebService.setCthWebServiceTemplate(cthWsConfig.cthWebServiceTemplate());
		return cthWebService;
	}

	@Bean
	public CTHCaseWebService cthCaseWebServiceLogger() {
		CTHCaseWebServiceLogger cthWebService = new CTHCaseWebServiceLogger();
		cthWebService.setCthWebServiceTemplate(cthWsConfig.cthWebServiceTemplate());
		cthWebService.setCthJaxb2WorkflowMarshaller(cthWsConfig.cthJaxb2Marshaller());
		return cthWebService;
	}

	@Bean
	public CTHCaseRecordCreator caseManagerCthRecordCreator() {
		CTHCaseRecordCreator cthCaseRecordCreator = new CTHCaseRecordCreator();
		cthCaseRecordCreator.setCreateHierarchyPartyRequestBuilder(caseManagerCreateHierarchyPartyRequestBuilder());
		cthCaseRecordCreator.setCthCaseWebService(cthCaseWebService());
		return cthCaseRecordCreator;
	}

	@Bean
	public CTHCaseRecordRetriever caseManagerCthRecordRetriever() {
		CTHCaseRecordRetriever cthRecordRetriever = new CTHCaseRecordRetriever(new RetrieveRequestsBuilder("ServiceRequest", "InstitutionalImplementationRequest"));
		cthRecordRetriever.setCthWebService(cthCaseWebService());
		return cthRecordRetriever;
	}

	@Bean
	public CTHCaseRecordUpdater caseManagerCthRecordUpdater() {
		CTHCaseRecordUpdater cthCaseRecordUpdater = new CTHCaseRecordUpdater();
		cthCaseRecordUpdater.setCthCaseWebService(cthCaseWebService());
		cthCaseRecordUpdater.setCthRecordRetriever(caseManagerCthRecordRetriever());
		cthCaseRecordUpdater.setRetrieveRequestsResponseProcessor(caseManagerServiceRequestCTHClobProcessor());
		return cthCaseRecordUpdater;
	}

	@Bean
	public RetrieveRequestsResponseProcessor caseManagerServiceRequestCTHClobProcessor() {
		RetrieveRequestsResponseProcessor serviceRequestProcessor = new RetrieveRequestsResponseProcessor();
		serviceRequestProcessor.setServicerequestWorkflowJaxb2Marshaller(cthWsConfig.serviceRequestWorkflowJaxb2Marshaller());
		serviceRequestProcessor.setPayloadInfoBuilder(caseManagerPayloadInfoBuilder());
		return serviceRequestProcessor;
	}

	@Bean
	public CaseManagerCreateHierarchyPartyRequestBuilder caseManagerCreateHierarchyPartyRequestBuilder() {
		CaseManagerCreateHierarchyPartyRequestBuilder createHierarchyPartyRequestBuilder = new CaseManagerCreateHierarchyPartyRequestBuilder();
		createHierarchyPartyRequestBuilder.setCthRequestBuilder(caseManagerPayloadInfoBuilder());
		return createHierarchyPartyRequestBuilder;
	}

	@Bean
	public PayloadInfoBuilder caseManagerPayloadInfoBuilder() {
		PayloadInfoBuilder caseManagerPayloadInfoBuilder = new PayloadInfoBuilder("service-request-1-0-clob.xsd", "1.0");
		caseManagerPayloadInfoBuilder.setServicerequestWorkflowJaxb2Marshaller(cthWsConfig.serviceRequestWorkflowJaxb2Marshaller());
		caseManagerPayloadInfoBuilder.setServiceRequestJaxb2Marshaller(caseManagerServiceRequestJaxb2Marshaller());
		return caseManagerPayloadInfoBuilder;
	}

	@Bean
	public Jaxb2Marshaller caseManagerServiceRequestJaxb2Marshaller() {
		Map<String, Object> marshallerProperties = new HashMap<String, Object>();
		marshallerProperties.put(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		//
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		jaxb2Marshaller.setClassesToBeBound(org.tiaa.esb.servicerequest.types.ObjectFactory.class);
		ExceptionHandler.initalize(jaxb2Marshaller);
		return jaxb2Marshaller;
	}

	@Bean
	public CaseManagerCMSAuditService caseManagerCMSAuditService() {
		return new CaseManagerCMSAuditService();
	}
}
