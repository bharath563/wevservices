package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.Reason;

/**
 * This class is responsible for mapping the QC fail action detail to Reasons
 * @author kumprad
 *
 */
public class QCReasonsMapper extends AbstractRowMapper<Reason> implements RowMapper<Reason> {

	@Override
	public Reason mapRow(ResultSet rs, int rowNum) throws SQLException {

		Reason reason = new Reason();
		reason.setReasonType(getStringTrimmed(rs, "FAILNAME"));
		reason.setReasonCode(getStringTrimmed(rs, "FAILCODE"));
		reason.setReasonDesc(getStringTrimmed(rs, "FAILDESC"));

		Date startDate = DateUtil.parseDateTime(getStringTrimmed(rs, "STARTDATE"), getStringTrimmed(rs, "STARTTIME"));	
		XMLGregorianCalendar startDateTime = DateUtil.toXMLGregorianCalendarDateTime(startDate);

		Date endDate = DateUtil.parseDateTime(getStringTrimmed(rs, "ENDDATE"), getStringTrimmed(rs, "ENDTIME"));	
		XMLGregorianCalendar endDateTime = DateUtil.toXMLGregorianCalendarDateTime(endDate);

		reason.setReasonStartTime(startDateTime);
		reason.setReasonEndTime(endDateTime);
		return reason;
	}

}
