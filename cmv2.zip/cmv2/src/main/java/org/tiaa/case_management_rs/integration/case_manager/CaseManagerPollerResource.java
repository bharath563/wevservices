package org.tiaa.case_management_rs.integration.case_manager;

import java.util.Arrays;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;
import org.tiaa.case_management_rs.repository.CMSAuditHistoryRepository;
import org.tiaa.case_management_rs.resource.MediaTypes;

@Component
@Path("/support/caseManager")
public class CaseManagerPollerResource {
	private static final Logger LOG = LoggerFactory.getLogger(CaseManagerPollerResource.class);
	@Autowired
	private CaseManagerDAO caseManagerDAO;
	@Autowired
	private CaseManagerCaseProcessor caseManagerCaseProcessor;
	@Autowired
	private CMSAuditHistoryRepository cmsAuditHistoryRepository;

	@Path("/cases/sync")
	@GET
	@Produces({ MediaTypes.V1_XML, MediaTypes.V1_JSON })
	public Response retryCasesSync(@QueryParam("caseIds") String caseIds) {
		StringBuilder stringBuilder = new StringBuilder();
		try {
			List<String> caseIdList = Arrays.asList(caseIds.split(","));
			for (CaseDetails caseDetails : caseManagerDAO.getCaseDetailList(caseIdList)) {
				try {
					caseManagerCaseProcessor.processCase(caseDetails);
					stringBuilder.append("Processing Successful for CaseId:").append(caseDetails.getCaseId()).append("\r\n<br/>");
				} catch (Exception e) {
					stringBuilder.append("Processing Failed for CaseId:").append(caseDetails.getCaseId()).append(", Error:").append(e.getMessage()).append("\r\n<br/>");
				}
			}
			return successResponse(stringBuilder.toString());
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
			return errorResponse(e);
		}
	}

	@Path("/cases/{caseId}/sync")
	@GET
	@Produces({ MediaTypes.V1_XML, MediaTypes.V1_JSON })
	public Response retryCaseSync(@PathParam("caseId") String caseId) {
		try {
			CaseDetails caseDetails = caseManagerDAO.getCaseDetails(caseId);
			caseManagerCaseProcessor.processCase(caseDetails);
			return successResponse("Processing Successful for CaseId:" + caseDetails.getCaseId());
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
			return errorResponse(e);
		}
	}

	@Path("/cases/{caseId}/sync/auditHistory/{auditHistoryId}")
	@GET
	@Produces({ MediaTypes.V1_XML, MediaTypes.V1_JSON })
	public Response retryCaseSyncForAuditId(@PathParam("caseId") String caseId, @QueryParam("auditHistoryId") long id) {
		try {
			CaseDetails caseDetails = caseManagerDAO.getCaseDetails(caseId);
			CMSAuditHistory cmsAuditHistory = cmsAuditHistoryRepository.findOne(id);
			caseManagerCaseProcessor.processCase(caseDetails, cmsAuditHistory);
			return successResponse("Processing Successful for CaseId:" + caseDetails.getCaseId());
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
			return errorResponse(e);
		}
	}

	private Response successResponse(String string) {
		return Response.ok(string).type("text/plain").build();
	}

	private Response errorResponse(Exception e) {
		return Response.status(Status.INTERNAL_SERVER_ERROR).entity(e).type("text/plain").build();
	}

}
