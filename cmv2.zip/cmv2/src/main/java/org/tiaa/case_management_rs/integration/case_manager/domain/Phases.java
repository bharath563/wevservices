package org.tiaa.case_management_rs.integration.case_manager.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Phases implements Serializable {
	private static final long serialVersionUID = 813139091812911799L;
	private List<Phase> phases;
	private Map<String, String> phaseTargetDateMap = new HashMap<String, String>();
	private Map<String, String> phaseNameToPhaseDescriptionMap;

	public Phase getCurrentPhase() {
		List<Phase> phaseList = getPhases();
		if (phaseList.isEmpty()) {
			return null;
		}

		ArrayList<Phase> list = new ArrayList<Phase>();
		for (Phase phase : phaseList) {
			if (phase.getStartedTS() != null) {
				list.add(phase);
			}
		}
		Collections.sort(list, new PhaseComparatorByStartDate());
		return list.get(0);
	}

	public String getCurrentPhaseDescription() {
		Phase currentPhase = getCurrentPhase();
		return currentPhase == null ? "" : currentPhase.getDescription();
	}

	public String getCurrentPhaseName() {
		Phase currentPhase = getCurrentPhase();
		return currentPhase == null ? "" : currentPhase.getName();
	}

	public String getCurrentPhaseNameAndDescription() {
		Phase currentPhase = getCurrentPhase();
		return currentPhase == null ? "" : currentPhase.getPhaseNameAndDescription();
	}

	public Date getCurrentPhaseTargetCompletionDateTime() {
		Phase currentPhase = getCurrentPhase();
		return currentPhase == null ? null : currentPhase.getTargetCompletionDateTime();
	}

	public String getCurrentPhaseTargetCompletionTS() {
		Phase currentPhase = getCurrentPhase();
		return currentPhase == null ? "" : currentPhase.getTargetCompletionTS();
	}

	public Map<String, String> getPhaseNameToPhaseDescriptionMap() {
		return phaseNameToPhaseDescriptionMap;
	}

	public List<Phase> getPhases() {
		if (phases == null) {
			phases = new ArrayList<Phase>();
		}
		Collections.sort(phases, new PhaseComparator());
		return this.phases;
	}

	public Map<String, String> getPhaseTargetDateMap() {
		return phaseTargetDateMap;
	}

	public void setPhaseNameToPhaseDescriptionMap(Map<String, String> phaseNameToPhaseDescriptionMap) {
		this.phaseNameToPhaseDescriptionMap = phaseNameToPhaseDescriptionMap;
		for (Phase phase : getPhases()) {
			phase.setDescription(phaseNameToPhaseDescriptionMap.get(phase.getName()));
		}
	}

	public void setPhases(List<Phase> phases) {
		this.phases = phases;
	}

	@Override
	public String toString() {
		return "Phases [phases=" + phases + ", phaseTargetDateMap=" + phaseTargetDateMap + ", phaseNameToPhaseDescriptionMap=" + phaseNameToPhaseDescriptionMap + "]";
	}

	static final class PhaseComparatorByStartDate implements Comparator<Phase> {
		@Override
		public int compare(Phase o1, Phase o2) {
			return o2.getStartedTS().compareTo(o1.getStartedTS());
		}
	}

	static final class PhaseComparator implements Comparator<Phase> {
		@Override
		public int compare(Phase o1, Phase o2) {
			return compareByName(o1, o2);
		}

		private int compareByName(Phase o1, Phase o2) {
			String name1 = o1.getName();
			String name2 = o2.getName();
			int result = name1.compareTo(name2);
			if (result != 0) {
				return result;
			}
			return compareByStartDate(o1, o2);
		}

		private int compareByStartDate(Phase o1, Phase o2) {
			Date startedTS1 = o1.getStartedTS();
			Date startedTS2 = o2.getStartedTS();
			if (startedTS1 != null && startedTS2 != null) {
				return startedTS1.compareTo(startedTS2);
			}
			if (startedTS1 != null) {
				return -1;
			}
			return 1;
		}

		int compareByTargetCompletionDateStartDateAndName(Phase o1, Phase o2) {
			Date targetCompletionDate1 = o1.getTargetCompletionDateTime();
			Date targetCompletionDate2 = o2.getTargetCompletionDateTime();
			if (targetCompletionDate1 != null && targetCompletionDate2 != null) {
				int result = targetCompletionDate1.compareTo(targetCompletionDate2);
				if (result != 0) {
					return result;
				}
			}
			return compareByStartDateAndName(o1, o2);
		}

		private int compareByStartDateAndName(Phase o1, Phase o2) {
			Date startedTS1 = o1.getStartedTS();
			Date startedTS2 = o2.getStartedTS();
			if (startedTS1 != null && startedTS2 != null) {
				int result = startedTS1.compareTo(startedTS2);
				if (result != 0) {
					return result;
				}
			}
			return compareByName(o1, o2);
		}
	}
}