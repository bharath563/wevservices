package org.tiaa.case_management_rs.delegate.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import org.tiaa.case_management_rs.activiti.helper.ActivitiConfigHelper;
import org.tiaa.case_management_rs.activiti.helper.ActivitiDocumentHelper;
import org.tiaa.case_management_rs.common.Request;
import org.tiaa.case_management_rs.dao.EXPAGDAO;
import org.tiaa.case_management_rs.delegate.CaseManagementDelegate;
import org.tiaa.case_management_rs.exception.CaseManagementRuntimeException;
import org.tiaa.case_management_rs.expag.helper.ExpagTaskHelper;
import org.tiaa.case_management_rs.integration.activiti.ActivitiRepositoryImpl;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.WorkflowException;
import org.tiaa.case_management_rs.integration.federeated_document.FederatedDocumentRSService;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.Comment;
import org.tiaa.esb.case_management_rs_v2.type.Comments;
import org.tiaa.esb.case_management_rs_v2.type.CommentsRequest;
import org.tiaa.esb.case_management_rs_v2.type.CommentsResponse;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItems;
import org.tiaa.esb.case_management_rs_v2.type.Document;
import org.tiaa.esb.case_management_rs_v2.type.DocumentRequest;
import org.tiaa.esb.case_management_rs_v2.type.Documents;
import org.tiaa.esb.case_management_rs_v2.type.DocumentsRequest;
import org.tiaa.esb.case_management_rs_v2.type.DocumentsResponse;
import org.tiaa.esb.case_management_rs_v2.type.History;
import org.tiaa.esb.case_management_rs_v2.type.Metrics;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.ProcessRequest;
import org.tiaa.esb.case_management_rs_v2.type.ProcessResponse;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.ProcessesRequest;
import org.tiaa.esb.case_management_rs_v2.type.Properties;
import org.tiaa.esb.case_management_rs_v2.type.RelatedTasks;
import org.tiaa.esb.case_management_rs_v2.type.Routing;
import org.tiaa.esb.case_management_rs_v2.type.SLADetail;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;
import org.tiaa.esb.case_management_rs_v2.type.SearchResponse;
import org.tiaa.esb.case_management_rs_v2.type.Status;
import org.tiaa.esb.case_management_rs_v2.type.Statuses;
import org.tiaa.esb.case_management_rs_v2.type.Task;
import org.tiaa.esb.case_management_rs_v2.type.TaskRequest;
import org.tiaa.esb.case_management_rs_v2.type.TaskResponse;
import org.tiaa.esb.case_management_rs_v2.type.Tasks;

@Repository(value="activitiAdapter")
public class ActivitiAdapter implements CaseManagementDelegate {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ActivitiAdapter.class);

	@Value("${filterConvertedTasks}")
	private String filterConvertedExpagTasks;
	
	@Autowired
	private ActivitiRepositoryImpl activitiRepositoryImpl;

	@Autowired
	private ActivitiDocumentHelper activitiDocumentHelper;
	
	@Autowired
	private FederatedDocumentRSService federatedDocumentRSService;
	
	@Autowired
	private ActivitiConfigHelper activitiConfigHelper;
	
	@Autowired
	private ExpagTaskHelper expagTaskHelper;
	
	@Autowired
	private EXPAGDAO expagdao;

	@Override
	public Processes getProcesses(Request request) {
	    String userId = (String) request.getAttribute(USER_ID);
		String type = (String) request.getAttribute(TYPE);
		String dept = (String) request.getAttribute(DEPARTMENT);
		String convertedExpagTask = String.valueOf(request.getAttribute(CONVERTED_EXPAG_TASK));
		Processes processes = activitiRepositoryImpl.getActivitiTasksClaimable(userId,dept, type, convertedExpagTask);
		if (YES.equalsIgnoreCase(filterConvertedExpagTasks)) {
			convertExpAgProcesses(processes);
		}
		
		return processes;
	}
	
	private void convertExpAgProcesses(Processes processes) {
		if (processes != null && processes.getProcesses() != null && processes.getProcesses().size() > 0) {
			List<Process> processList = processes.getProcesses();
			for (Process process : processList) {
				if (APP_CONVERTED_EXPAG.equalsIgnoreCase(process.getAppName())) {
					process.setAppName(APP_EXPAG);
				}
			}
		}
	}

	@Override
	public Process getProcess(Request request) {

		String convertedEXPAGTask = (String) request.getAttribute(CONVERTED_EXPAG_TASK);
		String userId = (String) request.getAttribute(USER_ID);
		Process process = new Process();
		try {

			ProcessResponse processResponse = getActivitiProcess(request);
			process.setProcessId(processResponse.getProcess().getProcessId());
			process.setProcessProperties(processResponse.getProcess().getProcessProperties());
			// Documents are returning as part of the getProcess call
			process.setDocuments(processResponse.getProcess().getDocuments());
			process.setAppName(processResponse.getProcess().getAppName());
			process.setEditMode(processResponse.getProcess().getEditMode());
			process.setLockedBy(processResponse.getProcess().getLockedBy());
			process.setHistory(processResponse.getProcess().getHistory());
			process.setStatusHistory(processResponse.getProcess().getStatusHistory());

			// Activiti RelatedTasks call
			Process processRelated = getRelatedProcesses(request);
			process.setRelatedTasks(processRelated.getRelatedTasks());

			// ACTIVITI documents call
			Documents documents = getDocuments(request);
			process.setDocuments(documents);

			if (YES.equalsIgnoreCase(convertedEXPAGTask)) {
				// TBD-- Need to check get tasks with converted-expag as a
				// parameter.
				process.setTasks(processResponse.getProcess().getTasks());
				process.setHistory(getTaskHistory(request));
				
				//Changes for OmniTrans and Edit defaults
				
				Task expagTask = processResponse.getProcess().getTasks().getTasks().get(0);
				
				org.tiaa.esb.case_management_rs_v2.type.Properties properties = this.expagTaskHelper.addOmniTransType(expagTask.getType(), expagTask.getActionStep(), expagTask.getTaskProperties());
				
				//Adding priority of a task as a property to show in Edit Defaults
				if(expagTask.getPriority() != null) {
					properties.getProperties().add(this.expagTaskHelper.addProperty(BigInteger.ONE, PROPERTY_NAME_PRIORITY, expagTask.getPriority(), PROPERTY_DESC_PRIORITY));
				}
				
				//Getting flag if user is entitled to access Edit Defaults and sending that flag as a property to enable/disable edit defaults in UI
				boolean isUserEntitledToEditDefaults = this.expagdao.isUserEntitledToFunction(FUNCTION_CATEGORY_EDIT_DEFAULTS, FUNCTION_DESC_ACTION_TYPE, userId);
				properties.getProperties().add(this.expagTaskHelper.addProperty(BigInteger.ONE, PROPERTY_NAME_ENTITLED_TO_EDIT_DEFAULTS, Boolean.valueOf(isUserEntitledToEditDefaults), PROPERTY_DESC_ENTITLED_TO_EDIT_DEFAULTS));
				
				setTaskAdditionalDetailsFromActiviti(request, process);
				
			} else {
				// Other than conversion requests
				Tasks tasks = getTasks(request);
				process.setTasks(tasks);

				// Activiti Comments Call
				Comments comments = getComments(request);
				process.setComments(comments);
			}

		} catch (Exception e) {
			LOGGER.error("Activiti getProcess() call failed" + e.toString());
			throw new WorkflowException("ACTIVITI Service call failed: " + e.getMessage());
		}
		return process;
	}
	

	private ProcessResponse getActivitiProcess(Request request) {
		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);
		String searchMode=(String) request.getAttribute(SEARCH_MODE);
		String section = (String) request.getAttribute(SECTION);
		
		String convertedEXPAGTask = (String) request.getAttribute(CONVERTED_EXPAG_TASK);
		
		String lockMode="true";
		
		if (searchMode != null && searchMode.equalsIgnoreCase("y")){
			 lockMode = "false";
		}
		
		ProcessResponse processResponse = activitiRepositoryImpl
				.getActivitiProcess(processId, userId, lockMode,section,convertedEXPAGTask);
		return processResponse;
	}
	
	@Override
	public Documents getDocuments(Request request) {
		Documents documents = new Documents();
		String userId = (String) request.getAttribute(USER_ID);
		String taskId = (String) request.getAttribute(PROCESS_ID);
		String convertedExpag = (String) request.getAttribute(CONVERTED_EXPAG_TASK);

		try {
			documents = this.getActivitiDocuments(taskId, userId, convertedExpag);
		} catch (Exception e) {
			LOGGER.error("Activiti getDocuments() call failed" + e.toString());
		}

		return documents;
	}
	
	private Documents getActivitiDocuments(String processId, String userId, String convertedExpag) {
		Documents rsvDocuments = new Documents();
		List<Document> rsvDocumentList = new ArrayList<Document>();

		DocumentsResponse activitiDocumentsResponse = this.activitiRepositoryImpl
				.getActivitiDocuments(processId, userId, convertedExpag);
	    LOGGER.debug("activiti Documents Response -->:" + activitiDocumentsResponse);

		if(activitiDocumentsResponse.getDocs() != null 
				&& activitiDocumentsResponse.getDocs().getDocuments() != null){
			rsvDocumentList = activitiDocumentsResponse.getDocs().getDocuments();
			rsvDocuments.getDocuments().addAll(rsvDocumentList);
		}
		return rsvDocuments;

	}


	/*
	 * @Override public Document getDocument(Request request) {
	 * 
	 * DocumentResponse documentsResponse=null; String userId = (String)
	 * request.getAttribute(USER_ID); String processId = (String)
	 * request.getAttribute(PROCESS_ID); String documentId= (String)
	 * request.getAttribute(DOCUMENT_ID);
	 * 
	 * documentsResponse = activitiRepositoryImpl
	 * .getActivitiDocument(processId, userId,documentId);
	 * 
	 * return documentsResponse.getDocument(); }
	 */

    @Override
	public Comments getComments(Request request) {
		/*
		 * Comments comments = null; CommentsResponse commentsResponse =
		 * getActivitiComments(request); comments =
		 * commentsResponse.getComments(); return comments;
		 */
		Comments rsvComments = new Comments();
		List<Comment> rsvCommentList = new ArrayList<Comment>();

		CommentsResponse commentsResponse = null;
		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);
		String taskId = (String) request.getAttribute(TASK_ID);

		if (taskId != null) {
			commentsResponse = activitiRepositoryImpl.getActivitiTaskComments(
					processId, userId, taskId);
		} else {

			commentsResponse = activitiRepositoryImpl.getActivitiComments(
					processId, userId);
		}
		LOGGER.debug("activiti Comments Response -->:" + commentsResponse);
		
		if(commentsResponse.getComments() != null 
				&& commentsResponse.getComments().getComments() != null){
			rsvCommentList = commentsResponse.getComments().getComments();
			rsvComments.getComments().addAll(rsvCommentList);
		}
		return rsvComments;
	}

	@Override
	public Tasks getTasks(Request request) {
		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);

		Tasks rsvTasks = new Tasks();
		List<Task> rsvTaskList = new ArrayList<Task>();

		ProcessResponse processResponse = activitiRepositoryImpl.getActivitiTasks(
				processId, userId);
		LOGGER.debug("ACTIVITI Tasks Response -->:" + processResponse);
		if(processResponse.getProcess().getTasks() != null 
				&& processResponse.getProcess().getTasks().getTasks() != null){
			rsvTaskList = processResponse.getProcess().getTasks().getTasks();
			rsvTasks.getTasks().addAll(rsvTaskList);
		}
		return rsvTasks;

	}
	
		@Override
	public TaskResponse getTaskById(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);
		String taskId = (String) request.getAttribute(TASK_ID);

		TaskResponse taskByIdResponse = activitiRepositoryImpl
				.getActivitiTaskById(processId, userId, taskId);
		return taskByIdResponse;
	}

	@Override
	public Processes getTasksClaimable(Request request) {
		String userId = (String) request.getAttribute(USER_ID);

		String dept = (String) request.getAttribute(DEPARTMENT);
		String type = (String) request.getAttribute(TYPE);
		String convertedExpagTask = String.valueOf(request.getAttribute(CONVERTED_EXPAG_TASK));

		Processes processes = activitiRepositoryImpl
				.getActivitiTasksClaimable(userId, dept, type, convertedExpagTask);
		return processes;
	}
	
	@Override
	public Process createProcess(Request request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Process updateProcess(Request request) {
		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);

		ProcessRequest processRequest = (ProcessRequest) request.getAttribute(PROCESS_REQUEST);
		String convertedEXPAGTask = (String) request.getAttribute(CONVERTED_EXPAG_TASK);
		
		Process process = new Process();
		if (processRequest.getProcess() != null)
		{
			process = activitiRepositoryImpl.updateActivitiProcess(processRequest, userId, processId, convertedEXPAGTask);
		}

		return process;

	}

	@Override
	public ConfigItems getConfigItems(Request request) {
		String property = (String) request.getAttribute(PROPERTY);
		String userId = (String) request.getAttribute(USER_ID);
		String department = (String) request.getAttribute(DEPT) != null ? (String) request.getAttribute(DEPT) : null;
		String tableHeader = (String) request.getAttribute(TABLE_HEADER);
		ConfigItems configItems = new ConfigItems();
		LOGGER.debug("ActivitiAdapter getConfigItems() userId =" + userId + " Property =" + property + "& department ="
				+ department + " & tableHeader =" + tableHeader);
		if (tableHeader != null && department!=null) {
			configItems = activitiRepositoryImpl.getActivitiSolutionHeaders(department,userId, tableHeader);
		} else {
			configItems = this.activitiRepositoryImpl.getActivitiConfigItems(property, userId, department);
		}
		return configItems;
	}

	@Override
	public Processes doSearch(Request request) {
		Processes searchResults = new Processes();
		String userId = (String) request.getAttribute(USER_ID);
		SearchRequest searchRequest = (SearchRequest) request
				.getAttribute(SEARCH_REQUEST);

		SearchRequest activitiSearchRequest = new SearchRequest();

		// set properties from UW search request to activiti search request
		Properties searchRequestProperties = searchRequest.getProperties();
		Properties activitiProps = null;
		if (searchRequestProperties != null
				&& searchRequestProperties.getProperties() != null
				&& searchRequestProperties.getProperties().size() > 0) {
			activitiProps = new Properties();
			 getActivitiProperties(searchRequest , activitiProps);
		}
		
		if (searchRequest.getTaskId() != null){
			if(activitiProps == null){
				activitiProps = new Properties();
			}
			NameValue orchNameValue = new NameValue();
			orchNameValue.setName(ORCHESTRATION_ID);
			orchNameValue.setValue(searchRequest.getTaskId());
			activitiProps.getProperties().add(orchNameValue);
		}
	
		if( activitiProps != null){
			activitiSearchRequest.setProperties(activitiProps);
		}
		
		populateRootLevelFields(searchRequest, activitiSearchRequest);

		LOGGER.info("ACTIVITI search request -->:" + activitiSearchRequest);

		try {
			SearchResponse searchResponse = activitiRepositoryImpl
					.search(activitiSearchRequest, userId);
			searchResults = searchResponse.getProcesses();
			if (YES.equalsIgnoreCase(filterConvertedExpagTasks)) {
				convertExpAgProcesses(searchResults);
			}
		} catch (Exception e) {
			LOGGER.error("Error while searching in Activiti: "+e.getMessage());
		}
		
		return searchResults;
	}

	private void populateRootLevelFields(SearchRequest searchRequest,
			SearchRequest activitiSearchRequest) {
		if(searchRequest.getFilterType() != null){
			activitiSearchRequest.setFilterType(searchRequest.getFilterType());
			activitiSearchRequest.setStartDate(searchRequest.getStartDate());
			activitiSearchRequest.setEndDate(searchRequest.getEndDate());
		}
		
		if(StringUtils.isNotBlank(searchRequest.getDepartment())){
			activitiSearchRequest.setDepartment(searchRequest.getDepartment());
		}
		
		if(StringUtils.isNotBlank(searchRequest.getAction())){
			activitiSearchRequest.setAction(searchRequest.getAction());
		}
		
		if(StringUtils.isNotBlank(searchRequest.getAssignedTo())){
			activitiSearchRequest.setAssignedTo(searchRequest.getAssignedTo());
		}
		if(StringUtils.isNotBlank(searchRequest.getTaskType())){
			activitiSearchRequest.setTaskType(searchRequest.getTaskType());
		}
		
		if(searchRequest.getTaskStatus() != null && StringUtils.isNotBlank(searchRequest.getTaskStatus().getSts())){
			activitiSearchRequest.setTaskStatus(searchRequest.getTaskStatus());
		}
		
		
	}
	
	private void getActivitiProperties(SearchRequest cmrsv2SearchRequest, Properties activitiProperties) {
		
				for (NameValue nameValue : cmrsv2SearchRequest.getProperties().getProperties()) {
					List<NameValue> childNameValueList = nameValue.getChildrenNameValues();
					for (NameValue childNameValue : childNameValueList) {
						NameValue activitiNameValue = new NameValue();
						activitiNameValue.setName(nameValue.getDesc());
						activitiNameValue.setValue(childNameValue.getValue());
						activitiProperties.getProperties().add(activitiNameValue);
					}
				}
	}

	@Override
	public Metrics getMetrics(Request request) {
		String userId = (String) request.getAttribute(USER_ID);
		String department = (String)request.getAttribute(SOLUTION_NAME);
		
		LOGGER.info("getMetrics call, userId ="+userId+ "  Solution =" +department);
		Metrics metrics = this.activitiRepositoryImpl.getActivitiMetrics(userId,department);
		return metrics;
	}

	@Override
	public Document createDocument(Request request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Documents createDocuments(Request request) {
		Documents documents = null;
		boolean uploadStatus = false;

		String userId = (String) request.getAttribute(USER_ID);
		String taskId = (String) request.getAttribute(PROCESS_ID);
		String caseId = (String) request.getAttribute(CASE_ID);
		String appName = (String) request.getAttribute(APP_NAME);
		String convertedExpag = (String) request.getAttribute(CONVERTED_EXPAG_TASK);
		String nonUWDocument = (String) request.getAttribute(NON_UW_DOCUMENT);

		DocumentsRequest documentsRequest = (DocumentsRequest) request
				.getAttribute(DOCUMENTS_REQUEST);
		// List<DocumentSubmission> documentsList = new
		// ArrayList<DocumentSubmission>();
		if ((documentsRequest != null)
				&& documentsRequest.getDocuments() != null && null == nonUWDocument) {
			
			for (Document cmsDocument : documentsRequest.getDocuments()
					.getDocuments()) {
				uploadStatus = activitiDocumentHelper.createDocumentInActiviti(
						userId, taskId, caseId, cmsDocument, convertedExpag);
			}
			
		}else if(null != nonUWDocument && TRUE.equalsIgnoreCase(nonUWDocument)){
			
			if ((documentsRequest != null)
					&& (documentsRequest.getDocuments() != null)) {
				for (Document cmsDocument : documentsRequest.getDocuments()
						.getDocuments()) {
					uploadStatus = activitiDocumentHelper.createNonUWDocument(userId, taskId, caseId, cmsDocument, convertedExpag);
				}
			}
			
		}
		
		if (uploadStatus) {
			documents = getDocuments(request);
		}
		
		return documents;
	}

	//conversion changes
	@Override
	public Process createRelatedTask(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);
		String caseId = (String) request.getAttribute(CASE_ID);
		ProcessRequest processRequest = (ProcessRequest) request.getAttribute(PROCESS_REQUEST);

		activitiRepositoryImpl.createActivitiRelatedTask(processRequest, userId, processId, caseId);

		Process process = getProcess(request);

		return process;
	}

	@Override
	public Processes createProcesses(Request request) {
		
		String userId = (String) request.getAttribute(USER_ID);
		ProcessesRequest processesRequest = (ProcessesRequest) request.getAttribute(PROCESSES_REQUEST);
		
		String convertedEXPAGTask = (String) request.getAttribute(CONVERTED_EXPAG_TASK);
		
		Process process = processesRequest.getProcesses().getProcesses().get(0);
		Documents docs = process.getDocuments();
		
		// Archive only if Docs exist, otherwise invoke createProcess
		if(docs != null && docs.getDocuments().size() > 0){
			// 1. Archive Documents in found in Request.
			List<Map<String, String>> archivedDocs = federatedDocumentRSService.uploadMultipleDocsToFDRS(docs);
			LOGGER.info("No. of documents archived to mobius - "+archivedDocs.size());
				
			Documents newDocs = new Documents();
			for(Map<String, String> doc : archivedDocs){
				org.tiaa.esb.case_management_rs_v2.type.Document actDoc = activitiDocumentHelper.createActivitiDocument(doc);
				newDocs.getDocuments().add(actDoc);
			}
			
			// 2. Updating the process with new document metadata info which consists of the DRI.
			process.setDocuments(newDocs);
		}

		//3 . Call Activiti for Process Creation.
		
		Processes createActivitiProcesses = activitiRepositoryImpl.createActivitiProcesses(processesRequest, userId, convertedEXPAGTask);
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				LOGGER.info("unable get the process in sleep mode");
			}
		
		
		if(YES.equalsIgnoreCase(convertedEXPAGTask)){
			
			String activitiTaskId = createActivitiProcesses.getProcesses().get(0).getTasks().getTasks().get(0).getID();
			
			request.setAttribute(PROCESS_ID,activitiTaskId);
			
			Process activitiProcess = getProcess(request);
			if(!createActivitiProcesses.getProcesses().isEmpty()){
				createActivitiProcesses.getProcesses().remove(0);
			}
			createActivitiProcesses.getProcesses().add(activitiProcess);

			return createActivitiProcesses;
		}
		else{
			return createActivitiProcesses;
		}
		
	}

	@Override
	public Processes doDatabaseSearch(Request request) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	/*@Override
	public Tasks getIcmTasks(Request request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Comments getIcmComments(Request request) {
		// TODO Auto-generated method stub
		return null;
	}*/

	@Override
	public ConfigItems getIcmConfigItems(Request request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Comments addComment(Request request) {
		
		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);
		
		CommentsRequest commentRequest = (CommentsRequest) request.getAttribute(COMMENT_REQUEST);
		CommentsResponse commentResponse = activitiRepositoryImpl.addActivitiComment(processId, userId, commentRequest);
		
		return commentResponse.getComments();
	}

	@Override
	public Processes updateProcesses(Request request) throws Exception {
		
		String userId = (String) request.getAttribute(USER_ID);
		ProcessesRequest processesReq = (ProcessesRequest) request.getAttribute(PROCESSES_REQUEST);
		String convertedEXPAGTask = (String) request.getAttribute(CONVERTED_EXPAG_TASK);
		return activitiRepositoryImpl.updateActivitiProcesses(userId, processesReq,convertedEXPAGTask);
		
	}
	
	@Override
	public void updateDocument(Request request) {
		String docId = (String) request.getAttribute(DOCUMENT_ID);
		String taskId = (String) request.getAttribute(PROCESS_ID);
		String userId = (String) request.getAttribute(USER_ID);
		String caseId = (String) request.getAttribute(CASE_ID);
		String appName = (String) request.getAttribute(APP_NAME);
		String convertedExpag = (String) request.getAttribute(CONVERTED_EXPAG_TASK);

		DocumentRequest documentRequest = (DocumentRequest) request.getAttribute(DOCUMENT_REQUEST);
		if(documentRequest.getDocument() != null) {
			Document cmsDocument = documentRequest.getDocument();
			if (Routing.NOTE.toString().equalsIgnoreCase(documentRequest.getDocument().getDocDirection())) {
				try{
					this.activitiDocumentHelper.appendNote(taskId, userId, docId, cmsDocument, convertedExpag);		
				}catch(Exception e){
					LOGGER.error("Error in appending Notes in Activiti. " + e.getMessage());
				}
						
			} else { // should be Corro.. we need to revisit this...We need to ask UW to pass corro type in payload
				try {
					this.activitiDocumentHelper.updateDocumentInExpag(docId, cmsDocument);
				} catch (Exception e) {
					LOGGER.error("Error in updating Correspondence. " + e.getMessage());
				}
			}
		}
	}

	@Override
public Document getDocument(Request request) throws JAXBException {
		Document document = new Document();

		String userId = (String) request.getAttribute(USER_ID);
		String docId = (String) request.getAttribute(DOCUMENT_ID);
		String extDocKey = (String) request.getAttribute(EXT_DOC_KEY);
		String appName = (String) request.getAttribute(APP_NAME);
		document = this.activitiDocumentHelper.getDocument(request);
		return document;
	}

	/*
	 * @Autowired private BprsService bprsService;
	 * 
	 * private Process getBprsProcess(Request request) {
	 * 
	 * String userId = (String) request.getAttribute(USER_ID); String processId
	 * = (String) request.getAttribute(PROCESS_ID);
	 * 
	 * Process processResponse = this.bprsService.getBprsProcess(processId,
	 * userId); return processResponse; }
	 */
	 @Override
	public String toString(){
		return "ACTIVITI";
	}

	@Override
	public Process getRelatedProcesses(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);
		String convertedEXPAGTask = (String) request.getAttribute(CONVERTED_EXPAG_TASK);

		RelatedTasks relatedTasks = new RelatedTasks();
		Process process = new Process();
		Processes activitiProcesses = null;

		try {
			activitiProcesses = activitiRepositoryImpl.getActivitiRelatedProcesses(userId, processId);
			if (activitiProcesses.getProcesses() != null) {

				if (!convertedEXPAGTask.equalsIgnoreCase(YES)) {
					for (Process activitiProcess : activitiProcesses.getProcesses()) {
						List<NameValue> processProperties = activitiProcess.getProcessProperties().getProperties();
						Task task = new Task();
						for (NameValue nameValue : processProperties) {
							try {
								switch (nameValue.getName().toLowerCase()) {
									case "requestid" :
										Properties taskProperties = new Properties();
										NameValue nameValueRequestId = new NameValue();
										nameValueRequestId.setDesc("confirmation");
										nameValueRequestId.setValue(nameValue.getValue());
										taskProperties.getProperties().add(nameValueRequestId);
										task.setTaskProperties(taskProperties);
										break;
									case "requesttype" :
										task.setType(nameValue.getValue());
										break;
									case "datecreated" :
										if (nameValue.getValue() != null) {
											task.setCreateDate(DateUtil.toXMLGregorianCalendarDateOnly(DateUtil.parseDateTimeWithMilliseconds(nameValue.getValue())));

											task.setCreateTime(DateUtil.toXMLGregorianCalendarTimeOnly(DateUtil.parseDateTimeWithMilliseconds(nameValue.getValue())));
										}
										break;
									case "completeddate" :
										if (nameValue.getValue() != null) {
											task.setCompleteDate(DateUtil.toXMLGregorianCalendarDateOnly(DateUtil.parseDateTimeWithMilliseconds(nameValue.getValue())));

											task.setCompleteTime(DateUtil.toXMLGregorianCalendarTimeOnly(DateUtil.parseDateTimeWithMilliseconds(nameValue.getValue())));
										}
										break;
									case "status" :
										Status status = new Status();
										status.setSts(nameValue.getValue());
										Statuses statuses = new Statuses();
										statuses.getSts().add(status);
										task.setStatusHistory(statuses);
										break;
								}
							} catch (Exception e) {
								LOGGER.error("Exception while converting :" + nameValue.getName() + ", exception is:" + e.getMessage());
							}

						}
						task.setID(process.getProcessId());
						relatedTasks.getRelatedTasks().add(task);

					}
					process.setRelatedTasks(relatedTasks);
				} else {
					// For conversion realted requests
					process.setRelatedTasks(activitiProcesses.getProcesses().get(0).getRelatedTasks());
				}
			}

		} catch (Exception e) {
			LOGGER.error("Activiti getRelatedProcesses() call failed" + e.toString());
		}
		return process;
	}

	@Override
	public Process getHistory(Request request) {
		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);
		String type = (String) request.getAttribute(TYPE);
		String start = (String) request.getAttribute(START);
		
		Process process = activitiRepositoryImpl
				.getTimeline(processId, userId, start, type);
		return process;
	}

	@Override
	public Task updateTask(Request request) {
		
		String userId = (String) request.getAttribute(USER_ID);
		String taskId = (String) request.getAttribute(WOB_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);

		TaskRequest taskRequest = (TaskRequest) request.getAttribute(TASK_REQUEST);
		
		Task task = new Task();
		if (taskRequest.getTask() != null)
		{
			task = activitiRepositoryImpl.updateActivitiTask(taskRequest, userId, processId, taskId);
		}
		return task;

	}

	@Override
	public Task createTask(Request request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ConfigItems searchConfigItems(Request request) {
		
		String userId =	(String) request.getAttribute(USER_ID);
		String property = (String) request.getAttribute(PROPERTY);
		SearchRequest searchRequest = (SearchRequest) request.getAttribute(SEARCH_REQUEST);

		LOGGER.info("ActivitiAdapter getConfigItems() userId ="+userId+" Property =" +property );
		ConfigItems configItems = this.activitiRepositoryImpl.getActivitiCaseWorkers(property, userId,searchRequest);
		
		return configItems;
	}

	@Override
	public void deleteDocument(Request request) {
		
		String processId = (String) request.getAttribute(PROCESS_ID);
		String documentId = (String) request.getAttribute(DOCUMENT_ID);
		String userId = (String) request.getAttribute(USER_ID);
		
		this.activitiRepositoryImpl.deleteActivitiDocument(processId, documentId, userId);
	}
	
	@Override
	public History getTaskHistory(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);
		History history = new History();
		try {
			ProcessResponse processResponse = activitiRepositoryImpl.getActivitiTasks(processId, userId);
			LOGGER.debug("ACTIVITI TaskHistory Response -->:" + processResponse);
			if (processResponse.getProcess() != null && processResponse.getProcess().getHistory() != null) {
				history = processResponse.getProcess().getHistory();

			}
		} catch (Exception e) {
			LOGGER.error("Activiti-getActivitiTasks() call failed" + e.toString());
		}
		return history;
	}
	
	public  ProcessResponse getActivitiTaskAdditionalDetails(Request request) {
		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);

		ProcessResponse processResponse = activitiRepositoryImpl.getActivitiTaskAdditionalDetails(processId, userId);
		return processResponse;
	}
	
	private void setTaskAdditionalDetailsFromActiviti(Request request, Process process) {

		try {
			// Code for SLA Detail,Routing rules & Reasons
			Task task = process.getTasks().getTasks().get(0);
			List<NameValue> properties = task.getTaskProperties().getProperties();

			ProcessResponse processResponse = getActivitiTaskAdditionalDetails(request);

			properties.addAll(processResponse.getProcess().getTasks().getTasks().get(0).getTaskProperties().getProperties());
			process.setSLADetail(processResponse.getProcess().getSLADetail());
			task.setReasons(processResponse.getProcess().getTasks().getTasks().get(0).getReasons());

		} catch (Exception e) {
			LOGGER.error("Activiti getActivitiTaskAdditionalDetails() call failed" + e.toString());
		}

	}
	

}
