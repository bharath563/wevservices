package org.tiaa.case_management_rs.utils;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageInputStream;
import javax.imageio.stream.ImageOutputStream;
import javax.media.jai.NullOpImage;
import javax.media.jai.OpImage;
import javax.media.jai.PlanarImage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.codec.binary.Base64;

import com.sun.media.jai.codec.FileSeekableStream;
import com.sun.media.jai.codec.ImageCodec;
import com.sun.media.jai.codec.ImageDecoder;
import com.sun.media.jai.codec.ImageEncoder;
import com.sun.media.jai.codec.SeekableStream;
import com.sun.media.jai.codec.TIFFEncodeParam;

public class TiffUtils {

	private static final String TIFF = "tiff";
	private static final Logger LOGGER = LoggerFactory.getLogger(TiffUtils.class);

	public static byte[] getCombinedTiffFile(final List<String> tifs, final String filename) throws IOException {

		OutputStream out = null;
		File pdffile = new File(filename);

		try {

			int numOfTifFiles = tifs.size();

			BufferedImage image[] = new BufferedImage[numOfTifFiles];

			for (int i = 0; i < numOfTifFiles; i++) {
				SeekableStream seekableStream = new FileSeekableStream(tifs.get(i));
				ImageDecoder decoder = ImageCodec.createImageDecoder(TIFF, seekableStream, null);
				PlanarImage pi = new NullOpImage(decoder.decodeAsRenderedImage(0), null, null, OpImage.OP_IO_BOUND);
				image[i] = pi.getAsBufferedImage();
				seekableStream.close();
			}

			TIFFEncodeParam params = new TIFFEncodeParam();
			params.setCompression(TIFFEncodeParam.COMPRESSION_DEFLATE);

			out = new FileOutputStream(filename);

			ImageEncoder encoder = ImageCodec.createImageEncoder(TIFF, out, params);
			List<BufferedImage> list = new ArrayList<BufferedImage>(image.length);
			for (int i = 1; i < image.length; i++) {
				list.add(image[i]);
			}
			params.setExtraImages(list.iterator());
			encoder.encode(image[0]);

			out.flush();
		} finally {
			if (out != null) {
				out.close();
			}
		}

		return readFileContents(pdffile);

	}

	@SuppressWarnings("cast")
	public static void changeTiffToOutStream(final InputStream is, final OutputStream tiffOutStream) throws IOException {
		final Iterator<ImageReader> readers = ImageIO.getImageReadersByFormatName(TIFF);
		final ImageReader imgReader = readers.next();
		final ImageInputStream iis = ImageIO.createImageInputStream(is);
		imgReader.setInput(iis, false);
		final ImageWriter imgWriter = ImageIO.getImageWritersByFormatName(TIFF).next();

		final ImageOutputStream ios = ImageIO.createImageOutputStream(tiffOutStream);
		imgWriter.setOutput(ios);
		int imageIndex = 0;
		IndexOutOfBoundsException iobe = null;
		for (imageIndex = 0; iobe == null; imageIndex++) {
			try {
				final BufferedImage bufferedImg = imgReader.read(imageIndex);
				final ImageWriteParam writeParam = imgWriter.getDefaultWriteParam();
				final IIOImage outImage = new IIOImage(bufferedImg, null, null);

				if (imageIndex == 0) {
					imgWriter.write(null, outImage, writeParam);
				} else if (imageIndex > 0) {
					imgWriter.writeInsert(imageIndex, outImage, writeParam);
				} else {
					throw new RuntimeException("Invalid Image index " + imageIndex);
				}
			} catch (final IndexOutOfBoundsException ex) {
				iobe = ex;
			}
		}

		is.close();
		ios.close();
	}

	private static byte[] readFileContents(File file) {
		RandomAccessFile f;
		byte[] bytes = null;

		try {
			f = new RandomAccessFile(file, "r");
			bytes = new byte[(int) f.length()];
			f.read(bytes);
			f.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		LOGGER.debug("Successfully read the byte contentes for the file " + file.getName());
		LOGGER.debug("Bytes : " + Base64.encodeBase64(bytes));

		return bytes;
	}
}
