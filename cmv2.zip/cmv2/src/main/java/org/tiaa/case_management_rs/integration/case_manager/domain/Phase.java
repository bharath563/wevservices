package org.tiaa.case_management_rs.integration.case_manager.domain;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.case_management_rs.utils.DateUtil;

public class Phase implements Serializable {
	public static final Logger LOG = LoggerFactory.getLogger(Phase.class);
	private static final long serialVersionUID = -6515718649483935112L;
	private String name;
	private String description;
	private Date startedTS;
	private Date completedTS;
	private String targetCompletionTS;

	public XMLGregorianCalendar getCompletedDateTime() {
		return DateUtil.toXMLGregorianCalendar(getCompletedTS());
	}

	public Date getCompletedTS() {
		return completedTS;
	}

	public String getDescription() {
		return description;
	}

	public String getName() {
		return name;
	}

	public String getPhaseNameAndDescription() {
		return getName() + " - " + getDescription();
	}

	public XMLGregorianCalendar getStartDateTime() {
		return DateUtil.toXMLGregorianCalendar(getStartedTS());
	}

	public Date getStartedTS() {
		return startedTS;
	}

	public Date getTargetCompletionDateTime() {
		if (targetCompletionTS == null) {
			return null;
		}
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
			return simpleDateFormat.parse(targetCompletionTS);
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
		}
		return null;
	}

	public String getTargetCompletionTS() {
		return targetCompletionTS;
	}

	public void setCompletedTS(Date completedTS) {
		this.completedTS = completedTS;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setStartedTS(Date startedTS) {
		this.startedTS = startedTS;
	}

	public void setTargetCompletionTS(String targetCompletionTS) {
		this.targetCompletionTS = targetCompletionTS;
	}

	@Override
	public String toString() {
		return "Phase [phase=" + name + ", description=" + description + ", startedTS=" + startedTS + ", completedTS=" + completedTS + ", targetCompletionTS="
				+ targetCompletionTS + "]";
	}
}
