package org.tiaa.case_management_rs.dao;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import org.tiaa.case_management_rs.model.NextGenProcessSource;

@Repository
public class NEXTGENDAO {

	private static final Logger LOGGER = LoggerFactory.getLogger(NEXTGENDAO.class);

	@Autowired
	private JdbcTemplate nextGenJdbcTemplate;

	@Value("${SourceSystemNameByTaskType}")
	private String sourceSystemNameByTaskTypeSql;
	
	@Value("${NxtGenDelegateProcessSourceSystem}")
	private String processSourceSystemNameByTaskTypeSql;

	public String getSourceSystemNameByTaskType(String taskType) {

		Object[] args = new Object[]{taskType, taskType};
		String sourceSystem = null;
		try {
			sourceSystem = this.nextGenJdbcTemplate.queryForObject(this.sourceSystemNameByTaskTypeSql, args, String.class);
		} catch (DataAccessException exception) {
			LOGGER.error("Exception while getiing source name" + exception.getMessage());

		}

		return sourceSystem;
	}
	
	@Cacheable(value="nxtGenDelegator", cacheManager="cmrsCacheManager")
	public List<NextGenProcessSource> getNextGenProcessDelegator() {
		
		List<NextGenProcessSource> rows = new ArrayList<NextGenProcessSource>();
		try {
			rows = this.nextGenJdbcTemplate.query(processSourceSystemNameByTaskTypeSql, new NextGenDelegatorProcessSourceMapper());
		} catch (DataAccessException ex) {
			LOGGER.error("Exception while fetching delegator results", ex);
		}
		return rows;
	}

}
