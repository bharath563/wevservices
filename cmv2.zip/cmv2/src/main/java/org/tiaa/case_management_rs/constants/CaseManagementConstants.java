package org.tiaa.case_management_rs.constants;

public interface CaseManagementConstants {

	/* Response text value constants */
	public static final String SUCCESS = "SUCCESS";
	public static final String SUCCESS_TEXT = "SUCCESS";
	public static final String FAILURE = "FAILURE";
	public static final String ERROR = "Error";
	public static final String FAILURE_TEXT = "Service Call Failed";
	public static final String MSG_TYPE_INFO = "INFO";
	public static final String ESB_MSGS = "ESBMessages";

	/* Request parameter values */
	public static final String USER_ID = "userid";
	public static final String TIAA_CONSUMER = "tiaa-consumer";
	public static final String TIAA_USER_REF = "tiaa-user-ref";
	public static final String CASEMANAGEMENTUD = "CaseManagementUD";
	public static final String DEPARTMENT = "department";
	public static final String SOLUTION = "solution";
	public static final String TYPE = "type";
	public static final String TASKID = "workitemid";
	public static final String TASK_ID = "taskid";
	public static final String CASE_ID = "caseid";
	public static final String DOCUMENT_ID = "docid";
	//public static final String TASK_XML = "taskXML";
	public static final String EXT_DOC_KEY = "extdockey";
	public static final String WORKITEM_REQUEST = "workitemrequest";
	public static final String PROCESS_REQUEST = "processrequest";
	public static final String WORKITEMS_REQUEST = "workitemsrequest";
	public static final String PROCESSES_REQUEST = "processesrequest";
	public static final String DOCUMENT_REQUEST = "documentrequest";
	public static final String COMMENT_REQUEST = "commentrequest";
	public static final String DOCUMENTS_REQUEST = "documentsrequest";
	public static final String SEARCH_REQUEST = "searchrequest";
	public static final String METRICS_REQUEST = "metricsrequest";
	public static final String TASK_REQUEST = "taskrequest";
	public static final String PROPERTY = "property";
	public static final String PARAMETER = "parameter";
	public static final String PARAMETER1 = "parameter1";
	public static final String DEPT = "dept";
	public static final String REQUESTTYPE = "requesttype";
	public static final String ACTIONSTEP = "actionstep";
	public static final String FIELDNUMBER = "fieldnumber";
	public static final String IDCODE = "idcode";
	public static final String DAYS = "days";
	public static final String SSN = "ssn";
	public static final String PIN = "pin";
	public static final String IS_NEW_TASK = "isnewtask";
	public static final String TRUE = "true";
	public static final String FALSE = "false";
	public static final String LOCK_ONLY = "lockonly";
	public static final String PROCESS_ID = "processid";
	public static final String ACTION = "action";
	public static final String USER_REF = "tiaa-user-ref";
	public static final String ORCHESTRATION_ID = "orchestrationId";
	public static final String QUEUE_NAME = "queueName";
	public static final String WOB_ID = "wobid";
	public static final String START_OMNI_TASKS = "startOmniTasks";

	/* search request values */
	public static final String BEGINDATE = "begindate";
	public static final String ENDDATE = "enddate";
	public static final String TASKSTATUS = "taskstatus";
	public static final String DEPTDESC = "deptdesc";
	public static final String TASKTYPE = "tasktype";
	public static final String ACTDESC = "actddesc";
	public static final String WORKBASKET = "workbasket";
	public static final String ROWCOUNT = "rowcount";
	public static final String USECREATEDATE = "usecreatedate";
	public static final String EMPTYWORKBASKET = "emptyworkbasket";
	public static final String IDDESC1 = "iddesc1";
	public static final String FIELD11 = "field11";
	public static final String FIELD12 = "field12";
	public static final String FIELD13 = "field13";
	public static final String FIELD14 = "field14";
	public static final String IDDESC2 = "iddesc2";
	public static final String FIELD21 = "field21";
	public static final String FIELD22 = "field22";
	public static final String FIELD23 = "field23";
	public static final String FIELD24 = "field24";
	public static final String IDDESC3 = "iddesc3";
	public static final String FIELD31 = "field31";
	public static final String FIELD32 = "field32";
	public static final String FIELD33 = "field33";
	public static final String FIELD34 = "field34";

	/* Special Character constants */
	public static final String COMMA = ",";
	public static final String UNDERSCORE = "_";
	public static final String BACKWARD_SLASH = "/";
	public static final String FORWARD_SLASH = "\\";
	public static final String COLON = ":";
	public static final String SPACE_COMMA_SAPCE = " , ";
	public static final String SPACE_COLON_SAPCE = " : ";
	public static final String SPACE_HYPEN_SAPCE = " - ";

	/* EXP-AG Constants */
	public static final int WORKITEM_DEFAULT_COUNT = 0;
	public static final String WORKITEM_DEFAULT_LOCK_INDICATOR = "N";
	public static final int EXPAG_DEFAULT_PRIORITY = 900;

	/* Validation Error configurtaions */
	public static final String GENERAL_ERROR_CODE = "CMS10000";
	public static final String ERROR_GENERAL_EXCEPTION = "ERROR.GENERAL.EXCEPTION";
	public static final String VALIDATION_USERID_IS_EMPTY = "USER.ID.EMPTY";
	public static final String VALIDATION_DOC_CONTENT_IS_NULL = "DOC.CONTENT.NULL";
	public static final String VALIDATION_TASKID_IS_EMPTY = "TASK.ID.EMPTY";
	public static final String VALIDATION_ACTION_IS_EMPTY = "ACTION.ID.EMPTY";
	public static final String VALIDATION_CASEID_IS_EMPTY = "CASE.ID.EMPTY";
	public static final String VALIDATION_CASE_ID_INVALID = "CASE.ID.INVALID";
	public static final String VALIDATION_TASKSTATUS_IS_EMPTY = "TASK.STATUS.EMPTY";
	public static final String VALIDATION_DEPTDESC_IS_EMPTY = "TASK.DEPTDESC.EMPTY";
	public static final String VALIDATION_WORKITEM_REQUEST_IS_NULL = "WORKITEM.REQUEST.NULL";
	public static final String VALIDATION_BOTH_TASKID_CASID_IS_EMPTY = "TASKID.CASID.EMPTY";
	public static final String VALIDATION_BOTH_DOCID_EXTDOCKEY_IS_EMPTY = "DOCID.EXTDOCKEY.EMPTY";
	public static final String VALIDATION_PROCESSID_IS_EMPTY = "PROCESS.ID.EMPTY";
	public static final String VALIDATION_APPNAME_IS_EMPTY = "APPNAME.ID.EMPTY";
	public static final String VALIDATION_COMMENT_IS_EMPTY = "COMMENT.EMPTY";
	public static final String VALIDATION_COMMENTSLIST_IS_EMPTY = "COMMENTSLIST.EMPTY";
	public static final String VALIDATION_BUSINESS_UNIT_CODE_IS_EMPTY = "BUSINESSUNITCODE.ID.EMPTY";
	public static final String VALIDATION_DOC_CODE_IS_EMPTY = "DOCCODE.ID.EMPTY";
	public static final String VALIDATION_VERSION_VALUE_IS_EMPTY = "VERSION.ID.EMPTY";
	public static final String VALIDATION_ID_TYPE_IS_EMPTY = "IDTYPE.ID.EMPTY";
	public static final String VALIDATION_DOC_CREATED_DATE_IS_NULL = "DOC.CONTENT.CREATEDDATE.EMPTY";
	public static final String VALIDATION_DOC_ID_IS_NULL = "DOC.ID.EMPTY";
	public static final String VALIDATION_SOLUTION_NAME_IS_NULL = "SOLUTION.NAME.EMPTY";
	public static final String VALIDATION_ICM_CASEID_INCORRECT_FORMAT = "ICM.CASEID.INCORRECT.FORMAT";
	public static final String VALIDATION_ICM_WOBID_ISEMPTY = "WOB.ID.EMPTY";
	public static final String VALIDATION_ICM_QUEUENAME_IS_EMPTY = "QUEUE.NAME.EMPTY";
	public static final String VALIDATION_ICM_ACTION_IS_EMPTY = "ACTION.EMPTY";
	public static final String VALIDATION_TASKSEARCH_TYPE_VALUE_IS_MISSING_OR_WRONG = "TASKSEARCH.SEARCHTYPE.PROPERTY.EMPTY.INVALID";
	public static final String VALIDATION_ICM_TASKTYPE_IS_EMPTY="TASKTYPE.EMPTY";

	/* Error message configuration constants */
	public static final String MSG_CODE_SUFFIX = ".CODE";
	public static final String MSG_TYPE_SUFFIX = ".TYPE";
	public static final String MSG_TEXT_SUFFIX = ".TEXT";

	/* General warning information configuration */
	public static final String GENERAL_WARNING_CODE = "CMS20000";
	public static final String WARNING = "WARNING";

	/* List of supported applications */
	public static final String APP_CONVERTED_EXPAG = "CONVERTED-EXPAG";
	public static final String APP_EXPAG = "EXPAG";
	public static final String APP_ACTIVITI = "ACTIVITI";
	public static final String EXP_AG_INDEX = "ExpAg Index";
	public static final String TEXT_PDF = "text/pdf";
	public static final String BASE64BINARY = "BASE64BINARY";

	public static final String ACTIONDESC_PROCESS = "Process";
	public static final String SCAN_MODE_R = "R";
	public static final String DEFAULT_VIP_INDICATOR = "N";
	public static final String EXPAG_ADD_DOCUMENT_TASK = "Y";
	public static final String EXPAG_ADD_DOCUMENT_CASE = "N";
	public static final String EXPAG_MAIL_ID_CMSUD = "CMSUD";
	public static final String EXPAG_MAIL_ID_WEB = "WEB";
	public static final String EXPAG_MAIL_DESC_WEB = "WEB";
	public static final String EXPAG_MAIL_ID_REGULAR = "REGULAR";
	public static final String EXPAG_MAIL_DESC_REGULAR = "REGULAR";
	public static final String EXPAG_WORKSTATION_TIAAPI = "TIAAPI";
	public static final String SCANFIX_MODE_S = "S";
	public static final String EXPAG_STORAGE_INTERNAL = "INTERNAL";

	public static final String FLAG_N = "N";
	public static final String FLAG_Y = "Y";

	// Expag file types
	public static final String EXPAG_PIDOCTYPE_ATTACHMENT = "A";
	public static final String EXPAG_PIDOCTYPE_BITMAP = "B";
	public static final String EXPAG_PIDOCTYPE_CORRESPONDENCE = "C";
	public static final String EXPAG_PIDOCTYPE_DATA_FILE = "D";
	public static final String EXPAG_PIDOCTYPE_IMAGE = "I";
	public static final String EXPAG_PIDOCTYPE_NOTE = "N";
	public static final String EXPAG_PIDOCTYPE_TEXT = "T";
	public static final String EXPAG_PIDOCTYPE_EXTERNAL = "X";
	public static final String EXPAG_PIDOCTYPE_COMPRESSED_TEXT = "Z";
	public static final String EXPAG_PIDOCTYPE_REPORT = "R";
	public static final String EXPAG_PIDOCTYPE_SIGN = "S";
	public static final String EXPAG_PIDOCTYPE_NOTICE = "E";
	public static final String EXPAG_PIDOCTYPE_CONFIRM = "F";
	public static final String EXPAG_PIDOCTYPE_USEREXTERN = "U";
	public static final String EXPAG_CONT_TYPE_CORRESPONDENCE = "CORRESPONDENCE - OUTBOUND";

	// Expag filetypes
	// Text-based files such as reports, eforms.
	public static final String EXPAG_FILETYPE_ACSII = "A";
	// Images
	public static final String EXPAG_FILETYPE_TIFF = "T";
	// Unknown
	public static final String EXPAG_FILETYPE_UNKNOWN = "U";

	// Expag document content types
	public static final String EXPAG_WEB_REQUEST = "WEB REQUEST";
	public static final String EXPAG_REGULAR = "REGULAR";

	public static final String READ_WRITE_MODE = "rw";
	public static final String READ_MODE = "r";

	public static final String DOC_CONTENT_TYPE_POST = "POST";
	public static final String DOC_CONTENT_TYPE_CALCULATION = "CALCULATION";
	public static final String DOC_CONTENT_TYPE_DCS = "DCS";
	public static final String DOC_CONTENT_TYPE_OUTBOUND = "OUTBOUND";
	public static final String NOTE = "NOTE";
	public static final String NONE = "NONE";

	// Expag dropdown list
	public static final String EXPAG_DEPARTMENTS = "ExpagDepartments";
	public static final String EXPAG_ALL_DEPARTMENTS = "ExpagAllDepartments";
	public static final String EXPAG_INACTIVE_DEPARTMENTS = "ExpagInactiveDepartments";
	public static final String EXPAG_CASE_WORKER_FOR_DEPARTMENT = "EXPAGCaseWorkerForDepartment";
	public static final String EXPAG_DEPARTMENTS_FOR_TASK_TYPE = "EXPAGDepartmentsForTaskType";
	public static final String EXPAG_DEPARTMENTS_FOR_CASEWORKER = "EXPAGDepartmentsForCaseworker";
	public static final String EXPAG_TASK_TYPES_FOR_DEPARTMENT = "ExpagTaskTypesForDepartment";
	public static final String EXPAG_ALL_TASK_TYPES = "ExpagAllTaskTypes";
	public static final String EXPAG_INACTIVE_TASK_TYPES = "ExpagInactiveTaskTypes";
	public static final String EXPAG_NOTE_TYPES = "ExpagNoteTypes";
	public static final String EXPAG_DOC_CONTENT_TYPES = "ExpagDocContentTypes";
	public static final String EXPAG_CASE_WORKERS = "ExpagCaseWorkers";
	public static final String EXPAG_TASK_TYPES = "ExpagTaskTypes";
	public static final String EXPAG_IDENTIFIERS = "ExpagIdentifiers";
	public static final String IDENTIFIERS = "identifiers";
	public static final String EXPAG_NOTE_TEMPLATES = "ExpagNoteTemplates";
	public static final String EXPAG_ENTITLED_CASE_WORKERS = "ExpagEntitledCaseWorkers";
	public static final String EXPAG_ACTIONSTEPS_FOR_TASK_TYPE = "ExpagActionStepsForTaskType";
	public static final String EXPAG_USER_ENTITLED_TO_FUNCTION = "ExpagUserEntitledToFunction";
	public static final String EXPAG_REQUIRED_IDENTIFIERS = "ExpagRequiredIdentifiers";
	public static final String EXPAG_FIRSTACTIONSTEP_FOR_TASK_TYPE = "ExpagFirstActionStepForTaskType";
	public static final String EXPAG_FIRSTACTIONSTEP_INTEGRATION_FOR_TASK_TYPE = "ExpagFirstActionStepWithIntegrationForTaskType";
	public static final String EXPAG_HELP_VARIABLES = "EXPAGHelpVariables";
	public static final String EXPAG_HELP_MESSAGES = "EXPAGHelpMessages";
	public static final String EXPAG_HELP_MESSAGES_CODES = "EXPAGHelpMessageCodes";

	public static final String EXPAG_INSTITUTION_NAMES = "ExpagGetInstitutionNames";
	public static final String EXPAG_PLAN_INFO_INSTITUTION_NAME = "ExpagGetPlanInfoForInstitutionName";
	public static final String EXPAG_ENTITLED_TASK_TYPES = "ExpagEntitledTaskTypes";
	public static final String EXPAG_CORRESPONDENCE_TEMPLATES = "ExpagCorresTemplates";
	public static final String EXPAG_CORRESPONDENCE_PARAGRAPHS_FOR_TEMPLATE = "ExpagCorresParagraphsForTemplate";
	public static final String EXPAG_CORRESPONDENCE_TEMPLATE_PARAGRAPHS_CONTENT = "ExpagCorresContent";
	public static final String EXPAG_CORR_SAVED_INFO = "ExpagCorrSavedInfo";
	public static final String EXPAG_MOC = "MOC";
	public static final String EXPAG_LOCATION_AND_MAIL_DROP_TIMES = "ExpagLocationAndMailDropTimes";
	/* new code */
	public static final String EXPAG_LOCATION_CODE = "LocationCode";

	// new config call for Entitled Departments
	public static final String ENTITLED_DEPARTMENTS = "EntitledDepartments";

	// ICM constants for ICM config call
	public static final String ICM_SOLUTION = "solution";
	public static final String ICM_CASE_TYPE = "casetype";
	public static final String ICM_CHANNEL = "channel";
	public static final String ICM_CASE_STATUS = "casestatus";
	public static final String ICM_ALL_CONFIGS = "ICMConfigItems";
	public static final String ICM_CE_DROPDOWN = "cedropdown";

	public static final String ICM_PENDED = "Pended";
	public static final String ICM_SUSPENDED = "Suspended";
	public static final String ICM_ASSIGNED = "Assigned";
	public static final String ICM_ALLASSIGNED = "AllAssigned";
	
	public static final String PLATFORM = "platform";
	public static final String MOC = "moc";
	public static final String REPAYMENT_MODE = "repaymentmode";

	public static final String ICM_CASE_READ_MODE = "Read";
	public static final String ICM_CASE_WRITE_MODE = "Write";
	public static final String ICM_CASE_READ_WRITE_MODE = "Read/Write";
	public static final String EXPAG_ACTION_DESC_PROCESS = "Process";

	public static final String EXPAG_STATUS_DESC_PROCESS = "Process";
	public static final String EXPAG_STATUS_DESC_NONE = "None";
	public static final String EXPAG_STATUS_DESC_FAIL = "Fail";
	public static final String EXPAG_STATUS_DESC_REVIEW = "Review";
	public static final String EXPAG_STATUS_DESC_REJECT = "Reject";
	public static final String EXPAG_STATUS_DESC_SUSPEND = "Suspend";
	public static final String EXPAG_STATUS_DESC_UNSUSPEND = "Unsuspend";
	public static final String EXPAG_STATUS_DESC_OPEN = "Open";

	public static final String LOCK_INDICATOR_YES = "Y";
	public static final String LOCK_INDICATOR_NO = "N";
	public static final String LOCK_INDICATOR_UNLOCK = "U";

	public static final String EXPAG_SUPER_USER_ISVOPER = "isvoper";

	public static final String IDENTIFIER_DEL = "DEL";
	public static final String IDENTIFIER_ADD = "ADD";

	// task status

	public static final String TASK_STATUS_OPEN = "Open";
	public static final String TASK_STATUS_OUTSTANDING = "Outstanding";
	public static final String TASK_STATUS_ACTIVE = "Active";
	public static final String TASK_STATUS_SUSPENDED = "Suspended";
	public static final String TASK_STATUS_REJECTED = "Rejected";
	public static final String TASK_STATUS_CANCELLED = "Cancelled";
	public static final String TASK_STATUS_COMPLETED = "Completed";
	public static final String TASK_STATUS_CLOSED = "Closed";
	public static final String EXPAG_STATUS_DESC_MODIFIED = "Modified";
	public static final String EXPAG_STATUS_DESC_AUTHORIZE = "Authorize";
	public static final String EXPAG_STATUS_DESC_REINDEX = "Reindex";
	public static final String EXPAG_STATUS_DESC_REVIEW2 = "Review2";
	public static final String EXPAG_TASK_STATUS_EVAL_QUEUE = "Eval Queue";
	public static final String EXPAG_TASK_STATUS_AWAIT_EVAL = "Await Eval";

	public static final String APP_NAME = "appname";
	public static final String SEARCH_MODE = "searchmode";
	public static final String APP_ICM = "ICM";

	public static final String ISOSESSION_COOKIE = "ISOSESSION";
	public static final String SOLUTION_NAME = "solutionName";
	public static final String SECTION = "section";
	public static final String GROUP_ID = "groupId";
	public static final String TABLE_NAME = "tableName";
	public static final String SORT_ORDER = "sortOrder";
	public static final String SORT_BY = "sortBy";

	public static final String BUSINESS_UNIT_CODE = "bizunit";
	public static final String DOC_CODE = "doccode";
	public static final String VERSION = "version";
	public static final String ID_TYPE = "idtype";
	public static final String MIME_TYPE = "mimetype";
	public static final String ACCEPT = "Accept";

	public static final String FAIL_TASK_CODES = "failtaskcodes";
	public static final String OMNI_TRANS_TYPE = "OMNITRANSTYPE";

	public static final String EXPAG_TASK_READ_MODE = "Read";
	public static final String EXPAG_TASK_WRITE_MODE = "Write";
	public static final String NEW_RELATED_TASK_ID = "NEWRELATEDTASKID";

	public static final String PLAN = "PLAN";
	public static final String CLIENT_ID = "client id";
	public static final String SOURCE_FILE_NAME = "SOURCE FILE NAME";
	public static final String RELATED_ORDER = "RELATED ORDER";
	public static final String LOAN_ID = "LOAN ID";
	public static final String CASE_NUMBER = "CASE NUMBER";
	public static final String ACCOUNT_NUMBER = "ACCOUNT NUMBER";
	public static final String BATCH_ID = "BATCH ID";
	public static final String CASE_TYPE = "CASE TYPE";
	public static final String CASE_STATUS = "CASE STATUS";
	public static final String CONFIRMATION = "CONFIRMATION";

	public static final String PROPERTY_NAME_PRIORITY = "PRIORITY";
	public static final String PROPERTY_DESC_PRIORITY = "PRIORITY";
	public static final String PROPERTY_NAME_ENTITLED_TO_EDIT_DEFAULTS = "ENTITLEDTOEDITDEFAULTS";
	public static final String PROPERTY_DESC_ENTITLED_TO_EDIT_DEFAULTS = "ENTITLED TO EDIT DEFAULTS";
	public static final String FUNCTION_CATEGORY_EDIT_DEFAULTS = "Edit Defaults";
	public static final String FUNCTION_DESC_ACTION_TYPE = "Action Type";
	public static final String CONFIG_ITEM_ENTITLEMENT = "ENTITLEMENT";
	public static final String PROPERTY_NAME_ROUTING_RULES = "ROUTINGRULES";
	public static final String PROPERTY_DESC_ROUTING_RULES = "Routing Rules";
	public static final String CHILD_PROPERTY_NAME_STATUS = "STATUS";
	public static final String CHILD_PROPERTY_NAME_START_TIME = "STARTTIME";
	public static final String CHILD_PROPERTY_NAME_END_TIME = "ENDTIME";
	public static final String CHILD_PROPERTY_NAME_START_DATE = "STARTDATE";
	public static final int ACCESS_FLAG_AVAILABLE = 2;

	public static final String ACTION_UNLOCK = "unlock";
	public static final String ICM_ACTION_REASSIGN = "reassign";

	public static final String DOMAIN_TYPE_PREPSHEET = "PREPSHEET";
	public static final String PREPSHEET_ARCHIVE_TASK_TYPE = "IMGPREPDCO";
	public static final String EXPAG_IDENTIFIER_BATCH_NO = "BATCHNO";
	public static final String EXPAG_IDENTIFIER_IMAGE_SITE = "IMG SITE";

	public static final String REQUEST_TYPES = "REQUESTTYPES";
	public static final String REQUEST_TYPES_FOR_BUSINESSAREA = "requesttypesforbusinessarea";

	public static final String ESB_TIAA_NS = "http://esb.tiaa.org";
	public static final String TABLE_HEADER = "tableheader";

	public static final String SUMMARY = "summary";
	public static final String DOCUMENTS = "documents";
	public static final String COMMENTS = "comments";
	public static final String TASKS = "tasks";
	public static final String RELATEDCASES = "relatedcases";
	public static final String START = "start";
	public static final String TOTAL_RECORDS_COUNT = "TotalRecordsCount";
	public static final String NYSE_HOLIDAYS  = "NYSEHolidays";
	
	public static final String ACTION_ASSIGN  = "assign";
	public static final String DEPARTMENT_PAYOUT_OPERATIONS  = "Payout Operations";

	public static final String[] EXPAG_SYSTEM_USERS = {"OPERID","BPELPUSR","BPELUSR","DSVUSR01","PIEVAL","PIWAKE","ems","ems2","isvoper","piadmin","picopy","pifaxcha","pifaxden","piocrp","piocrpf","pipostp","pipostpf","pitest","predocs","uduwprd"};
	
	public static final String TABLEHEADERS = "TableHeaders";
	
	public static final String AWAKETODAY = "AwakeToday";
	public static final String OMNI_TASK_PLAN = "plan";
	public static final String OMNI_TASK_SUBPLAN = "subPlan";
	public static final String TASK = "task";
	public static final String USE_IDENTIFIERS_ID = "useidentifiersid";
	public static final String YYYYMMDD = "yyyyMMdd";
	public static final String HHMMSSSSS = "HHmmssSSS";
	public static final String APP_CMTS = "cmts";

	//converison related 
	public static final String CONVERTED_EXPAG_TASK = "convertedEXPAGTask";
	public static final String YES = "Y";
	public static final String NO = "N";
	
	public static final String METHOD_UPDATE_PROCESS="updateProcess";
	public static final String METHOD_ADD_COMMENTS="addComments";
	public static final String NON_UW_DOCUMENT="nonuwdocument";
	public static final String DOC_ORIGIN="docorigin";
}
