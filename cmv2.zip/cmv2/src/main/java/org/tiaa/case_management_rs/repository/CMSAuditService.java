package org.tiaa.case_management_rs.repository;

import java.util.Date;

import org.jvnet.hk2.annotations.Service;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.domain.CMSAudit;
import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.CMRSEvent;
import org.tiaa.case_management_rs.domain.ProcessingStatus;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.domain.TaskStatus;
import org.tiaa.case_management_rs.utils.CommonUtil;

@Service
public class CMSAuditService {
	@Autowired
	private CMSAuditRepository cmsAuditRepository;
	@Autowired
	private CMSAuditHistoryRepository cmsAuditHistoryRepository;

	public CMSAuditHistory markAsSuccessful(CMSAuditHistory cmsAuditHistory) {
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		Date lastUpdatedTs = new Date();
		if (cmsAudit.isUpdateCthRequestId()) {
			cmsAudit.setLastUpdatedTs(lastUpdatedTs);
			cmsAuditRepository.save(cmsAudit);
		}
		cmsAuditHistory.setStatus(ProcessingStatus.Success.name());
		cmsAuditHistory.setErrorMessage("");
		cmsAuditHistory.setLastUpdatedTs(lastUpdatedTs);
		return cmsAuditHistoryRepository.save(cmsAuditHistory);
	}

	public CMSAuditHistory markAsSameStatus(CMSAuditHistory cmsAuditHistory) {
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		Date lastUpdatedTs = new Date();
		if (cmsAudit != null && cmsAudit.isUpdateCthRequestId()) {
			cmsAudit.setLastUpdatedTs(lastUpdatedTs);
			cmsAuditRepository.save(cmsAudit);
		}
		cmsAuditHistory.setStatus(ProcessingStatus.Success.name());
		cmsAuditHistory.setComments(ProcessingStatus.SameStatus.name());
		cmsAuditHistory.setLastUpdatedTs(lastUpdatedTs);
		return cmsAuditHistoryRepository.save(cmsAuditHistory);
	}

	public CMSAuditHistory markSuccessfullyProcessed(CMSAuditHistory cmsAuditHistory) {
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		Date lastUpdatedTs = new Date();
		if (cmsAudit != null && cmsAudit.isUpdateCthRequestId()) {
			cmsAudit.setLastUpdatedTs(lastUpdatedTs);
			cmsAuditRepository.save(cmsAudit);
		}
		cmsAuditHistory.setStatus(ProcessingStatus.Success.name());
		cmsAuditHistory.setLastUpdatedTs(lastUpdatedTs);
		return cmsAuditHistoryRepository.save(cmsAuditHistory);
	}

	public CMSAuditHistory markAsFailed(CMSAuditHistory cmsAuditHistory, Exception e) {
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		Date lastUpdatedTs = new Date();
		if (cmsAudit != null && cmsAudit.isUpdateCthRequestId()) {
			cmsAudit.setLastUpdatedTs(lastUpdatedTs);
			cmsAuditRepository.save(cmsAudit);
		}
		cmsAuditHistory.setComments(e.getMessage());
		String exceptionStackTrace = CommonUtil.exceptionStackTrace(e);
		final int maxLength = 3000;
		String exceptionStackTraceSizedToFit = exceptionStackTrace.length() > maxLength ? exceptionStackTrace.substring(0, maxLength) : exceptionStackTrace;
		cmsAuditHistory.setErrorMessage(exceptionStackTraceSizedToFit);
		//
		cmsAuditHistory.setStatus(ProcessingStatus.Failed.name());
		cmsAuditHistory.setLastUpdatedTs(lastUpdatedTs);
		return cmsAuditHistoryRepository.save(cmsAuditHistory);
	}

	public CMSAuditHistory markAsFailed(CMSAuditHistory cmsAuditHistory, String errorMessage) {
		cmsAuditHistory.setErrorMessage(errorMessage);
		cmsAuditHistory.setLastUpdatedTs(new Date());
		return cmsAuditHistoryRepository.save(cmsAuditHistory);
	}

	public CMSAuditHistory markAsIgnore(CMSAuditHistory cmsAuditHistory, Exception e) {
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		Date lastUpdatedTs = new Date();
		if (cmsAudit != null && cmsAudit.isUpdateCthRequestId()) {
			cmsAudit.setLastUpdatedTs(lastUpdatedTs);
			cmsAuditRepository.save(cmsAudit);
		}
		cmsAuditHistory.setComments(e.getMessage());
		String exceptionStackTrace = CommonUtil.exceptionStackTrace(e);
		final int maxLength = 3000;
		String exceptionStackTraceSizedToFit = exceptionStackTrace.length() > maxLength ? exceptionStackTrace.substring(0, maxLength) : exceptionStackTrace;
		cmsAuditHistory.setErrorMessage(exceptionStackTraceSizedToFit);
		//
		cmsAuditHistory.setStatus(ProcessingStatus.Ignore.name());
		cmsAuditHistory.setLastUpdatedTs(lastUpdatedTs);
		return cmsAuditHistoryRepository.save(cmsAuditHistory);
	}

	public CMSAuditHistory createCMSAuditHistory(TaskInfo taskInfo) {
		return createCMSAuditHistory(taskInfo, false);
	}

	public CMSAuditHistory createAndSaveCMSAuditHistoryForCTHCancelEvent(String orchId, String errorMessage) {
		CMSAuditHistory cmsAuditHistory = new CMSAuditHistory();
		cmsAuditHistory.setCreatedDate(new Date());
		cmsAuditHistory.setCthRequestStatus(TaskStatus.Cancelled.getCthStatus());
		cmsAuditHistory.setTaskStatus(TaskStatus.Cancelled.name());
		cmsAuditHistory.setStatus(ProcessingStatus.Failed.name());
		cmsAuditHistory.setRetryAttempt(0);
		cmsAuditHistory.setCthEvent(true);
		cmsAuditHistory.setErrorMessage(errorMessage);
		cmsAuditHistory.setComments(String.format("orchId=%s", orchId));
		cmsAuditHistory.setEvent(CMRSEvent.EXPAG_CANCEL_TASK);
		//
		return cmsAuditHistoryRepository.saveAndFlush(cmsAuditHistory);
	}

	public CMSAuditHistory createAndSaveCMSAuditHistoryForCTHEvent(String orchId, CMRSEvent event) {
		CMSAuditHistory cmsAuditHistory = new CMSAuditHistory();
		cmsAuditHistory.setCreatedDate(new Date());
		cmsAuditHistory.setStatus(ProcessingStatus.InProgress.name());
		cmsAuditHistory.setRetryAttempt(0);
		cmsAuditHistory.setCthEvent(true);
		cmsAuditHistory.setEvent(event);
		cmsAuditHistory.setComments(String.format("orchId=%s", orchId));
		//
		return cmsAuditHistoryRepository.saveAndFlush(cmsAuditHistory);
	}

	public CMSAuditHistory createCMSAuditHistory(TaskInfo taskInfo, boolean cthEvent) {
		CMSAudit cmsAudit = cmsAuditRepository.findByTaskId(taskInfo.getTaskId());
		if (cmsAudit == null) {
			cmsAudit = createAuditEntry(taskInfo);
			cmsAudit = cmsAuditRepository.saveAndFlush(cmsAudit);
		}
		CMSAuditHistory cmsAuditHistory = createCMSAuditHistoryInternal(taskInfo);
		cmsAuditHistory.setCthEvent(cthEvent);
		cmsAuditHistory.setCmsAudit(cmsAudit);
		cmsAudit.getCmsAuditHistories().add(cmsAuditHistory);
		//
		return cmsAuditHistoryRepository.saveAndFlush(cmsAuditHistory);
	}

	private CMSAuditHistory createCMSAuditHistoryInternal(TaskInfo taskInfo) {
		CMSAuditHistory cmsAuditHistory = new CMSAuditHistory();
		cmsAuditHistory.setCreatedDate(new Date());
		cmsAuditHistory.setComments("");
		cmsAuditHistory.setCthRequestStatus(taskInfo.getCthStatus());
		cmsAuditHistory.setTaskStatus(taskInfo.getTaskStatusAsStr());
		//
		cmsAuditHistory.setStatus(ProcessingStatus.InProgress.name());
		cmsAuditHistory.setRetryAttempt(0);
		cmsAuditHistory.setTaskId(taskInfo.getTaskId());
		cmsAuditHistory.setStartDate(taskInfo.getStartDate());
		cmsAuditHistory.setStartTime(taskInfo.getStartTime());
		return cmsAuditHistory;
	}

	private CMSAudit createAuditEntry(TaskInfo taskInfo) {
		CMSAudit cmsAudit = new CMSAudit();
		cmsAudit.setCaseId(taskInfo.getWorkpacketId());
		cmsAudit.setTaskType(taskInfo.getTaskType());
		cmsAudit.setTaskId(taskInfo.getTaskId());
		cmsAudit.setCthOrchestrationId(taskInfo.getCthOrchestrationId());
		cmsAudit.setSystem(taskInfo.getSystem());
		cmsAudit.setCreatedDate(new Date());
		//
		return cmsAudit;
	}
}