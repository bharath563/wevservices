package org.tiaa.case_management_rs.model;

import java.sql.Types;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;

public class SearchRecordByGroup extends StoredProcedure  
{  
    public SearchRecordByGroup(JdbcTemplate expagJdbcTemplate, DataSource ds)  
    {  
        super(expagJdbcTemplate, "GETLINK");  
        declareParameter(new SqlOutParameter("p_links", OracleTypes.CURSOR,new SearchRecordTypeMapper()));  
        declareParameter(new SqlParameter("p_link_id",Types.VARCHAR));  
        compile();  
    }  
}  
