package org.tiaa.case_management_rs.integration.exp_ag;

import org.tiaa.case_management_rs.domain.ProcessingStatus;

public class TaskHistoryEvent {
	private String taskId;
	private int startDate;
	private int startTime;
	private String status;
	private String errorMessage;

	public TaskHistoryEvent() {
		super();
	}

	public TaskHistoryEvent(String taskId, int startDate, int startTime) {
		super();
		this.taskId = taskId;
		this.startDate = startDate;
		this.startTime = startTime;
	}

	public TaskHistoryEvent(String taskId, int startDate, int startTime, String status, String errorMessage) {
		super();
		this.taskId = taskId;
		this.startDate = startDate;
		this.startTime = startTime;
		this.status = status;
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}
	
	public int getStartDate() {
		return startDate;
	}

	public int getStartTime() {
		return startTime;
	}

	public String getStatus() {
		return status;
	}

	public String getTaskId() {
		return taskId;
	}

	public boolean isLessThan(TaskHistoryEvent other) {
		return other.startDate > startDate || (other.startDate == startDate && other.startTime >= startTime);
	}

	public boolean isSame(TaskHistoryEvent other) {
		return other.startDate == startDate && other.startTime == startTime;
	}

	public void setStartDate(int startDate) {
		this.startDate = startDate;
	}

	public void setStartTime(int startTime) {
		this.startTime = startTime;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		TaskHistoryEvent other = (TaskHistoryEvent) obj;
		if (startDate != other.startDate) {
			return false;
		}
		if (startTime != other.startTime) {
			return false;
		}
		if (taskId == null) {
			if (other.taskId != null) {
				return false;
			}
		} else if (!taskId.equals(other.taskId)) {
			return false;
		}
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + startDate;
		result = prime * result + startTime;
		result = prime * result + ((taskId == null) ? 0 : taskId.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "TaskHistoryEvent [taskId=" + taskId + ", startDate=" + startDate + ", startTime=" + startTime + ", status=" + status + ", errorMessage=" + errorMessage + "]";
	}

	public boolean isFailedStatus() {
		return ProcessingStatus.Failed.name().equals(status);
	}
}
