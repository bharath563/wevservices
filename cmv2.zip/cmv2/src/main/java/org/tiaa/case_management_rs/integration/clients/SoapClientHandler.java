/**
 * 
 */
package org.tiaa.case_management_rs.integration.clients;

import java.util.Iterator;

import javax.xml.namespace.QName;
import javax.xml.rpc.handler.Handler;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.MessageContext;
import javax.xml.rpc.handler.soap.SOAPMessageContext;
import javax.xml.soap.SOAPEnvelope;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPHeaderElement;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.utils.GuidUtility;

/**
 * @author ganapaa
 *
 */
public class SoapClientHandler implements Handler {

	private HandlerInfo handlerInfo;
	
	private static final Logger LOG = LoggerFactory.getLogger(SoapClientHandler.class);
	
	@Override
	public void destroy() {
	}

	@Override
	public QName[] getHeaders() {
		return handlerInfo.getHeaders();
	}

	@Override
	public boolean handleFault(MessageContext arg0) {
		return false;
	}

	@Override
	public boolean handleRequest(MessageContext mc) {
		
		try {
			SOAPMessage message = ((SOAPMessageContext) mc).getMessage();
			SOAPPart soapPart = message.getSOAPPart();
			SOAPEnvelope soapEnvelope = soapPart.getEnvelope();
			SOAPHeader header = soapEnvelope.getHeader();
			Iterator<SOAPHeaderElement> elements = header.getChildElements();
			while(elements.hasNext()) {
				SOAPHeaderElement element = elements.next();
				if(element.getNamespaceURI().equalsIgnoreCase(CaseManagementConstants.ESB_TIAA_NS)) {
					element.setAttributeNS(CaseManagementConstants.ESB_TIAA_NS, "guid", new GuidUtility().toString());	
					message.saveChanges();
					break;
				}				
			}			
		} catch (SOAPException e) {
			LOG.error(e.getMessage());
		}
		
		return true;
	}

	@Override
	public boolean handleResponse(MessageContext arg0) {
		return false;
	}

	@Override
	public void init(HandlerInfo hi) {
		handlerInfo = hi;
	
	}

}
