package org.tiaa.case_management_rs.email;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EmailConfig {
	private static final Logger LOG = LoggerFactory.getLogger(EmailConfig.class);

	@Bean
	public EmailSender emailSender() {
		return new LoggingEmailSender();
	}

	private static class LoggingEmailSender implements EmailSender {
		@Override
		public boolean isEmailEnabled() {
			return false;
		}

		@Override
		public boolean sendEmail(String from, String toEmail, String subject, String emailText) {
			log(subject, emailText);
			return false;
		}

		@Override
		public boolean sendEmail(String from, String toEmail, String ccEmail, String subject, String emailText) {
			log(subject, emailText);
			return false;
		}

		@Override
		public boolean sendEmail(String from, String[] toEmail, String ccEmail, String subject, String emailText) {
			log(subject, emailText);
			return false;
		}

		@Override
		public boolean sendEmailToProdSupport(String subject, String emailText) {
			log(subject, emailText);
			return false;
		}

		@Override
		public void sendHtmlEmail(String subject, String html) {
			log(subject, html);
		}

		@Override
		public void sendTextEmail(String subject, String text) {
			log(subject, text);
		}

		private void log(String subject, String emailText) {
			LOG.debug("subject: , emailText: ", subject, emailText);
		}

		@Override
		public void setEmailEnabled(boolean enableEmail) {
		}

		@Override
		public boolean sendEmail(String from, String[] toEmail, String subject, String emailText) {
			log(subject, emailText);
			return false;
		}
	}
}
