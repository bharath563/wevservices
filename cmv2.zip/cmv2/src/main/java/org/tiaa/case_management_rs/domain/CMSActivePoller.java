package org.tiaa.case_management_rs.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.core.style.ToStringCreator;

@Entity
@Table(name = "CMS_ACTIVE_POLLER")
public class CMSActivePoller implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name = "OWNER", nullable = true)
	private String owner;
	@Id
	@Column(name = "NAME", nullable = false)
	private String name;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_UPDATED_TS", nullable = true)
	private Date lastUpdatedTimestamp;

	public Date getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Date lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getComponent() {
		return name;
	}

	public void setComponent(String component) {
		this.name = component;
	}

	public long getTime() {
		return getLastUpdatedTimestamp().getTime();
	}

	@Override
	public String toString() {
		return new ToStringCreator(this).append("owner", getOwner()).append("name", getComponent()).append(
				"lastUpdatedTs", getLastUpdatedTimestamp()).toString();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		if (!(obj instanceof CMSActivePoller)) {
			return false;
		}
		CMSActivePoller other = (CMSActivePoller) obj;
		return this.name.equals(other.getComponent()) && this.owner.equals(other.getOwner());
	}

	@Override
	public int hashCode() {
		int result = 17;
		result = 31 * result + this.name.hashCode();
		result = 31 * result + this.owner.hashCode();
		return result;
	}
}
