package org.tiaa.case_management_rs.integration.case_manager.domain;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.servicerequest_workflow.types.DocumentType;

public class CaseDetails {
	private static final Logger LOG = LoggerFactory.getLogger(CaseDetails.class);
	private Case kase;
	//
	private String cthOrchestrationId;
	private String cthRequestId;
	private String cthStatus;
	//
	private String system = "CaseManager";
	private String processType = "InstitutionalImplementationRequest";
	private String requestType = "";
	//
	private int startDate;
	private int startTime;
	//
	private boolean useChannelInCaseManager;

	public CaseDetails() {
		super();
	}

	public CaseDetails(Case kase) {
		super();
		this.kase = kase;
		Date caseStartedTS = kase.getCaseStartedTS();
		startDate = Integer.parseInt(new SimpleDateFormat("yyyyMMdd").format(caseStartedTS));
		startTime = Integer.parseInt(new SimpleDateFormat("mmHHss").format(caseStartedTS));
	}

	public String getClientId() {
		return kase.getClientId();
	}

	public String getSystemIdentifier() {
		return "EX-PAG";
	}

	public String getCthStatus() {
		String caseStatus = kase.getCaseStatus();
		//
		HashMap<String, String> caseStatus2CthStatus = new HashMap<String, String>();
		caseStatus2CthStatus.put("Cancelled", "Cancelled");
		caseStatus2CthStatus.put("Pending Forms", "Submitted");
		caseStatus2CthStatus.put("COMPLETED", "Completed");
		caseStatus2CthStatus.put("In Process", "In Process");
		caseStatus2CthStatus.put("Completed", "Completed");
		caseStatus2CthStatus.put("Withdrawn", "Cancelled");
		caseStatus2CthStatus.put("Expired", "Cancelled");
		caseStatus2CthStatus.put("Cancel", "Cancelled");
		caseStatus2CthStatus.put("Received", "Submitted");
		caseStatus2CthStatus.put("Started", "In Process");
		caseStatus2CthStatus.put("NIGO", "NIGO");
		caseStatus2CthStatus.put("Suspended", "Suspended");
		caseStatus2CthStatus.put("Rejected", "Cancelled");
		caseStatus2CthStatus.put("Declined", "Cancelled");
		caseStatus2CthStatus.put("Reviewed", "In Process");
		caseStatus2CthStatus.put("NIGO'ed", "Cancelled");

		String cthStatus = caseStatus2CthStatus.get(caseStatus);
		if (cthStatus == null) {
			LOG.warn("case status not correctly mapped:" + caseStatus);
			return "In Process";
		}
		return cthStatus;
	}

	public String getChannel() {
		if (useChannelInCaseManager) {
			return kase.getChannel();
		}
		return "Internal";
	}

	public String getUpdatedBy() {
		return AppConstants.APPLICATION_NAME;
	}

	public XMLGregorianCalendar getRecievedDateTimeAsXMLGregorianCalendar() {
		return kase.getRecievedDateTimeAsXMLGregorianCalendar();
	}

	public XMLGregorianCalendar getRecievedDateTimeAsXMLGregorianCalendarAsDate() {
		return kase.getRecievedDateTimeAsXMLGregorianCalendarAsDate();
	}

	public String getCaseStatus() {
		return kase.getCaseStatus();
	}

	public String getCaseId() {
		return kase.getCaseId();
	}

	public String getGenericCaseType() {
		String caseType = kase.getCaseType();
		return caseType == null ? "" : caseType;
	}

	public String getCaseType() {
		String caseName = kase.getCaseName();
		int index = caseName.indexOf("_");
		if (index != -1) {
			caseName = caseName.substring(0, index);
		}
		return caseName == null ? "" : caseName;
	}

	public String getCthOrchestrationId() {
		return cthOrchestrationId;
	}

	public String getCthRequestId() {
		return cthRequestId;
	}

	public List<? extends DocumentType> getDocuments() {
		return kase.getDocuments().getDocuments();
	}

	public String getProcessType() {
		return processType;
	}

	public String getRequestType() {
		return requestType;
	}

	public int getStartDate() {
		return startDate;
	}

	public int getStartTime() {
		return startTime;
	}

	public String getSystem() {
		return system;
	}

	public String getTaskId() {
		return getCaseId();
	}

	public void setCthOrchestrationId(String cthOrchestrationId) {
		this.cthOrchestrationId = cthOrchestrationId;
	}

	public void setCthRequestId(String cthRequestId) {
		this.cthRequestId = cthRequestId;
	}

	public void setCthStatus(String cthStatus) {
		this.cthStatus = cthStatus;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public void setStartDate(int startDate) {
		this.startDate = startDate;
	}

	public void setStartTime(int startTime) {
		this.startTime = startTime;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public Case getKase() {
		return kase;
	}

	public void setKase(Case kase) {
		this.kase = kase;
	}

	public Date getTargetImplementationDate() {
		String targetImplDate = kase.getTargetImplDate();
		if (targetImplDate == null) {
			return null;
		}
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
			return simpleDateFormat.parse(targetImplDate);
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
		}
		return null;
	}

	public String getCurrentPhaseName() {
		return kase.getCurrentPhaseName();
	}

	public String getCurrentPhaseDescription() {
		return kase.getCurrentPhaseDesription();
	}

	public Date getPhaseTargetImplementationDate() {
		return kase.getCurrentPhaseTargetCompletionDateTime();
	}

	public String getPhaseTargetImplementationDateAsStr() {
		String currentPhaseTargetCompletionTS = kase.getCurrentPhaseTargetCompletionTS();
		return currentPhaseTargetCompletionTS == null ? "" : currentPhaseTargetCompletionTS;
	}

	public String getWorkflowTaskID() {
		return kase.getRequestId();
	}

	public String getTransitionManager() {
		String transitionManager = kase.getTransitionManager();
		return transitionManager == null ? "" : transitionManager;
	}

	public String getServiceRequestTopic() {
		return getCaseType();
	}

	public Date getActualImplementationDate() {
		return kase.getCaseCompletedTS();
	}

	public String getActualImplementationDateAsStr() {
		Date caseCompletedTS = kase.getCaseCompletedTS();
		return caseCompletedTS == null ? "" : DateUtil.toXmlFormat(caseCompletedTS);
	}

	public boolean updateTaskStatusInCTH(String status) {
		return true;
	}

	public boolean hasDocuments() {
		return !kase.getDocuments().getDocuments().isEmpty();
	}

	public List<Phase> getPhases() {
		return getKase().getPhases().getPhases();
	}

	@Override
	public String toString() {
		return "CaseDetails [kase=" + kase + ", cthOrchestrationId=" + cthOrchestrationId + ", cthRequestId=" + cthRequestId + ", cthStatus=" + cthStatus + ", system=" + system
				+ ", processType=" + processType + ", requestType=" + requestType + ", startDate=" + startDate + ", startTime=" + startTime + "]";
	}
}
