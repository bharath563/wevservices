package org.tiaa.case_management_rs.integration.cth;

import java.util.List;

import org.tiaa.case_management_rs.domain.Identifier;
import org.tiaa.case_management_rs.domain.Identifiers;
import org.tiaa.case_management_rs.domain.TaskDetails;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.esb.plansponsor.types.Contact;
import org.tiaa.esb.plansponsor.types.ContactResp;
import org.tiaa.esb.plansponsor.types.ContactResponse;
import org.tiaa.esb.plansponsor.types.Contacts;
import org.tiaa.esb.plansponsor.types.Name;

public class AbstractContext {
	private ContactResponse contactResponse;
	private TaskDetails taskDetails;

	public Contact getContact() {
		if (contactResponse == null) {
			return null;
		}
		ContactResp contactResp = contactResponse.getContactResp();
		if (contactResp == null) {
			return null;
		}
		Contacts contacts = contactResp.getContacts();
		if (contacts == null) {
			return null;
		}
		List<Contact> contact = contacts.getContacts();
		if (contact == null) {
			return null;
		}
		if (contact.isEmpty()) {
			return null;
		}
		return contact.get(0);
	}

	public Name getContactName() {
		Contact contact = getContact();
		if (contact == null) {
			return null;
		}
		return contact.getName();
	}

	public ContactResponse getContactResponse() {
		return contactResponse;
	}

	public String getCustomerNumber() {
		TaskInfo taskInfo = taskDetails.getTaskInfo();
		return taskInfo == null ? "" : taskInfo.getCustomerNumber();
	}
	
	public String getTaskId() {
		TaskInfo taskInfo = taskDetails.getTaskInfo();
		return taskInfo == null ? "" : taskInfo.getTaskId();
	}

	public String getFirstName() {
		Name contactName = getContactName();
		if (contactName == null) {
			return "";
		}
		String firstName = contactName.getFirstName();
		return firstName == null ? "" : firstName;
	}

	public Identifiers getIdentifiers() {
		return taskDetails.getIdentifiers();
	}

	public String getLastName() {
		Name contactName = getContactName();
		if (contactName == null) {
			return "";
		}
		String lastName = contactName.getLastName();
		return lastName == null ? "" : lastName;
	}

	public String getStringIdentifierValue(String name) {
		Identifier identifier = getIdentifiers().getIdentifier(name);
		return identifier == null ? null : identifier.getStringValue();
	}

	public TaskDetails getTaskDetails() {
		return taskDetails;
	}

	public TaskInfo getTaskInfo() {
		return taskDetails.getTaskInfo();
	}

	public void setContactResponse(ContactResponse contactResponse) {
		this.contactResponse = contactResponse;
	}

	public void setTaskDetails(TaskDetails taskDetails) {
		this.taskDetails = taskDetails;
	}

	@Override
	public String toString() {
		return "AbstractContext [contactResponse=" + contactResponse + ", taskDetails=" + taskDetails + "]";
	}
}
