package org.tiaa.case_management_rs.validator.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.util.List;

import org.apache.commons.lang3.StringUtils;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.Properties;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;

public class TaskSearchValidator extends BaseValidatorImpl {

	@Override
	public void doValidate(Request request) {

		SearchRequest searchRequest = (SearchRequest) request
				.getAttribute(CaseManagementConstants.SEARCH_REQUEST);

		Properties props = searchRequest.getProperties();
		List<NameValue> nameValueList = props.getProperties();
		boolean searchTypeValid = false;
		for (NameValue nameValue : nameValueList) {
			if (StringUtils.isNotEmpty(nameValue.getName())
					&& nameValue.getName().equalsIgnoreCase("SearchType")) {
				if (StringUtils.isNoneEmpty(nameValue.getValue())
						&& nameValue.getValue().equalsIgnoreCase("NIGO")) {
					searchTypeValid = true;
				}
			}
		}
		if (!searchTypeValid) {
			handleException(VALIDATION_TASKSEARCH_TYPE_VALUE_IS_MISSING_OR_WRONG);
		}
	}

}
