package org.tiaa.case_management_rs.integration.exp_ag;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.utils.DateUtil;

public class EXPAGTaskInfoMapper extends AbstractRowMapper<TaskInfo> implements RowMapper<TaskInfo> {
	/*
	 * s.statusdesc, t.tskid, t.pidate, t.starttime, operid, t.datercvd,
	 * t.timercvd, t.dptcode, t.tskcode, t.actcode, t.wrkbskt, t.viptsk,
	 * t.priority, t.status, c.pktid, c.compdate, c.comptime
	 */
	@Override
	public TaskInfo mapRow(ResultSet resultSet, int index) throws SQLException {
		TaskInfo taskInfo = new TaskInfo();
		taskInfo.setSystem("EXP_AG");
		taskInfo.setTaskId(getStringTrimmed(resultSet, "tskid"));
		taskInfo.setOperatorId(getStringTrimmed(resultSet, "operid"));
		taskInfo.setDptcode(getStringTrimmed(resultSet, "dptcode"));
		taskInfo.setTskcode(getStringTrimmed(resultSet, "tskcode"));
		taskInfo.setTaskType(getStringTrimmed(resultSet, "tskdesc"));
		taskInfo.setActcode(getStringTrimmed(resultSet, "actcode"));
		taskInfo.setWrkbskt(getStringTrimmed(resultSet, "wrkbskt"));
		taskInfo.setViptsk(getStringTrimmed(resultSet, "viptsk"));
		taskInfo.setPriority(getStringTrimmed(resultSet, "priority"));
		taskInfo.setStatusCode(getStringTrimmed(resultSet, "status"));
		taskInfo.setPktid(getStringTrimmed(resultSet, "pktid"), getStringTrimmed(resultSet, "completedpktid"));
		taskInfo.setStatusDescription(getStringTrimmed(resultSet, "statusdesc"));
		//
		taskInfo.setTaskLastUpdated(DateUtil.parseDateTime(getString(resultSet, "pidate"), getString(resultSet, "starttime")));
		taskInfo.setStartDate(resultSet.getInt("pidate"));
		taskInfo.setStartTime(resultSet.getInt("starttime"));
		taskInfo.setRecievedDateTime(DateUtil.parseDateTime(getString(resultSet, "datercvd"), getString(resultSet, "timercvd")));
		taskInfo.setCompletedDateTime(DateUtil.parseDateTime(getString(resultSet, "compdate"), getString(resultSet, "comptime")));
		if (taskInfo.isCompleted()) {
			taskInfo.addIdentifier(getStringTrimmed(resultSet, "iddesc").trim(), getStringTrimmed(resultSet, "compfieldvalue").trim());
			taskInfo.setCreateOperator(getStringTrimmed(resultSet, "createoper2"));
		} else {
			taskInfo.addIdentifier(getStringTrimmed(resultSet, "iddesc").trim(), getStringTrimmed(resultSet, "fieldvalue").trim());
			taskInfo.setCreateOperator(getStringTrimmed(resultSet, "createoper"));
		}
		taskInfo.setTaskStatus();
		return taskInfo;
	}

}