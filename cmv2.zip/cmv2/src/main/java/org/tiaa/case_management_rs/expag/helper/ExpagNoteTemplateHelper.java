package org.tiaa.case_management_rs.expag.helper;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.SAXException;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.txt.TXTParser;
import org.apache.tika.sax.BodyContentHandler;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.exception.CaseManagementRuntimeException;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItem;

@Component
public class ExpagNoteTemplateHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExpagNoteTemplateHelper.class);

	@Value("${expag.note.template.folderpath}")
	private String noteTemplateFolderPath;

	public ConfigItem getNoteTemplates(String dropDownName) {
		ConfigItem configItem = new ConfigItem();

		configItem.setItemName(dropDownName);

		// Load all the tpl files from the Notetemplate folder and set it in the
		// response
		try {

			File dir = new File(this.noteTemplateFolderPath);

			LOGGER.debug("Getting all files in " + dir.getCanonicalPath() + " including those in subdirectories");

			List<File> files = (List<File>) FileUtils.listFiles(dir, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);

			if (files != null) {

				for (File file : files) {

					ConfigData configData = new ConfigData();

					LOGGER.debug("file: " + file.getCanonicalPath());

					FileInputStream fis = new FileInputStream(file);

					// detecting the file type
					BodyContentHandler handler = new BodyContentHandler();
					Metadata metadata = new Metadata();
					ParseContext pcontext = new ParseContext();

					// Text document parser
					TXTParser TexTParser = new TXTParser();
					TexTParser.parse(fis, handler, metadata, pcontext);
					LOGGER.debug("Contents of the document:" + handler.toString());

					String noteTemplate = this.textToHTML(handler.toString());

					String encodedNoteTemplate = org.apache.commons.codec.binary.Base64.encodeBase64URLSafeString(noteTemplate.getBytes());

					String[] result = file.getName().split("\\.", 2);
					String noteTemplateName = result[0];

					configData.setShortDescription(noteTemplateName);
					configData.setLongDescription(encodedNoteTemplate);

					fis.close();

					configItem.getDataPairs().add(configData);
				}
			}

		} catch (IOException e) {

			throw new CaseManagementRuntimeException("IOException occured while loading the note temaplates from the directory path " + this.noteTemplateFolderPath);

		} catch (SAXException e) {

			throw new CaseManagementRuntimeException("SAXException occured while loading the note temaplates from the directory path " + this.noteTemplateFolderPath);

		} catch (TikaException e) {

			throw new CaseManagementRuntimeException("TikaException occured while loading the note temaplates from the directory path " + this.noteTemplateFolderPath);

		}

		return configItem;

	}

	private String textToHTML(String text) {

		if (text == null) {
			return null;
		}

		int length = text.length();
		boolean prevSlashR = false;
		StringBuffer out = new StringBuffer();

		for (int i = 0; i < length; i++) {
			char ch = text.charAt(i);
			switch (ch) {
				case '\r' :
					if (prevSlashR) {
						out.append("<br>");
					}
					prevSlashR = true;
					break;
				case '\n' :
					prevSlashR = false;
					out.append("<br>");
					break;
				case '"' :
					if (prevSlashR) {
						out.append("<br>");
						prevSlashR = false;
					}
					out.append("&quot;");
					break;
				case '<' :
					if (prevSlashR) {
						out.append("<br>");
						prevSlashR = false;
					}
					out.append("&lt;");
					break;
				case '>' :
					if (prevSlashR) {
						out.append("<br>");
						prevSlashR = false;
					}
					out.append("&gt;");
					break;
				case '&' :
					if (prevSlashR) {
						out.append("<br>");
						prevSlashR = false;
					}
					out.append("&amp;");
					break;
				default :
					if (prevSlashR) {
						out.append("<br>");
						prevSlashR = false;
					}
					out.append(ch);
					break;
			}
		}
		return out.toString();
	}
}
