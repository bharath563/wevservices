package org.tiaa.case_management_rs.domain;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.time.DateFormatUtils;

import org.tiaa.case_management_rs.utils.DateUtil;

@Entity
@Table(name="CMS_POLLER_LOG")
public class CMSPollerLog implements Serializable {
	private static final Logger LOG = LoggerFactory.getLogger(CMSPollerLog.class);
	private static final long serialVersionUID = -3599679175228588484L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="CMS_POLLER_LOG_SEQ")
	@SequenceGenerator(name = "CMS_POLLER_LOG_SEQ", sequenceName = "CMREPORTING.CMS_POLLER_LOG_SEQ", allocationSize = 1)
	private long id;
	//
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="LAST_PROCESSED_TS")
	private Date lastProcessedDateTime;
	//
	@Enumerated(EnumType.STRING)
	private WorkflowSystem workflowSystem;
	private String hostName;
	private String nodeName;
	private boolean active;
	
	public String getHostName() {
		return hostName;
	}

	public long getId() {
		return id;
	}

	public int getLastProcessedDate() {
		return Integer.parseInt(DateFormatUtils.format(getLastProcessedDateTime(), "yyyyMMdd"));
	}

	public Date getLastProcessedDateTime() {
		if (lastProcessedDateTime == null) {
			lastProcessedDateTime = DateUtil.getStartOfDay();
		}
		return lastProcessedDateTime;
	}

	public int getLastProcessedTime() {
		return Integer.parseInt(DateFormatUtils.format(getLastProcessedDateTime(), "HHmmss") + "00");
	}

	public WorkflowSystem getWorkflowSystem() {
		return workflowSystem;
	}

	public boolean isActive() {
		return active;
	}

	public void printInfo() {
		LOG.debug("startDate:{}", getLastProcessedDate());
		LOG.debug("startTime:{}", getLastProcessedTime());
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setLastProcessedDateTime(Date lastProcessedDateTime) {
		this.lastProcessedDateTime = lastProcessedDateTime;
	}

	public void setWorkflowSystem(WorkflowSystem workflowSystem) {
		this.workflowSystem = workflowSystem;
	}

	@Override
	public String toString() {
		return "CMSPollerLog [id=" + id + ", lastProcessedDateTime=" + lastProcessedDateTime + ", workflowSystem=" + workflowSystem + ", hostName=" + hostName + ", active="
				+ active + "]";
	}

	public String getNodeName() {
		return nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

}
