package org.tiaa.case_management_rs.support;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang3.StringUtils;

import org.tiaa.esb.case_management_rs_v2.type.CommentsResponse;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItemsResponse;
import org.tiaa.esb.case_management_rs_v2.type.DocumentResponse;
import org.tiaa.esb.case_management_rs_v2.type.DocumentsResponse;
import org.tiaa.esb.case_management_rs_v2.type.MetricsResponse;
import org.tiaa.esb.case_management_rs_v2.type.ObjectFactory;
import org.tiaa.esb.case_management_rs_v2.type.ProcessResponse;
import org.tiaa.esb.case_management_rs_v2.type.ProcessesResponse;
import org.tiaa.esb.case_management_rs_v2.type.ResponseStatus;
import org.tiaa.esb.case_management_rs_v2.type.SearchResponse;
import org.tiaa.esb.case_management_rs_v2.type.TaskResponse;
import org.tiaa.esb.case_management_rs_v2.type.TasksResponse;

public final class ResponseObjectFactory {

	private static final ObjectFactory CASEMANAGEMENTRS_OBJECT_FACTORY = new ObjectFactory();

	private ResponseObjectFactory() {

	}

	public static ProcessesResponse createProcessesResponse(String status, String statusMessage) {
		ProcessesResponse resp = CASEMANAGEMENTRS_OBJECT_FACTORY.createProcessesResponse();
		resp.setResponseStatus(createEsbResponseStatus(status, statusMessage));
		return resp;
	}

	public static ProcessResponse createProcessResponse(String status, String statusMessage) {
		ProcessResponse resp = CASEMANAGEMENTRS_OBJECT_FACTORY.createProcessResponse();
		resp.setResponseStatus(createEsbResponseStatus(status, statusMessage));
		return resp;
	}

	public static DocumentResponse createDocumentResponse(String status, String statusMessage) {
		DocumentResponse resp = CASEMANAGEMENTRS_OBJECT_FACTORY.createDocumentResponse();
		resp.setResponseStatus(createEsbResponseStatus(status, statusMessage));
		return resp;
	}

	public static DocumentsResponse createDocumentsResponse(String status, String statusMessage) {
		DocumentsResponse resp = CASEMANAGEMENTRS_OBJECT_FACTORY.createDocumentsResponse();
		resp.setResponseStatus(createEsbResponseStatus(status, statusMessage));
		return resp;
	}

	public static ConfigItemsResponse createConfigItemResponse(String status, String statusMessage) {
		ConfigItemsResponse resp = CASEMANAGEMENTRS_OBJECT_FACTORY.createConfigItemsResponse();
		resp.setResponseStatus(createEsbResponseStatus(status, statusMessage));
		return resp;
	}

	public static SearchResponse createSearchResponse(String status, String statusMessage) {
		SearchResponse resp = CASEMANAGEMENTRS_OBJECT_FACTORY.createSearchResponse();
		resp.setResponseStatus(createEsbResponseStatus(status, statusMessage));
		return resp;
	}

	public static MetricsResponse createMetricsResponse(String status, String statusMessage) {
		MetricsResponse resp = CASEMANAGEMENTRS_OBJECT_FACTORY.createMetricsResponse();
		resp.setResponseStatus(createEsbResponseStatus(status, statusMessage));
		return resp;
	}	
	
	public static TasksResponse createTasksResponse(String status, String statusMessage) {
		TasksResponse resp = CASEMANAGEMENTRS_OBJECT_FACTORY.createTasksResponse();
		resp.setResponseStatus(createEsbResponseStatus(status, statusMessage));
		return resp;
	}	
	
	
	public static CommentsResponse createCommentsResponse(String status, String statusMessage) {
		CommentsResponse resp = CASEMANAGEMENTRS_OBJECT_FACTORY.createCommentsResponse();
		resp.setResponseStatus(createEsbResponseStatus(status, statusMessage));
		return resp;
	}
	
	
	
	public static ResponseStatus createEsbResponseStatus(String status, String text) {
		ResponseStatus esbResponseStatus = CASEMANAGEMENTRS_OBJECT_FACTORY.createResponseStatus();
		esbResponseStatus.setStatus(status.toString());

		if (StringUtils.isNotBlank(text)) {
			esbResponseStatus.setStatusText(text);
		}
		return esbResponseStatus;
	}

	public static Response createResponseStatus(ResponseStatus responseStatus, Object object) {
		// getMessage - will create new Array List if null
		String type = null;
		Response response = null;
		if ((responseStatus != null) && (responseStatus.getMessages() != null) && (responseStatus.getMessages().getMessages().size() > 0)) {
			type = responseStatus.getMessages().getMessages().get(0).getType();
			String code = responseStatus.getMessages().getMessages().get(0).getCode();
			if (GENERAL_ERROR_CODE.equals(code)) {
				response = Response.status(Status.INTERNAL_SERVER_ERROR).entity(object).build();
			} else {
				response = Response.status(org.tiaa.case_management_rs.utils.ResponseStatus.valueOf(type).value()).entity(object).build();
			}
		}
		return response;
	}
	public static TaskResponse createTaskResponse(String status,
			String statusMessage) {
		TaskResponse resp = CASEMANAGEMENTRS_OBJECT_FACTORY
				.createTaskResponse();
		resp.setResponseStatus(createEsbResponseStatus(status, statusMessage));
		return resp;
	}

}
