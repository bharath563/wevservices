package org.tiaa.case_management_rs.integration.case_manager.cth;

import java.io.Serializable;

import org.tiaa.case_management_rs.domain.CMSTaskType;
import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;

public class CreateCTHCaseContext extends AbstractCTHCaseContext implements Serializable {
	private static final long serialVersionUID = 642209869358124381L;
	private CMSTaskType cmsTaskType;
	private String cthOrchestrationId;
	private String cthRequestId;
	private boolean success;
	//
	private CaseDetails caseDetails;

	public CreateCTHCaseContext() {
		super();
	}

	public CaseDetails getCaseDetails() {
		return caseDetails;
	}

	public String getCthOrchestrationId() {
		return cthOrchestrationId;
	}

	public String getCthRequestId() {
		return cthRequestId;
	}

	public String getClientId() {
		return caseDetails.getClientId();
	}

	public String getCaseId() {
		return caseDetails.getCaseId();
	}

	public boolean isSuccess() {
		return success;
	}

	public void setCaseDetails(CaseDetails caseDetails) {
		this.caseDetails = caseDetails;
	}

	public void setCthOrchestrationId(String cthOrchestrationId) {
		this.cthOrchestrationId = cthOrchestrationId;
	}

	public void setCthRequestId(String cthRequestId) {
		this.cthRequestId = cthRequestId;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	@Override
	public String toString() {
		return "CreateCTHCaseContext [cmsTaskType=" + cmsTaskType + ", cthOrchestrationId=" + cthOrchestrationId + ", cthRequestId=" + cthRequestId + ", success=" + success
				+ ", caseDetails=" + caseDetails + "]";
	}

	public CMSTaskType getCmsTaskType() {
		return cmsTaskType;
	}

	public void setCmsTaskType(CMSTaskType cmsTaskType) {
		this.cmsTaskType = cmsTaskType;
	}
}
