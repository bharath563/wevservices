package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.domain.EXPAGFileInfo;
import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;

public class EXPAGFilePathMapper extends AbstractRowMapper<EXPAGFileInfo> implements RowMapper<EXPAGFileInfo> {

	@Override
	public EXPAGFileInfo mapRow(ResultSet resultSet, int index) throws SQLException {
		EXPAGFileInfo expagFileInfo = new EXPAGFileInfo();

		expagFileInfo.setFilename(getStringTrimmed(resultSet, "foldername"));
		expagFileInfo.setFilepath(getStringTrimmed(resultSet, "filepath"));
		expagFileInfo.setVolume(getStringTrimmed(resultSet, "volume"));

		return expagFileInfo;
	}

}
