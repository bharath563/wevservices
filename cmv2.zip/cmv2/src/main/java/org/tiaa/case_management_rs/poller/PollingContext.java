package org.tiaa.case_management_rs.poller;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.tiaa.case_management_rs.domain.CMSPollerLog;
import org.tiaa.case_management_rs.domain.CMSTaskDocument;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.utils.CommonUtil;

public class PollingContext {
	private CMSPollerLog pollerLog;
	private List<CMSTaskDocument> taskDocuments = new ArrayList<CMSTaskDocument>();
	private List<String> taskIdsInProgress = new ArrayList<String>();
	private List<String> taskIdsCompletedOrCancelled = new ArrayList<String>();
	private Map<String, TaskInfo> taskInfoMap = new LinkedHashMap<String, TaskInfo>();
	private boolean init = false;

	public void init(List<TaskInfo> tasks) {
		for (TaskInfo taskInfo : tasks) {
			taskInfoMap.put(taskInfo.getTaskId(), taskInfo);
			if (taskInfo.isCompleted()) {
				taskIdsCompletedOrCancelled.add(taskInfo.getTaskId());
			} else {
				taskIdsInProgress.add(taskInfo.getTaskId());
			}
		}
	}

	public void init(Map<String, TaskInfo> map) {
		this.taskInfoMap = map;
		for (TaskInfo taskInfo : taskInfoMap.values()) {
			if (taskInfo.isCompleted()) {
				taskIdsCompletedOrCancelled.add(taskInfo.getTaskId());
			} else {
				taskIdsInProgress.add(taskInfo.getTaskId());
			}
			if (init) {
				taskInfo.init();
			}
		}
	}

	public CMSPollerLog getPollerLog() {
		return pollerLog;
	}

	public List<CMSTaskDocument> getTaskDocuments() {
		getTaskTypes();
		return taskDocuments;
	}

	public List<String> getTaskIdsCompletedOrCancelled() {
		return taskIdsCompletedOrCancelled;
	}

	public List<String> getTaskIdsInProgress() {
		return taskIdsInProgress;
	}

	public List<String> getTaskTypes() {
		List<String> taskTypes = new ArrayList<String>();
		for (CMSTaskDocument taskDocument : taskDocuments) {
			taskTypes.add(taskDocument.getTaskType());
		}
		return taskTypes;
	}

	public String getTaskIdsInProgressCommaSeparated() {
		return CommonUtil.toStringSingleQuoted(getTaskIdsInProgress());
	}

	public String getTaskIdsCompletedOrCancelledCommaSeparated() {
		return CommonUtil.toStringSingleQuoted(getTaskIdsCompletedOrCancelled());
	}

	public String getTaskTypesCommaSeparated() {
		return CommonUtil.toStringSingleQuoted(getTaskTypes());
	}

	public void setPollerLog(CMSPollerLog pollerLog) {
		this.pollerLog = pollerLog;
	}

	public Map<String, TaskInfo> getTaskInfoMap() {
		return taskInfoMap;
	}

	public void setTaskDocuments(List<CMSTaskDocument> taskDocuments) {
		this.taskDocuments = taskDocuments;
	}

}
