package org.tiaa.case_management_rs.resource;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;



import org.tiaa.case_management_rs.common.impl.RequestImpl;
import org.tiaa.case_management_rs.service.CaseManagementRestService;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;

@Path("/config")
public class ConfigResource {

	/*	Loggers are pointing to WorkResource class*/
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigResource.class);

	@Autowired
	private CaseManagementRestService caseManagmentRestService;
	
	@GET
	@Produces({ MediaTypes.V2_JSON, MediaTypes.V2_XML })
	public Response getConfigItems(@QueryParam(PROPERTY) String property, @QueryParam(PARAMETER) String parameter, @QueryParam(APP_NAME) String appname, @QueryParam(TABLE_HEADER) String tableheader, 
			 @QueryParam(PARAMETER1) String parameter1, @HeaderParam(USER_REF) String userId, @QueryParam(DEPT) String dept, @QueryParam(REQUESTTYPE) String requestType,
			 @QueryParam(ACTIONSTEP) String actionStep, @QueryParam(IDCODE) Integer idcode, @QueryParam(FIELDNUMBER) Integer fieldnumber) {

		LOGGER.debug("Entering getConfigItems");
		LOGGER.debug("Request Params");
		LOGGER.debug(PROPERTY + SPACE_HYPEN_SAPCE + property);
		LOGGER.debug(PARAMETER + SPACE_HYPEN_SAPCE + parameter);
		LOGGER.debug(FIELDNUMBER + SPACE_HYPEN_SAPCE + fieldnumber);
		LOGGER.debug(IDCODE + SPACE_HYPEN_SAPCE + idcode);
		LOGGER.debug(APP_NAME + SPACE_HYPEN_SAPCE +appname);
		LOGGER.debug(DEPT+ SPACE_HYPEN_SAPCE+dept);
		
		Response response = null;
		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		// Get all the request parameter string values
		request.setAttribute(PROPERTY, property);
		
		if(StringUtils.isNotEmpty(parameter1)){
			request.setAttribute(PARAMETER1, parameter1);
		}
		if(StringUtils.isNotEmpty(userId)){
			request.setAttribute(USER_ID, userId);
		}
		request.setAttribute(PARAMETER, parameter);
		
		request.setAttribute(FIELDNUMBER, fieldnumber);
		request.setAttribute(IDCODE, idcode);
		request.setAttribute(DEPT, dept);
		request.setAttribute(REQUESTTYPE, requestType);
		request.setAttribute(ACTIONSTEP, actionStep);
		request.setAttribute(APP_NAME, appname);
		request.setAttribute(TABLE_HEADER, tableheader);
		response = this.caseManagmentRestService.getConfigItems(request);

		LOGGER.debug("Exiting getConfigItems");

		return response;

	}
	
	@POST
	@Consumes({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	@Produces({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	public Response searchConfigItems(@QueryParam(PROPERTY) String property, @QueryParam(USER_ID) String userId, @QueryParam(APP_NAME) String appName, 
			SearchRequest searchRequest) {

		LOGGER.debug("Entering searchConfigItems");
		org.tiaa.case_management_rs.common.Request request = new RequestImpl();
		

		// Get all the request parameter string values
		request.setAttribute(USER_ID, userId);
		request.setAttribute(APP_NAME, appName);
		if(property != null){
			request.setAttribute(PROPERTY, property.trim());
		}
		request.setAttribute(SEARCH_REQUEST, searchRequest);

		Response response = this.caseManagmentRestService.searchConfigItems(request);
		
		LOGGER.debug("Exiting doSearch");

		return response;
	}
	
}
