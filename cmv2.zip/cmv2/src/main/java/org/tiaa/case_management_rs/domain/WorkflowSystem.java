package org.tiaa.case_management_rs.domain;

public enum WorkflowSystem {
	EXP_AG_ServiceRequest, EXP_AG_CustomerWebForm, CaseManager, EXP_AG_Retry, EXP_AG_PlanModTaskReqest
}
