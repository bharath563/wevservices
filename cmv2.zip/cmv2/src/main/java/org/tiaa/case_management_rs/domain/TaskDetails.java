package org.tiaa.case_management_rs.domain;

import java.io.Serializable;

public class TaskDetails implements Serializable {
	private static final long serialVersionUID = -5731430478133967829L;
	private Identifiers identifiers = new Identifiers();
	private TaskInfo taskInfo;

	public TaskDetails() {
		super();
	}

	public TaskDetails(TaskInfo taskInfo) {
		super();
		setTaskInfoInternal(taskInfo);
	}

	public Identifiers getIdentifiers() {
		return identifiers;
	}

	public TaskInfo getTaskInfo() {
		return taskInfo;
	}

	public void setTaskInfo(TaskInfo taskInfo) {
		setTaskInfoInternal(taskInfo);
	}

	private void setTaskInfoInternal(TaskInfo value) {
		this.taskInfo = value;
		this.identifiers.setIdentifiers(value.getIdentifiers());
	}

	@Override
	public String toString() {
		return String.format("TaskDetails [identifiers=%s, taskInfo=%s]", identifiers, taskInfo);
	}
}
