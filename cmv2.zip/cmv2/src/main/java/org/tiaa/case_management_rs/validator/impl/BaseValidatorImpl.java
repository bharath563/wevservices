package org.tiaa.case_management_rs.validator.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.case_management_rs.exception.CaseManagementRuntimeException;
import org.tiaa.case_management_rs.utils.ExceptionUtil;
import org.tiaa.case_management_rs.validator.BaseValidator;
import org.tiaa.esb.case_management_rs_v2.type.ESBMessage;

public abstract class BaseValidatorImpl implements BaseValidator {

	private static final Logger LOGGER = LoggerFactory.getLogger(BaseValidatorImpl.class);

	public abstract void doValidate(Request request);

	public void validateRequest(Request request) {
		if (request == null) {
			LOGGER.error("Request object is null");
			ESBMessage esbMessage = ExceptionUtil.getESBMessage(ERROR_GENERAL_EXCEPTION);
			throw new CaseManagementRuntimeException(esbMessage.getText(), esbMessage);
		}
	}

	@Override
	public void validate(Request request) {
		validateRequest(request);
		doValidate(request);

	}

	protected void handleException(String message) {
		ESBMessage esbMessage = new ESBMessage();
		esbMessage = ExceptionUtil.getESBMessage(message);
		throw new CaseManagementRuntimeException(esbMessage.getText(), esbMessage);
	}

}
