package org.tiaa.case_management_rs.integration.cth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.xml.transform.StringResult;

import org.tiaa.esb.partyrequest.types.CreateRequests;
import org.tiaa.esb.partyrequest.types.CreateRequestsResponse;
import org.tiaa.esb.partyrequest.types.RetrieveRequests;
import org.tiaa.esb.partyrequest.types.RetrieveRequestsResponse;
import org.tiaa.esb.partyrequest.types.UpdateRequests;
import org.tiaa.esb.partyrequest.types.UpdateRequestsResponse;

public class CTHWebServiceLogger extends CTHWebService {
	private static final Logger LOG = LoggerFactory.getLogger(CTHWebServiceLogger.class);
	private Jaxb2Marshaller cthJaxb2WorkflowMarshaller;

	public CTHWebServiceLogger() {
		super();
	}

	public CTHWebServiceLogger(Jaxb2Marshaller cthJaxb2WorkflowMarshaller) {
		super();
		this.cthJaxb2WorkflowMarshaller = cthJaxb2WorkflowMarshaller;
	}

	@Override
	public CreateRequestsResponse createCTHEntry(CreateCTHContext context, CreateRequests createRequests) {
		StringResult result = new StringResult();
		cthJaxb2WorkflowMarshaller.marshal(createRequests, result);
		debugResponse(result);
		return null;
	}

	@Override
	public UpdateRequestsResponse updateCTHEntry(CreateCTHContext context, UpdateRequests updateRequests) {
		StringResult result = new StringResult();
		cthJaxb2WorkflowMarshaller.marshal(updateRequests, result);
		debugResponse(result);
		return null;
	}

	@Override
	public UpdateRequestsResponse updateCTHEntry(UpdateCTHContext context, UpdateRequests updateRequests) {
		StringResult result = new StringResult();
		cthJaxb2WorkflowMarshaller.marshal(updateRequests, result);
		debugResponse(result);
		return null;
	}

	@Override
	public RetrieveRequestsResponse retrieveRequests(RetrieveRequests retrieveRequests, String user, String taskId) {
		LOG.debug("retrieveRequests:%s", retrieveRequests);
		StringResult result = new StringResult();
		cthJaxb2WorkflowMarshaller.marshal(retrieveRequests, result);
		debugResponse(result);
		RetrieveRequestsResponse retrieveRequestsResponse = super.retrieveRequests(retrieveRequests, user, taskId);
		LOG.debug("retrieveRequestsResponse:%s", retrieveRequestsResponse);
		return retrieveRequestsResponse;
	}

	private void debugResponse(StringResult result) {
		LOG.debug("response:%s", result);
	}

	public void setCthJaxb2WorkflowMarshaller(Jaxb2Marshaller cthJaxb2WorkflowMarshaller) {
		this.cthJaxb2WorkflowMarshaller = cthJaxb2WorkflowMarshaller;
	}

}
