@javax.xml.bind.annotation.XmlSchema(namespace = "http://tiaa-cref.org/FileTransferWebService", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.tiaa.case_management_rs.integration.exp_ag.file_transfer;
