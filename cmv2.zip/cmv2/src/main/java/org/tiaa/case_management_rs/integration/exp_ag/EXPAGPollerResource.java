package org.tiaa.case_management_rs.integration.exp_ag;

import java.util.Arrays;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.repository.CMSAuditHistoryRepository;
import org.tiaa.case_management_rs.resource.MediaTypes;

@Component
@Path("/support/expag")
public class EXPAGPollerResource {
	private static final Logger LOG = LoggerFactory.getLogger(EXPAGPollerResource.class);
	@Autowired
	private EXPAGTasksDAO serviceRequestEXPAGTasksDAO;
	@Autowired
	private EXPAGTasksDAO customerWebFormEXPAGTasksDAO;
	@Autowired
	private CMSAuditHistoryRepository cmsAuditHistoryRepository;
	@Autowired
	private EXPAGTaskProcessorSupport expagTaskProcessorSupport;

	@Path("/tasks/sync")
	@GET
	@Produces({ MediaTypes.V1_XML, MediaTypes.V1_JSON })
	public Response retryTasksSync(@QueryParam("taskType") String taskType, @QueryParam("taskIds") String taskIds) {
		StringBuilder stringBuilder = new StringBuilder();
		try {
			List<String> taskIdList = Arrays.asList(taskIds.split(","));
			EXPAGTasksDAO expagTasksDAO = getExpagTasksDAO(taskType);
			for (TaskInfo taskInfo : expagTasksDAO.getTaskInfo(taskIdList)) {
				try {
					EXPAGTaskProcessor expagTaskProcessor = expagTaskProcessorSupport.getEXPAGTaskProcessor(taskInfo);
					addDocumentsToTasks(taskInfo);
					expagTaskProcessor.processTask(taskInfo);
					stringBuilder.append("Processing Successful for TaskId:").append(taskInfo.getTaskId()).append("\r\n<br/>");
				} catch (Exception e) {
					stringBuilder.append("Processing Failed for TaskId:").append(taskInfo.getTaskId()).append(", Error:").append(e.getMessage()).append("\r\n<br/>");
				}
			}
			return successResponse(stringBuilder.toString());
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
			return errorResponse(e);
		}
	}

	@Path("/tasks/{taskId}/sync")
	@GET
	@Produces({ MediaTypes.V1_XML, MediaTypes.V1_JSON })
	public Response retryTaskSync(@QueryParam("taskType") String taskType, @PathParam("taskId") String taskId) {
		try {
			EXPAGTasksDAO expagTasksDAO = getExpagTasksDAO(taskType);
			TaskInfo taskInfo = expagTasksDAO.getTaskInfo(taskId);
			EXPAGTaskProcessor expagTaskProcessor = expagTaskProcessorSupport.getEXPAGTaskProcessor(taskInfo);
			addDocumentsToTasks(taskInfo);
			expagTaskProcessor.processTask(taskInfo);
			return successResponse("Processing Successful for TaskId:" + taskInfo.getTaskId());
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
			return errorResponse(e);
		}
	}

	@Path("/tasks/{taskId}/sync/auditHistory/{auditHistoryId}")
	@GET
	@Produces({ MediaTypes.V1_XML, MediaTypes.V1_JSON })
	public Response retryTaskSyncForAuditId(@QueryParam("taskType") String taskType, @PathParam("taskId") String taskId, @QueryParam("auditHistoryId") long id) {
		try {
			EXPAGTasksDAO expagTasksDAO = getExpagTasksDAO(taskType);
			TaskInfo taskInfo = expagTasksDAO.getTaskInfo(taskId);
			CMSAuditHistory cmsAuditHistory = cmsAuditHistoryRepository.findOne(id);
			EXPAGTaskProcessor expagTaskProcessor = expagTaskProcessorSupport.getEXPAGTaskProcessor(taskInfo);
			addDocumentsToTasks(taskInfo);
			expagTaskProcessor.processTask(taskInfo, cmsAuditHistory);
			return successResponse("Processing Successful for TaskId:" + taskInfo.getTaskId());
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
			return errorResponse(e);
		}
	}

	private void addDocumentsToTasks(TaskInfo taskInfo) {
		String taskType = taskInfo.getTaskType();
		try {
			EXPAGTasksDAO expagTasksDAO = getExpagTasksDAO(taskType);
			String taskId = taskInfo.getTaskId();
			String taskIdQuoted = String.format("'%s'", taskId);
			for (EXPAGDocument expagDocument : expagTasksDAO.getAllDocumentsForInProgressTasks(taskIdQuoted)) {
				taskInfo.addDocument(expagDocument);
			}
			for (EXPAGDocument expagDocument : expagTasksDAO.getAllDocumentsForCompletedTasks(taskIdQuoted)) {
				taskInfo.addDocument(expagDocument);
			}
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
		}
	}

	private EXPAGTasksDAO getExpagTasksDAO(String taskType) {
		return "ServiceRequest".equals(taskType) ? serviceRequestEXPAGTasksDAO : customerWebFormEXPAGTasksDAO;
	}

	private Response successResponse(String string) {
		return Response.ok(string).type("text/plain").build();
	}

	private Response errorResponse(Exception e) {
		return Response.status(Status.INTERNAL_SERVER_ERROR).entity(e).type("text/plain").build();
	}
}
