package org.tiaa.case_management_rs.icm.helper;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 * @author pamdama
 * 
 *
 */
public class ICMDelegateHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(ICMSearchHelper.class);
	
	private static final String DELIMITER_PIPE ="|";
	
	public static String getAppNameForDepartment(String appName, String department){
		
		String updatedAppName = appName;
		if(appName != null){
			
			if(APP_ICM.equalsIgnoreCase(appName) && DEPARTMENT_PAYOUT_OPERATIONS.equalsIgnoreCase(department)){
				
				updatedAppName = APP_ICM + DELIMITER_PIPE +APP_ACTIVITI;
				
			}
		}
		return updatedAppName;	
	}
	
	
}
