package org.tiaa.case_management_rs.common;

import java.util.concurrent.Callable;

import javax.validation.ValidationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.tiaa.case_management_rs.email.EmailSender;
import org.tiaa.case_management_rs.email.EmailUtil;

@Service
public class ExceptionHandler {
	private static final Logger LOG = LoggerFactory.getLogger(ExceptionHandler.class);
	private static boolean init = false;
	@Autowired
	protected EmailSender emailSender;

	public static void initalize(InitializingBean initializingBean) {
		initalize(initializingBean, init);
	}

	public static void initalize(InitializingBean initializingBean, boolean initalize) {
		if (!initalize) {
			return;
		}
		try {
			initializingBean.afterPropertiesSet();
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			throw new ConfigurationException(e);
		}
	}

	public void run(Runnable runnable) {
		try {
			runnable.run();
		} catch (ValidationException e) {
			LOG.warn(e.getMessage());
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			if (emailSender != null) {
				emailSender.sendEmailToProdSupport("Exception while processing " + e.getMessage(), EmailUtil.createEmail(e));
			} else {
				LOG.warn("emailSender is null");
			}
		}
	}

	public static Runnable createSafeRunnable(final Runnable runnable) {
		return new Runnable() {
			@Override
			public void run() {
				try {
					runnable.run();
				} catch (ValidationException e) {
					LOG.warn(e.getMessage());
				} catch (Exception e) {
					LOG.warn(e.getMessage(), e);
				}
			}
		};
	}
	
	public static void runSafe(final Runnable runnable) {
		try {
			runnable.run();
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
		}
	}

	public static <T> T callSafe(Callable<T> callable) {
		try {
			return callable.call();
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
		}
		return null;
	}

	public void setEmailSender(EmailSender emailSender) {
		this.emailSender = emailSender;
	}
}
