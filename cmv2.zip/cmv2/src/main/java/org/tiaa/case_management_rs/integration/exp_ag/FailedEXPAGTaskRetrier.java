package org.tiaa.case_management_rs.integration.exp_ag;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.domain.CMRSEvent;
import org.tiaa.case_management_rs.domain.CMSAudit;
import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.CMSTaskType;
import org.tiaa.case_management_rs.domain.ProcessingStatus;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.email.plan_modification_request.PlanModificationTaskCreationProcessor;
import org.tiaa.case_management_rs.integration.cth.CTHCreateRecordFailedException;
import org.tiaa.case_management_rs.integration.cth.CTHRecordNotFoundException;
import org.tiaa.case_management_rs.integration.cth.CTHRecordRetriever;
import org.tiaa.case_management_rs.integration.cth.CTHUpdateRecordFailedException;
import org.tiaa.case_management_rs.repository.CMSAuditHistoryRepository;
import org.tiaa.case_management_rs.repository.CMSAuditRepository;
import org.tiaa.case_management_rs.repository.CMSAuditService;
import org.tiaa.case_management_rs.repository.CMSTaskTypeRepository;

@Service
public class FailedEXPAGTaskRetrier {
	private static final Logger log = LoggerFactory.getLogger(FailedEXPAGTaskRetrier.class);
	@Autowired
	private CMSAuditHistoryRepository cmsAuditHistoryRepository;
	@Autowired
	private CMSTaskTypeRepository cmsTaskTypeRepository;
	@Autowired
	private EXPAGTasksDAO retryFailedTasksEXPAGTasksDAO;
	@Autowired
	private CMSAuditService cmsAuditService;
	@Autowired
	private CMSAuditRepository cmsAuditRepository;
	@Autowired
	private CTHRecordRetriever cthRecordRetriever;
	@Autowired
	private EXPAGTaskProcessorSupport expagTaskProcessorSupport;
	@Autowired
	private PlanModificationTaskCreationProcessor planModificationTaskCreationProcessor;

	public void retryFailedEXPAGTask(final CMSAuditHistory cmsAuditHistory) {
		boolean sendingPlanModificationRequestEmailFailed = sendingPlanModificationRequestEmailFailed(cmsAuditHistory);
		boolean createCTHRecordFailed = createCTHRecordFailed(cmsAuditHistory);
		boolean updateCTHRecordFailed = updateCTHRecordFailed(cmsAuditHistory);
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		TaskHistoryEvent taskHistoryEvent = createTaskHistoryEvent(cmsAuditHistory);
		log.debug("taskHistoryEvent: {}", taskHistoryEvent.toString());
		//
		String taskType = cmsAudit.getTaskType();
		log.warn("taskType:{}", taskType);
		CMSTaskType cmsTaskType = cmsTaskTypeRepository.findByTaskType(taskType);
		log.warn("cmsTaskType:{}", cmsTaskType);
		if (cmsTaskType == null) {
			log.warn("cmsTaskType is null, not processing further");
			return;
		}
		String cthRequestSchemaName = cmsTaskType.getCthRequestSchemaName();
		log.warn("cthRequestSchemaName:{}", cthRequestSchemaName);
		if (cthRequestSchemaName == null) {
			log.warn("cthRequestSchemaName is null, not processing further");
			return;
		}
		EXPAGTasksQueryProvider queryProvider = expagTaskProcessorSupport.getEXPAGTasksQueryProvider(cthRequestSchemaName);
		log.debug("queryProvider:{}", queryProvider);
		if (queryProvider == null) {
			log.warn("queryProvider is null, not processing further");
			return;
		}
		TaskInfo taskInfo = retryFailedTasksEXPAGTasksDAO.getTaskInfo(taskHistoryEvent, queryProvider);
		String taskId = taskHistoryEvent.getTaskId();
		if (taskId != null) {
			taskInfo = retryFailedTasksEXPAGTasksDAO.getTaskInfo(taskId, queryProvider);
			cmsAuditHistory.setStartDate(taskInfo.getStartDate());
			cmsAuditHistory.setStartTime(taskInfo.getStartTime());
		}
		if (taskInfo == null) {
			final String taskNotFoundMessage = "taskInfo is null";
			log.debug(taskNotFoundMessage);
			cmsAuditService.markAsFailed(cmsAuditHistory, taskNotFoundMessage);
			return;
		}
		if (sendingPlanModificationRequestEmailFailed) {
			planModificationTaskCreationProcessor.processTask(taskInfo, cmsAuditHistory);
			return;
		}
		addDocumentsToTasks(cmsTaskType, taskInfo);
		if (createCTHRecordFailed) {
			createCTHRecord(cmsAuditHistory, taskInfo);
		} else if(updateCTHRecordFailed) {
			updateCTHRecord(cmsAuditHistory, taskInfo);
		}
	}

	private void addDocumentsToTasks(CMSTaskType cmsTaskType, TaskInfo taskInfo) {
		try {
			EXPAGTasksDAO expagTasksDAO = expagTaskProcessorSupport.getExpagTasksDAO(cmsTaskType);
			String taskId = taskInfo.getTaskId();
			String taskIdQuoted = String.format("'%s'", taskId);
			for (EXPAGDocument expagDocument : expagTasksDAO.getAllDocumentsForInProgressTasks(taskIdQuoted)) {
				taskInfo.addDocument(expagDocument);
			}
			for (EXPAGDocument expagDocument : expagTasksDAO.getAllDocumentsForCompletedTasks(taskIdQuoted)) {
				taskInfo.addDocument(expagDocument);
			}
		} catch (Exception e) {
			log.warn(e.getMessage(), e);
		}
	}

	private void createCTHRecord(CMSAuditHistory cmsAuditHistory, TaskInfo taskInfo) {
		CMSAudit cmsAudit = cmsAuditRepository.findByTaskId(taskInfo.getTaskId());
		if (cmsAudit.getCthRequestId() != null) {
			updateRecordAlreadyExists(cmsAuditHistory);
			updateCTHRecord(cmsAuditHistory, taskInfo);
			return;
		}
		boolean cthRecordExists = false;
		try {
			cthRecordExists = cthRecordRetriever.cthRecordExists(taskInfo);
		} catch (CTHRecordNotFoundException e) {
			log.warn(e.getMessage(), e);
		}
		if (cthRecordExists) {
			updateRecordAlreadyExists(cmsAuditHistory);
			return;
		}
		processCTHRecord(cmsAuditHistory, taskInfo);
	}

	private void updateRecordAlreadyExists(CMSAuditHistory cmsAuditHistory) {
		log.info("record exists in CTH");
		cmsAuditHistory.setStatus(ProcessingStatus.Ignore.name());
		cmsAuditHistory.setLastUpdatedTs(new Date());
		cmsAuditHistoryRepository.save(cmsAuditHistory);
	}

	private void updateCTHRecord(CMSAuditHistory cmsAuditHistory, TaskInfo taskInfo) {
		processCTHRecord(cmsAuditHistory, taskInfo);
	}

	private void processCTHRecord(CMSAuditHistory cmsAuditHistory, TaskInfo taskInfo) {
		String taskType = cmsAuditHistory.getCmsAudit().getTaskType();
		EXPAGTaskProcessor taskProcessor = expagTaskProcessorSupport.getEXPAGTaskProcessor(taskType);
		if (taskProcessor == null) {
			log.warn("task processor is null");
			return;
		}
		taskProcessor.processTask(taskInfo, cmsAuditHistory);
	}

	public static boolean sendingPlanModificationRequestEmailFailed(CMSAuditHistory cmsAuditHistory) {
		return CMRSEvent.SEND_PLAN_MODIFICATION_EMAIL.name().equals(cmsAuditHistory.getEventName());
	}

	public static boolean createCTHRecordFailed(CMSAuditHistory cmsAuditHistory) {
		if (CMRSEvent.CREATE_CTH_RECORD.name().equals(cmsAuditHistory.getEventName())) {
			return true;
		}
		return cmsAuditHistory.hasErrorMessage(AppConstants.CTH_RECORD_NOT_FOUND) || cmsAuditHistory.hasErrorMessage(CTHCreateRecordFailedException.class.getName())
				|| cmsAuditHistory.hasErrorMessage(CTHRecordNotFoundException.class.getName());
	}

	public static boolean updateCTHRecordFailed(CMSAuditHistory cmsAuditHistory) {
		if (CMRSEvent.UPDATE_CTH_RECORD.name().equals(cmsAuditHistory.getEventName())) {
			return true;
		}
		return cmsAuditHistory.hasErrorMessage(AppConstants.CUSTOMER_NUMBER_REQUIRED) || cmsAuditHistory.hasErrorMessage(CTHUpdateRecordFailedException.class.getName())
				|| cmsAuditHistory.hasErrorMessage(CTHRecordNotFoundException.class.getName());
	}

	private TaskHistoryEvent createTaskHistoryEvent(CMSAuditHistory cmsAuditHistory) {
		TaskHistoryEvent taskHistoryEvent = new TaskHistoryEvent();
		taskHistoryEvent.setTaskId(cmsAuditHistory.getTaskId());
		taskHistoryEvent.setStartDate(cmsAuditHistory.getStartDate());
		taskHistoryEvent.setStartTime(cmsAuditHistory.getStartTime());
		return taskHistoryEvent;
	}

	public static boolean isDocumentUploadEvent(CMSAuditHistory cmsAuditHistory) {
		return CMRSEvent.CTH_LASTUPDATEDDRI.name().equals(cmsAuditHistory.getEventName());
	}
}
