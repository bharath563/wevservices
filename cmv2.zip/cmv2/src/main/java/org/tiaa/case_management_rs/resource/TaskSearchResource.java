package org.tiaa.case_management_rs.resource;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import org.tiaa.case_management_rs.common.impl.RequestImpl;
import org.tiaa.case_management_rs.service.CaseManagementRestService;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;

@Repository
@Path("/tasksearch")
public class TaskSearchResource {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(TaskSearchResource.class);

	@Autowired
	private CaseManagementRestService caseManagmentRestService;

	@POST
	@Consumes({ MediaTypes.V2_XML, MediaTypes.V2_JSON })
	@Produces({ MediaTypes.V2_XML, MediaTypes.V2_JSON })
	public Response doSearch(@Context HttpHeaders headers,
			 @HeaderParam(USER_REF) String userId, SearchRequest searchRequest) {

		LOGGER.debug("Entering doSearch");
		LOGGER.debug("Request Params");
		LOGGER.debug(USER_ID + SPACE_HYPEN_SAPCE + userId);
		String consumerId = null;

		org.tiaa.case_management_rs.common.Request request = new RequestImpl();
		if (headers.getRequestHeaders() != null
				&& headers.getRequestHeaders().containsKey(TIAA_CONSUMER)) {
			consumerId = headers.getRequestHeaders() == null ? "" : headers
					.getRequestHeader(TIAA_CONSUMER).get(0);
		}

		// Get all the request parameter string values
		request.setAttribute(USER_ID, userId);
		request.setAttribute(TIAA_CONSUMER, consumerId);
		request.setAttribute(SEARCH_REQUEST, searchRequest);
		Response response = this.caseManagmentRestService.doTaskSearch(request);

		LOGGER.debug("Exiting doSearch");

		return response;

	}
}
