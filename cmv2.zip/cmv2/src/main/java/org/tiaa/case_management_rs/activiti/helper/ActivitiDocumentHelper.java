package org.tiaa.case_management_rs.activiti.helper;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBException;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.dao.EXPAGDAO;
import org.tiaa.case_management_rs.exception.CaseManagementRuntimeException;
import org.tiaa.case_management_rs.integration.activiti.ActivitiRepository;
import org.tiaa.case_management_rs.integration.activiti.ActivitiRepositoryImpl;
import org.tiaa.case_management_rs.integration.exp_ag.file_transfer.WebDAVClient;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.PowerImageService;
import org.tiaa.case_management_rs.integration.federeated_document.FederatedDocumentRSService;
import org.tiaa.case_management_rs.model.AddDocumentExVO;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.case_management_rs.utils.GuidUtility;
import org.tiaa.esb.case_management_rs_v2.type.Document;
import org.tiaa.esb.case_management_rs_v2.type.DocumentRequest;
import org.tiaa.esb.case_management_rs_v2.type.DocumentResponse;
import org.tiaa.esb.case_management_rs_v2.type.Paragraphs;
import org.tiaa.esb.case_management_rs_v2.type.Routing;

import org.tiaa.atom.core.support.rest.RestServiceESBSupport;

@Service
public class ActivitiDocumentHelper {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(ActivitiDocumentHelper.class);

	@Autowired
	private RestServiceESBSupport restServiceESBSupport;

	@Autowired
	private ActivitiRepositoryImpl activitiRepositoryImpl;

	@Autowired
	private FederatedDocumentRSService federatedDocumentRSService;

	@Autowired
	private ActivitiRepository activitiRepository;
	
	@Value("${expag.document.uploadpath}")
	private String expagFileUploadPath;
	
	@Value("${expag.document.upload.url}")
	private String expagFileUploadUrl;
	
	@Autowired
	private PowerImageService powerImageService;
	
	@Autowired
	private EXPAGDAO expagDAO;

	@Autowired
	private WebDAVClient webDAVClient;
	
	@Value("${expag.webdav.url.docs}")
	private String webDAVDocsUrl;
	
	@Value("${expag.webdav.url.predocs}")
	private String webDAVPredocsUrl;
	
	public boolean createDocumentInActiviti(String userId, String taskId,
			String caseId, Document cmsDocument, String convertedExpag) {
		org.tiaa.esb.case_management_rs_v2.type.Document activitiDocument = new org.tiaa.esb.case_management_rs_v2.type.Document();
		DocumentResponse response = null;
		boolean uploadStatus = false;
		
		// Get the document content
		byte[] documentContent = cmsDocument.getDocContent();
		String documentName = cmsDocument.getDocName();
		
		if (Routing.NOTE.toString().equalsIgnoreCase(cmsDocument.getDocDirection())) {
			
			uploadStatus = createNotesInActiviti(documentContent, cmsDocument, taskId, userId, convertedExpag);
			
		} else{
			
						
			String uploadfileName = this.expagFileUploadPath + BACKWARD_SLASH + documentName;
			RandomAccessFile fi = null;
			
			if(null == convertedExpag){

				try {
						fi = new RandomAccessFile(new File(uploadfileName), READ_WRITE_MODE);
						fi.write(documentContent);
						fi.close();
				} catch (IOException ioexception) {
						LOGGER.error(ioexception.getMessage());
						throw new CaseManagementRuntimeException("Error occured while dropping the file in the file path : " + uploadfileName);
				}finally{
					if(null != fi){
						try {
							fi.close();
						} catch (IOException e) {
							LOGGER.warn("Error in closing the file." + e.getMessage());
						}
					}
					
				}
			}
			
			if(EXPAG_PIDOCTYPE_CORRESPONDENCE.equalsIgnoreCase(cmsDocument.getDocTyp())){
				
				//TBD: Remove EXPAG Upload process once Activiti edit document is supported.
				if(null == convertedExpag){
					processCorrespondence(cmsDocument, userId, taskId, caseId, documentName, uploadfileName );
				}
				
				String expagDocURL = this.expagFileUploadUrl + BACKWARD_SLASH + documentName;
				uploadStatus = createCorrespondenceInActiviti(expagDocURL, taskId, userId, cmsDocument, convertedExpag);
				
			}
			else{
								
				String dri = uploadToFDRI(cmsDocument);
				
				DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
				Date dateobj = new Date();
				String date = df.format(dateobj);
				XMLGregorianCalendar result = null;
				GregorianCalendar gregorianCalendar = (GregorianCalendar) GregorianCalendar
						.getInstance();
				gregorianCalendar.setTime(dateobj);
				
				try {
					result = DatatypeFactory.newInstance().newXMLGregorianCalendar(
							gregorianCalendar);
				} catch (DatatypeConfigurationException e) {
					LOGGER.warn("DatatypeConfigurationException in converting XMLFregorian Calendar " + e.getMessage());
				}

				activitiDocument.setDocBizUnit(FederatedDocumentRSService.BIZ_UNIT);
				activitiDocument.setDocID(dri);
				activitiDocument.setDocVrsn(FederatedDocumentRSService.DOC_VERSION);
				activitiDocument.setDocIDTyp("DRI");
				activitiDocument.setDocTyp(FederatedDocumentRSService.DOC_CODE);
				activitiDocument.setDocName(cmsDocument.getDocName());
				activitiDocument.setMimeTyp(cmsDocument.getMimeTyp());
				activitiDocument.setFrmtTyp(cmsDocument.getMimeTyp());
				activitiDocument.setDocDesc("first update");
				activitiDocument.setDocSts("final");
				activitiDocument.setDocCreateDateTime(result);
				activitiDocument.setDocTitle(cmsDocument.getDocTitle());
				activitiDocument.setDocDirection(cmsDocument.getDocDirection());
				activitiDocument.setDocCategory(cmsDocument.getDocCategory());
				activitiDocument.setDocStorgSyst("MOBIUS");
				activitiDocument.setDocTemplateCd(cmsDocument.getDocTemplateCd());
				
				ObjectMapper objMapper = new ObjectMapper();
				DocumentRequest documentRequest = new DocumentRequest();
				documentRequest.setDocument(activitiDocument);
				try {
					LOGGER.info("Document object as String - "+objMapper.writeValueAsString(documentRequest));
				} catch (JsonProcessingException e) {
					LOGGER.error("Error in converting Document object as String - " + e.getMessage());
				}
				response = this.activitiRepository.addActivitiDocument(
						documentRequest, taskId, userId, convertedExpag);
				if (response.getResponseStatus() != null) {
					uploadStatus = true;
				}
			}
		}
		return uploadStatus;

	}

	private void processCorrespondence(Document cmsDocument, String userId, String taskId, String caseId, String documentName, String uploadfileName) {
		
		AddDocumentExVO expagDocument = new AddDocumentExVO();	
		

		String guid = new GuidUtility().toString();
		expagDocument.setPiDocType(EXPAG_PIDOCTYPE_CORRESPONDENCE);
		expagDocument.setContType(EXPAG_CONT_TYPE_CORRESPONDENCE);
		expagDocument.setUserId(userId);
		
		expagDocument.setPacketId(cmsDocument.getProcessID().getRqstID());
		
		expagDocument.setStorage(EXPAG_STORAGE_INTERNAL);
		expagDocument.setWrkStationId(EXPAG_WORKSTATION_TIAAPI);

		// Set mail description values
		expagDocument.setMailDesc(EXPAG_MAIL_DESC_REGULAR);
		expagDocument.setMailId(EXPAG_MAIL_ID_CMSUD + SPACE_COLON_SAPCE + guid);

		expagDocument.setPageTotal(1);
		expagDocument.setStartPage(1);
		expagDocument.setEndPage(1);

		if (StringUtils.isNotBlank(caseId)) {
			expagDocument.setTaskOnlyFlag(false);
		} else {
			expagDocument.setTaskOnlyFlag(true);
			expagDocument.setTaskId(taskId);
		}
		
		String expagDocURL = this.expagFileUploadUrl + BACKWARD_SLASH + documentName;
		expagDocument.setUrlDocPath(expagDocURL);

		LOGGER.debug(uploadfileName + " - Document successfully uploaded in the file share");
		LOGGER.debug(expagDocURL + " - Document ready fo EXPAG upload");


		boolean uploadPIStatus = this.powerImageService.addDocumentEx(expagDocument);

		LOGGER.debug(documentName + " - Document uploaded in EXPAG: " + uploadPIStatus);
	
		/** Code for Correspondence Document details **/

		if (uploadPIStatus 
				&& EXPAG_PIDOCTYPE_CORRESPONDENCE.equalsIgnoreCase(cmsDocument.getDocTyp())) {
				String corroDocId = expagDAO.getExpagCorrDocId(taskId, guid);
				if(corroDocId != null){
					moveFileOnExpag(corroDocId);
					insertIntoExpagCorrTables(userId, taskId, cmsDocument, corroDocId);
					
				}
			}

	}

	private String uploadToFDRI(Document cmsDocument) {
		Map<String, String> documentDataMap = new HashMap<String, String>();
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_MIME_TYPE, cmsDocument.getMimeTyp());
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_DOCUMENT_TITLE, cmsDocument.getDocName());
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_FILE_NAME, cmsDocument.getDocName());
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_DOCUMENT_DESCRIPTION, cmsDocument.getDocTitle());
		//documentDataMap.put(FederatedDocumentRSService.UPLOAD_CLIENT_ID, cmsDocument.getClientId());
		//documentDataMap.put(FederatedDocumentRSService.UPLOAD_PIN, cmsDocument.getPin());
		//documentDataMap.put(FederatedDocumentRSService.UPLOAD_ORCH_ID, cmsDocument.getOrchId());

		documentDataMap.put("Business_Date", DateUtil.today());
		return federatedDocumentRSService.archiveDocumentInMobius(documentDataMap, new ByteArrayResource(cmsDocument.getDocContent()));
	}

	public Document getDocument(Request request) throws JAXBException {
		String docOrigin = (String) request.getAttribute(DOC_ORIGIN);
		String processId = (String) request.getAttribute(PROCESS_ID);
		String userId = (String) request.getAttribute(USER_ID);
		String documentId = (String) request.getAttribute(DOCUMENT_ID);
		String convertedExpag = (String) request.getAttribute(CONVERTED_EXPAG_TASK);
		if( docOrigin != null && docOrigin.equalsIgnoreCase(EXPAG_STORAGE_INTERNAL)){
			DocumentResponse documentResponse = this.activitiRepository.getActivitiDocument(processId, userId, documentId, convertedExpag);
			Document document = documentResponse.getDocument();
			Document rsv2DocResp = new Document();
			Map<String, Object> docInfoFromDB = this.expagDAO.getDocInfo(documentId);
			String folder = "d" + docInfoFromDB.get("CREATEDATE");
			
			byte[] docContent = null;
				docContent = webDAVClient.getDocContent(folder, documentId);
				document.setDocContent(docContent);
				rsv2DocResp.setDocContent(docContent);
				rsv2DocResp.setDocName(document.getDocID());
				rsv2DocResp.setDocTemplateCd(BASE64BINARY);
				rsv2DocResp.setMimeTyp(document.getMimeTyp());
				return rsv2DocResp;

		} else if(docOrigin != null && docOrigin.equalsIgnoreCase(APP_ACTIVITI)){
			DocumentResponse documentResponse = this.activitiRepository.getActivitiDocument(processId, userId, documentId, convertedExpag);
			Document document = documentResponse.getDocument();
			Document rsv2DocResp = new Document();
			rsv2DocResp.setDocContent(document.getDocContent());
			rsv2DocResp.setDocName(document.getDocID());
			rsv2DocResp.setDocTemplateCd(document.getDocTemplateCd());
			rsv2DocResp.setMimeTyp(document.getMimeTyp());
			return rsv2DocResp;
		}
		DocumentResponse documentResponse = this.activitiRepository.getActivitiDocument(processId, userId, documentId, convertedExpag);
		Document document = documentResponse.getDocument();
		Map<String, String> docSearchKey = new HashMap<String, String>();
		String bizUnit = document.getDocBizUnit();
		String docCode = document.getDocTyp();
		String ver = String.valueOf(document.getDocVrsn());
		String idType = document.getDocIDTyp();
		String mimeType = document.getMimeTyp();
		String docId = (String) request
				.getAttribute(CaseManagementConstants.DOCUMENT_ID);
		docSearchKey.put("business-unit-code", bizUnit);
		docSearchKey.put("doc-code", docCode);
		docSearchKey.put("version", ver);
		docSearchKey.put("id-type", idType);
		docSearchKey.put(CaseManagementConstants.MIME_TYPE, mimeType);

		Document rsv2DocResp = new Document();
		rsv2DocResp =  this.federatedDocumentRSService.getDocumentFromMobius(
				docSearchKey, docId);
		rsv2DocResp.setDocTemplateCd(document.getDocTemplateCd());
		rsv2DocResp.setDocName(document.getDocID());
		return rsv2DocResp;
	}
	
	
	/**
	 * This method creates an ActivitiDocument to be sent to Activiti for storing the document metadata
	 * @param documentDataMap
	 * @return
	 */
	public org.tiaa.esb.case_management_rs_v2.type.Document createActivitiDocument(Map<String, String> documentDataMap){
		
		org.tiaa.esb.case_management_rs_v2.type.Document activitiDocument = new org.tiaa.esb.case_management_rs_v2.type.Document();
		
		DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Date dateobj = new Date();
		XMLGregorianCalendar result = null;
		GregorianCalendar gregorianCalendar = (GregorianCalendar) GregorianCalendar.getInstance();
		gregorianCalendar.setTime(dateobj);
		try {
			
			result = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
			
		} catch (DatatypeConfigurationException e) {
			
			LOGGER.warn("Error converting to GregorianCalendar ");
		}

		activitiDocument.setDocBizUnit(FederatedDocumentRSService.BIZ_UNIT);
		activitiDocument.setDocID(documentDataMap.get(FederatedDocumentRSService.UPLOAD_DRI));
		activitiDocument.setDocVrsn(FederatedDocumentRSService.DOC_VERSION);
		activitiDocument.setDocIDTyp("DRI");
		activitiDocument.setDocTyp(FederatedDocumentRSService.DOC_CODE);
		activitiDocument.setDocName(documentDataMap.get(FederatedDocumentRSService.UPLOAD_FILE_NAME));
		activitiDocument.setMimeTyp(documentDataMap.get(FederatedDocumentRSService.UPLOAD_MIME_TYPE));
		activitiDocument.setFrmtTyp(documentDataMap.get(FederatedDocumentRSService.UPLOAD_MIME_TYPE));
		activitiDocument.setDocTitle(documentDataMap.get(FederatedDocumentRSService.UPLOAD_DOCUMENT_DESCRIPTION));
		activitiDocument.setDocDirection(documentDataMap.get(FederatedDocumentRSService.DOC_DIRECTION));
		activitiDocument.setDocCategory(documentDataMap.get(FederatedDocumentRSService.DOC_CATEGORY));
		activitiDocument.setDocDesc("first update");
		activitiDocument.setDocSts("final");
		activitiDocument.setDocCreateDateTime(result);
		activitiDocument.setDocTitle(documentDataMap.get(FederatedDocumentRSService.UPLOAD_DOCUMENT_DESCRIPTION));
		activitiDocument.setDocDirection(documentDataMap.get(FederatedDocumentRSService.DOC_DIRECTION));
		activitiDocument.setDocCategory(documentDataMap.get(FederatedDocumentRSService.DOC_CATEGORY));
		activitiDocument.setDocURL(documentDataMap.get("MOBIUS_URI"));
		return activitiDocument;
	}

	private boolean createCorrespondenceInActiviti(String expagDocURL, String taskId,
			String userId, Document cmsDocument, String convertedExpag) {

		org.tiaa.esb.case_management_rs_v2.type.Document activitiDocument = new org.tiaa.esb.case_management_rs_v2.type.Document();
		DocumentResponse response = null;
		
		boolean uploadStatus = false;
		DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Date dateobj = new Date();
		String date = df.format(dateobj);
		XMLGregorianCalendar result = null;
		GregorianCalendar gregorianCalendar = (GregorianCalendar) GregorianCalendar
				.getInstance();
		gregorianCalendar.setTime(dateobj);
		try {
			result = DatatypeFactory.newInstance().newXMLGregorianCalendar(
					gregorianCalendar);
		} catch (DatatypeConfigurationException e) {
			
			LOGGER.warn("Error converting to GregorianCalendar for Correspondence - " + e.getMessage());
		}

		activitiDocument.setDocName(cmsDocument.getDocName());
		activitiDocument.setDocTyp(EXPAG_PIDOCTYPE_CORRESPONDENCE);
		activitiDocument.setProcessID(cmsDocument.getProcessID());
		
		activitiDocument.setSalutation(cmsDocument.getSalutation());
		
		activitiDocument.setDocumentsDeliveries(cmsDocument.getDocumentsDeliveries());
		activitiDocument.setParagraphs(cmsDocument.getParagraphs());
		
		activitiDocument.setDocURL(expagDocURL);
		
		activitiDocument.setDocDirection(cmsDocument.getDocDirection());
		activitiDocument.setDocXtnsn(cmsDocument.getDocXtnsn());
		
		activitiDocument.setDocStorgSyst(EXPAG_STORAGE_INTERNAL);
		
		//TBD - Check Document Content Type - Used Desc
		activitiDocument.setDocDesc(EXPAG_CONT_TYPE_CORRESPONDENCE);
		
		//TBD - Check for File Type
		
		activitiDocument.setMimeTyp(cmsDocument.getMimeTyp());
		activitiDocument.setDocTemplateCd(cmsDocument.getDocTemplateCd());
		
		activitiDocument.setDocCreateDateTime(result);
		activitiDocument.setDocTitle(cmsDocument.getDocTitle());
		
		activitiDocument.setDocCategory(cmsDocument.getDocCategory());
		activitiDocument.setDocStorgSyst(EXPAG_STORAGE_INTERNAL);

		
		ObjectMapper objMapper = new ObjectMapper();
		DocumentRequest documentRequest = new DocumentRequest();
		documentRequest.setDocument(activitiDocument);
		
		try {
			
			LOGGER.info("Document object as String "+ objMapper.writeValueAsString(documentRequest));
			
		} catch (JsonProcessingException e) {
			
			LOGGER.error("Error in creating Correspondence in Activiti - " + e.getMessage());
		}
		
		response = this.activitiRepository.addActivitiDocument(
				documentRequest, taskId, userId, convertedExpag);
		
		
		if (response.getResponseStatus() != null) {
			uploadStatus = true;
		}
		
		return uploadStatus;

	
		
	}

	private boolean createNotesInActiviti(byte[] documentContent, Document cmsDocument, String taskId, String userId, String convertedExpag) {

		org.tiaa.esb.case_management_rs_v2.type.Document activitiDocument = new org.tiaa.esb.case_management_rs_v2.type.Document();
		DocumentResponse response = null;
		
		boolean uploadStatus = false;
		DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Date dateobj = new Date();
		String date = df.format(dateobj);
		XMLGregorianCalendar result = null;
		GregorianCalendar gregorianCalendar = (GregorianCalendar) GregorianCalendar
				.getInstance();
		gregorianCalendar.setTime(dateobj);
		try {
			result = DatatypeFactory.newInstance().newXMLGregorianCalendar(
					gregorianCalendar);
		} catch (DatatypeConfigurationException e) {
			LOGGER.warn("Error in converting date");
		}

		activitiDocument.setDocName(cmsDocument.getDocName());
		activitiDocument.setDocTyp(cmsDocument.getDocTyp());
		//BASE64BINARY
		activitiDocument.setDocTemplateCd(cmsDocument.getDocTemplateCd());
		//TBD: Check Doc EXTn
		activitiDocument.setDocXtnsn(cmsDocument.getDocXtnsn());
		activitiDocument.setDocDirection(NOTE);
		
		activitiDocument.setProcessID(cmsDocument.getProcessID());
		
		
		activitiDocument.setMimeTyp(cmsDocument.getMimeTyp());

		activitiDocument.setDocCreateDateTime(result);
		activitiDocument.setDocContent(documentContent);
		activitiDocument.setDocStorgSyst(APP_ACTIVITI);
		
		ObjectMapper objMapper = new ObjectMapper();
		DocumentRequest documentRequest = new DocumentRequest();
		documentRequest.setDocument(activitiDocument);
		try {
			
			LOGGER.info("Document object as String " + objMapper.writeValueAsString(documentRequest));
			
		} catch (JsonProcessingException e) {
			LOGGER.error("Error in creating notes in Activiti - " + e.getMessage());
		}
		response = this.activitiRepository.addActivitiDocument(
				documentRequest, taskId, userId, convertedExpag);
		
		if (response.getResponseStatus() != null) {
			uploadStatus = true;
		}
		
		return uploadStatus;

	}

	
	private void insertIntoExpagCorrTables(String userId, String taskId,
			Document cmsDocument, String corroDocId) {
		if (cmsDocument.getDocumentsDeliveries() != null
				&& cmsDocument.getDocumentsDeliveries().getDocDlvries() != null
				&& cmsDocument.getDocumentsDeliveries().getDocDlvries().get(0) != null
				&& cmsDocument.getDocumentsDeliveries().getDocDlvries().get(0).getContact() != null
				&& cmsDocument.getDocumentsDeliveries().getDocDlvries().get(0).getContact().getAddr() != null) {

				String corroId = null;
				try {
					corroId = expagDAO.getNextCorroId();
				} catch (Exception e) {
					LOGGER.error("Exception while getNextCorroId:" + e.getMessage());
				}
	
				if (StringUtils.isEmpty(corroId)) {
					LOGGER.error("CORROID is null, cannot insert into CORRO and CORROPARA tables");
				} else {
					String currentDate = DateUtil.DATE_FORMAT_YYYYMMDD.format(new Date());
					String currentTime = DateUtil.DATE_FORMAT_HHmmss.format(new Date());
									
					expagDAO.insertExpagCorro(userId, taskId, cmsDocument, corroId.trim(),
							corroDocId, currentDate, currentTime);
	
					Paragraphs paragraphs = cmsDocument.getParagraphs();
					if (paragraphs != null && paragraphs.getParas() != null) {
						for (org.tiaa.esb.case_management_rs_v2.type.Paragraph para : paragraphs
								.getParas()) {
							expagDAO.insertExpagCorroPara(corroId.trim(),
									para.getParaID(), "" + para.getParaSeqNum());
						}
					}
				}
		}
	}

	private void moveFileOnExpag(String corroDocId) {
	
		String docCreatedDate = DateUtil.today().substring(2);
		String fromDirectory = webDAVDocsUrl + BACKWARD_SLASH + "d" + docCreatedDate;
		String toDirectory = webDAVPredocsUrl + BACKWARD_SLASH + "d" + docCreatedDate;

		try {
			webDAVClient.moveFile(fromDirectory, toDirectory, corroDocId);
		} catch (Exception e) {
			LOGGER.error("Exception while moving file fromDirectory "+fromDirectory 
					+", toDirectory:"+toDirectory +", corroDocId:"+ corroDocId+ ": " + e.getMessage());
		}
	}

	public void appendNote(String taskId, String userId, String docId, Document cmsDocument, String convertedExpag) {
		
		byte[] appendedNoteContent = cmsDocument.getDocContent();
		
		if (appendedNoteContent.length > 0) {
				
				org.tiaa.esb.case_management_rs_v2.type.Document activitiDocument = new org.tiaa.esb.case_management_rs_v2.type.Document();
				
				DocumentResponse response = null;
				
				DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
				Date dateobj = new Date();
				String date = df.format(dateobj);
				XMLGregorianCalendar result = null;
				GregorianCalendar gregorianCalendar = (GregorianCalendar) GregorianCalendar
						.getInstance();
				gregorianCalendar.setTime(dateobj);
				try {
					result = DatatypeFactory.newInstance().newXMLGregorianCalendar(
							gregorianCalendar);
				} catch (DatatypeConfigurationException e) {
					LOGGER.warn("Error in converting date");
				}

				activitiDocument.setDocName(cmsDocument.getDocName());
				activitiDocument.setDocTyp(cmsDocument.getDocTyp());
				//BASE64BINARY
				activitiDocument.setDocTemplateCd(cmsDocument.getDocTemplateCd());
				//TBD: Check Doc EXTn
				activitiDocument.setDocXtnsn(cmsDocument.getDocXtnsn());
				activitiDocument.setDocDirection(NOTE);
				
				activitiDocument.setProcessID(cmsDocument.getProcessID());
				
				
				activitiDocument.setMimeTyp(cmsDocument.getMimeTyp());

				activitiDocument.setDocCreateDateTime(result);
				activitiDocument.setDocContent(appendedNoteContent);
				
				ObjectMapper objMapper = new ObjectMapper();
				DocumentRequest documentRequest = new DocumentRequest();
				documentRequest.setDocument(activitiDocument);
				
				try {
					
					LOGGER.info("Document object as String " + objMapper.writeValueAsString(documentRequest));
					
				} catch (JsonProcessingException e) {
					LOGGER.error("Error in creating notes in Activiti - " + e.getMessage());
				}

				response = this.activitiRepository.updateActivitiDocument(documentRequest, taskId, userId, convertedExpag);
			}
	}

	public void updateDocumentInExpag(String docId, Document cmsDocument) throws Exception {
		String docPath = "d" + DateUtil.getStringDatefromXMLGregorianDate(cmsDocument.getDocCreateDateTime());
		webDAVClient.updateFile(webDAVPredocsUrl + BACKWARD_SLASH + docPath, docId, cmsDocument.getDocContent());		
	}
	
	public boolean createNonUWDocument(String userId, String taskId,
			String caseId, Document cmsDocument, String convertedExpag) {

		org.tiaa.esb.case_management_rs_v2.type.Document activitiDocument = new org.tiaa.esb.case_management_rs_v2.type.Document();
		DocumentResponse response = null;
		boolean uploadStatus = false;

		String dri = uploadToFDRI(cmsDocument);
		
		DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		Date dateobj = new Date();
		String date = df.format(dateobj);
		XMLGregorianCalendar result = null;
		GregorianCalendar gregorianCalendar = (GregorianCalendar) GregorianCalendar
				.getInstance();
		gregorianCalendar.setTime(dateobj);
		
		try {
			result = DatatypeFactory.newInstance().newXMLGregorianCalendar(
					gregorianCalendar);
		} catch (DatatypeConfigurationException e) {
			LOGGER.warn("DatatypeConfigurationException in converting XMLFregorian Calendar " + e.getMessage());
		}

		activitiDocument.setDocBizUnit(FederatedDocumentRSService.BIZ_UNIT);
		activitiDocument.setDocID(dri);
		activitiDocument.setDocVrsn(FederatedDocumentRSService.DOC_VERSION);
		activitiDocument.setDocIDTyp("DRI");
		activitiDocument.setDocTyp(FederatedDocumentRSService.DOC_CODE);
		activitiDocument.setDocName(cmsDocument.getDocName());
		activitiDocument.setMimeTyp(cmsDocument.getMimeTyp());
		activitiDocument.setFrmtTyp(cmsDocument.getMimeTyp());
		activitiDocument.setDocDesc("first update");
		activitiDocument.setDocSts("final");
		activitiDocument.setDocCreateDateTime(result);
		activitiDocument.setDocTitle(cmsDocument.getDocTitle());
		activitiDocument.setDocDirection(cmsDocument.getDocDirection());
		activitiDocument.setDocCategory(cmsDocument.getDocCategory());
		
		ObjectMapper objMapper = new ObjectMapper();
		DocumentRequest documentRequest = new DocumentRequest();
		documentRequest.setDocument(activitiDocument);
		
		try {
			LOGGER.info("Document object as String - "+objMapper.writeValueAsString(documentRequest));
		} catch (JsonProcessingException e) {
			LOGGER.error("Error in converting Document object as String - " + e.getMessage());
		}
		response = this.activitiRepository.addActivitiDocument(
				documentRequest, taskId, userId, convertedExpag);
		if (response.getResponseStatus() != null) {
			uploadStatus = true;
		}

		return uploadStatus;

			
	}
}
