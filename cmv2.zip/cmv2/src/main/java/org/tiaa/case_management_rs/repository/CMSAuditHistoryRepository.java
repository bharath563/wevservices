package org.tiaa.case_management_rs.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.tiaa.case_management_rs.domain.CMSAuditHistory;

public interface CMSAuditHistoryRepository extends JpaRepository<CMSAuditHistory, Long> {
	List<CMSAuditHistory> findByStatus(String status);
}
