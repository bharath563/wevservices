package org.tiaa.case_management_rs.integration.case_manager;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.tiaa.case_management_rs.integration.case_manager.domain.Case;
import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;

public class CaseMapper extends AbstractRowMapper<Case> {
	protected Case mapCase(ResultSet resultSet) throws SQLException {
		Case kase = mapCaseInfo(resultSet);
		kase.setRequestId(getStringTrimmed(resultSet, "request_id"));
		kase.setChannel(getStringTrimmed(resultSet, "channel_name"));
		kase.setRequestSubmittedTS(resultSet.getTimestamp("req_submitted_Ts"));
		return kase;
	}

	protected Case mapCaseInfo(ResultSet resultSet) throws SQLException {
		Case kase = new Case();
		kase.setCaseId(getStringTrimmed(resultSet, "case_id"));
		kase.setCaseIdentifier(getStringTrimmed(resultSet, "case_identifier"));
		kase.setCaseType(getStringTrimmed(resultSet, "case_type_name"));
		kase.setOrchId(getStringTrimmed(resultSet, "orch_id"));
		kase.setCthId(getStringTrimmed(resultSet, "cth_id"));
		kase.setCaseStartedTS(resultSet.getTimestamp("case_started_ts"));
		kase.setCaseCompletedTS(resultSet.getTimestamp("case_completed_ts"));
		kase.setCaseDueDateTS(resultSet.getTimestamp("case_due_date_ts"));
		kase.setAdditionalReqType(getStringTrimmed(resultSet, "addtl_req_type_name"));
		return kase;
	}

	@Override
	public Case mapRow(ResultSet resultSet, int rowNum) throws SQLException {
		return mapCase(resultSet);
	}
}
