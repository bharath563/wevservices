package org.tiaa.case_management_rs.poller;

import org.springframework.stereotype.Component;

@Component
public @interface Poller {

}
