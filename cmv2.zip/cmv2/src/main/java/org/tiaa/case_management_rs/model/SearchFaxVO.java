package org.tiaa.case_management_rs.model;

import java.util.Calendar;

public class SearchFaxVO {

	private String userId;
	private Calendar beginDate;
	private Calendar endDate;
	private String faxNumber; // Optional
	private String faxServer; // Optional
	private String operId; // Optional
	private String status;

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Calendar getBeginDate() {
		return this.beginDate;
	}

	public void setBeginDate(Calendar beginDate) {
		this.beginDate = beginDate;
	}

	public Calendar getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Calendar endDate) {
		this.endDate = endDate;
	}

	public String getFaxNumber() {
		return this.faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getFaxServer() {
		return this.faxServer;
	}

	public void setFaxServer(String faxServer) {
		this.faxServer = faxServer;
	}

	public String getOperId() {
		return this.operId;
	}

	public void setOperId(String operId) {
		this.operId = operId;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
