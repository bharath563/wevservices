package org.tiaa.case_management_rs.model;

import java.io.Serializable;
import java.util.Calendar;

@SuppressWarnings("serial")
public class CreateWork implements Serializable {
	private String userId;
	private String department; 
	private String taskType;
	private String actionStep; 		//Optional
	private String createOper;
	private Calendar receivedDate; 	//Optional
	private String vip;
	private String workBasket; 		//Optional
	private int priority;
	private String scanMode;
	private boolean byPassArcIdent;
	private String comments; 		//Optional
	private String wrkStationId;	//Optional
	private String idDesc;			//Optional
	private String field1;			//Optional
	private String field2;			//Optional
	private String field3;			//Optional
	private String field4;			//Optional
	private String storage;			//Optional
	private String extDocKey;		//Optional
	private String extSysName;		//Optional
	private String urlDocPath;		//Optional
	private String notes;			//Optional
	private int pageTotal;
	private String mailDesc;		//Optional
	private String mailId;			//Optional
	private String archBox;			//Optional
	private String magFldName;		//Optional
	private float fileSize;
	private String fileType;		//Optional
	private String piDocType;		//Optional
	private String faxNumber;		//Optional

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDepartment() {
		return this.department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getTaskType() {
		return this.taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getActionStep() {
		return this.actionStep;
	}

	public void setActionStep(String actionStep) {
		this.actionStep = actionStep;
	}

	public String getCreateOper() {
		return this.createOper;
	}

	public void setCreateOper(String createOper) {
		this.createOper = createOper;
	}

	public Calendar getReceivedDate() {
		return this.receivedDate;
	}

	public void setReceivedDate(Calendar receivedDate) {
		this.receivedDate = receivedDate;
	}

	public String getVip() {
		return this.vip;
	}

	public void setVip(String vip) {
		this.vip = vip;
	}

	public String getWorkBasket() {
		return this.workBasket;
	}

	public void setWorkBasket(String workBasket) {
		this.workBasket = workBasket;
	}

	public int getPriority() {
		return this.priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getScanMode() {
		return this.scanMode;
	}

	public void setScanMode(String scanMode) {
		this.scanMode = scanMode;
	}

	public boolean isByPassArcIdent() {
		return this.byPassArcIdent;
	}

	public void setByPassArcIdent(boolean byPassArcIdent) {
		this.byPassArcIdent = byPassArcIdent;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getWrkStationId() {
		return this.wrkStationId;
	}

	public void setWrkStationId(String wrkStationId) {
		this.wrkStationId = wrkStationId;
	}

	public String getIdDesc() {
		return this.idDesc;
	}

	public void setIdDesc(String idDesc) {
		this.idDesc = idDesc;
	}

	public String getField1() {
		return this.field1;
	}

	public void setField1(String field1) {
		this.field1 = field1;
	}

	public String getField2() {
		return this.field2;
	}

	public void setField2(String field2) {
		this.field2 = field2;
	}

	public String getField3() {
		return this.field3;
	}

	public void setField3(String field3) {
		this.field3 = field3;
	}

	public String getField4() {
		return this.field4;
	}

	public void setField4(String field4) {
		this.field4 = field4;
	}

	public String getStorage() {
		return this.storage;
	}

	public void setStorage(String storage) {
		this.storage = storage;
	}

	public String getExtDocKey() {
		return this.extDocKey;
	}

	public void setExtDocKey(String extDocKey) {
		this.extDocKey = extDocKey;
	}

	public String getExtSysName() {
		return this.extSysName;
	}

	public void setExtSysName(String extSysName) {
		this.extSysName = extSysName;
	}

	public String getUrlDocPath() {
		return this.urlDocPath;
	}

	public void setUrlDocPath(String urlDocPath) {
		this.urlDocPath = urlDocPath;
	}

	public String getNotes() {
		return this.notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public int getPageTotal() {
		return this.pageTotal;
	}

	public void setPageTotal(int pageTotal) {
		this.pageTotal = pageTotal;
	}

	public String getMailDesc() {
		return this.mailDesc;
	}

	public void setMailDesc(String mailDesc) {
		this.mailDesc = mailDesc;
	}

	public String getMailId() {
		return this.mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getArchBox() {
		return this.archBox;
	}

	public void setArchBox(String archBox) {
		this.archBox = archBox;
	}

	public String getMagFldName() {
		return this.magFldName;
	}

	public void setMagFldName(String magFldName) {
		this.magFldName = magFldName;
	}

	public float getFileSize() {
		return this.fileSize;
	}

	public void setFileSize(float fileSize) {
		this.fileSize = fileSize;
	}

	public String getFileType() {
		return this.fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getPiDocType() {
		return this.piDocType;
	}

	public void setPiDocType(String piDocType) {
		this.piDocType = piDocType;
	}

	public String getFaxNumber() {
		return this.faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

}
