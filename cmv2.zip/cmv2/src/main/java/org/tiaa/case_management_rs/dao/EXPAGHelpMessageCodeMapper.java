package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;

public class EXPAGHelpMessageCodeMapper extends AbstractRowMapper<ConfigData> implements RowMapper<ConfigData> {

	@Override
	public ConfigData mapRow(ResultSet rs, int paramInt)
			throws SQLException {
		ConfigData helpMessageCodes = new ConfigData();

		helpMessageCodes.setShortDescription(getStringTrimmed(rs, "ShortDescription"));
		return helpMessageCodes;
	}

}
