package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;

public class LongDescCDataMapper extends AbstractRowMapper<ConfigData> implements
		RowMapper<ConfigData> {

	@Override
	public ConfigData mapRow(ResultSet paramResultSet, int paramInt)
			throws SQLException {
		ConfigData configData = new ConfigData();
		
		String longDescription = getStringTrimmed(paramResultSet, "LongDescription");
			if(longDescription!=null && longDescription.length()>0){
				configData.setLongDescription("<![CDATA["+longDescription+"]]>");
			}
			
		return configData;
	}

}
