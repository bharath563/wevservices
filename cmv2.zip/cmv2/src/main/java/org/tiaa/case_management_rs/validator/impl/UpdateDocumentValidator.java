package org.tiaa.case_management_rs.validator.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.apache.commons.lang3.StringUtils;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.esb.case_management_rs_v2.type.DocumentRequest;
import org.tiaa.esb.case_management_rs_v2.type.Routing;

public class UpdateDocumentValidator extends BaseValidatorImpl {

	@Override
	public void doValidate(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		String appName = (String) request.getAttribute(APP_NAME);
		String docId =  (String) request.getAttribute(DOCUMENT_ID); 

		DocumentRequest document = (DocumentRequest) request.getAttribute(DOCUMENT_REQUEST);
		
		if(StringUtils.isBlank(docId)) {
			handleException(VALIDATION_DOC_ID_IS_NULL);
		}
		
		if (StringUtils.isBlank(userId)) {
			handleException(VALIDATION_USERID_IS_EMPTY);
		}
		
		if (StringUtils.isBlank(appName)) {
			handleException(VALIDATION_APPNAME_IS_EMPTY);
		}
		
		
		//doc content
		if (document == null || document.getDocument() == null){
			handleException(VALIDATION_DOC_CONTENT_IS_NULL);
		}
		
		//Only for Corro check for Create Date...
		if (!Routing.NOTE.toString().equalsIgnoreCase(
				document.getDocument().getDocDirection())
				&& document.getDocument().getDocCreateDateTime() == null) {
			handleException(VALIDATION_DOC_CREATED_DATE_IS_NULL);
		}
		
		
	}
}
