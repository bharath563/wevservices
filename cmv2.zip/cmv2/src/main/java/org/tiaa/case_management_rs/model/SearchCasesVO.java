package org.tiaa.case_management_rs.model;

import java.util.Calendar;

public class SearchCasesVO {
	private String userId;
	private String caseId; // Optional
	private String caseType; // Optional
	private Calendar beginDate; // Optional
	private Calendar endDate; // Optional
	private String firstName; // Optional
	private String middleName; // Optional
	private String lastName; // Optional
	private Calendar wakeDate; // Optional

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getCaseId() {
		return this.caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getCaseType() {
		return this.caseType;
	}

	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}

	public Calendar getBeginDate() {
		return this.beginDate;
	}

	public void setBeginDate(Calendar beginDate) {
		this.beginDate = beginDate;
	}

	public Calendar getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Calendar endDate) {
		this.endDate = endDate;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return this.middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Calendar getWakeDate() {
		return this.wakeDate;
	}

	public void setWakeDate(Calendar wakeDate) {
		this.wakeDate = wakeDate;
	}

}
