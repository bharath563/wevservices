package org.tiaa.case_management_rs.expag.helper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.delegate.impl.ColumnsMapping;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;
import org.tiaa.esb.case_management_rs_v2.type.SortCriteria;
import org.tiaa.esb.case_management_rs_v2.type.SortOrder;

@Component
public class SearchHelper {
	

	@Value("${maxNumberOfResults}")
	private int maxNumberOfResults;

	
	/**
	 * Return sortfield value from request
	 * @param searchRequest
	 * @return
	 */
	public String getSortFieldValue(SearchRequest searchRequest){		
		if(searchRequest.getSortCriteriaInfo() != null && searchRequest.getSortCriteriaInfo().getSortCriterias() != null && searchRequest.getSortCriteriaInfo().getSortCriterias().size()>0 ){
			SortCriteria sortCriteria = searchRequest.getSortCriteriaInfo().getSortCriterias().get(0);
			String sortField = sortCriteria.getSortField();
			return sortField;
		}
		return ColumnsMapping.RECEIVED_DATE;
	}
	
	/**
	 * Return sort Order value from request
	 * @param searchRequest
	 * @return
	 */
	public String getSortOrderValue(SearchRequest searchRequest){		
		if(searchRequest.getSortCriteriaInfo() != null && searchRequest.getSortCriteriaInfo().getSortCriterias() != null && searchRequest.getSortCriteriaInfo().getSortCriterias().size()>0 ){
			SortCriteria sortCriteria = searchRequest.getSortCriteriaInfo().getSortCriterias().get(0);
			SortOrder sortOrder = sortCriteria.getSortOrder();
			if(sortOrder!=null){
				String sortOrderValue = sortOrder.value();
				if(sortOrderValue!=null){
					sortOrderValue = sortOrderValue.trim();
				}
				return sortOrderValue;
			}

		}
		return "DESC";
	}

	/**
	 * returns sublist based upon start offset.
	 * 
	 * @param processes
	 * @param start
	 * @return List<Process>
	 */
	
	public List<Process> createSearchResponseList(List<Process> processes, int start) {
		start = (start > 0) ? start : 0;
		int end = (start > 0) ? (start + maxNumberOfResults) : maxNumberOfResults;
		List<Process> searchResponseList = new ArrayList<Process>();
		if (processes.size() >= end) {
			searchResponseList = processes.subList(start, end);
		} else if (processes.size() >= start) {
			searchResponseList = processes.subList(start, processes.size());
		} 

		return searchResponseList;
	}
}
