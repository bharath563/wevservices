package org.tiaa.case_management_rs.integration.case_manager.cth;

import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;

public abstract class AbstractCTHCaseContext {

	public abstract CaseDetails getCaseDetails();

}
