package org.tiaa.case_management_rs.integration.cth;

import java.util.List;

import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;

import org.w3c.dom.Element;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;
import org.tiaa.esb.servicerequest_workflow.types.TaskDetailType;

public class ServiceRequestWorkflowJaxbMarshaller {
	protected Jaxb2Marshaller serviceRequestWorkflowJaxb2Marshaller;

	public String getTaskid(CaseInfo caseInfo) {
		if (caseInfo == null) {
			return null;
		}
		List<TaskDetailType> taskDetails = caseInfo.getTaskDetails().getTaskDetails();
		TaskDetailType taskDetailType = taskDetails.get(0);
		return taskDetailType.getTaskId();
	}

	public CaseInfo getCaseInfo(Element element) {
		if (element == null) {
			return null;
		}
		DOMSource domSource = new DOMSource();
		domSource.setNode(element);
		return (CaseInfo) serviceRequestWorkflowJaxb2Marshaller.unmarshal(domSource);
	}

	public static Element toElement(Object obj, Jaxb2Marshaller jaxb2Marshaller) {
		DOMResult domResult = new DOMResult();
		jaxb2Marshaller.marshal(obj, domResult);
		org.w3c.dom.Document node = (org.w3c.dom.Document) domResult.getNode();
		return node.getDocumentElement();
	}

	public void setServiceRequestWorkflowJaxb2Marshaller(Jaxb2Marshaller serviceRequestWorkflowJaxb2Marshaller) {
		this.serviceRequestWorkflowJaxb2Marshaller = serviceRequestWorkflowJaxb2Marshaller;
	}
}
