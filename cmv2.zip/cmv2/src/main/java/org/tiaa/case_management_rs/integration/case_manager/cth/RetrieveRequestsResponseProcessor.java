package org.tiaa.case_management_rs.integration.case_manager.cth;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.constants.FileTypes;
import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;
import org.tiaa.case_management_rs.integration.case_manager.domain.Phase;
import org.tiaa.case_management_rs.syncup.service_request.ServiceRequesJaxbMarshaller;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.partyrequest.types.AdditionalRequestIdentifier;
import org.tiaa.esb.partyrequest.types.ObjectFactory;
import org.tiaa.esb.partyrequest.types.PartyIdentifier;
import org.tiaa.esb.partyrequest.types.PartyIdentifiers;
import org.tiaa.esb.partyrequest.types.PartyRequestControlInfo;
import org.tiaa.esb.partyrequest.types.PartyRequestResponse;
import org.tiaa.esb.partyrequest.types.PayloadInfo;
import org.tiaa.esb.partyrequest.types.RequestInfo;
import org.tiaa.esb.partyrequest.types.RetrievePartyReqControlInfo;
import org.tiaa.esb.partyrequest.types.UpdateAdditionalRequestIdentifier;
import org.tiaa.esb.partyrequest.types.UpdateAdditionalRequestIdentifiers;
import org.tiaa.esb.partyrequest.types.UpdateDisplayField;
import org.tiaa.esb.partyrequest.types.UpdateDisplayFields;
import org.tiaa.esb.partyrequest.types.UpdatePartyIdentifier;
import org.tiaa.esb.partyrequest.types.UpdatePartyIdentifiers;
import org.tiaa.esb.partyrequest.types.UpdatePartyRequest;
import org.tiaa.esb.partyrequest.types.UpdatePartyRequests;
import org.tiaa.esb.partyrequest.types.UpdateRequests;
import org.tiaa.esb.servicerequest.types.AnyXMLSkipType;
import org.tiaa.esb.servicerequest.types.CTHClob;
import org.tiaa.esb.servicerequest.types.ImplementationPlanType;
import org.tiaa.esb.servicerequest.types.ImplementationPlansType;
import org.tiaa.esb.servicerequest.types.OtherData;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;
import org.tiaa.esb.servicerequest_workflow.types.DocumentType;

public class RetrieveRequestsResponseProcessor {
	private static final String WORKFLOW_TASK_ID = "WorkflowTaskID";
	private static final String CASE_TYPE = "TaskType";
	private static final String CLIENT_ID = "ClientID";
	private static final Logger LOG = LoggerFactory.getLogger(RetrieveRequestsResponseProcessor.class);
	private ObjectFactory partyRequestObjectFactory = new ObjectFactory();
	private Jaxb2Marshaller servicerequestWorkflowJaxb2Marshaller;
	protected PayloadInfoBuilder payloadInfoBuilder;
	@Autowired
	private ServiceRequesJaxbMarshaller serviceRequesJaxb2Marshaller;

	public CaseInfo getCaseInfo(Element element) {
		DOMSource domSource2 = new DOMSource();
		domSource2.setNode(element);
		return (CaseInfo) servicerequestWorkflowJaxb2Marshaller.unmarshal(domSource2);
	}

	public UpdateRequests processResponse(UpdateCaseCTHContext context, PartyRequestResponse partyRequestResponse) {
		long requestIdentifier = partyRequestResponse.getRequestIdentifier();
		LOG.debug("requestIdentifier:{}", requestIdentifier);
		RetrievePartyReqControlInfo retrievePartyReqControlInfo = partyRequestResponse.getPartyReqControlInfo();
		//
		UpdatePartyRequest updatePartyRequest = new UpdatePartyRequest();
		PartyRequestControlInfo partyReqControlInfo = mapRetrievePartyReqControlInfo(retrievePartyReqControlInfo);
		//
		String caseStatus = context.getCaseDetails().getCthStatus();
		partyReqControlInfo.setStatus(caseStatus);
		//
		updatePartyRequest.setPartyReqControlInfo(partyReqControlInfo);
		context.setCthOrchestrationId(partyRequestResponse.getOrchestrationID());
		context.setCthRequestId(requestIdentifier);
		updatePartyRequest.setRequestIdentifier(requestIdentifier);
		updatePartyRequest.setPayloadInfo(partyRequestResponse.getPayloadInfo());
		updatePartyRequest.setDisplayFields(createDisplayFields(context));
		copyPartyIdentifiers(partyRequestResponse, updatePartyRequest);
		updatePartyRequest.setAdditionalRequestIdentifiers(new UpdateAdditionalRequestIdentifiers());
		context.setUpdatePartyRequest(updatePartyRequest);
		updateIdentifers(context);
		updateIdentifiersFromResponse(context, partyRequestResponse);
		updateClob(context, retrievePartyReqControlInfo.getStatus());
		return createUpdatePartyRequestsPayload(updatePartyRequest);
	}

	private void updateIdentifers(UpdateCaseCTHContext context) {
		UpdatePartyRequest updatePartyRequest = context.getUpdatePartyRequest();
		CaseDetails caseDetails = context.getCaseDetails();
		String taskType = caseDetails.getCaseType();
		String clientId = caseDetails.getClientId();
		String taskId = caseDetails.getWorkflowTaskID();
		if (LOG.isDebugEnabled()) {
			LOG.debug("ClientID: {}", clientId);
			LOG.debug("WorkflowTaskID: {}", taskId);
			LOG.debug("TaskType: {}", taskType);
		}
		List<UpdateAdditionalRequestIdentifier> updateAdditionalRequestIdentifierList = updatePartyRequest.getAdditionalRequestIdentifiers().getAdditionalRequestIdentifiers();
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, CLIENT_ID, clientId);
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, WORKFLOW_TASK_ID, taskId);
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, CASE_TYPE, taskType);
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, "TransitionManager", caseDetails.getTransitionManager());
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, "Phase", caseDetails.getCurrentPhaseName());
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, "PhaseTargetImplementationDate", caseDetails.getPhaseTargetImplementationDate());
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, "TargetImplementationDate", caseDetails.getTargetImplementationDate());
		updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, "ActualImplementationDate", caseDetails.getActualImplementationDate());
	}

	private UpdateDisplayFields createDisplayFields(UpdateCaseCTHContext context) {
		UpdateDisplayField displayField = new UpdateDisplayField();
		displayField.setFieldName("PhaseDescription");
		displayField.setValue(new ObjectFactory().createUpdateDisplayFieldValue(context.getCaseDetails().getCurrentPhaseDescription()));
		//
		UpdateDisplayFields displayFields = new UpdateDisplayFields();
		displayFields.getDisplayFields().add(displayField);
		return displayFields;
	}

	public void setPayloadInfoBuilder(PayloadInfoBuilder payloadInfoBuilder) {
		this.payloadInfoBuilder = payloadInfoBuilder;
	}

	public void setServicerequestWorkflowJaxb2Marshaller(Jaxb2Marshaller servicerequestWorkflowJaxb2Marshaller) {
		this.servicerequestWorkflowJaxb2Marshaller = servicerequestWorkflowJaxb2Marshaller;
	}

	protected DOMSource getDomSource(RequestInfo requestInfo) {
		Element any = requestInfo.getAny();
		DOMSource domSource = new DOMSource();
		domSource.setNode(any);
		return domSource;
	}

	protected RequestInfo getRequestInfo(UpdateCaseCTHContext context) {
		UpdatePartyRequest updatePartyRequest = context.getUpdatePartyRequest();
		PayloadInfo payloadInfo = updatePartyRequest.getPayloadInfo();
		return payloadInfo.getRequestInfo();
	}

	protected Element toElement(Object obj) {
		return toElement(obj, servicerequestWorkflowJaxb2Marshaller);
	}

	protected Element toElement(Object obj, Jaxb2Marshaller jaxb2Marshaller) {
		DOMResult domResult = new DOMResult();
		jaxb2Marshaller.marshal(obj, domResult);
		org.w3c.dom.Document node = (org.w3c.dom.Document) domResult.getNode();
		return node.getDocumentElement();
	}

	protected boolean updateClob(UpdateCaseCTHContext context, String status) {
		RequestInfo requestInfo = getRequestInfo(context);
		DOMSource domSource = getDomSource(requestInfo);
		CTHClob cthClob = serviceRequesJaxb2Marshaller.getCTHClob(domSource);
		OtherData otherData = serviceRequesJaxb2Marshaller.getOtherData(cthClob);
		CaseInfo caseInfo = serviceRequesJaxb2Marshaller.getCaseInfo(otherData);
		updateIdentifiersForDocuments(context, caseInfo);
		mapCaseDocuments(context, caseInfo);
		context.setCaseInfo(caseInfo);
		//
		boolean updateCTH = updateCTH(context, status);
		//update CLOB
		if (otherData != null) {
			mapPhaseInfo(context, otherData);
			AnyXMLSkipType workflowXML = otherData.getWorkFlowXML();
			workflowXML.setAny(toElement(caseInfo));
		}
		requestInfo.setAny(toElement(cthClob, serviceRequesJaxb2Marshaller.getServiceRequestJaxb2Marshaller()));
		return updateCTH;
	}

	private void updateIdentifiersFromResponse(UpdateCaseCTHContext context, PartyRequestResponse partyRequestResponse) {
		UpdatePartyRequest updatePartyRequest = context.getUpdatePartyRequest();
		List<UpdateAdditionalRequestIdentifier> updateAdditionalRequestIdentifierList = updatePartyRequest.getAdditionalRequestIdentifiers().getAdditionalRequestIdentifiers();
		List<AdditionalRequestIdentifier> additionalRequestIdentifierList = partyRequestResponse.getAdditionalRequestIdentifiers().getAdditionalRequestIdentifiers();

		for(AdditionalRequestIdentifier additionalRequestIdentifier : additionalRequestIdentifierList){
			if (additionalRequestIdentifier.getKey().equals("UnreadDocumentCount")) {
				BigDecimal value = additionalRequestIdentifier.getDecimalValue();
				updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, "UnreadDocumentCount", value);
			}
			if (additionalRequestIdentifier.getKey().equals("LastDocumentUpdateDateTime")) {
				XMLGregorianCalendar value = additionalRequestIdentifier.getDateValue();
				updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, "LastDocumentUpdateDateTime", value.toGregorianCalendar().getTime());
			}
		}
	}

	protected void updateIdentifiersForDocuments(UpdateCaseCTHContext context, CaseInfo caseInfo){
		UpdatePartyRequest updatePartyRequest = context.getUpdatePartyRequest();
		List<UpdateAdditionalRequestIdentifier> updateAdditionalRequestIdentifierList = updatePartyRequest.getAdditionalRequestIdentifiers().getAdditionalRequestIdentifiers();
		List<Date> LastDocumentUpdateDateTimeList = new ArrayList<Date>();
		BigDecimal docCount = new BigDecimal(0.0);
		Boolean newDocumentUploaded = false;
		Boolean hasValidFileType = false;

		//get the <UnreadDocumentCount> from AdditionalRequestIdentifiers
		for (UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier : updateAdditionalRequestIdentifierList) {
			if (updateAdditionalRequestIdentifier.getKey().equals("UnreadDocumentCount")) {
				JAXBElement<BigDecimal> jaxbElementValue = updateAdditionalRequestIdentifier.getDecimalValue();
				BigDecimal value = jaxbElementValue.getValue();
				docCount = (value == null) ? docCount : value;
			}
		}
		//
		List<DocumentType> documentList = caseInfo.getDocuments().getDocuments();
		for (DocumentType document : context.getCaseDetails().getDocuments()) {
			DocumentType foundDocument = PayloadInfoBuilder.findDocument(document, documentList);
			String documentType = document.getDocumentType();
			String fileExtension = documentType == null ? null : documentType.substring(documentType.lastIndexOf(".") + 1);
			hasValidFileType = fileExtension == null ? false : FileTypes.isValid(fileExtension);
			//Increment unread document count and set the updated LastDocumentUpdateDateTime if new document found for Upload/Checkin
			if (foundDocument == null) {
				if(document.getDocumentStatus().equals("REQUIRED") && hasValidFileType){
					docCount = docCount.add(new BigDecimal(1));
					newDocumentUploaded = true;
				}
			}else{
				if(!CommonUtil.isNull(document.getDocumentStatus()) && document.getDocumentStatus().equals("DELETED") && !CommonUtil.isNull(foundDocument.isDocumentRead()) && foundDocument.isDocumentRead() == false && docCount.compareTo(BigDecimal.ZERO) > 0 && hasValidFileType){
					docCount = docCount.subtract(new BigDecimal(1));
					updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, "UnreadDocumentCount", docCount);
				}
			}
			XMLGregorianCalendar documentUploadedDateTime = document.getDocumentUploadedDateTime();
			Date date = documentUploadedDateTime == null ? null : documentUploadedDateTime.toGregorianCalendar().getTime();
			if (date != null && hasValidFileType) {
				LastDocumentUpdateDateTimeList.add(date);
			}
		}
		Date latestDateTime = getLatestDate(LastDocumentUpdateDateTimeList);

		//if new document is uploaded
		if(newDocumentUploaded){
			updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, "UnreadDocumentCount", docCount);
			updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, "LastDocumentUpdateDateTime", latestDateTime);
		}
	}

	//get the latest date from the list
	protected Date getLatestDate(List<Date> LastDocumentUpdateDateTimeList){
		Date latestDate = null;
		for(Date LastDocumentUpdateDateTime : LastDocumentUpdateDateTimeList){
		   if (latestDate == null || LastDocumentUpdateDateTime.compareTo(latestDate) > 0){
			   latestDate = LastDocumentUpdateDateTime;
		   }
		}
		return latestDate;
	}

	protected void mapCaseDocuments(UpdateCaseCTHContext context, CaseInfo caseInfo) {
		PayloadInfoBuilder.updateDocumentsType(context, caseInfo);
	}

	private void mapPhaseInfo(UpdateCaseCTHContext context, OtherData otherDataType) {
		ImplementationPlansType implementationPlansType = new ImplementationPlansType();
		otherDataType.setImplementationPlansType(implementationPlansType);
		//
		List<ImplementationPlanType> implementationPlens = implementationPlansType.getImplementationPlen();
		HashMap<String, String> phaseMap = new HashMap<String, String>();
		for (Phase phase : context.getCaseDetails().getPhases()) {
			LOG.debug("phase - :" + phase);
			//
			XMLGregorianCalendar startDateTime = phase.getStartDateTime();
			XMLGregorianCalendar completedDateTime = phase.getCompletedDateTime();
			String phaseStartCompletionDates = new StringBuilder(phase.getName()).append(startDateTime).append(completedDateTime).toString();
			if (!phaseMap.containsKey(phaseStartCompletionDates)) {
				LOG.debug("not found: phaseStartCompletionDates:" + phaseStartCompletionDates);
				ImplementationPlanType implementationPlanType = new ImplementationPlanType();
				implementationPlanType.setName(phase.getName());
				implementationPlanType.setDescription(phase.getDescription());
				implementationPlanType.setStartDate(startDateTime);
				implementationPlanType.setActualCompletionDate(completedDateTime);
				implementationPlanType.setTargetCompletionDate(DateUtil.toXMLGregorianCalendar(phase.getTargetCompletionDateTime()));
				implementationPlens.add(implementationPlanType);
				//
				phaseMap.put(phaseStartCompletionDates, phaseStartCompletionDates);
			} else {
				LOG.warn("duplicate:" + phaseStartCompletionDates);
			}
		}
	}

	protected boolean updateCTH(UpdateCaseCTHContext context, String status) {
		return payloadInfoBuilder.updateCTH(context, status);
	}

	void addUpdateAdditionalIdentifer(UpdatePartyRequest updatePartyRequest, String key, String value) {
		if (value == null || value.isEmpty()) {
			return;
		}
		List<UpdateAdditionalRequestIdentifier> additionalRequestIdentifiers = updatePartyRequest.getAdditionalRequestIdentifiers().getAdditionalRequestIdentifiers();
		additionalRequestIdentifiers.add(createUpdateAdditionalRequestIdentifier(key, value));
	}

	void addUpdateAdditionalIdentifer(UpdatePartyRequest updatePartyRequest, String key, Date value) {
		if (value == null) {
			return;
		}
		List<UpdateAdditionalRequestIdentifier> additionalRequestIdentifiers = updatePartyRequest.getAdditionalRequestIdentifiers().getAdditionalRequestIdentifiers();
		additionalRequestIdentifiers.add(createUpdateAdditionalRequestIdentifier(key, value));
	}

	UpdateAdditionalRequestIdentifier copy(org.tiaa.esb.partyrequest.types.ObjectFactory objectFactory, AdditionalRequestIdentifier additionalRequestIdentifier) {
		UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier = new UpdateAdditionalRequestIdentifier();
		updateAdditionalRequestIdentifier.setKey(additionalRequestIdentifier.getKey());
		boolean updated = false;
		if (!updated) {
			XMLGregorianCalendar dateValue = additionalRequestIdentifier.getDateValue();
			if (dateValue != null) {
				updateAdditionalRequestIdentifier.setDateValue(objectFactory.createUpdateAdditionalRequestIdentifierDateValue(dateValue));
				updated = true;
			}
		}
		if (!updated) {
			BigDecimal decimalValue = additionalRequestIdentifier.getDecimalValue();
			if (decimalValue != null) {
				updateAdditionalRequestIdentifier.setDecimalValue(objectFactory.createUpdateAdditionalRequestIdentifierDecimalValue(decimalValue));
				updated = true;
			}
		}
		if (!updated) {
			String value = additionalRequestIdentifier.getValue();
			if (value != null) {
				updateAdditionalRequestIdentifier.setValue(objectFactory.createUpdateAdditionalRequestIdentifierValue(value));
				updated = true;
			}
		}
		return updateAdditionalRequestIdentifier;
	}

	private void copyPartyIdentifiers(PartyRequestResponse partyRequestResponse, UpdatePartyRequest updatePartyRequest) {
		UpdatePartyIdentifiers updatePartyIdentifiers = new UpdatePartyIdentifiers();
		List<UpdatePartyIdentifier> updatePartyIdentifiersList = updatePartyIdentifiers.getPartyIdentifiers();
		//
		PartyIdentifiers partyIdentifiers = partyRequestResponse.getPartyIdentifiers();
		for (PartyIdentifier partyIdentifier : partyIdentifiers.getPartyIdentifiers()) {
			UpdatePartyIdentifier updatePartyIdentifier = new UpdatePartyIdentifier();
			updatePartyIdentifier.setKey(partyIdentifier.getKey());
			updatePartyIdentifier.setValue(partyIdentifier.getValue());
			updatePartyIdentifiersList.add(updatePartyIdentifier);
		}
		updatePartyRequest.setPartyIdentifiers(updatePartyIdentifiers);
	}

	private UpdateAdditionalRequestIdentifier createUpdateAdditionalRequestIdentifier(String key, String value) {
		UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier = new UpdateAdditionalRequestIdentifier();
		updateAdditionalRequestIdentifier.setKey(key);
		updateAdditionalRequestIdentifier.setValue(partyRequestObjectFactory.createUpdateAdditionalRequestIdentifierValue(value));
		return updateAdditionalRequestIdentifier;
	}

	private UpdateAdditionalRequestIdentifier createUpdateAdditionalRequestIdentifier(String key, Date date) {
		UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier = new UpdateAdditionalRequestIdentifier();
		updateAdditionalRequestIdentifier.setKey(key);
		updateAdditionalRequestIdentifier.setDateValue(partyRequestObjectFactory.createUpdateAdditionalRequestIdentifierDateValue(DateUtil.toXMLGregorianCalendar(date)));
		return updateAdditionalRequestIdentifier;
	}

	private UpdateAdditionalRequestIdentifier createUpdateAdditionalRequestIdentifier(String key, BigDecimal value) {
		UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier = new UpdateAdditionalRequestIdentifier();
		updateAdditionalRequestIdentifier.setKey(key);
		updateAdditionalRequestIdentifier.setDecimalValue(partyRequestObjectFactory.createUpdateAdditionalRequestIdentifierDecimalValue(value));
		return updateAdditionalRequestIdentifier;
	}

	UpdatePartyIdentifier createUpdatePartyIdentifier(String key, String value) {
		UpdatePartyIdentifier updatePartyIdentifier = new UpdatePartyIdentifier();
		updatePartyIdentifier.setKey(key);
		updatePartyIdentifier.setValue(value);
		return updatePartyIdentifier;
	}

	private UpdateRequests createUpdatePartyRequestsPayload(UpdatePartyRequest updatePartyRequest) {
		UpdatePartyRequests updatePartyRequests = new UpdatePartyRequests();
		updatePartyRequests.getUpdatePartyRequests().add(updatePartyRequest);
		//
		UpdateRequests updateRequests = new UpdateRequests();
		updateRequests.setUpdatePartyRequests(updatePartyRequests);
		LOG.debug("updateRequests:{}", updateRequests);
		return updateRequests;
	}

	String getPartyIdentifier(UpdatePartyRequest updatePartyRequest, String key) {
		UpdatePartyIdentifiers partyIdentifiers = updatePartyRequest.getPartyIdentifiers();
		for (UpdatePartyIdentifier updatePartyIdentifier : partyIdentifiers.getPartyIdentifiers()) {
			if (key.equals(updatePartyIdentifier.getKey())) {
				return updatePartyIdentifier.getValue();
			}
		}
		return "";
	}

	boolean isAdditionalIdentifierFound(PartyRequestResponse partyRequestResponse, String key) {
		for (AdditionalRequestIdentifier additionalRequestIdentifier : partyRequestResponse.getAdditionalRequestIdentifiers().getAdditionalRequestIdentifiers()) {
			if (key.equals(additionalRequestIdentifier.getKey())) {
				return true;
			}
		}
		return false;
	}

	boolean isPartyIdentifierFound(PartyRequestResponse partyRequestResponse, String key) {
		PartyIdentifiers partyIdentifiers = partyRequestResponse.getPartyIdentifiers();
		for (PartyIdentifier partyIdentifier : partyIdentifiers.getPartyIdentifiers()) {
			if (key.equals(partyIdentifier.getKey())) {
				return true;
			}
		}
		return false;
	}

	private PartyRequestControlInfo mapRetrievePartyReqControlInfo(RetrievePartyReqControlInfo retrievePartyReqControlInfo) {
		PartyRequestControlInfo partyRequestControlInfo = new PartyRequestControlInfo();
		partyRequestControlInfo.setChannel(retrievePartyReqControlInfo.getChannel());
		partyRequestControlInfo.setEffectiveDate(retrievePartyReqControlInfo.getEffectiveDate());
		partyRequestControlInfo.setStatus(retrievePartyReqControlInfo.getStatus());
		partyRequestControlInfo.setSubmitDateTime(retrievePartyReqControlInfo.getSubmitDateTime());
		partyRequestControlInfo.setSystemIdentifier(retrievePartyReqControlInfo.getSystemIdentifier());
		partyRequestControlInfo.setUpdatedBy(AppConstants.USER_REF);
		return partyRequestControlInfo;
	}

	private boolean updateAdditionalRequestIdentifier(List<UpdateAdditionalRequestIdentifier> updateAdditionalRequestIdentifierList, String key, String value) {
		if (CommonUtil.isNullOrEmpty(value)) {
			return false;
		}
		boolean found = false;
		boolean updateValue = false;
		for (UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier : updateAdditionalRequestIdentifierList) {
			if (updateAdditionalRequestIdentifier.getKey().equals(key)) {
				JAXBElement<String> jaxbElementValue = updateAdditionalRequestIdentifier.getValue();
				String anotherValue = jaxbElementValue.getValue();
				found = true;
				updateValue = !value.equals(anotherValue);
				if (updateValue) {
					updateAdditionalRequestIdentifier.setValue(partyRequestObjectFactory.createUpdateAdditionalRequestIdentifierValue(value));
				}
				break;
			}
		}
		if (found) {
			return updateValue;
		}
		updateAdditionalRequestIdentifierList.add(createUpdateAdditionalRequestIdentifier(key, value));
		return true;
	}

	private boolean updateAdditionalRequestIdentifier(List<UpdateAdditionalRequestIdentifier> updateAdditionalRequestIdentifierList, String key, Date value) {
		if (CommonUtil.isNull(value)) {
			return false;
		}
		boolean found = false;
		boolean updateValue = false;
		for (UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier : updateAdditionalRequestIdentifierList) {
			if (updateAdditionalRequestIdentifier.getKey().equals(key)) {
				JAXBElement<XMLGregorianCalendar> jaxbElementValue = updateAdditionalRequestIdentifier.getDateValue();
				XMLGregorianCalendar anotherValue = jaxbElementValue.getValue();
				found = true;
				updateValue = value.compareTo(anotherValue.toGregorianCalendar().getTime()) != 0;
				if (updateValue) {
					updateAdditionalRequestIdentifier.setDateValue(partyRequestObjectFactory.createUpdateAdditionalRequestIdentifierDateValue(DateUtil.toXMLGregorianCalendar(value)));
				}
				break;
			}
		}
		if (found) {
			return updateValue;
		}
		updateAdditionalRequestIdentifierList.add(createUpdateAdditionalRequestIdentifier(key, value));
		return true;
	}

	private boolean updateAdditionalRequestIdentifier(List<UpdateAdditionalRequestIdentifier> updateAdditionalRequestIdentifierList, String key, BigDecimal value) {
		if (CommonUtil.isNull(value)) {
			return false;
		}
		boolean found = false;
		boolean updateValue = false;
		for (UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier : updateAdditionalRequestIdentifierList) {
			if (updateAdditionalRequestIdentifier.getKey().equals(key)) {
				JAXBElement<BigDecimal> jaxbElementValue = updateAdditionalRequestIdentifier.getDecimalValue();
				BigDecimal anotherValue = jaxbElementValue.getValue();
				found = true;
				updateValue = !value.equals(anotherValue);
				if (updateValue) {
					updateAdditionalRequestIdentifier.setDecimalValue(partyRequestObjectFactory.createUpdateAdditionalRequestIdentifierDecimalValue(value));
				}
				break;
			}
		}
		if (found) {
			return updateValue;
		}
		updateAdditionalRequestIdentifierList.add(createUpdateAdditionalRequestIdentifier(key, value));
		return true;
	}

	boolean updatePartyIdentifier(UpdatePartyRequest updatePartyRequest, String key, String value) {
		if (CommonUtil.isNullOrEmpty(value)) {
			return false;
		}
		UpdatePartyIdentifiers partyIdentifiers = updatePartyRequest.getPartyIdentifiers();
		for (UpdatePartyIdentifier updatePartyIdentifier : partyIdentifiers.getPartyIdentifiers()) {
			if (key.equals(updatePartyIdentifier.getKey())) {
				if (!value.equals(updatePartyIdentifier.getValue())) {
					updatePartyIdentifier.setValue(value);
					return true;
				}
				return false;
			}
		}
		return false;
	}
}
