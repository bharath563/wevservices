package org.tiaa.case_management_rs.integration.case_manager;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class CaseManagerDBConfig {
	@Autowired
	private DataSource caseManagerDataSource;

	@Bean
	public JdbcTemplate caseManagerJdbcTemplate() {
		return new JdbcTemplate(caseManagerDataSource);
	}

	@Bean
	public CaseManagerDAO retryCaseManagerCaseDetailsDAO() {
		return new CaseManagerDAO();
	}
}
