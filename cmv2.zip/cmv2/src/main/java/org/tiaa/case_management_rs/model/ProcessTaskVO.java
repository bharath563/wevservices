package org.tiaa.case_management_rs.model;

import java.util.Calendar;

public class ProcessTaskVO {

	private String userId;
	private String taskId;
	private String packetId;
	private Calendar receiveDate;
	private String department; // Optional
	private String taskType; // Optional
	private String actionDesc; // Optional
	private String workBasket; // Optional
	private String vip; // Optional
	private int priority;
	private String caseDesc; // Optional
	private String caseId; // Optional
	private String status;
	private String commentsnotes; // Optional
	private String usecommentsnotes; // Optional
	private String wakeOperId; // Optional
	private Calendar wakeDate; // Optional
	private String reviewOperId; // Optional
	private Calendar startDate; // Required
	private int cdReason1;
	private int cdReason2;
	private int cdReason3;
	private int cdReason4;
	private int cdReason5;
	private String updatedXml; // Optional

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTaskId() {
		return this.taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getPacketId() {
		return this.packetId;
	}

	public void setPacketId(String packetId) {
		this.packetId = packetId;
	}

	public Calendar getReceiveDate() {
		return this.receiveDate;
	}

	public void setReceiveDate(Calendar receiveDate) {
		this.receiveDate = receiveDate;
	}

	public String getDepartment() {
		return this.department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getTaskType() {
		return this.taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public String getActionDesc() {
		return this.actionDesc;
	}

	public void setActionDesc(String actionDesc) {
		this.actionDesc = actionDesc;
	}

	public String getWorkBasket() {
		return this.workBasket;
	}

	public void setWorkBasket(String workBasket) {
		this.workBasket = workBasket;
	}

	public String getVip() {
		return this.vip;
	}

	public void setVip(String vip) {
		this.vip = vip;
	}

	public int getPriority() {
		return this.priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public String getCaseDesc() {
		return this.caseDesc;
	}

	public void setCaseDesc(String caseDesc) {
		this.caseDesc = caseDesc;
	}

	public String getCaseId() {
		return this.caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCommentsnotes() {
		return this.commentsnotes;
	}

	public void setCommentsnotes(String commentsnotes) {
		this.commentsnotes = commentsnotes;
	}

	public String getUsecommentsnotes() {
		return this.usecommentsnotes;
	}

	public void setUsecommentsnotes(String usecommentsnotes) {
		this.usecommentsnotes = usecommentsnotes;
	}

	public String getWakeOperId() {
		return this.wakeOperId;
	}

	public void setWakeOperId(String wakeOperId) {
		this.wakeOperId = wakeOperId;
	}

	public Calendar getWakeDate() {
		return this.wakeDate;
	}

	public void setWakeDate(Calendar wakeDate) {
		this.wakeDate = wakeDate;
	}

	public String getReviewOperId() {
		return this.reviewOperId;
	}

	public void setReviewOperId(String reviewOperId) {
		this.reviewOperId = reviewOperId;
	}

	public Calendar getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Calendar startDate) {
		this.startDate = startDate;
	}

	public int getCdReason1() {
		return this.cdReason1;
	}

	public void setCdReason1(int cdReason1) {
		this.cdReason1 = cdReason1;
	}

	public int getCdReason2() {
		return this.cdReason2;
	}

	public void setCdReason2(int cdReason2) {
		this.cdReason2 = cdReason2;
	}

	public int getCdReason3() {
		return this.cdReason3;
	}

	public void setCdReason3(int cdReason3) {
		this.cdReason3 = cdReason3;
	}

	public int getCdReason4() {
		return this.cdReason4;
	}

	public void setCdReason4(int cdReason4) {
		this.cdReason4 = cdReason4;
	}

	public int getCdReason5() {
		return this.cdReason5;
	}

	public void setCdReason5(int cdReason5) {
		this.cdReason5 = cdReason5;
	}

	public String getUpdatedXml() {
		return this.updatedXml;
	}

	public void setUpdatedXml(String updatedXml) {
		this.updatedXml = updatedXml;
	}

}
