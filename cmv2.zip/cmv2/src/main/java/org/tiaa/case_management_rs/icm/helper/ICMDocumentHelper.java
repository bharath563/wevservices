package org.tiaa.case_management_rs.icm.helper;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.stereotype.Service;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.integration.federeated_document.FederatedDocumentRSService;
import org.tiaa.case_management_rs.integration.icm.ICMRepositoryLinkHelper;
import org.tiaa.case_management_rs.integration.icm.ICMService;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.Document;
import org.tiaa.esb.icm.types.Response;

import org.tiaa.atom.core.support.rest.RestServiceESBSupport;

@Service
public class ICMDocumentHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(ICMDocumentHelper.class);
	
	@Autowired
	private RestServiceESBSupport restServiceESBSupport;
	
	@Autowired
	private ICMService icmService;
	
	@Autowired
	private FederatedDocumentRSService federatedDocumentRSService;
		
	@Autowired
	private ICMRepositoryLinkHelper iCMRepositoryLinkHelper;
	
	public boolean createDocumentInICM(String userId, String taskId,
			String caseId, Document cmsDocument) {
		org.tiaa.esb.icm.types.Document icmDocument = new org.tiaa.esb.icm.types.Document();
		Response response = null;
		// upload document to FDRS
		String dri = uploadToFDRI(cmsDocument);
		boolean uploadStatus = false;
		icmDocument.setBusinessUnit(FederatedDocumentRSService.BIZ_UNIT);
		icmDocument.setId(dri);
		icmDocument.setIdtype("DRI");
		icmDocument.setVersion(FederatedDocumentRSService.VERSION);
		icmDocument.setDocCode(FederatedDocumentRSService.DOC_CODE);
		String mimeType = cmsDocument.getMimeTyp();
		if (null != mimeType) {
			mimeType = mimeType.trim();
		}
		icmDocument.setMimeType(mimeType);
		icmDocument.setDocumentName(cmsDocument.getDocName());
		icmDocument.setFolder(cmsDocument.getDocDirection());
		response = this.icmService.addDocument(icmDocument, caseId, userId);
		if (response.getErrorCode() == null) {
			uploadStatus = true;
		}
		return uploadStatus;
	}

	private String uploadToFDRI(Document cmsDocument) {
		Map<String, String> documentDataMap = new HashMap<String, String>();
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_MIME_TYPE, cmsDocument.getMimeTyp());
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_DOCUMENT_TITLE, cmsDocument.getDocName());
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_FILE_NAME, cmsDocument.getDocName());
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_DOCUMENT_DESCRIPTION, cmsDocument.getDocTitle());

		if(cmsDocument.getDocOriginator() != null){
			if(cmsDocument.getDocOriginator().getDocOrigIndiv() != null) {
				documentDataMap.put(FederatedDocumentRSService.UPLOAD_PIN, cmsDocument.getDocOriginator().getDocOrigIndiv().getPIN());
			}
			
			if(cmsDocument.getDocOriginator().getDocOrigOrg() != null) {
				documentDataMap.put(FederatedDocumentRSService.UPLOAD_CLIENT_ID, cmsDocument.getDocOriginator().getDocOrigOrg().getID());
			}
		}
		
		if(cmsDocument.getProcessID() != null){
			documentDataMap.put(FederatedDocumentRSService.UPLOAD_ORCH_ID, cmsDocument.getProcessID().getOrchestrationID());
		}

		documentDataMap.put("Business_Date", DateUtil.today());
		return federatedDocumentRSService.archiveDocumentInMobius(documentDataMap, new ByteArrayResource(cmsDocument.getDocContent()));
	}	
	
	public Document getDocument(Request request) throws JAXBException {
		Map<String,String> docSearchKey = new HashMap<String,String>();
		String bizUnit = (String)request.getAttribute(CaseManagementConstants.BUSINESS_UNIT_CODE);
		String docCode =  (String)request.getAttribute(CaseManagementConstants.DOC_CODE);
		String ver =  (String)request.getAttribute(CaseManagementConstants.VERSION);
		String idType = (String) request.getAttribute(CaseManagementConstants.ID_TYPE);
		String mimeType = (String)request.getAttribute(CaseManagementConstants.MIME_TYPE);
		String docId =  (String)request.getAttribute(CaseManagementConstants.DOCUMENT_ID);
		docSearchKey.put("business-unit-code", bizUnit);
		docSearchKey.put("doc-code", docCode);
		docSearchKey.put("version", ver);
		docSearchKey.put("id-type", idType);
		docSearchKey.put(CaseManagementConstants.MIME_TYPE, mimeType);
		
		return  this.federatedDocumentRSService.getDocumentFromMobius(docSearchKey,docId);
	}

}

