package org.tiaa.case_management_rs.delegate;

import org.tiaa.esb.icm.types.ResponseList;
import org.tiaa.esb.icm.types.TaskSearch;

public interface TaskSearchDelegate {

	ResponseList searchNigoTasks(TaskSearch taskSearchRequest, String userId);

}
