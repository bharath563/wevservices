package org.tiaa.case_management_rs.integration.exp_ag.power_image;

public class WorkflowException extends RuntimeException {
	private static final long serialVersionUID = 2346780708079166229L;

	public WorkflowException() {
		super();
	}

	public WorkflowException(String message) {
		super(message);
	}

	public WorkflowException(String message, Throwable cause) {
		super(message, cause);
	}

	public WorkflowException(Throwable cause) {
		super(cause);
	}
}
