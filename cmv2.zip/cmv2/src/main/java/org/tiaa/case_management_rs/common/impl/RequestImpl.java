package org.tiaa.case_management_rs.common.impl;

import java.util.HashMap;
import java.util.Map;

import org.tiaa.case_management_rs.common.Request;

/**
 * This class will be used to send request attributes to business processing
 * layer from service interaction layer
 */
public class RequestImpl implements Request {

	/**
	 * Hashmap used to store the request attributes.
	 */
	private Map<String, Object> map = new HashMap<String, Object>();

	/**
	 * This method is used to set the object in the request using the given key.
	 *
	 * @param key
	 *            Key to set the object in request
	 * @param value
	 *            Object to be added in the request
	 */
	@Override
	public void setAttribute(String key, Object value) {
		this.map.put(key, value);
	}

	/**
	 * This method is used to get an object from the request based on a key.
	 *
	 * @param aKey
	 *            Key to get the object from request
	 * @return Object Object that was stored in request for the given key; Null
	 *         if there is no object exists.
	 */

	@Override
	public Object getAttribute(String aKey) {
		return this.map.get(aKey);
	}

}
