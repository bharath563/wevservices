package org.tiaa.case_management_rs.common;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class XMLGregCalendarTest {

	public static void main(String[] args) throws Exception {
		Calendar gc = new GregorianCalendar();
		String startDateString = "2016-11-13T20:22:17.209-05:00";
		XMLGregCalendarTest test = new XMLGregCalendarTest();
		 DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ"); 
		//test.convertDateFormat(startDateString,"yyyy-MM-dd'T'HH:mm:ss.SSSZ","yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		XMLGregorianCalendar currServTime = null;
		try {
			currServTime = DatatypeFactory.newInstance().newXMLGregorianCalendar(startDateString);
		} catch (DatatypeConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("currServTime is "+currServTime);
	}
	
	public static String convertDateFormat(String oldDateString, String currentFormat, String expectedFormat)
			throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat(currentFormat);
		Date d = null;
		d = sdf.parse(oldDateString);

		sdf.applyPattern(expectedFormat);
		return sdf.format(d);
	} 


}
