package org.tiaa.case_management_rs.delegate.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.case_management_rs.common.WorkItemsCreationStatus;
import org.tiaa.case_management_rs.common.impl.RequestImpl;
import org.tiaa.case_management_rs.dao.EXPAGDAO;
import org.tiaa.case_management_rs.dao.NEXTGENDAO;
import org.tiaa.case_management_rs.dao.ProcessDBDAO;
import org.tiaa.case_management_rs.delegate.CaseManagementDelegate;
import org.tiaa.case_management_rs.expag.helper.ExpagCorrespondenceHelper;
import org.tiaa.case_management_rs.expag.helper.ExpagDocumentHelper;
import org.tiaa.case_management_rs.expag.helper.ExpagNoteTemplateHelper;
import org.tiaa.case_management_rs.expag.helper.ExpagProcessTaskHelper;
import org.tiaa.case_management_rs.expag.helper.ExpagSearchHelper;
import org.tiaa.case_management_rs.expag.helper.ExpagTaskHelper;
import org.tiaa.case_management_rs.expag.helper.SearchHelper;
import org.tiaa.case_management_rs.icm.helper.ICMCommentsHelper;
import org.tiaa.case_management_rs.icm.helper.ICMConfigHelper;
import org.tiaa.case_management_rs.icm.helper.ICMDocumentHelper;
import org.tiaa.case_management_rs.icm.helper.ICMSearchHelper;
import org.tiaa.case_management_rs.icm.helper.ICMTaskHelper;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.PowerImageService;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.WorkflowException;
import org.tiaa.case_management_rs.integration.icm.ICMService;
import org.tiaa.case_management_rs.model.ExpagStatusHistory;
import org.tiaa.case_management_rs.model.NextGenProcessSource;
import org.tiaa.case_management_rs.model.SearchItemsVO;
import org.tiaa.case_management_rs.model.TaskIdentifiersValue;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.Comment;
import org.tiaa.esb.case_management_rs_v2.type.Comments;
import org.tiaa.esb.case_management_rs_v2.type.CommentsRequest;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItem;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItems;
import org.tiaa.esb.case_management_rs_v2.type.DateType;
import org.tiaa.esb.case_management_rs_v2.type.Document;
import org.tiaa.esb.case_management_rs_v2.type.Document.DocOriginator;
import org.tiaa.esb.case_management_rs_v2.type.DocumentRequest;
import org.tiaa.esb.case_management_rs_v2.type.Documents;
import org.tiaa.esb.case_management_rs_v2.type.DocumentsRequest;
import org.tiaa.esb.case_management_rs_v2.type.EmailAttributes;
import org.tiaa.esb.case_management_rs_v2.type.FromEmail;
import org.tiaa.esb.case_management_rs_v2.type.History;
import org.tiaa.esb.case_management_rs_v2.type.Metrics;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.ProcessID;
import org.tiaa.esb.case_management_rs_v2.type.ProcessRequest;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.ProcessesRequest;
import org.tiaa.esb.case_management_rs_v2.type.Properties;
import org.tiaa.esb.case_management_rs_v2.type.RelatedTasks;
import org.tiaa.esb.case_management_rs_v2.type.Routing;
import org.tiaa.esb.case_management_rs_v2.type.SLADetail;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;
import org.tiaa.esb.case_management_rs_v2.type.Statuses;
import org.tiaa.esb.case_management_rs_v2.type.Task;
import org.tiaa.esb.case_management_rs_v2.type.TaskResponse;
import org.tiaa.esb.case_management_rs_v2.type.Tasks;
import org.tiaa.esb.case_management_rs_v2.type.ToEmail;
import org.tiaa.esb.icm.types.Configuration;
import org.tiaa.esb.icm.types.FormatType;
import org.tiaa.esb.icm.types.ResponseList;
import org.tiaa.esb.powerimage.types.PIAcknowledge;
import org.tiaa.esb.powerimage.types.WorkPacket;

import org.tiaa.atom.core.AtomCoreException;

@Repository(value="expagAdapter")
public class ExpAGAdapter implements CaseManagementDelegate {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExpAGAdapter.class);

	@Autowired
	private PowerImageService powerImageService;

	@Autowired
	private ProcessDBDAO processDBDao;

	@Autowired
	private EXPAGDAO expagdao;
	
	@Autowired
	private NEXTGENDAO nextgenDao;

	@Autowired
	private ExpagNoteTemplateHelper expagNoteTemplateHelper;
	
	@Autowired
	private ExpagCorrespondenceHelper expagCorrespondenceHelper  ;
	
	@Autowired
	private ExpagTaskHelper expagTaskHelper;

	@Autowired
	private ExpagDocumentHelper expagDocumentHelper;

	@Autowired
	private ICMDocumentHelper icmDocumentHelper;

	@Autowired
	private ExpagSearchHelper expagSearchHelper;

	@Autowired
	private SearchHelper searchHelper;
	
	@Autowired
	private ExpagProcessTaskHelper expagProcessTaskHelper;

	@Autowired
	private ICMSearchHelper icmSearchHelper;

	@Autowired
	private ICMTaskHelper icmTaskHelper;

	@Autowired
	private ICMCommentsHelper icmCommentsHelper;

	@Autowired
	private ICMConfigHelper icmConfigHelper;

	@Autowired
	private ICMService icmService;

	@Value("${maxNumberOfResults}")
	private int maxNumberOfResults;
	@Value("${maxBulkAssignmentThreadPoolSize}")
	protected int maxBulkAssignmentThreadPoolSize;
	
	@Value("${maxBulkSuspensionThreadPoolSize}")
	protected int maxBulkSuspensionThreadPoolSize;
	
	@Value("${retry.count}")
	private int retryCount;
	
	@Value("${filterConvertedTasks}")
	private String filterConvertedExpagTasks;

	private ObjectMapper objectMapper = new ObjectMapper();

	@Override
	public Processes getProcesses(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		String department = (String) request.getAttribute(DEPARTMENT);
		String type = (String) request.getAttribute(TYPE);
		int start = request.getAttribute(START) != null ? Integer.parseInt(String.valueOf(request.getAttribute(START))) : 0;
		/*
		 * Call database instead of the webservice call
		 */

		Processes processes = this.expagTaskHelper.getWorkItemsfromDB(userId, department, type, start);

		return processes;

	}

	@Override
	public Process getProcess(Request request) {
		return  getExpagProcess(request);

	}

	/**
	 * Return ICM Related Task
	 * 
	 * @param processId
	 * @param userId
	 * @return
	 */
/*	public RelatedTasks getRelatedCasesICM(String processId, String userId, String solutionName) {
		ResponseList reponseList = this.icmService.getICMRelatedCase(processId, userId, solutionName);
		RelatedTasks relatedTasks = new RelatedTasks();
		@SuppressWarnings("unchecked")
		List<RelatedCase> relatedCasesList = (List<RelatedCase>) reponseList.getResults();

		if (!relatedCasesList.isEmpty()) {
			for (Object icmTaskResponseJSON : relatedCasesList) {
				try {
					DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss.SSS a");
					String icmResponseJSONString = this.objectMapper.writeValueAsString(icmTaskResponseJSON);
					this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
					this.objectMapper.setDateFormat(df);
					RelatedCase icmRelatedCaseResponse = objectMapper.readValue(icmResponseJSONString, RelatedCase.class);
					Task cmsTask = new Task();

					cmsTask.setID(icmRelatedCaseResponse.getCaseId());
					cmsTask.setType(icmRelatedCaseResponse.getCaseType());

					if (icmRelatedCaseResponse.getCreatedDate() != null) {
						cmsTask.setCreateDate(DateUtil.toXMLGregorianCalendarDateOnly(DateUtil.parseDateTimeWithMilliseconds((df.format(icmRelatedCaseResponse.getCreatedDate())))));
						cmsTask.setCreateTime(DateUtil.toXMLGregorianCalendarTimeOnly(DateUtil.parseDateTimeWithMilliseconds((df.format(icmRelatedCaseResponse.getCreatedDate())))));
					}
					if (icmRelatedCaseResponse.getCompletedDate() != null) {
						cmsTask.setCompleteDate(DateUtil.toXMLGregorianCalendarDateOnly(DateUtil.parseDateTimeWithMilliseconds((df.format(icmRelatedCaseResponse.getCompletedDate())))));
						cmsTask.setCompleteTime(DateUtil.toXMLGregorianCalendarTimeOnly(DateUtil.parseDateTimeWithMilliseconds((df.format(icmRelatedCaseResponse.getCompletedDate())))));
					}

					Statuses statuses = new Statuses();
					Status status = new Status();
					status.setSts(icmRelatedCaseResponse.getCaseStatus());
					statuses.getSts().add(status);
					cmsTask.setStatusHistory(statuses);

					Properties icmProperties = new Properties();
					NameValue nameValueChannel = new NameValue();
					nameValueChannel.setDesc("confirmation");
					nameValueChannel.setValue(icmRelatedCaseResponse.getConfirmation());
					icmProperties.getProperties().add(nameValueChannel);

					// NameValue nameValueChannel2 = new NameValue();
					// nameValueChannel2.setDesc("pathName");
					// nameValueChannel2.setValue(icmRelatedCaseResponse.getPathName());
					// icmProperties.getProperties().add(nameValueChannel2);

					cmsTask.setTaskProperties(icmProperties);

					relatedTasks.getRelatedTasks().add(cmsTask);

				} catch (JsonProcessingException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return relatedTasks;

	}*/
	
	private Processes filterExpAgProcess(Processes processes) {
		List<NextGenProcessSource> nextGenSourceDelegator = nextgenDao.getNextGenProcessDelegator();
		List<String> expagProcessList = new ArrayList<String>();
		for (NextGenProcessSource nxtGenProcess : nextGenSourceDelegator) {
			expagProcessList.add(nxtGenProcess.getProcessName().trim());
		}
		List<Process> processList = processes.getProcesses();
		List<Process> filteredExpagProcess = new ArrayList<Process>();
		if (processList != null && processList.size() > 0) {
			for (Process process : processList) {
				if (expagProcessList.contains(process.getTasks().getTasks().get(0).getType())) {
					filteredExpagProcess.add(process);
				}
			}
		}
		Processes filteredProcesses = new Processes();
		filteredProcesses.getProcesses().addAll(filteredExpagProcess);
		filteredProcesses.setPaginationInfo(processes.getPaginationInfo());
		return filteredProcesses;
	}

	private Process getExpagProcess(Request request) {

		Process process = new Process();

		Documents documents = new Documents();
		RelatedTasks relatedTasks = new RelatedTasks();
		Comments comments = new Comments();
		History history = new History();

		Tasks tasks = new Tasks();
		Task cmsTask = new Task();

		WorkPacket workPacket = new WorkPacket();

		String userId = (String) request.getAttribute(USER_ID);
		String taskId = (String) request.getAttribute(PROCESS_ID);
		String isNewTask = (String) request.getAttribute(IS_NEW_TASK);
		String searchMode = (String) request.getAttribute(SEARCH_MODE);
		String processId = null;

		List<String> actions = new ArrayList<String>();

		org.tiaa.esb.powerimage.types.Task expagTask = this.powerImageService.getTaskDetails(userId, taskId);

		Statuses statuses = this.expagTaskHelper.computeTaskStatuses(expagTask);

		String taskStatus = null;
		if (statuses != null && statuses.getSts() != null && statuses.getSts().get(0) != null) {
			taskStatus = statuses.getSts().get(0).getSts();
		}

		if ((searchMode != null && searchMode.equalsIgnoreCase("y")) || (TRUE.equalsIgnoreCase(isNewTask)) || (TASK_STATUS_CANCELLED.equalsIgnoreCase(taskStatus)) || (TASK_STATUS_REJECTED.equalsIgnoreCase(taskStatus)) || (TASK_STATUS_COMPLETED.equalsIgnoreCase(taskStatus))) {
			cmsTask.setMode(EXPAG_TASK_READ_MODE);
		} else {

			/*
			 * If task is already locked then fetch task actions from database
			 * else autolock task by calling getWorkItem powerImage service and
			 * fetch task actions from getWorkItem object
			 */
			if ((expagTask != null) && (StringUtils.isNotBlank(expagTask.getLockoper()) || (StringUtils.isNotBlank(expagTask.getSuspoper())))) {

				if (userId.equalsIgnoreCase(expagTask.getLockoper())) {
					cmsTask.setMode(EXPAG_TASK_WRITE_MODE);
				} else {
					cmsTask.setMode(EXPAG_TASK_READ_MODE);
				}

				if (expagTask.getActiondesc() != null) {
					actions = this.expagdao.getTaskActions(expagTask.getActiondesc());
				}

			} else {
				org.tiaa.esb.powerimage.types.GetWorkItem getWorkItem = this.powerImageService.getWorkItem(userId, taskId, expagTask.getLasthistdate().toGregorianCalendar());
				expagTask = getWorkItem.getTask();
				if (getWorkItem.getAvailablestatus() != null) {
					actions = getWorkItem.getAvailablestatus().getStatuses();
					// Sometime we get None as status and to avoid extra db call
					// that why this check is done
					if (actions.size() == 1 && actions.get(0).equalsIgnoreCase("none") && expagTask.getActiondesc() != null) {
						actions = this.expagdao.getTaskActions(expagTask.getActiondesc());
					}
					LOGGER.info("Task Id --> " + expagTask.getTaskid() + "  Action Step --> " + expagTask.getActiondesc() + " Actions -->" + actions);
				}
				cmsTask.setMode(EXPAG_TASK_WRITE_MODE);
			}

			org.tiaa.esb.case_management_rs_v2.type.List actionList = new org.tiaa.esb.case_management_rs_v2.type.List();
			actionList.getItems().addAll(actions);
			cmsTask.setAction(actionList);

		}

		if ((expagTask != null) && StringUtils.isNotBlank(expagTask.getPktid())) {

			processId = expagTask.getPktid();

			// Populate summary
			this.expagTaskHelper.expagTaskTocmsTask(expagTask, cmsTask);
			tasks.getTasks().add(cmsTask);

			if ((searchMode == null || searchMode.equalsIgnoreCase("n")) && StringUtils.isNotBlank(expagTask.getLockoper())) {
				cmsTask.setLocked(true);
				String lockedByName = this.expagdao.getOperatorName(expagTask.getLockoper());
				cmsTask.setLockedBy(lockedByName);
			}

			org.tiaa.esb.case_management_rs_v2.type.Properties properties = this.expagTaskHelper.addOmniTransType(cmsTask.getType(), cmsTask.getActionStep(), cmsTask.getTaskProperties());
			
			//Adding priority of a task as a property to show in Edit Defaults
			if(expagTask.getPriority() != null) {
				properties.getProperties().add(this.expagTaskHelper.addProperty(BigInteger.ONE, PROPERTY_NAME_PRIORITY, BigInteger.valueOf(expagTask.getPriority()), PROPERTY_DESC_PRIORITY));
			}
			
			//Getting flag if user is entitled to access Edit Defaults and sending that flag as a property to enable/disable edit defaults in UI
			boolean isUserEntitledToEditDefaults = this.expagdao.isUserEntitledToFunction(FUNCTION_CATEGORY_EDIT_DEFAULTS, FUNCTION_DESC_ACTION_TYPE, userId);
			properties.getProperties().add(this.expagTaskHelper.addProperty(BigInteger.ONE, PROPERTY_NAME_ENTITLED_TO_EDIT_DEFAULTS, Boolean.valueOf(isUserEntitledToEditDefaults), PROPERTY_DESC_ENTITLED_TO_EDIT_DEFAULTS));
			
			//Adding property to include routing rules
			NameValue routingRulesProperty = this.expagdao.getRoutingRulesForTask(taskId);
			if(routingRulesProperty != null){
				properties.getProperties().add(routingRulesProperty);
			}
			
			cmsTask.setTaskProperties(properties);

			cmsTask.setReasons(this.expagdao.getQCReasons(taskId));
			
			//Calculate the Suspend SLA
			Set<String> taskIds = new HashSet<String>();
			taskIds.addAll(Arrays.asList(new String[] { taskId }));
			List<ExpagStatusHistory> suspendedStatusHistory = this.expagdao.getExpagWorkItemSuspendedHistory(taskIds);
			Map<String, Integer> suspendedDuration = this.expagTaskHelper.calculateSuspendedDuration(suspendedStatusHistory);
			int suspDuration = suspendedDuration.get(cmsTask.getID()) != null ? suspendedDuration.get(cmsTask.getID()) : 0;
			
			SLADetail slaDetail = this.expagTaskHelper.computeSLADetails(cmsTask, suspDuration);

			// Populate Documents
			documents = this.expagDocumentHelper.getDocumentsFromExpagTask(expagTask);

			// Populate comments information
			comments = this.getComments(userId, taskId);

			// Call getWorkpacket
			workPacket = this.powerImageService.getWorkPacketDetails(userId, processId);

			// Populate related task information
			relatedTasks = this.expagTaskHelper.getRelatedTasks(taskId, workPacket);

			process.setProcessId(expagTask.getPktid());
			process.setAppName(APP_EXPAG);
			process.setSLADetail(slaDetail);
			process.setDocuments(documents);

			process.setRelatedTasks(relatedTasks);
			process.setTasks(tasks);

			process.setComments(comments);

			// Lock operator name is need as part of task object
			// process.setLockedBy(expagTask.getLockoper());
			history.getEvents().addAll(expagdao.getExpagProcessHistory(taskId));
			history.getEvents().addAll(expagdao.getCaseWorkersonTask(taskId));
			process.setHistory(history);

		}

		return process;

	}

/*	private Process getIcmProcess(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);

		Case caseResponse = this.icmService.getICMProcess(processId, userId);

		// Converting ICM CASE RESPONSE to CMS RSV Process Response
		Process process = new Process();
		Properties icmProperties = new Properties();

		try {

			String icmResponseJSONString = this.objectMapper.writeValueAsString(caseResponse);
			this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			Case icmCaseResponse = this.objectMapper.readValue(icmResponseJSONString, Case.class);

			Statuses statuses = new Statuses();
			Status status = new Status();

			process.setAppName("ICM");
			process.setProcessId(icmCaseResponse.getId());
			process.setProcessType(icmCaseResponse.getType());
			status.setSts(icmCaseResponse.getStatus());
			statuses.getSts().add(status);
			process.setStatusHistory(statuses);

			// ICM documents Call
			Documents documents = getICMDocuments(processId, userId);
			process.setDocuments(documents);

			// ICM Comments Call
			Comments comments = getComments(request);
			process.setComments(comments);

			// ICM Tasks Call
			Tasks tasks = getTasks(request);
			process.setTasks(tasks);

			NameValue nameValueChannel = new NameValue();
			nameValueChannel.setDesc("channel");
			nameValueChannel.setValue(icmCaseResponse.getChannel());
			icmProperties.getProperties().add(nameValueChannel);

			NameValue nameValuePathName = new NameValue();
			nameValuePathName.setDesc("pathName");
			nameValuePathName.setValue(icmCaseResponse.getPathName());
			icmProperties.getProperties().add(nameValuePathName);

			if (StringUtils.isNotBlank(icmCaseResponse.getCreatedDate())) {
				NameValue nameValueCreatedDateTime = new NameValue();
				nameValueCreatedDateTime.setDesc("createdDate");
				nameValueCreatedDateTime.setDateValue(DateUtil.toXMLGregorianCalendar(DateUtil.parseDateTimeWithoutMilliseconds(icmCaseResponse.getCreatedDate())));

				icmProperties.getProperties().add(nameValueCreatedDateTime);
			}

			if (StringUtils.isNotBlank(icmCaseResponse.getRequestReceivedDate())) {
				NameValue nameValueRequestReceivedDateTime = new NameValue();
				nameValueRequestReceivedDateTime.setDesc("requestReceivedDate");
				nameValueRequestReceivedDateTime.setDateValue(DateUtil.toXMLGregorianCalendar(DateUtil.parseDateTimeWithoutMilliseconds(icmCaseResponse.getRequestReceivedDate())));

				icmProperties.getProperties().add(nameValueRequestReceivedDateTime);
			}

			if (StringUtils.isNotBlank(icmCaseResponse.getModifiedDate())) {
				NameValue nameValueModifiedDateTime = new NameValue();
				nameValueModifiedDateTime.setDesc("modifiedDate");
				nameValueModifiedDateTime.setDateValue(DateUtil.toXMLGregorianCalendar(DateUtil.parseDateTimeWithoutMilliseconds(icmCaseResponse.getModifiedDate())));

				icmProperties.getProperties().add(nameValueModifiedDateTime);
			}

			// Map all the additional identifiers.

			HashMap<String, Object> additionalIdentifiers = icmCaseResponse.getAdditionalIdentifiers();

			if (additionalIdentifiers != null) {

				for (String key : additionalIdentifiers.keySet()) {
					NameValue nameValue = new NameValue();
					nameValue.setDesc(key);
					Object entryValue = additionalIdentifiers.get(key);
					if (String.class.isInstance(entryValue)) {
						nameValue.setValue((String) entryValue);
					} else if (Integer.class.isInstance(entryValue)) {
						((Integer) entryValue).longValue();
						nameValue.getNumValue().add(BigInteger.valueOf(((Integer) entryValue).longValue()));
					} else if (Boolean.class.isInstance(entryValue)) {
						nameValue.setBooleanValue((Boolean) entryValue);
					} else if (Float.class.isInstance(entryValue)) {
						nameValue.setDecimalValue(BigDecimal.valueOf(((Float) entryValue).floatValue()));
					} else if (Date.class.isInstance(entryValue)) {
						nameValue.setDateValue(DateUtil.toXMLGregorianCalendar(((Date) entryValue)));
					} else if (Double.class.isInstance(entryValue)) {
						nameValue.setDecimalValue(BigDecimal.valueOf(((Double) entryValue)));
					}
					icmProperties.getProperties().add(nameValue);
				}

			}
			process.setProcessProperties(icmProperties);

			String solutionName = (String) icmCaseResponse.getAdditionalIdentifiers().get("Solution Name");
			LOGGER.debug("solutionName to get Related Cases is:" + solutionName);
			process.setRelatedTasks(getRelatedCasesICM(processId, userId, solutionName));
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return process;
	}*/

	@Override
	public Documents getDocuments(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		String taskId = (String) request.getAttribute(PROCESS_ID);
		String caseId = (String) request.getAttribute(CASE_ID);
		String appName = (String) request.getAttribute(APP_NAME);

		Documents documents = new Documents();

		if (appName.equalsIgnoreCase(APP_EXPAG)) {

			if (StringUtils.isNotBlank(caseId)) {

				WorkPacket workPacket = this.powerImageService.getWorkPacketDetails(userId, caseId);

				if ((workPacket != null) && (workPacket.getTasks().getCount() > 0)) {

					documents = this.expagDocumentHelper.getDocumentsFromExpagWorkPacket(workPacket, taskId);

				}

			} else if (StringUtils.isNotEmpty(taskId)) {

				org.tiaa.esb.powerimage.types.Task expagTask = this.powerImageService.getTaskDetails(userId, taskId);

				documents = this.expagDocumentHelper.getDocumentsFromExpagTask(expagTask);
			}
		}

		if (appName.equalsIgnoreCase(APP_ICM)) {
			documents = this.getICMDocuments(taskId, userId);
		}

		return documents;
	}

	private Documents getICMDocuments(String processId, String userId) {

		Documents rsvDocuments = new Documents();
		List<Document> rsvDocumentList = new ArrayList<Document>();

		ResponseList icmDocumentsResponse = this.icmService.getICMDocuments(processId, userId);
		List<org.tiaa.esb.icm.types.Document> icmDocumentsList = (List<org.tiaa.esb.icm.types.Document>) icmDocumentsResponse.getResults();
		
		if (icmDocumentsList == null || icmDocumentsList.size() == 0) {
			return rsvDocuments;
		}
		for (Object icmDocumentsResponseJSON : icmDocumentsList) {

			String icmResponseJSONString;
			try {			
				icmResponseJSONString = this.objectMapper.writeValueAsString(icmDocumentsResponseJSON);
	
				org.tiaa.esb.icm.types.EmailDocument icmDocument = this.objectMapper.readValue(icmResponseJSONString, org.tiaa.esb.icm.types.EmailDocument.class);
				
				Document rsvDocument = new Document();
				rsvDocument.setDocBizUnit(icmDocument.getBusinessUnit());
				rsvDocument.setDocTyp(icmDocument.getDocCode());
				rsvDocument.setDocName(icmDocument.getDocumentName());
				rsvDocument.setLgcFold(icmDocument.getFolder());
				rsvDocument.setFrmtTyp(icmDocument.getFormatType());
				
				// Populate EmailAttributes if format type is MobiusEmail
				if(icmDocument.getFormatType()!=null && icmDocument.getFormatType().equalsIgnoreCase(FormatType.MobiusEmail.toString())){
					EmailAttributes emailAttributes = new EmailAttributes();
					FromEmail fromEmail = new FromEmail();
					ToEmail toEmail = new ToEmail();
					
					fromEmail.getEmails().add(icmDocument.getFromEmailAddress());
					toEmail.getEmails().add(icmDocument.getToEmailAddress());
					emailAttributes.setFromEmail(fromEmail);
					emailAttributes.setToEmail(toEmail);
					emailAttributes.setSubj(icmDocument.getSubjectLine());
					rsvDocument.setEmailAttributes(emailAttributes);
					
					if(CommonUtil.isNotNullAndNotEmpty(icmDocument.getSentOn())) {
						rsvDocument.setSentDTTM(DateUtil.toXMLGregorianCalendar(DateUtil.parseDateTimeForMobiusFormat(icmDocument.getSentOn())));
					}
				}
				rsvDocument.setDocID(icmDocument.getId());
				rsvDocument.setDocIDTyp(icmDocument.getIdtype());
				rsvDocument.setMimeTyp(icmDocument.getMimeType());
				rsvDocument.setDocURL(icmDocument.getDocUrl());
					
				if( CommonUtil.isNotNullAndNotEmpty(icmDocument.getVersion())){
					rsvDocument.setDocVrsn(Integer.valueOf(icmDocument.getVersion()));
				}
						
				DocOriginator docOriginator = new DocOriginator();
				docOriginator.setDocOrigName(icmDocument.getCreatedBy());
				rsvDocument.setDocOriginator(docOriginator);
				rsvDocument.setDocCreateDateTime(DateUtil.toXMLGregorianCalendar(DateUtil.parseDateTimeWithMilliseconds(icmDocument.getCreatedDate())));
				
				ProcessID processID = new ProcessID();
				processID.setRqstID(processId);
				rsvDocument.setProcessID(processID);

				rsvDocumentList.add(rsvDocument);
			} catch (JsonGenerationException e) {
				e.printStackTrace();
			} catch (JsonMappingException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		rsvDocuments.getDocuments().addAll(rsvDocumentList);
		return rsvDocuments;
	}

	@Override
	public Document getDocument(Request request) throws JAXBException {

		Document document = new Document();

		String userId = (String) request.getAttribute(USER_ID);
		String docId = (String) request.getAttribute(DOCUMENT_ID);
		String extDocKey = (String) request.getAttribute(EXT_DOC_KEY);
		String appName = (String) request.getAttribute(APP_NAME);
		//Boolean taskXML = (Boolean) request.getAttribute(TASK_XML);

		if (APP_ICM.equalsIgnoreCase(appName)) {
			// getDocumentFromFDRS
			document = this.icmDocumentHelper.getDocument(request);

			// document =
			// this.icmDocumentHelper.getDocumentContentFromFDRS(icmDocument);
			// if not null
			// getDocumentContentFromFDRSDocument

		} else if (StringUtils.isNotEmpty(extDocKey)) {

			byte[] pdfData = this.expagDocumentHelper.getPDFDocument(docId, extDocKey);

			// set the pdf data in the docstream to output
			document.setDocContent(pdfData);

			document.setDocTemplateCd(BASE64BINARY);
			document.setMimeTyp(TEXT_PDF);

			String[] result = docId.split("\\.", 2);
			String newdocumentName = result[0];

			document.setDocContent(pdfData);
			document.setDocName(newdocumentName + ".pdf");
			document.setDocURL(extDocKey);
		}
			
			/*else if (BooleanUtils.isTrue(taskXML)){
		    	     String XMLTaskId = docId.substring(docId.indexOf("t"), docId.indexOf("t")+11);		
					 document = this.expagdao.getXMLDocContentFromDB(XMLTaskId);	
				}*/

		 else {

			for (int retryCnt = 0; retryCnt < this.retryCount; retryCnt++) {

				org.tiaa.esb.powerimage.types.Document expagDocument = this.powerImageService.getDocument(userId, docId);

				if ((expagDocument != null) && (expagDocument.getDocstream() != null) && (expagDocument.getDocstream().getValue() != null)) {
					document = this.expagDocumentHelper.getDocumentContentFromExpagDocument(expagDocument);
					if (document.getDocContent() != null && document.getDocContent().length > 0) {
						break;
					}
				} else {
					try {
						Thread.sleep(3000);
					} catch (Exception exception) {
						LOGGER.error("Unable to put document thread in the sleep mode.");
					}
				}
			}

		}

		return document;

    }

	@Override
	public Document createDocument(Request request) {

		Document document = new Document();
		boolean expUploadStatus = false;
		boolean icmUploadStatus = false;

		String userId = (String) request.getAttribute(USER_ID);
		String taskId = (String) request.getAttribute(PROCESS_ID);
		String caseId = (String) request.getAttribute(CASE_ID);

		DocumentRequest documentRequest = (DocumentRequest) request.getAttribute(DOCUMENT_REQUEST);

		if ((documentRequest != null) && (documentRequest.getDocument() != null)) {
			expUploadStatus = this.expagDocumentHelper.createDocumentInExpag(userId, taskId, caseId, documentRequest.getDocument());
		}
		LOGGER.error("expUploadStatus:" + expUploadStatus);
		LOGGER.error("icmUploadStatus:" + icmUploadStatus);
		if (expUploadStatus) {

			getDocuments(request);
		}

		return document;
	}
	
	
	@Override
	public void updateDocument(Request request) throws Exception {
		String docId = (String) request.getAttribute(DOCUMENT_ID);
		String userId = (String) request.getAttribute(USER_ID);

		DocumentRequest documentRequest = (DocumentRequest) request.getAttribute(DOCUMENT_REQUEST);

		if(documentRequest.getDocument() != null) {
			if (Routing.NOTE.toString().equalsIgnoreCase(documentRequest.getDocument().getDocDirection())) {
				this.expagDocumentHelper.appendNote(userId, docId, documentRequest.getDocument());				
			} else { //should be Corro.. we need to revisit this...We need to ask UW to pass corro type in payload
				this.expagDocumentHelper.updateDocumentInExpag(docId, documentRequest.getDocument());
			}
		}

	}

	@Override
	public Documents createDocuments(Request request) {

		Documents documents = null;
		boolean uploadStatus = false;

		String userId = (String) request.getAttribute(USER_ID);
		String taskId = (String) request.getAttribute(PROCESS_ID);
		String caseId = (String) request.getAttribute(CASE_ID);
		String appName = (String) request.getAttribute(APP_NAME);
		
		String packetId = null;

		DocumentsRequest documentsRequest = (DocumentsRequest) request.getAttribute(DOCUMENTS_REQUEST);
		// List<DocumentSubmission> documentsList = new
		// ArrayList<DocumentSubmission>();
		if ((documentsRequest != null) && (documentsRequest.getDocuments() != null)) {
			for (Document cmsDocument : documentsRequest.getDocuments().getDocuments()) {

				if (APP_EXPAG.equalsIgnoreCase(appName)) {
					if(packetId == null){
						packetId = cmsDocument.getProcessID().getRqstID();
					}
					uploadStatus = expagDocumentHelper.createDocumentInExpag(userId, taskId, caseId, cmsDocument);
				} else if (APP_ICM.equalsIgnoreCase(appName)) {
					uploadStatus = icmDocumentHelper.createDocumentInICM(userId, taskId, caseId, cmsDocument);
				}
			}

			/*
			 * ExecutorService executor
			 * =Executors.newFixedThreadPool(documentsList.size());
			 * List<Future<Boolean>> result = null; try { result =
			 * executor.invokeAll(documentsList); } catch (InterruptedException
			 * e) { // TODO Auto-generated catch block e.printStackTrace();
			 * }finally{ executor.shutdown(); }
			 * java.util.Iterator<Future<Boolean>> iter = result.iterator();
			 * 
			 * boolean finalResponse = false; while(iter.hasNext()){
			 * finalResponse = true; Future<Boolean> current = iter.next(); try
			 * { finalResponse = finalResponse && current.get(); } catch
			 * (InterruptedException | ExecutionException e) {
			 * e.printStackTrace(); } } return finalResponse;
			 */
		}

		if (uploadStatus) {
			if(APP_EXPAG.equalsIgnoreCase(appName)){
				request.setAttribute(CASE_ID, packetId);
			}
			documents = getDocuments(request);
		}
		return documents;

	}

	@Override
	public ConfigItems getConfigItems(Request request) {

		ConfigItems configItems = new ConfigItems();
		ConfigItem configItem = new ConfigItem();

		String property = (String) request.getAttribute(PROPERTY);
		String tableheader = (String) request.getAttribute(TABLE_HEADER);
		String parameter = (String) request.getAttribute(PARAMETER);
		String dept = (String) request.getAttribute(DEPT);
		String parameter1 = null;
		String userId = null;
		String department = null;
		String requestType = null;
		String actionStep = null;
		if (request.getAttribute(DEPT) != null) {
			department = (String) request.getAttribute(DEPT);
		}
		if (request.getAttribute(REQUESTTYPE) != null) {
			requestType = (String) request.getAttribute(REQUESTTYPE);
		}
		if (request.getAttribute(ACTIONSTEP) != null) {
			actionStep = (String) request.getAttribute(ACTIONSTEP);
		}
		if (request.getAttribute(PARAMETER1) != null) {
			parameter1 = (String) request.getAttribute(PARAMETER1);
		}
		
		if (request.getAttribute(USER_ID) != null) {
			userId = (String) request.getAttribute(USER_ID);
		}

		Integer fieldNumber = new Integer(0);
		if (request.getAttribute(FIELDNUMBER) != null) {
			fieldNumber = (Integer) request.getAttribute(FIELDNUMBER);
		}
		Integer idcode = new Integer(0);
		if (request.getAttribute(IDCODE) != null) {
			idcode = (Integer) request.getAttribute(IDCODE);
		}
		if (EXPAG_DEPARTMENTS.equalsIgnoreCase(property) || EXPAG_ALL_DEPARTMENTS.equalsIgnoreCase(property) || EXPAG_INACTIVE_DEPARTMENTS.equalsIgnoreCase(property)|| DEPARTMENT.equalsIgnoreCase(property) || EXPAG_TASK_TYPES.equalsIgnoreCase(property) || EXPAG_ALL_TASK_TYPES.equalsIgnoreCase(property)  || EXPAG_INACTIVE_TASK_TYPES.equalsIgnoreCase(property) || EXPAG_CASE_WORKERS.equalsIgnoreCase(property) 
				|| EXPAG_DOC_CONTENT_TYPES.equalsIgnoreCase(property) || EXPAG_NOTE_TYPES.equalsIgnoreCase(property)) {
			configItem = this.expagdao.getConfigItem(property);           
		} else if (EXPAG_TASK_TYPES_FOR_DEPARTMENT.equalsIgnoreCase(property)) {
			configItem = this.expagdao.getConfigItemWithSubfieldValue(property, StringUtils.rightPad(parameter, 10));
		} else if (EXPAG_CASE_WORKER_FOR_DEPARTMENT.equalsIgnoreCase(property)) {
			configItem = this.expagdao.getConfigItem(property, StringUtils.rightPad(parameter, 10));
		} else if (EXPAG_DEPARTMENTS_FOR_TASK_TYPE.equalsIgnoreCase(property)) {
			configItem = this.expagdao.getConfigItem(property, StringUtils.rightPad(parameter, 10));
		} else if (EXPAG_IDENTIFIERS.equalsIgnoreCase(property) || IDENTIFIERS.equalsIgnoreCase(property)) {
			if (idcode > 0 && fieldNumber > 0) {
				configItem = this.expagdao.getCatalogConfigItemValues(idcode, fieldNumber);
			} else {
				configItem = this.expagdao.getConfigItemWithSubfields(property);
			}

		} else if (EXPAG_NOTE_TEMPLATES.equalsIgnoreCase(property)) {
			configItem = this.expagNoteTemplateHelper.getNoteTemplates(property);
		} else if (EXPAG_DEPARTMENTS_FOR_CASEWORKER.equalsIgnoreCase(property)) {
			configItem = this.expagdao.getConfigItem(property, StringUtils.rightPad(parameter, 8));
		} else if (OMNI_TRANS_TYPE.equalsIgnoreCase(property)) {
			configItem = this.expagdao.getOmniTransTypeConfig(parameter, parameter1);
		} else if (EXPAG_ENTITLED_CASE_WORKERS.equalsIgnoreCase(property)) {
			configItem = this.expagdao.getEntitledCaseWorkers(property, department, requestType, actionStep);
		} else if (EXPAG_ACTIONSTEPS_FOR_TASK_TYPE.equalsIgnoreCase(property)) {
			configItem = this.expagdao.getConfigItem(property, StringUtils.rightPad(requestType, 10));
		} else if (EXPAG_USER_ENTITLED_TO_FUNCTION.equalsIgnoreCase(property)) {
			configItem = this.expagdao.getUserEntitlementToFunction(property, parameter, parameter1, userId);
		} else if (EXPAG_REQUIRED_IDENTIFIERS.equalsIgnoreCase(property)){
			configItem = this.expagdao.getExpagRequiredIdentifiers(property, requestType, actionStep);
		} else if (EXPAG_FIRSTACTIONSTEP_FOR_TASK_TYPE.equalsIgnoreCase(property)){
			configItem = this.expagdao.getConfigItem(property, StringUtils.rightPad(requestType, 10));
		} else if (EXPAG_HELP_VARIABLES.equalsIgnoreCase(property)){
			configItem = this.expagdao.getExpagHelpVariables(property, parameter);
		} else if (EXPAG_HELP_MESSAGES.equalsIgnoreCase(property)){
			configItem = this.expagdao.getExpagHelpMessages(property);
		} else if (EXPAG_HELP_MESSAGES_CODES.equalsIgnoreCase(property)){
			configItem = this.expagdao.getExpagHelpMessagesCodes(property, requestType, actionStep);
		}else if (EXPAG_INSTITUTION_NAMES.equalsIgnoreCase(property)){
			configItem = this.expagdao.getExpagInstitutionNames(property);
		}else if (EXPAG_PLAN_INFO_INSTITUTION_NAME.equalsIgnoreCase(property)){
			configItem = this.expagdao.getExpagPlanInfoInstutionName(property, parameter);
		} else if (EXPAG_ENTITLED_TASK_TYPES.equalsIgnoreCase(property)){
			configItem = this.expagdao.getExpagEntitledTaskTypes(property, userId, department);
		} else if (EXPAG_CORRESPONDENCE_TEMPLATES.equalsIgnoreCase(property)){
			configItem = this.expagdao.getExpagCorresTemplates(property);
		} else if (EXPAG_CORRESPONDENCE_PARAGRAPHS_FOR_TEMPLATE.equalsIgnoreCase(property)){
			configItem = this.expagdao.getExpagCorresParagraphsForTemplate(property,parameter);
		} else if (EXPAG_CORRESPONDENCE_TEMPLATE_PARAGRAPHS_CONTENT.equalsIgnoreCase(property)){
			configItem = this.expagCorrespondenceHelper.getCorresTemplateParagraphsContent(property,parameter,parameter1);
		} else if (EXPAG_CORR_SAVED_INFO.equalsIgnoreCase(property)){
			configItem = this.expagdao.getExpagCorrSavedInfo(property, parameter);
		} else if (EXPAG_FIRSTACTIONSTEP_INTEGRATION_FOR_TASK_TYPE.equalsIgnoreCase(property)){
			configItem = this.expagdao.getConfigItem(property, StringUtils.rightPad(requestType, 10));
		} else if (EXPAG_MOC.equalsIgnoreCase(property)){
			configItem = this.expagdao.getExpagMehtodOfCommunication(property);
		} else if (EXPAG_LOCATION_AND_MAIL_DROP_TIMES.equalsIgnoreCase(property)){
			configItem = this.expagdao.getLocationAndMailDropTimes(property, StringUtils.rightPad(userId, 8));
		} else if (EXPAG_LOCATION_CODE.equalsIgnoreCase(property)){
			configItem = this.expagdao.getLocationCodeBasedOnUserId(property, StringUtils.rightPad(userId, 8));
		} else if( NYSE_HOLIDAYS.equalsIgnoreCase(property)) {
			 configItem = this.expagTaskHelper.getExternalizationCache(property);
		} else if (REQUEST_TYPES.equalsIgnoreCase(property)) {
			try {
				configItem = this.expagdao.getConfigItem(property);
			} catch (Exception exception) {
				LOGGER.error("Config Item Failed For Property" +  property,  exception.getMessage());
			} 
		}
		if (FAIL_TASK_CODES.equalsIgnoreCase(property)) {
			configItem = this.expagdao.getFailCodes(parameter);
		}
		
		
		// added for Entitled Departments	
		if (ENTITLED_DEPARTMENTS.equalsIgnoreCase(property)) {
			try{
				//configItem = this.expagdao.getConfigItem(property, StringUtils.rightPad(parameter, 8));
				configItem = this.expagdao.getConfigItem(property, StringUtils.rightPad(userId.toLowerCase(), 8));
			}catch(Exception e){
				LOGGER.error("Exception while getting "+ property +" from EXPAG -" + e.getMessage());
			}
			getICMEntitledDepartments(configItems, property, userId);
		}
		
		// Add it to the list
		if(configItem.getItemName() != null){
			configItems.getConfigItems().add(configItem);
		}
		// This block will be executed for Config call for any of The ICM config
		// Property
		if (ICM_SOLUTION.equalsIgnoreCase(property) || ICM_CASE_TYPE.equalsIgnoreCase(property) || ICM_CHANNEL.equalsIgnoreCase(property) 
				|| ICM_CASE_STATUS.equalsIgnoreCase(property) || ICM_ALL_CONFIGS.equalsIgnoreCase(property) || ICM_CE_DROPDOWN.equalsIgnoreCase(property)) {
				configItems = getIcmConfigItems(request);		
		} else if (REQUEST_TYPES.equalsIgnoreCase(property) || REQUEST_TYPES_FOR_BUSINESSAREA.equalsIgnoreCase(property)) {
			try {
				configItems = getIcmConfigItems(request);
				configItems.getConfigItems().get(0).getDataPairs().addAll(configItem.getDataPairs());
			} catch (Exception exception) {
				LOGGER.error("ICM config item error message  -" + exception.getMessage(), exception);
			}
		}
		
		//ICM solution Headers
		if (tableheader != null && dept != null){
			if(ICM_SUSPENDED.equalsIgnoreCase(tableheader)){
				tableheader = ICM_PENDED;
			}else if(ICM_ASSIGNED.equalsIgnoreCase(tableheader)){
				tableheader = ICM_ALLASSIGNED;
			}
			
			Configuration configuration = this.icmService.getICMSolutionHeaders(dept, userId,  tableheader);
			configItems = icmConfigHelper.icmConfigurationToSolutionHeadersConfig(configuration);
		}

		// This block will execute to fetch the all config details for EXPAG &
		// ICM
		if (DEPARTMENT.equalsIgnoreCase(property)) {
			Configuration configuration = this.icmService.getICMConfigItem(ICM_SOLUTION);
			configItem = icmConfigHelper.icmConfiguration(configuration, property);
			configItems.getConfigItems().get(0).getDataPairs().addAll(configItem.getDataPairs());
		} 

		return configItems;
	}

	private void getICMEntitledDepartments(ConfigItems configItems,
			String property, String userId) {
		List<String> solutionsList = null;
		try{
			solutionsList = this.icmService.getICMSolutions(ICM_SOLUTION, userId);
		}catch(Exception e){
			LOGGER.error("Exception while getting "+ property +" from ICM -" + e.getMessage());
		}

		if (solutionsList != null && solutionsList.size() > 0) {
			ConfigItem configItemICM = new ConfigItem();
			configItemICM.setItemName(APP_ICM);
			for (String solution : solutionsList) {
				ConfigData configData = new ConfigData();
				configData.setLongDescription(solution);
				configData.setShortDescription(solution);

				configItemICM.getDataPairs().add(configData);
			}
			configItems.getConfigItems().add(configItemICM);
		}
	}

	@Override
	public ConfigItems getIcmConfigItems(Request request) {

		String property = (String) request.getAttribute(PROPERTY);
		String dept = (String) request.getAttribute(DEPT);
		ConfigItems configItems = new ConfigItems();
		ConfigItem configItem = new ConfigItem();

		if (ICM_SOLUTION.equalsIgnoreCase(property)) {

			Configuration configuration = this.icmService.getICMConfigItem(property);
			configItem = icmConfigHelper.icmConfiguration(configuration, property);
			configItems.getConfigItems().add(configItem);

		} else if (ICM_CASE_TYPE.equalsIgnoreCase(property) || REQUEST_TYPES.equalsIgnoreCase(property)) {
			
			Configuration configuration = this.icmService.getICMConfigItem(ICM_CASE_TYPE);
			configItem = icmConfigHelper.icmConfiguration(configuration, property);
			configItems.getConfigItems().add(configItem);
		} else if (REQUEST_TYPES_FOR_BUSINESSAREA.equalsIgnoreCase(property)) {
			
			Configuration configuration = this.icmService.getICMRequestTypesForBA(property, dept);
			configItem = icmConfigHelper.icmConfiguration(configuration, property);
			configItems.getConfigItems().add(configItem);
		} else if (ICM_CHANNEL.equalsIgnoreCase(property)) {
			Configuration configuration = this.icmService.getICMConfigItem(property);
			configItem = icmConfigHelper.icmConfiguration(configuration, property);
			configItems.getConfigItems().add(configItem);
		} else if (ICM_CASE_STATUS.equalsIgnoreCase(property)) {
			Configuration configuration = this.icmService.getICMConfigItem(property);
			configItem = icmConfigHelper.icmConfiguration(configuration, property);
			configItems.getConfigItems().add(configItem);
		} else if (ICM_ALL_CONFIGS.equalsIgnoreCase(property)) {
			Configuration configuration = this.icmService.getICMConfigItem("all");
			configItems = icmConfigHelper.icmConfigurationToAllConfigItems(configuration);

		} else if (ICM_CE_DROPDOWN.equalsIgnoreCase(property)) {
			Configuration configuration = this.icmService.getICMConfigItem(property);
			configItems = icmConfigHelper.icmConfigurationToCEDropDowns(configuration);
			
		}
		
		return configItems;
	}
	
	@Override
	public Process createProcess(Request request) {

		Process process = new Process();

		org.tiaa.esb.powerimage.createtask.types.WorkPacket expagWorkPacket = new org.tiaa.esb.powerimage.createtask.types.WorkPacket();

		String userId = (String) request.getAttribute(USER_ID);
		ProcessRequest processRequest = (ProcessRequest) request.getAttribute(PROCESS_REQUEST);

		Task cmsTask = new Task();
		Process cmsProcess = new Process();
		
		if ((processRequest != null) && (processRequest.getProcess() != null) && (processRequest.getProcess().getTasks() != null) && !(processRequest.getProcess().getTasks().getTasks().isEmpty())) {

			cmsTask = processRequest.getProcess().getTasks().getTasks().get(0);
			cmsProcess = processRequest.getProcess();
		}

		expagWorkPacket = this.expagTaskHelper.cmsTasktoExpagWork(userId, cmsTask,cmsProcess.getDocuments());

		// Call the service method and create the new task
		PIAcknowledge expagAck = this.powerImageService.createWorkEx(userId, expagWorkPacket);

		String expagTaskId = null;

		if ((expagAck != null) && (expagAck.getAcknowledges() != null)) {
			for (org.tiaa.esb.powerimage.types.PIAcknowledge.Acknowledge acknowledge : expagAck.getAcknowledges()) {

				if ((acknowledge != null)) {

					if (acknowledge.getErrorcode() != 0) {
						LOGGER.error(acknowledge.getErrordesc());
					}

					if (StringUtils.isNotBlank(acknowledge.getTaskid())) {
						expagTaskId = acknowledge.getTaskid();
					} else {
						throw new WorkflowException(acknowledge.getErrordesc());
					}
				}

			}
		}

		if (StringUtils.isNotBlank(expagTaskId)) {
			Tasks tasks = new Tasks();
			Task task = new Task();
			task.setID(expagTaskId);
			tasks.getTasks().add(task);
			process.setTasks(tasks);
		}

		return process;
	}

	@Override
	public Processes createProcesses(Request request) {

		Task cmsTask = new Task();
		WorkItemsCreationStatus creationStatus = new WorkItemsCreationStatus();

		org.tiaa.esb.powerimage.createtask.types.WorkPacket expagWorkPacket = new org.tiaa.esb.powerimage.createtask.types.WorkPacket();

		String userId = (String) request.getAttribute(USER_ID);
		ProcessesRequest processesRequest = (ProcessesRequest) request.getAttribute(PROCESSES_REQUEST);
		
		Processes processes = new Processes();

		PIAcknowledge expagAck = null;
		String batchNo = null;
		String batchSeqNumber = null;
		String locCode = null;
		String currentDate = null;

		if ((processesRequest != null) && (processesRequest.getProcesses() != null) && (processesRequest.getProcesses().getProcesses() != null)) {
			List<Process> processesList = processesRequest.getProcesses().getProcesses();
			Process process = processesList.get(0);
			Documents cmsDocuments = process.getDocuments();

			if (null != processesList && !processesList.isEmpty()) {

				cmsTask = processesList.get(0).getTasks().getTasks().get(0);
				
				//For Prep-Sheet, creating batch no identifier
				if(DOMAIN_TYPE_PREPSHEET.equalsIgnoreCase(cmsTask.getDomain())) {
					cmsTask.setType(PREPSHEET_ARCHIVE_TASK_TYPE);
					Properties properties = cmsTask.getTaskProperties();
					if(properties != null && properties.getProperties() != null && properties.getProperties().size() > 0){
						List<NameValue> identifiers = properties.getProperties();
						for(NameValue identifier : identifiers){
							if(EXPAG_IDENTIFIER_IMAGE_SITE.equalsIgnoreCase(identifier.getDesc())){
								List<NameValue> childNameVlaues = identifier.getChildrenNameValues();
								if(childNameVlaues != null && childNameVlaues.size() > 0){
									currentDate = DateUtil.today();
									locCode = childNameVlaues.get(0).getValue();
									String nextSeqNumber = this.expagdao.getNextBatchInfoSequenceNumber(locCode, currentDate);
									batchSeqNumber = StringUtils.leftPad(nextSeqNumber, 7, '0');
									batchNo = locCode + currentDate + batchSeqNumber;
								}
								break;
							}
						}
					}
					
					cmsTask.getTaskProperties().getProperties().add(this.expagTaskHelper.addProperty(BigInteger.ONE, EXPAG_IDENTIFIER_BATCH_NO, batchNo, EXPAG_IDENTIFIER_BATCH_NO));
				}
					expagWorkPacket = this.expagTaskHelper.cmsTasktoExpagWork(userId, cmsTask, cmsDocuments);
				// Call the service method and create the new task
				expagAck = this.powerImageService.createWorkEx(userId, expagWorkPacket);

				if (processesList.size() > 1) {
					request.setAttribute(CASE_ID, expagAck.getPktid());
					// This Call will create the List of workItems to the Parent
					// task Packet Id
					String relTasksCreationStatusMessage = createRelatedWorkItems(request);
					creationStatus.setRelTasksCreationStatusMessage(relTasksCreationStatusMessage);
				}
			}
		}

		String expagTaskId = null;
		if ((expagAck != null) && (expagAck.getAcknowledges() != null)) {

			if (StringUtils.isNotBlank(expagAck.getAcknowledges().get(0).getTaskid())) {
				if(DOMAIN_TYPE_PREPSHEET.equalsIgnoreCase(cmsTask.getDomain()) && batchNo != null){
					this.expagdao.insertBatchInfo(locCode, currentDate, batchSeqNumber);
				}
				expagTaskId = expagAck.getAcknowledges().get(0).getTaskid();
				creationStatus.setParentWorkItemId(expagTaskId);
			} else {
				throw new WorkflowException(expagAck.getAcknowledges().get(0).getErrordesc());
			}
		}
		
		org.tiaa.case_management_rs.common.Request taskRequest = new RequestImpl();

		// Get all the request parameter string values
		taskRequest.setAttribute(USER_ID, request.getAttribute(USER_ID));
		//The Parent task Id will be come from Response
		taskRequest.setAttribute(PROCESS_ID, creationStatus.getParentWorkItemId());

		taskRequest.setAttribute(IS_NEW_TASK, TRUE);
		taskRequest.setAttribute(APP_NAME, request.getAttribute(APP_NAME));

		if (creationStatus.getParentWorkItemId() != null){
			if(null != creationStatus.getRelTasksCreationStatusMessage() && !creationStatus.getRelTasksCreationStatusMessage().equalsIgnoreCase("SUCCESS")){
				//processesResponse = ResponseObjectFactory.createProcessesResponse("INFO", creationStatus.getRelTasksCreationStatusMessage());
			}else{
				//processesResponse = ResponseObjectFactory.createProcessesResponse(SUCCESS, SUCCESS_TEXT);
			}
			List<Process> newProcesses = new ArrayList<Process>();
			Process process = this.getProcess(taskRequest);
			newProcesses.add(process);
			if(process != null && process.getRelatedTasks() != null && process.getRelatedTasks().getRelatedTasks() != null){
				List<Task> relatedTasks = process.getRelatedTasks().getRelatedTasks();
				for(Task task:relatedTasks){
					Process prc = new Process();
					Tasks tasks = new Tasks();
					Task tsk = new Task();
					tsk.setID(task.getID());
					tasks.getTasks().add(tsk);
					prc.setTasks(tasks);
					newProcesses.add(prc);
				}
			}
			processes.getProcesses().addAll(newProcesses);
			
		}else {
			//processesResponse = ResponseObjectFactory.createProcessesResponse(FAILURE, FAILURE_TEXT);
			LOGGER.error("ParentWorkItemId is null, no EXPAG Task created.");
		}

		return processes;
	}

	/**
	 * Callable for assignment of task
	 * 
	 * @author nistala
	 *
	 */
	private class AssignedTask implements Callable<Process> {
		private Process process;
		private String userId;

		public AssignedTask(Process process, String userId) {
			this.process = process;
			this.userId = userId;
		}

		@Override
		public Process call() throws Exception {

			String taskId = process.getTasks().getTasks().get(0).getID();
			String lockInd = LOCK_INDICATOR_NO;
			try {

				org.tiaa.esb.powerimage.types.ProcessTask processExpagTask = null;
				org.tiaa.esb.powerimage.types.GetWorkItem getWorkItem = null;

				org.tiaa.esb.powerimage.types.Task expagTask = powerImageService.getTaskDetails(userId, taskId);
				String assignedOperator = process.getTasks().getTasks().get(0).getAssignedTo();
				
				if(expagTask != null && StringUtils.isNotBlank(expagTask.getExcoper()) && assignedOperator.equalsIgnoreCase(expagTask.getExcoper())){
					throw new WorkflowException("Operator " + userId + " is an excluded operator from processing the task.");
				}
				
				if ((expagTask != null) && (StringUtils.isNotBlank(expagTask.getLockoper()) || (StringUtils.isNotBlank(expagTask.getSuspoper())))) {

					if (userId.equalsIgnoreCase(expagTask.getLockoper())) {
						lockInd = LOCK_INDICATOR_YES;
						taskId = expagTask.getTaskid();
						LOGGER.debug("Successfully obtained the lock on the expag task." + taskId);
					}

				} else {
					getWorkItem = powerImageService.getWorkItem(userId, taskId, expagTask.getLasthistdate().toGregorianCalendar());
					org.tiaa.esb.powerimage.types.Task lockedExpagTask = getWorkItem.getTask();
					lockInd = LOCK_INDICATOR_YES;
					taskId = lockedExpagTask.getTaskid();
				}

				processExpagTask = expagProcessTaskHelper.constructAssignRequest(process.getTasks().getTasks().get(0), expagTask);
				//TO DO - Check this logic 
				// lockInd = LOCK_INDICATOR_NO;
				if (StringUtils.isNotBlank(expagTask.getLockoper())) {
					processExpagTask.setLockoper(expagTask.getLockoper());
				}
				processExpagTask.setPktid(process.getProcessId());
				processExpagTask.setDatereceived(getWorkItem != null ? getWorkItem.getTask().getDatereceived() : expagTask.getDatereceived());
				processExpagTask.setTimereceived(getWorkItem != null ? getWorkItem.getTask().getTimereceived() : expagTask.getTimereceived());
				processExpagTask.setPistartdate(DateUtil.getCurrentESTDate());
				processExpagTask.setPistarttime(DateUtil.getCurrentESTTime());
				
				if (processExpagTask != null) {
					org.tiaa.esb.powerimage.types.ProcessTaskResult updateResult = powerImageService.processTaskEx(userId, processExpagTask);
					if (updateResult.getErrorcode() == 0) {
						taskId = updateResult.getTaskid();
					} else {
						throw new WorkflowException(updateResult.getErrordesc());
					}
				}
				return process;
			} catch (Exception exception) {
				lockInd = LOCK_INDICATOR_UNLOCK;
				Process failedProcess = new Process();
				Tasks tasks = new Tasks();
				Task failedTask = new Task();
				failedTask.setID(taskId);
				tasks.getTasks().add(failedTask);
				failedProcess.setTasks(tasks);
				failedProcess.setAppName(process.getAppName());
				failedProcess.setProcessId(process.getProcessId());

				return failedProcess;
			} finally {
				if (LOCK_INDICATOR_UNLOCK.equalsIgnoreCase(lockInd)) {
					powerImageService.unlockTask(userId, taskId, null);
					lockInd = LOCK_INDICATOR_UNLOCK;
				}
			}
		}
	}
	
	/**
	 * Callable for suspend of task
	 * 
	 * @author 
	 *
	 */
	private class SuspendTask implements Callable<Process> {
		private Process process;
		private String userId;

		public SuspendTask(Process process, String userId) {
			this.process = process;
			this.userId = userId;
		}
		
		@Override
		public Process call() throws Exception {
			
			String taskId = null;
			String lockInd = LOCK_INDICATOR_NO;
			
			try{
				org.tiaa.esb.powerimage.types.ProcessTask processExpagTask = null;
				org.tiaa.esb.powerimage.types.Task expagTask = null;
				org.tiaa.esb.case_management_rs_v2.type.Task cmsTask=null;
				org.tiaa.esb.powerimage.types.GetWorkItem getWorkItem = null;
				
				if(!CommonUtil.isNull(process.getTasks().getTasks().get(0))){
					cmsTask=process.getTasks().getTasks().get(0);
					taskId=cmsTask.getID();
				}	
				expagTask = powerImageService.getTaskDetails(userId, taskId);		
				
				if(expagTask != null && StringUtils.isNotBlank(expagTask.getExcoper())&& userId.equalsIgnoreCase(expagTask.getExcoper())){
					throw new WorkflowException("Operator " + userId + " is an excluded operator from processing the task.");
				}
				if(StringUtils.isBlank(expagTask.getSuspoper()) && StringUtils.isBlank(expagTask.getLockoper())){
				
					if (expagTask != null){
						getWorkItem = powerImageService.getWorkItem(userId, taskId, expagTask.getLasthistdate().toGregorianCalendar());
						org.tiaa.esb.powerimage.types.Task lockedExpagTask = getWorkItem.getTask();
						lockInd = LOCK_INDICATOR_UNLOCK;
						taskId = lockedExpagTask.getTaskid();
					}
				}
				else{
					throw new WorkflowException(taskId+ ": is either suspended or locked.");	
				}				
				
				processExpagTask = expagProcessTaskHelper.constructSuspendRequest(cmsTask,expagTask);

				processExpagTask.setPktid(process.getProcessId());

				if (StringUtils.isNotBlank(expagTask.getLockoper())) {
					processExpagTask.setLockoper(expagTask.getLockoper());
				}
				else {
					processExpagTask.setLockoper(userId);
				}

				processExpagTask.setDatereceived(expagTask.getDatereceived());
				processExpagTask.setTimereceived(expagTask.getTimereceived());
				processExpagTask.setPistartdate(DateUtil.getCurrentESTDate());
				processExpagTask.setPistarttime(DateUtil.getCurrentESTTimeIncludingMilliSec());

				if (processExpagTask != null) {			
					org.tiaa.esb.powerimage.types.ProcessTaskResult updateResult = powerImageService.processTaskEx(userId, processExpagTask);

					// Write a mechanism to handle the error cases
					if (updateResult.getErrorcode() == 0) {
						taskId = updateResult.getTaskid();
						process.getTasks().getTasks().get(0).setAwakeDate(processExpagTask.getWakedate());
					} else {
						throw new WorkflowException(updateResult.getErrordesc());
					}			
			}
				return process;
			}catch (Exception exception) {
				Process failedProcess = new Process();
				lockInd = LOCK_INDICATOR_UNLOCK;
				Tasks tasks = new Tasks();
				Task failedTask = new Task();
				failedTask.setID(taskId);
				tasks.getTasks().add(failedTask);
				failedProcess.setTasks(tasks);
				failedProcess.setAppName(process.getAppName());
				failedProcess.setProcessId(process.getProcessId());
				return failedProcess;
			}finally {
				if (LOCK_INDICATOR_UNLOCK.equalsIgnoreCase(lockInd)) {
					powerImageService.unlockTask(userId, taskId, null);
				}
			}
		}
	}

	@Override
	public Processes updateProcesses(Request request) throws Exception {
		String userId = (String) request.getAttribute(USER_ID);
		String action = (String) request.getAttribute(ACTION);
		Processes returnProcesses = new Processes();
		int numberOfAssignedTasks = 0;
		int numberOfFailedTasks = 0;
		int numberOfSuspendedTasks =0;

		if ("assign".equalsIgnoreCase(action)) {

			final List<Callable<Process>> callables = new ArrayList<Callable<Process>>();
			ProcessesRequest processRequest = (ProcessesRequest) request.getAttribute(PROCESSES_REQUEST);

			int sizeOfProcesses = processRequest.getProcesses().getProcesses().size();

			for (Process process : processRequest.getProcesses().getProcesses()) {
				callables.add(new AssignedTask(process, userId));
			}

			// #TODO for multiple assignment, change thread pool accordingly to
			// sizeOfProcesses
			// ExecutorService executor = Executors.newFixedThreadPool(1);
			ExecutorService executor = Executors.newFixedThreadPool(maxBulkAssignmentThreadPoolSize);
			Process processedProcess;
			try {
				/*
				 * Future<Process> results =
				 * executor.invokeAll(callables).get(0); results.get();
				 */
				// #TODO for multiple assignment
				// List<Process> processesList = returnProcesses.getProcesses();
				for (Future<Process> results : executor.invokeAll(callables)) {
					processedProcess = results.get();
					returnProcesses.getProcesses().add(processedProcess);
				}

				// iterator To get the count of success and failure.

				Iterator<Process> iterator = returnProcesses.getProcesses().iterator();

				while (iterator.hasNext()) {
					Process process = iterator.next();
					String assignedOperator = process.getTasks().getTasks().get(0).getAssignedTo();
					if (assignedOperator != null) {
						++numberOfAssignedTasks;
						iterator.remove();
					} else {
						++numberOfFailedTasks;
					}
				}

				if (numberOfFailedTasks == sizeOfProcesses) {
					// If all task assignment fails
					throw new WorkflowException("All Task Assigment Failed");
				} else if (numberOfAssignedTasks == sizeOfProcesses) {
					// If all task assignment success then simple showing success message instead of rendering all processes in the response
					returnProcesses.getProcesses().clear();
				}

			} catch (ExecutionException exception) {
				Throwable throwable = exception.getCause();
				if (throwable instanceof WorkflowException) {
					String message = throwable.getMessage();
					throw new WorkflowException(message);

				}
			} finally {
				if (executor != null) {
					executor.shutdown();
				}
			}
		}else if (EXPAG_STATUS_DESC_SUSPEND.equalsIgnoreCase(action)){
			
			final List<Callable<Process>> callables = new ArrayList<Callable<Process>>();
			ProcessesRequest processRequest = (ProcessesRequest) request.getAttribute(PROCESSES_REQUEST);

			int sizeOfProcesses = processRequest.getProcesses().getProcesses().size();

			for (Process process : processRequest.getProcesses().getProcesses()) {
				callables.add(new SuspendTask(process, userId));
			}
			
			ExecutorService executor = Executors.newFixedThreadPool(maxBulkSuspensionThreadPoolSize);
			Process processedProcess;
			try {
				for (Future<Process> results : executor.invokeAll(callables)) {
					processedProcess = results.get();
					returnProcesses.getProcesses().add(processedProcess);
				}

				// iterator To get the count of success and failure.
				Iterator<Process> iterator = returnProcesses.getProcesses().iterator();

				while (iterator.hasNext()) {
					Process process = iterator.next();
					if (process.getTasks().getTasks().get(0).getAwakeDate()!=null) {
						++numberOfSuspendedTasks;
						iterator.remove();
					} else {
						++numberOfFailedTasks;
					}
				}
				
				if (numberOfFailedTasks == sizeOfProcesses) {
					// If all task suspension fails
					returnProcesses=null;
				} else if (numberOfSuspendedTasks == sizeOfProcesses) {
					// If all task suspension success then simple showing success message instead of rendering all processes in the response
					returnProcesses.getProcesses().clear();
				}

			}catch(ExecutionException e){
				Throwable throwable = e.getCause();
				if (throwable instanceof WorkflowException) {
					String message = throwable.getMessage();
					throw new WorkflowException();
				}
			}
			finally {
				if (executor != null) {
					executor.shutdown();
				}
			}
		
		}
		return returnProcesses;
	}
	@Override
	public Process updateProcess(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		String taskId = (String) request.getAttribute(PROCESS_ID);
		String useIdentifiersId = request.getAttribute(USE_IDENTIFIERS_ID) != null ? String.valueOf(request.getAttribute(USE_IDENTIFIERS_ID)) : FALSE;
		
		ProcessRequest processRequest = (ProcessRequest) request.getAttribute(PROCESS_REQUEST);

		Process process = new Process();

		boolean unlock = true;

		try {

			if ((processRequest != null) && (processRequest.getProcess() != null)) {

				org.tiaa.esb.powerimage.types.ProcessTask processExpagTask = null;

				org.tiaa.esb.powerimage.types.Task expagTask = null;

				if ((processRequest.getProcess() != null) && processRequest.getProcess().getTasks() != null) {

					Task cmsTask = processRequest.getProcess().getTasks().getTasks().get(0);

					String action = cmsTask.getAction().getItems().get(0);

					if (StringUtils.isNotBlank(action)) {

						if (ACTION_UNLOCK.equalsIgnoreCase(action)) {
								// if the task action item is "unlock" from request  then unlocking the task from expag by passing userid&taskid
								this.powerImageService.unlockTask(userId, taskId, null);
								unlock = false;
							
						} else {
							expagTask = this.powerImageService.getTaskDetails(userId, taskId);
							
							// task couldn't be assigned to excluded operator for "Save & Close" option and For edit defaults when action step has not been changed
							if(action.equalsIgnoreCase(EXPAG_STATUS_DESC_NONE) && StringUtils.isNotBlank(cmsTask.getAssignedTo()) && cmsTask.getAssignedTo().equalsIgnoreCase(expagTask.getExcoper())) {
								if(StringUtils.isBlank(cmsTask.getActionStep()) || (StringUtils.isNotBlank(cmsTask.getActionStep()) && cmsTask.getActionStep().equalsIgnoreCase(expagTask.getActiondesc()))){
									throw new WorkflowException(taskId+" cannot be assigned to excluded operator "+ cmsTask.getAssignedTo()+".");
								}
							}
							
							if (!EXPAG_STATUS_DESC_UNSUSPEND.equalsIgnoreCase(action)) {
								processExpagTask = this.expagProcessTaskHelper.constructCommonRequest(processRequest, expagTask, action, useIdentifiersId, userId);
							}

							if (EXPAG_STATUS_DESC_SUSPEND.equalsIgnoreCase(action)) {
								processExpagTask.setWakedate(cmsTask.getCompleteDate());
								processExpagTask.setWaketime(cmsTask.getCompleteTime());
								processExpagTask.setWakeoper(cmsTask.getAssignedTo());

							} else if (EXPAG_STATUS_DESC_UNSUSPEND.equalsIgnoreCase(action)) {
								this.powerImageService.releaseTask(userId, taskId, true);
								unlock = false;
								processExpagTask = this.expagProcessTaskHelper.constructUnsuspendRequest(processRequest);
							} else if (EXPAG_STATUS_DESC_REVIEW.equalsIgnoreCase(action)) {
								processExpagTask.setReviewoper(cmsTask.getAssignedTo());
							} else if (EXPAG_STATUS_DESC_FAIL.equalsIgnoreCase(action)) {
								processExpagTask = this.expagProcessTaskHelper.constructFailRequest(processRequest, processExpagTask);

							}

							if (EXPAG_STATUS_DESC_REVIEW2.equalsIgnoreCase(action) || EXPAG_STATUS_DESC_REINDEX.equalsIgnoreCase(action) || EXPAG_STATUS_DESC_AUTHORIZE.equalsIgnoreCase(action) || EXPAG_STATUS_DESC_MODIFIED.equalsIgnoreCase(action) || EXPAG_STATUS_DESC_PROCESS.equalsIgnoreCase(action) || EXPAG_STATUS_DESC_REJECT.equalsIgnoreCase(action) || EXPAG_STATUS_DESC_UNSUSPEND.equalsIgnoreCase(action) || EXPAG_STATUS_DESC_FAIL.equalsIgnoreCase(action)) {

								if (StringUtils.isNotBlank(cmsTask.getAssignedTo())) {
									processExpagTask.setWrkbskt(cmsTask.getAssignedTo());
								} else if (StringUtils.isNotBlank(expagTask.getWorkbasket())) {
									processExpagTask.setWrkbskt(expagTask.getWorkbasket());
								}

							}

							if (StringUtils.isNotBlank(expagTask.getLockoper())) {
								processExpagTask.setLockoper(expagTask.getLockoper());
							}
								
							processExpagTask.setPistartdate(DateUtil.getCurrentESTDate());
							processExpagTask.setPistarttime(DateUtil.getCurrentESTTimeIncludingMilliSec());

							if (processExpagTask != null) {
								
								// Getting already existed identifier's value from expag
								List<TaskIdentifiersValue> entites = this.expagdao.getTaskIdentifiersValue(taskId);
								
								org.tiaa.esb.powerimage.types.ProcessTaskResult updateResult = this.powerImageService.processTaskEx(userId, processExpagTask);

								// Write a mechanism to handle the error cases
								if (updateResult.getErrorcode() == 0) {
									
									//Routing rule method call
									if (!EXPAG_STATUS_DESC_UNSUSPEND.equalsIgnoreCase(action)) {
										if(StringUtils.isNotBlank(cmsTask.getType()) && (!cmsTask.getType().equals(expagTask.getTasktype()))){
											this.expagdao.getRoutingRuleAlgorithm(userId, taskId);
										} else {
											this.expagTaskHelper.triggerRoutingRule(userId, taskId, cmsTask, entites);
										}
									}
									
									//if it is Edit Defaults
									if(StringUtils.isNotBlank(cmsTask.getActionStep())){
										handleEditDefaultsInDB(taskId,processExpagTask, expagTask,cmsTask, action);
										if(StringUtils.isNotBlank(cmsTask.getAssignedTo()) && cmsTask.getAssignedTo().equalsIgnoreCase(expagTask.getExcoper())){
											this.expagdao.removeExcludedOperFromTask(taskId);
										}
									}
									taskId = updateResult.getTaskid();
								} else {
									throw new WorkflowException(updateResult.getErrordesc());
								}

							}
						}
					}
				}
			}
		} finally {

			// If the process is not successful make an attempt to unlock the
			// task
			if (unlock) {
				this.powerImageService.unlockTask(userId, taskId, null);
			}
		}

		return process;

	}

	private void handleEditDefaultsInDB(String tskId,
			org.tiaa.esb.powerimage.types.ProcessTask processExpagTask,
			org.tiaa.esb.powerimage.types.Task expagTask, Task cmsTask,
			String action) {
		
		String workBasket = "";
		int actionCode = -1;
		
		String existingAction = expagTask.getActiondesc() == null ? "" : expagTask.getActiondesc();
		String newAction = processExpagTask.getActiondesc() == null ? "" : processExpagTask.getActiondesc();

		String existingWrkBasket = expagTask.getWorkbasket() == null ? "" : expagTask.getWorkbasket();
		String newWorkBasket = processExpagTask.getWrkbskt() == null ? "" : processExpagTask.getWrkbskt();
		
		Integer priority = expagTask.getPriority() == null ?  -1 : expagTask.getPriority();

		if (!existingAction.equalsIgnoreCase(newAction)) {
			actionCode = 1;
		}

		if (!existingWrkBasket.equalsIgnoreCase(newWorkBasket)) {
			workBasket = processExpagTask.getWrkbskt();
		}

		String piDate = DateUtil.toFormat(processExpagTask.getPistartdate(), "yyyyMMdd");
		String startTime = DateUtil.toFormat(processExpagTask.getPistarttime(), "HHmmssSSS");

		startTime = startTime.substring(0, startTime.length() - 1);

		expagdao.updateExpagTskHist(tskId, piDate, startTime);
		expagdao.insertTskHistEditDefault(tskId, piDate, startTime, actionCode,
				workBasket, priority);

	}

	@Override
	public Processes doSearch(Request request) throws Exception{

		return doDatabaseSearch(request);
	}

	private Comments getComments(String userId, String taskId) {

		Comments cmsComments = new Comments();

		org.tiaa.esb.powerimage.types.Comments expagComments = this.powerImageService.viewComments(userId, taskId);

		if ((expagComments != null) && (expagComments.getCount() > 0)) {
			for (org.tiaa.esb.powerimage.types.Comment expagComment : expagComments.getComments()) {
				Comment cmsComment = new Comment();
				cmsComment.setCreateDate(expagComment.getCreatedate());
				cmsComment.setCreateTime(expagComment.getCreatetime());
				cmsComment.setCreateOper(expagComment.getCreateoper());
				// cmsComment.setCommentDesc(expagComment.getComment());
				cmsComment.setDesc(expagComment.getComment());
				cmsComments.getComments().add(cmsComment);
			}
		}

		return cmsComments;
	}

	@Override
	public Process createRelatedTask(Request request) {

		Process process = new Process();

		org.tiaa.esb.powerimage.types.AddTasksToPacket expagTasksPacket = new org.tiaa.esb.powerimage.types.AddTasksToPacket();

		String userId = (String) request.getAttribute(USER_ID);
		String caseId = (String) request.getAttribute(CASE_ID);
		String appName = (String) request.getAttribute(APP_NAME);
		String processId = (String) request.getAttribute(PROCESS_ID);
		String type = (String) request.getAttribute(TYPE);
		ProcessRequest processRequest = (ProcessRequest) request.getAttribute(PROCESS_REQUEST);

		Task cmsTask = new Task();
		if ((null != processRequest) && (null != processRequest.getProcess()) && (null != processRequest.getProcess().getTasks()) && !(processRequest.getProcess().getTasks().getTasks().isEmpty())) { // (workItemRequest
			cmsTask = processRequest.getProcess().getTasks().getTasks().get(0);
		}

		expagTasksPacket = this.expagTaskHelper.cmsTasktoExpagRelatedTask(userId, caseId, cmsTask, type);

		// Call the service method and create the new task
		PIAcknowledge expagAck = this.powerImageService.addTasksToPacket(userId, expagTasksPacket);

		String expagTaskId = null;

		if ((expagAck != null) && (expagAck.getAcknowledges() != null)) {
			for (org.tiaa.esb.powerimage.types.PIAcknowledge.Acknowledge acknowledge : expagAck.getAcknowledges()) {

				if ((acknowledge != null)) {

					if (acknowledge.getErrorcode() != 0) {
						LOGGER.error(acknowledge.getErrordesc());
					}

					if (StringUtils.isNotBlank(acknowledge.getTaskid())) {
						expagTaskId = acknowledge.getTaskid();
					} else {
						throw new WorkflowException(acknowledge.getErrordesc());
					}
				}

			}
		}

		if (StringUtils.isNotBlank(expagTaskId)) {

			// call the work item to get the task back
			org.tiaa.case_management_rs.common.Request taskRequest = new RequestImpl();

			// Get all the request parameter string values
			taskRequest.setAttribute(USER_ID, userId);
			taskRequest.setAttribute(PROCESS_ID, processId);
			taskRequest.setAttribute(APP_NAME, appName);
			taskRequest.setAttribute(IS_NEW_TASK, FALSE);
			process = this.getProcess(taskRequest);

			if (process != null && process.getTasks() != null && process.getTasks().getTasks() != null) {
				org.tiaa.esb.case_management_rs_v2.type.Properties properties = process.getTasks().getTasks().get(0).getTaskProperties();
				NameValue parentNameValue = new NameValue();
				parentNameValue.setDesc(NEW_RELATED_TASK_ID);

				NameValue childNameValue = new NameValue();
				childNameValue.setDsplSqncNbr(BigInteger.valueOf(1));
				childNameValue.setName(NEW_RELATED_TASK_ID);
				childNameValue.setValue(expagTaskId);

				parentNameValue.getChildrenNameValues().add(childNameValue);
				properties.getProperties().add(parentNameValue);

				process.getTasks().getTasks().get(0).setTaskProperties(properties);
			}

		}

		return process;
	}

	private String createRelatedWorkItems(Request request) {

		org.tiaa.esb.powerimage.types.AddTasksToPacket expagTasksPacket = new org.tiaa.esb.powerimage.types.AddTasksToPacket();

		String userId = (String) request.getAttribute(USER_ID);
		String caseId = (String) request.getAttribute(CASE_ID);
		String relatedTaskCreationStatus = "SUCCESS";

		ProcessesRequest processesRequest = (ProcessesRequest) request.getAttribute(PROCESSES_REQUEST);

		if ((processesRequest != null) && (processesRequest.getProcesses() != null) && (processesRequest.getProcesses().getProcesses() != null)) {

			List<Process> processList = processesRequest.getProcesses().getProcesses();
			expagTasksPacket = this.expagTaskHelper.cmsTasktoExpagRelatedTask(userId, caseId, processList);
		}

		// Call the service method and create the new tasks as related tasks to
		// the ParentTask
		try {
			this.powerImageService.addTasksToPacket(userId, expagTasksPacket);
		} catch (Exception e) {
			relatedTaskCreationStatus = "Create Parent Task was a success but related tasks were not. " + e.getMessage();
			return relatedTaskCreationStatus;
		}
		return relatedTaskCreationStatus;
	}

	@Override
	public Metrics getMetrics(Request request) {

		String userId = (String) request.getAttribute(USER_ID );
		String department = (String) request.getAttribute(SOLUTION_NAME);
		Metrics metrics = this.expagdao.getMetrics(department, userId);
		return metrics;
	}

	/**
	 * returns Processes based upon the different search criteria.
	 * 
	 * @param request
	 * @return Processes
	 */
	@Override
	public Processes doDatabaseSearch(Request request) throws Exception {
		Processes expagProcesses = new Processes();
		String userId = (String) request.getAttribute(USER_ID);

		SearchRequest searchRequest = (SearchRequest) request.getAttribute(SEARCH_REQUEST);
		
		String requestedSearchDate = searchRequest.getFilterType().value();
		
		if(requestedSearchDate.equalsIgnoreCase(DateType.SCHEDULED_DATE.value()) || requestedSearchDate.equalsIgnoreCase(DateType.PROCESSING_DATE.value()) || requestedSearchDate.equalsIgnoreCase(DateType.TRANSACTION_DATE.value())){
			return expagProcesses;
		}

		SearchItemsVO searchItemsVO = this.expagSearchHelper.multiSearchRequest(userId, searchRequest);
	
		// If task id starts with "t", search only from ExpAG
		if ((searchItemsVO.getTaskid() != null && searchItemsVO.getTaskid().startsWith("t")) 
				|| (searchItemsVO.getTaskid() == null || searchItemsVO.getTaskid().length() <= 11) ) {
			expagProcesses = expagSearch(searchItemsVO);
			if (YES.equalsIgnoreCase(filterConvertedExpagTasks)) {
				expagProcesses = filterExpAgProcess(expagProcesses);
			}
			//Calculate Suspend SLA
			Set<String> taskIds = new HashSet<String>();
			for (Process cmsProcess : expagProcesses.getProcesses()) {
				taskIds.add(cmsProcess.getTasks().getTasks().get(0).getID());
			}
			List<ExpagStatusHistory> suspendedStatusHistory = this.expagdao.getExpagWorkItemSuspendedHistory(taskIds);
			Map<String, Integer> suspendedDuration = this.expagTaskHelper.calculateSuspendedDuration(suspendedStatusHistory);
			
			for (Process cmsProcess : expagProcesses.getProcesses()) {
				int suspDuration = suspendedDuration.get(cmsProcess.getTasks().getTasks().get(0).getID()) != null ? suspendedDuration.get(cmsProcess.getTasks().getTasks().get(0).getID()) : 0;
				SLADetail slaDetail = expagTaskHelper.computeSLADetails(cmsProcess.getTasks().getTasks().get(0), suspDuration);
				cmsProcess.getTasks().getTasks().get(0).setSLADetail(slaDetail);
				cmsProcess.setSLADetail(slaDetail);
			}
			
		}
		return expagProcesses;
	}


/*	@Override
	public Tasks getTasks(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);

		ResponseList icmTasksResponse = this.icmService.getICMtasks(processId, userId);
		List<org.tiaa.esb.icm.types.Task> icmtasks = (List<org.tiaa.esb.icm.types.Task>) icmTasksResponse.getResults();

		Tasks tasks = this.icmTaskHelper.icmCasesToTasks(icmtasks);

		return tasks;
	}*/

	@Override
	public Comments getComments(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		String processId = (String) request.getAttribute(PROCESS_ID);

		ResponseList icmCommentsResponse = this.icmService.getICMcomments(processId, userId);
		List<LinkedHashMap<String, Object>> icmComments = (List<LinkedHashMap<String, Object>>) icmCommentsResponse.getResults();

		Comments comments = this.icmCommentsHelper.icmCommentsToComments(icmComments);

		return comments;
	}

	@Override
	public Comments addComment(Request request) {
		Comments comments = null;
		boolean addStatus = false;
		String userId = (String) request.getAttribute(USER_ID);
		String caseId = (String) request.getAttribute(PROCESS_ID);
		
		CommentsRequest commentsRequest = (CommentsRequest) request.getAttribute(COMMENT_REQUEST);
		List<Comment> commentsList = commentsRequest.getComments().getComments();
		Comment commentRequest = commentsList.get(0);

		if ((commentRequest != null) && (commentRequest.getMessage() != null)) {
			addStatus = this.icmCommentsHelper.addComment(userId, caseId, commentRequest);
		}
		if (addStatus) {
			// Get all the request parameter string values
			request.setAttribute(USER_ID, userId);
			request.setAttribute(PROCESS_ID, caseId);
			comments = getComments(request);
		}

		return comments;
	}

	private Processes expagSearch(SearchItemsVO searchItemsVO) throws SQLException {
		Processes processes = new Processes();
		List<String> pinList = new ArrayList<String>();
		List<String> npinList = new ArrayList<String>();

		if (searchItemsVO.getIddesc1() != null) {
			if ("NPIN".equalsIgnoreCase(searchItemsVO.getIddesc1())) {
				npinList.add(searchItemsVO.getField11());
			} else if ("PIN".equalsIgnoreCase(searchItemsVO.getIddesc1())) {
				pinList.add(searchItemsVO.getField11());
			}
		}

		if (searchItemsVO.getIddesc2() != null) {
			if ("NPIN".equalsIgnoreCase(searchItemsVO.getIddesc2())) {
				npinList.add(searchItemsVO.getField21());
			} else if ("PIN".equalsIgnoreCase(searchItemsVO.getIddesc2())) {
				pinList.add(searchItemsVO.getField21());
			}
		}

		if (searchItemsVO.getIddesc3() != null) {
			if ("NPIN".equalsIgnoreCase(searchItemsVO.getIddesc3())) {
				npinList.add(searchItemsVO.getField31());
			} else if ("PIN".equalsIgnoreCase(searchItemsVO.getIddesc3())) {
				pinList.add(searchItemsVO.getField31());
			}
		}

		if (pinList.size() > 0 && npinList.size() > 0) {
			if (pinList.size() > 1 || npinList.size() > 1) {
				// This is an or'ing of only PINs and NPINs
				processes = getOnlyNpinOrPinResults(npinList, pinList, searchItemsVO);
			} else {
				// This is an or'ing of PINs and NPINs
				processes = expagOrOperation(searchItemsVO);
			}
		} else {
			processes = this.expagdao.getSearchResults(searchItemsVO);
		}
		return processes;
	}

	private Processes expagOrOperation(SearchItemsVO searchItemsVO) throws SQLException {
		Processes processes = new Processes();
		int pinIdentifier = 0;
		int npinIdentifier = 0;

		String pin = null;
		String npin = null;

		int pinCount = 0;
		int npinCount = 0;

		if (searchItemsVO.getIddesc1() != null) {
			if ("NPIN".equalsIgnoreCase(searchItemsVO.getIddesc1())) {
				npinIdentifier = 1;
				npin = searchItemsVO.getField11();
				npinCount++;
			} else if ("PIN".equalsIgnoreCase(searchItemsVO.getIddesc1())) {
				pinIdentifier = 1;
				pin = searchItemsVO.getField11();
				pinCount++;
			}
		}

		if (searchItemsVO.getIddesc2() != null) {
			if ("NPIN".equalsIgnoreCase(searchItemsVO.getIddesc2())) {
				npinIdentifier = 2;
				npin = searchItemsVO.getField21();
				npinCount++;
			} else if ("PIN".equalsIgnoreCase(searchItemsVO.getIddesc2())) {
				pinIdentifier = 2;
				pin = searchItemsVO.getField21();
				pinCount++;
			}
		}

		if (searchItemsVO.getIddesc3() != null) {
			if ("NPIN".equalsIgnoreCase(searchItemsVO.getIddesc3())) {
				npinIdentifier = 3;
				npin = searchItemsVO.getField31();
				npinCount++;
			} else if ("PIN".equalsIgnoreCase(searchItemsVO.getIddesc3())) {
				pinIdentifier = 3;
				pin = searchItemsVO.getField31();
				pinCount++;
			}
		}

		if (npinIdentifier == 0 || pinIdentifier == 0 || StringUtils.isEmpty(pin) || StringUtils.isEmpty(npin)) {
			throw new AtomCoreException("Attempted OrOperation without a required pin or npin identifier.");
		}

		if (npinIdentifier == 1) {
			/*
			 * This case poses a challenge- search won't work for a blank first
			 * identifier so we have to substitute the other value for it
			 */

			try {
				Class searchItemVOClass;
				searchItemVOClass = Class.forName("org.tiaa.case_management_rs.model.SearchItemsVO");

				// String parameter
				Class[] paramString = new Class[1];
				paramString[0] = String.class;

				Method setIddescMethod = searchItemVOClass.getDeclaredMethod("setIddesc" + npinIdentifier, paramString);
				Method setFieldMethod = searchItemVOClass.getDeclaredMethod("setField" + npinIdentifier + "1", paramString);

				Method setIddescMethod2 = searchItemVOClass.getDeclaredMethod("setIddesc" + pinIdentifier, paramString);
				Method setFieldMethod2 = searchItemVOClass.getDeclaredMethod("setField" + pinIdentifier + "1", paramString);

				setIddescMethod.invoke(searchItemsVO, new String("PIN"));
				setFieldMethod.invoke(searchItemsVO, new String(pin));

				setIddescMethod2.invoke(searchItemsVO, new String());
				setFieldMethod2.invoke(searchItemsVO, new String());

				processes = this.expagdao.getSearchResults(searchItemsVO);

				setIddescMethod.invoke(searchItemsVO, new String("NPIN"));
				setFieldMethod.invoke(searchItemsVO, new String(npin));

				setIddescMethod2.invoke(searchItemsVO, new String("PIN"));
				setFieldMethod2.invoke(searchItemsVO, new String(pin));
			} catch (NoSuchMethodException | SecurityException e) {
				throw new AtomCoreException(e);
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e1);
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e);
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e);
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e);
			}

		} else if (npinIdentifier == 2) {
			searchItemsVO.setIddesc2(null);
			searchItemsVO.setField21(null);

			processes = this.expagdao.getSearchResults(searchItemsVO);

			searchItemsVO.setIddesc2("NPIN");
			searchItemsVO.setField21(npin);
		} else if (npinIdentifier == 3) {
			searchItemsVO.setIddesc3(null);
			searchItemsVO.setField31(null);

			processes = this.expagdao.getSearchResults(searchItemsVO);

			searchItemsVO.setIddesc3("NPIN");
			searchItemsVO.setField31(npin);

		}

		if (pinIdentifier == 1) {
			try {
				Class searchItemVOClass;
				searchItemVOClass = Class.forName("org.tiaa.case_management_rs.model.SearchItemsVO");

				// String parameter
				Class[] paramString = new Class[1];
				paramString[0] = String.class;

				Method setIddescMethod = searchItemVOClass.getDeclaredMethod("setIddesc" + pinIdentifier, paramString);
				Method setFieldMethod = searchItemVOClass.getDeclaredMethod("setField" + pinIdentifier + "1", paramString);

				Method setIddescMethod2 = searchItemVOClass.getDeclaredMethod("setIddesc" + npinIdentifier, paramString);
				Method setFieldMethod2 = searchItemVOClass.getDeclaredMethod("setField" + npinIdentifier + "1", paramString);

				setIddescMethod.invoke(searchItemsVO, new String("NPIN"));
				setFieldMethod.invoke(searchItemsVO, new String(npin));

				setIddescMethod2.invoke(searchItemsVO, new String());
				setFieldMethod2.invoke(searchItemsVO, new String());

				processes.getProcesses().addAll((this.expagdao.getSearchResults(searchItemsVO)).getProcesses());

			} catch (NoSuchMethodException | SecurityException e) {
				throw new AtomCoreException(e);
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e1);
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e);
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e);
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e);
			}

		} else if (pinIdentifier == 2) {
			searchItemsVO.setIddesc2(null);
			searchItemsVO.setField21(null);

			processes.getProcesses().addAll((this.expagdao.getSearchResults(searchItemsVO)).getProcesses());

		} else if (pinIdentifier == 3) {
			searchItemsVO.setIddesc3(null);
			searchItemsVO.setField31(null);

			processes.getProcesses().addAll((this.expagdao.getSearchResults(searchItemsVO)).getProcesses());

		}

		return processes;
	}

	private Processes getOnlyNpinOrPinResults(List npinList, List pinList, SearchItemsVO searchItemsVO) throws SQLException {
		Processes processes = new Processes();

		searchItemsVO.setIddesc1(null);
		searchItemsVO.setField11(null);
		searchItemsVO.setIddesc2(null);
		searchItemsVO.setField21(null);
		searchItemsVO.setIddesc3(null);
		searchItemsVO.setField31(null);

		for (int i = 1; i <= npinList.size(); i++) {

			try {
				Class searchItemVOClass;
				searchItemVOClass = Class.forName("org.tiaa.case_management_rs.model.SearchItemsVO");

				// String parameter
				Class[] paramString = new Class[1];
				paramString[0] = String.class;

				Method setIddescMethod = searchItemVOClass.getDeclaredMethod("setIddesc" + i, paramString);
				Method setFieldMethod = searchItemVOClass.getDeclaredMethod("setField" + i + "1", paramString);

				setIddescMethod.invoke(searchItemsVO, new String("NPIN"));
				setFieldMethod.invoke(searchItemsVO, new String((String) npinList.get(i - 1)));
			} catch (NoSuchMethodException | SecurityException e) {
				throw new AtomCoreException(e);
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e1);
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e);
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e);
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e);
			}
		}
		processes = this.expagdao.getSearchResults(searchItemsVO);

		searchItemsVO.setIddesc1(null);
		searchItemsVO.setField11(null);
		searchItemsVO.setIddesc2(null);
		searchItemsVO.setField21(null);
		searchItemsVO.setIddesc3(null);
		searchItemsVO.setField31(null);

		for (int i = 1; i <= pinList.size(); i++) {

			try {
				Class searchItemVOClass;
				searchItemVOClass = Class.forName("org.tiaa.case_management_rs.model.SearchItemsVO");

				// String parameter
				Class[] paramString = new Class[1];
				paramString[0] = String.class;

				Method setIddescMethod = searchItemVOClass.getDeclaredMethod("setIddesc" + i, paramString);
				Method setFieldMethod = searchItemVOClass.getDeclaredMethod("setField" + i + "1", paramString);

				setIddescMethod.invoke(searchItemsVO, new String("PIN"));
				setFieldMethod.invoke(searchItemsVO, new String((String) pinList.get(i - 1)));
			} catch (NoSuchMethodException | SecurityException e) {
				throw new AtomCoreException(e);
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e1);
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e);
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e);
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				throw new AtomCoreException(e);
			}

		}

		processes.getProcesses().addAll((this.expagdao.getSearchResults(searchItemsVO)).getProcesses());

		return processes;
	}

	private class DocumentSubmission implements Callable<Boolean> {

		private String appName;
		private String userId, taskId, caseId;
		private boolean uploadStatus = false;
		private Document cmsDocument = null;

		public DocumentSubmission(String appName, String userId, String taskId, String caseId, Document cmsDocument) {
			this.appName = appName;
			this.userId = userId;
			this.taskId = taskId;
			this.caseId = caseId;
			this.cmsDocument = cmsDocument;
		}

		@Override
		public Boolean call() throws Exception {
			if (APP_EXPAG.equalsIgnoreCase(appName)) {
				uploadStatus = expagDocumentHelper.createDocumentInExpag(userId, taskId, caseId, cmsDocument);
			} else if (APP_ICM.equalsIgnoreCase(appName)) {
				uploadStatus = icmDocumentHelper.createDocumentInICM(userId, taskId, caseId, cmsDocument);
			}
			return uploadStatus;
		}

	}
	@Override
	public String toString(){
		return "EXPAG";
	}
	
	@Override
	public TaskResponse getTaskById(Request request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Processes getTasksClaimable(Request request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Tasks getTasks(Request request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Process getRelatedProcesses(Request request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Process getHistory(Request request) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Task updateTask(Request request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Task createTask(Request request) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ConfigItems searchConfigItems(Request request) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void deleteDocument(Request request) {
	}

	@Override
	public History getTaskHistory(Request request) {
		// TODO Auto-generated method stub
		return null;
	}

	}
