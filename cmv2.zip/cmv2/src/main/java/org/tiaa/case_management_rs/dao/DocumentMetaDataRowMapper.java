package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.esb.case_management_rs_v2.type.Document;
import org.tiaa.esb.case_management_rs_v2.type.DocumentDeliveries;
import org.tiaa.esb.case_management_rs_v2.type.DocumentDelivery;


public class DocumentMetaDataRowMapper extends AbstractRowMapper<Document> {

	@Override
	public Document mapRow(ResultSet rs, int rowNum) throws SQLException {

		Document document = new Document();

	     DocumentDelivery docdlvry = new DocumentDelivery();
	     docdlvry.setDlvryMethod(getStringTrimmed(rs, "DOCDLVRY"));
	     
	     DocumentDeliveries docdlvries =new DocumentDeliveries();
	     docdlvries.getDocDlvries().add(docdlvry);
	     
	     Document.DocOriginator docOrginiator = new Document.DocOriginator();
	     docOrginiator.setDocOrigName(getStringTrimmed(rs, "CREATEOPER"));
	     
	     document.setDocDesc(getStringTrimmed(rs,"CREATEDATETIME"));
	     
		 document.setDocumentsDeliveries(docdlvries);
		 document.setDocName(getStringTrimmed(rs, "DOCNAME"));
		 document.setDocOriginator(docOrginiator);
		 document.setDocTyp(getStringTrimmed(rs, "DOCTYPE"));
		 document.setLgcFold(getStringTrimmed(rs, "LGCFOLDER"));

		return document;
	}
}
