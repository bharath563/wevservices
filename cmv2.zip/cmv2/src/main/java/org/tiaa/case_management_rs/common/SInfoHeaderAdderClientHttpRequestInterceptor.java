package org.tiaa.case_management_rs.common;

import java.io.IOException;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.xml.bind.DatatypeConverter;

import org.apache.ws.security.message.token.UsernameToken;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.GuidUtility;

import org.tiaa.atom.core.security.SecretKeyLoader;

public class SInfoHeaderAdderClientHttpRequestInterceptor implements ClientHttpRequestInterceptor {
	private String userId = AppConstants.APPLICATION_NAME;
	private final String pwd;
	private final String acceptHeader;

	public SInfoHeaderAdderClientHttpRequestInterceptor(String acceptHeader) {
		pwd = SecretKeyLoader.getSecretKey(AppConstants.APPLICATION_NAME);
		this.acceptHeader = acceptHeader;
	}

	public SInfoHeaderAdderClientHttpRequestInterceptor(String userId, String pwd, String acceptHeader) {
		this.userId = userId;
		this.pwd = pwd;
		this.acceptHeader = acceptHeader;
	}

	@Override
	public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
		setHeaders(request.getHeaders());
		return execution.execute(request, body);
	}

	public void setHeaders(HttpHeaders headers) {
		String guid = new GuidUtility().toString();
		headers.set("Accept", acceptHeader);
		headers.set("tiaa-guid", guid);
		headers.set("tiaa-correlation-id", guid);
		headers.set("tiaa-partner-id", "");
		headers.set("tiaa-consumer", userId);
		headers.set("tiaa-user-ref", ThreadLocalCustomerNumber.get());
		headers.set("tiaa-sender-machine", CommonUtil.getHostName());
		//
		final String currentTimestamp = currentTimestamp();
		headers.set("tiaa-timestamp", currentTimestamp);
		headers.set("tiaa-digest", UsernameToken.doPasswordDigest("", currentTimestamp, pwd));
	}

	private static String currentTimestamp() {
		TimeZone gmtTimeZone = TimeZone.getTimeZone("GMT");
		return DatatypeConverter.printDateTime(GregorianCalendar.getInstance(gmtTimeZone));
	}
}