package org.tiaa.case_management_rs.model;

import java.util.Calendar;

public class QuickSerachByIdentVO {
	private String userId;
	private Calendar beginDate; // Optional
	private Calendar endDate; // Optional
	private String taskstatus;
	private int rowcount;
	private boolean usecreatedate;
	private String iddesc1;
	private String field11;
	private String field12; // Optional
	private String field13; // Optional
	private String field14; // Optional

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Calendar getBeginDate() {
		return this.beginDate;
	}

	public void setBeginDate(Calendar beginDate) {
		this.beginDate = beginDate;
	}

	public Calendar getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Calendar endDate) {
		this.endDate = endDate;
	}

	public String getTaskstatus() {
		return this.taskstatus;
	}

	public void setTaskstatus(String taskstatus) {
		this.taskstatus = taskstatus;
	}

	public int getRowcount() {
		return this.rowcount;
	}

	public void setRowcount(int rowcount) {
		this.rowcount = rowcount;
	}

	public boolean isUsecreatedate() {
		return this.usecreatedate;
	}

	public void setUsecreatedate(boolean usecreatedate) {
		this.usecreatedate = usecreatedate;
	}

	public String getIddesc1() {
		return this.iddesc1;
	}

	public void setIddesc1(String iddesc1) {
		this.iddesc1 = iddesc1;
	}

	public String getField11() {
		return this.field11;
	}

	public void setField11(String field11) {
		this.field11 = field11;
	}

	public String getField12() {
		return this.field12;
	}

	public void setField12(String field12) {
		this.field12 = field12;
	}

	public String getField13() {
		return this.field13;
	}

	public void setField13(String field13) {
		this.field13 = field13;
	}

	public String getField14() {
		return this.field14;
	}

	public void setField14(String field14) {
		this.field14 = field14;
	}

}
