package org.tiaa.case_management_rs.resource;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.container.ResourceContext;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;

import org.dozer.Mapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.common.impl.RequestImpl;
import org.tiaa.case_management_rs.service.CaseManagementRestService;
import org.tiaa.esb.case_management_rs_v2.type.ProcessRequest;

public class WorkItemResource {

	private static final Logger LOGGER = LoggerFactory.getLogger(WorkItemResource.class);

	@Context
	private ResourceContext resourceContext;

	@Autowired
	private CaseManagementRestService caseManagmentRestService;

	@Autowired
	private Mapper dozerMapper;

	@GET
	@Produces({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	//public Response getProcess(@QueryParam(USER_ID) String userId, @PathParam(PROCESS_ID) String processId) {
	public Response getProcess(@Context HttpHeaders header,
			@QueryParam(USER_ID) String userId,
			@PathParam(PROCESS_ID) String processId,
			@QueryParam(APP_NAME) String appName,
			@QueryParam(SEARCH_MODE) String searchMode,
			@QueryParam(SECTION) String section,
			@QueryParam(SOLUTION_NAME) String solutionName,
			@QueryParam(GROUP_ID) String groupId,
			@QueryParam(TABLE_NAME) String tableName,
			@QueryParam(START) String start,
			@QueryParam(SORT_ORDER) String sortOrder,
			@QueryParam(SORT_BY) String sortBy,
			@QueryParam(TYPE) String type,
			@QueryParam(TASK_ID) String taskId) {

		LOGGER.debug("Entering getProcess");
		LOGGER.debug("Request Params");
		LOGGER.debug(USER_ID + SPACE_HYPEN_SAPCE + userId);
		LOGGER.debug(PROCESS_ID + SPACE_HYPEN_SAPCE + processId);
		LOGGER.debug(APP_NAME + SPACE_HYPEN_SAPCE + appName);
		LOGGER.debug(TYPE + SPACE_HYPEN_SAPCE + type);

		Response response = null;
		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		// Get all the request parameter string values
		request.setAttribute(USER_ID, userId);
		request.setAttribute(PROCESS_ID, processId);
		request.setAttribute(IS_NEW_TASK, FALSE);
		request.setAttribute(SEARCH_MODE, searchMode);
		request.setAttribute(SOLUTION_NAME, solutionName);
		request.setAttribute(GROUP_ID, groupId);
		request.setAttribute(TABLE_NAME, tableName);
		request.setAttribute(SECTION, section);
		request.setAttribute(START, start);
		request.setAttribute(SORT_ORDER, sortOrder);
		request.setAttribute(SORT_BY, sortBy);
		request.setAttribute(TYPE, type);
		request.setAttribute(TASK_ID, taskId);
		
		// Application name added to get the response from either  EXPAG or ICM
		request.setAttribute(APP_NAME, appName);
		//response = this.caseManagmentRestService.getWorkItem(request);
		response = this.caseManagmentRestService.getProcess(request);
		

		LOGGER.debug("Exiting getProcess");

		return response;

	}
	
	@POST
	@Produces({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	@Consumes({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	public Response createProcess(@QueryParam(USER_ID) String userId, @PathParam(PROCESS_ID) String processId, ProcessRequest processRequest) {

		LOGGER.debug("Entering createProcess");
		LOGGER.debug("Request Params");
		LOGGER.debug(USER_ID + SPACE_HYPEN_SAPCE + userId);
		LOGGER.debug(PROCESS_ID + SPACE_HYPEN_SAPCE + processId);

		Response response = null;
		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		// Get all the request parameter string values
		request.setAttribute(USER_ID, userId);
		request.setAttribute(PROCESS_ID, processId);
		//request.setAttribute(WORKITEM_REQUEST, processRequest); 
		request.setAttribute(PROCESS_REQUEST, processRequest);
		response = this.caseManagmentRestService.createProcess(request);

		LOGGER.debug("Exiting createProcess");

		return response;

	}

	@PUT
	@Produces({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	@Consumes({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	public Response updateProcess(@QueryParam(USER_ID) String userId, @PathParam(PROCESS_ID) String processId, @QueryParam(LOCK_ONLY) String lockOnly,
			@QueryParam(APP_NAME) String appName, ProcessRequest processRequest, @QueryParam(USE_IDENTIFIERS_ID) String useIdentifiersId) {

		LOGGER.debug("Entering updateProcess");
		LOGGER.debug("Request Params");
		LOGGER.debug(USER_ID + SPACE_HYPEN_SAPCE + userId);
		LOGGER.debug(PROCESS_ID + SPACE_HYPEN_SAPCE + processId);

		Response response = null;
		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		// Get all the request parameter string values
		request.setAttribute(USER_ID, userId);
		request.setAttribute(PROCESS_ID, processId);
		request.setAttribute(LOCK_ONLY, lockOnly);
		request.setAttribute(APP_NAME, appName);
		request.setAttribute(PROCESS_REQUEST, processRequest);
		request.setAttribute(USE_IDENTIFIERS_ID, useIdentifiersId);

		response = this.caseManagmentRestService.updateProcess(request);

		LOGGER.debug("Exiting updateProcess");

		return response;
	}

	@Path("/documents")
	public DocumentsResource documentsSubResource() {
		return this.resourceContext.getResource(DocumentsResource.class);
	}

	@Path("/relatedtask")
	public RelatedTaskResource relatedTaskSubResource() {
		return this.resourceContext.getResource(RelatedTaskResource.class);
	}

	@Path("/task")
	public TaskResource taskSubResource() {
		return this.resourceContext.getResource(TaskResource.class);
	}

	@Path("/timeline")
	public TimelineResource timelineSubResource() {
		return this.resourceContext.getResource(TimelineResource.class);
	}

	@Path("/tasks")
	public TasksResource tasksSubResource() {
		return this.resourceContext.getResource(TasksResource.class);
	}
	
	@Path("/comments")
	public CommentsResource commentsSubResource() {
		return this.resourceContext.getResource(CommentsResource.class);
	}
	
	@Path("/relatedprocesses")
	public RelatedProcessesResource relatedProcessesSubResource() {
		return this.resourceContext.getResource(RelatedProcessesResource.class);
	}
	@Path("/copy")
	public CopyResource copySubResource() {
		return this.resourceContext.getResource(CopyResource.class);
	}
	
}
