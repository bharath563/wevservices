package org.tiaa.case_management_rs.integration.exp_ag.file_transfer;


import org.springframework.beans.factory.annotation.Autowired;
import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;



public class FileTransferService {


	private FileTransferSoap fileTransfer;
	
	public FileTransferService(){}
	
	private String fileTransferWsdl;

	@Autowired
//	public FileTransferService(@Value("${fileTransferWsdl}") String fileTransferWsdl) throws MalformedURLException {
	public FileTransferService(String fileTransferWsdl) throws MalformedURLException {
		URL url = new URL(fileTransferWsdl);
		QName qname = new QName("http://tiaa-cref.org/FileTransferWebService",
				"FileTransfer");
		javax.xml.ws.Service service = javax.xml.ws.Service.create(url, qname);
		 fileTransfer = service.getPort(FileTransferSoap.class);
	}

	public void moveFile(String filename,String sourcePath,String destPath) throws Exception{
		fileTransfer.moveFile(filename, sourcePath, destPath);
	}
	
	public void replaceFileContent(String filename,String sourcePath,byte[] fileContent) throws Exception{
		fileTransfer.replaceFileContent(filename, sourcePath, fileContent);;
	}

	public String getFileTransferWsdl() {
		return fileTransferWsdl;
	}

	public void setFileTransferWsdl(String fileTransferWsdl) {
		this.fileTransferWsdl = fileTransferWsdl;
	}
}
