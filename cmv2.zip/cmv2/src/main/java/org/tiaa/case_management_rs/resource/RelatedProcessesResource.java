package org.tiaa.case_management_rs.resource;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.common.impl.RequestImpl;
import org.tiaa.case_management_rs.service.CaseManagementRestService;

public class RelatedProcessesResource {

	private static final Logger LOGGER = LoggerFactory.getLogger(RelatedProcessesResource.class);

	@Autowired
	private CaseManagementRestService caseManagmentRestService;

	@GET
	@Produces({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	@Consumes({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	public Response getRelatedProcesses(@QueryParam("userid") String userId,@QueryParam(APP_NAME) String appName, @PathParam(PROCESS_ID) String processId,@QueryParam(SOLUTION_NAME) String solutionName) {

		LOGGER.debug("Entering createRelatedTask");
		LOGGER.debug("Request Params");
		LOGGER.debug(USER_ID + SPACE_HYPEN_SAPCE + userId);

		Response response = null;
		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		// Get all the request parameter string values
		request.setAttribute(USER_ID, userId);
		request.setAttribute(APP_NAME, appName);
		request.setAttribute(PROCESS_ID, processId);
		request.setAttribute(SOLUTION_NAME, solutionName);
		

		response = this.caseManagmentRestService.getRelatedProcesses(request);

		LOGGER.debug("Exiting createRelatedTask");

		return response;

	}

}
