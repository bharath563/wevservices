package org.tiaa.case_management_rs.integration.icm;
 

import java.util.List;
import java.util.Map;

import org.tiaa.esb.icm.types.Case;
import org.tiaa.esb.icm.types.CaseSearch;
import org.tiaa.esb.icm.types.Comment;
import org.tiaa.esb.icm.types.Configuration;
import org.tiaa.esb.icm.types.Document;
import org.tiaa.esb.icm.types.Response;
import org.tiaa.esb.icm.types.ResponseList;
import org.tiaa.esb.icm.types.Step;
import org.tiaa.esb.icm.types.StepList;
import org.tiaa.esb.icm.types.Task;
 
public interface ICMRepository {
    
	public ResponseList searchICMCases(CaseSearch icmCaseSearchRequest, String userId);
	
    public Case getICMProcess(String processId, String userId);
    
    public ResponseList getICMtasks(String processId, String userId, String start);
    
    public List<Object> getCaseAdditionalInfo(String processId, String userId, String solutionName, String section, String groupId, String tableName, String start, String sortOrder, String sortBy, String taskId);
    
    public ResponseList getICMDocuments(String processId, String userId);
    
    public ResponseList getICMcomments(String processId, String userId);
    
    public Configuration getICMConfigItem(String property);
 
    public Response addICMComment(Comment comment, String caseId, String userId);
 
    public Response addICMDocument(Document document, String caseId, String userId);
    
    public ResponseList getICMRelatedCase(String processId, String userID, String solutionName);
    
    public List<String> getICMSolutions(String property, String userId);
    
	public Configuration getICMSolutionHeaders(String dept, String userId, String tableheader);
	
	public List<StepList> getICMSteps(String userId,String department,String type, String start);

	public Step getICMStepDetails(String wobId, String queName, String userId, String property);

	public ResponseList getICMHistory(String processId, String userId, String start,
			String type);

	public ResponseList getMetrics(String userId, String solutionName);
	
	public Response actionIcmTask(String wobId, String userId,
			String queueName, Step stepElement);

	public Response unLockIcmTask(String wobId, String userId,
			String queueName);

	public Response reAssignIcmTask(String wobId, String userId, String queueName,
			Step stepElement);

	public Response createCase(Case caseObj, String userId);

	public Response createIcmTask(String caseId, Task task, String userId);

	public Configuration getICMRequestTypesForBA(String property, String dept);

	public Map<String, String> searchConfigItems(StepList stepList, String userId,
			String type);

	public ResponseList getIcmOmniTasks(String processId, String userId, String startOmniTasks, String plan, String subPlan);

	public void deleteICMDocument(String caseId, String docTemplateCode, String userId);
}
 