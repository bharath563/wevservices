package org.tiaa.case_management_rs.validator;

import org.tiaa.case_management_rs.common.Request;

/**
 * Base validator class for the request object
 */
public interface BaseValidator {

	void validate(Request request);

}
