package org.tiaa.case_management_rs.expagconversion.aspect;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import javax.ws.rs.core.Response;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.case_management_rs.dao.EXPAGDAO;
import org.tiaa.case_management_rs.expag.helper.ConversionHelper;
import org.tiaa.esb.case_management_rs_v2.type.ProcessRequest;
import org.tiaa.esb.case_management_rs_v2.type.ProcessesRequest;

@Aspect
public class ConversionAspect {
	
	@Autowired
	private EXPAGDAO expagdao;

	private static final Logger LOGGER = LoggerFactory.getLogger(ConversionAspect.class);

	@Autowired
	private ConversionHelper conversionHelper;

	@Pointcut("execution(* org.tiaa.case_management_rs.service.impl.CaseManagementRestServiceImpl.getProcess(..))")
	public void getProcessPointCut() {
	}
	
	@Pointcut("execution(* org.tiaa.case_management_rs.service.impl.CaseManagementRestServiceImpl.getProcesses(..))")
	public void getProcessesPointCut() {
	}

	@Pointcut("execution(* org.tiaa.case_management_rs.service.impl.CaseManagementRestServiceImpl.createProcesses(..))")
	public void createProcessesPointCut() {
	}

	@Pointcut("execution(* org.tiaa.case_management_rs.service.impl.CaseManagementRestServiceImpl.getDocuments(..))")
	public void getDocumentsPointCut() {
	}
	
	@Pointcut("execution(* org.tiaa.case_management_rs.service.impl.CaseManagementRestServiceImpl.getDocument(..))")
	public void getDocumentPointCut() {
	}
	
	@Pointcut("execution(* org.tiaa.case_management_rs.service.impl.CaseManagementRestServiceImpl.updateProcess(..))")
	public void updateProcessPointCut() {
	}
	
	@Pointcut("execution(* org.tiaa.case_management_rs.service.impl.CaseManagementRestServiceImpl.updateProcesses(..))")
	public void updateProcessesPointCut() {
	}
	
	@Pointcut("execution(* org.tiaa.case_management_rs.service.impl.CaseManagementRestServiceImpl.createDocuments(..))")
	public void createDocumentsPointCut() {
	}
	
	@Pointcut("execution(* org.tiaa.case_management_rs.service.impl.CaseManagementRestServiceImpl.updateDocument(..))")
	public void updateDocumentPointCut() {
	}
	
	@Pointcut("execution(* org.tiaa.case_management_rs.service.impl.CaseManagementRestServiceImpl.createRelatedTask(..))")
	public void createRelatedTaskPointCut() {
	}

	@Before("getProcessPointCut()")
	public void getProcessAdvice(JoinPoint joinPoint) {

		LOGGER.debug("SourceSystemRoutingAspect- getProcessAdvice call");

		Object[] args = joinPoint.getArgs();

		Request request = (Request) args[0];

		String appName = (String) request.getAttribute(APP_NAME);
		
		if (APP_CONVERTED_EXPAG.equalsIgnoreCase(appName)) {
			request.setAttribute(CONVERTED_EXPAG_TASK, YES);
			request.setAttribute(APP_NAME, APP_ACTIVITI); 
		}

/*		if (APP_EXPAG.equalsIgnoreCase(appName)) {

			conversionHelper.setAppNameBasedOnTaskType(request);
		}*/
	}
	
	@Before("getProcessesPointCut()")
	public void getProcessesAdvice(JoinPoint joinPoint) {
		LOGGER.info("SourceSystemRoutingAspect- getProcessesAdvice call");

		Object[] args = joinPoint.getArgs();

		Request request = (Request) args[0];

		String appName = (String) request.getAttribute(APP_NAME);

		if (APP_EXPAG.equalsIgnoreCase(appName)) {
			request.setAttribute(CONVERTED_EXPAG_TASK, YES);
		}
	}

	@Around("createProcessesPointCut()")
	public Object createProcessesAdvice(ProceedingJoinPoint pjp) throws Throwable {

		LOGGER.debug("SourceSystemRoutingAspect--createProcessesAdvice call");

		Object[] args = pjp.getArgs();

		Request request = (Request) args[0];

		String appName = (String) request.getAttribute(APP_NAME);

		Response response = null;
		// appName check for the conversion process
		if (APP_EXPAG.equalsIgnoreCase(appName)) {

			ProcessesRequest processesRequest = (ProcessesRequest) request.getAttribute(PROCESSES_REQUEST);

			String taskType = processesRequest.getProcesses().getProcesses().get(0).getTasks().getTasks().get(0).getType();

			String sourceSystem = conversionHelper.getSourceSystemNameByTaskType(taskType);

			if (sourceSystem != null) {
				response = conversionHelper.createProcesses(pjp, sourceSystem);
			} else {
				response = (Response) pjp.proceed();
			}

		} else {
			response = (Response) pjp.proceed();
		}

		return response;
	}

	@Before("getDocumentsPointCut()")
	public void getDocumentsAdvice(JoinPoint joinPoint) {

		LOGGER.debug("SourceSystemRoutingAspect- getDocumentsAdvice call");

		Object[] args = joinPoint.getArgs();

		Request request = (Request) args[0];

		String appName = (String) request.getAttribute(APP_NAME);
		
		request.setAttribute(CONVERTED_EXPAG_TASK, YES);
		if (APP_CONVERTED_EXPAG.equalsIgnoreCase(appName)) {
			request.setAttribute(APP_NAME, APP_ACTIVITI); 
		}

		if (APP_EXPAG.equalsIgnoreCase(appName)) {

			conversionHelper.setAppNameBasedOnTaskType(request);
		}
	}
	
	@Before("getDocumentPointCut()")
	public void getDocumentAdvice(JoinPoint joinPoint) {

		LOGGER.debug("SourceSystemRoutingAspect- getDocumentAdvice call");

		Object[] args = joinPoint.getArgs();

		Request request = (Request) args[0];

		String appName = (String) request.getAttribute(APP_NAME);
		
		if (APP_CONVERTED_EXPAG.equalsIgnoreCase(appName)) {
			request.setAttribute(CONVERTED_EXPAG_TASK, YES);
			request.setAttribute(APP_NAME, APP_ACTIVITI); 
		}

	}

	@Around("updateProcessPointCut()")
	public Object updateProcessAdvice(ProceedingJoinPoint jointPoint) throws Throwable {
		Response response = null;

		LOGGER.debug("SourceSystemRoutingAspect--updateProcessAdvice call");

		Object[] args = jointPoint.getArgs();

		Request request = (Request) args[0];
		String appName = (String) request.getAttribute(APP_NAME);

		// appName check for the conversion process
		if (APP_EXPAG.equalsIgnoreCase(appName) || APP_CONVERTED_EXPAG.equalsIgnoreCase(appName)) {

			ProcessRequest processRequest = (ProcessRequest) request.getAttribute(PROCESS_REQUEST);

			String taskType = processRequest.getProcess().getTasks().getTasks().get(0).getType();

			String sourceSystem = conversionHelper.getSourceSystemNameByTaskType(taskType);

			if (sourceSystem != null) {

				response = conversionHelper.updateProcess(jointPoint, sourceSystem, request);
			} else {
				response = (Response) jointPoint.proceed();
			}

		} 
		else
			response = (Response) jointPoint.proceed();

		return response;
	}
	
	@Around("createDocumentsPointCut()")
	public Object createDocumentsAdvice(ProceedingJoinPoint pjp) throws Throwable {
		Response response = null;

		LOGGER.debug("SourceSystemRoutingAspect--createDocumentsAdvice call");
		Object[] args = pjp.getArgs();

		Request request = (Request) args[0];
		String appName = (String) request.getAttribute(APP_NAME);

		// appName check for the conversion process
		if (APP_EXPAG.equalsIgnoreCase(appName) || APP_CONVERTED_EXPAG.equalsIgnoreCase(appName)) {
			
			String taskId = (String) request.getAttribute(PROCESS_ID);
			request.setAttribute(CONVERTED_EXPAG_TASK, YES);
			String taskType = expagdao.getExpagTaskTypeForTaskId(taskId);
			String sourceSystem = conversionHelper.getSourceSystemNameByTaskType(taskType);
			
			if (sourceSystem != null) {
				response = conversionHelper.createDocuments(pjp, sourceSystem);
			} else {
				response = (Response) pjp.proceed();
			}

		} else {
			response = (Response) pjp.proceed();
		}

		return response;
	}
	
	@Around("createRelatedTaskPointCut()")
	public Object createRealtedTaskAdvice(ProceedingJoinPoint pjp) throws Throwable {

		LOGGER.debug("SourceSystemRoutingAspect--createProcessesAdvice call");

		Object[] args = pjp.getArgs();

		Request request = (Request) args[0];

		String appName = (String) request.getAttribute(APP_NAME);

		Response response = null;
		// appName check for the conversion process
		if (APP_EXPAG.equalsIgnoreCase(appName) || APP_CONVERTED_EXPAG.equalsIgnoreCase(appName)) {

			ProcessRequest processRequest  = (ProcessRequest) request.getAttribute(PROCESS_REQUEST);

			String taskType = processRequest.getProcess().getTasks().getTasks().get(0).getType();

			String sourceSystem = conversionHelper.getSourceSystemNameByTaskType(taskType);

			if (sourceSystem != null) {
				response = conversionHelper.createRelatedTask(pjp, sourceSystem);
			} else {
				response = (Response) pjp.proceed();
			}

		} else {
			response = (Response) pjp.proceed();
		}

		return response;
	}
	
	@Around("updateDocumentPointCut()")
	public Object updateDocumentAdvice(ProceedingJoinPoint pjp) throws Throwable {
		Response response = null;

		LOGGER.debug("SourceSystemRoutingAspect--updateDocumentAdvice call");
		Object[] args = pjp.getArgs();

		Request request = (Request) args[0];
		String appName = (String) request.getAttribute(APP_NAME);

		// appName check for the conversion process for given task
		if (APP_EXPAG.equalsIgnoreCase(appName) || APP_CONVERTED_EXPAG.equalsIgnoreCase(appName)) {
			
			String taskId = (String) request.getAttribute(PROCESS_ID);
			request.setAttribute(CONVERTED_EXPAG_TASK, YES);
			String taskType = expagdao.getExpagTaskTypeForTaskId(taskId);
			String sourceSystem = conversionHelper.getSourceSystemNameByTaskType(taskType);
			
			if (sourceSystem != null) {
				response = conversionHelper.updateDocument(pjp, sourceSystem);
			} else {
				response = (Response) pjp.proceed();
			}

		} else {
			response = (Response) pjp.proceed();
		}

		return response;
		
	}
	@Around("updateProcessesPointCut()")
	public Object updateProcessesAdvice(ProceedingJoinPoint jointPoint) throws Throwable {
		Response response = null;

		LOGGER.debug("SourceSystemRoutingAspect--updateProcessAdvice call");

		Object[] args = jointPoint.getArgs();

		Request request = (Request) args[0];
		String appName = (String) request.getAttribute(APP_NAME);

		// appName check for the conversion process
		if (APP_EXPAG.equalsIgnoreCase(appName) || APP_CONVERTED_EXPAG.equalsIgnoreCase(appName)) {

			
		request.setAttribute(CONVERTED_EXPAG_TASK, YES);
		response = conversionHelper.updateProcesses(jointPoint, request);
			

		} else {
			response = (Response) jointPoint.proceed();
		}

		return response;

	}
	
	
	
}
