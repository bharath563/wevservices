package org.tiaa.case_management_rs.validator.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.esb.case_management_rs_v2.type.DocumentsRequest;

public class CreateDocumentsValidator extends BaseValidatorImpl {

	@Override
	public void doValidate(Request request) {

		String userid = (String) request.getAttribute(USER_ID);
		String appname = (String) request.getAttribute(APP_NAME);
		String taskid = (String) request.getAttribute(PROCESS_ID);
		String caseid = (String) request.getAttribute(CASE_ID);
		DocumentsRequest docs = (DocumentsRequest) request.getAttribute(DOCUMENTS_REQUEST);
		if (StringUtils.isBlank(userid)) {
			handleException(VALIDATION_USERID_IS_EMPTY);
		}
		
		if (StringUtils.isBlank(appname)) {
			handleException(VALIDATION_APPNAME_IS_EMPTY);
		}
		
		//doc content
		for( org.tiaa.esb.case_management_rs_v2.type.Document  document:docs.getDocuments().getDocuments()){
			//if(document.getDocContent()==null){
			if(ArrayUtils.isEmpty(document.getDocContent())){
				handleException(VALIDATION_DOC_CONTENT_IS_NULL);
			}
		}
		
		//case id if the appname is CM
		if(appname!=null && appname.equalsIgnoreCase(APP_ICM)){
			if (StringUtils.isBlank(caseid)) {
				handleException(VALIDATION_CASEID_IS_EMPTY);
			}
		}
			}
}
