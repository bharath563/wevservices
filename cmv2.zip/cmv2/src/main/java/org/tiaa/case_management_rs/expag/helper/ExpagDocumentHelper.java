package org.tiaa.case_management_rs.expag.helper;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import com.itextpdf.text.DocumentException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import org.tiaa.case_management_rs.dao.EXPAGDAO;
import org.tiaa.case_management_rs.dao.ProcessDBDAO;
import org.tiaa.case_management_rs.domain.EXPAGFileInfo;
import org.tiaa.case_management_rs.exception.CaseManagementRuntimeException;
import org.tiaa.case_management_rs.integration.exp_ag.file_transfer.WebDAVClient;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.PowerImageService;
import org.tiaa.case_management_rs.model.AddDocumentExVO;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.case_management_rs.utils.GuidUtility;
import org.tiaa.case_management_rs.utils.PDFUtils;
import org.tiaa.case_management_rs.utils.TiffUtils;
import org.tiaa.esb.case_management_rs_v2.type.Document;
import org.tiaa.esb.case_management_rs_v2.type.Document.DocOriginator;
import org.tiaa.esb.case_management_rs_v2.type.Documents;
import org.tiaa.esb.case_management_rs_v2.type.Paragraphs;
import org.tiaa.esb.case_management_rs_v2.type.Routing;
import org.tiaa.esb.case_management_rs_v2.type.Task;
import org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo;
import org.tiaa.esb.powerimage.types.WorkPacket;


@Service
public class ExpagDocumentHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExpagDocumentHelper.class);

	@Value("${expag.document.upload.url}")
	private String expagFileUploadUrl;

	@Value("${expag.document.uploadpath}")
	private String expagFileUploadPath;
	
	@Value("${expag.docPath}")
	private String expagDocPath;
	

	@Autowired
	private PowerImageService powerImageService;

	@Autowired
	private ProcessDBDAO processDBDao;

	@Autowired
	private EXPAGDAO expagDAO;

	@Autowired
	private WebDAVClient webDAVClient;
	
	@Value("${expag.webdav.url.docs}")
	private String webDAVDocsUrl;
	
	@Value("${expag.webdav.url.predocs}")
	private String webDAVPredocsUrl;

	public Document getcmsDocumentFromExpagDocument(org.tiaa.esb.powerimage.types.Document expagDocument, String taskType) {

		Document document = new Document();

		document.setDocName(expagDocument.getDocid());
		document.setDocTyp(expagDocument.getPidoctype());		

		if ((expagDocument.getDocumentContents() != null) && (expagDocument.getDocumentContents().size() > 0) && (expagDocument.getDocumentContents().get(0) != null)) {
			document.setDocDesc(expagDocument.getDocumentContents().get(0).getContentdesc());
		}

		if (expagDocument.getMailinfo() != null) {
			document.setDocCategory(expagDocument.getMailinfo().getMaildesc());
		}

		
		XMLGregorianCalendar gregorianCalendar=  expagDocument.getCreatedate();
		gregorianCalendar.setHour(expagDocument.getCreatetime().getHour());
		gregorianCalendar.setMinute(expagDocument.getCreatetime().getMinute());
		gregorianCalendar.setSecond(expagDocument.getCreatetime().getSecond());
		
		document.setDocCreateDateTime(gregorianCalendar);
		
		//document.setCreateOper(expagDocument.getCreateoper()); // TODO. what to map?
		//document create operator will be mapped as document customer name in rsv2
		
		
		//customer name moved as originatorname
	    /*IndividualName individualName= new IndividualName();
	    individualName.setFullName(expagDocument.getCreateoper());
		document.setCustName(individualName);*/
		
		DocOriginator docOriginator= new DocOriginator();
		docOriginator.setDocOrigName(expagDocument.getCreateoper());
		document.setDocOriginator(docOriginator);
		
		document.setDocURL(expagDocument.getExtdockey());
		
		document.setDocDirection(getDocumentRoutingType(expagDocument, taskType).value());

		return document;
	}

	public Document getDocumentContentFromExpagDocument(org.tiaa.esb.powerimage.types.Document expagDocument) {

		Document document = new Document();

		if ((expagDocument != null) && (expagDocument.getDocstream() != null)) {

			if ((expagDocument.getDocstream() != null) && (expagDocument.getDocstream().getValue() != null)) {
				
				byte[] docContent = getDocContentFromEXPAG(expagDocument.getDocid());
				
				if ((BASE64BINARY).equalsIgnoreCase(expagDocument.getDocstream().getEncoding())) {
					document.setDocContent(docContent);
					
					document.setDocTemplateCd(BASE64BINARY);
					document.setMimeTyp(expagDocument.getDocstream().getMimetype());
					
				} else if (NONE.equalsIgnoreCase(expagDocument.getDocstream().getEncoding())) {
					document.setDocContent(docContent);
					document.setDocTemplateCd(BASE64BINARY);
					document.setMimeTyp(expagDocument.getDocstream().getMimetype());
				}

				if (NOTE.equalsIgnoreCase(expagDocument.getPidoctype())) {
					document.setDocContent(docContent);
					document.setMimeTyp("text/html");
				}

			}

			document.setDocName(expagDocument.getDocid());
			
			document.setDocURL(expagDocument.getExtdockey());
			
		}
		return document;
	}

	public Routing getDocumentRoutingType(org.tiaa.esb.powerimage.types.Document expagDocument, String taskType) {

		Routing routing = Routing.OTHER;

		if ((expagDocument != null)) {

			List<String> outboundDocTypes = this.expagDAO.getOutboundDocumentTypes();

			if (NOTE.equalsIgnoreCase(expagDocument.getPidoctype())) {
				routing = Routing.NOTE;
			} else if (((outboundDocTypes != null) && (taskType != null) && outboundDocTypes.contains(taskType))) {
				routing = Routing.OUTBOUND;
			} else if (expagDocument.getDocumentContents() != null) {
				for (org.tiaa.esb.powerimage.types.DocumentContent docContent : expagDocument.getDocumentContents()) {
					if ((docContent.getContentdesc() != null) && (docContent.getContentdesc().contains(DOC_CONTENT_TYPE_OUTBOUND) || docContent.getContentdesc().contains(DOC_CONTENT_TYPE_DCS) || docContent.getContentdesc().contains(DOC_CONTENT_TYPE_CALCULATION) || docContent.getContentdesc().contains(DOC_CONTENT_TYPE_POST))) {
						routing = Routing.OUTBOUND;
						break;
					}
				}
			} 
			
			if (Routing.OTHER.equals(routing) && EXPAG_SUPER_USER_ISVOPER.equalsIgnoreCase(expagDocument.getCreateoper())) {
				routing = Routing.INBOUND;
			} 
		}

		return routing;

	}
	
 public Documents getDocumentsFromExpagTask(org.tiaa.esb.powerimage.types.Task expagTask) {

		Documents documents = new Documents();

		if ((expagTask != null) && (expagTask.getDocuments() != null) && (expagTask.getDocuments().getCount() > 0)) {
			// iterate all documents for each task
			for (org.tiaa.esb.powerimage.types.Document expagDocument : expagTask.getDocuments().getDocuments()) {
				Document document = this.getcmsDocumentFromExpagDocument(expagDocument, expagTask.getTasktype()); 
				documents.getDocuments().add(document);
			}
			//Document doc = this.expagDAO.getXMLDocMetaDataFromDB(expagTask.getTaskid());
			//documents.getDocuments().add(doc);
	   
	        }
	
	     return documents;
	}
	
	public byte[] getDocContentFromEXPAG(String docId) {
		
		Map<String, Object> docInfoFromDB = this.expagDAO.getDocInfo(docId);
		String folder = "d" + docInfoFromDB.get("CREATEDATE");
		
		byte[] docContent = null;
			docContent = webDAVClient.getDocContent(folder, docId);

		return docContent;
	}

	public Documents getDocumentsFromExpagWorkPacket(WorkPacket workPacket, String tskId) {

		Documents documents = new Documents();

		if ((workPacket != null) && (workPacket.getTasks() != null)) {

			List<org.tiaa.esb.powerimage.types.Task> expagTasksFromPacket = workPacket.getTasks().getTasks();

			// Get documents from the packet
			if ((workPacket != null) && (workPacket.getPidocuments() != null) && (workPacket.getPidocuments().getCount() > 0)) {

				// iterate all documents for each task
				for (org.tiaa.esb.powerimage.types.Document expagDocument : workPacket.getPidocuments().getDocuments()) {
					Document document = this.getcmsDocumentFromExpagDocument(expagDocument, null);
					if(NOTE.equalsIgnoreCase(document.getDocTyp())){
						document.setIsEditable(false);
					}
					documents.getDocuments().add(document);
				}

			}

			// Get documents related to all tasks
			for (org.tiaa.esb.powerimage.types.Task expagTask : expagTasksFromPacket) {

				if ((expagTask != null) && (tskId.equalsIgnoreCase(expagTask.getTaskid())) && (expagTask.getDocuments() != null) && (expagTask.getDocuments().getCount() > 0)) {
					// iterate all documents for each task
					for (org.tiaa.esb.powerimage.types.Document expagDocument : expagTask.getDocuments().getDocuments()) {
						Document document = this.getcmsDocumentFromExpagDocument(expagDocument, expagTask.getTasktype());
						if(NOTE.equalsIgnoreCase(document.getDocTyp())){
							document.setIsEditable(true);
						}
						documents.getDocuments().add(document);
					}
				}

			}
			
			//Document doc = this.expagDAO.getXMLDocMetaDataFromDB(tskId);
			//documents.getDocuments().add(doc);
		}

		return documents;
	}

	public boolean createDocumentInExpag(String userId, String taskId, String caseId, Document cmsDocument) {

		String guid = new GuidUtility().toString();

		AddDocumentExVO expagDocument = new AddDocumentExVO();

		String documentName = cmsDocument.getDocName();

		expagDocument.setUserId(userId);
		
		expagDocument.setPacketId(cmsDocument.getProcessID().getRqstID());
		
		expagDocument.setStorage(EXPAG_STORAGE_INTERNAL);
		expagDocument.setWrkStationId(EXPAG_WORKSTATION_TIAAPI);

		// Set mail description values
		expagDocument.setMailDesc(EXPAG_MAIL_DESC_REGULAR);
		expagDocument.setMailId(EXPAG_MAIL_ID_CMSUD + SPACE_COLON_SAPCE + guid);

		expagDocument.setPageTotal(1);
		expagDocument.setStartPage(1);
		expagDocument.setEndPage(1);

		if (StringUtils.isNotBlank(caseId)) {
			expagDocument.setTaskOnlyFlag(false);
		} else {
			expagDocument.setTaskOnlyFlag(true);
			expagDocument.setTaskId(taskId);
		}

		if (StringUtils.isNotBlank(cmsDocument.getDocTyp())) { 
			expagDocument.setContType(cmsDocument.getDocTyp());
		}

		// If its a note then do different processing
		if (Routing.NOTE.toString().equalsIgnoreCase(cmsDocument.getDocDirection())) {

			expagDocument.setPiDocType(EXPAG_PIDOCTYPE_NOTE);
			expagDocument.setFileType(EXPAG_FILETYPE_UNKNOWN);

			// Get the document content
			byte[] noteContent = cmsDocument.getDocContent();

			String note = new String(noteContent);

			expagDocument.setNotes(note);

		} else {

			String extension = cmsDocument.getDocXtnsn();

			if ("tif".equalsIgnoreCase(extension) || "tiff".equalsIgnoreCase(extension)) {
				expagDocument.setPiDocType(EXPAG_PIDOCTYPE_IMAGE);
				expagDocument.setFileType(EXPAG_FILETYPE_TIFF);
			} else {
				if(EXPAG_PIDOCTYPE_CORRESPONDENCE.equalsIgnoreCase(cmsDocument.getDocTyp())){
					expagDocument.setPiDocType(EXPAG_PIDOCTYPE_CORRESPONDENCE);
					expagDocument.setContType(EXPAG_CONT_TYPE_CORRESPONDENCE);
				}else{
					expagDocument.setPiDocType(EXPAG_PIDOCTYPE_EXTERNAL);
				}
				expagDocument.setFileType(EXPAG_FILETYPE_UNKNOWN);
			}

			// Get the document content
			byte[] documentContent = cmsDocument.getDocContent();

			String uploadfileName = this.expagFileUploadPath + BACKWARD_SLASH + documentName;

			try {
				RandomAccessFile fi = new RandomAccessFile(new File(uploadfileName), READ_WRITE_MODE);
				fi.write(documentContent);
				fi.close();
			} catch (IOException ioexception) {
				LOGGER.error(ioexception.getMessage());
				throw new CaseManagementRuntimeException("Error occured while dropping the file in the file path : " + uploadfileName);
			}

			expagDocument.setUrlDocPath(this.expagFileUploadUrl + BACKWARD_SLASH + documentName);

			LOGGER.debug(uploadfileName + " - Document successfully uploaded in the file share");
		}

		LOGGER.debug(this.expagFileUploadUrl + BACKWARD_SLASH + documentName + " - Document ready fo EXPAG upload");

		boolean uploadStatus = this.powerImageService.addDocumentEx(expagDocument);

		LOGGER.debug(documentName + " - Document uploaded in EXPAG: " + uploadStatus);
		
		/** Code for Correspondence Document details **/

		if (uploadStatus 
				&& EXPAG_PIDOCTYPE_CORRESPONDENCE.equalsIgnoreCase(cmsDocument.getDocTyp())) {
			String corroDocId = expagDAO.getExpagCorrDocId(taskId, guid);
			if(corroDocId != null){
				moveFileOnExpag(corroDocId);
				insertIntoExpagCorrTables(userId, taskId, cmsDocument, corroDocId);
			}
		}

		return uploadStatus;
	}
	
	private void insertIntoExpagCorrTables(String userId, String taskId,
			Document cmsDocument, String corroDocId) {
		if (cmsDocument.getDocumentsDeliveries() != null
				&& cmsDocument.getDocumentsDeliveries().getDocDlvries() != null
				&& cmsDocument.getDocumentsDeliveries().getDocDlvries().get(0) != null
				&& cmsDocument.getDocumentsDeliveries().getDocDlvries().get(0).getContact() != null
				&& cmsDocument.getDocumentsDeliveries().getDocDlvries().get(0).getContact().getAddr() != null) {

				String corroId = null;
				try {
					corroId = expagDAO.getNextCorroId();
				} catch (Exception e) {
					LOGGER.error("Exception while getNextCorroId:" + e.getMessage());
				}
	
				if (StringUtils.isEmpty(corroId)) {
					LOGGER.error("CORROID is null, cannot insert into CORRO and CORROPARA tables");
				} else {
					String currentDate = DateUtil.DATE_FORMAT_YYYYMMDD.format(new Date());
					String currentTime = DateUtil.DATE_FORMAT_HHmmss.format(new Date());
									
					expagDAO.insertExpagCorro(userId, taskId, cmsDocument, corroId.trim(),
							corroDocId, currentDate, currentTime);
	
					Paragraphs paragraphs = cmsDocument.getParagraphs();
					if (paragraphs != null && paragraphs.getParas() != null) {
						for (org.tiaa.esb.case_management_rs_v2.type.Paragraph para : paragraphs
								.getParas()) {
							expagDAO.insertExpagCorroPara(corroId.trim(),
									para.getParaID(), "" + para.getParaSeqNum());
						}
					}
				}
		}
	}

	private void moveFileOnExpag(String corroDocId) {
	
		String docCreatedDate = DateUtil.today().substring(2);
		String fromDirectory = webDAVDocsUrl + BACKWARD_SLASH + "d" + docCreatedDate;
		String toDirectory = webDAVPredocsUrl + BACKWARD_SLASH + "d" + docCreatedDate;

		try {
			webDAVClient.moveFile(fromDirectory, toDirectory, corroDocId);
		} catch (Exception e) {
			LOGGER.error("Exception while moving file fromDirectory "+fromDirectory 
					+", toDirectory:"+toDirectory +", corroDocId:"+ corroDocId+ ": " + e.getMessage());
		}
	}

	public byte[] getPDFDocument(String docId, String extDocKey) {

		ByteArrayOutputStream pdfBaos = null;

		byte[] pdfData = null;

		List<String> tiffFiles = getTiffFilePaths(extDocKey);

		LOGGER.debug("Total number of files for the supplied extdockey : " + tiffFiles.size());

		for (String filename : tiffFiles) {
			LOGGER.debug("Filenames for extdockey : " + extDocKey + " filename : " + filename);
		}

		try {

			byte[] tiffData = TiffUtils.getCombinedTiffFile(tiffFiles, docId);

			pdfBaos = PDFUtils.createPDF(tiffData, EXP_AG_INDEX);
			pdfData = pdfBaos.toByteArray();
			pdfBaos.close();

		} catch (FileNotFoundException e) {
			throw new CaseManagementRuntimeException("File Not found in the imaging drives for the file path : " + tiffFiles.get(0));
		} catch (IOException e) {
			throw new CaseManagementRuntimeException("Not able to fetch the file from imaging drives for the file path : " + tiffFiles.get(0));
		} catch (DocumentException e) {
			throw new CaseManagementRuntimeException("ERROR occurred while converting tiff to a pdf document : " + tiffFiles.get(0));
		}

		return pdfData;
	}

	public List<String> getTiffFilePaths(String extDocKey) {

		List<String> tiffFiles = new ArrayList<String>();

		String mountPath = "";
		String vol = "";

		int initialFolderNumber = 0;
		int firstFileNumber = 0;
		int lastFileNumber = 0;

		int finalFolderNumber = 0;
		int finalFileNumber = 0;

		// Extract the values from extdockey value passed
		String platterName = extDocKey.substring(0, 9);
		String fullFilePathNumber = extDocKey.substring(10, 16);
		String numberOfPages = extDocKey.substring(16, 21);

		// perform calculations to arrive at initial values
		initialFolderNumber = (Integer.parseInt(fullFilePathNumber)) / 200;
		firstFileNumber = (Integer.parseInt(fullFilePathNumber)) - ((initialFolderNumber * 200));

		List<EXPAGFileInfo> expagFilePathList = this.processDBDao.getFilePathInfo(platterName, FLAG_N);

		if ((expagFilePathList != null) && (expagFilePathList.size() > 0)) {

			for (EXPAGFileInfo filePath : expagFilePathList) {
				mountPath = filePath.getFilepath();
				platterName = filePath.getFilename();
				vol = filePath.getVolume().toLowerCase();
			}
		}

		lastFileNumber = firstFileNumber + (Integer.parseInt(numberOfPages) - 1);

		int i = 0;

		for (int requiredFileNumber = firstFileNumber; requiredFileNumber <= lastFileNumber; requiredFileNumber++) {

			if (requiredFileNumber < 200) {
				finalFolderNumber = initialFolderNumber;
				finalFileNumber = requiredFileNumber;
			} else {
				/*
				 * If the required FileNumber is accessible after storage size
				 * of 200 then navigate to next folder and adjust the file
				 * number accordingly
				 *
				 * EXP-AG stores files only from 0-199 in a folder.The next file
				 * will be stored in the next subfolder.Increment value by 1.
				 * Next SubFolder value = Current SubFolder + 1
				 */
				int incrementor = (requiredFileNumber / 200);

				finalFolderNumber = initialFolderNumber + incrementor;
				finalFileNumber = (requiredFileNumber - (incrementor * 200));
			}

			StringBuffer sb = new StringBuffer();

			sb.append(mountPath).append(BACKWARD_SLASH).append(vol).append(BACKWARD_SLASH).append(platterName).append(BACKWARD_SLASH).append(finalFolderNumber).append(BACKWARD_SLASH).append(finalFileNumber);

			String finalFilePath = sb.toString();

			sb = null;

			if (finalFilePath != null) {
				tiffFiles.add(i, finalFilePath);
			} else {
				throw new CaseManagementRuntimeException("File Path values are coming null for the expag document legacy drives");
			}

			i++;

		}

		return tiffFiles;
	}
	
	public void updateDocumentInExpag(String docId, Document cmsDocument) throws Exception {
		// Corro Documents are under folder name "D+DocCreatedDate(yyMMdd)"
		String docPath = "d" + DateUtil.getStringDatefromXMLGregorianDate(cmsDocument.getDocCreateDateTime());
		webDAVClient.updateFile(webDAVPredocsUrl + BACKWARD_SLASH + docPath, docId, cmsDocument.getDocContent());
	}
	
	public void appendNote(String userId, String docId, Document cmsDocument) {
		
		byte[] appendedNoteContent = cmsDocument.getDocContent();
		ByteArrayOutputStream baos = null;

		try {
			if (appendedNoteContent.length > 0) {

				baos = new ByteArrayOutputStream();
				//add the newly appended note to the beginning of the stream..
				baos.write(appendedNoteContent);

				Document existingNote = new Document();
				
				//Get the Document content of existing document...
				for (int retryCount = 0; retryCount < 20; retryCount++) {
					
					org.tiaa.esb.powerimage.types.Document expagDocument = this.powerImageService
							.getDocument(userId, docId);

					if ((expagDocument != null)
							&& (expagDocument.getDocstream() != null)
							&& (expagDocument.getDocstream().getValue() != null)) {
						existingNote = this
								.getDocumentContentFromExpagDocument(expagDocument);
						if(existingNote.getDocContent().length > 0) {
							//add the existing note to the stream...
							baos.write(existingNote.getDocContent());
							break;
						}
					}else {
						try {
							Thread.sleep(3000);
						} catch (Exception exception) {
							LOGGER.error("Unable to put document thread in the sleep mode.");
						}
					}
				}			
			}
			
			// All EXPAG Documents are under folder name "D+DocCreatedDate(yyMMdd)"
			//String docCreatedDate = this.expagDAO.getDocCreateDate(docId);
			//String postfixDocPath = "d" + docCreatedDate;
			
			Map<String,Object> docInfoFromDB = this.expagDAO.getDocInfo(docId);
			String postfixDocPath = "d" + docInfoFromDB.get("CREATEDATE");

			webDAVClient.updateFile(webDAVPredocsUrl + BACKWARD_SLASH + postfixDocPath, docId, baos.toByteArray());
			
			//update newly added note type
			if(StringUtils.isNotBlank(cmsDocument.getDocTyp())) {
				if(this.expagDAO.selectContentCode(docId)){
						this.expagDAO.updateContentCode(cmsDocument.getDocTyp(), docId);
					}else{
						this.expagDAO.insertContentCode(cmsDocument.getDocTyp(),
								docId,
								cmsDocument.getProcessID().getTaskID(),
								Integer.parseInt("0"+ docInfoFromDB.get("BEGPAGENBR")),
								Integer.parseInt("0"+ docInfoFromDB.get("ENDPAGENBR")));
					}
				
			}
			
			//update date of the appended note..
			if (cmsDocument.getDocLastUpdTmstmp() != null) {
				String updateDate = DateUtil.getStringDatefromXMLGregorianDate(cmsDocument.getDocLastUpdTmstmp(), "yyyyMMdd");
				this.expagDAO.updateLastAccessDate(updateDate, docId);
			}
			
			
							
		}catch (Exception exception) {
			LOGGER.error("Exception in appending Notes" + exception.getLocalizedMessage());
			throw new CaseManagementRuntimeException(
					"Exception in appending notes " + exception.getMessage());		
			
		}			
	}
	
	
	/**
	 * Method to upload the documents in NFS storage and then add upoloaded URL
	 * into the powerimage creaeteDocuemtnsInfos request
	 * @throws IOException 
	 * 
	 */
	public List<CreateDocumentInfo> createExpagDocumentInfosRequest(Task cmsTask, Documents cmsDocuments) throws IOException {

		List<CreateDocumentInfo> createDocumentInfos = new ArrayList<CreateDocumentInfo>();

		if (cmsDocuments != null && !cmsDocuments.getDocuments().isEmpty()) {

			List<Document> cmsDocumentsList = cmsDocuments.getDocuments();

			// if the process have any Documents.
			for (Document cmsDocument : cmsDocumentsList) {

				org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo createDocumentInfo = new org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo();
				org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo.Mailinfo mailInfo = new org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo.Mailinfo();
				org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo.Internalinfo internalinfo = new org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo.Internalinfo();

				org.tiaa.esb.powerimage.createtask.types.DocumentContentInfo docContInfo = new org.tiaa.esb.powerimage.createtask.types.DocumentContentInfo();

				// Creating the unique guid for each document creation
				String guid = new GuidUtility().toString();

				createDocumentInfo.setStorage(EXPAG_STORAGE_INTERNAL);
				createDocumentInfo.setWrkstnid(EXPAG_WORKSTATION_TIAAPI);

				// Set mail description values
				mailInfo.setMaildesc(EXPAG_MAIL_DESC_REGULAR);
				mailInfo.setMailid(EXPAG_MAIL_ID_CMSUD + SPACE_COLON_SAPCE + guid);

				createDocumentInfo.setTotalpages(BigInteger.valueOf(1));
				docContInfo.setStartpage(BigInteger.valueOf(1));
				docContInfo.setEndpage(BigInteger.valueOf(1));

				docContInfo.setTaskonlyflg(EXPAG_ADD_DOCUMENT_TASK);
				
				docContInfo.setContentdesc(cmsDocument.getDocTyp());
				
				if (StringUtils.isNotBlank(cmsDocument.getDocTyp())) { 
					docContInfo.setContentdesc(cmsDocument.getDocTyp());
				}

				if (Routing.NOTE.toString().equalsIgnoreCase(cmsDocument.getDocDirection())) {

					createDocumentInfo.setPidoctype(EXPAG_PIDOCTYPE_NOTE);
					createDocumentInfo.setFiletype(EXPAG_FILETYPE_UNKNOWN);

					// Get the document content
					byte[] noteContent = cmsDocument.getDocContent();

					String note = new String(noteContent);

					internalinfo.setText(note);

				} else {

					String extension = cmsDocument.getDocXtnsn();

					if ("tif".equalsIgnoreCase(extension) || "tiff".equalsIgnoreCase(extension)) {
						createDocumentInfo.setPidoctype(EXPAG_PIDOCTYPE_IMAGE);
						createDocumentInfo.setFiletype(EXPAG_FILETYPE_TIFF);
					} else {
						if (EXPAG_PIDOCTYPE_CORRESPONDENCE.equalsIgnoreCase(cmsDocument.getDocTyp())) {
							createDocumentInfo.setPidoctype(EXPAG_PIDOCTYPE_CORRESPONDENCE);
							createDocumentInfo.setFiletype(EXPAG_CONT_TYPE_CORRESPONDENCE);
						} else {
							createDocumentInfo.setPidoctype(EXPAG_PIDOCTYPE_EXTERNAL);
						}
						createDocumentInfo.setFiletype(EXPAG_FILETYPE_UNKNOWN);
					}

					// Get the document content
					byte[] documentContent = cmsDocument.getDocContent();

					String documentName = cmsDocument.getDocName();

					String uploadfileName = this.expagFileUploadPath + BACKWARD_SLASH + documentName;
					RandomAccessFile fi = null;
					try {
						fi = new RandomAccessFile(new File(uploadfileName), READ_WRITE_MODE);
						fi.write(documentContent);
					} catch (IOException exception) {
						LOGGER.error(exception.getMessage());
						throw new CaseManagementRuntimeException("Error occured while dropping the file in the file path : " + uploadfileName);
					}
					finally{
						if(fi != null){
							fi.close();
						}
					}

					String urlDocPath = this.expagFileUploadUrl + BACKWARD_SLASH + documentName;

					LOGGER.debug(uploadfileName + " - Document successfully uploaded in the file share");

					internalinfo.setDocpath(urlDocPath);
				}

				createDocumentInfo.setInternalinfo(internalinfo);
				createDocumentInfo.setMailinfo(mailInfo);

				createDocumentInfo.getDocumentContentInfos().add(docContInfo);

				createDocumentInfos.add(createDocumentInfo);

			}
		}

		return createDocumentInfos;
	}
}
