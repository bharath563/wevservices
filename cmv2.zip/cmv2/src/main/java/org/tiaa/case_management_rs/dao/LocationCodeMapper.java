package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;

public class LocationCodeMapper extends AbstractRowMapper<PIOperatorLocation> implements RowMapper<PIOperatorLocation> {

	@Override
	public PIOperatorLocation mapRow(ResultSet rs, int rowNum) throws SQLException {

		PIOperatorLocation piOperatorLocation = new PIOperatorLocation();
		piOperatorLocation.setLocationCode(getStringTrimmed(rs, "LOCATIONCODE"));
		/*if we want to set the location name */
		//piOperatorLocation.setLocationName(getStringTrimmed(rs, "LOCATIONNAME"));
		
		return piOperatorLocation;
	}

}
