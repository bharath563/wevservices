package org.tiaa.case_management_rs.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.tiaa.case_management_rs.utils.CommonUtil;

@Entity
@Table(name = "CMS_AUDIT")
public class CMSAudit implements Serializable {
	private static final long serialVersionUID = -8039055731926421077L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CMS_AUDIT_SEQ")
	@SequenceGenerator(name = "CMS_AUDIT_SEQ", sequenceName = "CMREPORTING.CMS_AUDIT_SEQ", allocationSize = 1)
	private long cmsAuditId;
	private String caseId;
	private String taskId;
	private String taskType;
	private String cthOrchestrationId;
	private String cthRequestId;
	private String system;
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastUpdatedTs;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATED_DATE_TS")
	private Date createdDate;
	@OneToMany(mappedBy = "cmsAudit", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	private List<CMSAuditHistory> cmsAuditHistories;
	private boolean updateCthRequestId = false;
	@Column(name="SEND_EMAIL")
	private boolean sendEmail;
	@Column(name="EMAIL_SENT")
	private boolean emailSent;

	public String getCaseId() {
		return caseId;
	}

	public List<CMSAuditHistory> getCmsAuditHistories() {
		if (cmsAuditHistories == null) {
			cmsAuditHistories = new ArrayList<CMSAuditHistory>();
		}
		return cmsAuditHistories;
	}

	public long getCmsAuditId() {
		return cmsAuditId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public String getCthOrchestrationId() {
		return cthOrchestrationId;
	}

	public boolean hasCthOrchestrationId() {
		return CommonUtil.isNotNullAndNotEmpty(cthOrchestrationId);
	}

	public String getCthRequestId() {
		return cthRequestId;
	}

	public Date getLastUpdatedTs() {
		return lastUpdatedTs;
	}

	public String getSystem() {
		return system;
	}

	public String getTaskId() {
		return taskId;
	}

	public boolean isUpdateCthRequestId() {
		return updateCthRequestId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public void setCmsAuditHistories(List<CMSAuditHistory> cmsAuditHistories) {
		this.cmsAuditHistories = cmsAuditHistories;
	}

	public void setCmsAuditId(long id) {
		this.cmsAuditId = id;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public void setCthOrchestrationId(String cthOrchestrationId) {
		this.cthOrchestrationId = cthOrchestrationId;
	}

	public void setCthRequestId(String cthRequestId) {
		updateCthRequestId = CommonUtil.isNotNullAndNotEmpty(cthRequestId);
		this.cthRequestId = cthRequestId;
	}

	public void setLastUpdatedTs(Date lastUpdatedTs) {
		this.lastUpdatedTs = lastUpdatedTs;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	public boolean isSendEmail() {
		return sendEmail;
	}

	public void setSendEmail(boolean sendEmail) {
		this.sendEmail = sendEmail;
	}

	public boolean isEmailSent() {
		return emailSent;
	}

	public void setEmailSent(boolean emailSent) {
		this.emailSent = emailSent;
	}

	public void setUpdateCthRequestId(boolean updateCthRequestId) {
		this.updateCthRequestId = updateCthRequestId;
	}

	@Override
	public String toString() {
		return "CMSAudit [cmsAuditId=" + cmsAuditId + ", caseId=" + caseId + ", taskId=" + taskId + ", taskType=" + taskType + ", cthOrchestrationId="
						+ cthOrchestrationId + ", cthRequestId=" + cthRequestId + ", system=" + system + ", lastUpdatedTs=" + lastUpdatedTs
						+ ", createdDate=" + createdDate + ", updateCthRequestId=" + updateCthRequestId
						+ ", sendEmail=" + sendEmail + ", emailSent=" + emailSent + "]";
	}

}