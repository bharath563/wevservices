package org.tiaa.case_management_rs.integration.exp_ag;

import static org.tiaa.case_management_rs.integration.exp_ag.FailedEXPAGTaskCancellationRetrier.*;
import static org.tiaa.case_management_rs.integration.exp_ag.FailedEXPAGTaskRetrier.*;

import java.util.Date;

import org.apache.log4j.MDC;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.scheduling.annotation.Scheduled;

import org.tiaa.case_management_rs.common.ExceptionHandler;
import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.CMSPollerLog;
import org.tiaa.case_management_rs.domain.ProcessingStatus;
import org.tiaa.case_management_rs.domain.WorkflowSystem;
import org.tiaa.case_management_rs.email.EmailSender;
import org.tiaa.case_management_rs.email.EmailUtil;
import org.tiaa.case_management_rs.integration.case_manager.FailedCaseManagerCaseRetrier;
import org.tiaa.case_management_rs.integration.case_manager.cth.events.DocumentUploadProcessor;
import org.tiaa.case_management_rs.poller.Poller;
import org.tiaa.case_management_rs.poller.WorkflowSystemPoller;
import org.tiaa.case_management_rs.repository.CMSAuditHistoryRepository;

@Poller
public class RetryFailedTasksPoller extends WorkflowSystemPoller {
	@Autowired
	private CMSAuditHistoryRepository cmsAuditHistoryRepository;
	@Autowired
	private FailedEXPAGTaskRetrier failedEXPAGTaskRetrier;
	@Autowired
	private FailedEXPAGTaskCancellationRetrier failedEXPAGTaskCancellationRetrier;
	@Autowired
	private FailedCaseManagerCaseRetrier failedCaseManagerCaseRetrier;
	@Value("${retry.max.attempts}")
	private int maxNoOfRetries;
	@Autowired
	private EmailSender emailSender;
	@Autowired
	private DocumentUploadProcessor documentUploadProcessor;

	public RetryFailedTasksPoller() {
		super(WorkflowSystem.EXP_AG_Retry);
	}
	/*
	 * *******************************************************************************************************
	 * DISABLING CM POLLER FOR OCT 2016 POLLER, by commenting @Scheduled
	 * ********************************************************************************************************
	 */
//	@Scheduled(cron = EVERY_5_MINUTES_AT_15TH_SECOND)
	public void pollDatabase() {
		pollWithLock(this);
	}

	public void run() {
		final int secondStartingAtFifteen = 15;
		pollForInterval(secondStartingAtFifteen);
	}

	public void execute(CMSPollerLog pollerLog) {
		log.debug("start poll retry failed tasks");
		for (final CMSAuditHistory cmsAuditHistory : cmsAuditHistoryRepository.findByStatus(ProcessingStatus.Failed.name())) {
			MDC.put("X-INF-RequestID", cmsAuditHistory.getTaskId());
			try {
				ExceptionHandler.createSafeRunnable(new Runnable() {
					@Override
					public void run() {
						process(cmsAuditHistory);
					}
				}).run();
			} finally {
				MDC.remove("X-INF-RequestID");
			}
		}
		log.debug("end poll retry failed tasks");
	}

	private void process(final CMSAuditHistory cmsAuditHistory) {
		log.info("processing record: {}", cmsAuditHistory);
		int retryAttempt = cmsAuditHistory.getRetryAttempt();

		if(cmsAuditHistory.getCmsAudit() == null || cmsAuditHistory.getCmsAudit().getSystem() == null){
			cmsAuditHistory.setStatus(ProcessingStatus.Aborted.name());
			cmsAuditHistory.setLastUpdatedTs(new Date());
			cmsAuditHistoryRepository.save(cmsAuditHistory);
			return;
		}


		String system = cmsAuditHistory.getCmsAudit().getSystem();
		boolean isEXPAGWorkflowSystem = "EXP_AG".equals(system) || "EXPAG".equals(system);
		if (retryAttempt >= maxNoOfRetries) { //exhausted
			cmsAuditHistory.setStatus(ProcessingStatus.Aborted.name());
			cmsAuditHistory.setLastUpdatedTs(new Date());
			cmsAuditHistoryRepository.save(cmsAuditHistory);
			log.debug("exhaused {} attempts", maxNoOfRetries);

			boolean sendEmailOnRetryFailure = !isEXPAGWorkflowSystem;
			if (isCancelEXPAGTaskRecord(cmsAuditHistory) || updateCTHRecordFailed(cmsAuditHistory)) {
				sendEmailOnRetryFailure = true;
			}
			if (sendEmailOnRetryFailure) {
				String emailText = "Retry attempt failed for Task Id: " + cmsAuditHistory.getTaskId();
				emailSender.sendEmailToProdSupport(emailText, EmailUtil.createEmail(emailText));
			}
			return;
		}
		cmsAuditHistory.setRetryAttempt(retryAttempt + 1);
		if (isCancelEXPAGTaskRecord(cmsAuditHistory)) {
			failedEXPAGTaskCancellationRetrier.retryFailedEXPAGTaskCancellation(cmsAuditHistory);
			return;
		}
		if (isDocumentUploadEvent(cmsAuditHistory)) {
			documentUploadProcessor.retryFailedDocumentUploadEvent(cmsAuditHistory);
			return;
		}
		if (!sendingPlanModificationRequestEmailFailed(cmsAuditHistory) && !createCTHRecordFailed(cmsAuditHistory) && !updateCTHRecordFailed(cmsAuditHistory)) {
			log.info("not processing");
			cmsAuditHistory.setStatus(ProcessingStatus.Ignore.name());
			cmsAuditHistoryRepository.save(cmsAuditHistory);
			return;
		}
		if (isEXPAGWorkflowSystem) {
			failedEXPAGTaskRetrier.retryFailedEXPAGTask(cmsAuditHistory);
		} else {
			failedCaseManagerCaseRetrier.retryFailedCaseManagerCase(cmsAuditHistory);
		}
	}

}
