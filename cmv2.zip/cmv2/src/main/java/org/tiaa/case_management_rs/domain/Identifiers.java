package org.tiaa.case_management_rs.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Identifiers implements Serializable {
	private static final long serialVersionUID = -5735722716538841204L;
	private Map<String, Identifier> identifierByNameMap = new LinkedHashMap<String, Identifier>();

	public void addIdentifier(String name, Object value) {
		Identifier identifier = new Identifier(name, value);
		getIdentifiers().add(identifier);
		identifierByNameMap.put(name, identifier);
	}

	public Identifier getIdentifier(String name) {
		return identifierByNameMap.get(name);
	}

	public List<Identifier> getIdentifiers() {
		return new ArrayList<Identifier>(identifierByNameMap.values());
	}

	public String getIdentifierStringValue(String name) {
		Identifier identifier = identifierByNameMap.get(name);
		if (identifier == null) {
			return "";
		}
		Object value = identifier.getValue();
		if (value == null) {
			return "";
		}
		return value.toString();
	}

	public Object getIdentifierValue(String name) {
		return identifierByNameMap.get(name).getValue();
	}

	public void setIdentifiers(Map<String, Object> identifiers) {
		for (Entry<String, Object> entry : identifiers.entrySet()) {
			String key = entry.getKey();
			Identifier identifier = new Identifier();
			identifier.setName(key);
			identifier.setValue(entry.getValue());
			identifierByNameMap.put(key, identifier);
		}
	}

	@Override
	public String toString() {
		return "Identifiers [identifierByNameMap=" + identifierByNameMap + "]";
	}
}
