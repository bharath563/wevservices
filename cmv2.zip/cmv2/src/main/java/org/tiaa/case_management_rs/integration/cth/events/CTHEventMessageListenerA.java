package org.tiaa.case_management_rs.integration.cth.events;

import org.springframework.jms.annotation.JmsListener;

public class CTHEventMessageListenerA extends AbstractMessageListener {
	@JmsListener(destination = "APPL.CTH.CMUDRS.INPUT", containerFactory = "jmsListenerContainerFactoryA")
	public void processEventMessage(String jmsMessage) {
		super.processEventMessage(jmsMessage);
	}
}