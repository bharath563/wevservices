package org.tiaa.case_management_rs.dao;

import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import org.tiaa.case_management_rs.domain.EXPAGFileInfo;

@Repository
public class ProcessDBDAO {

	private static final Logger LOG = LoggerFactory.getLogger(ProcessDBDAO.class);

	@Value("${CMSGetAllTaskSLA}")
	private String cmsGetAllTaskSla;

	private boolean debugSql;

	@Value("${CMSDocumentFilePath}")
	private String filePathSql;

	@Value("${CMSOriginalSLA}")
	private String originalSlaSql;
	
	@Value("${CMSGetUpdatedSLA}")
	private String updatedSLASql;

	@Autowired
	private JdbcTemplate processJdbcTemplate;

	protected void debugSQL(String sql) {
		if (this.debugSql) {
			LOG.debug("sql: {}", sql);
		}
	}



	public List<CMSTaskTypeSla> getAllTaskSLA() {
		CMSTaskTypeSLAMapper mapper = new CMSTaskTypeSLAMapper();
		return query(this.cmsGetAllTaskSla, mapper, null);
	}


	public List<EXPAGFileInfo> getFilePathInfo(String platter, String dev) {

		EXPAGFilePathMapper expagFileInfomapper = new EXPAGFilePathMapper();
		Object[] args = new Object[]{platter, dev};
		return query(this.filePathSql, expagFileInfomapper, args);

	}


	public Integer getOriginalSLA(String reqType) {

		Integer originalSla = 0;

		OriginalSLAInfoMapper mapper = new OriginalSLAInfoMapper();

		Object[] args = new Object[]{reqType};
		List<Integer> originalSLAList = query(this.originalSlaSql, mapper, args);

		if ((originalSLAList != null) && (originalSLAList.size() > 0)) {
			originalSla = originalSLAList.get(0);
		}

		return originalSla;
	}
	
	public List<CMSTaskTypeSla> getUpdatedSLA() {
		CMSTaskTypeSLAMapper mapper = new CMSTaskTypeSLAMapper();
		return query(this.updatedSLASql, mapper, null);
	}

    protected <T> List<T> query(String sql, RowMapper<T> rowMapper, Object[] args) {
        try {
              List<T> rows = this.processJdbcTemplate.query(sql, args, rowMapper);
              LOG.info("SQL:{}, rows:{}", sql, rows.size());
              return rows;
        } catch (DataAccessException e) {
              LOG.warn("sql:{}", sql);
              LOG.warn(e.getMessage(), e);
              if (args != null && args.length > 0) {
                    for (Object object : args) {                          
                          LOG.warn("arg:{}", object);
                    }
              }                 
        }           
        return Collections.emptyList();
  }


}
