package org.tiaa.case_management_rs.integration.clients;

import org.springframework.ws.client.core.WebServiceMessageCallback;

public interface JaxWsClient<T> {
	
	public T marshallSendAndReceive(Object requestPayload, WebServiceMessageCallback webServiceMessageCallback);

}
