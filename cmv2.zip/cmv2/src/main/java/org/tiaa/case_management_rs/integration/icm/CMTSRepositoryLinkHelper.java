package org.tiaa.case_management_rs.integration.icm;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CMTSRepositoryLinkHelper {

	@Value("${nigoTaskSearchURL}")
	private String nigoTaskSearchURL;

	public String getNigoTaskSearchURL() {
		return this.nigoTaskSearchURL;
	}
}
