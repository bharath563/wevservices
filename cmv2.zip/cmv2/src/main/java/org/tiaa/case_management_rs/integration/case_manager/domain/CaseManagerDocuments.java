package org.tiaa.case_management_rs.integration.case_manager.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class CaseManagerDocuments implements Serializable {
	private static final long serialVersionUID = 388138516631350258L;
	private List<CaseManagerDocument> documents;

	public List<CaseManagerDocument> getDocuments() {
		if (documents == null) {
			documents = new ArrayList<CaseManagerDocument>();
		}
		return this.documents;
	}

	@Override
	public String toString() {
		return "CaseManagerDocument [documents=" + documents + "]";
	}
}
