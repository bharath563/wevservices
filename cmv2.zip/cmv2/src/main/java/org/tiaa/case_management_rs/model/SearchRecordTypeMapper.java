package org.tiaa.case_management_rs.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class SearchRecordTypeMapper implements RowMapper  
{  
    public Object mapRow(ResultSet rs, int rowNum) throws SQLException  
    {  
    	SearchRecord searchRecord = new SearchRecord();
    	searchRecord.setActdesc(rs.getString("actionstep"));
    	searchRecord.setAssignedto(rs.getString("assignedto"));
    	searchRecord.setBeginDate(rs.getInt("createdate"));
    	searchRecord.setBegintime(rs.getInt("createtime"));
    	searchRecord.setChannel(rs.getString("channel"));
    	searchRecord.setClientid(rs.getString("clientid"));
    	searchRecord.setCreateoper(rs.getString("createoper"));
    	searchRecord.setDatercvd(rs.getInt("datercvd"));
    	searchRecord.setDepartment(rs.getString("dptdesc"));
    	searchRecord.setDepartmentdescription(rs.getString("departmentdescription"));
    	searchRecord.setLckoper(rs.getString("lckoper"));
    	searchRecord.setPlanid(rs.getString("planid"));
    	searchRecord.setPlanname(rs.getString("planname"));
    	searchRecord.setRN(rs.getInt("RN"));
    	searchRecord.setSuspoper(rs.getString("suspoper"));
    	searchRecord.setTaskdescription(rs.getString("taskdescription"));
    	searchRecord.setTasktype(rs.getString("tasktype"));
    	searchRecord.setTimercvd(rs.getInt("timercvd"));

    	return searchRecord;  
    }  
}
