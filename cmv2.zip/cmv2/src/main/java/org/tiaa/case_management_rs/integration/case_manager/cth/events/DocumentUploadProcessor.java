package org.tiaa.case_management_rs.integration.case_manager.cth.events;

import java.util.List;
import java.util.UUID;

import javax.validation.ValidationException;
import javax.xml.transform.dom.DOMSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Component;
import org.springframework.xml.transform.StringSource;

import org.tiaa.case_management_rs.domain.CMSAudit;
import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.email.EmailSender;
import org.tiaa.case_management_rs.email.EmailUtil;
import org.tiaa.case_management_rs.integration.case_manager.cth.CTHCaseRecordRetriever;
import org.tiaa.case_management_rs.integration.case_manager.domain.Case;
import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;
import org.tiaa.case_management_rs.integration.cth.events.AbstractEventProcessor;
import org.tiaa.case_management_rs.repository.CMSAuditRepository;
import org.tiaa.case_management_rs.repository.CMSAuditService;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.cth.event.generated.jaxb.types.EventPayLoadInfo;
import org.tiaa.cth.event.generated.jaxb.types.EventRequest;
import org.tiaa.cth.event.generated.jaxb.types.EventType;
import org.tiaa.esb.partyrequest.types.AdditionalRequestIdentifier;
import org.tiaa.esb.partyrequest.types.PartyRequestResponse;
import org.tiaa.esb.partyrequest.types.PartyRequestResponses;
import org.tiaa.esb.partyrequest.types.PayloadInfo;
import org.tiaa.esb.partyrequest.types.RequestInfo;
import org.tiaa.esb.partyrequest.types.RetrieveRequestsResp;
import org.tiaa.esb.partyrequest.types.RetrieveRequestsResponse;
import org.tiaa.esb.servicerequest.types.CTHClob;
import org.tiaa.esb.servicerequest.types.OtherData;
import org.tiaa.esb.servicerequest_workflow.types.CaseDetailsType;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;
import org.tiaa.esb.servicerequest_workflow.types.DocumentType;

@Component
public class DocumentUploadProcessor extends AbstractEventProcessor {
	private static final Logger LOG = LoggerFactory.getLogger(DocumentUploadProcessor.class);
	private static final String SOLUTION_TYPE = "Institutional Client Solutions";
	private static final String CASE_TYPE = "ICS_PlanAdmin";
	private static final String TASK_OPERATION = "ICS_AddDocument";
	private static final String CHANNEL = "PlanFocus";
	private static final String ORIGINATOR_ID = "PlanFocus";
	private static final String RESPONSE_REQUIRED = "NONE";
	private static final String LAST_UPDATED_DRI = "LastUpdatedDRI";
	private static final String PROCESS_PRIORITY = "high";
	@Autowired
	private Jaxb2Marshaller cthJaxb2Marshaller;
	@Autowired
	private Jaxb2Marshaller serviceRequestWorkflowJaxb2Marshaller;
	@Autowired
	private Jaxb2Marshaller caseManagerServiceRequestJaxb2Marshaller;
	@Autowired
	private CaseInRosterDAO caseInRosterDAO;
	@Autowired
	private DocumentUploadPayloadBuilder pfDocUploadPayloadBuilder;
	@Value("${cm.hostname}")
	private String cmHostName;
	@Autowired
	private CMSAuditService cmsAuditService;
	@Autowired
	private CMSAuditRepository cmsAuditRepository;
	@Autowired
	private EmailSender emailSender;
	@Autowired
	private CTHCaseRecordRetriever cthRecordRetriever;

	public void process(EventRequest eventRequest, CMSAuditHistory cmsAuditHistory) {
		final EventType event = eventRequest.getEvent();
		//
		String requestType = event.getRequestType();
		LOG.debug("requestType:{}", requestType);
		//
		EventPayLoadInfo payload = event.getPayload();
		Element retrieveRequestsResponseElement = payload.getAny();
		if (LOG.isDebugEnabled()) {
			LOG.debug("payload:{}", toString(retrieveRequestsResponseElement));
		}
		//
		PartyRequestResponse partyRequestResponse = getPartyRequestResponse(getDomSource(retrieveRequestsResponseElement));
		try {
			 processEvent(partyRequestResponse, cmsAuditHistory);
			 cmsAuditService.markSuccessfullyProcessed(cmsAuditHistory);
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
			cmsAuditService.markAsFailed(cmsAuditHistory, e);
			String orchestrationID = partyRequestResponse.getOrchestrationID();
			emailSender.sendEmailToProdSupport("Error while handling document upload event for CTH Orchestration Id:" + orchestrationID, EmailUtil.createEmail(cmsAuditHistory, e));
		}
	}

	public void retryFailedDocumentUploadEvent(CMSAuditHistory cmsAuditHistory) {
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		String cthOrchestrationId = cmsAudit.getCthOrchestrationId();
		//
		CaseDetails caseDetails = new CaseDetails();
		caseDetails.setKase(new Case());
		caseDetails.setCthOrchestrationId(cthOrchestrationId);
		//
		PartyRequestResponse partyRequestResponse = null;
		try {
			partyRequestResponse = cthRecordRetriever.retrieveCTHRecordForCaseDetails(caseDetails);
			processEvent(partyRequestResponse, cmsAuditHistory);
			cmsAuditService.markSuccessfullyProcessed(cmsAuditHistory);
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
			cmsAuditService.markAsFailed(cmsAuditHistory, e);
			final String subject = "Error while handling document upload event for CTH Orchestration Id:" + cthOrchestrationId;
			emailSender.sendEmailToProdSupport(subject, EmailUtil.createEmail(cmsAuditHistory, e));
		}
	}

	public int process(String xmlMessage) {
		try {
			 processEvent(getPartyRequestResponse(xmlMessage), null);
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
		}
		return -1;
	}

	private int processEvent(PartyRequestResponse partyRequestResponse, CMSAuditHistory cmsAuditHistory) {
		String orchestrationID = partyRequestResponse.getOrchestrationID();
		String requestID = getAdditionalRequestIdentifierValue(partyRequestResponse, "WorkflowTaskID");
		String lastUpdatedDRI = getAdditionalRequestIdentifierValue(partyRequestResponse, LAST_UPDATED_DRI);
		//
		CaseInfo caseInfo = getCaseInfo(partyRequestResponse);
		CaseDetailsType caseDetails = caseInfo.getCaseDetails();
		//
		cmsAuditHistory.setComments(String.format("orchId=%s,lastUpdatedDRI=%s", orchestrationID, lastUpdatedDRI));
		if (caseDetails != null) {
			String caseId = caseDetails.getCaseId();
			cmsAuditHistory.setTaskId(caseId);
			CMSAudit cmsAudit = cmsAuditRepository.findByTaskId(caseId);//taskId is same as caseId for case-manager
			if (cmsAudit != null) {
				cmsAuditHistory.setCmsAudit(cmsAudit);
			}
		}
		LOG.debug("lastUpdatedDRI:" + lastUpdatedDRI);
		DocumentType documentType = findDocument(caseInfo, lastUpdatedDRI);
		LOG.debug("found document:" + documentType);
		//
		CaseInRosterItem caseInRosterItem = createCaseInRosterItem(caseDetails, orchestrationID, requestID);
		String inputPayload = pfDocUploadPayloadBuilder.process(caseInfo, caseInRosterItem, documentType);
		LOG.debug("caseInRoster input payload:" + inputPayload);
		caseInRosterItem.setInputPayload(inputPayload);
		//
		int noOfRecordsInserted = caseInRosterDAO.insert(caseInRosterItem);
		LOG.debug("No of records inserted Successfuly:" + inputPayload);
		return noOfRecordsInserted;
	}

	private String getAdditionalRequestIdentifierValue(PartyRequestResponse partyRequestResponse, String key) {
		for (AdditionalRequestIdentifier additionalRequestIdentifier : partyRequestResponse.getAdditionalRequestIdentifiers().getAdditionalRequestIdentifiers()) {
			if (key.equals(additionalRequestIdentifier.getKey())) {
				return additionalRequestIdentifier.getValue();
			}
		}
		return null;
	}

	private CaseInRosterItem createCaseInRosterItem(CaseDetailsType caseDetails, String orchestrationID, String requestID) {
		CaseInRosterItem caseInRosterItem = new CaseInRosterItem();
		caseInRosterItem.setCaseId(caseDetails.getCaseId());
		caseInRosterItem.setCaseType(CASE_TYPE);
		caseInRosterItem.setCorrelationId(UUID.randomUUID().toString());
		caseInRosterItem.setOrchestrationId(orchestrationID);
		caseInRosterItem.setSolutionType(SOLUTION_TYPE);
		caseInRosterItem.setTaskOperation(TASK_OPERATION);
		caseInRosterItem.setChannel(CHANNEL);
		caseInRosterItem.setResponseRequired(RESPONSE_REQUIRED);
		caseInRosterItem.setOriginatorId(ORIGINATOR_ID);
		caseInRosterItem.setRequestId(requestID);
		caseInRosterItem.setRecievedDateTime(DateUtil.getCurrentDateInDateTime());
		caseInRosterItem.setChannelPutTime(DateUtil.getCurrentDateInDateTime());
		caseInRosterItem.setProcessingPriority(PROCESS_PRIORITY);
		caseInRosterItem.setProcessedDateTime(null);
		caseInRosterItem.setDispatchedDateTime(null);
		caseInRosterItem.setCmHostName(cmHostName);
		caseInRosterItem.setStatus("0");
		return caseInRosterItem;
	}

	private PartyRequestResponse getPartyRequestResponse(String xmlMessage) {
		RetrieveRequestsResponse retrieveRequestsResponse = (RetrieveRequestsResponse) cthJaxb2Marshaller.unmarshal(new StringSource(xmlMessage));
		RetrieveRequestsResp retrieveRequestsResp = retrieveRequestsResponse.getRetrieveRequestsResp();
		PartyRequestResponses partyRequestResponses = retrieveRequestsResp.getPartyRequestResponses();
		List<PartyRequestResponse> partyRequestResponseList = partyRequestResponses.getPartyRequestResponses();
		PartyRequestResponse partyRequestResponse = partyRequestResponseList.get(0);
		return partyRequestResponse;
	}

	private CaseInfo getCaseInfo(PartyRequestResponse partyRequestResponse) {
		PayloadInfo payloadInfo = partyRequestResponse.getPayloadInfo();
		RequestInfo requestInfo = payloadInfo.getRequestInfo();
		CTHClob cthClob = getCTHClob(requestInfo);
		return getCaseInfo(cthClob);
	}

	private CTHClob getCTHClob(RequestInfo requestInfo) {
		DOMSource domSource = getDomSource(requestInfo.getAny());
		return (CTHClob) caseManagerServiceRequestJaxb2Marshaller.unmarshal(domSource);
	}

	private CaseInfo getCaseInfo(CTHClob cthClob) {
		OtherData otherData = cthClob.getOtherData();
		return (CaseInfo) serviceRequestWorkflowJaxb2Marshaller.unmarshal(getDomSource(otherData.getWorkFlowXML().getAny()));
	}

	private DOMSource getDomSource(Element any) {
		DOMSource domSource = new DOMSource();
		domSource.setNode(any);
		return domSource;
	}

	private DocumentType findDocument(CaseInfo caseInfo, String lastUpdatedDRI) {
		List<DocumentType> documents = caseInfo.getDocuments().getDocuments();
		for (DocumentType documentType : documents) {
			String docID = documentType.getDocumentIDs().getDocumentIDs().get(0).getValue();
			if (docID.equals(lastUpdatedDRI)) {
				return documentType;
			} else {
				LOG.debug("DRI do not match: {}, {}", docID, lastUpdatedDRI);
			}
		}
		throw new ValidationException("Document not found for DRI:" + lastUpdatedDRI);
	}

}
