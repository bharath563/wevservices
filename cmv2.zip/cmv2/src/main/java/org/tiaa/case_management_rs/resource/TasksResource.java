package org.tiaa.case_management_rs.resource;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.container.ResourceContext;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.common.impl.RequestImpl;
import org.tiaa.case_management_rs.service.CaseManagementRestService;
import org.tiaa.esb.case_management_rs_v2.type.TaskRequest;

public class TasksResource {

	@Context
	private ResourceContext resourceContext;
	
	@Autowired
	private CaseManagementRestService caseManagmentRestService;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(TasksResource.class);

	
	@GET
	@Produces({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	public Response getTasks(@QueryParam(USER_ID) String userId, @PathParam(PROCESS_ID) String processId, 
			@QueryParam(APP_NAME) String appName, @QueryParam(START_OMNI_TASKS) String startOmniTasks, 
			@QueryParam(START) String start, @QueryParam(OMNI_TASK_PLAN) String plan, @QueryParam(OMNI_TASK_SUBPLAN) String subPlan) {

		LOGGER.debug("Entering getTasks");
		LOGGER.debug("Request Params");
		LOGGER.debug(USER_ID + SPACE_HYPEN_SAPCE + userId);
		LOGGER.debug(PROCESS_ID + SPACE_HYPEN_SAPCE + processId);
		LOGGER.debug(APP_NAME + SPACE_HYPEN_SAPCE + appName);
		LOGGER.debug(START_OMNI_TASKS + SPACE_HYPEN_SAPCE + startOmniTasks);
		LOGGER.debug(START + SPACE_HYPEN_SAPCE + start);
		LOGGER.debug(OMNI_TASK_PLAN + SPACE_HYPEN_SAPCE + plan);
		LOGGER.debug(OMNI_TASK_SUBPLAN + SPACE_HYPEN_SAPCE + subPlan);

		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		// Get all the request parameter string values
		request.setAttribute(USER_ID, userId);
		request.setAttribute(PROCESS_ID, processId);
		request.setAttribute(APP_NAME, appName);	
		request.setAttribute(START_OMNI_TASKS, startOmniTasks);
		request.setAttribute(START, start);
		request.setAttribute(OMNI_TASK_PLAN, plan);
		request.setAttribute(OMNI_TASK_SUBPLAN, subPlan);
		Response response = this.caseManagmentRestService.getTasks(request);

		LOGGER.debug("Exiting getProcess");

		return response;

	}
	
	@POST
	@Produces({ MediaTypes.V2_XML, MediaTypes.V2_JSON })
	@Consumes({ MediaTypes.V2_XML, MediaTypes.V2_JSON })
	public Response createTask(@PathParam(PROCESS_ID) String caseId, @QueryParam("userid") String userId,
			@QueryParam("appname") String appName, TaskRequest taskRequest) {

		LOGGER.debug("Entering createTask");
		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		request.setAttribute(PROCESS_ID, caseId);
		request.setAttribute(APP_NAME, appName);
		request.setAttribute(USER_ID, userId);
		request.setAttribute(TASK_REQUEST, taskRequest);
		Response response = this.caseManagmentRestService.createTask(request);
		
		LOGGER.debug("Exiting createTask");

		return response;
	}
	
	@Path("/{taskid}")
	public TaskResource taskSubResource() {
		return this.resourceContext.getResource(TaskResource.class);
	}
}
