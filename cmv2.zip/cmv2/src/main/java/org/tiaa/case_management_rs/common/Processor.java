package org.tiaa.case_management_rs.common;

public interface Processor<IN, OUT> {
	OUT process(IN in);
}
