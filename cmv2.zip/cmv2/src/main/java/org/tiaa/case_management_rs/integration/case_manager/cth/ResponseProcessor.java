package org.tiaa.case_management_rs.integration.case_manager.cth;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.esb.partyrequest.types.CreateRequestsResp;
import org.tiaa.esb.partyrequest.types.CreateRequestsResponse;
import org.tiaa.esb.partyrequest.types.ESBMessage;
import org.tiaa.esb.partyrequest.types.ESBMessages;
import org.tiaa.esb.partyrequest.types.HierarchyPartyRequestIdentifier;
import org.tiaa.esb.partyrequest.types.HierarchyPartyRequestIdentifiers;
import org.tiaa.esb.partyrequest.types.ResponseStatus;
import org.tiaa.esb.partyrequest.types.UpdateRequestsResp;
import org.tiaa.esb.partyrequest.types.UpdateRequestsResponse;

public class ResponseProcessor {
	private static final Logger LOG = LoggerFactory.getLogger(CTHCaseWebService.class);

	public boolean processCreateResponse(CreateCTHCaseContext context, CreateRequestsResponse createRequestsResponse) {
		CreateRequestsResp createRequestsResp = createRequestsResponse.getCreateRequestsResp();
		if (createRequestsResp == null) {
			LOG.warn("createRequestsResp is null");
			return false;
		}
		ResponseStatus responseStatus = createRequestsResp.getResponseStatus();
		boolean success = processResponseStatus(responseStatus);
		if (success) {
			setRequestInfo(context, createRequestsResp);
		}
		return success;
	}

	private void setRequestInfo(CreateCTHCaseContext context, CreateRequestsResp createRequestsResp) {
		HierarchyPartyRequestIdentifiers hierarchyPartyRequestIdentifiers = createRequestsResp.getHierarchyPartyRequestIdentifiers();
		if (hierarchyPartyRequestIdentifiers == null) {
			return;
		}
		List<HierarchyPartyRequestIdentifier> hierarchyPartyRequestIdentifierList = hierarchyPartyRequestIdentifiers.getHierarchyPartyRequestIdentifiers();
		if (hierarchyPartyRequestIdentifierList == null) {
			return;
		}
		for (HierarchyPartyRequestIdentifier hierarchyPartyRequestIdentifier : hierarchyPartyRequestIdentifierList) {
			long requestIdentifier = hierarchyPartyRequestIdentifier.getRequestIdentifier();
			String orchestrationID = hierarchyPartyRequestIdentifier.getOrchestrationID();
			LOG.debug("requestIdentifier:{}", requestIdentifier);
			LOG.debug("orchestrationID:{}", orchestrationID);
			context.setCthOrchestrationId(orchestrationID);
			context.setCthRequestId(String.valueOf(requestIdentifier));
		}
	}

	public void processUpdateResponse(UpdateRequestsResponse updateRequestsResponse) {
		UpdateRequestsResp updateRequestsResp = updateRequestsResponse.getUpdateRequestsResp();
		if (updateRequestsResp == null) {
			LOG.warn("updateRequestsResp is null");
			return;
		}
		ResponseStatus responseStatus = updateRequestsResp.getResponseStatus();
		processResponseStatus(responseStatus);
	}

	public boolean processResponseStatus(ResponseStatus responseStatus) {
		if (responseStatus == null) {
			LOG.warn("responseStatus is null");
			return false;
		}
		LOG.debug(String.format("status: %s, statusText: %s", responseStatus.getStatus(), responseStatus.getStatusText()));
		ESBMessages messages = responseStatus.getMessages();
		if (messages == null) {
			LOG.warn("messages is null");
			return outcome(responseStatus);
		}
		for (ESBMessage esbMessage : messages.getMessages()) {
			LOG.debug(String.format("code: %s, type: %s, text: %s", esbMessage.getCode(), esbMessage.getText(), esbMessage.getType()));
		}
		return outcome(responseStatus);
	}

	private boolean outcome(ResponseStatus responseStatus) {
		return "SUCCESS".equals(responseStatus.getStatus());
	}

}
