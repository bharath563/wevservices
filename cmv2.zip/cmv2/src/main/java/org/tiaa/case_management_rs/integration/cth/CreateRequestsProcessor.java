package org.tiaa.case_management_rs.integration.cth;

import org.tiaa.case_management_rs.common.Processor;
import org.tiaa.case_management_rs.integration.plan_sponsor.ContactResponseProcessor;
import org.tiaa.esb.partyrequest.types.CreateRequests;
import org.tiaa.esb.plansponsor.types.ContactResponse;

public class CreateRequestsProcessor implements Processor<CreateCTHContext, CreateRequests> {
	private CreateHierarchyPartyRequestBuilder createHierarchyPartyRequestBuilder;
	private ContactResponseProcessor contactResponseProcessor;

	public CreateRequests process(CreateCTHContext context) {
		ContactResponse contactResponse = contactResponseProcessor.process(context.getCustomerNumber());
		context.setContactResponse(contactResponse);
		return createHierarchyPartyRequestBuilder.build(context);
	}

	public void setCreateHierarchyPartyRequestBuilder(CreateHierarchyPartyRequestBuilder createHierarchyPartyRequestBuilder) {
		this.createHierarchyPartyRequestBuilder = createHierarchyPartyRequestBuilder;
	}

	public void setContactResponseProcessor(ContactResponseProcessor contactResponseProcessor) {
		this.contactResponseProcessor = contactResponseProcessor;
	}
}
