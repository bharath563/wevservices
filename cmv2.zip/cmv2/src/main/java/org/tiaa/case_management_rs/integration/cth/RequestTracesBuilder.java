package org.tiaa.case_management_rs.integration.cth;

import org.tiaa.esb.partyrequest.types.RequestTrace;
import org.tiaa.esb.partyrequest.types.RequestTraces;

public class RequestTracesBuilder {
	public RequestTraces createRequestTraces() {
		RequestTrace requestTrace = new RequestTrace();
		requestTrace.setTraceApplicationName("");
		requestTrace.setTraceCode("");
		requestTrace.setTraceMessage("");
		//
		RequestTraces requestTraces = new RequestTraces();
		requestTraces.getRequestTraces().add(requestTrace);
		return requestTraces;
	}
}
