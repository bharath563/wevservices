package org.tiaa.case_management_rs.common;

/**
 * This interface will be used to send request attributes to business processing
 * layer from service interaction layer
 */
public interface Request {

	/**
	 * Holds the key to store request usage statistics object
	 */
	static final String REQUEST = "REQUEST_";

	/**
	 * This method is used to get an object from the request based on a key.
	 *
	 * @param key
	 *            Key to get the object from request
	 * @return Object Object that was stored in request for the given key; Null
	 *         if there is no object exists.
	 */
	Object getAttribute(String key);

	/**
	 * This method is used to set the object in the request using the given key.
	 *
	 * @param key
	 *            Key to set the object in request
	 * @param value
	 *            Object to be added in the request
	 */
	void setAttribute(String key, Object value);
}
