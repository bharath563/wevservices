package org.tiaa.case_management_rs.syncup.customer_webform;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.CMRSEvent;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.email.EmailSender;
import org.tiaa.case_management_rs.email.EmailUtil;
import org.tiaa.case_management_rs.integration.cth.CTHRecordNotFoundException;
import org.tiaa.case_management_rs.integration.cth.CTHUpdateRecordFailedException;
import org.tiaa.case_management_rs.integration.cth.RetryableCTHRecordUpdater;
import org.tiaa.case_management_rs.integration.exp_ag.AbstractEXPAGTaskProcessor;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTaskProcessor;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTaskType;
import org.tiaa.case_management_rs.syncup.service_request.ServiceRequestEXPAGTaskProcessor;
import org.tiaa.case_management_rs.utils.CommonUtil;

@Component
@EXPAGTaskType(schemaName = "customer-webform-1-0-clob.xsd")
public class CustomerWebFormEXPAGTaskProcessor extends AbstractEXPAGTaskProcessor implements EXPAGTaskProcessor {
	private static final Logger LOG = LoggerFactory.getLogger(CustomerWebFormEXPAGTaskProcessor.class);
	@Autowired
	private EmailSender emailSender;
	@Autowired
	private ServiceRequestEXPAGTaskProcessor serviceRequestEXPAGTaskProcessor;
	@Autowired
	private RetryableCTHRecordUpdater customerWebFormRetryableCTHRecordUpdater;

	@PostConstruct
	public void init() {
		retryableCTHRecordUpdater = customerWebFormRetryableCTHRecordUpdater;
	}

	public void processTask(TaskInfo taskInfo) {
		if (CommonUtil.isNullOrEmpty(taskInfo.getCreateOperator())) {
			LOG.warn("create operator is null or empty, won't process the task");
			return;
		}
		CMSAuditHistory cmsAuditHistory = cmsAuditService.createCMSAuditHistory(taskInfo);
		try {
			processTask(taskInfo, cmsAuditHistory);
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
			cmsAuditService.markAsFailed(cmsAuditHistory, e);
		}
	}

	public void processTask(TaskInfo taskInfo, CMSAuditHistory cmsAuditHistory) {
		if (taskInfo.isServiceRequest()) {
			serviceRequestEXPAGTaskProcessor.processTask(taskInfo, cmsAuditHistory);
			return;
		}
		taskInfo.setRequestType("DigitalFormFactory");
		taskInfo.setProcessType("CustomerWebform");
		LOG.debug("Processing Task: {} : {} : {}", taskInfo.getTaskId(), taskInfo.getTaskStatusAsStr(), taskInfo.getDocuments().size());
		updateCTHRecord(taskInfo, cmsAuditHistory);
	}

	private void updateCTHRecord(TaskInfo taskInfo, CMSAuditHistory cmsAuditHistory) {
		cmsAuditHistory.setEvent(CMRSEvent.UPDATE_CTH_RECORD);
		LOG.debug("attempting to update cth record for task id:{}", taskInfo.getTaskId());
		try {
			tryUpdateCTHRecord(taskInfo, cmsAuditHistory);
			LOG.debug("successfully updated cth record for task id:{}", taskInfo.getTaskId());
		} catch (CTHRecordNotFoundException e) {
			LOG.debug("failed to update cth record for task id:{}", taskInfo.getTaskId());
			LOG.warn(e.getMessage());
			cmsAuditService.markAsFailed(cmsAuditHistory, e);
			emailSender.sendEmailToProdSupport("Error while updating CTH Record for Task Id:" + taskInfo.getTaskId(), EmailUtil.createEmail(cmsAuditHistory, e));
		} catch (CTHUpdateRecordFailedException e) {
			LOG.debug("failed to update cth record for task id:{}", taskInfo.getTaskId());
			LOG.warn(e.getMessage(), e);
			cmsAuditService.markAsFailed(cmsAuditHistory, e);
			emailSender.sendEmailToProdSupport("Error while updating CTH Record for Task Id:" + taskInfo.getTaskId(), EmailUtil.createEmail(cmsAuditHistory, e));
		}
	}
}