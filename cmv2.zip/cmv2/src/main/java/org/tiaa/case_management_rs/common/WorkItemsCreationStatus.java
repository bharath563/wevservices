package org.tiaa.case_management_rs.common;

public class WorkItemsCreationStatus {
	private String parentWorkItemId;
	private String relTasksCreationStatusMessage;
	public String getParentWorkItemId() {
		return parentWorkItemId;
	}
	public void setParentWorkItemId(String parentWorkItemId) {
		this.parentWorkItemId = parentWorkItemId;
	}
	public String getRelTasksCreationStatusMessage() {
		return relTasksCreationStatusMessage;
	}
	public void setRelTasksCreationStatusMessage(String relTasksCreationStatusMessage) {
		this.relTasksCreationStatusMessage = relTasksCreationStatusMessage;
	}
}
