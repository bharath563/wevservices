package org.tiaa.case_management_rs.utils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.io.RandomAccessSource;
import com.itextpdf.text.io.RandomAccessSourceFactory;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.RandomAccessFileOrArray;
import com.itextpdf.text.pdf.codec.TiffImage;

public class PDFUtils {

	private static final Logger LOGGER = LoggerFactory.getLogger(PDFUtils.class);

	public static void addTif(final com.itextpdf.text.Document document, final byte[] decodedTif, final String indexes) throws DocumentException, IOException {

		final RandomAccessSource ras = new RandomAccessSourceFactory().createSource(decodedTif);
		final RandomAccessFileOrArray ra = new RandomAccessFileOrArray(ras);
		final int n = TiffImage.getNumberOfPages(ra);

		Image img;

		for (int i = 1; i <= n; i++) {
			img = TiffImage.getTiffImage(ra, i);
			img.scaleToFit(500, 900); // image fit to pdf
			if (i == 1) {
				final Paragraph pg = new Paragraph(indexes, FontFactory.getFont(FontFactory.COURIER, 1, Font.NORMAL, new BaseColor(0, 0, 0)));
				document.add(pg);
			}
			document.add(img);
			document.newPage();
		}

		ra.close();
	}

	private static void addTiffToPDFDocument(final com.itextpdf.text.Document pdfDocument, final InputStream tiffInputStream, final String indexes) throws DocumentException, IOException {
		final RandomAccessSource randomAccessSource = new RandomAccessSourceFactory().createSource(tiffInputStream);
		final RandomAccessFileOrArray randomAccessFile = new RandomAccessFileOrArray(randomAccessSource);
		final int tiffImagePageCount = TiffImage.getNumberOfPages(randomAccessFile);

		for (int currentPageNumber = 1; currentPageNumber <= tiffImagePageCount; currentPageNumber++) {
			final Image tiffImage = TiffImage.getTiffImage(randomAccessFile, currentPageNumber);
			tiffImage.scaleToFit(500, 900);

			if (currentPageNumber == 1) {
				final Paragraph pg = new Paragraph(indexes, FontFactory.getFont(FontFactory.COURIER, 1, Font.NORMAL, new BaseColor(0, 0, 0)));
				pdfDocument.add(pg);
			}

			pdfDocument.add(tiffImage);
			pdfDocument.newPage();
		}

		randomAccessFile.close();
	}

	public static ByteArrayOutputStream convertTiffIntoPdf(final InputStream is, final String indexes) throws IOException, DocumentException {
		final ByteArrayOutputStream outTiff = new ByteArrayOutputStream();
		final byte[] buffer = new byte[131070];
		int br = 0;
		while ((br = is.read(buffer)) > -1) {
			outTiff.write(buffer, 0, br);
		}
		final ByteArrayOutputStream pdfBaos = createPDF(outTiff.toByteArray(), indexes);
		return pdfBaos;
	}

	public static ByteArrayOutputStream createPDF(final byte[] tiffImgData, final String indexes) throws DocumentException, IOException {
		final ByteArrayOutputStream pdfBaos = new ByteArrayOutputStream();
		final com.itextpdf.text.Document document = new com.itextpdf.text.Document();

		/*
		 * setStrictImageSequence is to make sure image is added to pdf in the
		 * sequence they are received
		 */
		final PdfWriter pdfWriter = PdfWriter.getInstance(document, pdfBaos);
		pdfWriter.setStrictImageSequence(true);

		document.open();
		document.addCreationDate();
		addTif(document, tiffImgData, indexes);
		document.newPage();
		document.close();
		return pdfBaos;
	}

	public static File createPDFFromTIFFImages(final File pdfOutputFile, final InputStream tiffInputStream, final String indexes) throws DocumentException, IOException {

		LOGGER.debug("Output pdf File name : " + pdfOutputFile);

		final OutputStream pdfOutputStream = new FileOutputStream(pdfOutputFile);

		try {
			final com.itextpdf.text.Document pdfDocument = new com.itextpdf.text.Document();

			try {
				final PdfWriter pdfWriter = PdfWriter.getInstance(pdfDocument, pdfOutputStream);

				try {
					pdfWriter.setStrictImageSequence(true);
					pdfDocument.open();
					pdfDocument.addCreationDate();
					addTiffToPDFDocument(pdfDocument, tiffInputStream, indexes);
					pdfDocument.newPage();
				} finally {
					pdfWriter.close();
				}
			} finally {
				pdfDocument.close();
			}
		} finally {
			pdfOutputStream.close();
		}

		return pdfOutputFile;
	}
}
