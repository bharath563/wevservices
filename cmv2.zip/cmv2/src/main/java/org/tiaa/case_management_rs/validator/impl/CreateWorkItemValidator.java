package org.tiaa.case_management_rs.validator.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.apache.commons.lang3.StringUtils;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.esb.case_management_rs_v2.type.ProcessRequest;

public class CreateWorkItemValidator extends BaseValidatorImpl {

	@Override
	public void doValidate(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		ProcessRequest processRequest = (ProcessRequest) request.getAttribute(PROCESS_REQUEST);

		if (StringUtils.isBlank(userId)) {
			handleException(VALIDATION_USERID_IS_EMPTY);
		}

		if (processRequest == null) {
			handleException(VALIDATION_WORKITEM_REQUEST_IS_NULL);
		}

	}

}
