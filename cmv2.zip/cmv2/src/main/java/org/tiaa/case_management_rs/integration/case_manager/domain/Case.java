package org.tiaa.case_management_rs.integration.case_manager.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.servicerequest_workflow.types.DocumentIDType;
import org.tiaa.esb.servicerequest_workflow.types.DocumentIDsType;
import org.tiaa.esb.servicerequest_workflow.types.DocumentType;

public class Case implements Serializable {
	private static final Logger LOG = LoggerFactory.getLogger(Case.class);
	private static final long serialVersionUID = -8839793605344590567L;
	private String requestId;
	private String caseId;
	private String channel;
	private String caseIdentifier;
	private String caseType;
	private String requestType;
	private String orchId;
	private String cthId;
	private String clientId = "";
	private Date caseStartedTS;
	private Date caseCompletedTS;
	private Date caseDueDateTS;
	private Date caseUpdatedTS;
	private String targetImplDate;
	private String additionalReqType;
	private Date requestSubmittedTS;
	private String caseName;
	//
	private CaseStatuses caseStatuses = new CaseStatuses();
	private Phases phases = new Phases();
	private CaseManagerDocuments documents = new CaseManagerDocuments();
	private String transitionManager = "";
	private String relationshipManager = "";

	public String getCaseStatus() {
		return caseStatuses.getLatestCaseStatus();
	}

	public void addPhase(Phase phase) {
		getPhases().getPhases().add(phase);
	}

	public String getAdditionalReqType() {
		return additionalReqType;
	}

	public Date getCaseCompletedTS() {
		return caseCompletedTS;
	}

	public CaseStatuses getCaseStatuses() {
		return caseStatuses;
	}

	public Date getCaseDueDateTS() {
		return caseDueDateTS;
	}

	public String getCaseId() {
		return caseId;
	}

	public String getCaseIdentifier() {
		return caseIdentifier;
	}

	public Date getCaseStartedTS() {
		return caseStartedTS;
	}

	public String getCaseType() {
		return caseType;
	}

	public Date getCaseUpdatedTS() {
		return caseUpdatedTS;
	}

	public String getCthId() {
		return cthId;
	}

	public String getOrchId() {
		return orchId;
	}

	public Phases getPhases() {
		return phases;
	}

	public Map<String, String> getPhaseTargetDateMap() {
		return phases.getPhaseTargetDateMap();
	}

	public String getTargetImplDate() {
		return targetImplDate;
	}

	public void setAdditionalReqType(String additionalReqType) {
		this.additionalReqType = additionalReqType;
	}

	public void setCaseCompletedTS(Date caseCompletedTS) {
		this.caseCompletedTS = caseCompletedTS;
	}

	public void setCaseStatuses(CaseStatuses caseDetailsInfo) {
		this.caseStatuses = caseDetailsInfo;
	}

	public void setCaseDueDateTS(Date caseDueDateTS) {
		this.caseDueDateTS = caseDueDateTS;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public void setCaseIdentifier(String caseIdentifier) {
		this.caseIdentifier = caseIdentifier;
	}

	public void setCaseStartedTS(Date caseStartedTS) {
		this.caseStartedTS = caseStartedTS;
	}

	public void setCaseType(String caseTypeName) {
		this.caseType = caseTypeName;
	}

	public void setCaseUpdatedTS(Date caseUpdatedTS) {
		this.caseUpdatedTS = caseUpdatedTS;
	}

	public void setCthId(String cthId) {
		this.cthId = cthId;
	}

	public void setOrchId(String orchId) {
		this.orchId = orchId;
	}

	public void setPhases(Phases phases) {
		this.phases = phases;
	}

	public void setTargetImplDate(String targetImplDate) {
		this.targetImplDate = targetImplDate;
	}

	public Date getRequestSubmittedTS() {
		return requestSubmittedTS;
	}

	public void setRequestSubmittedTS(Date requestSubmittedTS) {
		this.requestSubmittedTS = requestSubmittedTS;
	}

	public void addCaseStatus(CaseStatus mapCaseStatus) {
		getCaseStatuses().getCaseStatuses().add(mapCaseStatus);
	}

	public CaseManagerDocuments getDocuments() {
		return documents;
	}

	public void setDocuments(CaseManagerDocuments documents) {
		this.documents = documents;
	}

	public boolean addDocument(CaseManagerDocument document) {
		final String newDRI = getDRI(document);
		List<CaseManagerDocument> documentList = getDocuments().getDocuments();
		for (CaseManagerDocument documentType : documentList) {
			String dri = getDRI(documentType);
			if (dri.equals(newDRI)) {
				return false;
			}
		}
		return documentList.add(document);
	}

	private String getDRI(DocumentType document) {
		DocumentIDsType documentIDs = document.getDocumentIDs();
		if (documentIDs == null) {
			return "";
		}
		List<DocumentIDType> documentIDList = documentIDs.getDocumentIDs();
		if (documentIDList.isEmpty()) {
			return "";
		}
		DocumentIDType documentIDType = documentIDList.get(0);
		String value = documentIDType.getValue();
		return value == null ? "" : value;
	}

	public XMLGregorianCalendar getRecievedDateTimeAsXMLGregorianCalendar() {
		if (requestSubmittedTS == null) {
			return null;
		}
		return DateUtil.toXMLGregorianCalendar(requestSubmittedTS);
	}

	public XMLGregorianCalendar getRecievedDateTimeAsXMLGregorianCalendarAsDate() {
		if (requestSubmittedTS == null) {
			return null;
		}
		return DateUtil.toXMLGregorianCalendarDateOnly(requestSubmittedTS);
	}

	public String getTransitionManager() {
		return transitionManager;
	}

	public void setTransitionManager(String transitionManager) {
		this.transitionManager = transitionManager;
	}

	public String getRelationshipManager() {
		return relationshipManager;
	}

	public void setRelationshipManager(String relationshipManager) {
		this.relationshipManager = relationshipManager;
	}

	public String getCurrentPhaseNameAndDescription() {
		return phases.getCurrentPhaseNameAndDescription();
	}

	public String getCurrentPhaseName() {
		return phases.getCurrentPhaseName();
	}

	public String getCurrentPhaseDesription() {
		return phases.getCurrentPhaseDescription();
	}

	public String getCurrentPhaseTargetCompletionTS() {
		return phases.getCurrentPhaseTargetCompletionTS();
	}

	public Date getCurrentPhaseTargetCompletionDateTime() {
		return phases.getCurrentPhaseTargetCompletionDateTime();
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public Map<String, List<CaseManagerDocument>> groupByDocumentContainerId() {
		Map<String, List<CaseManagerDocument>> documentsByDocumentContainerId = new HashMap<String, List<CaseManagerDocument>>();
		for (CaseManagerDocument documentType : getDocuments().getDocuments()) {
			String documentContainerId = documentType.getDocumentContainerId();
			if (!documentsByDocumentContainerId.containsKey(documentContainerId)) {
				documentsByDocumentContainerId.put(documentContainerId, new ArrayList<CaseManagerDocument>());
			}
			documentsByDocumentContainerId.get(documentContainerId).add(documentType);
		}
		return documentsByDocumentContainerId;
	}

	public String getCaseName() {
		return caseName;
	}

	public void setCaseName(String caseName) {
		this.caseName = caseName;
	}

	public void markPreviousVersionOfDocumentsAsDeletedForCase() {
		try {
			Map<String, List<CaseManagerDocument>> documentsByDocumentContainerId = groupByDocumentContainerId();
			for (List<CaseManagerDocument> list : documentsByDocumentContainerId.values()) {
				int size = list.size();
				if (size > 1) {
					markPreviousVersionOfDocumentsAsDeleted(list, size);
				}
			}
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
		}
	}

	private void markPreviousVersionOfDocumentsAsDeleted(List<CaseManagerDocument> list, int size) {
		Collections.sort(list, CaseManagerDocument.COMPARE_BY_VERSION);
		for (int ii = 0; ii < size; ii++) {
			if (ii != size - 1) {
				CaseManagerDocument caseManagerDocument = list.get(ii);
				caseManagerDocument.setDocumentStatus("DELETED");
			}						
		}
	}

	@Override
	public String toString() {
		return "Case [requestId=" + requestId + ", caseId=" + caseId + ", channel=" + channel + ", caseIdentifier=" + caseIdentifier + ", caseType=" + caseType + ", requestType="
				+ requestType + ", orchId=" + orchId + ", cthId=" + cthId + ", clientId=" + clientId + ", caseStartedTS=" + caseStartedTS + ", caseCompletedTS=" + caseCompletedTS
				+ ", caseDueDateTS=" + caseDueDateTS + ", caseUpdatedTS=" + caseUpdatedTS + ", targetImplDate=" + targetImplDate + ", additionalReqType=" + additionalReqType
				+ ", requestSubmittedTS=" + requestSubmittedTS + ", caseName=" + caseName + ", caseStatuses=" + caseStatuses + ", phases=" + phases + ", documents=" + documents
				+ ", transitionManager=" + transitionManager + ", relationshipManager=" + relationshipManager + "]";
	}
}
