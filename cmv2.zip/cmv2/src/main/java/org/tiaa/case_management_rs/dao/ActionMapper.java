package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;

public class ActionMapper extends AbstractRowMapper<String> implements RowMapper<String> {

	@Override
	public String mapRow(ResultSet rs, int rowNum) throws SQLException {
		return getStringTrimmed(rs, "FIRSTACTIONDESC");
	}

}
