package org.tiaa.case_management_rs.email.plan_modification_request;

import java.util.Comparator;

public class ContactInfo implements Comparable<ContactInfo> {
	public static final ContactInfoComparatorByRole COMPARATOR_BY_ROLE = new ContactInfoComparatorByRole();
	private String name;
	private String role;
	private String emailAddress;

	@Override
	public int compareTo(ContactInfo o) {
		int compareTo = this.emailAddress.compareTo(o.emailAddress);
		if (compareTo != 0) {
			return compareTo;
		}
		compareTo = this.name.compareTo(o.name);
		if (compareTo != 0) {
			return compareTo;
		}
		compareTo = this.role.compareTo(o.role);
		return compareTo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public String getName() {
		return name;
	}

	public String getRole() {
		return role;
	}

	public Integer getSortOrder() {
		if ("RM".equals(role)) {
			return 0;
		}
		if ("CM".equals(role)) {
			return 1;
		}
		return 2;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "ContactInfo [name=" + name + ", role=" + role + ", emailAddress=" + emailAddress + "]";
	}

	public static class ContactInfoComparatorByRole implements Comparator<ContactInfo> {
		@Override
		public int compare(ContactInfo o1, ContactInfo o2) {
			return o1.getSortOrder().compareTo(o2.getSortOrder());
		}
	}

}
