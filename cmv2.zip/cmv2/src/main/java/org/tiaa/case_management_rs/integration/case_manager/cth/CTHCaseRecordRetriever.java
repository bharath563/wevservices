package org.tiaa.case_management_rs.integration.case_manager.cth;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.case_management_rs.integration.case_manager.domain.CaseDetails;
import org.tiaa.case_management_rs.integration.cth.CTHRecordNotFoundException;
import org.tiaa.esb.partyrequest.types.ESBMessage;
import org.tiaa.esb.partyrequest.types.ESBMessages;
import org.tiaa.esb.partyrequest.types.PartyRequestResponse;
import org.tiaa.esb.partyrequest.types.PartyRequestResponses;
import org.tiaa.esb.partyrequest.types.ResponseStatus;
import org.tiaa.esb.partyrequest.types.RetrieveRequests;
import org.tiaa.esb.partyrequest.types.RetrieveRequestsResp;
import org.tiaa.esb.partyrequest.types.RetrieveRequestsResponse;

public class CTHCaseRecordRetriever {
	private CTHCaseWebService cthWebService;
	private static final Logger LOG = LoggerFactory.getLogger(CTHCaseRecordRetriever.class);
	private RetrieveRequestsBuilder retrieveRequestsBuilder;

	public CTHCaseRecordRetriever(RetrieveRequestsBuilder retrieveRequestsBuilder) {
		super();
		this.retrieveRequestsBuilder = retrieveRequestsBuilder;
	}

	public boolean cthRecordExists(CaseDetails taskInfo) {
		try {
			retrieveCTHRecord(taskInfo);
			//record found
			return true;
		} catch (CTHRecordNotFoundException e) {
			//record not found
			LOG.debug(e.getMessage());
		}
		return false;
	}

	public PartyRequestResponse retrieveCTHRecord(CaseDetails caseDetails) {
		RetrieveRequests retrieveRequests = retrieveRequestsBuilder.build(caseDetails);
		RetrieveRequestsResponse retrieveRequestsResponse = cthWebService.retrieveRequests(retrieveRequests, caseDetails.getClientId(), caseDetails.getWorkflowTaskID());
		//
		RetrieveRequestsResp retrieveRequestsResp = retrieveRequestsResponse.getRetrieveRequestsResp();
		checkIfRecordFound(retrieveRequestsResp);
		return getPartyRequestResponse(retrieveRequestsResponse);
	}

	public PartyRequestResponse retrieveCTHRecordForCaseDetails(CaseDetails caseDetails) {
		RetrieveRequests retrieveRequests = retrieveRequestsBuilder.build(caseDetails);
		RetrieveRequestsResponse retrieveRequestsResponse = cthWebService.retrieveRequests(retrieveRequests, "", "");
		//
		RetrieveRequestsResp retrieveRequestsResp = retrieveRequestsResponse.getRetrieveRequestsResp();
		checkIfRecordFound(retrieveRequestsResp);
		return getPartyRequestResponse(retrieveRequestsResponse);
	}

	private void checkIfRecordFound(RetrieveRequestsResp retrieveRequestsResp) {
		ResponseStatus responseStatus = retrieveRequestsResp.getResponseStatus();
		String status = responseStatus.getStatus();
		if (!"SUCCESS".equals(status)) {
			throw new CTHRecordNotFoundException(responseStatus.getStatusText());
		}
		ESBMessages messages = responseStatus.getMessages();
		if (messages == null) {
			return;
		}
		List<ESBMessage> messageList = messages.getMessages();
		if (messageList.isEmpty()) {
			return;
		}
		ESBMessage esbMessage = messageList.get(0);
		throw new CTHRecordNotFoundException(esbMessage.getCode() + ":" + esbMessage.getText());
	}

	private PartyRequestResponse getPartyRequestResponse(RetrieveRequestsResponse retrieveRequestsResponse) {
		RetrieveRequestsResp retrieveRequestsResp = retrieveRequestsResponse.getRetrieveRequestsResp();
		if (retrieveRequestsResp == null) {
			LOG.debug("retrieveRequestsResp is null");
			return null;
		}
		PartyRequestResponses partyRequestResponses = retrieveRequestsResp.getPartyRequestResponses();
		if (partyRequestResponses == null) {
			LOG.debug("partyRequestResponses is null");
			return null;
		}
		List<PartyRequestResponse> partyRequestResponseList = partyRequestResponses.getPartyRequestResponses();
		if (partyRequestResponseList.isEmpty()) {
			LOG.debug("partyRequestResponseList is empty");
			return null;
		}
		return partyRequestResponseList.get(0);
	}

	public void setCthWebService(CTHCaseWebService cthWebService) {
		this.cthWebService = cthWebService;
	}

	public void setRetrieveRequestsBuilder(RetrieveRequestsBuilder retrieveRequestsBuilder) {
		this.retrieveRequestsBuilder = retrieveRequestsBuilder;
	}
}
