package org.tiaa.case_management_rs.integration.cth;

import org.tiaa.case_management_rs.domain.Identifiers;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.esb.plansponsor.types.ContactResponse;

public interface CTHContext {
	Identifiers getIdentifiers();

	TaskInfo getTaskInfo();

	ContactResponse getContactResponse();
}
