package org.tiaa.case_management_rs.syncup.service_request;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBElement;
import javax.xml.transform.dom.DOMSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.case_management_rs.constants.FileTypes;
import org.tiaa.case_management_rs.integration.cth.PayloadInfoBuilder;
import org.tiaa.case_management_rs.integration.cth.RetrieveRequestsResponseProcessor;
import org.tiaa.case_management_rs.integration.cth.UpdateCTHContext;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.esb.partyrequest.types.RequestInfo;
import org.tiaa.esb.partyrequest.types.UpdateAdditionalRequestIdentifier;
import org.tiaa.esb.partyrequest.types.UpdatePartyRequest;
import org.tiaa.esb.servicerequest.types.AnyXMLSkipType;
import org.tiaa.esb.servicerequest.types.CTHClob;
import org.tiaa.esb.servicerequest.types.OtherData;
import org.tiaa.esb.servicerequest.types.RequestCustomerType;
import org.tiaa.esb.servicerequest.types.RequestPlanType;
import org.tiaa.esb.servicerequest.types.ServiceRequest;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;
import org.tiaa.esb.servicerequest_workflow.types.DocumentType;

public class ServiceRequestProcessor extends RetrieveRequestsResponseProcessor {
	private static final Logger LOG = LoggerFactory.getLogger(ServiceRequestProcessor.class);
	private ServiceRequesJaxbMarshaller serviceRequesJaxb2Marshaller;
	private ServiceRequestPayloadBuilder serviceRequestPayloadBuilder;

	protected boolean updateClob(UpdateCTHContext context, String status) {
		RequestInfo requestInfo = getRequestInfo(context);
		DOMSource domSource = getDomSource(requestInfo);
		CTHClob cthClob = serviceRequesJaxb2Marshaller.getCTHClob(domSource);
		OtherData otherData = serviceRequesJaxb2Marshaller.getOtherData(cthClob);
		CaseInfo caseInfo = serviceRequesJaxb2Marshaller.getCaseInfo(otherData);
		updateIdentifiersForDocuments(context, caseInfo);
		context.setCaseInfo(caseInfo);
		//
		boolean updateCTH = updateCTH(context, status);
		ServiceRequest serviceRequest = cthClob.getRequest().getServiceRequest();
		if (context.isCustomerNumberUpdated()) {
			LOG.info("try update customer info");
			RequestCustomerType customer = serviceRequestPayloadBuilder.createCustomer(context);
			if (customer != null) {
				LOG.info("update customer info");
				serviceRequest.setCustomer(customer);
			}
		}
		RequestPlanType requestPlanType = serviceRequest.getPlan();
		if (requestPlanType == null) {
			requestPlanType = new RequestPlanType();
			serviceRequest.setPlan(requestPlanType);
		}
		requestPlanType.setPlanName(context.getStringIdentifierValue("PLAN NAME"));
		requestPlanType.setSubplanName(context.getStringIdentifierValue("SUBPLAN"));
		//update CLOB
		if (otherData != null) {
			AnyXMLSkipType workflowXML = otherData.getWorkFlowXML();
			workflowXML.setAny(toElement(caseInfo));
		}
		requestInfo.setAny(toElement(cthClob, serviceRequesJaxb2Marshaller.getServiceRequestJaxb2Marshaller()));
		return updateCTH;
	}

	protected void updateIdentifiersForDocuments(UpdateCTHContext context, CaseInfo caseInfo){
		UpdatePartyRequest updatePartyRequest = context.getUpdatePartyRequest();
		List<UpdateAdditionalRequestIdentifier> updateAdditionalRequestIdentifierList = updatePartyRequest.getAdditionalRequestIdentifiers().getAdditionalRequestIdentifiers();
		List<Date> LastDocumentUpdateDateTimeList = new ArrayList<Date>();
		BigDecimal docCount = new BigDecimal(0.0);
		Boolean newDocumentUploaded = false;
		Boolean hasValidFileType = false;

		//get the <UnreadDocumentCount> from AdditionalRequestIdentifiers
		for (UpdateAdditionalRequestIdentifier updateAdditionalRequestIdentifier : updateAdditionalRequestIdentifierList) {
			if (updateAdditionalRequestIdentifier.getKey().equals("UnreadDocumentCount")) {
				JAXBElement<BigDecimal> jaxbElementValue = updateAdditionalRequestIdentifier.getDecimalValue();
				BigDecimal value = jaxbElementValue.getValue();
				docCount = (value == null) ? docCount : value;
			}
		}
		//
		List<DocumentType> documentList = caseInfo.getDocuments().getDocuments();
		for (DocumentType document : context.getTaskInfo().getDocuments()) {
			DocumentType foundDocument = PayloadInfoBuilder.findDocument(document, documentList);
			String documentType = document.getOriginalDocumentID();
			String fileExtension = documentType == null ? null : documentType.substring(documentType.lastIndexOf(".") + 1);
			hasValidFileType = fileExtension == null ? false : FileTypes.isValid(fileExtension);
			//Increment unread document count and set the updated LastDocumentUpdateDateTime if new document found for Upload
			if (foundDocument == null) {
				if((CommonUtil.isNullOrEmpty(document.getDocumentStatus()) || document.getDocumentStatus().equals("REQUIRED"))
						&& (document.getDocumentCategoryType().equals("CORRESPONDENCE - INBOUND") || document.getDocumentCategoryType().equals("CORRESPONDENCE - OUTBOUND")) && hasValidFileType){
					docCount = docCount.add(new BigDecimal(1));
					newDocumentUploaded = true;
				}
			}
			Date date = document.getBusinessDate().toGregorianCalendar().getTime();
			if (date != null && (CommonUtil.isNullOrEmpty(document.getDocumentStatus()) || document.getDocumentStatus().equals("REQUIRED")) &&
					(document.getDocumentCategoryType().equals("CORRESPONDENCE - INBOUND") || document.getDocumentCategoryType().equals("CORRESPONDENCE - OUTBOUND")) && hasValidFileType) {
				LastDocumentUpdateDateTimeList.add(date);
			}
		}
		Date latestDateTime = getLatestDate(LastDocumentUpdateDateTimeList);

		//if new document is uploaded
		if(newDocumentUploaded){
			updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, "UnreadDocumentCount", docCount);
			updateAdditionalRequestIdentifier(updateAdditionalRequestIdentifierList, "LastDocumentUpdateDateTime", latestDateTime);
		}
	}

	//get the latest date from the list
	protected Date getLatestDate(List<Date> LastDocumentUpdateDateTimeList){
		Date latestDate = null;
		for(Date LastDocumentUpdateDateTime : LastDocumentUpdateDateTimeList){
		   if (latestDate == null || LastDocumentUpdateDateTime.compareTo(latestDate) > 0){
			   latestDate = LastDocumentUpdateDateTime;
		   }
		}
		return latestDate;
	}

	public void setServiceRequesJaxb2Marshaller(ServiceRequesJaxbMarshaller serviceRequesJaxb2Marshaller) {
		this.serviceRequesJaxb2Marshaller = serviceRequesJaxb2Marshaller;
	}

	public void setServiceRequestPayloadBuilder(ServiceRequestPayloadBuilder serviceRequestPayloadBuilder) {
		this.serviceRequestPayloadBuilder = serviceRequestPayloadBuilder;
	}
}
