package org.tiaa.case_management_rs.utils;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.util.List;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import org.tiaa.case_management_rs.exception.CaseManagementRuntimeException;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.WorkflowException;
import org.tiaa.esb.case_management_rs_v2.type.ESBMessage;
import org.tiaa.esb.case_management_rs_v2.type.ESBMessages;
import org.tiaa.esb.case_management_rs_v2.type.ResponseStatus;

public final class ExceptionUtil {

	private ExceptionUtil() {
	}

	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionUtil.class);

	public static ESBMessage getESBMessage(String key) {
		String code = Messages.getMessage(key + MSG_CODE_SUFFIX);
		String type = Messages.getMessage(key + MSG_TYPE_SUFFIX);
		String text = Messages.getMessage(key + MSG_TEXT_SUFFIX);
		if (StringUtils.isEmpty(code) || StringUtils.isEmpty(type) || StringUtils.isEmpty(text)) {
			LOGGER.error("The key " + key + " is not present in the propery file. setting general exception key");
			return getESBMessage(ERROR_GENERAL_EXCEPTION);
		}
		return createESBMessage(code, type, text);
	}

	public static ESBMessage getESBMessage(String key, Object[] objArray) {
		String code = Messages.getMessage(key + MSG_CODE_SUFFIX);
		String type = Messages.getMessage(key + MSG_TYPE_SUFFIX);
		String text = Messages.getMessage(key + MSG_TEXT_SUFFIX, objArray);
		return createESBMessage(code, type, text);
	}

	public static ESBMessage getESBMessage(String key, Object[] objArray, Locale locale) {
		String code = Messages.getMessage(key + MSG_CODE_SUFFIX, null, locale);
		String type = Messages.getMessage(key + MSG_TYPE_SUFFIX, null, locale);
		String text = Messages.getMessage(key + MSG_TEXT_SUFFIX, objArray, locale);
		return createESBMessage(code, type, text);
	}

	private static ESBMessage createESBMessage(String code, String type, String text) {
		ESBMessage esbMessage = new ESBMessage();
		esbMessage.setCode(code);
		esbMessage.setType(type);
		esbMessage.setText(text);
		return esbMessage;
	}

	public static ResponseStatus createESBResponseStatus(Exception exp) {
		ResponseStatus responseStatus = new ResponseStatus();
		ESBMessages esbMessages = null;

		// If the exception is of type runtime retrieve the
		// esbMessages from
		// the exception object.
		if (exp instanceof CaseManagementRuntimeException) {
			CaseManagementRuntimeException caseManagmentRuntimeException = (CaseManagementRuntimeException) exp;
			esbMessages = caseManagmentRuntimeException.getEsbMessages();
		}

		if (exp instanceof WorkflowException) {
			esbMessages = new ESBMessages();
			esbMessages.getMessages().add(createESBMessage(GENERAL_ERROR_CODE, "ERROR", exp.getMessage()));
		}

		if ((esbMessages != null) && (esbMessages.getMessages().size() > 0)) {
			responseStatus.setMessages(esbMessages);
			responseStatus.setStatus(SUCCESS);
			responseStatus.setStatusText(SUCCESS_TEXT);
			// Loop through the all the ESB messages. If any one of the message
			// type is not INFO,
			// mark response as failure.
			List<ESBMessage> esbMessageList = esbMessages.getMessages();
			for (ESBMessage esbMessage : esbMessageList) {
				if (!esbMessage.getType().equalsIgnoreCase(MSG_TYPE_INFO)) {
					responseStatus.setStatus(FAILURE);
					responseStatus.setStatusText(FAILURE_TEXT);
				}
			}
		} else {
			esbMessages = new ESBMessages();
			ESBMessage esbMessage = ExceptionUtil.getESBMessage(ERROR_GENERAL_EXCEPTION);
			esbMessages.getMessages().add(esbMessage);
			responseStatus.setStatus(FAILURE);
			responseStatus.setStatusText(FAILURE_TEXT);
			responseStatus.setMessages(esbMessages);
		}

		return responseStatus;
	}
}
