package org.tiaa.case_management_rs.utils;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

public class CryptUtility {

	private static final Logger LOGGER = Logger.getLogger(CryptUtility.class);

	public static final String CRYPT_ALGORITHM = "DES";
	public static final String SECRET_PASSKEY = "=LvTmrSa3Uj-%keu";

	public static String decrypt(String cipherText) {

		if (StringUtils.isEmpty(cipherText)) {
			throw new IllegalArgumentException("Invalid Cipher Text "
					+ cipherText);
		}

		try {
			Cipher desCipher = Cipher.getInstance(CRYPT_ALGORITHM);
			desCipher.init(
					Cipher.DECRYPT_MODE,
					SecretKeyFactory.getInstance(CRYPT_ALGORITHM)
					.generateSecret(
							new DESKeySpec(SECRET_PASSKEY.getBytes())));
			return new String(desCipher.doFinal(Base64.decode(cipherText)));
		} catch (Exception e) {
			LOGGER.error(
					"Error Decrypting CipherText. Reason: " + e.getMessage()
					+ ". Cipher:" + cipherText, e);
			throw new IllegalArgumentException("Error Decrypting " + cipherText);
		}
	}

	public static String encrypt(String clearText) {

		if (StringUtils.isEmpty(clearText)) {
			throw new IllegalArgumentException("Invalid Clear Text "
					+ clearText);
		}

		try {
			Cipher desCipher = Cipher.getInstance(CRYPT_ALGORITHM);
			desCipher.init(
					Cipher.ENCRYPT_MODE,
					SecretKeyFactory.getInstance(CRYPT_ALGORITHM)
					.generateSecret(
							new DESKeySpec(SECRET_PASSKEY.getBytes())));
			return Base64.encode(desCipher.doFinal(clearText.getBytes()));
		} catch (Exception e) {
			LOGGER.error(
					"Error Encrypting Clear Text. Reason: " + e.getMessage()
					+ ". ClearText:" + clearText, e);
			throw new IllegalArgumentException("Error Decrypting " + clearText);
		}
	}

	public static void main(String arp[]) {
		String encrypted = CryptUtility.encrypt("message");
		String decrypted = CryptUtility.decrypt(encrypted);
		System.out.println("Encrypted Text:" + encrypted);
		System.out.println("DEcrypted Text:" + decrypted);

		encrypted = CryptUtility.encrypt("123AwqweMesasa");
		decrypted = CryptUtility.decrypt(encrypted);
		System.out.println("Encrypted Text:" + encrypted);
		System.out.println("DEcrypted Text:" + decrypted);

		encrypted = CryptUtility.encrypt("&!*!@#!#%#(^");
		decrypted = CryptUtility.decrypt(encrypted);
		System.out.println("Encrypted Text:" + encrypted);
		System.out.println("DEcrypted Text:" + decrypted);

	}

}
