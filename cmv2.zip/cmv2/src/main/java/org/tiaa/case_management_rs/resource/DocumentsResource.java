package org.tiaa.case_management_rs.resource;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.container.ResourceContext;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.common.impl.RequestImpl;
import org.tiaa.case_management_rs.service.CaseManagementRestService;
import org.tiaa.esb.case_management_rs_v2.type.DocumentsRequest;

public class DocumentsResource {

	private static final Logger LOGGER = LoggerFactory.getLogger(DocumentsResource.class);

	@Context
	private ResourceContext resourceContext;

	@Autowired
	private CaseManagementRestService caseManagmentRestService;

	@GET
	@Produces({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	public Response getDocuments(@PathParam(PROCESS_ID) String taskId, @QueryParam(USER_ID) String userId, @QueryParam(CASE_ID) String caseId,@QueryParam(APP_NAME) String appName) {

		LOGGER.debug("Entering getDocuments");
		LOGGER.debug("Request Params");
		LOGGER.debug(USER_ID + SPACE_HYPEN_SAPCE + userId);
		LOGGER.debug(PROCESS_ID + SPACE_HYPEN_SAPCE + taskId);
		LOGGER.debug(CASE_ID + SPACE_HYPEN_SAPCE + caseId);
		LOGGER.debug(APP_NAME + SPACE_HYPEN_SAPCE + appName);

		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		// Get all the request parameter string values
		request.setAttribute(USER_ID, userId);
		request.setAttribute(PROCESS_ID, taskId);
		request.setAttribute(CASE_ID, caseId);
		request.setAttribute(APP_NAME, appName);

		Response response = this.caseManagmentRestService.getDocuments(request);

		LOGGER.debug("Exiting getDocuments");

		return response;
	}

	@POST
	@Produces({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	@Consumes({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	public Response createDocuments(@QueryParam(USER_ID) String userId, @QueryParam(CASE_ID) String caseId, @PathParam(PROCESS_ID) String taskId, @PathParam(DOCUMENT_ID) String docId, 
			DocumentsRequest documentsRequest, @QueryParam(APP_NAME) String appName, @QueryParam(NON_UW_DOCUMENT) String nonUWDocument) {

		LOGGER.debug("Entering createDocument");
		LOGGER.debug("Request Params ");
		LOGGER.debug(USER_ID + SPACE_HYPEN_SAPCE + userId);

		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		// Get all the request parameter string values
		request.setAttribute(USER_ID, userId);
		request.setAttribute(PROCESS_ID, taskId);
		request.setAttribute(CASE_ID, caseId);
		request.setAttribute(DOCUMENT_ID, docId);
		request.setAttribute(DOCUMENTS_REQUEST, documentsRequest);
		request.setAttribute(APP_NAME, appName);
		request.setAttribute(NON_UW_DOCUMENT, nonUWDocument);
		Response response = this.caseManagmentRestService.createDocuments(request);

		LOGGER.debug("Exiting createDocument");

		return response;
	}

	@Path("/{docid}")
	public DocumentResource documentSubResource() {
		return this.resourceContext.getResource(DocumentResource.class);
	}
}
