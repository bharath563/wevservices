package org.tiaa.case_management_rs.domain;

import java.io.Serializable;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

public class CMSTaskDocument implements Serializable {
	private static final long serialVersionUID = 1670021362781885735L;
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="CMS_TASK_DOCUMENT_SEQ")
	@SequenceGenerator(name = "CMS_TASK_DOCUMENT_SEQ", sequenceName = "CMS_TASK_DOCUMENT_SEQ", allocationSize = 1)
	private long id;
	private String taskType;
	private String documentType;
	private String contentType;
	private String documentTitle;

	public String getContentType() {
		return contentType;
	}

	public String getDocumentTitle() {
		return documentTitle;
	}

	public String getDocumentType() {
		return documentType;
	}

	public long getId() {
		return id;
	}

	public String getTaskType() {
		return taskType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public void setDocumentTitle(String documentTitle) {
		this.documentTitle = documentTitle;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setTaskType(String taskType) {
		this.taskType = taskType;
	}

	@Override
	public String toString() {
		return String.format("TaskDefinition [id=%s, taskType=%s, documentType=%s]", id, taskType, documentType);
	}
}
