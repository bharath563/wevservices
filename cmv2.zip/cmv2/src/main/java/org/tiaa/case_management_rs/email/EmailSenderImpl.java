package org.tiaa.case_management_rs.email;

import static org.tiaa.case_management_rs.email.EmailUtil.*;

import java.util.Arrays;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.utils.CommonUtil;

public class EmailSenderImpl implements EmailSender, InitializingBean {
	private static final Logger LOG = LoggerFactory.getLogger(EmailSenderImpl.class);
	@Autowired
	private JavaMailSender javaMailSender;
	@Autowired
	private SimpleMailMessage message;
	private String signature;
	private String signatureHTML;
	private boolean emailEnabled = true;//default enabled

	public EmailSenderImpl() {
	}

	public EmailSenderImpl(SimpleMailMessage message, JavaMailSender javaMailSender) {
		this.message = message;
		this.javaMailSender = javaMailSender;
	}

	@Override
	public void afterPropertiesSet() {
		signature = getSignature(NEW_LINE);
		signatureHTML = getSignature(NEW_LINE_HTML);
	}

	public JavaMailSender getJavaMailSender() {
		return javaMailSender;
	}

	public SimpleMailMessage getMessage() {
		return message;
	}

	public String getSignature() {
		return signature;
	}

	protected String getSignature(String separator) {
		return separator + "Thanks," + separator + PROD_SUPPORT_SIGNATURE + separator + separator + separator + "    ***" + AppConstants.APPLICATION_DESCRIPTION + " auto-generated email notification***";
	}

	public String getSignatureHTML() {
		return signatureHTML;
	}

	@Override
	public boolean sendEmailToProdSupport(String subject, String messageContents) {
		if (!emailEnabled) {
			LOG.warn("sending email is disabled");
			LOG.info("subject:{}", subject);
			LOG.info("messageContents:{}", messageContents);
			return false;
		}
		try {
			MimeMessage mimeMessage = javaMailSender.createMimeMessage();
			// use the true flag to indicate you need a multipart message
			MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
			helper.setFrom(message.getFrom());
			helper.setTo(message.getTo());
			helper.setSubject(CommonUtil.getHostAndNodeName() + " - " + subject);
			helper.setText(messageContents, true);
			//
			LOG.trace("Sending html message:{}", messageContents);
			javaMailSender.send(mimeMessage);
			return true;
		} catch (MailException e) {
			LOG.error("Exception occurred while sending email", e);
		} catch (MessagingException e) {
			LOG.error("Exception occurred while sending email", e);
		}
		return false;
	}

	public void sendHtmlEmail(String subject, String html) {
		sendEmailToProdSupport(subject, html);
	}

	public void sendTextEmail(String subject, String text) {
		if (!emailEnabled) {
			LOG.warn("sending email is disabled");
			LOG.info("subject:{}", subject);
			LOG.info("text:{}", text + signature);
			return;
		}
		SimpleMailMessage msg = new SimpleMailMessage(this.message);
		msg.setText(text + signature);
		msg.setSubject(subject);
		try {
			LOG.trace("Sending text message:{}", msg);
			this.javaMailSender.send(msg);
		} catch (MailException e) {
			LOG.error("Exception occurred while sending email", e);
		}
	}

	public void setMailSender(JavaMailSender mailSender) {
		this.javaMailSender = mailSender;
	}

	public void setMessage(SimpleMailMessage message) {
		this.message = message;
	}

	public void setSignature(String signature) {
		this.signature = signature;
	}

	public void setSignatureHTML(String signatureHTML) {
		this.signatureHTML = signatureHTML;
	}

	public boolean sendEmail(String from, String toEmail, String subject, String emailText) {
		return sendEmail(from, new String[] { toEmail }, null, subject, emailText);
	}

	public boolean sendEmail(String from, String toEmail, String ccEmail, String subject, String emailText) {
		return sendEmail(from, new String[] { toEmail }, ccEmail, subject, emailText);
	}

	public boolean sendEmail(String from, final String[] toEmail, String ccEmail, String subject, String emailText) {
		if (!emailEnabled) {
			LOG.warn("sending email is disabled");
			LOG.info("subject:{}", subject);
			LOG.info("text:{}", emailText);
			return false;
		}
		try {
			LOG.debug("Inside sendEmail method to send email to support teams.");
			MimeMessage mimeMessage = javaMailSender.createMimeMessage();
			MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
			helper.setFrom(message.getFrom());
			String[] to = toEmail;
			if (to == null) {
				to = new String[0];
			}
			LOG.info("Sending email to: {} and CCing: {} with email subject : {}", Arrays.asList(to), ccEmail, subject);
			//Use the method param values
			helper.setTo(to);
			if (ccEmail != null) {
				helper.setCc(ccEmail);
			}
			helper.setFrom(from);
			helper.setSubject(subject);
			//set the font and the style of the email text
			StringBuilder sb = new StringBuilder();
			sb.append("<span style='font-size:10.0pt;font-family:Arial;color:black'>");
			sb.append(emailText);
			sb.append("</span>");
			// use the true flag to indicate you need a multipart message
			helper.setText(sb.toString(), true);
			LOG.debug("Sending message..");
			javaMailSender.send(mimeMessage);
			LOG.debug("Sent message..");
			return true;
		} catch (MailException e) {
			LOG.error("Exception occurred while sending reort", e);
			return false;
		} catch (MessagingException e) {
			LOG.error("Exception occurred while sending reort", e);
			return false;
		}
	}

	public boolean isEmailEnabled() {
		return emailEnabled;
	}

	public void setEmailEnabled(boolean enableEmail) {
		this.emailEnabled = enableEmail;
	}

	@Override
	public boolean sendEmail(String from, String[] toEmail, String subject, String emailText) {
		return sendEmail(from, toEmail, null, subject, emailText);
	}

}