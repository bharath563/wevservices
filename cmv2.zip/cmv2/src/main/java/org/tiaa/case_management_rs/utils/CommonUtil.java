package org.tiaa.case_management_rs.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetAddress;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.web.util.UriComponentsBuilder;

public final class CommonUtil {
	private static final Logger LOG = LoggerFactory.getLogger(CommonUtil.class);
	private static String hostAndNodeName;
	private static String hostName;
	private static String nodeName;

	private CommonUtil() {
	}

	public static String getHostAndNodeName() {
		return hostAndNodeName;
	}

	public static final String getHostName() {
		return hostName;
	}

	public static String getNodeName() {
		return nodeName;
	}

	private static String getHostNameInternal() {
		try {
			return InetAddress.getLocalHost().getHostName();
		} catch (UnknownHostException e) {
			LOG.warn(e.getMessage(), e.getCause());
		}
		return null;
	}

	public static String[] getHostNameIpAddress() {
		String canonicalHostName = null;
		String ipAddress = null;
		try {
			InetAddress inet = InetAddress.getLocalHost();
			if (inet != null) {
				canonicalHostName = inet.getCanonicalHostName();
				ipAddress = inet.getHostAddress();
			}
		} catch (UnknownHostException e) {
			LOG.warn(e.getMessage(), e);
		}
		return new String[] { canonicalHostName, ipAddress };
	}

	private static String getNodeNameInternal() {
		return System.getProperty("weblogic.Name");
	}

	public static boolean isNull(Object str) {
		return str == null;
	}

	public static boolean isNullOrEmpty(String str) {
		return str == null || str.isEmpty();
	}

	public static boolean isNullOrEmpty(Collection<?> str) {
		return str == null || str.isEmpty();
	}

	public static boolean isNullOrEmptyAfterTrim(String str) {
		return str == null || str.trim().isEmpty();
	}

	private static void init() {
		hostName = getHostNameInternal();
		nodeName = getNodeNameInternal();
		if (nodeName == null) {
			hostAndNodeName = hostName;
		} else {
			hostAndNodeName = hostName + "-" + nodeName;
		}
	}

	static {
		init();
	}

	public static String exceptionStackTrace(Exception e) {
		StringWriter out = new StringWriter();
		e.printStackTrace(new PrintWriter(out));
		return out.toString();
	}

	public static boolean isNotNullAndNotEmpty(String str) {
		return str != null && !str.isEmpty();
	}

	public static String toString(List<String> strs) {
		if (isNullOrEmpty(strs)) {
			return "";
		}
		final String separator = ",";
		StringBuilder stringBuilder = new StringBuilder();
		int noOfCommas = strs.size() - 1;
		int count = 0;
		for (String string : strs) {
			stringBuilder.append(string);
			if (count < noOfCommas) {
				stringBuilder.append(separator);
			}
			count++;
		}
		return stringBuilder.toString();
	}
	
	public static String toStringSingleQuoted(Collection<String> strs) {
		if (isNullOrEmpty(strs)) {
			return "";
		}
		final String separator = ",";
		StringBuilder stringBuilder = new StringBuilder();
		int noOfCommas = strs.size() - 1;
		int count = 0;
		for (String string : strs) {
			stringBuilder.append("'");
			stringBuilder.append(string);
			stringBuilder.append("'");
			if (count < noOfCommas) {
				stringBuilder.append(separator);
			}
			count++;
		}
		return stringBuilder.toString();
	}

	public static int extractNumber(String str) {
		return Integer.parseInt(str.replaceAll("[^0-9]", ""));
	}
	
	public static URI buildUrlWithParams(String url, Map<String, String> urlParams) {
		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url);
		URI restUri = null;
		if (urlParams != null && urlParams.size() > 0) {
			restUri = builder.buildAndExpand(urlParams).toUri();
		} else {
			restUri = builder.build().toUri();
		}
		return restUri;
	}
}
