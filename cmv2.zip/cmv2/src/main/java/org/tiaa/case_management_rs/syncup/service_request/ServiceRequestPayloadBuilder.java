package org.tiaa.case_management_rs.syncup.service_request;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;

import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.integration.cth.CTHContext;
import org.tiaa.case_management_rs.integration.cth.CreateCTHContext;
import org.tiaa.case_management_rs.integration.cth.PayloadInfoBuilder;
import org.tiaa.esb.plansponsor.types.ClientRelationship;
import org.tiaa.esb.plansponsor.types.Contact;
import org.tiaa.esb.plansponsor.types.ContactResp;
import org.tiaa.esb.plansponsor.types.ContactResponse;
import org.tiaa.esb.plansponsor.types.Contacts;
import org.tiaa.esb.plansponsor.types.EmailAddress;
import org.tiaa.esb.plansponsor.types.Name;
import org.tiaa.esb.plansponsor.types.PhoneNumber;
import org.tiaa.esb.plansponsor.types.PhoneNumbers;
import org.tiaa.esb.servicerequest.types.AnyXMLSkipType;
import org.tiaa.esb.servicerequest.types.CTHClob;
import org.tiaa.esb.servicerequest.types.Documents;
import org.tiaa.esb.servicerequest.types.OtherData;
import org.tiaa.esb.servicerequest.types.PersonNameType;
import org.tiaa.esb.servicerequest.types.Request;
import org.tiaa.esb.servicerequest.types.RequestContactDetailsType;
import org.tiaa.esb.servicerequest.types.RequestContactPhoneType;
import org.tiaa.esb.servicerequest.types.RequestCustomerType;
import org.tiaa.esb.servicerequest.types.RequestPlanType;
import org.tiaa.esb.servicerequest.types.ServiceRequest;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;

public class ServiceRequestPayloadBuilder extends PayloadInfoBuilder {
	private Jaxb2Marshaller serviceRequestJaxb2Marshaller;

	public ServiceRequestPayloadBuilder(String requestSchemaName, String requestSchemaVersion) {
		super(requestSchemaName, requestSchemaVersion);
	}

	@Override
	protected Element setRequestInfoAnyElement(CreateCTHContext context) {
		return toElement(createCTHClobType(context), serviceRequestJaxb2Marshaller);
	}

	private CTHClob createCTHClobType(CreateCTHContext context) {
		CTHClob cthClobType = new CTHClob();
		cthClobType.setRequest(createRequestType(context));
		if (setDocuments) {
			cthClobType.setDocuments(new Documents());
		}
		//
		CaseInfo caseInfoType = mapCaseInfo(context);
		//
		AnyXMLSkipType anyXMLSkipType = new AnyXMLSkipType();
		anyXMLSkipType.setAny(toElement(caseInfoType, servicerequestWorkflowJaxb2Marshaller));
		//
		OtherData otherDataType = new OtherData();
		otherDataType.setWorkFlowXML(anyXMLSkipType);
		//
		cthClobType.setOtherData(otherDataType);
		return cthClobType;
	}

	private Request createRequestType(CreateCTHContext context) {
		ServiceRequest requestServiceRequestType = new ServiceRequest();
		//
		requestServiceRequestType.setCustomer(createCustomer(context));
		//
		RequestPlanType requestPlanType = new RequestPlanType();
		requestPlanType.setPlanName(context.getStringIdentifierValue("PLAN NAME"));
		requestPlanType.setSubplanName(context.getStringIdentifierValue("SUBPLAN"));
		requestServiceRequestType.setPlan(requestPlanType);
		//
		Request requestType = new Request();
		requestType.setServiceRequest(requestServiceRequestType);
		return requestType;
	}

	public RequestCustomerType createCustomer(CTHContext context) {
		ContactResponse contactResponse = context.getContactResponse();
		if (contactResponse == null) {
			return null;
		}
		ContactResp contactResp = contactResponse.getContactResp();
		if (contactResp == null) {
			return null;
		}
		Contacts contacts = contactResp.getContacts();
		if (contacts == null) {
			return null;
		}
		List<RequestCustomerType> requestCustomerTypes = new ArrayList<RequestCustomerType>();
		for (Contact contact : contacts.getContacts()) {
			RequestContactPhoneType requestContactPhoneType = new RequestContactPhoneType();
			PhoneNumbers phoneNumbers = contact.getPhoneNumbers();
			List<PhoneNumber> phoneNumberList = phoneNumbers.getPhoneNumbers();
			for (PhoneNumber phoneNumber : phoneNumberList) {
				requestContactPhoneType.setExtension(phoneNumber.getExtension());
				requestContactPhoneType.setNumber(phoneNumber.getNumber());
			}
			//
			RequestContactDetailsType requestContactDetailsType = new RequestContactDetailsType();
			requestContactDetailsType.setPhone(requestContactPhoneType);
			for (EmailAddress emailAddress2 : contact.getEmailAddresses().getEmailAddresses()) {
				requestContactDetailsType.setEmailAddress(emailAddress2.getAddress());
			}
			//
			PersonNameType personNameType = new PersonNameType();
			Name name = contact.getName();
			personNameType.setFirstName(name.getFirstName());
			personNameType.setLastName(name.getLastName());
			personNameType.setMiddleName(name.getMiddleName());
			personNameType.setPrefix(name.getPrefix());
			personNameType.setSuffix(name.getSuffix());
			//
			RequestCustomerType requestCustomerType1 = new RequestCustomerType();
			requestCustomerType1.setContactDetails(requestContactDetailsType);
			requestCustomerType1.setCustomerName(personNameType);
			List<ClientRelationship> clientRelationships = contact.getClientRelationships().getClientRelationships();
			for (ClientRelationship clientRelationship : clientRelationships) {
				requestCustomerType1.setCustomerType(clientRelationship.getUserType());
			}
			requestCustomerTypes.add(requestCustomerType1);
		}
		return requestCustomerTypes.get(0);
	}

	public void setServiceRequestJaxb2Marshaller(Jaxb2Marshaller serviceRequestJaxb2Marshaller) {
		this.serviceRequestJaxb2Marshaller = serviceRequestJaxb2Marshaller;
	}
}
