package org.tiaa.case_management_rs.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import org.tiaa.case_management_rs.domain.CMSAudit;

@Repository
public interface CMSAuditRepository extends JpaRepository<CMSAudit, Long> {
	CMSAudit findByTaskId(String taskId);
	CMSAudit findByCthOrchestrationId(String cthOrchestrationId);
}
