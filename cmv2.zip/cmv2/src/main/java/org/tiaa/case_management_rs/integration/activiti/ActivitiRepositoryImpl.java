package org.tiaa.case_management_rs.integration.activiti;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.io.StringReader;
import java.io.StringWriter;
import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import org.tiaa.case_management_rs.common.ActivitiHeaderAdderInterceptor;
import org.tiaa.case_management_rs.delegate.TaskSearchDelegate;
import org.tiaa.case_management_rs.exception.CaseManagementRuntimeException;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.CryptUtility;
import org.tiaa.esb.case_management_rs_v2.type.CommentsRequest;
import org.tiaa.esb.case_management_rs_v2.type.CommentsResponse;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItems;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItemsResponse;
import org.tiaa.esb.case_management_rs_v2.type.DocumentRequest;
import org.tiaa.esb.case_management_rs_v2.type.DocumentResponse;
import org.tiaa.esb.case_management_rs_v2.type.DocumentsResponse;
import org.tiaa.esb.case_management_rs_v2.type.ESBMessages;
import org.tiaa.esb.case_management_rs_v2.type.Metrics;
import org.tiaa.esb.case_management_rs_v2.type.MetricsResponse;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.ProcessRequest;
import org.tiaa.esb.case_management_rs_v2.type.ProcessResponse;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.ProcessesRequest;
import org.tiaa.esb.case_management_rs_v2.type.ProcessesResponse;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;
import org.tiaa.esb.case_management_rs_v2.type.SearchResponse;
import org.tiaa.esb.case_management_rs_v2.type.Task;
import org.tiaa.esb.case_management_rs_v2.type.TaskRequest;
import org.tiaa.esb.case_management_rs_v2.type.TaskResponse;
import org.tiaa.esb.icm.types.Configuration;
import org.tiaa.esb.icm.types.ResponseList;
import org.tiaa.esb.icm.types.TaskSearch;

import sun.misc.BASE64Encoder;

@Repository(value = "activitiRepositoryImpl")
public class ActivitiRepositoryImpl implements ActivitiRepository, TaskSearchDelegate {
	public static final String DEPARTMENT = "department";
	private static final Logger LOGGER = LoggerFactory
			.getLogger(ActivitiRepositoryImpl.class);

	@Value("${activiti.root}")
	private String activitiRoot;

	@Value("${activitiUserName}")
	private String activitiUserName;
	@Value("${activitiPassword}")
	private String activitiPassword;

	@Autowired
	private RestTemplate activitiRestTemplate; // use new RestTemplate

	private HttpHeaders headers = new HttpHeaders();
	private HttpHeaders cmtsHeaders = new HttpHeaders();
	private HttpEntity<String> entity = null;


	@Autowired
	private ActivitiRepositoryLinkHelper activitiRepositoryLinkHelper;

	@Autowired
	private BASE64Encoder base64Encoder;

	@PostConstruct
	private void beanPostProcess() {
		if (this.activitiRestTemplate != null) {
			headers.setAccept(Arrays.asList(MediaType.APPLICATION_XML));
			headers.setContentType(MediaType.APPLICATION_XML);
		}
	}

	@Override
	public ProcessResponse getActivitiProcess(String processId, String userId,
			String lockMode, String section, String convertedEXPAGTask) {

		String activitiProcessURL = null;
		
		if(YES.equalsIgnoreCase(convertedEXPAGTask)){
			 activitiProcessURL =  activitiRepositoryLinkHelper.getActivitiProcessRestURL().replace("{processId}", processId).replace("{lockmode}", lockMode)+"&appName=converted-expag";
		}
		else{
			activitiProcessURL = (section != null) ? activitiRepositoryLinkHelper.getActivitiGetProcessInfocaddyURL().replace("{processId}", processId).replace("{lockmode}", lockMode).replace("{section}", section) : activitiRepositoryLinkHelper.getActivitiProcessRestURL().replace("{processId}", processId).replace("{lockmode}", lockMode);
		}
		//activitiProcessURL ="http://dend2b3tcwfm10.cloud.tiaa-cref.org:9080/nxtgen-business-process-rs-v1/process/t1801180003?appName=converted-expag&lock=true";
		LOGGER.info("ActivitiGetProcessURL - "+activitiProcessURL);
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		ResponseEntity<ProcessResponse> result = this.activitiRestTemplate
				.exchange(activitiProcessURL,
						org.springframework.http.HttpMethod.GET, entity,
						ProcessResponse.class, processId);

		ProcessResponse processResponse = result.getBody();
		return processResponse;
	}

	@Override
	public DocumentsResponse getActivitiDocuments(String processId,
			String userId, String convertedExpag) {
		
		String activitiGetDocumentsURL = null;
		if(YES.equalsIgnoreCase(convertedExpag)){
			activitiGetDocumentsURL = activitiRepositoryLinkHelper
					.getActivitiGetDocumentsURL().replace("{processId}", processId)+"?appName=converted-expag";
		} else{
			activitiGetDocumentsURL = activitiRepositoryLinkHelper
					.getActivitiGetDocumentsURL().replace("{processId}", processId);
		}
		

		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		ResponseEntity<DocumentsResponse> result = this.activitiRestTemplate
				.exchange(activitiGetDocumentsURL,
						org.springframework.http.HttpMethod.GET, entity,
						DocumentsResponse.class, processId);
		DocumentsResponse documentsResp = result.getBody();

		LOGGER.debug("documentsResp:" + documentsResp);

		return documentsResp;
	}

	@Override
	public CommentsResponse getActivitiComments(String processId, String userId) {
		String activitiGetCommentsURL = activitiRepositoryLinkHelper
				.getActivitiGetCommentsURL().replace("{processId}", processId);
		LOGGER.debug("activitiGetCommentsURL--->" + activitiGetCommentsURL);
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		ResponseEntity<CommentsResponse> result = this.activitiRestTemplate
				.exchange(activitiGetCommentsURL,
						org.springframework.http.HttpMethod.GET, entity,
						CommentsResponse.class, processId);
		CommentsResponse commentsResp = result.getBody();

		LOGGER.debug("Comments Response->" + commentsResp);
		return commentsResp;
	}

	@Override
	public CommentsResponse getActivitiTaskComments(String processId,
			String userId, String taskId) {
		String activitiGetTaskCommentsURL = activitiRepositoryLinkHelper
				.getActivitiGetTaskCommentsURL()
				.replace("{processId}", processId).replace("{taskId}", taskId);
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		ResponseEntity<CommentsResponse> result = this.activitiRestTemplate
				.exchange(activitiGetTaskCommentsURL,
						org.springframework.http.HttpMethod.GET, entity,
						CommentsResponse.class, processId);
		CommentsResponse taskCommentsResponse = result.getBody();

		LOGGER.debug("Comments Response->" + taskCommentsResponse);

		return taskCommentsResponse;
	}

	@Override
	public DocumentResponse getActivitiDocument(String processId,
			String userId, String documentId, String convertedExpag) {
		
		String activitiGetDocumentURL = null;
		if(YES.equalsIgnoreCase(convertedExpag)){
		 activitiGetDocumentURL = activitiRepositoryLinkHelper
				.getActivitiGetDocumentURL().replace("{processId}", processId)
				.replace("{documentId}", documentId)+"?appName=converted-expag";
		 } else{
			 activitiGetDocumentURL = activitiRepositoryLinkHelper
						.getActivitiGetDocumentURL().replace("{processId}", processId)
						.replace("{documentId}", documentId);
		 }
		
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		ResponseEntity<DocumentResponse> result = this.activitiRestTemplate
				.exchange(activitiGetDocumentURL,
						org.springframework.http.HttpMethod.GET, entity,
						DocumentResponse.class, processId);
		DocumentResponse documentResponse = result.getBody();
		return documentResponse;
	}

	// for march release getTasks is making call to
	// Activiti({processId}/history) service
	@Override
	public ProcessResponse getActivitiTasks(String processId, String userId) {
		String activitiGetTasksURL = activitiRepositoryLinkHelper
				.getActivitiGetTasksURL().replace("{processId}", processId);
		 //activitiGetTasksURL ="http://dend2b3tcwfm10.cloud.tiaa-cref.org:9080/nxtgen-business-process-rs-v1/process/t1801120004/tasks?appName=converted-expag";
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		ResponseEntity<ProcessResponse> result = this.activitiRestTemplate
				.exchange(activitiGetTasksURL,
						org.springframework.http.HttpMethod.GET, entity,
						ProcessResponse.class, processId);
		ProcessResponse processResponse = result.getBody();

		LOGGER.debug("Tasks Response->" + processResponse);

		return processResponse;
	}


	@Override
	public TaskResponse getActivitiTaskById(String processId, String userId,
			String taskId) {
		String activitiGetTaskByIdURL = activitiRepositoryLinkHelper
				.getActivitiGetTaskByIdURL().replace("{processId}", processId)
				.replace("{taskId}", taskId);
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);
		ResponseEntity<TaskResponse> result = this.activitiRestTemplate
				.exchange(activitiGetTaskByIdURL,
						org.springframework.http.HttpMethod.GET, entity,
						TaskResponse.class, processId);
		TaskResponse taskByIdResponse = result.getBody();
		return taskByIdResponse;
	}

	@Override
	public Processes getActivitiTasksClaimable(String userId, String dept, String type, String convertedExpagTask) {
		String activitiGetTasksClaimableURL = activitiRepositoryLinkHelper
				.getActivitiGetTasksClaimableURL().replace("{type}", type);
		if (StringUtils.isNotBlank(dept)) {
			activitiGetTasksClaimableURL = activitiGetTasksClaimableURL.replace("{dept}", dept);
		} else {
			activitiGetTasksClaimableURL = new StringBuilder(activitiGetTasksClaimableURL).delete(activitiGetTasksClaimableURL.indexOf("&department="), activitiGetTasksClaimableURL.length()).toString();
		}
		if (YES.equalsIgnoreCase(convertedExpagTask)) {
			activitiGetTasksClaimableURL = new StringBuilder(activitiGetTasksClaimableURL).append("&appName=converted-expag").toString();
		}

		LOGGER.info("GetClaimableTasks Activiti URL : "+activitiGetTasksClaimableURL);
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		ResponseEntity<ProcessesResponse> result = this.activitiRestTemplate
				.exchange(activitiGetTasksClaimableURL,
						org.springframework.http.HttpMethod.GET, entity,
						ProcessesResponse.class);
		ProcessesResponse tasksClaimableResponse = result.getBody();

		Processes processes = new Processes();
		if (tasksClaimableResponse != null && tasksClaimableResponse.getProcesses() != null) {
			processes = tasksClaimableResponse.getProcesses();
		}
		LOGGER.info("GET Processes Response --->" +processes);
		return processes;
	}

	@Override
	public CommentsResponse addActivitiComment(String processId, String userId,CommentsRequest commentRequest) {

		String activitiAddCommentURL = activitiRepositoryLinkHelper.getActivitiAddCommentURL().replace("{processId}", processId);

		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(headers, base64Encoder, activitiUserName, activitiPassword,userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		HttpEntity<CommentsRequest> entity = new HttpEntity<CommentsRequest>(commentRequest, headers);
		ResponseEntity<CommentsResponse> responseEntity = this.activitiRestTemplate	.exchange(activitiAddCommentURL,
				org.springframework.http.HttpMethod.POST, entity,
				CommentsResponse.class );
		CommentsResponse commentResponse = responseEntity.getBody();
		LOGGER.debug("POST Comment Response->" + commentResponse);
		return commentResponse;
	}

	// Authorization Header method
	public String getActivitiAuthorizationHeader() {
		String userpass = activitiUserName + ":"
				+ CryptUtility.decrypt(activitiPassword);
		String encString = base64Encoder.encode(userpass.getBytes());
		return "Basic " + encString;

	}

	@Override
	public DocumentResponse addActivitiDocument(
			DocumentRequest activitiDocumentReq, String taskId, String userId, String convertedExpag) {
		
		String activitiDocumentsURL = null;
		if(YES.equalsIgnoreCase(convertedExpag)){
			activitiDocumentsURL = activitiRepositoryLinkHelper.getActivitiDocumentsURL().replace("{processId}", taskId)+"?appName=converted-expag";
		}
		else{
		activitiDocumentsURL = activitiRepositoryLinkHelper
				.getActivitiDocumentsURL().replace("{processId}", taskId);
		}
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);
		HttpEntity<DocumentRequest> entity = new HttpEntity<DocumentRequest>(
				activitiDocumentReq, headers);
		ResponseEntity<DocumentResponse> responseEntity = this.activitiRestTemplate
				.exchange(activitiDocumentsURL,
						org.springframework.http.HttpMethod.POST, entity,
						DocumentResponse.class, taskId);
		DocumentResponse documentsResponse = responseEntity.getBody();
		LOGGER.debug("POST Document Response->" + documentsResponse);
		return documentsResponse;
	}
	
	@Override
	public DocumentResponse updateActivitiDocument(
			DocumentRequest activitiDocumentReq, String taskId, String userId, String convertedExpag) {
		
		String activitiDocumentsURL = null;
		if(YES.equalsIgnoreCase(convertedExpag)){
			activitiDocumentsURL = activitiRepositoryLinkHelper.getActivitiDocumentsURL().replace("{processId}", taskId)+"?appName=converted-expag";
		}
		else{
		activitiDocumentsURL = activitiRepositoryLinkHelper
				.getActivitiDocumentsURL().replace("{processId}", taskId);
		}
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);
		HttpEntity<DocumentRequest> entity = new HttpEntity<DocumentRequest>(
				activitiDocumentReq, headers);
		ResponseEntity<DocumentResponse> responseEntity = this.activitiRestTemplate
				.exchange(activitiDocumentsURL,
						org.springframework.http.HttpMethod.PUT, entity,
						DocumentResponse.class, taskId);
		DocumentResponse documentsResponse = responseEntity.getBody();
		LOGGER.debug("PUT Document Response->" + documentsResponse);
		return documentsResponse;
	}

	@Override
	public SearchResponse search(SearchRequest searchRequest, String userId) {
		String activitiSearchURL = activitiRepositoryLinkHelper
				.getActivitiSearchURL();

		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		this.activitiRestTemplate
		.setInterceptors(clientHttpRequestInterceptors);
		HttpEntity<SearchRequest> entity = new HttpEntity<SearchRequest>(
				searchRequest, headers);
		ResponseEntity<SearchResponse> responseEntity = this.activitiRestTemplate
				.exchange(activitiSearchURL,
						org.springframework.http.HttpMethod.POST, entity,
						SearchResponse.class);
		SearchResponse searchResponse = responseEntity.getBody();	
		LOGGER.info("ACTIVITI Search Response->" + searchResponse);
		return searchResponse;
	}

	@Override
	public Process updateActivitiProcess(ProcessRequest processRequest, String userId, String processId, String convertedEXPAGTask) {
		
		String updateProcessURL = null;
		
		if(YES.equalsIgnoreCase(convertedEXPAGTask)){
			updateProcessURL = activitiRepositoryLinkHelper.getActivitiUpdateProcessURL().replace("{processId}", processId)+"?appName=converted-expag";
		}
		else{
			updateProcessURL = activitiRepositoryLinkHelper.getActivitiUpdateProcessURL().replace("{processId}", processId);
		}
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(headers, base64Encoder, activitiUserName, activitiPassword, userId));
		this.activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		LOGGER.info("Activiti Update URL - " + updateProcessURL);
		LOGGER.info("TriggerEventName being sent to Activiti - " + processRequest.getProcess().getTriggerEventName());
		LOGGER.info("Invoking Signal in activiti - ");

		HttpEntity<ProcessRequest> entity = new HttpEntity<ProcessRequest>(processRequest, headers);
		ResponseEntity<ProcessResponse> responseEntity = this.activitiRestTemplate.exchange(updateProcessURL, org.springframework.http.HttpMethod.PUT, entity, ProcessResponse.class, processId);
		ProcessResponse processResponse = responseEntity.getBody();
		LOGGER.debug("Update Process Response->" + processResponse);
		Process process = new Process();
		if (processResponse != null && processResponse.getProcess() != null) {
			process = processResponse.getProcess();
		}
		return process;
	}

	@Override
	public ConfigItems getActivitiConfigItems(String property, String userId,String department) {
		String getConfigURL = (department != null)
				? activitiRepositoryLinkHelper.getActivitiConfigItemsURLforDept().replace("{property}", property)
						.replace("{department}", department)
						: activitiRepositoryLinkHelper.getActivitiConfigItemsURL().replace("{property}", property);
						LOGGER.info("GetConfigURL -->" + getConfigURL);
						List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
						clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
								headers, base64Encoder, activitiUserName, activitiPassword,
								userId));
						this.activitiRestTemplate
						.setInterceptors(clientHttpRequestInterceptors);
						ConfigItems configItems = new ConfigItems();
						try {
							ResponseEntity<ConfigItemsResponse> responseEntity = this.activitiRestTemplate
									.exchange(getConfigURL,
											org.springframework.http.HttpMethod.GET, entity,
											ConfigItemsResponse.class);
							ConfigItemsResponse configItemsResponse = responseEntity.getBody();

							if (configItemsResponse != null
									&& configItemsResponse.getConfigItems() != null) {
								configItems = configItemsResponse.getConfigItems();
							}
						} catch (Exception e) {
							LOGGER.error("ACTIVITI ConfigItems error message=" + e.getMessage());
						}

						return configItems;
	}

	/* (non-Javadoc)
	 * @see org.tiaa.case_management_rs.integration.activiti.ActivitiRepository#createActivitiProcess(org.tiaa.esb.case_management_rs_v2.type.ProcessRequest, java.lang.String)
	 */
	@Override
	public Processes createActivitiProcesses(ProcessesRequest processesReq,	String userId, String convertedEXPAGTask) {
		
		String createProcURL= null;
		
		if(YES.equalsIgnoreCase(convertedEXPAGTask)){
			 createProcURL = activitiRepositoryLinkHelper.getActivitiCreateProcessURL()+"?appName=converted-expag";
		}
		else{
			 createProcURL = activitiRepositoryLinkHelper.getActivitiCreateProcessURL();
		}
		LOGGER.info("Activiti createProcURL - "+createProcURL);

		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(headers, base64Encoder, activitiUserName, activitiPassword,userId));

		this.activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		//Create ProcessRequest to support Activiti createProcess api
		ProcessRequest processReq = new ProcessRequest();
		if(processesReq.getProcesses().getProcesses().size() > 0){
			Process proc = processesReq.getProcesses().getProcesses().get(0);
			processReq.setProcess(proc);
		}

		HttpEntity<ProcessRequest> entity = new HttpEntity<ProcessRequest>(processReq, headers);
		Processes processes = null;
		try {
			ResponseEntity<ProcessResponse> responseEntity = this.activitiRestTemplate.exchange(createProcURL,org.springframework.http.HttpMethod.POST, entity,ProcessResponse.class);
			ProcessResponse processResponse = responseEntity.getBody();
			LOGGER.debug("Create Process Response->" + processResponse);
			processes = new Processes();
			if (processResponse != null && processResponse.getProcess() != null) {
				Process process = processResponse.getProcess();
				processes.getProcesses().add(process);
				LOGGER.info("Response from Activiti - " + process);
			}
		} catch (HttpClientErrorException httpClientException) {
			LOGGER.error("Client Error Code" + httpClientException.getStatusCode());
			LOGGER.error("Client Error Code" + httpClientException.getResponseBodyAsString());
			StringReader strReader = new StringReader(httpClientException.getResponseBodyAsString());
			try {
				JAXBContext jaxbContext = JAXBContext.newInstance(ProcessResponse.class);
				javax.xml.bind.Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
				ProcessResponse processResponse = (ProcessResponse) unmarshaller.unmarshal(strReader);
				ESBMessages errorESBMessages = processResponse.getResponseStatus().getMessages();
				throw new CaseManagementRuntimeException(errorESBMessages);
			} catch (JAXBException jaxbException) {
				LOGGER.error("Error occured while converting the JAXB Object " + jaxbException.getMessage());
			}
		}

		return processes;
	}

	@Override
	public Metrics getActivitiMetrics(String userId, String department) {

		String getMetricsURL =  activitiRepositoryLinkHelper.getActivitiGeMetricsURL().replace("{dept}", department);

		LOGGER.info("getMetricsURL :" + getMetricsURL);
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		this.activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);
		Metrics metrics = new Metrics();
		HttpEntity entity = new HttpEntity(headers);
		try {
			ResponseEntity<MetricsResponse> responseEntity = this.activitiRestTemplate
					.exchange(getMetricsURL,
							org.springframework.http.HttpMethod.GET, entity,
							MetricsResponse.class);
			MetricsResponse metricResponse = responseEntity.getBody();

			if (metricResponse != null	&& metricResponse.getMetrics() != null) {
				metrics = metricResponse.getMetrics();
			}
		} catch (Exception e) {
			LOGGER.error("ACTIVITI GetMetrics error message=" + e.getMessage());
		}

		return metrics;
	}

	@Override
	public Task updateActivitiTask(TaskRequest taskRequest, String userId, String processId, String taskId) {

		String updateTaskURL = activitiRepositoryLinkHelper.getActivitiUpdateTaskURL()
				.replace("{processId}", processId).replace("{taskId}", taskId);
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		this.activitiRestTemplate
		.setInterceptors(clientHttpRequestInterceptors);

		LOGGER.info("Activiti updateTaskURL - "+updateTaskURL);

		HttpEntity<TaskRequest> entity = new HttpEntity<TaskRequest>(taskRequest, headers);
		ResponseEntity<TaskResponse> responseEntity = this.activitiRestTemplate
				.exchange(updateTaskURL,
						org.springframework.http.HttpMethod.PUT, entity,
						TaskResponse.class, processId);
		TaskResponse taskResponse = responseEntity.getBody();
		LOGGER.debug("Update Task Response->" + taskResponse);
		Task task = new Task();
		if (taskResponse != null && taskResponse.getTask() != null) {
			task = taskResponse.getTask();
		}

		return task;
	}

	public ConfigItems getActivitiSolutionHeaders(String department, String userId, String tableHeaderType) {
		Configuration configuration = null;

		String activitiSolutionHeadersURL = activitiRoot
				+ "/config?property={property}&businessArea={dept}&type={type}";
		Map<String, String> uriParams = new HashMap<String, String>();
		uriParams.put("property", TABLEHEADERS);
		uriParams.put("dept", department);
		uriParams.put("type", tableHeaderType);
		URI uriForRestTemplate = CommonUtil.buildUrlWithParams(activitiSolutionHeadersURL, uriParams);
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(
				new ActivitiHeaderAdderInterceptor(headers, base64Encoder, activitiUserName, activitiPassword, userId));
		this.activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);
		ConfigItems configItems = new ConfigItems();
		try {
			ResponseEntity<?> responseEntity = this.activitiRestTemplate.exchange(uriForRestTemplate,org.springframework.http.HttpMethod.GET, entity, ConfigItemsResponse.class);
			ConfigItemsResponse configItemResponse = (ConfigItemsResponse) responseEntity.getBody();

			if (configItemResponse != null) {
				configItems = configItemResponse.getConfigItems();
			}
		} catch (Exception exception) {
			LOGGER.error("ACTIVITI GetSolutionHeader Exception -->" + exception.getMessage());
		}
		LOGGER.debug("Solution Headers Response ->" + configuration);
		return configItems;
	}

	@Override
	public ConfigItems getActivitiCaseWorkers(String userId, String property,
			SearchRequest srchRequest) {
		String activitiCaseWorkersURL = activitiRepositoryLinkHelper.getActivitiCaseworkersURL();

		LOGGER.info("ActivitiCaseWorkersURL - "+activitiCaseWorkersURL);
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(headers, base64Encoder, activitiUserName, activitiPassword,userId));
		this.activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);
		HttpEntity<SearchRequest> entity = new HttpEntity<SearchRequest>(srchRequest, headers);
		ResponseEntity<ConfigItemsResponse> responseEntity = this.activitiRestTemplate.exchange(activitiCaseWorkersURL,
				org.springframework.http.HttpMethod.POST, entity,ConfigItemsResponse.class);
		ConfigItemsResponse configItemResponse = responseEntity.getBody();
		LOGGER.info("ACTIVITI Caseworkers Response->" + configItemResponse);

		ConfigItems configItems = new ConfigItems();
		if (configItemResponse != null && configItemResponse.getConfigItems() != null) {
			configItems = configItemResponse.getConfigItems();
		}
		return configItems;
	}

	@Override
	public Processes updateActivitiProcesses(String userId,
			ProcessesRequest processesReq,String convertedEXPAGTask) {
		String activitiAssignTaskURL = activitiRepositoryLinkHelper.getActivitiAssginTaskURL();
		if(YES.equalsIgnoreCase(convertedEXPAGTask)){
			activitiAssignTaskURL=activitiAssignTaskURL+"?appName=converted-expag";
		}
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,	userId));
		this.activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		LOGGER.info("Activiti AssignTaskURL - "+activitiAssignTaskURL);

		HttpEntity<ProcessesRequest> entity = new HttpEntity<ProcessesRequest>(processesReq, headers);
		ResponseEntity<ProcessesResponse> responseEntity = this.activitiRestTemplate
				.exchange(activitiAssignTaskURL,
						org.springframework.http.HttpMethod.PUT, entity,
						ProcessesResponse.class);
		ProcessesResponse processesResponse = responseEntity.getBody();
		LOGGER.debug("Update ProcessesResponse->" + processesResponse);
		Processes processes = new Processes();
		if (processesResponse != null && processesResponse.getProcesses() != null) {
			processes = processesResponse.getProcesses();
		}
		return processes;
	}

	public Process getTimeline(String processId, String userId, String start, String type) {
		String activitGetTimelineURL= activitiRoot+"/process/{processid}/timeline?type={type}&start={start}";
		Process process = null;

		//start = (start == null) ? "0" : start;
		Map<String, String> uriParams = new HashMap<String, String>();

		uriParams.put("processid", processId);
		uriParams.put("type", type);
		uriParams.put("start", start);
		URI uriForRestTemplate = CommonUtil.buildUrlWithParams(activitGetTimelineURL, uriParams);

		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		ResponseEntity<ProcessResponse> result = this.activitiRestTemplate
				.exchange(uriForRestTemplate,
						org.springframework.http.HttpMethod.GET, entity,
						ProcessResponse.class);
		ProcessResponse processResponse = result.getBody();
		if(processResponse != null){
			process = processResponse.getProcess();
		}
		return process;
	}
	@Override
	public Processes getActivitiRelatedProcesses(String userId,String processId) {

		String activitiRelatedTasks= activitiRoot+"/process/{processid}/relatedRequests";
		Map<String, String> uriParams = new HashMap<String, String>();
		uriParams.put("processid", processId);

		URI uriForRestTemplate = CommonUtil.buildUrlWithParams(activitiRelatedTasks, uriParams);

		LOGGER.info("GetActivitiRelatedTasks Activiti URL : "+activitiRelatedTasks);
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
				headers, base64Encoder, activitiUserName, activitiPassword,
				userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		ResponseEntity<ProcessesResponse> result = this.activitiRestTemplate
				.exchange(uriForRestTemplate,
						org.springframework.http.HttpMethod.GET, entity,
						ProcessesResponse.class);
		ProcessesResponse relatedProcesses = result.getBody();

		Processes processes = new Processes();
		if (relatedProcesses != null && relatedProcesses.getProcesses() != null && relatedProcesses.getProcesses().getProcesses() != null ) {
			processes = relatedProcesses.getProcesses();
		}

		return processes;
	}

	@Override
	public void deleteActivitiDocument(String processId, String documentId, String userId) {

		try {
			String deleteActivitiDocument =  activitiRoot +"/process/{processId}/document/{documentId}";

			Map<String, String> uriParams = new HashMap<String, String>();

			uriParams.put("processId", processId);
			uriParams.put("documentId", documentId);

			URI uriForRestTemplate = CommonUtil.buildUrlWithParams(deleteActivitiDocument, uriParams);

			List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
			clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(
					headers, base64Encoder, activitiUserName, activitiPassword,
					userId));


			activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

			HttpEntity entity = new HttpEntity(headers);

			this.activitiRestTemplate
			.exchange(uriForRestTemplate,
					org.springframework.http.HttpMethod.DELETE, entity,
					DocumentResponse.class);

		} catch (HttpClientErrorException httpClientException) {

			LOGGER.error("Delete Document - Error Code: " + httpClientException.getStatusCode());
			StringReader strReader = new StringReader(httpClientException.getResponseBodyAsString());

			try {

				JAXBContext jaxbContext = JAXBContext.newInstance(ProcessResponse.class);
				javax.xml.bind.Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();

				ProcessResponse response = (ProcessResponse) unmarshaller.unmarshal(strReader);

				ESBMessages errorESBMessages = response.getResponseStatus().getMessages();
				throw new CaseManagementRuntimeException(errorESBMessages);

			} catch (JAXBException jaxbException) {
				LOGGER.error("Error occured while converting the JAXB Object " + jaxbException.getMessage());
			}

		}catch (Exception e) {
			LOGGER.error("Delete Document Service Call Failed " + e.getMessage());
			throw e;
		}

	}

	@Override
	public ResponseList searchNigoTasks(TaskSearch taskSearchRequest, String userId) {
		String status = taskSearchRequest.getTaskStatus();
		String noOfDays = taskSearchRequest.getDays();
		String activitiTaskSearchURL = activitiRepositoryLinkHelper
				.getActivitiTaskSearchURL().replace("{tskstatus}", status)
				.replace("{days}", noOfDays);

		cmtsHeaders.set("Accept", "application/json");
		cmtsHeaders.set("ContentType", "application/json");
		cmtsHeaders.set("tiaa_user", userId);
		cmtsHeaders.set("Authorization", getActivitiAuthorizationHeader());

		HttpEntity<String> entity = new HttpEntity<String>(cmtsHeaders);
		ResponseList taskResponse = new ResponseList();
		List<LinkedHashMap<String,String>> resTaskList = new ArrayList<LinkedHashMap<String,String>>();

		try {
			ResponseEntity<ResponseList> responseEntity = new RestTemplate().exchange(activitiTaskSearchURL,
					org.springframework.http.HttpMethod.GET, entity,	
					ResponseList.class);
			taskResponse = responseEntity.getBody();
			@SuppressWarnings("unchecked")
			ArrayList<LinkedHashMap<String,String>> resList =  (ArrayList<LinkedHashMap<String,String>>) taskResponse.getResults();
			LOGGER.info("ACTIVITI TaskSearch Response->" + taskResponse);

			//code to compare request PINS against response PINS
			List<String> reqpins = taskSearchRequest.getPins();


			for( LinkedHashMap<String,String> resData : resList){
				Set<String> keys = resData.keySet();
				for(String key: keys){
					if (reqpins.contains(resData.get(key))) {
						resTaskList.add(resData);
					}
				}
			}
		} catch(Exception e){
			LOGGER.error("ACTIVITI tasksearch error message=" + e.getMessage());
		}

		ResponseList resp = new ResponseList();
		resp.setResults(resTaskList);
		return  resp;
	}

	
	@Override
	public Process createActivitiRelatedTask(ProcessRequest processReq, String userId, String processId, String caseId) {

		Process process = new Process();

		String createRealtedProcessURL = activitiRepositoryLinkHelper.getActivitiCreateRelatedTask().replace("{processId}", processId).replace("{caseId}", caseId)+"&appName=converted-expag";

		/* change ProcessReq to ProcessReq as per BPRS API */
		ProcessesRequest processesRequest = new ProcessesRequest();
		Processes processes = new Processes();
		processes.getProcesses().add(processReq.getProcess());
		processesRequest.setProcesses(processes);

		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(headers, base64Encoder, activitiUserName, activitiPassword, userId));

		this.activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);
		
		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(ProcessesRequest.class);
			javax.xml.bind.Marshaller marshaller = jaxbContext.createMarshaller();
			StringWriter sw = new StringWriter();
			marshaller.marshal(processesRequest, sw);
			//System.out.println(sw.toString());
			
		} catch (JAXBException jaxbException) {
			LOGGER.error("Error occured while converting the JAXB Object " + jaxbException.getMessage());
		}

		HttpEntity<ProcessesRequest> entity = new HttpEntity<ProcessesRequest>(processesRequest, headers);

		try {
			ResponseEntity<ProcessesResponse> responseEntity = this.activitiRestTemplate.exchange(createRealtedProcessURL, org.springframework.http.HttpMethod.POST, entity, ProcessesResponse.class);
			ProcessesResponse processesResponse = responseEntity.getBody();
			LOGGER.debug("Create Processes Response->" + processesResponse);

			if (processesResponse != null && processesResponse.getProcesses() != null && !processesResponse.getProcesses().getProcesses().isEmpty()) {
				process = processesResponse.getProcesses().getProcesses().get(0);

				LOGGER.info("Response from Activiti - " + process);
			}
		} catch (HttpClientErrorException httpClientException) {
			LOGGER.error("Client Error Code" + httpClientException.getStatusCode());
			LOGGER.error("Client Error Code" + httpClientException.getResponseBodyAsString());
			StringReader strReader = new StringReader(httpClientException.getResponseBodyAsString());
			try {
				JAXBContext jaxbContext = JAXBContext.newInstance(ProcessResponse.class);
				javax.xml.bind.Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
				ProcessResponse processResponse = (ProcessResponse) unmarshaller.unmarshal(strReader);
				ESBMessages errorESBMessages = processResponse.getResponseStatus().getMessages();
				throw new CaseManagementRuntimeException(errorESBMessages);
			} catch (JAXBException jaxbException) {
				LOGGER.error("Error occured while converting the JAXB Object " + jaxbException.getMessage());
			}
		}

		return process;
	}
	
	@Override
	public ProcessResponse getActivitiTaskAdditionalDetails(String processId, String userId) {

		String activitiGetTaskAdditionalDetailsURL = activitiRepositoryLinkHelper.getActivitiTaskAdditionalDetails().replace("{processId}", processId);

		LOGGER.info("ActivitiGetProcessURL - " + activitiGetTaskAdditionalDetailsURL);

		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new ActivitiHeaderAdderInterceptor(headers, base64Encoder, activitiUserName, activitiPassword, userId));
		activitiRestTemplate.setInterceptors(clientHttpRequestInterceptors);

		ResponseEntity<ProcessResponse> result = this.activitiRestTemplate.exchange(activitiGetTaskAdditionalDetailsURL, org.springframework.http.HttpMethod.GET, entity, ProcessResponse.class, processId);

		ProcessResponse processResponse = result.getBody();
		return processResponse;
	}
	
}

