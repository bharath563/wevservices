package org.tiaa.case_management_rs.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

public class PropertiesProvider {
	private static final Logger LOG = LoggerFactory.getLogger(PropertiesProvider.class);
	@Autowired
	private Environment environment;

	public int getIntProperty(String key) {
		String value = environment.getRequiredProperty(key);
		try {
			return Integer.parseInt(value);
		} catch (NumberFormatException e) {
			throw new ConfigurationException(e.getMessage(), e);
		}
	}

	public int getIntProperty(String key, int defaultValue) {
		String value = environment.getRequiredProperty(key);
		try {
			return Integer.parseInt(value);
		} catch (NumberFormatException e) {
			return defaultValue;
		}
	}

	public String getProperty(String key) {
		try {
			return environment.getRequiredProperty(key);
		} catch (IllegalStateException e) {
			LOG.error("Error:{} - property: {} not found", e.getMessage(), key);
			return "";
		}
	}

}
