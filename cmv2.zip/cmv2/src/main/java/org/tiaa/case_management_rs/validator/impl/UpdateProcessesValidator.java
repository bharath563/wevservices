package org.tiaa.case_management_rs.validator.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.apache.commons.lang3.StringUtils;

import org.tiaa.case_management_rs.common.Request;

/**
 * Update processes validator
 * @author nistala
 *
 */
public class UpdateProcessesValidator extends BaseValidatorImpl{

	@Override
	public void doValidate(Request request) {
		String userId = (String) request.getAttribute(USER_ID);
		String action = (String) request.getAttribute(ACTION);
		String appName = (String) request.getAttribute(APP_NAME);

		if (StringUtils.isBlank(userId)) {
			handleException(VALIDATION_USERID_IS_EMPTY);
		}

		if (StringUtils.isBlank(action)) {
			handleException(VALIDATION_ACTION_IS_EMPTY);
		}

		if (StringUtils.isBlank(appName)) {
			handleException(VALIDATION_APPNAME_IS_EMPTY);
		}

	}

}
