package org.tiaa.case_management_rs.integration.cth;

import org.springframework.ws.client.core.WebServiceTemplate;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.common.SInfoHeaderAdderWebServiceMessageCallback;
import org.tiaa.esb.partyrequest.types.CreateRequests;
import org.tiaa.esb.partyrequest.types.CreateRequestsResponse;
import org.tiaa.esb.partyrequest.types.RetrieveRequests;
import org.tiaa.esb.partyrequest.types.RetrieveRequestsResponse;
import org.tiaa.esb.partyrequest.types.UpdateRequests;
import org.tiaa.esb.partyrequest.types.UpdateRequestsResponse;

public class CTHWebService {
	private WebServiceTemplate cthWebServiceTemplate;
	private ResponseProcessor responseProcessor = new ResponseProcessor();

	public CreateRequestsResponse createCTHEntry(CreateCTHContext context, CreateRequests createRequests) {
		CreateRequestsResponse createRequestsResponse = (CreateRequestsResponse) cthWebServiceTemplate.marshalSendAndReceive(createRequests, createSInfoHeaderAdder(context.getCustomerNumber(), context.getTaskId()));
		responseProcessor.processCreateResponse(context, createRequestsResponse);
		return createRequestsResponse;
	}

	public UpdateRequestsResponse updateCTHEntry(CreateCTHContext context, UpdateRequests updateRequests) {
		String customerNumber = context.getCustomerNumber();
		UpdateRequestsResponse updateRequestsResponse = (UpdateRequestsResponse) cthWebServiceTemplate.marshalSendAndReceive(updateRequests, createSInfoHeaderAdder(customerNumber, context.getTaskId()));
		responseProcessor.processUpdateResponse(updateRequestsResponse);
		return updateRequestsResponse;
	}

	public UpdateRequestsResponse updateCTHEntry(UpdateCTHContext context, UpdateRequests updateRequests) {
		String customerNumber = context.getCustomerNumber();
		UpdateRequestsResponse updateRequestsResponse = (UpdateRequestsResponse) cthWebServiceTemplate.marshalSendAndReceive(updateRequests, createSInfoHeaderAdder(customerNumber, context.getTaskId()));
		responseProcessor.processUpdateResponse(updateRequestsResponse);
		return updateRequestsResponse;
	}

	private SInfoHeaderAdderWebServiceMessageCallback createSInfoHeaderAdder(String user, String taskId) {
		return new SInfoHeaderAdderWebServiceMessageCallback(AppConstants.APPLICATION_NAME, user, taskId);
	}

	public void setCthWebServiceTemplate(WebServiceTemplate cthWebServiceTemplate) {
		this.cthWebServiceTemplate = cthWebServiceTemplate;
	}

	public RetrieveRequestsResponse retrieveRequests(RetrieveRequests retrieveRequests, String user, String taskId) {
		return (RetrieveRequestsResponse) cthWebServiceTemplate.marshalSendAndReceive(retrieveRequests, createSInfoHeaderAdder(user, taskId));
	}
}
