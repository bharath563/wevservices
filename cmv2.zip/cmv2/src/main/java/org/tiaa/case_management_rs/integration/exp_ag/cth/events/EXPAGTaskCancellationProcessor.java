package org.tiaa.case_management_rs.integration.exp_ag.cth.events;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;

import javax.annotation.PostConstruct;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.transform.dom.DOMSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.oxm.UnmarshallingFailureException;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.common.ExceptionHandler;
import org.tiaa.case_management_rs.domain.CMRSEvent;
import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.domain.TaskStatus;
import org.tiaa.case_management_rs.email.EmailSender;
import org.tiaa.case_management_rs.email.EmailUtil;
import org.tiaa.case_management_rs.integration.cth.CTHPayloadJaxbMarshaller;
import org.tiaa.case_management_rs.integration.cth.events.AbstractEventProcessor;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTaskType;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.PowerImageService;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.WorkflowException;
import org.tiaa.case_management_rs.repository.CMSAuditService;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.cth.event.generated.jaxb.types.EventPayLoadInfo;
import org.tiaa.cth.event.generated.jaxb.types.EventType;
import org.tiaa.esb.partyrequest.types.AdditionalRequestIdentifier;
import org.tiaa.esb.partyrequest.types.AdditionalRequestIdentifiers;
import org.tiaa.esb.partyrequest.types.PartyRequestResponse;
import org.tiaa.esb.partyrequest.types.PayloadInfo;
import org.tiaa.esb.partyrequest.types.RequestInfo;

@Component
public class EXPAGTaskCancellationProcessor extends AbstractEventProcessor implements ApplicationContextAware {
	private static final Logger LOG = LoggerFactory.getLogger(EXPAGTaskCancellationProcessor.class);
	private Map<String, CTHPayloadJaxbMarshaller> cthPayloadJaxb2MarshallerMapByRequestType = new HashMap<String, CTHPayloadJaxbMarshaller>();
	private ApplicationContext applicationContext;
	@Autowired
	private PowerImageService powerImageService;
	@Autowired
	private EmailSender emailSender;
	@Autowired
	private CMSAuditService cmsAuditService;

	@PostConstruct
	public void init() {
		for (CTHPayloadJaxbMarshaller cthPayloadJaxbMarshaller : applicationContext.getBeansOfType(CTHPayloadJaxbMarshaller.class).values()) {
			EXPAGTaskType annotation = cthPayloadJaxbMarshaller.getClass().getAnnotation(EXPAGTaskType.class);
			cthPayloadJaxb2MarshallerMapByRequestType.put(annotation.requestType(), cthPayloadJaxbMarshaller);
		}
	}

	public void process(final EventType event, String orchestrationId) {
		String taskId = ExceptionHandler.callSafe(new Callable<String>() {
			@Override
			public String call() {
				return getTaskId(event);
			}
		});
		LOG.debug("taskId:{}", taskId);
		if (CommonUtil.isNullOrEmpty(taskId)) {
			LOG.warn("Task Id is null or empty for orchestrationId:{}", orchestrationId);
			cmsAuditService.createAndSaveCMSAuditHistoryForCTHCancelEvent(orchestrationId, AppConstants.TASK_ID_NOT_AVAILABLE_IN_CTH_AT_THE_TIME_OF_CANCELLATION);
			return;
		}
		TaskInfo taskInfo = createTaskInfo(event, taskId);
		//
		CMSAuditHistory cmsAuditHistory = cmsAuditService.createCMSAuditHistory(taskInfo, true);
		cmsAuditHistory.setEvent(CMRSEvent.EXPAG_CANCEL_TASK);
		try {
			powerImageService.cancelTask(taskId);
			cmsAuditService.markAsSuccessful(cmsAuditHistory);
		} catch (WorkflowException e) {
			LOG.warn(e.getMessage(), e);
			cmsAuditService.markAsFailed(cmsAuditHistory, e);
			emailSender.sendEmailToProdSupport("Error while updating CTH for Orchestration Id:" + orchestrationId, EmailUtil.createEmail(cmsAuditHistory, e));
		}
	}

	private String getTaskId(EventType event) {
		String requestType = event.getRequestType();
		LOG.debug("requestType:{}", requestType);
		EventPayLoadInfo payload = event.getPayload();
		Element retrieveRequestsResponseElement = payload.getAny();
		if (LOG.isDebugEnabled()) {
			LOG.debug("payload:{}", toString(retrieveRequestsResponseElement));
		}
		//
		DOMSource domSource = new DOMSource();
		domSource.setNode(retrieveRequestsResponseElement);
		//
		PartyRequestResponse partyRequestResponse = getPartyRequestResponse(domSource);
		String taskId = getTaskId(partyRequestResponse);
		if (taskId != null) {
			return taskId;
		}
		CTHPayloadJaxbMarshaller cthPayloadJaxbMarshaller = cthPayloadJaxb2MarshallerMapByRequestType.get(requestType);
		LOG.debug("cthPayloadJaxbMarshaller:{}", cthPayloadJaxbMarshaller);
		return getTaskId(partyRequestResponse, cthPayloadJaxbMarshaller);
	}

	private TaskInfo createTaskInfo(EventType event, String taskId) {
		XMLGregorianCalendar recievedTimeStamp = event.getRecievedTimeStamp();
		int startDate = Integer.parseInt(DateUtil.toFormat(recievedTimeStamp, "YYYYMMdd"));
		int startTime = Integer.parseInt(DateUtil.toFormat(recievedTimeStamp, "HHmmssSS"));
		//
		TaskInfo taskInfo = new TaskInfo();
		taskInfo.setTaskId(taskId);
		taskInfo.setCthOrchestrationId(event.getOrchestrationId());
		taskInfo.setTaskStatus(TaskStatus.Cancelled);
		taskInfo.setStartDate(startDate);
		taskInfo.setStartTime(startTime);
		return taskInfo;
	}

	private String getTaskId(PartyRequestResponse partyRequestResponse) {
		AdditionalRequestIdentifiers additionalRequestIdentifiers = partyRequestResponse.getAdditionalRequestIdentifiers();
		for (AdditionalRequestIdentifier additionalRequestIdentifier : additionalRequestIdentifiers.getAdditionalRequestIdentifiers()) {
			if ("WorkflowTaskID".equals(additionalRequestIdentifier.getKey())) {
				return additionalRequestIdentifier.getValue();
			}
		}
		return null;
	}

	private String getTaskId(PartyRequestResponse partyRequestResponse, CTHPayloadJaxbMarshaller cthPayloadJaxbMarshaller) {
		if (cthPayloadJaxbMarshaller == null) {
			return null;
		}
		try {
			PayloadInfo payloadInfo = partyRequestResponse.getPayloadInfo();
			RequestInfo requestInfo = payloadInfo.getRequestInfo();
			Element payload = requestInfo.getAny();
			return cthPayloadJaxbMarshaller.getTaskId(payload);
		} catch (UnmarshallingFailureException e) {
			LOG.warn(e.getMessage(), e);
		}
		return null;
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		this.applicationContext = applicationContext;
	}

	public void setPowerImageService(PowerImageService powerImageService) {
		this.powerImageService = powerImageService;
	}

}