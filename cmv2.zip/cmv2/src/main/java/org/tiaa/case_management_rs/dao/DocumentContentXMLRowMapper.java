package org.tiaa.case_management_rs.dao;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.zip.GZIPInputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.esb.case_management_rs_v2.type.Document;


public class DocumentContentXMLRowMapper extends AbstractRowMapper<Document> {

	private static final Logger LOGGER = LoggerFactory.getLogger(DocumentContentXMLRowMapper.class);
	
	@Override
	public Document mapRow(ResultSet rs, int rowNum) throws SQLException {
	     
	     Document document =new Document();
	     Blob blob = rs.getBlob("XMLDATA");
	     byte[] bytes = blob.getBytes(1L, Long.valueOf(blob.length()).intValue());
	     
	     if(null != bytes){
		     try {
					String xml = unzipByteArray(bytes);
			         document.setMimeTyp(getStringTrimmed(rs,"MIMETYPE"));
				     document.setDocContent(xml.getBytes());	     
				} catch (IOException e) {
					LOGGER.error("Error in getting XML data. " + e.getMessage());
				}	    	 
	     }


		return document;
	}
	
	 private String unzipByteArray(byte[] compressedBytes) throws IOException
	  {
		ByteArrayInputStream inputByteStream = null;
		BufferedInputStream buf = null;
		ByteArrayOutputStream outputByteStream = null;
		String ret = null;
		try
		{
			inputByteStream = new ByteArrayInputStream(compressedBytes);
			buf = new BufferedInputStream(new GZIPInputStream(inputByteStream));
			outputByteStream = new ByteArrayOutputStream();
		  
			byte[] readBuf = new byte['?'];
			int bytesRead = 0;
			while ((bytesRead = buf.read(readBuf)) > 0) {
				outputByteStream.write(readBuf, 0, bytesRead);
			}
			
		  ret = outputByteStream.toString();
		  
		}
		catch (IOException e)
		{
		  throw e;
		}
		finally
		{
			  if (inputByteStream != null) {
			    inputByteStream.close();
			  }
			  if (buf != null) {
			    buf.close();
			  }
			  if (outputByteStream != null) {
			    outputByteStream.close();
			  }
		}
		    return ret;
	  }

}

