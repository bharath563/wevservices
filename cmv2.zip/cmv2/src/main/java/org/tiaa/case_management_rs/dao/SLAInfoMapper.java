package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.case_management_rs.model.SLAInfo;
import org.tiaa.case_management_rs.utils.DateUtil;

public class SLAInfoMapper extends AbstractRowMapper<SLAInfo> implements RowMapper<SLAInfo> {

	@Override
	public SLAInfo mapRow(ResultSet rs, int rowNum) throws SQLException {

		SLAInfo slaInfo = new SLAInfo();

		long starttime = rs.getLong("starttime");
		long endtime = rs.getLong("endtime");
		long pidate = rs.getLong("pidate");
		long pienddate = 0;

		if (starttime > endtime) {
			pienddate = pidate + 1L;
		} else {
			pienddate = pidate;
		}

		slaInfo.setStartDateTime(DateUtil.parseDateTime(String.valueOf(pidate), String.valueOf(starttime)));

		slaInfo.setEndDateTime(DateUtil.parseDateTime(String.valueOf(pienddate), String.valueOf(endtime)));

		return slaInfo;
	}

}
