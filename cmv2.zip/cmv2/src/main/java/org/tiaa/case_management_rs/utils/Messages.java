package org.tiaa.case_management_rs.utils;

import java.util.Locale;

import org.springframework.context.MessageSource;

/**
 * This utility class will be used to fetch messages from application message
 * property file.
 */
public class Messages {

	/**
	 * Holds the reference to message source
	 */
	private static MessageSource messageSource = null;

	/**
	 * Setter method for messageSource
	 * 
	 * @param messageSource
	 *            the messageSource to set
	 */
	public void setMessageSource(MessageSource messageSource) {
		Messages.messageSource = messageSource;
	}

	/**
	 * This method returns the Message in the properties file based on the key
	 * for the US Locale. If the message is not found for the given key, a blank
	 * message will be returned.
	 *
	 * @param key
	 *            The key to lookup the message
	 * @return String The resolved message if the lookup was successful;
	 *         otherwise blank message
	 */
	public static String getMessage(String key) {

		String value = messageSource.getMessage(key, null, "", Locale.US);
		return value;

	}

	/**
	 * This method returns the Message in the properties file based on the key
	 * for the US Locale. The parameters in the message will be replaced using
	 * the values that are passed in object array. If the message is not found
	 * for the given key, a blank message will be returned.
	 *
	 * @param key
	 *            The key to lookup the message
	 * @param objArray
	 *            Array of arguments that will be filled in for params within
	 *            the message
	 * @return String The resolved message if the lookup was successful;
	 *         otherwise blank message
	 */
	public static String getMessage(String key, Object[] objArray) {
		return messageSource.getMessage(key, objArray, "", Locale.US);
	}

	/**
	 * This method returns the Message in the properties file based on the key
	 * and the Locale. The parameters in the message will be replaced using the
	 * values that are passed in object array. If the message is not found for
	 * the given key and Locale, a blank message will be returned.
	 *
	 * @param key
	 *            The key to lookup the message
	 * @param objArray
	 *            Array of arguments that will be filled in for params within
	 *            the message
	 * @param locale
	 *            The Locale in which to do the lookup
	 * @return String The resolved message if the lookup was successful;
	 *         otherwise blank message
	 */
	public static String getMessage(String key, Object[] objArray, Locale locale) {
		return messageSource.getMessage(key, objArray, "", locale);
	}

	/**
	 * This method returns the Message in the properties file based on the key
	 * and the Locale. The parameters in the message will be replaced using the
	 * values that are passed in object array. If the message is not found for
	 * the given key and Locale, a default message will be returned.
	 *
	 * @param key
	 *            The key to lookup the message
	 * @param objArray
	 *            Array of arguments that will be filled in for params within
	 *            the message
	 * @param locale
	 *            The Locale in which to do the lookup
	 * @param defaultMessage
	 *            String to return if the lookup fails
	 * @return String The resolved message if the lookup was successful;
	 *         otherwise the default message passed as a parameter
	 */
	public static String getMessage(String key, Object[] objArray, String defaultMessage, Locale locale) {
		return messageSource.getMessage(key, objArray, defaultMessage, locale);
	}
}
