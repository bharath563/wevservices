package org.tiaa.case_management_rs.integration.exp_ag;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class NextGenDBConfig {
	
	@Autowired
	private DataSource nextGenAppDatasource;

	@Bean
	public JdbcTemplate nextGenJdbcTemplate() {
		return new JdbcTemplate(nextGenAppDatasource);
	}

}
