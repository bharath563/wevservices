package org.tiaa.case_management_rs.integration.icm.binding;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlJavaTypeAdapter(AdditionalIdentifiersMapAdapter.class)

public class AdditionalIdentifiersMap extends HashMap {

	/**
	 *
	 */
	public List<HashMapType> entry = new ArrayList<HashMapType>();
	private static final long serialVersionUID = 1L;

}