package org.tiaa.case_management_rs.integration.cth.events;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.log4j.MDC;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.domain.CMRSEvent;
import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.integration.case_manager.cth.events.DocumentUploadProcessor;
import org.tiaa.case_management_rs.integration.exp_ag.cth.events.EXPAGTaskCancellationProcessor;
import org.tiaa.case_management_rs.repository.CMSAuditService;
import org.tiaa.cth.event.generated.jaxb.types.EventRequest;
import org.tiaa.cth.event.generated.jaxb.types.EventType;

public class CTHEventProcessor extends AbstractEventProcessor {
	private static final Logger LOG = LoggerFactory.getLogger(CTHEventProcessor.class);
	@Autowired
	private CMSAuditService cmsAuditService;
	@Autowired
	private DocumentUploadProcessor documentUploadProcessor;
	@Autowired
	private EXPAGTaskCancellationProcessor expagTaskCancellationProcessor;

	public void processEvent(EventRequest eventRequest) {
		LOG.debug("eventRequest:{}", ReflectionToStringBuilder.toString(eventRequest));
		final EventType event = eventRequest.getEvent();
		LOG.debug("event:{}", ReflectionToStringBuilder.toString(event));
		//
		String eventName = event.getEventName();
		String orchestrationId = event.getOrchestrationId();
		LOG.debug("orchestrationId:{}", orchestrationId);
		MDC.put("X-INF-RequestID", orchestrationId);
		if ("ADD_AI_LASTUPDATEDDRI".equals(eventName) || "UPDATE_AI_LASTUPDATEDDRI".equals(eventName)) {
			CMSAuditHistory cmsAuditHistory = cmsAuditService.createAndSaveCMSAuditHistoryForCTHEvent(orchestrationId, CMRSEvent.CTH_LASTUPDATEDDRI);
			documentUploadProcessor.process(eventRequest, cmsAuditHistory);
			return;
		}
		expagTaskCancellationProcessor.process(event, orchestrationId);
		MDC.remove("X-INF-RequestID");
	}

}