package org.tiaa.case_management_rs.integration.cth;

public class CTHRecordNotFoundException extends RuntimeException {

	public CTHRecordNotFoundException() {
		super();
	}

	public CTHRecordNotFoundException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public CTHRecordNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public CTHRecordNotFoundException(String message) {
		super(message);
	}

	public CTHRecordNotFoundException(Throwable cause) {
		super(cause);
	}

}
