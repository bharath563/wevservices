package org.tiaa.case_management_rs.utils;

public class FatalException extends RuntimeException {
	private static final long serialVersionUID = 3821767259500186716L;

	public FatalException() {
		super();
	}

	public FatalException(String message, Throwable cause) {
		super(message, cause);
	}

	public FatalException(String message) {
		super(message);
	}

	public FatalException(Throwable cause) {
		super(cause);
	}
}
