package org.tiaa.case_management_rs.integration.cth;

import java.util.List;

import javax.validation.ValidationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.tiaa.case_management_rs.common.AppConstants;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.partyrequest.types.AdditionalRequestIdentifier;
import org.tiaa.esb.partyrequest.types.AdditionalRequestIdentifiers;
import org.tiaa.esb.partyrequest.types.CreateHierarchyPartyRequest;
import org.tiaa.esb.partyrequest.types.CreateHierarchyPartyRequests;
import org.tiaa.esb.partyrequest.types.CreateRequests;
import org.tiaa.esb.partyrequest.types.PartyIdentifier;
import org.tiaa.esb.partyrequest.types.PartyIdentifiers;
import org.tiaa.esb.partyrequest.types.PartyReqControlInfo;
import org.tiaa.esb.partyrequest.types.PayloadInfo;
import org.tiaa.esb.partyrequest.types.YesNo;

public class CreateHierarchyPartyRequestBuilder {
	private static final Logger LOG = LoggerFactory.getLogger(CreateHierarchyPartyRequestBuilder.class);
	private PayloadInfoBuilder cthRequestBuilder;
	private boolean setServiceRequestTopic;

	public CreateRequests build(CreateCTHContext context) {
		PayloadInfo payloadInfo = cthRequestBuilder.build(context);
		//
		CreateHierarchyPartyRequest createHierarchyPartyRequest = new CreateHierarchyPartyRequest();
		createHierarchyPartyRequest.setAdditionalRequestIdentifiers(createAdditionalIdentifiers(context));
		createHierarchyPartyRequest.setPartyIdentifiers(createPartyIdentifiers(context));
		createHierarchyPartyRequest.setPartyReqControlInfo(createPartyReqControlInfo(context));
		createHierarchyPartyRequest.setPayloadInfo(payloadInfo);
		//
		CreateHierarchyPartyRequests createHierarchyPartyRequests = new CreateHierarchyPartyRequests();
		createHierarchyPartyRequests.getCreateHierarchyPartyRequests().add(createHierarchyPartyRequest);
		//
		CreateRequests createRequests = new CreateRequests();
		createRequests.setCreateHierarchyPartyRequests(createHierarchyPartyRequests);
		return createRequests;
	}

	public PartyReqControlInfo createPartyReqControlInfo(CreateCTHContext context) {
		TaskInfo taskInfo = context.getTaskInfo();
		//
		PartyReqControlInfo partyReqControlInfo = new PartyReqControlInfo();
		partyReqControlInfo.setChannel(taskInfo.getChannel());
		partyReqControlInfo.setEffectiveDate(taskInfo.getRecievedDateTimeAsXMLGregorianCalendar());
		partyReqControlInfo.setStatus(taskInfo.getCthStatus());
		partyReqControlInfo.setSubmitDateTime(DateUtil.getCurrentDate());
		partyReqControlInfo.setSystemIdentifier(taskInfo.getSystemIdentifier());
		partyReqControlInfo.setUpdatedBy(taskInfo.getUpdatedBy());
		partyReqControlInfo.setProcessType(taskInfo.getProcessType());
		partyReqControlInfo.setRequestType(taskInfo.getRequestType());
		partyReqControlInfo.setTrackingRequestIndicator(YesNo.N);
		return partyReqControlInfo;
	}

	public PartyIdentifiers createPartyIdentifiers(CreateCTHContext context) {
		TaskInfo taskInfo = context.getTaskInfo();
		//
		PartyIdentifiers partyIdentifiers = new PartyIdentifiers();
		List<PartyIdentifier> partyIdentifierList = partyIdentifiers.getPartyIdentifiers();
		LOG.debug("CustomerNumber: {}", taskInfo.getCustomerNumber());
		addPartyIdentifier(partyIdentifierList, "CustomerNumber", taskInfo.getCustomerNumber());
		if (partyIdentifierList.isEmpty()) {
			throw new ValidationException(AppConstants.CUSTOMER_NUMBER_REQUIRED);
		}
		return partyIdentifiers;
	}

	private void addPartyIdentifier(List<PartyIdentifier> partyIdentifierList, String key, String value) {
		if (!value.isEmpty()) {
			partyIdentifierList.add(createPartyIdentifier(key, value));
		}
	}

	public PartyIdentifier createPartyIdentifier(String name, String value) {
		PartyIdentifier partyIdentifier = new PartyIdentifier();
		partyIdentifier.setKey(name);
		partyIdentifier.setValue(value);
		return partyIdentifier;
	}

	public AdditionalRequestIdentifiers createAdditionalIdentifiers(CreateCTHContext context) {
		TaskInfo taskInfo = context.getTaskInfo();
		String taskType = taskInfo.getTaskType();
		//
		AdditionalRequestIdentifiers updateAdditionalRequestIdentifiers = new AdditionalRequestIdentifiers();
		List<AdditionalRequestIdentifier> additionalRequestIdentifierList = updateAdditionalRequestIdentifiers.getAdditionalRequestIdentifiers();
		//
		if (LOG.isDebugEnabled()) {
			LOG.debug("ClientID: {}", taskInfo.getClientId());
			LOG.debug("PlanNumber: {}", taskInfo.getPlanNumber());
			LOG.debug("FirstName: {}", context.getFirstName());
			LOG.debug("LastName: {}", context.getLastName());
			LOG.debug("WorkflowTaskID: {}", taskInfo.getTaskId());
			LOG.debug("TaskType: {}", taskType);
		}
		addAdditionalRequestIdentifier(additionalRequestIdentifierList, "ClientID", taskInfo.getClientId());
		addAdditionalRequestIdentifier(additionalRequestIdentifierList, "PlanNumber", taskInfo.getPlanNumber());
		addAdditionalRequestIdentifier(additionalRequestIdentifierList, "FirstName", context.getFirstName());
		addAdditionalRequestIdentifier(additionalRequestIdentifierList, "LastName", context.getLastName());
		if (setServiceRequestTopic) {
			addAdditionalRequestIdentifier(additionalRequestIdentifierList, "ServiceRequestTopic", taskInfo.getServiceRequestTopic());
		}
		addAdditionalRequestIdentifier(additionalRequestIdentifierList, "WorkflowTaskID", taskInfo.getTaskId());
		if (!taskType.isEmpty()) {
			addAdditionalRequestIdentifier(additionalRequestIdentifierList, "TaskType", taskType);
		}
		return updateAdditionalRequestIdentifiers;
	}

	private void addAdditionalRequestIdentifier(List<AdditionalRequestIdentifier> additionalRequestIdentifierList, String key, String value) {
		if (!value.isEmpty()) {
			additionalRequestIdentifierList.add(createAdditionalRequestIdentifier(key, value));
		}
	}

	public AdditionalRequestIdentifier createAdditionalRequestIdentifier(String name, String value) {
		AdditionalRequestIdentifier additionalRequestIdentifier = new AdditionalRequestIdentifier();
		additionalRequestIdentifier.setKey(name);
		additionalRequestIdentifier.setValue(value);
		return additionalRequestIdentifier;
	}

	public void setCthRequestBuilder(PayloadInfoBuilder cthRequestBuilder) {
		this.cthRequestBuilder = cthRequestBuilder;
	}
}
