package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.tiaa.esb.case_management_rs_v2.type.ConfigData;


public class PlanInfoMapper  extends LongDescCDataMapper {

	@Override
	public ConfigData mapRow(ResultSet rs, int rowNum) throws SQLException {

		ConfigData configData = super.mapRow(rs, rowNum);
		String shortDescription = null;
		shortDescription = getStringTrimmed(rs, "ShortDescription");
		if(shortDescription != null && shortDescription.length() > 0){
			configData.setShortDescription(shortDescription);
		}
		return configData;
		
	}
}