package org.tiaa.case_management_rs.common.impl;

import java.util.HashMap;
import java.util.Map;

import org.tiaa.case_management_rs.common.Response;

/**
 * Service interaction layer will use this class to get response attributes from
 * business processing layer.
 */
public class ResponseImpl implements Response {

	/**
	 * Hashmap used to store the response attributes.
	 */
	private Map<String, Object> map = new HashMap<String, Object>();

	/**
	 * This method is used to set the object in the response using the given
	 * key.
	 *
	 * @param key
	 *            Key to set the object in response
	 * @param value
	 *            Object to be added in the response
	 */
	@Override
	public void setAttribute(String key, Object value) {
		this.map.put(key, value);
	}

	/**
	 * This method is used to get an object from the response based on a key.
	 *
	 * @param aKey
	 *            Key to get the object from response
	 * @return Object Object that was stored in response for the given key; Null
	 *         if there is no object exists.
	 */
	@Override
	public Object getAttribute(String aKey) {
		return this.map.get(aKey);
	}

	@Override
	public void putAll(Map<String, Object> inputMap) {
		this.map.putAll(inputMap);
	}

	/**
	 * @return Map Process: This method returns the implementing map
	 *
	 */

	@Override
	public Map<String, Object> getMap() {
		return this.map;
	}
}
