package org.tiaa.case_management_rs.resource;

import javax.ws.rs.core.MediaType;

public class MediaTypes extends MediaType {
	private static final String BASE_STRING = "application/vnd.tiaa.case-management-rs-";
	private static final String V1_BASE_STRING = BASE_STRING + "v1.0";
	public static final String V1_XML = V1_BASE_STRING + "+xml";
	public static final MediaType V1_XML_TYPE = valueOf(V1_XML);
	public static final String V1_JSON = V1_BASE_STRING + "+json";
	public static final MediaType V1_JSON_TYPE = valueOf(V1_JSON);
	
	private static final String V2_BASE_STRING = BASE_STRING + "v2.0";
	public static final String V2_XML = V2_BASE_STRING + "+xml";
	public static final MediaType V2_XML_TYPE = valueOf(V2_XML);
	public static final String V2_JSON = V2_BASE_STRING + "+json";
	public static final MediaType V2_JSON_TYPE = valueOf(V2_JSON);
}