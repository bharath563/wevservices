package org.tiaa.case_management_rs.resource;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.container.ResourceContext;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.common.impl.RequestImpl;
import org.tiaa.case_management_rs.service.CaseManagementRestService;
import org.tiaa.esb.case_management_rs_v2.type.ProcessesRequest;

@Path("/processes")
public class WorkItemsResource {

	private static final Logger LOGGER = LoggerFactory.getLogger(WorkItemsResource.class);

	@Context
	private ResourceContext resourceContext;

	@Autowired
	private CaseManagementRestService caseManagmentRestService;

	@GET
	@Produces({ MediaTypes.V2_XML, MediaTypes.V2_JSON })
	public Response getProcesses(@QueryParam(USER_ID) String userId, @QueryParam(DEPARTMENT) String department, @QueryParam(TYPE) String type, @QueryParam(APP_NAME) String appName, @QueryParam(START) String start) {

		LOGGER.debug("Entering getProcesses");
		LOGGER.debug("Request Params");
		LOGGER.debug(USER_ID + SPACE_HYPEN_SAPCE + userId);
		LOGGER.debug(DEPARTMENT + SPACE_HYPEN_SAPCE + department);

		Response response = null;
		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		// Get all the request parameter string values
		request.setAttribute(USER_ID, userId);
		request.setAttribute(DEPARTMENT, department);
		request.setAttribute(TYPE, type);
		request.setAttribute(APP_NAME, appName);
		request.setAttribute(START, start);
		response = this.caseManagmentRestService.getProcesses(request);

		LOGGER.debug("Exiting getProcesses");

		return response;
	}
	
	
	
	
	@POST
	@Produces({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	@Consumes({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	public Response createProcesses(@QueryParam(USER_ID) String userId,@QueryParam(APP_NAME) String appName, ProcessesRequest processesRequest) {

		LOGGER.debug("Entering createProcesses");
		LOGGER.debug("Request Params");
		LOGGER.debug(USER_ID + SPACE_HYPEN_SAPCE + userId);

		Response response = null;
		org.tiaa.case_management_rs.common.Request request = new RequestImpl();

		// Get all the request parameter string values
		request.setAttribute(USER_ID, userId);
		request.setAttribute(PROCESSES_REQUEST, processesRequest);
		request.setAttribute(APP_NAME, appName);

		response = this.caseManagmentRestService.createProcesses(request);

		LOGGER.debug("Exiting createProcesses");

		return response;

	}

	@Path("/{processid}")
	public WorkItemResource workItemsSubResource() {
		return this.resourceContext.getResource(WorkItemResource.class);
	}

	@PUT
	@Produces({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	@Consumes({MediaTypes.V2_XML, MediaTypes.V2_JSON})
	public Response updateProcesses(ProcessesRequest processesRequest, @QueryParam(USER_ID) String userId, @QueryParam(APP_NAME) String appName, @QueryParam(ACTION) String action ){
		LOGGER.debug("Entering updateProcesses");
		org.tiaa.case_management_rs.common.Request request = new RequestImpl();		
		Response response = null;
		
		request.setAttribute(USER_ID, userId);
		request.setAttribute(APP_NAME, appName);
		request.setAttribute(ACTION, action);
		request.setAttribute(PROCESSES_REQUEST, processesRequest);
		
		response = this.caseManagmentRestService.updateProcesses(request);
		
		LOGGER.debug("Exiting updateProcesses");		
		return response;
	}
	
}