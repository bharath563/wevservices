package org.tiaa.case_management_rs.email;

import org.tiaa.case_management_rs.common.PropertiesProvider;

public class EmailConfiguration {
	public static final String FROM = "email.from";
	public static final String TO = "email.to";
	public static final String HOST = "email.host";
	public static final String DISTRIBUTION_LIST_TEST_ENV = "email.test.distributionList";
	private String host;
	private String from;
	private String to;
	private String distributionList;

	public EmailConfiguration(PropertiesProvider propertiesProvider) {
		from = propertiesProvider.getProperty(FROM);
		to = propertiesProvider.getProperty(TO);
		host = propertiesProvider.getProperty(HOST);
		distributionList = propertiesProvider.getProperty(DISTRIBUTION_LIST_TEST_ENV);
	}

	public String getTo() {
		return to;
	}

	public String getFrom() {
		return from;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getDistributionList() {
		return distributionList;
	}

	public void setDistributionList(String distributionLst) {
		this.distributionList = distributionLst;
	}

	public String[] getDistributionArray() {
		return getDistributionList().split(",");
	}
	
	
}
