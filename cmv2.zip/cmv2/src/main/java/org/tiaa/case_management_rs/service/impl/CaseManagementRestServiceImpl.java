package org.tiaa.case_management_rs.service.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.sql.DataSource;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.case_management_rs.common.impl.RequestImpl;
import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.constants.ConfigItemSortBy;
import org.tiaa.case_management_rs.delegate.CaseManagementDelegate;
import org.tiaa.case_management_rs.delegate.impl.ColumnsMapping;
import org.tiaa.case_management_rs.delegate.impl.ConfigItemsSortComparator;
import org.tiaa.case_management_rs.delegate.impl.ICMAdapter;
import org.tiaa.case_management_rs.delegate.impl.SortingComparator;
import org.tiaa.case_management_rs.exception.CaseManagementRuntimeException;
import org.tiaa.case_management_rs.expag.helper.SearchHelper;
import org.tiaa.case_management_rs.icm.helper.TaskSearchHelper;
import org.tiaa.case_management_rs.service.CaseManagementRestService;
import org.tiaa.case_management_rs.support.ResponseObjectFactory;
import org.tiaa.case_management_rs.utils.ExceptionUtil;
import org.tiaa.case_management_rs.validator.BaseValidator;
import org.tiaa.case_management_rs.validator.impl.AddCommentsValidator;
import org.tiaa.case_management_rs.validator.impl.BaseValidatorImpl;
import org.tiaa.case_management_rs.validator.impl.CreateDocumentsValidator;
import org.tiaa.case_management_rs.validator.impl.CreateProcessesValidator;
import org.tiaa.case_management_rs.validator.impl.CreateReleatedTaskValidator;
import org.tiaa.case_management_rs.validator.impl.CreateTaskValidator;
import org.tiaa.case_management_rs.validator.impl.DeleteDocumentValidator;
import org.tiaa.case_management_rs.validator.impl.GetCommentsValidator;
import org.tiaa.case_management_rs.validator.impl.GetConfigItemsValidator;
import org.tiaa.case_management_rs.validator.impl.GetDocumentValidator;
import org.tiaa.case_management_rs.validator.impl.GetDocumentsValidator;
import org.tiaa.case_management_rs.validator.impl.GetProcessValidator;
import org.tiaa.case_management_rs.validator.impl.GetProcessesValidator;
import org.tiaa.case_management_rs.validator.impl.GetRelatedProcessesValidator;
import org.tiaa.case_management_rs.validator.impl.GetTaskValidator;
import org.tiaa.case_management_rs.validator.impl.GetTasksValidator;
import org.tiaa.case_management_rs.validator.impl.GetWorkItemsValidator;
import org.tiaa.case_management_rs.validator.impl.MetricsValidator;
import org.tiaa.case_management_rs.validator.impl.SearchValidator;
import org.tiaa.case_management_rs.validator.impl.TaskSearchValidator;
import org.tiaa.case_management_rs.validator.impl.UpdateDocumentValidator;
import org.tiaa.case_management_rs.validator.impl.UpdateProcessesValidator;
import org.tiaa.case_management_rs.validator.impl.UpdateTaskValidator;
import org.tiaa.esb.case_management_rs_v2.type.BPMPlatforms;
import org.tiaa.esb.case_management_rs_v2.type.Comments;
import org.tiaa.esb.case_management_rs_v2.type.CommentsResponse;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItem;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItems;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItemsResponse;
import org.tiaa.esb.case_management_rs_v2.type.Document;
import org.tiaa.esb.case_management_rs_v2.type.DocumentResponse;
import org.tiaa.esb.case_management_rs_v2.type.Documents;
import org.tiaa.esb.case_management_rs_v2.type.DocumentsResponse;
import org.tiaa.esb.case_management_rs_v2.type.Metric;
import org.tiaa.esb.case_management_rs_v2.type.Metrics;
import org.tiaa.esb.case_management_rs_v2.type.MetricsResponse;
import org.tiaa.esb.case_management_rs_v2.type.Pagination;
import org.tiaa.esb.case_management_rs_v2.type.PaginationInfo;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.ProcessResponse;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.ProcessesResponse;
import org.tiaa.esb.case_management_rs_v2.type.ResponseStatus;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;
import org.tiaa.esb.case_management_rs_v2.type.SearchResponse;
import org.tiaa.esb.case_management_rs_v2.type.Task;
import org.tiaa.esb.case_management_rs_v2.type.TaskResponse;
import org.tiaa.esb.case_management_rs_v2.type.Tasks;
import org.tiaa.esb.case_management_rs_v2.type.TasksResponse;

import org.tiaa.atom.service.support.HealthCheck;

@Service
public class CaseManagementRestServiceImpl implements CaseManagementRestService {

	private static final Logger LOGGER = LoggerFactory
			.getLogger(CaseManagementRestServiceImpl.class);

	@Autowired
	@Qualifier("expagAdapter")
	private CaseManagementDelegate caseManagementDelegate;

	@Autowired
	@Qualifier("activitiAdapter")
	private CaseManagementDelegate activitiDelegate;

	@Autowired
	private TaskSearchHelper taskSearchHelper;

	@javax.annotation.Resource(name = "appConfigs")
	private HashMap<String, CaseManagementDelegate> appConfigs;

	@Value("${search-timeout}")
	private int searchTimeOut;
	
	@Value("${maxNumberOfResults}")
	private int maxNumberOfResults;

	public HashMap<String, CaseManagementDelegate> getAppConfigs() {
		return appConfigs;
	}

	public void setAppConfigs(HashMap<String, CaseManagementDelegate> appConfigs) {
		this.appConfigs = appConfigs;
	}

	@Autowired
	private DataSource expagDataSource;

	@Autowired
	private DataSource processDataSource;

	@Autowired
	private SearchHelper searchHelper;
	
	@Value("${metrics.fieldNames}")
	private String metricFieldNames;

	@Value("${maxGetProcessesThreadPoolSize}")
	protected int maxGetProcessesThreadPoolSize;
	
	
	@Override
	public boolean isHealthy() {
		boolean isHealthy;
		isHealthy = HealthCheck.Helper.isHealthy(this.expagDataSource)
				&& HealthCheck.Helper.isHealthy(this.processDataSource);
		return isHealthy;
	}

	@Override
	public Response getProcesses(Request request) {

		Response response = null;
		Processes processes = new Processes();
		ProcessesResponse processesResponse = new ProcessesResponse();

		try {

			// Validate the request once it's received
			BaseValidator validator = new GetProcessesValidator();
			validator.validate(request);
			String appName = (String) request.getAttribute(CaseManagementConstants.APP_NAME);
			String start = (String) request.getAttribute(CaseManagementConstants.START);
			
			start = (start == null) ? "0" : start;
			
			boolean multipleICMRequests = false;
			Collection<CaseManagementDelegate> caseManagementDelegateList = new ArrayList<>();
			
			getDelegatesList(appName, caseManagementDelegateList);
			if (YES.equalsIgnoreCase(String.valueOf(request.getAttribute(CaseManagementConstants.CONVERTED_EXPAG_TASK)))) {
				// TODO: Open once BPRS is ready
				getDelegatesList(APP_ACTIVITI, caseManagementDelegateList);
			}
			if((caseManagementDelegateList.size() > 1) && (appName != null) && appName.contains(APP_ICM)
					&& (Integer.parseInt(start) > 0)){
				multipleICMRequests = true;
			}
			
			List<Callable<List<Process>>> processesReqs = new ArrayList<Callable<List<Process>>>();
			if (caseManagementDelegateList != null && caseManagementDelegateList.size() > 0) {
				for (CaseManagementDelegate cmDelegate : caseManagementDelegateList) {
					if(multipleICMRequests && cmDelegate instanceof ICMAdapter ){
						int noOfThreads = Integer.parseInt(start)/maxNumberOfResults;
						for(int i = 0; i <= noOfThreads ; i++){
							org.tiaa.case_management_rs.common.Request icmRequest = createNewRequest(
									request, i);
							ProcessesInvoker processInvoker = new ProcessesInvoker(cmDelegate, icmRequest);
							processesReqs.add(processInvoker);
						}
					}else{
						ProcessesInvoker processInvoker = new ProcessesInvoker(cmDelegate, request);
						processesReqs.add(processInvoker);
					}
				}
			}				
			
			Processes combinedResults = new Processes();
			List<Future<List<Process>>> results = null;

			ExecutorService executor = Executors.newFixedThreadPool(maxGetProcessesThreadPoolSize);
			try {

				//results = executor.invokeAll(processesReqs);
				results = executor.invokeAll(processesReqs, searchTimeOut, TimeUnit.SECONDS);

				for (Future<List<Process>> future : results) {
					List<Process> processList = null;
					try {
						if(future != null){
							processList = future.get();
						}
					} catch (CancellationException e) {
						LOGGER.error("CancellationException: "+ future.toString()+ " didnot return results within configured time");
					}catch(Exception e){
						LOGGER.error("Exception while getting processes list:" + e.getMessage());
					}
					if ((processList != null) && (!processList.isEmpty())) {
						combinedResults.getProcesses().addAll(processList);
					}
				}
			} catch (InterruptedException e) {
				LOGGER.error("InterruptedException: " + e.getMessage());
				//throw e;
			} catch (NullPointerException e) {
				LOGGER.error("NullPointerException: " + e.getMessage());
				//throw e;
			} finally {
				if (executor != null) {
					executor.shutdown();
				}
			}
			
			
			if (combinedResults != null && combinedResults.getProcesses() != null
					&& combinedResults.getProcesses().size() > 0) {
				
				List<Process> listOfProcess = combinedResults.getProcesses();
				List<Process> searchResponseList = new ArrayList<Process>();
				if((caseManagementDelegateList.size() == 1) && (appName != null) && appName.contains(APP_ICM)){
					searchResponseList = combinedResults.getProcesses();
				} else {
					String sortColumnValue = null;
					if(appName == null || APP_EXPAG.equalsIgnoreCase(appName)){
						sortColumnValue = ColumnsMapping.REQUEST_ID;
					}else {
						sortColumnValue = ColumnsMapping.CREATED_DATE;
					}
					String sortOrderValue = "DESC";
					Collections.sort(listOfProcess, new SortingComparator(sortOrderValue, sortColumnValue));
					searchResponseList = this.searchHelper.createSearchResponseList(
							combinedResults.getProcesses(), Integer.parseInt(start));				
				}
				
				processes.getProcesses().addAll(searchResponseList);
			}
		
			if ((processes.getProcesses() != null)) {
				processesResponse = ResponseObjectFactory.createProcessesResponse(SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				processesResponse.setProcesses(processes);
			} else {
				processesResponse = ResponseObjectFactory.createProcessesResponse(FAILURE, FAILURE_TEXT);
			}
			response = Response.ok(processesResponse).build();
	
		} catch (Exception exception) {

			LOGGER.error("ProcessesError - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			processesResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, processesResponse);
		}

		return response;
	}

	private Collection<CaseManagementDelegate> getDelegatesList(String appName, Collection<CaseManagementDelegate> caseManagementDelegateList) {
		
		
		if (appName == null) {
			caseManagementDelegateList.add(caseManagementDelegate);
		}else{
			
			String[] appNames = null;
			if(appName.contains("|")){
				appNames = appName.split("\\|");
				
			}else{
				appNames = new String[1];
				appNames[0] = appName;
			}
			
			for(String appNameReq : appNames){
				HashMap<String, CaseManagementDelegate> configApps = getAppConfigs();
				LOGGER.info("Calling Delegate for App Name" + appNameReq);
				CaseManagementDelegate cmDelegate = configApps.get(appNameReq.toLowerCase());
				caseManagementDelegateList.add(cmDelegate);
			}
			
		}
		return caseManagementDelegateList;
	}

	private org.tiaa.case_management_rs.common.Request createNewRequest(
			Request request, int i) {
		org.tiaa.case_management_rs.common.Request icmRequest = new RequestImpl();
		icmRequest.setAttribute(USER_ID, request.getAttribute(USER_ID));
		icmRequest.setAttribute(DEPARTMENT, request.getAttribute(DEPARTMENT));
		icmRequest.setAttribute(TYPE, request.getAttribute(TYPE));
		icmRequest.setAttribute(APP_NAME, APP_ICM);
		icmRequest.setAttribute(START, String.valueOf(i*1000));
		return icmRequest;
	}

	@Override
	public Response getProcess(Request request) {

		Response response = null;

		Process process = new Process();
		ProcessResponse processResponse = new ProcessResponse();

		try {

			// Validate the request once it's received
			BaseValidator validator = new GetProcessValidator();
			validator.validate(request);

			CaseManagementDelegate delegate = getCmDelegate(request);
			process = delegate.getProcess(request);

			if ((process != null)) {
				processResponse = ResponseObjectFactory.createProcessResponse(
						SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				processResponse.setProcess(process);

			} else {
				processResponse = ResponseObjectFactory.createProcessResponse(
						FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(processResponse).build();
		} catch (Exception exception) {

			LOGGER.error("ProcessError - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			processResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, processResponse);
		}

		return response;

	}

	@Override
	public Response getHistory(Request request) {

		Response response = null;

		Process process = new Process();
		ProcessResponse processResponse = new ProcessResponse();

		try {

			// Validate the request once it's received
			BaseValidator validator = new GetProcessValidator();
			validator.validate(request);

			CaseManagementDelegate delegate = getCmDelegate(request);
			process = delegate.getHistory(request);

			if ((process != null)) {
				processResponse = ResponseObjectFactory.createProcessResponse(
						SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				processResponse.setProcess(process);

			} else {
				processResponse = ResponseObjectFactory.createProcessResponse(
						FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(processResponse).build();
		} catch (Exception exception) {

			LOGGER.error("ProcessError - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			processResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, processResponse);
		}

		return response;

	}

	@Override
	public Response getDocument(Request request) {

		Response response = null;

		Document document = new Document();
		DocumentResponse documentResponse = new DocumentResponse();

		try {

			// Validate the request once it's received
			BaseValidator validator = new GetDocumentValidator();
			validator.validate(request);

			CaseManagementDelegate delegate = getCmDelegate(request);
			document = delegate.getDocument(request);
			if ((document != null)) {
				documentResponse = ResponseObjectFactory
						.createDocumentResponse(SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				documentResponse.setDocument(document);

			} else {
				documentResponse = ResponseObjectFactory
						.createDocumentResponse(FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(documentResponse).build();

		} catch (Exception exception) {

			LOGGER.error("GetDocument - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			documentResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, documentResponse);
		}

		return response;

	}

	@Override
	public Response createDocument(Request request) {

		Response response = null;

		Document document = new Document();
		DocumentResponse documentResponse = new DocumentResponse();

		try {

			// Validate the request once it's received
			BaseValidator validator = new GetDocumentValidator();
			validator.validate(request);
			CaseManagementDelegate delegate = getCmDelegate(request);
			document = delegate.createDocument(request);

			if ((document != null)) {
				documentResponse = ResponseObjectFactory
						.createDocumentResponse(SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				documentResponse.setDocument(document);

			} else {
				documentResponse = ResponseObjectFactory
						.createDocumentResponse(FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(documentResponse).build();

		} catch (Exception exception) {

			LOGGER.error("CreateDocument - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			documentResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, documentResponse);
		}

		return response;
	}

	@Override
	public Response createDocuments(Request request) {

		Response response = null;

		Documents documents = null;
		DocumentsResponse documentsResponse = new DocumentsResponse();

		try {

			// Validate the request once it's received
			BaseValidator validator = new CreateDocumentsValidator();
			validator.validate(request);
			CaseManagementDelegate delegate = getCmDelegate(request);
			documents = delegate.createDocuments(request);
			if ((documents != null)) {
				documentsResponse = ResponseObjectFactory
						.createDocumentsResponse(SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				documentsResponse.setDocs(documents);

			} else {
				documentsResponse = ResponseObjectFactory
						.createDocumentsResponse(FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(documentsResponse).build();

		} catch (Exception exception) {

			LOGGER.error("CreateDocuments - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			documentsResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, documentsResponse);
		}

		return response;
	}

	@Override
	public Response getDocuments(Request request) {

		Response response = null;

		Documents documents = new Documents();
		DocumentsResponse documentsResponse = new DocumentsResponse();

		try {

			// Validate the request once it's received
			BaseValidator validator = new GetDocumentsValidator();
			validator.validate(request);

			CaseManagementDelegate delegate = getCmDelegate(request);
			if (delegate != null) {
				documents = delegate.getDocuments(request);
			}

			if ((documents != null)) {
				documentsResponse = ResponseObjectFactory
						.createDocumentsResponse(SUCCESS, SUCCESS_TEXT);
				documentsResponse.setDocs(documents);
			} else {
				documentsResponse = ResponseObjectFactory
						.createDocumentsResponse(FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(documentsResponse).build();
		} catch (Exception exception) {
			LOGGER.error("GetDocuments - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			documentsResponse.setResponseStatus(responseStatus);
			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, documentsResponse);
		}
		return response;
	}

	@Override
	public Response createProcess(Request request) {
		Response response = null;

		Process process = new Process();
		ProcessResponse processResponse = new ProcessResponse();

		try {

			// Validate the request once its received
			BaseValidator validator = new GetProcessValidator();
			validator.validate(request);

			process = this.caseManagementDelegate.createProcess(request);

			if ((process != null)) {
				processResponse = ResponseObjectFactory.createProcessResponse(
						SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				processResponse.setProcess(process);

			} else {
				processResponse = ResponseObjectFactory.createProcessResponse(
						FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(processResponse).build();

		} catch (Exception exception) {

			LOGGER.error(
					"CreateWorkItemError - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			processResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, processResponse);
		}

		return response;
	}

	@Override
	public Response createProcesses(Request request) {
		Response response = null;

		Processes processes = new Processes();
		ProcessesResponse processesResponse = new ProcessesResponse();
		try {
			// 1. Validate the ProcessesRequest
			BaseValidator validator = new CreateProcessesValidator();
			validator.validate(request);

			// 2. Navigate the request to the proper delegate(EXPAG or ACTIVITI)
			// based on the appName
			CaseManagementDelegate delegate = getCmDelegate(request);
			if (delegate == null) {
				LOGGER.error("No CaseManagementDelegate found to further process the request for the application name - "
						+ request.getAttribute(APP_NAME));
				processesResponse = ResponseObjectFactory
						.createProcessesResponse(FAILURE, FAILURE_TEXT);
				response = Response.ok(processesResponse).build();
				return response;
			}

			LOGGER.debug("Navigating the request to - " + delegate);
			processes = delegate.createProcesses(request);

			if ((processes != null)) {
				processesResponse = ResponseObjectFactory
						.createProcessesResponse(SUCCESS, SUCCESS_TEXT);
				processesResponse.setProcesses(processes);
			} else {
				LOGGER.error("Error occured, no processes created ");
				processesResponse = ResponseObjectFactory
						.createProcessesResponse(FAILURE, FAILURE_TEXT);
			}
			response = Response.ok(processesResponse).build();
		} catch (CaseManagementRuntimeException exception) {
			LOGGER.error("createProcesses - error:>>" + exception.getMessage(), exception);
			ResponseStatus responseStatus = ExceptionUtil.createESBResponseStatus(exception);
			processesResponse.setResponseStatus(responseStatus);
			response = ResponseObjectFactory.createResponseStatus(responseStatus, processesResponse);
		} catch (Exception exception) {

			LOGGER.error("createProcesses - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			processesResponse.setResponseStatus(responseStatus);
			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, processesResponse);
		}

		return response;
	}

	@Override
	public Response updateProcess(Request request) {

		Response response = null;

		ProcessResponse processResponse = new ProcessResponse();

		try {

			// Validate the request once its received
			BaseValidator validator = new GetWorkItemsValidator();
			validator.validate(request);

			CaseManagementDelegate delegate = getCmDelegate(request);
			Process process = delegate.updateProcess(request);
			// Process process =
			// this.caseManagementDelegate.updateProcess(request);
			processResponse = ResponseObjectFactory.createProcessResponse(
					SUCCESS, SUCCESS_TEXT);
			processResponse.setProcess(process);
			response = Response.ok(processResponse).build();

		} catch (Exception exception) {

			LOGGER.error(
					"UpdateWorkItemError - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			processResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, processResponse);
		}

		return response;
	}

	@Override
	public Response getConfigItems(Request request) {

		Response response = null;

		ConfigItems configItems = new ConfigItems();

		ConfigItemsResponse configItemsResponse = new ConfigItemsResponse();

		try {

			// Validate the request once it's received
			BaseValidator validator = new GetConfigItemsValidator();
			validator.validate(request);

			String property = (String) request.getAttribute(PROPERTY);

			if (request.getAttribute(APP_NAME) != null) {
				CaseManagementDelegate delegate = getCmDelegate(request);
				configItems = delegate.getConfigItems(request);
			} else {
				//gets config items from EXPAGAdapter
				configItems = this.caseManagementDelegate
						.getConfigItems(request);
			
				ConfigItems activitiConfigItems = null;
				if (DEPARTMENT.equalsIgnoreCase(property)
						|| REQUEST_TYPES.equalsIgnoreCase(property)
						|| IDENTIFIERS.equalsIgnoreCase(property)
						|| ENTITLED_DEPARTMENTS.equalsIgnoreCase(property)) {
					LOGGER.info("Invoking Activiti for config call:"+ property);
					activitiConfigItems = this.activitiDelegate
							.getConfigItems(request);
					LOGGER.info("Got response Activiti for config call:"+ property);
					if (activitiConfigItems != null
							&& activitiConfigItems.getConfigItems().size() > 0
							&& activitiConfigItems.getConfigItems().get(0) != null) {
						
						if (ENTITLED_DEPARTMENTS.equalsIgnoreCase(property)){
							ConfigItem configItemActiviti = new ConfigItem();
							configItemActiviti.setItemName(APP_ACTIVITI);
							
							configItemActiviti.getDataPairs().addAll(activitiConfigItems.getConfigItems().get(0).getDataPairs());
							configItems.getConfigItems().add(configItemActiviti);
						} else if(configItems.getConfigItems() != null && configItems.getConfigItems().size() > 0){
							configItems.getConfigItems().get(0).getDataPairs().addAll(activitiConfigItems.getConfigItems().get(0).getDataPairs());
						}
						List<ConfigData> dataPairsList = configItems.getConfigItems().get(0).getDataPairs();
						
						if(dataPairsList.size() > 0){
							if(IDENTIFIERS.equalsIgnoreCase(property)){
									Collections.sort(dataPairsList, new ConfigItemsSortComparator(ConfigItemSortBy.LONG.value()));
							} else {
								Collections.sort(dataPairsList,new ConfigItemsSortComparator(ConfigItemSortBy.SHORT.value()));
							}
						}
					}
				}
			}

			if (configItems != null) {
				configItemsResponse = ResponseObjectFactory
						.createConfigItemResponse(SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				configItemsResponse.setConfigItems(configItems);

			} else {
				configItemsResponse = ResponseObjectFactory
						.createConfigItemResponse(FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(configItemsResponse).build();

		} catch (Exception exception) {

			LOGGER.error("GetConfigItem - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			configItemsResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, configItemsResponse);
		}

		return response;
	}

	@Override
	public Response doSearch(Request request, String databaseSearchFlag) {

		Response response = null;
		SearchResponse searchResponse = new SearchResponse();

		try {

			// Validate the request once it's received
			BaseValidator validator = new SearchValidator();
			validator.validate(request);

			HashMap<String, CaseManagementDelegate> configApps = getAppConfigs();

			SearchRequest searchRequest = (SearchRequest) request
					.getAttribute(SEARCH_REQUEST);
			int start = 0;
			if (searchRequest.getPaginationInfo() != null
					&& searchRequest.getPaginationInfo().getPagination() != null
					&& searchRequest.getPaginationInfo().getPagination()
					.getStartOffset() != null) {
				start = searchRequest.getPaginationInfo().getPagination()
						.getStartOffset().intValue();
			}

			List<Callable<List<Process>>> searchCases = new ArrayList<Callable<List<Process>>>();
			BPMPlatforms bpmPlatforms = searchRequest.getBPMPlatforms();

			if (bpmPlatforms != null && bpmPlatforms.getBPMPlatforms() != null
					&& bpmPlatforms.getBPMPlatforms().size() > 0) {
				List<String> bpmPlatformList = bpmPlatforms.getBPMPlatforms();
				for (String bpmPlatform : bpmPlatformList) {
					SearchInvoker searchInvoker = new SearchInvoker(
							configApps.get(bpmPlatform.toLowerCase()), request);
					searchCases.add(searchInvoker);
				}
			} else {
				Collection<CaseManagementDelegate> caseManagementDelegateList = configApps
						.values();

				if (caseManagementDelegateList != null) {
					for (CaseManagementDelegate cmDelegate : caseManagementDelegateList) {
						SearchInvoker searchInvoker = new SearchInvoker(
								cmDelegate, request);
						searchCases.add(searchInvoker);
					}
				}
			}

			Processes combinedSearchResults = new Processes();

			List<Future<List<Process>>> results = null;

			ExecutorService executor = Executors.newFixedThreadPool(searchCases
					.size());
			try {

				results = executor.invokeAll(searchCases);

				// We will implement timeout functionality in future.
				// results =
				// executor.invokeAll(searchCases,searchTimeOut,TimeUnit.SECONDS);

				for (Future<List<Process>> future : results) {
					List<Process> processList = null;
					try {
						if(future != null){
							processList = future.get();
						}
					} catch (CancellationException e) {
						LOGGER.error("CancellationException: "
								+ future.toString()
								+ " didnot return results within configured time");
					}
					if ((processList != null) && (!processList.isEmpty())) {
						combinedSearchResults.getProcesses()
						.addAll(processList);
					}
				}
			} catch (InterruptedException e) {
				LOGGER.error("InterruptedException: " + e.getMessage());
				throw e;
			} catch (NullPointerException e) {
				LOGGER.error("NullPointerException: " + e.getMessage());
				throw e;
			} finally {
				if (executor != null) {
					executor.shutdown();
				}
			}

			if (combinedSearchResults != null
					&& combinedSearchResults.getProcesses() != null
					&& combinedSearchResults.getProcesses().size() > 1) {
				List<Process> listOfProcess = combinedSearchResults
						.getProcesses();
				String sortColumnValue = this.searchHelper
						.getSortFieldValue(searchRequest);
				String sortOrderValue = this.searchHelper
						.getSortOrderValue(searchRequest);
				Collections.sort(listOfProcess, new SortingComparator(
						sortOrderValue, sortColumnValue));
			}
			Pagination pagination = new Pagination();
			PaginationInfo paginationInfo = new PaginationInfo();

			pagination.setPageSize(Integer.toString(combinedSearchResults
					.getProcesses().size()));
			List<Process> searchResponseList = this.searchHelper
					.createSearchResponseList(
							combinedSearchResults.getProcesses(), start);
			pagination.setTotalCount(BigInteger.valueOf(searchResponseList
					.size()));
			paginationInfo.setPagination(pagination);

			Processes responseListForSearch = new Processes();
			responseListForSearch.getProcesses().addAll(searchResponseList);
			responseListForSearch.setPaginationInfo(paginationInfo);

			if (responseListForSearch.getProcesses() != null) {
				searchResponse = ResponseObjectFactory.createSearchResponse(
						SUCCESS, SUCCESS_TEXT);
				searchResponse.setProcesses(responseListForSearch);
				searchResponse.setPaginationInfo(responseListForSearch
						.getPaginationInfo());
			} else {
				searchResponse = ResponseObjectFactory.createSearchResponse(
						FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(searchResponse).build();

		} catch (Exception exception) {

			if ((exception != null) && (exception.getMessage() != null)) {
				LOGGER.error("doSearch - error:>>" + exception.getMessage(),
						exception);
				ResponseStatus responseStatus = ExceptionUtil
						.createESBResponseStatus(exception);
				searchResponse.setResponseStatus(responseStatus);
				response = ResponseObjectFactory.createResponseStatus(
						responseStatus, searchResponse);
			} else {
				searchResponse = ResponseObjectFactory.createSearchResponse(
						FAILURE, FAILURE_TEXT);
				response = Response.ok(searchResponse).build();
			}

		}

		return response;
	}

	@Override
	public Response getMetrics(Request request) {
		//CaseManagementDelegate delegate = null;
		Response response = null;
		MetricsResponse metricsResponse = null;

		try {

			// Validate the request once it's received
			BaseValidator validator = new MetricsValidator();
			validator.validate(request);
			Metrics metrics = new Metrics();
			
			String appName = (String) request.getAttribute(CaseManagementConstants.APP_NAME);
			
			Collection<CaseManagementDelegate> caseManagementDelegateList = new ArrayList<>();
			
			getDelegatesList(appName, caseManagementDelegateList);
			
			List<String> metricTypes = Arrays.asList(metricFieldNames.split(","));
			for(String metricName: metricTypes){
				Metric initialMetric = new Metric();
				initialMetric.setFieldName(metricName);
				initialMetric.setFieldValue(String.valueOf(0));
				metrics.getMetrics().add(initialMetric);
			}
			for (CaseManagementDelegate delegate : caseManagementDelegateList) {
				
				Metrics metricsOfAnApp = delegate.getMetrics(request);
				List<Metric> appMetrics = metricsOfAnApp.getMetrics();
				List<Metric> metricsList = metrics.getMetrics();
					for(Metric appMetric : appMetrics){
						for(Metric metric : metricsList){
							if(metric.getFieldName().equalsIgnoreCase(appMetric.getFieldName())
									|| (metric.getFieldName().equalsIgnoreCase("Suspended") && appMetric.getFieldName().equalsIgnoreCase("Pended"))
									|| 	(metric.getFieldName().equalsIgnoreCase("Assigned") && appMetric.getFieldName().equalsIgnoreCase("AllAssigned"))){
								LOGGER.debug("delegate:" + delegate.toString()
										+ ",appMetric.getFieldName():" + appMetric.getFieldName()
										+ ",appMetric.getFieldValue():" + appMetric.getFieldValue()
										+ "existing metric:" + metric.getFieldValue());
								metric.setFieldValue(String.valueOf(Integer.parseInt(metric.getFieldValue()) + Integer.parseInt(appMetric.getFieldValue())));  
							}
						}
						
					}
			}
			
			
			/*	delegate = getCmDelegate(request);
			if (delegate != null) {
				metrics = delegate.getMetrics(request);
			}
			
			String solutionName = (String) request.getAttribute(SOLUTION_NAME);

			String FILED_SIZE="0";
			// 2. get the Metrics from Activiti Adapter also, for the Solution -
			// "Payout Operations"- FOR MOMM RIPC
			if (DEPARTMENT_PAYOUT_OPERATIONS.equalsIgnoreCase(solutionName)) {
				delegate = this.activitiDelegate;
				Metrics actiMetrics = delegate.getMetrics(request);

				// Combine the metrics count
				if (actiMetrics != null && actiMetrics.getMetrics().size() > 0) {
					if (metrics != null && metrics.getMetrics().size() > 0) {
						
						String[] fieldNames = metricFieldNames.split(",");
						Metrics initiallMetrics = new Metrics();
						
						for(String fldName : fieldNames){
							Metric metric = new Metric();
							metric.setFieldName(fldName);
							metric.setFieldValue(FILED_SIZE);
							initiallMetrics.getMetrics().add(metric);
						}
						
						setMetricFields(initiallMetrics,metrics);
						setMetricFields(initiallMetrics,actiMetrics);
						
						metrics = initiallMetrics;
						
					} else {
						metrics.getMetrics().addAll(actiMetrics.getMetrics());
					}
				}
			}*/

			if (metrics != null) {
				metricsResponse = ResponseObjectFactory.createMetricsResponse(
						SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				metricsResponse.setMetrics(metrics);
			} else {
				metricsResponse = ResponseObjectFactory.createMetricsResponse(
						FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(metricsResponse).build();

		} catch (Exception exception) {

			metricsResponse = new MetricsResponse();

			if ((exception != null) && (exception.getMessage() != null)) {
				LOGGER.error("getMetrics - error:>>" + exception.getMessage(),
						exception);
				ResponseStatus responseStatus = ExceptionUtil
						.createESBResponseStatus(exception);
				metricsResponse.setResponseStatus(responseStatus);
				response = ResponseObjectFactory.createResponseStatus(
						responseStatus, metricsResponse);
			} else {
				metricsResponse = ResponseObjectFactory.createMetricsResponse(
						FAILURE, FAILURE_TEXT);
				response = Response.ok(metricsResponse).build();
			}

		}

		return response;
	}
	
	private void setMetricFields(Metrics initialMet, Metrics delegMet){
		
		for(Metric iniMetric :initialMet.getMetrics()){
			for(Metric delgMetric :delegMet.getMetrics()){
					
			if(iniMetric.getFieldName().equalsIgnoreCase(delgMetric.getFieldName())) {
				
				Integer totalVal = Integer.valueOf(iniMetric.getFieldValue())+Integer.valueOf(delgMetric.getFieldValue());
				iniMetric.setFieldValue(String.valueOf(totalVal.intValue()));
				break;
				
				}
			}
		}
	}	

	@Override
	public Response createRelatedTask(Request request) {
		Response response = null;

		Process process = new Process();
		ProcessResponse processResponse = new ProcessResponse();

		try {

			// Validate the request once its received
			BaseValidator validator = new CreateReleatedTaskValidator();
			validator.validate(request);

			// Conversion changes
			// process = this.caseManagementDelegate.createRelatedTask(request);

			CaseManagementDelegate delegate = getCmDelegate(request);
			process = delegate.createRelatedTask(request);

			if ((process != null)) {
				processResponse = ResponseObjectFactory.createProcessResponse(
						SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				processResponse.setProcess(process);
			} else {
				processResponse = ResponseObjectFactory.createProcessResponse(
						FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(processResponse).build();

		} catch (Exception exception) {

			LOGGER.error(
					"createRelatedTask - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			processResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, processResponse);
		}

		return response;
	}

	@Override
	public Response getTasks(Request request) {
		Response response = null;

		TasksResponse tasksResponse = new TasksResponse();
		Tasks tasks = new Tasks();

		try {

			// Validate the request once its received
			BaseValidator validator = new GetTasksValidator();
			validator.validate(request);
			CaseManagementDelegate delegate;
			delegate = getCmDelegate(request);
			tasks = delegate.getTasks(request);

			if ((tasks != null)) {
				tasksResponse = ResponseObjectFactory.createTasksResponse(
						SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				tasksResponse.setTasks(tasks);
			} else {
				tasksResponse = ResponseObjectFactory.createTasksResponse(
						FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(tasksResponse).build();

		} catch (Exception exception) {

			LOGGER.error("getTasks - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			tasksResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, tasksResponse);
		}

		return response;
	}

	@Override
	public Response getComments(Request request) {
		Response response = null;

		CommentsResponse commentsResponse = new CommentsResponse();
		Comments comments = new Comments();

		try {

			// Validate the request once its received
			BaseValidator validator = new GetCommentsValidator();
			validator.validate(request);
			CaseManagementDelegate delegate = getCmDelegate(request);
			comments = delegate.getComments(request);

			if (comments != null) {
				commentsResponse = ResponseObjectFactory
						.createCommentsResponse(SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				commentsResponse.setComments(comments);
			} else {
				commentsResponse = ResponseObjectFactory
						.createCommentsResponse(FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(commentsResponse).build();

		} catch (Exception exception) {

			LOGGER.error("getComments - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			commentsResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, commentsResponse);
		}

		return response;
	}

	@Override
	public Response addComment(Request request) {
		CommentsResponse commentsResponse = null;
		Response response = null;
		Comments comments = new Comments();

		try {
			BaseValidator validator = new AddCommentsValidator();
			validator.validate(request);

			CaseManagementDelegate delegate = getCmDelegate(request);
			comments = delegate.addComment(request);

			if (comments != null) {
				commentsResponse = ResponseObjectFactory
						.createCommentsResponse(SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				commentsResponse.setComments(comments);
			} else {
				commentsResponse = ResponseObjectFactory
						.createCommentsResponse(FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(commentsResponse).build();

		} catch (Exception exception) {

			LOGGER.error("getComments - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			commentsResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, commentsResponse);
		}

		return response;
	}

	@Override
	public Response updateProcesses(Request request) {
		Response response = null;
		Processes processes = null;
		ProcessesResponse processesResponse = new ProcessesResponse();
		try {
			BaseValidator validator = new UpdateProcessesValidator();
			validator.validate(request);

			CaseManagementDelegate delegate = null;
			
			String appName = (String) request.getAttribute(CaseManagementConstants.APP_NAME);
			
			if (appName == null) {
				delegate = this.caseManagementDelegate;
			} else {
				delegate = getCmDelegate(request);
			} 
			if(delegate != null){
				processes = delegate.updateProcesses(request);
			}

			if (processes != null) {
				processesResponse = ResponseObjectFactory
						.createProcessesResponse(SUCCESS, SUCCESS_TEXT);
				processesResponse.setProcesses(processes);

			} else {
				processesResponse = ResponseObjectFactory
						.createProcessesResponse(FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(processesResponse).build();

		} catch (Exception exception) {

			LOGGER.error("createProcesses - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			processesResponse.setResponseStatus(responseStatus);
			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, processesResponse);

		}
		return response;
	}

	/*
	 * @Override public Response getTaskComments(Request request) { Response
	 * response = null;
	 *
	 * CommentsResponse taskCommentsResponse = new CommentsResponse(); Comments
	 * comments = new Comments();
	 *
	 * try {
	 *
	 * // Validate the request once its received BaseValidator validator = new
	 * GetCommentsValidator(); validator.validate(request);
	 *
	 * String appName=(String) request.getAttribute(APP_NAME);
	 * comments=appConfigs.get(appName).getTaskComments(request); //comments =
	 * this.caseManagementDelegate.getIcmComments(request);
	 *
	 * if (comments != null) { taskCommentsResponse = ResponseObjectFactory
	 * .createCommentsResponse(SUCCESS, SUCCESS_TEXT);
	 *
	 * // Set the constructed response object value for return
	 * taskCommentsResponse.setComments(comments); } else { taskCommentsResponse
	 * = ResponseObjectFactory .createCommentsResponse(FAILURE, FAILURE_TEXT); }
	 *
	 * response = Response.ok(taskCommentsResponse).build();
	 *
	 * } catch (Exception exception) {
	 *
	 * LOGGER.error("getComments - error:>>" + exception.getMessage(),
	 * exception); ResponseStatus responseStatus = ExceptionUtil
	 * .createESBResponseStatus(exception);
	 * taskCommentsResponse.setResponseStatus(responseStatus);
	 *
	 * response = ResponseObjectFactory.createResponseStatus( responseStatus,
	 * taskCommentsResponse); }
	 *
	 * return response; }
	 */

	/*
	 * @Override public Response getTaskById(Request request) { // TODO
	 * Auto-generated method stub return null; }
	 */

	@Override
	public Response getTaskById(Request request) {
		Response response = null;

		TaskResponse taskResponse = new TaskResponse();
		TaskResponse task = new TaskResponse();

		try {

			// Validate the request once its received
			BaseValidator validator = new GetTaskValidator();
			validator.validate(request);
			CaseManagementDelegate delegate = getCmDelegate(request);
			task = delegate.getTaskById(request);

			if ((task != null)) {
				taskResponse = ResponseObjectFactory.createTaskResponse(
						SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				taskResponse.setTask(task.getTask());
			} else {
				taskResponse = ResponseObjectFactory.createTaskResponse(
						FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(taskResponse).build();

		} catch (Exception exception) {

			LOGGER.error("getTasks - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			taskResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, taskResponse);
		}

		return response;
	}

	/*
	 * @Override public Response getTasksClaimable(Request request) { // TODO
	 * Auto-generated method stub return null; }
	 */

	@Override
	public Response getTasksClaimable(Request request) {
		Response response = null;

		ProcessesResponse processesResponse = new ProcessesResponse();
		Processes processes = new Processes();
		try {

			/*
			 * // Validate the request once its received BaseValidator validator
			 * = new GetTasksValidator(); validator.validate(request);
			 */

			CaseManagementDelegate delegate = getCmDelegate(request);
			processes = delegate.getTasksClaimable(request);
			// tasks = this.caseManagementDelegate.getTasks(request);

			if ((processes != null)) {
				processesResponse = ResponseObjectFactory
						.createProcessesResponse(SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				processesResponse.setProcesses(processes);
			} else {
				processesResponse = ResponseObjectFactory
						.createProcessesResponse(FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(processesResponse).build();

		} catch (Exception exception) {

			LOGGER.error("ProcessesError - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			processesResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, processesResponse);

		}

		return response;

	}

	private CaseManagementDelegate getCmDelegate(Request request) {
		HashMap<String, CaseManagementDelegate> configApps = getAppConfigs();
		String appName = (String) request.getAttribute(APP_NAME);
		LOGGER.info("Calling Delegate for App Name" + appName);
		CaseManagementDelegate cmDelegate = configApps.get(appName
				.toLowerCase());
		return cmDelegate;
	}

	private class SearchInvoker implements Callable<List<Process>> {
		private CaseManagementDelegate caseManagementDelegate;
		private Request request;

		public SearchInvoker(CaseManagementDelegate caseManagementDelegate,
				Request request) {
			this.caseManagementDelegate = caseManagementDelegate;
			this.request = request;
		}

		@Override
		public List<Process> call() throws Exception {
			LOGGER.debug("Invoking search for appName:"
					+ caseManagementDelegate.toString());
			List<Process> processList = caseManagementDelegate
					.doSearch(request).getProcesses();
			LOGGER.debug("Got " + processList.size()
					+ " results for search - appName:"
					+ caseManagementDelegate.toString());
			return processList;

		}
	}
	
	private class ProcessesInvoker implements Callable<List<Process>> {
		private CaseManagementDelegate caseManagementDelegate;
		private Request request;

		public ProcessesInvoker(CaseManagementDelegate caseManagementDelegate,
				Request request) {
			this.caseManagementDelegate = caseManagementDelegate;
			this.request = request;
		}

		@Override
		public List<Process> call() throws Exception {
			LOGGER.info("Invoking getProcesses for appName:"+ caseManagementDelegate.toString());
			List<Process> processList = caseManagementDelegate.getProcesses(request).getProcesses();
			LOGGER.info("Got " + processList.size()	+ " results for getProcesses - appName:"+ caseManagementDelegate.toString());
			return processList;

		}
	}

	@Override
	public Response updateDocument(Request request) {

		Response response = null;
		DocumentResponse documentResponse = new DocumentResponse();

		try {

			// Validate the request once it's received
			BaseValidator validator = new UpdateDocumentValidator();
			validator.validate(request);
			CaseManagementDelegate delegate = getCmDelegate(request);

			delegate.updateDocument(request);
			documentResponse = ResponseObjectFactory.createDocumentResponse(
					SUCCESS, SUCCESS_TEXT);
			response = Response.ok(documentResponse).build();

		} catch (Exception exception) {

			LOGGER.error("UpdateDocument - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			documentResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, documentResponse);
		}

		return response;
	}

	@Override
	public Response getRelatedProcesses(Request request) {
		Response response = null;

		ProcessResponse processResponse = new ProcessResponse();
		Process process = new Process();
		try {

			BaseValidator validator = new GetRelatedProcessesValidator();
			validator.validate(request);

			CaseManagementDelegate delegate = getCmDelegate(request);
			if (delegate != null) {
				process = delegate.getRelatedProcesses(request);
			}
			if ((process != null)) {
				processResponse = ResponseObjectFactory.createProcessResponse(
						SUCCESS, SUCCESS_TEXT);
				processResponse.setProcess(process);
			} else {
				processResponse = ResponseObjectFactory.createProcessResponse(
						FAILURE, FAILURE_TEXT);
			}
			response = Response.ok(processResponse).build();
		} catch (Exception exception) {
			LOGGER.error("GetRelatedProcesses - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			processResponse.setResponseStatus(responseStatus);
			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, processResponse);
		}
		return response;
	}

	@Override
	public Response updateTask(Request request) {
		TaskResponse taskResponse = new TaskResponse();
		Task task = new Task();
		Response response = null;
		try {

			BaseValidator validator = new UpdateTaskValidator();
			validator.validate(request);

			CaseManagementDelegate delegate = getCmDelegate(request);
			if (delegate != null) {
				task = delegate.updateTask(request);
			}
			if ((task != null)) {
				taskResponse = ResponseObjectFactory.createTaskResponse(
						SUCCESS, SUCCESS_TEXT);
				taskResponse.setTask(task);
			} else {
				taskResponse = ResponseObjectFactory.createTaskResponse(
						FAILURE, FAILURE_TEXT);
			}
			response = Response.ok(taskResponse).build();
		} catch (Exception exception) {
			LOGGER.error(
					"Icm Action Task Task - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			taskResponse.setResponseStatus(responseStatus);
			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, taskResponse);
		}
		return response;
	}
	
	@Override
	public Response createTask(Request request) {
		
		TaskResponse taskResponse = new TaskResponse();
		Task task = new Task();
		Response response = null ;
		try {

			BaseValidator validator = new CreateTaskValidator();
			validator.validate(request);

			CaseManagementDelegate delegate = getCmDelegate(request);
			if (delegate != null) {
				task = delegate.createTask(request);
			}
			if ((task != null)) {
				taskResponse = ResponseObjectFactory.createTaskResponse(
						SUCCESS, SUCCESS_TEXT);
				taskResponse.setTask(task);
			} else {
				taskResponse = ResponseObjectFactory.createTaskResponse(
						FAILURE, FAILURE_TEXT);
			}
			response = Response.ok(taskResponse).build();
		} catch (Exception exception) {
			LOGGER.error("Create Task - error:>>" + exception.getMessage(),
					exception);
			ResponseStatus responseStatus = ExceptionUtil
					.createESBResponseStatus(exception);
			taskResponse.setResponseStatus(responseStatus);
			response = ResponseObjectFactory.createResponseStatus(
					responseStatus, taskResponse);
		}
		
		return response;
	}
	
	@Override
	public Response searchConfigItems(Request request) {		
		Response response = null;

		ConfigItems configItems = new ConfigItems();

		ConfigItemsResponse configItemsResponse = new ConfigItemsResponse();

		try {

			if (request.getAttribute(APP_NAME) != null) {
				CaseManagementDelegate delegate = getCmDelegate(request);
				configItems = delegate.searchConfigItems(request);
			} else {
				configItems = this.caseManagementDelegate.searchConfigItems(request);
			}
			
			if ((configItems != null )){
				configItemsResponse = ResponseObjectFactory.createConfigItemResponse(SUCCESS, SUCCESS_TEXT);

				// Set the constructed response object value for return
				configItemsResponse.setConfigItems(configItems);

			} else {
				configItemsResponse = ResponseObjectFactory.createConfigItemResponse(FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(configItemsResponse).build();

		} catch (Exception exception) {

			LOGGER.error("SearchConfigItem - error:>>" + exception.getMessage(), exception);
			ResponseStatus responseStatus = ExceptionUtil.createESBResponseStatus(exception);
			configItemsResponse.setResponseStatus(responseStatus);

			response = ResponseObjectFactory.createResponseStatus(responseStatus, configItemsResponse);
		}

		return response;
	}

	@Override
	public Response doTaskSearch(Request request) {
		Response response = null;
		SearchResponse searchResponse = new SearchResponse();
		try {

			// Validate the request once it's received
			BaseValidatorImpl validator = new TaskSearchValidator();
			validator.validate(request);

			Processes processes = new Processes();
			processes = this.taskSearchHelper.doTaskSearch(request);
			if (processes != null) {
				searchResponse = ResponseObjectFactory.createSearchResponse(
						SUCCESS, SUCCESS_TEXT);
				searchResponse.setProcesses(processes);

			} else {
				searchResponse = ResponseObjectFactory.createSearchResponse(
						FAILURE, FAILURE_TEXT);
			}

			response = Response.ok(searchResponse).build();

		} catch (Exception exception) {

			if ((exception != null) && (exception.getMessage() != null)) {
				LOGGER.error("doTaskSearch - error:>>" + exception.getMessage(),
						exception);
				ResponseStatus responseStatus = ExceptionUtil
						.createESBResponseStatus(exception);
				searchResponse.setResponseStatus(responseStatus);
				response = ResponseObjectFactory.createResponseStatus(
						responseStatus, searchResponse);
			} else {
				searchResponse = ResponseObjectFactory.createSearchResponse(
						FAILURE, FAILURE_TEXT);
				response = Response.ok(searchResponse).build();
			}

		}

		return response;
	}
	
	@Override
	public Response deleteDocument(Request request) {

		Response response = null;
		DocumentResponse documentResponse = new DocumentResponse();

		try {
			// Validate the request once it's received
			BaseValidator validator = new DeleteDocumentValidator();
			validator.validate(request);
			CaseManagementDelegate delegate = getCmDelegate(request);
			delegate.deleteDocument(request);
			documentResponse = ResponseObjectFactory.createDocumentResponse(SUCCESS, SUCCESS_TEXT);
			response = Response.ok(documentResponse).build();

		} catch (Exception exception) {
			LOGGER.error("deleteDocument - error:>>" + exception.getMessage());
			ResponseStatus responseStatus = ExceptionUtil.createESBResponseStatus(exception);
			documentResponse.setResponseStatus(responseStatus);
			response = ResponseObjectFactory.createResponseStatus(responseStatus, documentResponse);
		}

		return response;
	}
}
