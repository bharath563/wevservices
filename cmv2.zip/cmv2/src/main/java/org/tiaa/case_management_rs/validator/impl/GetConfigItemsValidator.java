package org.tiaa.case_management_rs.validator.impl;

import org.tiaa.case_management_rs.common.Request;

public class GetConfigItemsValidator extends BaseValidatorImpl {

	@Override
	public void doValidate(Request request) {

	}

}
