package org.tiaa.case_management_rs.integration.cth;

import java.io.Serializable;

import org.tiaa.case_management_rs.domain.CMSTaskType;

public class CreateCTHContext extends AbstractContext implements Serializable, CTHContext {
	private static final long serialVersionUID = 642209869358124381L;
	private CMSTaskType cmsTaskType;
	private String cthOrchestrationId;
	private String cthRequestId;
	private boolean success;

	public CreateCTHContext() {
		super();
	}

	public CMSTaskType getCmsTaskType() {
		return cmsTaskType;
	}

	public String getCthOrchestrationId() {
		return cthOrchestrationId;
	}

	public String getCthRequestId() {
		return cthRequestId;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setCmsTaskType(CMSTaskType cmsTaskType) {
		this.cmsTaskType = cmsTaskType;
	}

	public void setCthOrchestrationId(String cthOrchestrationId) {
		this.cthOrchestrationId = cthOrchestrationId;
	}

	public void setCthRequestId(String cthRequestId) {
		this.cthRequestId = cthRequestId;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	@Override
	public String toString() {
		return "CreateCTHContext [cmsTaskType=" + cmsTaskType + ", cthOrchestrationId=" + cthOrchestrationId + ", cthRequestId=" + cthRequestId + ", success=" + success
				+ ", toString()=" + super.toString() + "]";
	}
}
