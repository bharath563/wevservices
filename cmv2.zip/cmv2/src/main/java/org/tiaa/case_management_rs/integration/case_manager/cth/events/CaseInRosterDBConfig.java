package org.tiaa.case_management_rs.integration.case_manager.cth.events;

import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.Marshaller;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.common.ExceptionHandler;

@Configuration
public class CaseInRosterDBConfig {
	@Bean
	public CaseInRosterDAO caseInRosterDAO() {
		return new CaseInRosterDAO();
	}

	@Bean
	public DocumentUploadProcessor documentUploadProcessor() {
		return new DocumentUploadProcessor();
	}

	@Bean
	public Jaxb2Marshaller transactionRequestJaxbMarshaller() {
		Map<String, Object> marshallerProperties = new HashMap<String, Object>();
		marshallerProperties.put(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		//
		Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setMarshallerProperties(marshallerProperties);
		jaxb2Marshaller.setClassesToBeBound(org.tiaa.esb.add_document.types.ObjectFactory.class);
		ExceptionHandler.initalize(jaxb2Marshaller);
		return jaxb2Marshaller;
	}
}
