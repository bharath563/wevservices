package org.tiaa.case_management_rs.service;

import javax.ws.rs.core.Response;

import org.tiaa.case_management_rs.common.Request;

import org.tiaa.atom.service.support.HealthCheck;

public interface CaseManagementRestService extends HealthCheck {

	Response getProcesses(Request request);

	Response getProcess(Request request);

	Response getDocument(Request request);

	Response getDocuments(Request request);

	Response createProcess(Request request);

	Response updateProcess(Request request);

	Response getConfigItems(Request request);

	Response doSearch(Request request, String databaseSearchFlag);

	Response getMetrics(Request request);

	Response createDocument(Request request);

	Response updateProcesses(Request request);

	Response createDocuments(Request request);

	Response createRelatedTask(Request request);

	Response createProcesses(Request request);

	Response getTasks(Request request);

	Response getComments(Request request);

	Response addComment(Request request);

	Response getTaskById(Request request);

	Response getTasksClaimable(Request request);

	Response updateDocument(Request request);

	Response getRelatedProcesses(Request request);

	Response getHistory(Request request);

	Response updateTask(Request request);

	Response createTask(Request request);

	Response searchConfigItems(Request request);

	Response doTaskSearch(Request request);
	
	Response deleteDocument(Request request);

}
