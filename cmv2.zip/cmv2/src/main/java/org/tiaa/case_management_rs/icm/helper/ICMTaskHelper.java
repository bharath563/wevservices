package org.tiaa.case_management_rs.icm.helper;

import java.io.IOException;
import java.util.List;
import java.util.Map.Entry;

import javax.xml.datatype.XMLGregorianCalendar;

import org.codehaus.jackson.JsonGenerationException;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.Properties;
import org.tiaa.esb.case_management_rs_v2.type.Status;
import org.tiaa.esb.case_management_rs_v2.type.Statuses;
import org.tiaa.esb.case_management_rs_v2.type.Task;
import org.tiaa.esb.case_management_rs_v2.type.Tasks;

@Component
public class ICMTaskHelper {

	//private static final Logger LOGGER = LoggerFactory.getLogger(ICMSearchHelper.class);
	private static ObjectMapper objectMapper = new ObjectMapper();

	public Tasks icmCasesToTasks(List<org.tiaa.esb.icm.types.Task> icmTaskList, int totalRecords) {
		
		
		MultiValueMap<String, org.tiaa.esb.icm.types.Task> tasksMap = createTasksMap(icmTaskList);
		Tasks tasks = processIcmTasksMap(tasksMap);
		
		if(null != tasks.getTasks() && tasks.getTasks().size() > 0){

			Task cmsTask = tasks.getTasks().get(0);
				if(null == cmsTask.getTaskProperties()){
					
					Properties properties = new Properties();
					cmsTask.setTaskProperties(properties);
		
				}
				
				cmsTask.getTaskProperties().getProperties().add(createNameValue(CaseManagementConstants.TOTAL_RECORDS_COUNT, "" + totalRecords));
			}
			
			return tasks;
	}	
	

	private Tasks processIcmTasksMap(
			MultiValueMap<String, org.tiaa.esb.icm.types.Task> tasksMap) {
		
		Tasks tasks = new Tasks();
		
		for(Entry<String, List<org.tiaa.esb.icm.types.Task>> entry : tasksMap.entrySet()){
			String key = entry.getKey();
			
			if(key.startsWith("groupId")){
				Task cmsTask = new Task();
				cmsTask.setID("{" + System.nanoTime() + "}");
				cmsTask.setName("Omni Transaction Details");
				cmsTask.setType("OmniTransactions");

				String plan = StringUtils.substringAfterLast(key, "-");
				NameValue planChildrenNameValue = createNameValue("Plan", plan);
				planChildrenNameValue.setDesc("Group");
				
				List<org.tiaa.esb.icm.types.Task> omniTaskList = entry.getValue();
				
				MultiValueMap<String, org.tiaa.esb.icm.types.Task> subPlanMap = new LinkedMultiValueMap<String, org.tiaa.esb.icm.types.Task>();
				
				for(org.tiaa.esb.icm.types.Task omniTask : omniTaskList){
					createSubPlanMap(subPlanMap, omniTask);
				}
						
				for(Entry<String, List<org.tiaa.esb.icm.types.Task>> subPlanEntry : subPlanMap.entrySet()){
					
					List<org.tiaa.esb.icm.types.Task> omniTaskSubPlanList = subPlanEntry.getValue();
					NameValue subPlanChildrenNameValue = createNameValue("SubPlan", subPlanEntry.getKey());
					subPlanChildrenNameValue.setDesc("Group");
					
					for(org.tiaa.esb.icm.types.Task omniTask : omniTaskSubPlanList){
						
						subPlanChildrenNameValue.getChildrenNameValues().add(populateOmniTaskDetails(omniTask));
						
					}
					
					planChildrenNameValue.getChildrenNameValues().add(subPlanChildrenNameValue);
				}
				
				Properties properties = new Properties();
				properties.getProperties().add(planChildrenNameValue);
				cmsTask.setTaskProperties(properties);

				tasks.getTasks().add(cmsTask);
				
			} else {
				
				List<org.tiaa.esb.icm.types.Task> tasksList = entry.getValue();
				
				for(org.tiaa.esb.icm.types.Task task : tasksList){
					tasks.getTasks().add(populateTask(task));
				}
				
			}
		}

		return tasks;
	}

	private void createSubPlanMap(MultiValueMap<String,org.tiaa.esb.icm.types.Task> subPlanMap, org.tiaa.esb.icm.types.Task omniTask) {
		
		String subPlan = (String)omniTask.getAdditionalProperties().get("subPlan");
		subPlanMap.add(subPlan, omniTask);
		
	}


	private MultiValueMap<String, org.tiaa.esb.icm.types.Task> createTasksMap(List<org.tiaa.esb.icm.types.Task> icmTaskList) {
		MultiValueMap<String, org.tiaa.esb.icm.types.Task> tasksMap = new LinkedMultiValueMap<String, org.tiaa.esb.icm.types.Task>();
		
		if (icmTaskList != null && !icmTaskList.isEmpty()) {
			for (Object icmTaskResponseJSON : icmTaskList) {
				try {
						String icmResponseJSONString = ICMTaskHelper.objectMapper.writeValueAsString(icmTaskResponseJSON);
						org.tiaa.esb.icm.types.Task icmTaskResponse = ICMTaskHelper.objectMapper.readValue(icmResponseJSONString, org.tiaa.esb.icm.types.Task.class);
						
						if(null != icmTaskResponse.getAdditionalProperties() && null != icmTaskResponse.getAdditionalProperties().get("groupId")){
							
							String plan = (String)icmTaskResponse.getAdditionalProperties().get("groupId");
							tasksMap.add(plan, icmTaskResponse);
							
						}else{
							
							tasksMap.add(icmTaskResponse.getId(), icmTaskResponse);
						}
					
				} catch (JsonGenerationException e) {
					e.printStackTrace();
				} catch (JsonMappingException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		return tasksMap;
	}



	
	private Task populateTask(org.tiaa.esb.icm.types.Task icmTask){
		
		Task cmsTask = new Task();
		cmsTask.setID(icmTask.getId());
		cmsTask.setType(icmTask.getType());
		cmsTask.setName(icmTask.getName());

		org.tiaa.esb.case_management_rs_v2.type.List actionList = new org.tiaa.esb.case_management_rs_v2.type.List();
		actionList.getItems().add(icmTask.getCompletedAction());
		cmsTask.setAction(actionList);
		List<org.tiaa.esb.icm.types.Status> icmStatusList =icmTask.getStatuses();

		Statuses statuses = new Statuses();
		for(org.tiaa.esb.icm.types.Status icmStatus  :icmStatusList){
			Status status = new Status();
			status.setSts(icmStatus.getStatus());
			if(icmStatus.getStatusOn() != null){
				status.setEffDate(DateUtil.toXMLGregorianCalendar(DateUtil.parseDateTimeWithMilliseconds(icmStatus.getStatusOn())));
			}
			status.setCmplmtBy(icmStatus.getStatusBy());
			statuses.getSts().add(status);
		}
		cmsTask.setStatusHistory(statuses);
		
		if(null != icmTask.getAdditionalProperties()){
			String fileHistory = (String)icmTask.getAdditionalProperties().get("fileHistory");
			if(!StringUtils.isBlank(fileHistory)){
				
				NameValue nameValue = createNameValue("fileHistory", fileHistory);
				
				Properties properties = new Properties();
				properties.getProperties().add(nameValue);
				cmsTask.setTaskProperties(properties);
			}
		}
		
		return cmsTask;
	}
	
	private NameValue populateOmniTaskDetails(org.tiaa.esb.icm.types.Task icmTask){
		
		NameValue taskNameValue = createNameValue(icmTask.getName(), null);
		
		NameValue statusDetailsChildrenNameValue = new NameValue();
		statusDetailsChildrenNameValue.setDesc("PropertyGroup");
		
		List<org.tiaa.esb.icm.types.Status> icmStatusList =icmTask.getStatuses();
		for(org.tiaa.esb.icm.types.Status icmStatus  :icmStatusList){
			
			NameValue statusNameValue = new NameValue(); 
			
			statusNameValue.getChildrenNameValues().add(createNameValue("Status", icmStatus.getStatus()));
			if(icmStatus.getStatusOn() != null){
				statusNameValue.getChildrenNameValues().add(createDateNameValue("Status On", DateUtil.toXMLGregorianCalendar(DateUtil.parseDateTimeWithMilliseconds(icmStatus.getStatusOn()))));
			}
			statusNameValue.getChildrenNameValues().add(createNameValue("Status By", icmStatus.getStatusBy()));
			statusDetailsChildrenNameValue.getChildrenNameValues().add(statusNameValue);
		}
		
		taskNameValue.getChildrenNameValues().add(statusDetailsChildrenNameValue);
		
		return taskNameValue;
	}
	
	private NameValue createDateNameValue(String name, XMLGregorianCalendar dateValue) {
		NameValue nameValue = new NameValue();
		
		nameValue.setName(name);
		
		if (dateValue != null) {
			nameValue.setDateValue(dateValue);
		}		
		
		return nameValue;
	}


	private NameValue createNameValue(String name, Object value) {
		NameValue nameValue = new NameValue();
		nameValue.setName(name);
		if (value != null) {
			nameValue.setValue(String.valueOf(value));
		}
		return nameValue;
	}
	
}
