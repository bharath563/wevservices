package org.tiaa.case_management_rs.common;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.tiaa.case_management_rs.domain.CMSTaskType;
import org.tiaa.case_management_rs.repository.CMSTaskTypeRepository;
import org.tiaa.case_management_rs.utils.CommonUtil;

public class CMSTaskTypeService {
	@Autowired
	private CMSTaskTypeRepository cmsTaskTypeRepository;

	public CMSTaskType getCMSTaskType(String taskType) {
		return cmsTaskTypeRepository.findByTaskType(taskType);
	}

	public List<CMSTaskType> getPlanModificationRequestTasks() {
		return cmsTaskTypeRepository.findByPlanModificationRequestTask(true);
	}

	public List<CMSTaskType> getCMSTaskTypes() {
		return cmsTaskTypeRepository.findAll();
	}

	public String getCMSTaskTypesCommaSeparated(String cthRequestSchemaName) {
		ArrayList<String> cmsTaskTypes = new ArrayList<String>();
		for (CMSTaskType cmsTaskType : cmsTaskTypeRepository.findByCthRequestSchemaName(cthRequestSchemaName)) {
			if (cmsTaskType.isActive()) {
				cmsTaskTypes.add(cmsTaskType.getTaskType());
			}
		}
		return CommonUtil.toStringSingleQuoted(cmsTaskTypes);
	}

	public String getPlanModificationCMSTaskTypesCommaSeparated() {
		ArrayList<String> cmsTaskTypes = new ArrayList<String>();
		for (CMSTaskType cmsTaskType : cmsTaskTypeRepository.findByPlanModificationRequestTaskAndCthRequestSchemaNameIsNull(true)) {
			if (cmsTaskType.isActive()) {
				cmsTaskTypes.add(cmsTaskType.getTaskType());
			}
		}
		return CommonUtil.toStringSingleQuoted(cmsTaskTypes);
	}
}