package org.tiaa.case_management_rs.validator.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.apache.commons.lang3.StringUtils;

import org.tiaa.case_management_rs.common.Request;

public class GetProcessValidator extends BaseValidatorImpl{

	@Override
	public void doValidate(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		//String taskId = (String) request.getAttribute(TASK_ID);
		String taskId = (String) request.getAttribute(PROCESS_ID);
		String appName = (String) request.getAttribute(APP_NAME);

		if (StringUtils.isBlank(userId)) {
			handleException(VALIDATION_USERID_IS_EMPTY);
		}

		if (StringUtils.isBlank(taskId)) {
			handleException(VALIDATION_TASKID_IS_EMPTY);
		}

		if (StringUtils.isBlank(appName)) {
			handleException(VALIDATION_APPNAME_IS_EMPTY);
		}
	}
}
