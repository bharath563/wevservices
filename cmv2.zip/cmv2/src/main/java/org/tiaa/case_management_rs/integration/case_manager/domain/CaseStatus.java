package org.tiaa.case_management_rs.integration.case_manager.domain;

import java.util.Date;

public class CaseStatus {
	private String caseStatus;
	private Date statusUpdatedTS;

	public CaseStatus() {
		super();
	}

	public CaseStatus(String caseStatus, Date statusUpdatedTS) {
		super();
		this.caseStatus = caseStatus;
		this.statusUpdatedTS = statusUpdatedTS;
	}

	public String getCaseStatus() {
		return caseStatus;
	}

	public Date getStatusUpdatedTS() {
		return statusUpdatedTS;
	}

	public void setCaseStatus(String caseStatus) {
		this.caseStatus = caseStatus;
	}

	public void setStatusUpdatedTS(Date statusUpdatedTS) {
		this.statusUpdatedTS = statusUpdatedTS;
	}

	@Override
	public String toString() {
		return "CaseStatus [caseStatus=" + caseStatus + ", statusUpdatedTS=" + statusUpdatedTS + "]";
	}
}
