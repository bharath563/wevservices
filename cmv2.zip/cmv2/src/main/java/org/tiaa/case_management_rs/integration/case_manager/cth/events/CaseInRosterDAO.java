package org.tiaa.case_management_rs.integration.case_manager.cth.events;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class CaseInRosterDAO {
	@Autowired
	private JdbcTemplate caseManagerJdbcTemplate;
	@Value("${insertCaseInRosterSql}")
	private String insertCaseInRosterSql;
	
	public int insert(CaseInRosterItem caseInRosterItem) {
		return caseManagerJdbcTemplate.update(insertCaseInRosterSql, new Object[] { //
				caseInRosterItem.getRequestId(), //
						caseInRosterItem.getOrchestrationId(), //
						caseInRosterItem.getCaseId(), //
						caseInRosterItem.getCorrelationId(), //
						caseInRosterItem.getSolutionType(), //
						caseInRosterItem.getCaseType(), //
						caseInRosterItem.getTaskOperation(), //
						caseInRosterItem.getStatus(), //
						caseInRosterItem.getChannelPutTime(), //
						caseInRosterItem.getRecievedDateTime(), //
						caseInRosterItem.getResponseRequired(), //
						caseInRosterItem.getInputPayload(), //
						caseInRosterItem.getDispatchedDateTime(), //
						caseInRosterItem.getProcessedDateTime(), //
						caseInRosterItem.getOriginatorId(), //
						caseInRosterItem.getChannel(), //
						caseInRosterItem.getCmHostName(), //
						caseInRosterItem.getProcessType(), //
						caseInRosterItem.getProcessingPriority() //
				});
	}
}
