package org.tiaa.case_management_rs.domain;

public enum TaskMode {
	Read("Read"), Write("Write");

	private TaskMode(String taskMode) {
		this.taskMode = taskMode;
	}

	private final String taskMode;

	public String getTaskMode() {
		return taskMode;
	}

}
