package org.tiaa.case_management_rs.integration.case_manager.cth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.support.RetryTemplate;

import org.tiaa.case_management_rs.integration.cth.CTHCreateRecordFailedException;

public class RetryableCTHCaseRecordCreator {
	private static final Logger LOG = LoggerFactory.getLogger(RetryableCTHCaseRecordCreator.class);
	private RetryTemplate retryTemplate;
	private CTHCaseRecordCreator cthRecordCreator;

	public RetryableCTHCaseRecordCreator(RetryTemplate retryTemplate, CTHCaseRecordCreator cthRecordCreator) {
		super();
		this.retryTemplate = retryTemplate;
		this.cthRecordCreator = cthRecordCreator;
	}

	public Object createCTHRecord(final CreateCTHCaseContext context) {
		try {
			return retryTemplate.execute(new RetryCallback<Object>() {
				@Override
				public Object doWithRetry(RetryContext retryContext) {
					return cthRecordCreator.createCTHRecord(context);
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
			LOG.warn(e.getMessage());
			throw new CTHCreateRecordFailedException(e.getMessage(), e);
		}
	}

}
