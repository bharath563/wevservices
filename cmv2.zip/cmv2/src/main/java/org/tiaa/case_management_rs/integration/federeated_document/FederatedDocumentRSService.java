package org.tiaa.case_management_rs.integration.federeated_document;

import java.io.StringWriter;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.http.converter.FormHttpMessageConverter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.xml.Jaxb2RootElementHttpMessageConverter;
import org.springframework.http.converter.xml.MarshallingHttpMessageConverter;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import org.tiaa.case_management_rs.common.ExceptionHandler;
import org.tiaa.case_management_rs.common.SInfoHeaderAdderClientHttpRequestInterceptor;
import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.Document;
import org.tiaa.esb.case_management_rs_v2.type.Documents;
import org.tiaa.esb.federated_document_rs.types.Artifact;
import org.tiaa.esb.federated_document_rs.types.Attachment;
import org.tiaa.esb.federated_document_rs.types.DocTypeOverride;
import org.tiaa.esb.federated_document_rs.types.DocumentDetails;
import org.tiaa.esb.federated_document_rs.types.DocumentLocator;
import org.tiaa.esb.federated_document_rs.types.DocumentLocatorType;
import org.tiaa.esb.federated_document_rs.types.Metadata;
import org.tiaa.esb.federated_document_rs.types.ObjectFactory;
import org.tiaa.esb.federated_document_rs.types.StoreDocumentsRequest;
import org.tiaa.esb.federated_document_rs.types.StoreDocumentsResponse;
import org.tiaa.esb.federated_document_rs.types.StoredDocument;

/*
Doc Type	Business Unit	Doc Code	Document_Version
INSRUPLOAD	PENSION			INST_DOCS	2

Same Doc Type Id/Report: INSRUPLOAD
Same Indexes:
Orchestration_ID
Plan_ID
Client_ID
Document_Request_ID
Filename
Document_Description
Business_Date
Customer_Number
*/
@Service
public class FederatedDocumentRSService {
	public static final String UPLOAD_PIN = "PIN";
	public static final String UPLOAD_PLAN_NUMBER = "PlanNumber";
	public static final String UPLOAD_DOCUMENT_TITLE = "DocumentTitle";
	public static final String UPLOAD_CLIENT_ID = "Client_ID";
	public static final String UPLOAD_MIME_TYPE = "MimeType";
	public static final String UPLOAD_DRI = "DocumentRequestID";
	//
	public static final String UPLOAD_ORCH_ID = "Orchestration_ID";
	public static final String UPLOAD_PLAN_ID = "Plan_ID";
	public static final String UPLOAD_FILE_NAME = "Filename";
	public static final String UPLOAD_DOCUMENT_DESCRIPTION = "Document_Description";
	public static final String UPLOAD_BUSINESS_DATE = "Business_Date";
	public static final String UPLOAD_CUSTOMER_NUMBER = "Customer_Number";

	private static final String FEDERATED_DOCUMENT = "vnd.tiaa.federated-document-rs-v1.0+xml";
	//private static final String CONTENT_TYPE_XML = "application/vnd.tiaa.federated-document-rs-v1.0+xml, application/pdf, application/octet-stream";
	private static final String CONTENT_TYPE_XML = "application/vnd.tiaa.federated-document-rs-v1.0+xml";
	private static final String APPLICATION_PDF = "application/pdf";
	
	private static final String COLON = ":";
	private static final String XML_FORM_NAME = "file1";
	private static final int CHUNK_SIZE = 1024 * 8;//8MB
	private static final Logger LOG = LoggerFactory.getLogger(FederatedDocumentRSService.class);
	//
	private static final String DELIVERY_TYPE = "PR";
	//
	private static final String DOC_TYPE_ID = "UWFRUPLOAD";
	public static final String BIZ_UNIT = "ALL";
	public static final String DOC_CODE = "UW_DOCS";
	public static final String VERSION = "1";
	public static final int DOC_VERSION = 1;
	//private String documentPathQueryTemplate = "/federated-document-rs-v1/documents?business-unit-code={BIZ_UNIT}&doc-code={DOC_CODE}&version={VER}&doc-type-id={DOC_TYPE_ID}";
	private String documentPathQueryTemplate = "/federated-document-rs-v1/documents?business-unit-code={BIZ_UNIT}&doc-code={DOC_CODE}&version={VER}&id-type={DOC_TYPE_ID}";
	//private String documentPathQueryTemplate1 = "/federated-document-rs-v1/documents/{DOC_ID}?business-unit-code={BIZ_UNIT}&doc-code={DOC_CODE}&version={VER}&id-type={DOC_TYPE_ID}";
	private String documentPathQueryTemplate1 = "/federated-document-rs-v1/documents/";
	//
	@Value("${esb.rs.root}")
	private String baseUrl;
	private RestTemplate restTemplate = new RestTemplate();
	private String mobiusServiceUrl;
	private String getmobiusServiceUrl;
	private Jaxb2Marshaller jaxb2Marshaller;

	private boolean msgConvert = true;
	public static final String DOC_DIRECTION = "DocDirection";
	public static final String DOC_CATEGORY = "DocCategory";
	
	public FederatedDocumentRSService() {
		super();
	}
	
	
	@PostConstruct
	public void init() {
		mobiusServiceUrl = baseUrl + documentPathQueryTemplate;
		getmobiusServiceUrl = baseUrl + documentPathQueryTemplate1;
		//
		restTemplate.setRequestFactory(createRequestFactory());
		LOG.debug("isMsgConvert():"+isMsgConvert());
		
		
		//
		List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
		clientHttpRequestInterceptors.add(new SInfoHeaderAdderClientHttpRequestInterceptor(CONTENT_TYPE_XML));
		restTemplate.setInterceptors(clientHttpRequestInterceptors);
	}

	private SimpleClientHttpRequestFactory createRequestFactory() {
		SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
		requestFactory.setBufferRequestBody(false);
		requestFactory.setChunkSize(CHUNK_SIZE);
		return requestFactory;
	}

	private List<HttpMessageConverter<?>> createMessageConverters() {
		jaxb2Marshaller = new Jaxb2Marshaller();
		jaxb2Marshaller.setClassesToBeBound(ObjectFactory.class);
		ExceptionHandler.initalize(jaxb2Marshaller, true);
		//
		List<HttpMessageConverter<?>> messageConverters = new ArrayList<HttpMessageConverter<?>>();
		FederatedDocumentMarshallingHttpMessageConverter mhmc = new FederatedDocumentMarshallingHttpMessageConverter(jaxb2Marshaller);
		mhmc.setSupportedMediaTypes(Arrays.asList(
				new org.springframework.http.MediaType("application",
						FEDERATED_DOCUMENT),
				org.springframework.http.MediaType.APPLICATION_XML,
				org.springframework.http.MediaType.TEXT_XML,
				org.springframework.http.MediaType.TEXT_HTML,
				org.springframework.http.MediaType.APPLICATION_OCTET_STREAM));
		
		messageConverters.add(mhmc);
		// add form converter
		FormHttpMessageConverter fmc = new FormHttpMessageConverter();
		fmc.addPartConverter(new Jaxb2RootElementHttpMessageConverter());
		messageConverters.add(fmc);
		/*
		ByteArrayHttpMessageConverter bahmc = new ByteArrayHttpMessageConverter();
		AllEncompassingFormHttpMessageConverter  aefhmc = new AllEncompassingFormHttpMessageConverter();
		
		messageConverters.add(bahmc); 
		messageConverters.add(aefhmc);
		messageConverters.add(new StringHttpMessageConverter(Charset.forName("UTF-8")));*/
		return messageConverters;
	}

	/**
	 * Archive the document to Mobius through FDRS Rest Service call.
	 *
	 * Set the message converters. Set the XML document. Set the Upload file.
	 * Call the FDRS service.
	 */
	public String archiveDocumentInMobius(Map<String, String> documentDataMap, Resource resource) {
		try {
			restTemplate.setMessageConverters(createMessageConverters());
			return tryArchiveDocumentInMobius(documentDataMap, resource);
		} catch (JAXBException e) {
			LOG.warn(e.getMessage(), e);
			throw new DocumentArchivalFailedException(e);
		} catch (DocumentArchivalFailedException e) {
			LOG.warn(e.getMessage(), e);
			throw e;
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
			throw new DocumentArchivalFailedException(e);
		}
	}

	private String tryArchiveDocumentInMobius(Map<String, String> documentDataMap, Resource inputStream) throws JAXBException {
		HttpEntity<MultiValueMap<String, Object>> request = createRequestEntity(documentDataMap, inputStream);
		ResponseEntity<StoreDocumentsResponse> response = null;
		response = restTemplate.exchange(mobiusServiceUrl, HttpMethod.POST, request, StoreDocumentsResponse.class, createUrlVariableMap());
		//
		StoreDocumentsResponse storeDocumentResponse = response.getBody();
		String status = storeDocumentResponse.getResponseStatus().getStatus();
		if ("SUCCESS".equals(status)) {
			return documentDataMap.get(UPLOAD_DRI);
		}
		String responseXml = marshal(storeDocumentResponse);
		LOG.error("Response status : " + status + ", xml :" + responseXml);
		throw new DocumentArchivalFailedException("federated-document-rs-v1 returned status: " + status + ", response xlm: " + responseXml);
	}

	private HttpEntity<MultiValueMap<String, Object>> createRequestEntity(Map<String, String> documentDataMap, Resource inputStream) throws JAXBException {
		MultiValueMap<String, Object> multipartMap = new LinkedMultiValueMap<String, Object>();
		addMultiParts(multipartMap, documentDataMap, inputStream);
		// using http entity for part to specify part content type
		return new HttpEntity<MultiValueMap<String, Object>>(multipartMap, createHttpHeader());
	}

	private void addMultiParts(MultiValueMap<String, Object> multipartMap, Map<String, String> documentDataMap, Resource inputStream) throws JAXBException {
		String documentTitle = documentDataMap.get(UPLOAD_DOCUMENT_TITLE);
		multipartMap.add(XML_FORM_NAME, createXMLPart(documentDataMap));
		multipartMap.add(documentTitle, createFilePart(documentDataMap, inputStream));
	}

	/**
	 * Attach the XML to the header.
	 *
	 * @return
	 * @throws JAXBException
	 * @throws PropertyException
	 */
	private HttpEntity<String> createXMLPart(Map<String, String> documentDataMap) throws JAXBException {
		// Add xml entity
		HttpHeaders xmlFileHeaders = new HttpHeaders();
		xmlFileHeaders.add("Content-type", CONTENT_TYPE_XML);
		//
		StoreDocumentsRequest request = createStoreDocumentsRequest(documentDataMap);
		String xml = marshal(request);
		LOG.debug("FederatedUpload - Generated XML" + xml);
		//
		return new HttpEntity<String>(xml, xmlFileHeaders);
	}

	/***
	 * Attach the file that needs to be upload to the Http Header
	 *
	 * @return
	 */
	private HttpEntity<Resource> createFilePart(final Map<String, String> documentDataMap, Resource resource) {
		HttpHeaders fileHeaders = new HttpHeaders();
		fileHeaders.add("Content-type", documentDataMap.get(UPLOAD_MIME_TYPE));
		return new HttpEntity<Resource>(resource, fileHeaders);
	}

	private void addMetadata(Map<String, String> documentDataMap, DocumentDetails documentDetails) {
		List<Metadata> metadataList = documentDetails.getMetadatas();
		//
		String dri = documentDataMap.get(UPLOAD_DRI);
		addMetaData("Document_Request_ID", dri, metadataList);
		//
		String orchId = documentDataMap.get(UPLOAD_ORCH_ID);
		addMetaData("Orchestration_ID", nullSafe(orchId), metadataList);
		//
		String clientId = documentDataMap.get(UPLOAD_CLIENT_ID);
		addMetaData("Client_ID", nullSafe(clientId), metadataList);
		//
		String customerNumber = documentDataMap.get(UPLOAD_CUSTOMER_NUMBER);
		addMetaData("Customer_Number", customerNumber, metadataList);
		//
		String planNumber = documentDataMap.get(UPLOAD_PLAN_NUMBER);
		addMetaData("Plan_ID", nullSafe(planNumber), metadataList);
		//
		String fileName = documentDataMap.get(UPLOAD_FILE_NAME);
		addMetaData("Filename", fileName, metadataList);
		//
		String description = documentDataMap.get(UPLOAD_DOCUMENT_TITLE);
		addMetaData("Document_Description", description, metadataList);
		//
		String businesDate = documentDataMap.get(UPLOAD_BUSINESS_DATE);
		addMetaData("Business_Date", businesDate, metadataList);
		
		String pin = documentDataMap.get(UPLOAD_PIN);
		addMetaData("PIN", nullSafe(pin), metadataList);

	}

	void addMetadataCaseManager(Map<String, String> documentDataMap, DocumentDetails documentDetails) {
		List<Metadata> metadataList = documentDetails.getMetadatas();
		String pin = documentDataMap.get(UPLOAD_PIN);
		if (pin != null) {
			addMetaData("PIN", pin, metadataList);
		}
		String clientId = documentDataMap.get(UPLOAD_CLIENT_ID);
		if (clientId != null) {
			addMetaData("Client_ID", clientId, metadataList);
		}
		String planNumber = documentDataMap.get(UPLOAD_PLAN_NUMBER);
		if (planNumber != null) {
			addMetaData("Plan_ID", planNumber, metadataList);
		}
		//
		String dri = documentDataMap.get(UPLOAD_DRI);
		addMetaData("Document_Request_ID", dri, metadataList);
		//
		String description = documentDataMap.get(UPLOAD_DOCUMENT_TITLE);
		addMetaData("DESCRIPTION", description, metadataList);
		//
		addMetaData("DELIVERYTYPE", DELIVERY_TYPE, metadataList);
		addMetaData("APPROVED", "Y", metadataList);
		addMetaData("EMAIL", "", metadataList);
		addMetaData("EMAILTEMPLATE", "", metadataList);
		addMetaData("First_Name", "", metadataList);
		addMetaData("Last_Name", "", metadataList);
		addMetaData("PREFIX", "", metadataList);
		addMetaData("MIDDLENAME", "", metadataList);
		addMetaData("SUFFIX", "", metadataList);
		addMetaData("BUSDATE", "", metadataList);
	}

	private void addMetaData(String name, String value, List<Metadata> metadataList) {
		Metadata metadata = new Metadata();
		metadata.setName(name);
		metadata.setValue(value);
		metadataList.add(metadata);
	}

	/**
	 * Generate DRI for the Request.
	 *
	 * @return
	 */
	private String computeDRI(String pin, String clientId) {
		String universalId = (pin != null) ? pin : clientId;
		if(StringUtils.isEmpty(universalId)){
			universalId = String.valueOf(Math.random());
		}
		String universalIDAppender = pad('0', universalId, 13);
		
		universalIDAppender = universalIDAppender.substring(Math.max(0, universalIDAppender.length() - 13));
		//
		SimpleDateFormat dformat = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		//dformat.setTimeZone(TimeZone.getTimeZone("UTC"));
		String now = dformat.format(new Date());
		//
		return new StringBuilder().append("UWFRUPLD").append(COLON).append(now).append(universalIDAppender).toString();
	}

	/**
	 * Generate the HTTP Headers that need to set in the post request. Note:
	 * This request will be intercepted by EsbRestClientInterceptor which adds
	 * default request headers.
	 *
	 * @return
	 */
	private HttpHeaders createHttpHeader() {
		HttpHeaders reqheaders = new HttpHeaders();
		reqheaders.setContentType(MediaType.MULTIPART_FORM_DATA);
		reqheaders.set("Accept", CONTENT_TYPE_XML);
		reqheaders.setAccept(Collections.singletonList(MediaType.valueOf(CONTENT_TYPE_XML)));
		return reqheaders;
	}

	/**
	 * Generate the XML request message formatted according to the
	 * StoreDocumentsRequest schema element
	 *
	 * @return
	 */
	private StoreDocumentsRequest createStoreDocumentsRequest(Map<String, String> documentDataMap) {
		String pin = documentDataMap.get(UPLOAD_PIN);
		String clientId = documentDataMap.get(UPLOAD_CLIENT_ID);
		String dri = computeDRI(pin, clientId);
		LOG.info("FederatedUpload - DRI: " + dri);
		documentDataMap.put(UPLOAD_DRI, dri);
		//
		DocTypeOverride docTypeOverride = new DocTypeOverride();
		docTypeOverride.setBusinessUnitCode(BIZ_UNIT);
		docTypeOverride.setDocCode(DOC_CODE);
		docTypeOverride.setDocumentTypeId(DOC_TYPE_ID);
		docTypeOverride.setVersion(VERSION);
		//
		DocumentDetails documentDetails = new DocumentDetails();
		documentDetails.setFileAssociation(getExtensionFromMimeType(documentDataMap));
		addMetadata(documentDataMap, documentDetails);
		//
		Artifact artifact = new Artifact();
		artifact.setDocTypeOverride(docTypeOverride);
		artifact.setDocumentDetails(documentDetails);
		//
		String fileName = documentDataMap.get(UPLOAD_DOCUMENT_TITLE);
		artifact.setName(fileName);
		//
		Attachment attachment = new Attachment();
		attachment.setArtifact(artifact);
		//
		StoreDocumentsRequest request = new StoreDocumentsRequest();
		request.getAttachments().add(attachment);
		return request;
	}

	// convert mime type to file suffix.
	private String getExtensionFromMimeType(Map<String, String> documentDataMap) {
		String mimeType = documentDataMap.get(UPLOAD_MIME_TYPE);
		String extensionFromMimeType = MimeTypeHelper.getExtensionFromMimeType(mimeType);
		LOG.info("File Extension :" + extensionFromMimeType);
		return extensionFromMimeType;
	}

	/**
	 * Build the URL Vairables
	 */
	private Map<String, String> createUrlVariableMap() {
		Map<String, String> urlVariables = new HashMap<String, String>();
		urlVariables.put("BIZ_UNIT", BIZ_UNIT);
		urlVariables.put("DOC_CODE", DOC_CODE);
		urlVariables.put("VER", VERSION);
		urlVariables.put("DOC_TYPE_ID", DOC_TYPE_ID);
		LOG.debug("FederatedUpload - uri variables:" + urlVariables);
		return urlVariables;
	}

	private String marshal(Object request) throws JAXBException {
		JAXBContext jaxbContext = jaxb2Marshaller.getJaxbContext();
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		jaxbMarshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
		//
		StringWriter sw = new StringWriter();
		jaxbMarshaller.marshal(request, sw);
		return sw.toString();
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	/**
	 * Pad the beginning of a string with a character.
	 *
	 * @param paddingChar
	 *            The character to pad the beginning of the string with.
	 * @param aString
	 *            The string.
	 * @param padLimit
	 *            The minimum length the new string will be.
	 * @return A new string with the pad character prepended to make sure the
	 *         string is at least p characters long.
	 */
	private static final String pad(final char paddingChar, final String aString, final int padLimit) {
		if (aString == null) {
			/*
			 * pad('0', null, 6) becomes "000000"
			 */
			return pad(paddingChar, "", padLimit); //$NON-NLS-1$
		}
		final int slength = aString.length();
		if (padLimit > slength) {
			/*
			 * pad('0', "1234", 6) becomes "001234"
			 */
			final int padding = (padLimit - slength);
			final char[] t = new char[padLimit];
			Arrays.fill(t, 0, padding, paddingChar);
			System.arraycopy(aString.toCharArray(), 0, t, padding, slength);
			return String.valueOf(t);
		}
		return aString;
	}

	private static String nullSafe(String str) {
		return str == null ? "" : str;
	}

	public static class FederatedDocumentMarshallingHttpMessageConverter extends MarshallingHttpMessageConverter {

		public FederatedDocumentMarshallingHttpMessageConverter(org.springframework.oxm.Marshaller marshaller) {
			super(marshaller);
		}

		@Override
		public boolean canRead(Class<?> clazz, MediaType mediaType) {
			return canRead(mediaType);
		}

		@Override
		protected boolean canRead(MediaType mediaType) {
			if (mediaType == null) {
				return false;
			}
			String type = mediaType.getType();
			if ("application/vnd.tiaa.federated-document-rs-v1.0+xml;profile=federated-document-rs-v1.0.xsd".equals(type)) {
				return true;
			}
			if (MediaType.APPLICATION_XML.getType().equals(type)) {
				return true;
			}
			return false;
		}
	}
		
	public Document getDocumentFromMobius(Map<String,String> request,String docId) throws JAXBException {
		 Document document = new Document(); 
		/*try{*/
				restTemplate.getMessageConverters().clear();
			List<ClientHttpRequestInterceptor> clientHttpRequestInterceptors = new ArrayList<ClientHttpRequestInterceptor>();
			String mimeTypes = "application/vnd.tiaa.federated-document-rs-v1.0+xml,application/pdf,application/xml,image/tiff,text/html,application/vnd.ms-excel";
			
			LOG.debug("request.get(\"Accept\")"+request.get(CaseManagementConstants.MIME_TYPE));
			if(request.get(CaseManagementConstants.MIME_TYPE)!=null){
				mimeTypes = mimeTypes+","+request.get(CaseManagementConstants.MIME_TYPE);
			}
			clientHttpRequestInterceptors.add(new SInfoHeaderAdderClientHttpRequestInterceptor(mimeTypes));
			restTemplate.setInterceptors(clientHttpRequestInterceptors);
			
			restTemplate.getMessageConverters().add(new ByteArrayHttpMessageConverter());
	    UriComponentsBuilder uriComponentsBuilder =  UriComponentsBuilder.fromUriString(getmobiusServiceUrl+docId);
	   
        for (Entry<String, String> query : request.entrySet() ) {
               uriComponentsBuilder = addQueryParam(uriComponentsBuilder, query.getKey(), query.getValue());
        }
        URI searchURI = uriComponentsBuilder.build().toUri();
        LOG.debug("uri:"+searchURI);
        ResponseEntity<byte[]> response = restTemplate.exchange(searchURI, HttpMethod.GET, null, byte[].class);

        byte[] docContent = response.getBody();
       
        HttpHeaders headers = response.getHeaders();
        if(response.getHeaders().containsKey(HttpHeaders.CONTENT_TYPE)){
        	List<String> values = headers.get(HttpHeaders.CONTENT_TYPE);
        	String value = "";
        	
        	for(String headerValue : values){
    			value = value + headerValue;
    		}
        	
        	document.setMimeTyp(value);    
        }
        
      
        LOG.debug("docContent Length"+docContent.length);
        document.setDocContent(docContent);
        LOG.debug("response:"+response);
		/*}catch(Exception e){
			e.printStackTrace();
		}*/
        return document;
        
  }
  
  private  UriComponentsBuilder addQueryParam(UriComponentsBuilder builder, String name, String value) {
	  if(value!=null && value !=""){
       builder.queryParam(name, value) ;
	  }
	  return builder;
  }

  public boolean isMsgConvert() {
		return msgConvert;
	}


	public void setMsgConvert(boolean msgConvert) {
		this.msgConvert = msgConvert;
	}

	/**
	 * This method uploads multiple documents to FDRS.
	 * @param docs
	 * @return
	 */
	public List<Map<String, String>> uploadMultipleDocsToFDRS(Documents docs) {
		
		Map<String, String> documentDataMap = null;
		
		List<StoreDocumentsRequest> docsList = new ArrayList<StoreDocumentsRequest>();
		MultiValueMap<String, Object> newMultipartMap = new LinkedMultiValueMap<String, Object>();
		Map<String,Resource> byteArrayMap = new HashMap<String,Resource>();
		
		List<Map<String, String>> docsArchvied = new ArrayList<Map<String, String>>();
		
		try{
			for (Document cmsDocument : docs.getDocuments()){
				documentDataMap = new HashMap<String, String>();
				
				documentDataMap.put(FederatedDocumentRSService.UPLOAD_MIME_TYPE, cmsDocument.getMimeTyp());
				documentDataMap.put(FederatedDocumentRSService.UPLOAD_DOCUMENT_TITLE, cmsDocument.getDocName());
				documentDataMap.put(FederatedDocumentRSService.UPLOAD_FILE_NAME, cmsDocument.getDocName());
				documentDataMap.put(FederatedDocumentRSService.UPLOAD_DOCUMENT_DESCRIPTION, cmsDocument.getDocTitle());
				documentDataMap.put("Business_Date", DateUtil.today());
				documentDataMap.put(FederatedDocumentRSService.DOC_DIRECTION, cmsDocument.getDocDirection());
				documentDataMap.put(FederatedDocumentRSService.DOC_CATEGORY, cmsDocument.getDocCategory());
				documentDataMap.put(FederatedDocumentRSService.DOC_DIRECTION, cmsDocument.getDocDirection());
				documentDataMap.put(FederatedDocumentRSService.DOC_CATEGORY, cmsDocument.getDocCategory());

				StoreDocumentsRequest storeDocReq = createStoreDocumentsRequest(documentDataMap);
				docsList.add(storeDocReq);
				
				String documentTitle = documentDataMap.get(UPLOAD_DOCUMENT_TITLE);
				byteArrayMap.put(documentTitle, new ByteArrayResource(cmsDocument.getDocContent()));
				
				docsArchvied.add(documentDataMap);
			}
		
			// 1. Create a StoreDocumentRequest with multiple attachments
			StoreDocumentsRequest newStoreDocReq = new StoreDocumentsRequest();
			for(StoreDocumentsRequest docReq :docsList){
				newStoreDocReq.getAttachments().addAll(docReq.getAttachments());
			}
			
			// 2. Set MessageConverters
			restTemplate.setMessageConverters(createMessageConverters());
			
			// 3. Add the xml and byte array to the map. First the xml request should be added.
			newMultipartMap.add(XML_FORM_NAME, createMultiDocXMLPart(newStoreDocReq));
			Iterator it = byteArrayMap.entrySet().iterator();
			    while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
			        String key = (String) pair.getKey();
			        Resource docContent = (Resource) pair.getValue();
			        HttpEntity<Resource> resource = createFilePart(documentDataMap,docContent);
			        newMultipartMap.add(key, resource);
			 }
			
			HttpEntity<MultiValueMap<String, Object>> multiDocrequest = createMultiRequestEntity(newMultipartMap);
			
			//4. Call FDRS for actual doc archival
			Map<String,String> docNameUriMap = archvieMultipleDocsInMobius(multiDocrequest);
			for(String mobiusDocName : docNameUriMap.keySet()){
				for(Map<String,String> docMap: docsArchvied){
					String docName = docMap.get(UPLOAD_DOCUMENT_TITLE);
					if(mobiusDocName.equalsIgnoreCase(docName)){
						String mobiusUri = docNameUriMap.get(mobiusDocName);
						docMap.put("MOBIUS_URI", mobiusUri);
					}
				}
			}
			
		}catch(Exception e){
			LOG.error("Error Occurred when uploading multiple documents "+e);
			throw new DocumentArchivalFailedException("Error Occurred when uploading multiple documents.Process Creation Failed ",e);
		}
		
		return docsArchvied;
	}

		private HttpEntity<MultiValueMap<String, Object>> createMultiRequestEntity(MultiValueMap<String, Object> multipartMap) throws JAXBException {
			return new HttpEntity<MultiValueMap<String, Object>>(multipartMap, createHttpHeader());
		}
		
		private Map<String,String> archvieMultipleDocsInMobius(HttpEntity<MultiValueMap<String, Object>> multiDocrequest) throws JAXBException {
			
			ResponseEntity<StoreDocumentsResponse> response = restTemplate.exchange(mobiusServiceUrl, HttpMethod.POST, multiDocrequest, StoreDocumentsResponse.class, createUrlVariableMap());
			Map<String,String> docNameUriMap = new HashMap<String,String>();
			StoreDocumentsResponse storeDocumentResponse = response.getBody();
			String status = storeDocumentResponse.getResponseStatus().getStatus();
			String responseXml = null;
			if ("SUCCESS".equals(status)) {
				responseXml = marshal(storeDocumentResponse);
				LOG.info("URI from mobius:"+storeDocumentResponse.getDocuments().getDocuments().get(0).getDocumentLocators().get(0).getValue());
				LOG.info("Uploaded Multiple documents successfully "+responseXml);
				List<StoredDocument> storeDocuments = storeDocumentResponse.getDocuments().getDocuments();
				for(StoredDocument storeDocument: storeDocuments){
					List<DocumentLocator> docLocators = storeDocument.getDocumentLocators();
					for(DocumentLocator docLocator: docLocators){
					if(docLocator.getType().equals(DocumentLocatorType.ESB_RELATIVE_URI)){
						if(docNameUriMap.containsKey(storeDocument.getArtifactName())){
							LOG.info("Document with the same name already exists:"+ storeDocument.getArtifactName());
						}
						docNameUriMap.put(storeDocument.getArtifactName(), storeDocument.getDocumentLocators().get(0).getValue());
					}
					}
				}
				//return responseXml;
				return docNameUriMap;
			}
			else{
				responseXml = marshal(storeDocumentResponse);
				LOG.error("Response status : " + status + ", xml :" + responseXml);
				throw new DocumentArchivalFailedException("federated-document-rs-v1 returned status: " + status + ", response xlm: " + responseXml);
				
			}
		}

		private HttpEntity<String> createMultiDocXMLPart(StoreDocumentsRequest request) throws JAXBException {
			// Add xml entity
			HttpHeaders xmlFileHeaders = new HttpHeaders();
			xmlFileHeaders.add("Content-type", CONTENT_TYPE_XML);
			String xml = marshal(request);
			LOG.info("FDRS MultiDocUpload - Generated XML" + xml);
			return new HttpEntity<String>(xml, xmlFileHeaders);
		}


}