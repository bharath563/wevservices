package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;
import org.tiaa.esb.case_management_rs_v2.type.Metric;

public class MetricsResultMapper extends AbstractRowMapper<Metric> implements RowMapper<Metric> {
	@Override
	public Metric mapRow(ResultSet rs, int rowNum) throws SQLException {

		Metric metric = new Metric();
		
		metric.setFieldName(getStringTrimmed(rs, "TYPE"));
		metric.setFieldValue(getStringTrimmed(rs, "CNT"));
		return metric;
	}
}
