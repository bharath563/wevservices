package org.tiaa.case_management_rs.model;

import java.util.Calendar;
import java.util.List;

public class SearchItemsVO {
	private String userId;
	private int days;
	private String ssn;
	private String pin;
	private Calendar beginDate;
	private Calendar endDate;
	private String taskstatus;
	private String taskid;
	private String deptdesc;
	private String tasktype;
	private String actdesc;
	private String workbasket;
	private int rowcount;
	private boolean usecreatedate;
	private boolean emptyworkbasket;
	private String iddesc1;
	private String field11;
	private String field12;
	private String field13;
	private String field14;
	private String iddesc2;
	private String field21;
	private String field22;
	private String field23;
	private String field24;
	private String iddesc3;
	private String field31;
	private String field32;
	private String field33;
	private String field34;
	private int result;
	private List<SortCriteriaVO> sortCriteria;
	private boolean isClosedStatus;
	private boolean isCompletedStatus;


	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public int getDays() {
		return this.days;
	}

	public void setDays(int days) {
		this.days = days;
	}
	public int getresult() {
		return result;
	}

	public void setresult(int result) {
		this.result = result;}

	public String getSsn() {
		return this.ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getPin() {
		return this.pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public Calendar getBeginDate() {
		return this.beginDate;
	}

	public void setBeginDate(Calendar beginDate) {
		this.beginDate = beginDate;
	}

	public Calendar getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Calendar endDate) {
		this.endDate = endDate;
	}

	public String getTaskstatus() {
		return this.taskstatus;
	}

	public void setTaskstatus(String taskstatus) {
		this.taskstatus = taskstatus;
	}

	public String getTaskid() {
		return this.taskid;
	}

	public void setTaskid(String taskid) {
		this.taskid = taskid;
	}

	public String getDeptdesc() {
		return this.deptdesc;
	}

	public void setDeptdesc(String deptdesc) {
		this.deptdesc = deptdesc;
	}

	public String getTasktype() {
		return this.tasktype;
	}

	public void setTasktype(String tasktype) {
		this.tasktype = tasktype;
	}

	public String getActdesc() {
		return this.actdesc;
	}

	public void setActdesc(String actdesc) {
		this.actdesc = actdesc;
	}

	public String getWorkbasket() {
		return this.workbasket;
	}

	public void setWorkbasket(String workbasket) {
		this.workbasket = workbasket;
	}

	public int getRowcount() {
		return this.rowcount;
	}

	public void setRowcount(int rowcount) {
		this.rowcount = rowcount;
	}

	public boolean isUsecreatedate() {
		return this.usecreatedate;
	}

	public void setUsecreatedate(boolean usecreatedate) {
		this.usecreatedate = usecreatedate;
	}

	public boolean isEmptyworkbasket() {
		return this.emptyworkbasket;
	}

	public void setEmptyworkbasket(boolean emptyworkbasket) {
		this.emptyworkbasket = emptyworkbasket;
	}

	public String getIddesc1() {
		return this.iddesc1;
	}

	public void setIddesc1(String iddesc1) {
		this.iddesc1 = iddesc1;
	}

	public String getField11() {
		return this.field11;
	}

	public void setField11(String field11) {
		this.field11 = field11;
	}

	public String getField12() {
		return this.field12;
	}

	public void setField12(String field12) {
		this.field12 = field12;
	}

	public String getField13() {
		return this.field13;
	}

	public void setField13(String field13) {
		this.field13 = field13;
	}

	public String getField14() {
		return this.field14;
	}

	public void setField14(String field14) {
		this.field14 = field14;
	}

	public String getIddesc2() {
		return this.iddesc2;
	}

	public void setIddesc2(String iddesc2) {
		this.iddesc2 = iddesc2;
	}

	public String getField21() {
		return this.field21;
	}

	public void setField21(String field21) {
		this.field21 = field21;
	}

	public String getField22() {
		return this.field22;
	}

	public void setField22(String field22) {
		this.field22 = field22;
	}

	public String getField23() {
		return this.field23;
	}

	public void setField23(String field23) {
		this.field23 = field23;
	}

	public String getField24() {
		return this.field24;
	}

	public void setField24(String field24) {
		this.field24 = field24;
	}

	public String getIddesc3() {
		return this.iddesc3;
	}

	public void setIddesc3(String iddesc3) {
		this.iddesc3 = iddesc3;
	}

	public String getField31() {
		return this.field31;
	}

	public void setField31(String field31) {
		this.field31 = field31;
	}

	public String getField32() {
		return this.field32;
	}

	public void setField32(String field32) {
		this.field32 = field32;
	}

	public String getField33() {
		return this.field33;
	}

	public void setField33(String field33) {
		this.field33 = field33;
	}

	public String getField34() {
		return this.field34;
	}

	public void setField34(String field34) {
		this.field34 = field34;
	}

	public List<SortCriteriaVO> getSortCriteria() {
		return sortCriteria;
	}

	public void setSortCriteria(List<SortCriteriaVO> sortCriteria) {
		this.sortCriteria = sortCriteria;
	}

	public boolean isClosedStatus() {
		return isClosedStatus;
	}

	public void setClosedStatus(boolean isClosedStatus) {
		this.isClosedStatus = isClosedStatus;
	}

	public boolean isCompletedStatus() {
		return isCompletedStatus;
	}

	public void setCompletedStatus(boolean isCompletedStatus) {
		this.isCompletedStatus = isCompletedStatus;
	}

}
