package org.tiaa.case_management_rs.email.plan_modification_request;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.domain.CMRSEvent;
import org.tiaa.case_management_rs.domain.CMSAudit;
import org.tiaa.case_management_rs.domain.CMSAuditHistory;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.email.EmailBuilder;
import org.tiaa.case_management_rs.email.EmailConfiguration;
import org.tiaa.case_management_rs.email.EmailSender;
import org.tiaa.case_management_rs.integration.cth.CTHRecordRetriever;
import org.tiaa.case_management_rs.integration.exp_ag.AbstractEXPAGTaskProcessor;
import org.tiaa.case_management_rs.integration.exp_ag.EXPAGTaskProcessor;
import org.tiaa.case_management_rs.integration.plan_sponsor.PlanSponosrRSService;
import org.tiaa.case_management_rs.syncup.service_request.ServiceRequesJaxbMarshaller;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.partyrequest.types.AdditionalRequestIdentifier;
import org.tiaa.esb.partyrequest.types.AdditionalRequestIdentifiers;
import org.tiaa.esb.partyrequest.types.PartyRequestResponse;
import org.tiaa.esb.plansponsor.types.AuthorizationType;
import org.tiaa.esb.plansponsor.types.AuthorizationTypes;
import org.tiaa.esb.plansponsor.types.Client;
import org.tiaa.esb.plansponsor.types.ClientRelationship;
import org.tiaa.esb.plansponsor.types.ClientRelationships;
import org.tiaa.esb.plansponsor.types.Contact;
import org.tiaa.esb.plansponsor.types.ContactPlan;
import org.tiaa.esb.plansponsor.types.ContactPlans;
import org.tiaa.esb.plansponsor.types.ContactResp;
import org.tiaa.esb.plansponsor.types.ContactResponse;
import org.tiaa.esb.plansponsor.types.Contacts;
import org.tiaa.esb.plansponsor.types.EmailAddress;
import org.tiaa.esb.plansponsor.types.EmailAddresses;
import org.tiaa.esb.plansponsor.types.Employer;
import org.tiaa.esb.plansponsor.types.Name;
import org.tiaa.esb.plansponsor.types.Plan;
import org.tiaa.esb.plansponsor.types.Role;
import org.tiaa.esb.plansponsor.types.Roles;
import org.tiaa.esb.plansponsor.types.UUPSearchResponse;
import org.tiaa.esb.servicerequest.types.CTHClob;
import org.tiaa.esb.servicerequest_workflow.types.NameValuePairType;

@Component
public class PlanModificationTaskCreationProcessor extends AbstractEXPAGTaskProcessor implements EXPAGTaskProcessor {
	private static final Logger LOG = LoggerFactory.getLogger(PlanModificationTaskCreationProcessor.class);
	@Autowired
	private PlanSponosrRSService planSponosrRSService;
	@Autowired
	private EmailSender emailSender;
	@Autowired
	private EmailConfiguration emailConfiguration;
	@Autowired
	private CTHRecordRetriever cthRecordRetriever;
	@Autowired
	private ServiceRequesJaxbMarshaller serviceRequesJaxb2Marshaller;
	@Value("${racf.environment}")
	private String racfEnvironment;
	@Value("${email.from.planModificationRequest}")
	private String from;

	public void processTask(TaskInfo taskInfo) {
		CMSAuditHistory cmsAuditHistory = cmsAuditService.createCMSAuditHistory(taskInfo);
		cmsAuditHistory.setEvent(CMRSEvent.SEND_PLAN_MODIFICATION_EMAIL);
		processTask(taskInfo, cmsAuditHistory);
	}

	public CMSAuditHistory processTask(TaskInfo taskInfo, PartyRequestResponse partyRequestResponse) {
		CMSAuditHistory cmsAuditHistory = cmsAuditService.createCMSAuditHistory(taskInfo);
		cmsAuditHistory.setEvent(CMRSEvent.SEND_PLAN_MODIFICATION_EMAIL);
		if (partyRequestResponse == null && cmsAuditHistory.getCmsAudit().hasCthOrchestrationId()) {
			partyRequestResponse = cthRecordRetriever.getCTHRecord(taskInfo);
		}
		processTask(taskInfo, cmsAuditHistory, partyRequestResponse);
		return cmsAuditHistory;
	}

	public void processTask(TaskInfo taskInfo, CMSAuditHistory cmsAuditHistory) {
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		if (cmsAudit.isEmailSent()) {
			cmsAuditHistory.setComments("Email already sent for Task: " + taskInfo.getTaskId());
			cmsAuditService.markAsSuccessful(cmsAuditHistory);
			LOG.debug("Email already sent for Task: {}", taskInfo.getTaskId());
			return;
		}
		PartyRequestResponse partyRequestResponse = cmsAudit.hasCthOrchestrationId() ? cthRecordRetriever.getCTHRecord(taskInfo) : null;
		processTask(taskInfo, cmsAuditHistory, partyRequestResponse);
	}

	public void processTask(TaskInfo taskInfo, CMSAuditHistory cmsAuditHistory, PartyRequestResponse partyRequestResponse) {
		CMSAudit cmsAudit = cmsAuditHistory.getCmsAudit();
		cmsAudit.setSendEmail(true);
		cmsAudit.setUpdateCthRequestId(true);
		//
		PlanModificationTaskCreationContext context = new PlanModificationTaskCreationContext();
		context.setCmsAuditHistory(cmsAuditHistory);
		context.setTaskInfo(taskInfo);
		context.setPartyRequestResponse(partyRequestResponse);
		//
		String taskId = taskInfo.getTaskId();
		LOG.debug("Processing Task: {} : {} : {}", taskId, taskInfo.getTaskStatusAsStr(), taskInfo.getDocuments().size());
		try {
			String planNumber = taskInfo.getPlanNumber();
			UUPSearchResponse uupSearchResponse = planSponosrRSService.searchUUP(planNumber);
			retrivePlanInfo(context, uupSearchResponse);
			//
			Properties contactSheetAsProperties = getContactSheetAsPropertiesFromCTH(context);
			context.setContactSheetAsProperties(contactSheetAsProperties);
			//
			LOG.debug("contactSheetAsProperties: {}", contactSheetAsProperties);
			Map<String, Object> variables = createEmailTemplateInputData(context);
			String email = isTestEnvironment() ? new EmailBuilder("PlanModificationTemplate.html").executeTemplate(variables) :
								new EmailBuilder("PlanModificationTemplateProd.html").executeTemplate(variables);
			LOG.debug("Email html: {}", email);
			String[] to = isTestEnvironment() ? unique(emailConfiguration.getDistributionArray()) : context.getRMandCMEmailAddresses();

			if (to.length != 0 && context.getRMandCMEmailAddresses().length != 0) {
				emailSender.sendEmail(from, to, "Plan modification request submitted", email);
				cmsAuditHistory.setComments("plan modification email sent");
			} else {
				LOG.warn("no RM/CM info associated with plan number {}", planNumber);
				cmsAuditHistory.setComments("no RM/CM info associated with plan " + planNumber + " or not direct segment");
			}
			//
			cmsAudit.setEmailSent(true);// regardless mark it as email sent out,
										// as retry will look for this flag
			cmsAuditService.markAsSuccessful(cmsAuditHistory);
			LOG.debug("successfully sent email for task id:{}", taskId);
		} catch (Exception e) {
			LOG.debug("failed to send email for task id:{}", taskId);
			LOG.warn(e.getMessage(), e);
			cmsAuditService.markAsFailed(cmsAuditHistory, e);
		}
	}

	private Map<String, Object> createEmailTemplateInputData(PlanModificationTaskCreationContext planModificationTaskCreationContext) {
		Properties contactSheetAsProperties = planModificationTaskCreationContext.getContactSheetAsProperties();
		//
		Map<String, Object> variables = new LinkedHashMap<String, Object>();
		variables.put("dateTime", propertyValue(contactSheetAsProperties, "Date Time", DateUtil.getCurrentDateInMMDDYYYY()));
		variables.put("requestType", propertyValue(contactSheetAsProperties, "Request Type", "Plan Modification Request"));
		variables.put("planId", propertyValue(contactSheetAsProperties, "Plan Id", planModificationTaskCreationContext.getPlanNumber()));
		variables.put("planName", propertyValue(contactSheetAsProperties, "Plan Name", planModificationTaskCreationContext.getPlanName()));
		variables.put("customerName", propertyValue(contactSheetAsProperties, "Customer Name", ""));
		variables.put("action", propertyValue(contactSheetAsProperties, "Action", "NEW REQUEST"));
		variables.put("comments", propertyValue(contactSheetAsProperties, "Comments", ""));
		variables.put("effectiveDate", propertyValue(contactSheetAsProperties, "Effective Date", ""));
		variables.put("planSectionsBeingChanged", propertyValue(contactSheetAsProperties, "Plan Section(s) Being Changed", ""));
		variables.put("areYouUsingTIAAPlanDoc", propertyValue(contactSheetAsProperties, "Are you using a TIAA-CREF plan document", ""));
		//variables.put("showRMAndCMDetails", isTestEnvironment() ? "block" : "none");
		variables.put("contactDetails", getContactDetails(planModificationTaskCreationContext));
		return variables;
	}

	private String getContactDetails(PlanModificationTaskCreationContext planModificationTaskCreationContext) {
		if (!isTestEnvironment()) {
			return "";
		}
		final String contactInfoTemplate = "<tr><td><b>%s</b></td><td>%s</td><td>%s</td></tr>";
		StringBuilder stringBuilder = new StringBuilder();
		for (ContactInfo contactInfo : planModificationTaskCreationContext.getRelationshipAndCaseManagersSortedByRole()) {
			stringBuilder.append(String.format(contactInfoTemplate, contactInfo.getRole(), contactInfo.getName(), contactInfo.getEmailAddress()));
		}
		return stringBuilder.toString();
	}

	private void retrivePlanInfo(PlanModificationTaskCreationContext planModificationTaskCreationContext, UUPSearchResponse uupSearchResponse) {
		List<Client> clients = uupSearchResponse.getUUPSearchResp().getUUPData().getClients().getClients();
		if (clients.isEmpty()) {
			return;
		}
		// get the first client, there will be only one client mapped to a given
		// plan number
		Client client = clients.get(0);
		String institutionalSegment = client.getInstitutionalSegment();
		String institutionalSubSegment = client.getInstitutionalSubSegment();
		LOG.warn("institution segment is {}, institution sub segment is {}", institutionalSegment, institutionalSubSegment);
		if (!("Direct".equals(institutionalSegment)
						&& ("Virtual East".equals(institutionalSubSegment) || "Virtual West".equals(institutionalSubSegment)))) {// select market segment
			LOG.warn("institution segment is {}, institution sub segment is {}, not processing further", institutionalSegment, institutionalSubSegment);
			return;
		}
		String planNumber = planModificationTaskCreationContext.getPlanNumber();
		// plan details from any employer should be fine as only Plan name will
		// be used
		planModificationTaskCreationContext.setPlan(findPlanByPlanNumber(client, planNumber));
		//
		ContactResponse contactResponse = planSponosrRSService.searchContact(client.getClientID());
		extractEmailIds(planModificationTaskCreationContext, client, contactResponse);
	}

	private void extractEmailIds(PlanModificationTaskCreationContext planModificationTaskCreationContext, Client client,
					ContactResponse contactResponse) {
		// For RM use IC-21 Role
		// For CM use IC-49 Role
		//
		Collection<ContactInfo> relationshipAndCaseManagers = planModificationTaskCreationContext.getRelationshipAndCaseManagers();
		String planNumber = planModificationTaskCreationContext.getPlanNumber();
		//
		ContactResp contactResp = contactResponse.getContactResp();
		if (contactResp == null) {
			return;
		}
		Contacts contacts = contactResp.getContacts();
		if (contacts == null) {
			return;
		}
		for (Contact contact : contacts.getContacts()) {
			boolean relationshipManager = false;
			boolean caseManager = false;
			ClientRelationships clientRelationships = contact.getClientRelationships();
			if (clientRelationships != null) {
				for (ClientRelationship clientRelationship : clientRelationships.getClientRelationships()) {
					ContactPlans plans = clientRelationship.getPlans();
					if (plans != null) {
						for (ContactPlan contactPlan : plans.getPlen()) {
							if (contactPlan.getPlanNumber().equals(planNumber)) {
								AuthorizationTypes authorizationTypes = contactPlan.getAuthorizationTypes();
								if (authorizationTypes != null) {
									for (AuthorizationType authorizationType : authorizationTypes.getAuthorizationTypes()) {
										Roles roles = authorizationType.getRoles();
										if (roles != null) {
											for (Role role : roles.getRoles()) {
												String name = role.getName();
												if ("IC-21".equals(name)) {// RM
													relationshipManager = true;
													break;
												} else if ("IC-49".equals(name)) {// CM
													caseManager = true;
													break;
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			if (relationshipManager || caseManager) {
				EmailAddresses emailAddresses = contact.getEmailAddresses();
				if (emailAddresses != null) {
					for (EmailAddress emailAddress : emailAddresses.getEmailAddresses()) {
						ContactInfo contactInfo = new ContactInfo();
						contactInfo.setEmailAddress(emailAddress.getAddress());
						//
						Name name = contact.getName();
						contactInfo.setName(name.getFirstName() + " " + name.getLastName());
						if (relationshipManager) {
							contactInfo.setRole("RM");
							relationshipAndCaseManagers.add(contactInfo);
						}
						if (caseManager) {
							contactInfo.setRole("CM");
							relationshipAndCaseManagers.add(contactInfo);
						}
					}
				}
			}
		}
	}

	private Properties getContactSheetAsPropertiesFromCTH(PlanModificationTaskCreationContext planModificationTaskCreationContext) {
		Properties contactSheetAsProperties = new Properties();
		PartyRequestResponse partyRequestResponse = planModificationTaskCreationContext.getPartyRequestResponse();
		if (partyRequestResponse == null) {
			return contactSheetAsProperties;
		}
		CTHClob cthClob = serviceRequesJaxb2Marshaller.getCTHClob(partyRequestResponse);
		contactSheetAsProperties.setProperty("Comments", serviceRequesJaxb2Marshaller.getRequestDescription(cthClob));
		for (AdditionalRequestIdentifier additionalRequestIdentifier : getAdditionalRequestIdentifiers(partyRequestResponse)) {
			contactSheetAsProperties.setProperty(additionalRequestIdentifier.getKey(), additionalRequestIdentifier.getValue());
		}
		for (NameValuePairType nameValuePairType : serviceRequesJaxb2Marshaller.getIdentifierTypes(cthClob)) {
			contactSheetAsProperties.setProperty(nameValuePairType.getName(), nameValuePairType.getValue());
		}
		String firstName = propertyValue(contactSheetAsProperties, "FirstName", "");
		String lastName = propertyValue(contactSheetAsProperties, "LastName", "");
		contactSheetAsProperties.setProperty("Customer Name", firstName + " " + lastName);
		return contactSheetAsProperties;
	}

	private Plan findPlanByPlanNumber(Client client, String planNumber) {
		for (Employer employer : client.getEmployers().getEmployers()) {
			for (Plan plan : employer.getPlans().getPlen()) {
				if (planNumber.equals(plan.getPlanNumber())) {
					return plan;
				}
			}
		}
		return null;
	}

	private boolean isTestEnvironment() {
		return "dev".equals(racfEnvironment);
	}

	private String propertyValue(Properties properties, String propertyName, String defaultValue) {
		String propertyValue = properties.getProperty(propertyName);
		if (propertyValue == null) {
			return defaultValue;
		}
		return propertyValue.trim();
	}

	public static String[] unique(String[] strs) {
		TreeSet<String> set = new TreeSet<String>();
		for (String string : strs) {
			set.add(string);
		}
		return set.toArray(new String[set.size()]);
	}

	private List<AdditionalRequestIdentifier> getAdditionalRequestIdentifiers(PartyRequestResponse partyRequestResponse) {
		AdditionalRequestIdentifiers additionalRequestIdentifiers = partyRequestResponse.getAdditionalRequestIdentifiers();
		if (additionalRequestIdentifiers == null) {
			return Collections.emptyList();
		}
		return additionalRequestIdentifiers.getAdditionalRequestIdentifiers();
	}

}