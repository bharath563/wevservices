package org.tiaa.case_management_rs.validator.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.apache.commons.lang3.StringUtils;

import org.tiaa.case_management_rs.common.Request;

public class GetDocumentsValidator extends BaseValidatorImpl {

	@Override
	public void doValidate(Request request) {

		String userId = (String) request.getAttribute(USER_ID);
		String taskId = (String) request.getAttribute(PROCESS_ID);
		String caseId = (String) request.getAttribute(CASE_ID);

		if (StringUtils.isBlank(userId)) {
			handleException(VALIDATION_USERID_IS_EMPTY);
		}

		if (StringUtils.isBlank(taskId) && StringUtils.isBlank(caseId)) {
			handleException(VALIDATION_BOTH_TASKID_CASID_IS_EMPTY);
		}

	}
}
