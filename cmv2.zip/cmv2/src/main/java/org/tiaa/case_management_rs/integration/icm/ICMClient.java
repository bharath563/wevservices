package org.tiaa.case_management_rs.integration.icm;

import java.util.Arrays;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

public class ICMClient  extends RestTemplate {

	private static HttpEntity<String> entity = null;
	private static HttpHeaders headers = new HttpHeaders();
	
	static {
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		// headers.set("racfId", "tst_p8cm01");
		// headers.set("password", "Spring2016");
	}

	public ICMClient() {
		super();
		headers.set("racfId", "tst_p8cm01");
	}	

}
