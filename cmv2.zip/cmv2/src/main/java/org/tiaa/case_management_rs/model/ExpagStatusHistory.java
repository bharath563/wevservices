package org.tiaa.case_management_rs.model;

import java.io.Serializable;

public class ExpagStatusHistory implements Serializable {

	/** Serial Version Id  **/
	private static final long serialVersionUID = 1201640933066510760L;
	private String taskId;
	private String startdatetime;
	private String enddatetime;
	private String operid;
	private String assignedto;
	private String status;
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getStartdatetime() {
		return startdatetime;
	}
	public void setStartdatetime(String startdatetime) {
		this.startdatetime = startdatetime;
	}
	public String getEnddatetime() {
		return enddatetime;
	}
	public void setEnddatetime(String enddatetime) {
		this.enddatetime = enddatetime;
	}
	public String getOperid() {
		return operid;
	}
	public void setOperid(String operid) {
		this.operid = operid;
	}
	public String getAssignedto() {
		return assignedto;
	}
	public void setAssignedto(String assignedto) {
		this.assignedto = assignedto;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "ExpagStatusHistory [taskId=" + taskId + ", startdatetime="
				+ startdatetime + ", enddatetime=" + enddatetime + ", operid="
				+ operid + ", assignedto=" + assignedto + ", status=" + status + "]";
	}
	
}
