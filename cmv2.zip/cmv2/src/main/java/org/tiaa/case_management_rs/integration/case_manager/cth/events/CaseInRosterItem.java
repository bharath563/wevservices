package org.tiaa.case_management_rs.integration.case_manager.cth.events;

public class CaseInRosterItem {
	private String orchestrationId;
	private String requestId;
	private String correlationId;
	private String caseId;
	private String solutionType;
	private String channel;
	private String caseType;
	private String status;
	private String taskOperation;
	private String recievedDateTime;
	private String channelPutTime;
	private String responseRequired;
	private String processType;
	private String originatorId;
	private String processingPriority;
	private String cmHostName;
	private String InputPayload;
	private String dispatchedDateTime;
	private String processedDateTime;

	public String getOrchestrationId() {
		return this.orchestrationId;
	}

	public void setOrchestrationId(String orchestrationId) {
		this.orchestrationId = orchestrationId;
	}

	public String getRequestId() {
		return this.requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getCorrelationId() {
		return this.correlationId;
	}

	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	public String getCaseId() {
		return this.caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getSolutionType() {
		return this.solutionType;
	}

	public void setSolutionType(String solutionType) {
		this.solutionType = solutionType;
	}

	public String getChannel() {
		return this.channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getCaseType() {
		return this.caseType;
	}

	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTaskOperation() {
		return this.taskOperation;
	}

	public void setTaskOperation(String taskOperation) {
		this.taskOperation = taskOperation;
	}

	public String getRecievedDateTime() {
		return this.recievedDateTime;
	}

	public void setRecievedDateTime(String recievedDateTime) {
		this.recievedDateTime = recievedDateTime;
	}

	public String getChannelPutTime() {
		return this.channelPutTime;
	}

	public void setChannelPutTime(String channelPutTime) {
		this.channelPutTime = channelPutTime;
	}

	public String getResponseRequired() {
		return this.responseRequired;
	}

	public void setResponseRequired(String responseRequired) {
		this.responseRequired = responseRequired;
	}

	public String getProcessType() {
		return this.processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}

	public String getOriginatorId() {
		return this.originatorId;
	}

	public void setOriginatorId(String originatorId) {
		this.originatorId = originatorId;
	}

	public String getProcessingPriority() {
		return this.processingPriority;
	}

	public void setProcessingPriority(String processingPriority) {
		this.processingPriority = processingPriority;
	}

	public String getCmHostName() {
		return this.cmHostName;
	}

	public void setCmHostName(String cmHostName) {
		this.cmHostName = cmHostName;
	}

	public String getInputPayload() {
		return this.InputPayload;
	}

	public void setInputPayload(String inputPayload) {
		this.InputPayload = inputPayload;
	}

	public String getDispatchedDateTime() {
		return this.dispatchedDateTime;
	}

	public void setDispatchedDateTime(String dispatchedDateTime) {
		this.dispatchedDateTime = dispatchedDateTime;
	}

	public String getProcessedDateTime() {
		return this.processedDateTime;
	}

	public void setProcessedDateTime(String processedDateTime) {
		this.processedDateTime = processedDateTime;
	}

	@Override
	public String toString() {
		return "CaseInRosterItem [orchestrationId=" + orchestrationId + ", requestId=" + requestId + ", correlationId=" + correlationId + ", caseId=" + caseId + ", solutionType="
				+ solutionType + ", channel=" + channel + ", caseType=" + caseType + ", status=" + status + ", taskOperation=" + taskOperation + ", recievedDateTime="
				+ recievedDateTime + ", channelPutTime=" + channelPutTime + ", responseRequired=" + responseRequired + ", processType=" + processType + ", originatorId="
				+ originatorId + ", processingPriority=" + processingPriority + ", cmHostName=" + cmHostName + ", InputPayload=" + InputPayload + ", dispatchedDateTime="
				+ dispatchedDateTime + ", processedDateTime=" + processedDateTime + "]";
	}
}
