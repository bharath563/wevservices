package org.tiaa.case_management_rs.integration.exp_ag;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.RetryException;
import org.springframework.retry.backoff.FixedBackOffPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Service;

import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.email.EmailSender;
import org.tiaa.case_management_rs.email.EmailUtil;
import org.tiaa.case_management_rs.exception.CaseManagementRuntimeException;
import org.tiaa.case_management_rs.expag.helper.ExpagDocumentHelper;
import org.tiaa.case_management_rs.integration.cth.CTHWSRetryConfiguration;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.PowerImageService;
import org.tiaa.case_management_rs.integration.exp_ag.power_image.WorkflowException;
import org.tiaa.case_management_rs.integration.federeated_document.DocumentArchivalFailedException;
import org.tiaa.case_management_rs.integration.federeated_document.FederatedDocumentRSService;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.Document;
import org.tiaa.esb.servicerequest_workflow.types.DocumentIDType;
import org.tiaa.esb.servicerequest_workflow.types.DocumentIDsType;
import org.tiaa.esb.servicerequest_workflow.types.DocumentType;

@Service
public class DocumentCopier {
	private static final Logger LOG = LoggerFactory.getLogger(DocumentCopier.class);
	@Autowired
	private FederatedDocumentRSService federatedDocumentRSService;
	@Autowired
	private ExpagDocumentHelper expagDocumentHelper;
	@Autowired
	private PowerImageService powerImageService;
	private boolean copyDocumentsEnabled = true;
	private RetryTemplate retryTemplate;
	@Autowired
	private CTHWSRetryConfiguration cthWSRetryConfiguration;
	@Autowired
	private EmailSender emailSender;

	@PostConstruct
	public void init() {
		retryTemplate = fdrsRetryTemplate();
	}

	private RetryTemplate fdrsRetryTemplate() {
		HashMap<Class<? extends Throwable>, Boolean> retryableExceptionMap = new HashMap<Class<? extends Throwable>, Boolean>();
		retryableExceptionMap.put(RetryException.class, Boolean.TRUE);
		//
		SimpleRetryPolicy simpleRetryPolicy = new SimpleRetryPolicy(cthWSRetryConfiguration.getRetryAttempts(), retryableExceptionMap);
		//
		FixedBackOffPolicy fixedBackOffPolicy = new FixedBackOffPolicy();
		fixedBackOffPolicy.setBackOffPeriod(cthWSRetryConfiguration.getBackOffPeriod());
		//
		RetryTemplate retryTemplate = new RetryTemplate();
		retryTemplate.setBackOffPolicy(fixedBackOffPolicy);
		retryTemplate.setRetryPolicy(simpleRetryPolicy);
		return retryTemplate;
	}

	public void copyDocumentsFromEXPAGToMobius(TaskInfo task) {
		if (!copyDocumentsEnabled) {
			return;
		}
		ArrayList<DocumentType> documentsArchivedInMobius = new ArrayList<DocumentType>();
		for (DocumentType documentType : task.getDocuments()) {
			DocumentType archivedDocumentType = copyDocumentFromEXPAGToMobius(task, documentType);
			if (archivedDocumentType != null) {
				documentsArchivedInMobius.add(archivedDocumentType);
			}
		}
		task.setDocuments(documentsArchivedInMobius);
	}

	public DocumentType copyDocumentFromEXPAGToMobius(TaskInfo task, DocumentType documentType) {
		DocumentType archivedDocumentType = null;
		if (documentType instanceof EXPAGDocument) {
			Document expAGDocument = getExpAGDocument(task, documentType);
			if (expAGDocument == null) {
				// comment the code below to skip putting exp-ag document
				// info in CT
				archivedDocumentType = documentType;
			} else {
				archivedDocumentType = archiveDocument(task, documentType, expAGDocument);
				if (archivedDocumentType == documentType) {
					// document failed archival
					LOG.warn("document failed archival {}", documentType);
				}
			}
		}
		return archivedDocumentType;
	}

	private DocumentType archiveDocument(TaskInfo task, DocumentType documentType, Document expAGDocument) {
		try {
			EXPAGDocument expAGDocumentType = (EXPAGDocument) documentType;
			if (expAGDocument.getDocContent() != null && expAGDocument.getMimeTyp() != null && expAGDocument.getDocContent() != null) { //expAGDocument.getDocumentStream() != null
				return retryStoreDocumentInMobius(expAGDocument, expAGDocumentType, task);
			} else {
				LOG.warn("document stream is null");
			}
		} catch (DocumentArchivalFailedException e) {
			LOG.warn(e.getMessage(), e);
			emailSender.sendEmailToProdSupport("Document archival failed:" + getDocumentId(documentType), EmailUtil.createEmail(e));
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
			emailSender.sendEmailToProdSupport("Document archival failed:" + getDocumentId(documentType), EmailUtil.createEmail(e));
		}
		return documentType;
	}

	private DocumentType retryStoreDocumentInMobius(final Document document, final EXPAGDocument expAGDocumentType, final TaskInfo taskInfo)
					throws Exception {
		return retryTemplate.execute(new RetryCallback<DocumentType>() {
			@Override
			public DocumentType doWithRetry(RetryContext retryContext) {
				return storeDocumentInMobius(document, expAGDocumentType, taskInfo);
			}
		});
	}

	private DocumentType storeDocumentInMobius(Document document, EXPAGDocument expAGDocumentType, TaskInfo taskInfo) {
//		DocumentStream documentStream = document.getDocumentStream();
		//
		Map<String, String> documentDataMap = new HashMap<String, String>();
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_PLAN_NUMBER, taskInfo.getPlanNumber());
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_ORCH_ID, taskInfo.getCthOrchestrationId());
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_CLIENT_ID, taskInfo.getClientId());
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_CUSTOMER_NUMBER, taskInfo.getCustomerNumber());
//		documentDataMap.put(FederatedDocumentRSService.UPLOAD_MIME_TYPE, documentStream.getMimetype());
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_MIME_TYPE, document.getMimeTyp());
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_DOCUMENT_TITLE, expAGDocumentType.getDocumentId());
//		documentDataMap.put(FederatedDocumentRSService.UPLOAD_FILE_NAME, document.getDocumentName());
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_FILE_NAME, document.getDocName());
		documentDataMap.put(FederatedDocumentRSService.UPLOAD_BUSINESS_DATE, DateUtil.toFormat(expAGDocumentType.getBusinessDate(), "yyyyMMdd"));
		//
//		federatedDocumentRSService.archiveDocumentInMobius(documentDataMap, new ByteArrayResource(documentStream.getValue()));
		federatedDocumentRSService.archiveDocumentInMobius(documentDataMap, new ByteArrayResource(document.getDocContent()));
		return mobiusDocumentType(taskInfo, expAGDocumentType, documentDataMap);
	}

	private Document getExpAGDocument(TaskInfo task, DocumentType documentType) {
		LOG.debug("expAGDocument:" + ReflectionToStringBuilder.toString(documentType));
		final String documentId = getDocumentId(documentType);
		try {
			return retrieveExpAGDocument(task, documentType);
		} catch (CaseManagementRuntimeException e) {
			LOG.warn(e.getMessage(), e);
			emailSender.sendEmailToProdSupport("Fetching EXPAG document failed:" + documentId, EmailUtil.createEmail(e));
		} catch (WorkflowException e) {
			LOG.warn(e.getMessage(), e);
			emailSender.sendEmailToProdSupport("Fetching EXPAG document failed:" + documentId, EmailUtil.createEmail(e));
		} catch (Exception e) {
			LOG.warn(e.getMessage(), e);
			emailSender.sendEmailToProdSupport("Fetching EXPAG document failed:" + documentId, EmailUtil.createEmail(e));
		}
		return null;
	}

	private Document retrieveExpAGDocument(TaskInfo taskInfo, DocumentType documentType) {
		String documentId = getDocumentId(documentType);
		String externalDocumentKey = documentType.getExternalDocumentKey();
		if (StringUtils.isNotEmpty(externalDocumentKey)) {
//			DocumentStream documentStream = new DocumentStream();
//			documentStream.setEncoding(BASE64BINARY);
//			documentStream.setMimetype(TEXT_PDF);
//			documentStream.setValue(expagDocumentHelper.getPDFDocument(documentId, externalDocumentKey));
			//
			Document document = new Document();
			document.setDocTemplateCd(BASE64BINARY);
			document.setMimeTyp(TEXT_PDF);
			document.setDocContent(expagDocumentHelper.getPDFDocument(documentId, externalDocumentKey));
//			document.setDocumentStream(documentStream);
//			document.setDocumentName(documentId);
			document.setDocName(documentId);
			document.setDocURL(externalDocumentKey);
			//
			return document;
		}
		return getDocumentByDocumentId(documentId);
	}

	public String getDocumentContents(DocumentType contactSheet) {
		String documentContents = null;
		String documentId = getDocumentId(contactSheet);
		if (contactSheet != null) {
			Document contactSheetDocument = getDocumentByDocumentId(documentId);
//			DocumentStream documentStream = contactSheetDocument.getDocumentStream();
//			byte[] value = documentStream.getValue();
			byte[] value = contactSheetDocument.getDocContent();
			documentContents = new String(value);
		}
		return documentContents;
	}

	public byte[] getDocumentContentsAsByteArray(DocumentType contactSheet) {
		String documentId = getDocumentId(contactSheet);
		Document contactSheetDocument = getDocumentByDocumentId(documentId);
//		DocumentStream documentStream = contactSheetDocument.getDocumentStream();
//		return documentStream != null? documentStream.getValue() : new byte[0];
		return contactSheetDocument.getDocContent() != null? contactSheetDocument.getDocContent() : new byte[0];
	}

	public Document getDocumentByDocumentId(String documentId) {
		try {
			final String userId = "isvoper";
			org.tiaa.esb.powerimage.types.Document expagDocument = powerImageService.getDocument(userId, documentId);
			return expagDocumentHelper.getDocumentContentFromExpagDocument(expagDocument);
		} catch (WorkflowException e) {
			LOG.warn(e.getMessage(), e);
			throw e;
		}
	}

	public DocumentType mobiusDocumentType(TaskInfo taskInfo, EXPAGDocument expAGDocumentType, Map<String, String> documentMap) {
		DocumentType copy = new DocumentType();
		copy.setBusinessUnit(FederatedDocumentRSService.BIZ_UNIT);
		copy.setDocumentCode(FederatedDocumentRSService.DOC_CODE);
		copy.setDocumentVersion(FederatedDocumentRSService.DOC_VERSION);
		//
		copy.setDocumentStorageSystem("MOBIUS");
		copy.setDocumentIDs(createDocumentIds(documentMap.get(FederatedDocumentRSService.UPLOAD_DRI)));
		//
		copy.setOriginalDocumentStorageSystem("EXP_AG");
		copy.setOriginalDocumentID(expAGDocumentType.getDocumentId());
		//
		copy.setBusinessDate(expAGDocumentType.getBusinessDate());
		copy.setDocumentCategoryType(expAGDocumentType.getDocumentCategoryType());
//		copy.setDocumentType(documentMap.get(FederatedDocumentRSService.UPLOAD_DOCUMENT_TITLE));
		copy.setDocumentType(expAGDocumentType.getDocumentCategoryType() + "_" + DateUtil.getCurrentDateInDateTime() + "." + 				FilenameUtils.getExtension(expAGDocumentType.getDocumentId()));
		//
		copy.setDocumentDirection(getDocumentDirection(expAGDocumentType));
		//
		String documentStatus = expAGDocumentType.getDocumentStatus();
		String docStatus = CommonUtil.isNullOrEmpty(documentStatus) ? "REQUIRED": documentStatus;
		copy.setDocumentStatus(docStatus);
		//
		return copy;
	}

	private String getDocumentDirection(EXPAGDocument expAGDocumentType) {
		String documentCategoryType = expAGDocumentType.getDocumentCategoryType();
		if ("CORRESPONDENCE - INBOUND".equals(documentCategoryType)) {
			return "Inbound";
		} else if("CORRESPONDENCE - OUTBOUND".equals(documentCategoryType)) {
			return "Outbound";
		}
		String documentDirection = expAGDocumentType.getDocumentDirection();
		return CommonUtil.isNullOrEmpty(documentDirection) ? "Other" : documentDirection;
	}

	private DocumentIDsType createDocumentIds(String documentId) {
		DocumentIDType documentIDType = new DocumentIDType();
		documentIDType.setValue(documentId);
		documentIDType.setType("DocumentRequestID");
		//
		DocumentIDsType documentIDsType = new DocumentIDsType();
		documentIDsType.getDocumentIDs().add(documentIDType);
		return documentIDsType;
	}

	public static String getDocumentId(DocumentType documentType) {
		return documentType.getDocumentIDs().getDocumentIDs().get(0).getValue();
	}
}
