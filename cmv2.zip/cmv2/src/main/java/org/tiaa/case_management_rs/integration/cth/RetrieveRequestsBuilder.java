package org.tiaa.case_management_rs.integration.cth;

import java.util.List;

import javax.xml.bind.JAXBElement;

import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.esb.partyrequest.types.ObjectFactory;
import org.tiaa.esb.partyrequest.types.OrchestrationIDs;
import org.tiaa.esb.partyrequest.types.PartyReqCriteria;
import org.tiaa.esb.partyrequest.types.PartyRequestCriterion;
import org.tiaa.esb.partyrequest.types.RequestIdentifiers;
import org.tiaa.esb.partyrequest.types.RequestTypes;
import org.tiaa.esb.partyrequest.types.RetrieveAdditionalRequestIdentifier;
import org.tiaa.esb.partyrequest.types.RetrieveAdditionalRequestIdentifiers;
import org.tiaa.esb.partyrequest.types.RetrieveRequests;
import org.tiaa.esb.partyrequest.types.StringValue;
import org.tiaa.esb.partyrequest.types.StringValue256;

public class RetrieveRequestsBuilder {
	private String processType = "";
	private String requestType = "";
	private ObjectFactory objectFactory = new ObjectFactory();

	public RetrieveRequestsBuilder(String requestType, String processType) {
		super();
		this.requestType = requestType;
		this.processType = processType;
	}

	public RetrieveRequests build(UpdateCTHContext updateCTHContext) {
		return build(updateCTHContext.getTaskInfo());
	}

	public RetrieveRequests build(TaskInfo taskInfo) {
		RetrieveRequests retrieveRequests = new RetrieveRequests();
		retrieveRequests.setIncludePayload(true);
		String taskId = taskInfo.getTaskId();
		if (taskId != null) {
			addPartyReqCriteria(retrieveRequests, taskId);
			return retrieveRequests;
		}
		String cthOrchestrationId = taskInfo.getCthOrchestrationId();
		if (CommonUtil.isNotNullAndNotEmpty(cthOrchestrationId)) {
			addOrchestrationId(retrieveRequests, cthOrchestrationId);
			return retrieveRequests;
		}
		String cthRequestId = taskInfo.getCthRequestId();
		if (CommonUtil.isNotNullAndNotEmpty(cthRequestId)) {
			RequestIdentifiers requestIdentifiers = new RequestIdentifiers();
			retrieveRequests.setRequestIdentifiers(requestIdentifiers);
			requestIdentifiers.getRequestIdentifiers().add(Long.parseLong(cthRequestId));
		}
		return retrieveRequests;
	}

	private void addOrchestrationId(RetrieveRequests retrieveRequests, String cthOrchestrationId) {
		OrchestrationIDs orchIds = new OrchestrationIDs();
		retrieveRequests.setOrchestrationIDs(orchIds);
		List<String> orchestrationIDList = orchIds.getOrchestrationIDs();
		orchestrationIDList.add(cthOrchestrationId);
	}

	private void addPartyReqCriteria(RetrieveRequests retrieveRequests, String taskId) {
		final int startRecordNumber = 1;
		final int numberOfRecordsToBeReturned = 100;
		PartyRequestCriterion partyRequestCriterion = createPartyRequestCriterion(retrieveRequests);
		retrieveRequests.setStartRecordNumber(startRecordNumber);
		retrieveRequests.setNumberOfRecordsToBeReturned(numberOfRecordsToBeReturned);
		//partyRequestCriterion.setProcessType(processType);
		//partyRequestCriterion.setRequestTypes(createRequestTypes(requestType));
		RetrieveAdditionalRequestIdentifiers retrieveAdditionalRequestIdentifiers = new RetrieveAdditionalRequestIdentifiers();
		List<RetrieveAdditionalRequestIdentifier> additionalRequestIdentifierList = retrieveAdditionalRequestIdentifiers.getAdditionalRequestIdentifiers();
		additionalRequestIdentifierList.add(createAdditionalIdentifier("WorkflowTaskID", taskId));
		if (!additionalRequestIdentifierList.isEmpty()) {
			partyRequestCriterion.setAdditionalRequestIdentifiers(retrieveAdditionalRequestIdentifiers);
		}
	}

	private RequestTypes createRequestTypes(String e) {
		RequestTypes requestTypes = new RequestTypes();
		requestTypes.getRequestTypes().add(e);
		return requestTypes;
	}

	private PartyRequestCriterion createPartyRequestCriterion(RetrieveRequests retrieveRequests) {
		PartyRequestCriterion partyRequestCriterion = new PartyRequestCriterion();
		PartyReqCriteria partyReqCriteria = new PartyReqCriteria();
		retrieveRequests.setPartyRequestCriteria(partyReqCriteria);
		partyReqCriteria.getPartyRequestCriterions().add(partyRequestCriterion);
		return partyRequestCriterion;
	}

	private RetrieveAdditionalRequestIdentifier createAdditionalIdentifier(String key, String value) {
		StringValue stringValue = new StringValue();
		stringValue.setValue(value);
		//
		RetrieveAdditionalRequestIdentifier retrieveAdditionalRequestIdentifier = new RetrieveAdditionalRequestIdentifier();
		retrieveAdditionalRequestIdentifier.setKey(key);
		//
		retrieveAdditionalRequestIdentifier.setValue(createStringValue(value));
		return retrieveAdditionalRequestIdentifier;
	}

	private JAXBElement<StringValue256> createStringValue(String value) {
		StringValue256 stringValue256 = new StringValue256();
		stringValue256.setValue(value);
		return objectFactory.createRetrieveAdditionalRequestIdentifierValue(stringValue256);
	}
}
