package org.tiaa.case_management_rs.poller;

import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.AsyncAnnotationBeanPostProcessor;
import org.springframework.scheduling.annotation.ScheduledAnnotationBeanPostProcessor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;

@Configuration
public class PollerConfig {
	@Value("${email.to}")
	private String emailTo;

	@Bean
	public AsyncAnnotationBeanPostProcessor asyncAnnotationBeanPostProcessor() {
		AsyncAnnotationBeanPostProcessor asyncAnnotationBeanPostProcessor = new AsyncAnnotationBeanPostProcessor();
		asyncAnnotationBeanPostProcessor.setExecutor(asyncTaskExecutor());
		return asyncAnnotationBeanPostProcessor;
	}

	@Bean
	public TaskExecutor asyncTaskExecutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		AsyncAnnotationConfiguration asyncAnnotationConfiguration = new AsyncAnnotationConfiguration();
		threadPoolTaskExecutor.setCorePoolSize(asyncAnnotationConfiguration.getAsyncTaskExecutorCorePoolSize());
		threadPoolTaskExecutor.setMaxPoolSize(asyncAnnotationConfiguration.getAsyncTaskExecutorMaxPoolSize());
		threadPoolTaskExecutor.setQueueCapacity(asyncAnnotationConfiguration.getAsyncTaskExecutorQueueCapacity());
		threadPoolTaskExecutor.setRejectedExecutionHandler(rejectedExecutionHandler());
		threadPoolTaskExecutor.initialize();
		return threadPoolTaskExecutor;
	}

	@Bean
	public CallerRunsPolicy rejectedExecutionHandler() {
		return new java.util.concurrent.ThreadPoolExecutor.CallerRunsPolicy();
	}

	@Bean
	public ScheduledAnnotationBeanPostProcessor scheduledAnnotationBeanPostProcessor() {
		ScheduledAnnotationBeanPostProcessor scheduledAnnotationBeanPostProcessor = new ScheduledAnnotationBeanPostProcessor();
		scheduledAnnotationBeanPostProcessor.setScheduler(taskScheduler());
		return scheduledAnnotationBeanPostProcessor;
	}

	@Bean
	public SchedulerConfiguration schedulerConfiguration() {
		return new SchedulerConfiguration();
	}

	@Bean
	public TaskScheduler taskScheduler() {
		ThreadPoolTaskScheduler taskScheduler = new ThreadPoolTaskScheduler();
		taskScheduler.setPoolSize(schedulerConfiguration().getTaskSchedulerPoolSize());
		taskScheduler.setRejectedExecutionHandler(rejectedExecutionHandler());
		taskScheduler.setWaitForTasksToCompleteOnShutdown(true);
		taskScheduler.initialize();
		return taskScheduler;
	}

	@Bean
	public CMSActivePollerDAO cmsActivePollerDAO() {
		return new CMSActivePollerDAOImpl();
	}

	@Bean
	public ComponentSynchronizerService componentSynchronizerService() {
		final int fiveMinutes = 5;
		final int twoMinutes = 2;
		ComponentSynchronizerServiceImpl componentSynchronizerService = new ComponentSynchronizerServiceImpl();
		componentSynchronizerService.setComponent("CMUDRS_POLLER");
		componentSynchronizerService.setInitialDelay(0);
		componentSynchronizerService.setPeriod(fiveMinutes);
		componentSynchronizerService.setTimeUnit(TimeUnit.MINUTES);
		componentSynchronizerService.setProactiveProcessorPollerMaxAgeInMillis(TimeUnit.MINUTES.toMillis(fiveMinutes + twoMinutes));
		componentSynchronizerService.setSupportGroupEmail(emailTo);
		return componentSynchronizerService;
	}

	@Bean
	public ScheduledThreadPoolExecutor scheduledThreadPoolExecutor() {
		final int corePoolSize = 5;
		return new ScheduledThreadPoolExecutor(corePoolSize);
	}

}
