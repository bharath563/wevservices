package org.tiaa.case_management_rs.integration.case_manager.cth;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import org.tiaa.case_management_rs.integration.case_manager.CaseManagerBatchApp;

public class CaseManagerBatchAppServlet extends HttpServlet {
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		response.setContentType("text/html;charset=UTF-8");
		//
		WebApplicationContext context = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
		CaseManagerBatchApp caseManagerBatchApp = context.getBean(CaseManagerBatchApp.class);
		ServletOutputStream outputStream = response.getOutputStream();
		//
		caseManagerBatchApp.execute(outputStream);
		outputStream.flush();
		outputStream.close();
	}
}