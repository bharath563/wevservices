package org.tiaa.case_management_rs.integration.cth;

import org.w3c.dom.Element;

public interface CTHPayloadJaxbMarshaller {
	String getTaskId(Element payload);
}
