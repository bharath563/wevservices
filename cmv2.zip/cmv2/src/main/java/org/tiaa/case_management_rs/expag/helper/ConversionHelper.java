package org.tiaa.case_management_rs.expag.helper;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.ws.rs.core.Response;

import org.aspectj.lang.ProceedingJoinPoint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.case_management_rs.dao.EXPAGDAO;
import org.tiaa.case_management_rs.dao.NEXTGENDAO;
import org.tiaa.case_management_rs.delegate.impl.ActivitiAdapter;
import org.tiaa.case_management_rs.delegate.impl.ExpAGAdapter;
import org.tiaa.case_management_rs.support.ResponseObjectFactory;
import org.tiaa.case_management_rs.utils.ExceptionUtil;
import org.tiaa.esb.case_management_rs_v2.type.DocumentRequest;
import org.tiaa.esb.case_management_rs_v2.type.DocumentResponse;
import org.tiaa.esb.case_management_rs_v2.type.DocumentsRequest;
import org.tiaa.esb.case_management_rs_v2.type.DocumentsResponse;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.ProcessRequest;
import org.tiaa.esb.case_management_rs_v2.type.ProcessResponse;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.ProcessesRequest;
import org.tiaa.esb.case_management_rs_v2.type.ProcessesResponse;
import org.tiaa.esb.case_management_rs_v2.type.ResponseStatus;
import org.tiaa.esb.case_management_rs_v2.type.Task;

@Component
public class ConversionHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(ConversionHelper.class);

	@Autowired
	private NEXTGENDAO nextGendao;

	@Autowired
	private EXPAGDAO expagdao;

	@Autowired
	private ExpAGAdapter expagAdapter;

	@Autowired
	private ActivitiAdapter activitiAdapter;
	
	@Value("${maxEXPAGConversionThreadPoolSize}")
	protected int maxEXPAGConversionThreadPoolSize;

	public void setAppNameBasedOnTaskType(Request request) {

		try {

			LOGGER.debug("ConversionHelper--setAppNameBasedOnTaskType call");

			String taskId = (String) request.getAttribute(PROCESS_ID);

			request.setAttribute(CONVERTED_EXPAG_TASK, YES);

			String taskType = expagdao.getExpagTaskTypeForTaskId(taskId);

			String sourceSystem = null;

			if (taskType != null) {
				sourceSystem = this.getSourceSystemNameByTaskType(taskType);
			} else {
				sourceSystem = APP_ACTIVITI;
			}
			setAppNameInRequest(sourceSystem, request);
		} catch (Exception exception) {
			LOGGER.error("ConversionHelper-setAppNameBasedOnTaskType"+exception.getMessage());
		}

	}

	public void setAppNameInRequest(String sourceSystem, Request request) {

		if (sourceSystem != null) {

			if (APP_EXPAG.equalsIgnoreCase(sourceSystem)) {
				request.setAttribute(APP_NAME, APP_EXPAG);
			} else if (APP_ACTIVITI.equalsIgnoreCase(sourceSystem)) {
				request.setAttribute(APP_NAME, APP_ACTIVITI);
			} else {
				String[] sourceName = sourceSystem.split("\\|");
				request.setAttribute(APP_NAME, sourceName[0]);

			}
		}
	}

	public String getSourceSystemNameByTaskType(String taskType) {

		String sourceSystem = this.nextGendao.getSourceSystemNameByTaskType(taskType);

		return sourceSystem;
	}



	public Response createProcesses(ProceedingJoinPoint pjp, String sourceSystem) throws Throwable {

		Response response = null;
		Response expagResponse = null;
		Response activitiResponse = null;

		Object[] args = pjp.getArgs();

		Request request = (Request) args[0];

		ProcessesRequest processesRequest = (ProcessesRequest) request.getAttribute(PROCESSES_REQUEST);

		request.setAttribute(CONVERTED_EXPAG_TASK, YES);

		if (sourceSystem.contains("|")) {

			String[] sourceNames = sourceSystem.split("\\|");
			ProcessesResponse processesResponse = new ProcessesResponse();
			try {
				setAppNameInRequest(APP_EXPAG, request);
				expagResponse = (Response) pjp.proceed();

				if (expagResponse.hasEntity()) {

					processesResponse = (ProcessesResponse) expagResponse.getEntity();

					String pktId = processesResponse.getProcesses().getProcesses().get(0).getProcessId();
					String taskId = processesResponse.getProcesses().getProcesses().get(0).getTasks().getTasks().get(0).getID();

					processesRequest.getProcesses().getProcesses().get(0).setProcessId(pktId);
					processesRequest.getProcesses().getProcesses().get(0).getTasks().getTasks().get(0).setID(taskId);

					request.setAttribute(PROCESSES_REQUEST, processesRequest);

					setAppNameInRequest(APP_ACTIVITI, request);
					activitiResponse = (Response) pjp.proceed();
				}

				if (APP_EXPAG.equalsIgnoreCase(sourceNames[0])) {
					return expagResponse;
				} else {
					return activitiResponse;
				}

			} catch (Exception exception) {
				LOGGER.error("ConversionHelper - createProcesses - error:>>" + exception.getMessage());
				ResponseStatus responseStatus = ExceptionUtil.createESBResponseStatus(exception);
				processesResponse.setResponseStatus(responseStatus);
				response = ResponseObjectFactory.createResponseStatus(responseStatus, processesResponse);
			}
		} else {
			setAppNameInRequest(sourceSystem, request);
			response = (Response) pjp.proceed();
		}

		return response;

	}

	public Response updateProcess(ProceedingJoinPoint jointPoint, String delegatorSourceSystem, Request request) throws Throwable {

		Process process = null;
		Response response = null;
		ProcessResponse processResponse = new ProcessResponse();
		request.setAttribute(CONVERTED_EXPAG_TASK, YES);
		if (delegatorSourceSystem.contains("|")) {

			String[] sourceName = delegatorSourceSystem.split("\\|");
			// For process exution in two systems

			ExecutorService executor = null;
			try {
				executor = Executors.newFixedThreadPool(maxEXPAGConversionThreadPoolSize);
				List<UpdateProcess> extProcesscallble = new ArrayList<UpdateProcess>();
				extProcesscallble.add(new UpdateProcess(APP_EXPAG, request));
				extProcesscallble.add(new UpdateProcess(APP_ACTIVITI, request));
				for (UpdateProcess callable : extProcesscallble) {
					if (callable.getSourceSystem().equalsIgnoreCase(APP_EXPAG)) {
						Future<org.tiaa.esb.case_management_rs_v2.type.Process> processResp = executor.submit(callable);
						process = processResp.get();
						if (null == process) {
							break;
						}
					} else {
						executor.submit(callable);
					}

				}

			} catch (Exception exception) {
				LOGGER.error("ConversionHelper - Error while updating the EXPAG  process " + exception.getMessage());
				ResponseStatus responseStatus = ExceptionUtil.createESBResponseStatus(exception);
				processResponse.setResponseStatus(responseStatus);
				response = ResponseObjectFactory.createResponseStatus(responseStatus, processResponse);

			} finally {
				if (executor != null) {
					executor.shutdown();
				}
			}

		} else {

			setAppNameInRequest(delegatorSourceSystem, request);
			response = (Response) jointPoint.proceed();
		}
		if (process != null) {

			processResponse = ResponseObjectFactory.createProcessResponse(SUCCESS, SUCCESS_TEXT);
			processResponse.setProcess(process);
			response = Response.ok(processResponse).build();
		}

		return response;

	}

	private class UpdateProcess implements Callable<org.tiaa.esb.case_management_rs_v2.type.Process> {

		private String sourceSystem;
		private Request request;

		public String getSourceSystem() {
			return sourceSystem;
		}

		public void setSourceSystem(String sourceSystem) {
			this.sourceSystem = sourceSystem;
		}

		public Request getRequest() {
			return request;
		}

		public void setRequest(Request request) {
			this.request = request;
		}

		public UpdateProcess(String sourceSystem, Request request) {
			this.sourceSystem = sourceSystem;
			this.request = request;
		}	

		@Override
		public org.tiaa.esb.case_management_rs_v2.type.Process call() throws Exception {

			org.tiaa.esb.case_management_rs_v2.type.Process updateProcess = new org.tiaa.esb.case_management_rs_v2.type.Process();
			if (sourceSystem.equalsIgnoreCase(APP_ACTIVITI)) {
					updateProcess = activitiAdapter.updateProcess(request);

			} else if (sourceSystem.equalsIgnoreCase(APP_EXPAG)) {
					updateProcess = expagAdapter.updateProcess(request);
			}

			return updateProcess;
		}
	}

	public Response createDocuments(ProceedingJoinPoint pjp, String sourceSystem) throws Throwable {

			Response response = null;
			Response expagResponse = null;
			Response activitiResponse = null;

			Object[] args = pjp.getArgs();

			Request request = (Request) args[0];

			DocumentsRequest documentsRequest = (DocumentsRequest) request.getAttribute(DOCUMENTS_REQUEST);

			request.setAttribute(CONVERTED_EXPAG_TASK, YES);

			if (sourceSystem.contains("|")) {

				String[] sourceNames = sourceSystem.split("\\|");
				DocumentsResponse documentsResponse = new DocumentsResponse();
				try {
					setAppNameInRequest(APP_EXPAG, request);
					expagResponse = (Response) pjp.proceed();

					if (expagResponse.hasEntity()) {

						documentsResponse = (DocumentsResponse) expagResponse.getEntity();

						request.setAttribute(DOCUMENTS_REQUEST, documentsRequest);

						setAppNameInRequest(APP_ACTIVITI, request);
						activitiResponse = (Response) pjp.proceed();
					}

					if (APP_EXPAG.equalsIgnoreCase(sourceNames[0])) {
						return expagResponse;
					} else {
						return activitiResponse;
					}

				} catch (Exception exception) {
					LOGGER.error("ConversionHelper - createDcouments - error:>>" + exception.getMessage(), exception);
					ResponseStatus responseStatus = ExceptionUtil.createESBResponseStatus(exception);
					documentsResponse.setResponseStatus(responseStatus);
					response = ResponseObjectFactory.createResponseStatus(responseStatus, documentsResponse);
				}
			} else {
				setAppNameInRequest(sourceSystem, request);
				response = (Response) pjp.proceed();
			}

			return response;

		}
	
	public Response createRelatedTask(ProceedingJoinPoint pjp, String sourceSystem) throws Throwable {

		Response response = null;
		Response expagResponse = null;
		Response activitiResponse = null;

		Object[] args = pjp.getArgs();

		Request request = (Request) args[0];

		ProcessRequest processRequest  = (ProcessRequest) request.getAttribute(PROCESS_REQUEST);
		request.setAttribute(CONVERTED_EXPAG_TASK, YES);

		if (sourceSystem.contains("|")) {

			String[] sourceNames = sourceSystem.split("\\|");
			ProcessResponse processResponse = new ProcessResponse();
			try {
				setAppNameInRequest(APP_EXPAG, request);
				expagResponse = (Response) pjp.proceed();

				if (expagResponse.hasEntity()) {

					processResponse = (ProcessResponse) expagResponse.getEntity();

					String pktId = processResponse.getProcess().getProcessId();
					
					String expagRelatedTaskId = null;
					Process process=processResponse.getProcess();
					
					if (process != null &&  process.getTasks() != null && process.getTasks().getTasks() != null) {
						
						org.tiaa.esb.case_management_rs_v2.type.Properties properties = process.getTasks().getTasks().get(0).getTaskProperties();
						
						for (NameValue parentNameValue : properties.getProperties()) {
							
							if(NEW_RELATED_TASK_ID.equalsIgnoreCase(parentNameValue.getDesc())){
								expagRelatedTaskId = parentNameValue.getChildrenNameValues().get(0).getValue();
							}
						}
					}
					processRequest.getProcess().setProcessId(pktId);
					processRequest.getProcess().getTasks().getTasks().get(0).setID(expagRelatedTaskId);

					request.setAttribute(PROCESS_REQUEST, processRequest);

					setAppNameInRequest(APP_ACTIVITI, request);
					activitiResponse = (Response) pjp.proceed();
				}

				if (APP_EXPAG.equalsIgnoreCase(sourceNames[0])) {
					return expagResponse;
				} else {
					return activitiResponse;
				}

			} catch (Exception exception) {
				LOGGER.error("ConversionHelper - createRelatedTask - error:>>" + exception.getMessage());
				ResponseStatus responseStatus = ExceptionUtil.createESBResponseStatus(exception);
				processResponse.setResponseStatus(responseStatus);
				response = ResponseObjectFactory.createResponseStatus(responseStatus, processResponse);
			}
		} else {
			setAppNameInRequest(sourceSystem, request);
			response = (Response) pjp.proceed();
		}

		return response;

	}
	
	public Response updateDocument(ProceedingJoinPoint pjp,
			String sourceSystem) throws Throwable {

		Response response = null;
		Response expagResponse = null;
		Response activitiResponse = null;

		Object[] args = pjp.getArgs();

		Request request = (Request) args[0];

		DocumentRequest documentRequest = (DocumentRequest) request.getAttribute(DOCUMENT_REQUEST);

		request.setAttribute(CONVERTED_EXPAG_TASK, YES);

		if (sourceSystem.contains("|")) {

			String[] sourceNames = sourceSystem.split("\\|");
			DocumentResponse documentResponse = new DocumentResponse();
			try {
				setAppNameInRequest(APP_EXPAG, request);
				expagResponse = (Response) pjp.proceed();
				String updateActivitiflag = YES;

				if (expagResponse.hasEntity()) {
					
					updateActivitiflag = NO;
					documentResponse = (DocumentResponse) expagResponse.getEntity();

					request.setAttribute(DOCUMENT_REQUEST, documentRequest);

					if (NOTE.equalsIgnoreCase(documentRequest.getDocument().getDocDirection()) || (APP_ACTIVITI.equalsIgnoreCase(sourceNames[0]) && YES.equalsIgnoreCase(updateActivitiflag))){
						setAppNameInRequest(APP_ACTIVITI, request);
						activitiResponse = (Response) pjp.proceed();
					}
					
				}

				if (APP_EXPAG.equalsIgnoreCase(sourceNames[0]) || ! NOTE.equalsIgnoreCase(documentRequest.getDocument().getDocDirection()) ) {
					return expagResponse;
				} else {
					return activitiResponse;
				}

			} catch (Exception exception) {
				LOGGER.error("ConversionHelper - updateDocument - error:>>" + exception.getMessage(), exception);
				ResponseStatus responseStatus = ExceptionUtil.createESBResponseStatus(exception);
				documentResponse.setResponseStatus(responseStatus);
				response = ResponseObjectFactory.createResponseStatus(responseStatus, documentResponse);
			}
		} else {
			setAppNameInRequest(sourceSystem, request);
			response = (Response) pjp.proceed();
		}

		return response;

	}
	
	public Response updateProcesses(ProceedingJoinPoint jointPoint,Request request) throws Throwable{
		
		List<Process> expagTasks=new ArrayList<Process>();
		List<Process> activitiTasks=new ArrayList<Process>();
		ProcessesRequest expAgProcessesRequest = new ProcessesRequest();
		ProcessesRequest activitiProcessesRequest = new ProcessesRequest();
		
		ExecutorService executorService=null;
		Processes processes=null;
		ProcessesResponse processesResponse=new ProcessesResponse();
		Response response=null;
		ProcessesRequest processesRequest = (ProcessesRequest) request.getAttribute(PROCESSES_REQUEST);
		List<Process> processesResult = processesRequest.getProcesses().getProcesses();
		for (Process process : processesResult) {
			Task task= process.getTasks().getTasks().get(0);
			String taskType=task.getType();
			String sourceSystem = getSourceSystemNameByTaskType(taskType);
			if(null != sourceSystem && sourceSystem.equals(APP_EXPAG)) {
				expagTasks.add(process);
			} else if(null != sourceSystem && sourceSystem.equals(APP_ACTIVITI)) {
				activitiTasks.add(process);
			} else if(sourceSystem.contains("|")){
				expagTasks.add(process);
				activitiTasks.add(process);
			}
		}		
		if (expagTasks.size() > 0) {
			Processes expAgProcesses = new Processes();
			expAgProcesses.getProcesses().addAll(expagTasks);
			expAgProcesses.setPaginationInfo(processesRequest.getProcesses().getPaginationInfo());
			expAgProcessesRequest.setProcesses(expAgProcesses);
		}
		
		if (activitiTasks.size() > 0) {
			Processes activitiProcesses = new Processes();
			activitiProcesses.getProcesses().addAll(activitiTasks);
			activitiProcesses.setPaginationInfo(processesRequest.getProcesses().getPaginationInfo());
			activitiProcessesRequest.setProcesses(activitiProcesses);
		}
	
		if(expagTasks.size() > 0 || activitiTasks.size() > 0) {
		    try {
				executorService = Executors.newFixedThreadPool(maxEXPAGConversionThreadPoolSize);
				List<UpdateProcesses> extProcessescallble = new ArrayList<UpdateProcesses>();
				if (expagTasks.size() > 0) {
					extProcessescallble.add(new UpdateProcesses(APP_EXPAG, request));
				}
				if (activitiTasks.size() > 0) {
					extProcessescallble.add(new UpdateProcesses(APP_ACTIVITI, request));
				}
				for (UpdateProcesses callable : extProcessescallble) {
					if (callable.getSourceSystem().equalsIgnoreCase(APP_EXPAG) && expagTasks.size() > 0) {
						callable.getRequest().setAttribute(PROCESSES_REQUEST, expAgProcessesRequest);
						Future<org.tiaa.esb.case_management_rs_v2.type.Processes> processesResp = executorService.submit(callable);
						processes = processesResp.get();
						if (null == processesResult) {
							LOGGER.error("Error while updating expag processes");
							break;
						}
					} else {
						callable.getRequest().setAttribute(PROCESSES_REQUEST, activitiProcessesRequest);
						executorService.submit(callable);
					}
	
				}
		    } catch(Exception exception){
		    	LOGGER.error("ConversionHelper-Error while updating the EXPAG  process " + exception.getMessage());
				ResponseStatus responseStatus = ExceptionUtil.createESBResponseStatus(exception);
				processesResponse.setResponseStatus(responseStatus);
				response = ResponseObjectFactory.createResponseStatus(responseStatus, processesResponse);
		    }
		}
	

		if (processes != null) {
			processesResponse = ResponseObjectFactory
					.createProcessesResponse(SUCCESS, SUCCESS_TEXT);
			processesResponse.setProcesses(processes);

		} else {
			processesResponse = ResponseObjectFactory
					.createProcessesResponse(FAILURE, FAILURE_TEXT);
		}

		response = Response.ok(processesResponse).build();
		
		
		return response;
		
	}

private class UpdateProcesses implements Callable<org.tiaa.esb.case_management_rs_v2.type.Processes> {

	private String sourceSystem;
	private Request request;

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public Request getRequest() {
		return request;
	}

	public void setRequest(Request request) {
		this.request = request;
	}

	public UpdateProcesses(String sourceSystem, Request request) {
		this.sourceSystem = sourceSystem;
		this.request = request;
	}	

	@Override
	public org.tiaa.esb.case_management_rs_v2.type.Processes call() throws Exception {

		org.tiaa.esb.case_management_rs_v2.type.Processes updateProcesses = new org.tiaa.esb.case_management_rs_v2.type.Processes();
		if (sourceSystem.equalsIgnoreCase(APP_ACTIVITI)) {
			updateProcesses = activitiAdapter.updateProcesses(request);

		} else if (sourceSystem.equalsIgnoreCase(APP_EXPAG)) {
			updateProcesses = expagAdapter.updateProcesses(request);
		}

		return updateProcesses;
	}
}

}
