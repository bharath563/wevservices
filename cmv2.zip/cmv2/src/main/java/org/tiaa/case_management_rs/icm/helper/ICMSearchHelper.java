package org.tiaa.case_management_rs.icm.helper;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import org.codehaus.jackson.JsonGenerationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.lang3.StringUtils;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.constants.CaseManagementConstants;
import org.tiaa.case_management_rs.delegate.impl.ColumnsMapping;
import org.tiaa.case_management_rs.model.SearchItemsVO;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.DateType;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.Properties;
import org.tiaa.esb.case_management_rs_v2.type.SearchRequest;
import org.tiaa.esb.case_management_rs_v2.type.SortCriteria;
import org.tiaa.esb.case_management_rs_v2.type.SortOrder;
import org.tiaa.esb.case_management_rs_v2.type.Status;
import org.tiaa.esb.case_management_rs_v2.type.Statuses;
import org.tiaa.esb.icm.types.Case;
import org.tiaa.esb.icm.types.CaseSearch;
import org.tiaa.esb.icm.types.DateRange;

@Component
public class ICMSearchHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(ICMSearchHelper.class);
	
	private static ObjectMapper objectMapper = new ObjectMapper();

	public SearchItemsVO multiSearchRequest(String userId, SearchRequest searchRequest) {

		SearchItemsVO searchItemsVO = new SearchItemsVO();

		// Set straight forward values
		searchItemsVO.setUserId(userId);

		if (StringUtils.isNotBlank(searchRequest.getTaskId())) {
			searchItemsVO.setTaskid(searchRequest.getTaskId());
		}

		if (StringUtils.isNotBlank(searchRequest.getTaskType())) {
			searchItemsVO.setTasktype(searchRequest.getTaskType());
		}

		if (StringUtils.isNotBlank(searchRequest.getDepartment())) {
			searchItemsVO.setDeptdesc(searchRequest.getDepartment());
		}

		if (StringUtils.isNotBlank(searchRequest.getAssignedTo())) {
			searchItemsVO.setWorkbasket(searchRequest.getAssignedTo());
		}

		if (StringUtils.isNotBlank(searchRequest.getAction())) {
			searchItemsVO.setActdesc(searchRequest.getAction());
		}

		if (searchRequest.getTaskStatus() != null) {

			if (TASK_STATUS_SUSPENDED.equalsIgnoreCase(searchRequest.getTaskStatus().getSts())) {
				searchItemsVO.setTaskstatus("S");
			} else if (TASK_STATUS_COMPLETED.equalsIgnoreCase(searchRequest.getTaskStatus().getSts())) {
				searchItemsVO.setTaskstatus("C");
			} else if (TASK_STATUS_OPEN.equalsIgnoreCase(searchRequest.getTaskStatus().getSts())) {
				searchItemsVO.setTaskstatus("O");
			} else {
				searchItemsVO.setTaskstatus("A");
			}
		} else {
			searchItemsVO.setTaskstatus("A");
		}

		if ((searchRequest.getRowCount() != null) && (searchRequest.getRowCount() > 0)) {
			searchItemsVO.setRowcount(searchRequest.getRowCount());
		}

		// Searches only those tasks not assigned to a caseworker(workbasket)
		if (StringUtils.isNotBlank(searchRequest.getAssignedTo())) {
			searchItemsVO.setEmptyworkbasket(true);
		} else {
			searchItemsVO.setEmptyworkbasket(false);
		}

		// Begin date and EndDate range is based on createdate if supplied
		if ((searchRequest.getFilterType() != null) && (searchRequest.getFilterType().equals(DateType.CREATED_DATE))) {

			searchItemsVO.setBeginDate(DateUtil.toCalendarDateOnly(searchRequest.getStartDate()));
			searchItemsVO.setEndDate(DateUtil.toCalendarDateOnly(searchRequest.getEndDate()));
			searchItemsVO.setUsecreatedate(true);

		} else if ((searchRequest.getFilterType() != null) && (searchRequest.getFilterType().equals(DateType.RECEIVED_DATE))) {

			searchItemsVO.setBeginDate(DateUtil.toCalendarDateOnly(searchRequest.getStartDate()));
			searchItemsVO.setEndDate(DateUtil.toCalendarDateOnly(searchRequest.getEndDate()));
			searchItemsVO.setUsecreatedate(false);
		} else {
			searchItemsVO.setUsecreatedate(false);
		}

		if ((searchRequest.getProperties() != null) && (searchRequest.getProperties().getProperties().size() > 0)) {

			NameValue nameValue1 = searchRequest.getProperties().getProperties().get(0);

			// First identifier set
			searchItemsVO.setIddesc1(nameValue1.getDesc());

			if (nameValue1.getChildrenNameValues() != null) {

				for (int i = 0; i < nameValue1.getChildrenNameValues().size(); i++) {

					NameValue childNameValue = nameValue1.getChildrenNameValues().get(i);

					if (childNameValue != null) {
						if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 1)) {
							searchItemsVO.setField11(childNameValue.getValue());
						} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 2)) {
							searchItemsVO.setField12(childNameValue.getValue());
						} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 3)) {
							searchItemsVO.setField13(childNameValue.getValue());
						} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 4)) {
							searchItemsVO.setField14(childNameValue.getValue());
						}
					}

				}
			}
			

			if ((searchRequest.getProperties() != null) && (searchRequest.getProperties().getProperties().size() > 1)) {
				NameValue nameValue2 = searchRequest.getProperties().getProperties().get(1);

				// Second identifier set
				searchItemsVO.setIddesc2(nameValue2.getDesc());

				if (nameValue2.getChildrenNameValues() != null) {

					for (int i = 0; i < nameValue2.getChildrenNameValues().size(); i++) {

						NameValue childNameValue = nameValue2.getChildrenNameValues().get(i);

						if (childNameValue != null) {
							if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 1)) {
								searchItemsVO.setField21(childNameValue.getValue());
							} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 2)) {
								searchItemsVO.setField22(childNameValue.getValue());
							} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 3)) {
								searchItemsVO.setField23(childNameValue.getValue());
							} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 4)) {
								searchItemsVO.setField24(childNameValue.getValue());
							}

						}
					}
				}

				if ((searchRequest.getProperties() != null) && (searchRequest.getProperties().getProperties().size() > 2)) {

					NameValue nameValue3 = searchRequest.getProperties().getProperties().get(2);

					// Third identifier set
					searchItemsVO.setIddesc3(nameValue3.getDesc());

					if (nameValue3.getChildrenNameValues() != null) {

						for (int i = 0; i < nameValue3.getChildrenNameValues().size(); i++) {

							NameValue childNameValue = nameValue3.getChildrenNameValues().get(i);
							if (childNameValue != null) {
								if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 1)) {
									searchItemsVO.setField31(childNameValue.getValue());
								} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 2)) {
									searchItemsVO.setField32(childNameValue.getValue());
								} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 3)) {
									searchItemsVO.setField33(childNameValue.getValue());
								} else if ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getDsplSqncNbr().intValue() == 4)) {
									searchItemsVO.setField34(childNameValue.getValue());
								}
							}

						}
					}
				}

			}

		}

		return searchItemsVO;

	}
	
	public Processes icmCasesToProcesses(List<Case> icmCaseResponseList){
		Processes processes = new Processes();
		
		if( !icmCaseResponseList.isEmpty()){
			for(Object icmCaseResponseJSON : icmCaseResponseList){
				
				try{
				String icmResponseJSONString = this.objectMapper.writeValueAsString(icmCaseResponseJSON);
				this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);				
				Case icmCaseResponse = this.objectMapper.readValue(icmResponseJSONString, Case.class);
				
				Process process = new Process();
				Statuses statuses = new Statuses();
				Status status = new Status();
				Properties icmProperties = new Properties();
				
				process.setAppName("ICM");
				process.setProcessId(icmCaseResponse.getId());
				process.setProcessType(icmCaseResponse.getType());
				status.setSts(icmCaseResponse.getStatus());
				statuses.getSts().add(status);
				process.setStatusHistory(statuses);
				
				NameValue nameValueChannel = new NameValue();
				nameValueChannel.setDesc("channel");
				nameValueChannel.setValue(icmCaseResponse.getChannel());
				icmProperties.getProperties().add(nameValueChannel);
				
				NameValue nameValuePathName = new NameValue();
				nameValuePathName.setDesc("pathName");
				nameValuePathName.setValue(icmCaseResponse.getPathName());
				icmProperties.getProperties().add(nameValuePathName);
				
				if( StringUtils.isNotBlank(icmCaseResponse.getCreatedDate())){
					NameValue nameValueCreatedDateTime = new NameValue();
					nameValueCreatedDateTime.setDesc("createdDate");
					nameValueCreatedDateTime.setDateValue(DateUtil.toXMLGregorianCalendar(DateUtil.parseDateTimeWithoutMilliseconds(icmCaseResponse.getCreatedDate())));
					
					icmProperties.getProperties().add(nameValueCreatedDateTime);
				}
				
				if( StringUtils.isNotBlank(icmCaseResponse.getRequestReceivedDate())){
					NameValue nameValueRequestReceivedDateTime = new NameValue();
					nameValueRequestReceivedDateTime.setDesc("requestReceivedDate");
					nameValueRequestReceivedDateTime.setDateValue(DateUtil.toXMLGregorianCalendar(DateUtil.parseDateTimeWithoutMilliseconds(icmCaseResponse.getRequestReceivedDate())));
					
					icmProperties.getProperties().add(nameValueRequestReceivedDateTime);
				}
				
				if( StringUtils.isNotBlank(icmCaseResponse.getModifiedDate())){
					NameValue nameValueModifiedDateTime = new NameValue();
					nameValueModifiedDateTime.setDesc("modifiedDate");
					nameValueModifiedDateTime.setDateValue(DateUtil.toXMLGregorianCalendar(DateUtil.parseDateTimeWithoutMilliseconds(icmCaseResponse.getModifiedDate())));
					
					icmProperties.getProperties().add(nameValueModifiedDateTime);
				}
				
				// Map all the additional identifiers.
				HashMap<String, Object> additionalIdentifiers= icmCaseResponse.getAdditionalIdentifiers() ;
				
					if(additionalIdentifiers != null){
					for(String key: additionalIdentifiers.keySet()){
						NameValue nameValue = new NameValue();
						if(CaseManagementConstants.SOLUTION.equalsIgnoreCase(key)) {
							nameValue.setDesc(CaseManagementConstants.DEPARTMENT);	
						}else {
							nameValue.setDesc(key);
						}
						Object entryValue = additionalIdentifiers.get(key);
						if(String.class.isInstance(entryValue)){
							nameValue.setValue((String)entryValue);
						}else if(Integer.class.isInstance(entryValue)){
							((Integer)entryValue).longValue();
							nameValue.getNumValue().add(BigInteger.valueOf(((Integer)entryValue).longValue()));
						}else if(Boolean.class.isInstance(entryValue)){
							nameValue.setBooleanValue((Boolean)entryValue);
						}else if(Float.class.isInstance(entryValue)){
							nameValue.setDecimalValue(BigDecimal.valueOf(((Float)entryValue).floatValue()));
						}else if(Date.class.isInstance(entryValue)){
							nameValue.setDateValue(DateUtil.toXMLGregorianCalendar(((Date)entryValue)));
						}
						icmProperties.getProperties().add(nameValue);	
						
					}

				}
				process.setProcessProperties(icmProperties);
				processes.getProcesses().add(process);
			
		} catch (JsonGenerationException e) {
			e.printStackTrace();
		} catch (JsonMappingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		}
		}
		
		return processes;
	}
	
	public CaseSearch rsvSearchRequestToICMRequest(SearchRequest rsvSearchRequest){
		CaseSearch icmCaseSearchRequest = new CaseSearch();
	    
	    icmCaseSearchRequest.setCaseType(rsvSearchRequest.getTaskType());
		
		if (rsvSearchRequest.getTaskStatus() != null) {
			icmCaseSearchRequest.setCaseStatus(rsvSearchRequest.getTaskStatus().getSts());
		}
		
		if ((rsvSearchRequest.getFilterType() != null) && (rsvSearchRequest.getFilterType().equals(DateType.CREATED_DATE))) {
			DateRange icmDateRangeType = new DateRange();
			icmDateRangeType.setFrom(toFormat(rsvSearchRequest.getStartDate(), DateUtil.DEFAULT_SIMPLE_DATE_FORMAT));
			icmDateRangeType.setTo(toFormat(rsvSearchRequest.getEndDate(), DateUtil.DEFAULT_SIMPLE_DATE_FORMAT));
			icmDateRangeType.setType("Case Creation Date");
			icmCaseSearchRequest.setDateRange(icmDateRangeType);

		} else if ((rsvSearchRequest.getFilterType() != null) && (rsvSearchRequest.getFilterType().equals(DateType.RECEIVED_DATE))) {
			DateRange icmDateRangeType = new DateRange();
			icmDateRangeType.setFrom(toFormat(rsvSearchRequest.getStartDate(), DateUtil.DEFAULT_SIMPLE_DATE_FORMAT));
			icmDateRangeType.setTo(toFormat(rsvSearchRequest.getEndDate(), DateUtil.DEFAULT_SIMPLE_DATE_FORMAT));
			icmDateRangeType.setType("Request Received Date");
			icmCaseSearchRequest.setDateRange(icmDateRangeType);
		} else {
			DateRange icmDateRangeType = new DateRange();
			icmDateRangeType.setFrom(toFormat(rsvSearchRequest.getStartDate(), DateUtil.DEFAULT_SIMPLE_DATE_FORMAT));
			icmDateRangeType.setTo(toFormat(rsvSearchRequest.getEndDate(), DateUtil.DEFAULT_SIMPLE_DATE_FORMAT));
			icmDateRangeType.setType("Case Modified Date");
			icmCaseSearchRequest.setDateRange(icmDateRangeType);
		}
		
		if(rsvSearchRequest.getTaskId() != null && !rsvSearchRequest.getTaskId().startsWith("t")){
			icmCaseSearchRequest.setConfirmation(rsvSearchRequest.getTaskId());
		}
		
		if(StringUtils.isNoneBlank(rsvSearchRequest.getDepartment())){
			icmCaseSearchRequest.setSolution(rsvSearchRequest.getDepartment());
		}
		
		List<String> pins = new ArrayList<String>();
		List<String> ssns = new ArrayList<String>();
		
		if ((rsvSearchRequest.getProperties() != null) && (rsvSearchRequest.getProperties().getProperties().size() > 0)) {

			for(NameValue nameValue : rsvSearchRequest.getProperties().getProperties()){
				if(PIN.equalsIgnoreCase(nameValue.getDesc())){
					pins.add(nameValue.getChildrenNameValues().get(0).getValue());
					icmCaseSearchRequest.setPins(pins);
				} else if(SSN.equalsIgnoreCase(nameValue.getDesc())){					
					ssns.add(nameValue.getChildrenNameValues().get(0).getValue());
					icmCaseSearchRequest.setSsns(ssns);					
				} else if(ICM_CHANNEL.equalsIgnoreCase(nameValue.getDesc())){
					icmCaseSearchRequest.setChannel(nameValue.getChildrenNameValues().get(0).getValue());
				} else if(CLIENT_ID.equalsIgnoreCase(nameValue.getDesc())){
					icmCaseSearchRequest.setClientId(nameValue.getChildrenNameValues().get(0).getValue());
				} else if(PLAN.equalsIgnoreCase(nameValue.getDesc())){
					icmCaseSearchRequest.setPlan(nameValue.getChildrenNameValues().get(0).getValue());
				} else if(SOURCE_FILE_NAME.equalsIgnoreCase(nameValue.getDesc())){
					icmCaseSearchRequest.setSourceFileName(nameValue.getChildrenNameValues().get(0).getValue());
				} else if(RELATED_ORDER.equalsIgnoreCase(nameValue.getDesc())){
					icmCaseSearchRequest.setRelatedOrder(nameValue.getChildrenNameValues().get(0).getValue());
				} else if(LOAN_ID.equalsIgnoreCase(nameValue.getDesc())){
					icmCaseSearchRequest.setLoanId(nameValue.getChildrenNameValues().get(0).getValue());
				} else if(CASE_NUMBER.equalsIgnoreCase(nameValue.getDesc())){
					icmCaseSearchRequest.setCaseNumber(nameValue.getChildrenNameValues().get(0).getValue());
				} else if(ACCOUNT_NUMBER.equalsIgnoreCase(nameValue.getDesc())){
					icmCaseSearchRequest.setAccountNumber(nameValue.getChildrenNameValues().get(0).getValue());
				} else if(BATCH_ID.equalsIgnoreCase(nameValue.getDesc())){
					icmCaseSearchRequest.setBatchId(nameValue.getChildrenNameValues().get(0).getValue());
				} else if(CASE_TYPE.equalsIgnoreCase(nameValue.getDesc())){
					icmCaseSearchRequest.setCaseType(nameValue.getChildrenNameValues().get(0).getValue());
				} else if(CASE_STATUS.equalsIgnoreCase(nameValue.getDesc())){
					icmCaseSearchRequest.setCaseStatus(nameValue.getChildrenNameValues().get(0).getValue());
				} else if(CONFIRMATION.equalsIgnoreCase(nameValue.getDesc())){
					icmCaseSearchRequest.setConfirmation(nameValue.getChildrenNameValues().get(0).getValue());
				} 
			}
		}
	
		//Setting sort order and sort field
		if(rsvSearchRequest.getSortCriteriaInfo()!=null && rsvSearchRequest.getSortCriteriaInfo().getSortCriterias()!=null && rsvSearchRequest.getSortCriteriaInfo().getSortCriterias().size()>0){
			SortCriteria sortCriteria = rsvSearchRequest.getSortCriteriaInfo().getSortCriterias().get(0);
			String sortField = sortCriteria.getSortField();
			String sortOrder = sortCriteria.getSortOrder().value();

			if(StringUtils.isNotBlank(sortField)){
				icmCaseSearchRequest.setSortField(ColumnsMapping.getICMColumn(sortField));
			}else{
				icmCaseSearchRequest.setSortField("requestReceivedDate");
			}
			if(StringUtils.isNotBlank(sortOrder)){
				icmCaseSearchRequest.setSortOrder(sortOrder);
			}else{
				icmCaseSearchRequest.setSortOrder(SortOrder.DESC.toString());
			}
		}else{
			icmCaseSearchRequest.setSortField("requestReceivedDate");
			icmCaseSearchRequest.setSortOrder(SortOrder.DESC.toString());
		}	
		
		
		return icmCaseSearchRequest;
	}
		

	public static String toFormat(XMLGregorianCalendar cal, String format) {
		if (cal == null) {
			return "";
		}
		long timeInMillis = cal.toGregorianCalendar().getTimeInMillis();
		
		Date date= new Date(timeInMillis);
		
		return new SimpleDateFormat(format).format(date);
	}


}
