package org.tiaa.case_management_rs.delegate;

import javax.xml.bind.JAXBException;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.esb.case_management_rs_v2.type.Comments;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItems;
import org.tiaa.esb.case_management_rs_v2.type.Document;
import org.tiaa.esb.case_management_rs_v2.type.Documents;
import org.tiaa.esb.case_management_rs_v2.type.History;
import org.tiaa.esb.case_management_rs_v2.type.Metrics;
import org.tiaa.esb.case_management_rs_v2.type.Process;
//import org.tiaa.esb.case_management_rs.type.WorkItem;
//import org.tiaa.esb.case_management_rs.type.WorkItems;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.Task;
import org.tiaa.esb.case_management_rs_v2.type.TaskResponse;
import org.tiaa.esb.case_management_rs_v2.type.Tasks;


public interface CaseManagementDelegate{

	public Processes getProcesses(Request request);

	public Process getProcess(Request request);

	public Document getDocument(Request request) throws JAXBException;

	public Documents getDocuments(Request request);

	public Process createProcess(Request request);

	public Process updateProcess(Request request);

	public ConfigItems getConfigItems(Request request);

	public Processes doSearch(Request request) throws Exception;
	
	public Metrics getMetrics(Request request);

	public Document createDocument(Request request);

	public Documents createDocuments(Request request);

	public Process createRelatedTask(Request request);

	public Processes createProcesses(Request request);

	public Processes doDatabaseSearch(Request request) throws Exception;
	
	// public Tasks getIcmTasks(Request request);

	// public Comments getIcmComments(Request request);

	public TaskResponse getTaskById(Request request);

	public Processes getTasksClaimable(Request request);

	public ConfigItems getIcmConfigItems(Request request);

    public Comments addComment(Request request);

	public Processes updateProcesses(Request request) throws Exception;
	
    public Comments getComments(Request request);

	public Tasks getTasks(Request request);

	public void updateDocument(Request request) throws Exception;
	
	public Process getRelatedProcesses(Request request);

	public Process getHistory(Request request);

	public Task updateTask(Request request);

	public Task createTask(Request request);

	public ConfigItems searchConfigItems(Request request);
	
	public void deleteDocument(Request request);

	public History getTaskHistory(Request request);

}
