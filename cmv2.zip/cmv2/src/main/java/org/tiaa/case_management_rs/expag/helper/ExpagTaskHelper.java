package org.tiaa.case_management_rs.expag.helper;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.xml.datatype.XMLGregorianCalendar;

import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.joda.time.DateTimeFieldType;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.joda.time.LocalTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.constants.HolidaysCache;
import org.tiaa.case_management_rs.constants.ProcessDBDaoCache;
import org.tiaa.case_management_rs.dao.EXPAGDAO;
import org.tiaa.case_management_rs.dao.ProcessDBDAO;
import org.tiaa.case_management_rs.model.ExpagStatusHistory;
import org.tiaa.case_management_rs.model.ExpagWorkItem;
import org.tiaa.case_management_rs.model.SLAInfo;
import org.tiaa.case_management_rs.model.TaskIdentifiersValue;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.case_management_rs_v2.type.ConfigData;
import org.tiaa.esb.case_management_rs_v2.type.ConfigItem;
import org.tiaa.esb.case_management_rs_v2.type.Documents;
import org.tiaa.esb.case_management_rs_v2.type.Duration;
import org.tiaa.esb.case_management_rs_v2.type.Identifier;
import org.tiaa.esb.case_management_rs_v2.type.Identifiers;
import org.tiaa.esb.case_management_rs_v2.type.NameValue;
import org.tiaa.esb.case_management_rs_v2.type.Process;
import org.tiaa.esb.case_management_rs_v2.type.Processes;
import org.tiaa.esb.case_management_rs_v2.type.Properties;
import org.tiaa.esb.case_management_rs_v2.type.RelatedTasks;
import org.tiaa.esb.case_management_rs_v2.type.SLADetail;
import org.tiaa.esb.case_management_rs_v2.type.Status;
import org.tiaa.esb.case_management_rs_v2.type.Statuses;
import org.tiaa.esb.case_management_rs_v2.type.SubField;
import org.tiaa.esb.case_management_rs_v2.type.SubFields;
import org.tiaa.esb.case_management_rs_v2.type.Task;
import org.tiaa.esb.case_management_rs_v2.type.Tasks;
import org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo;
import org.tiaa.esb.powerimage.types.Identifier.Fieldinfo;
import org.tiaa.esb.powerimage.types.WorkPacket;

@Component
public class ExpagTaskHelper {

	private class GetExpagWorkItems implements Callable<List<ExpagWorkItem>> {

		private String department;
		private String type;
		private String userId;
		private int start;
		public GetExpagWorkItems(String userId, String type, String department, int start) {
			this.type = type;
			this.userId = userId;
			this.department = department;
			this.start = start;
		}

		@Override
		public List<ExpagWorkItem> call() throws Exception {
			return expagDAO.getExpagDepartmentWorkItems(StringUtils.rightPad(userId, 8), type, department, start);
		}

	}

	private static final Logger LOGGER = LoggerFactory.getLogger(ExpagTaskHelper.class);

	@Autowired
	private EXPAGDAO expagDAO;
	
	@Autowired
	private ExpagDocumentHelper expagDocumentHelper;

	@Autowired
	private ProcessDBDAO processDBDao;

	@Autowired
	private ProcessDBDaoCache processDBDaoCache;
	
	@Autowired
	private HolidaysCache holidaysCache;
	
	private Integer calculateTotalTimeWorked(List<SLAInfo> slaInfoList) {
		List<String> dateList = new ArrayList<String>();

		for (SLAInfo slaInfo : slaInfoList)
			if ((slaInfo.getStartDateTime() != null) && (slaInfo.getEndDateTime() != null)) {
				String timeElapsed = DateUtil.getTimeElapsed(slaInfo.getStartDateTime(), slaInfo.getEndDateTime());
				dateList.add(timeElapsed);
			}
		return DateUtil.getTotalDays(dateList);
	}

	// new method for expag identifiers to ProcessProperties

	public org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo cmsDescriptionToExpagNote(String description) {

		org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo noteDocument = new org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo();
		org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo.Mailinfo mailInfo = new org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo.Mailinfo();
		org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo.Internalinfo internalinfo = new org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo.Internalinfo();

		org.tiaa.esb.powerimage.createtask.types.DocumentContentInfo docContInfo = new org.tiaa.esb.powerimage.createtask.types.DocumentContentInfo();

		// Add the supplied description as a document of type note while
		// creating the task
		internalinfo.setText(description);
		mailInfo.setMaildesc(EXPAG_MAIL_DESC_WEB);
		mailInfo.setMailid(EXPAG_MAIL_ID_WEB);

		// set the not details
		noteDocument.setInternalinfo(internalinfo);
		noteDocument.setMailinfo(mailInfo);
		noteDocument.setStorage(EXPAG_STORAGE_INTERNAL);
		noteDocument.setScanfix(SCANFIX_MODE_S);
		noteDocument.setWrkstnid(EXPAG_WORKSTATION_TIAAPI);
		noteDocument.setTotalpages(BigInteger.valueOf(1));
		noteDocument.setFiletype(EXPAG_FILETYPE_ACSII);
		noteDocument.setPidoctype(EXPAG_PIDOCTYPE_NOTE);

		docContInfo.setContentdesc(NOTE);
		docContInfo.setTaskonlyflg(EXPAG_ADD_DOCUMENT_TASK);
		docContInfo.setStartpage(BigInteger.valueOf(1));
		docContInfo.setEndpage(BigInteger.valueOf(1));

		noteDocument.getDocumentContentInfos().add(docContInfo);

		return noteDocument;
	}

	public List<org.tiaa.esb.powerimage.createtask.types.Identifier> cmsPropertiesToexpagCreateTaskIdentifiers(Properties properties) {

		List<org.tiaa.esb.powerimage.createtask.types.Identifier> expagIdentifiers = new ArrayList<org.tiaa.esb.powerimage.createtask.types.Identifier>();
		List<NameValue> nameValueList = properties.getProperties();

		for (int i = 0; i < nameValueList.size(); i++) {

			// Identifier cmsIdentifier = cmsIdentifiers.get(i);
			NameValue nameValue = nameValueList.get(i);
			org.tiaa.esb.powerimage.createtask.types.Identifier expagIdentifier = new org.tiaa.esb.powerimage.createtask.types.Identifier();

			// expagIdentifier.setId(BigInteger.valueOf(i + 1));
			expagIdentifier.setId(BigInteger.valueOf(i + 1));
			// expagIdentifier.setIddesc(cmsIdentifier.getDesc());
			expagIdentifier.setIddesc(nameValue.getDesc());

			for (NameValue childNameValue : nameValue.getChildrenNameValues()) {

				org.tiaa.esb.powerimage.createtask.types.Identifier.Fieldinfo fieldinfo = new org.tiaa.esb.powerimage.createtask.types.Identifier.Fieldinfo();
				fieldinfo.setFldnbr(childNameValue.getDsplSqncNbr().intValue());
				fieldinfo.setFieldname(childNameValue.getName());

				/*
				 * If planname is passed cut it off to 45 character for the
				 * successful task creation
				 */
				if ("PLANNAME".equalsIgnoreCase(childNameValue.getName()) && ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getValue().length() > 45)))
					fieldinfo.setFieldvalue(childNameValue.getValue().substring(0, 45));
				else
					fieldinfo.setFieldvalue(childNameValue.getValue());

				// Add each fieldinfo to the expag identifier after parsing
				expagIdentifier.getFieldinfos().add(fieldinfo);
			}

			// Finally add each identifier to the cmsidentifiers list
			expagIdentifiers.add(expagIdentifier);
		}

		return expagIdentifiers;
	}

	public List<org.tiaa.esb.powerimage.types.Identifier> cmsPropertiesToexpagIdentifiers(Properties properties) {

		List<org.tiaa.esb.powerimage.types.Identifier> expagIdentifiers = new ArrayList<org.tiaa.esb.powerimage.types.Identifier>();
		List<NameValue> nameValueList = properties.getProperties();

		for (int i = 0; i < nameValueList.size(); i++) {

			// Identifier cmsIdentifier = cmsIdentifiers.get(i);
			NameValue nameValue = nameValueList.get(i);
			org.tiaa.esb.powerimage.types.Identifier expagIdentifier = new org.tiaa.esb.powerimage.types.Identifier();

			expagIdentifier.setId(BigInteger.valueOf(i + 1));
			// expagIdentifier.setIddesc(cmsIdentifier.getDesc());
			expagIdentifier.setIddesc(nameValue.getDesc());

			for (NameValue childNameValue : nameValue.getChildrenNameValues()) {

				org.tiaa.esb.powerimage.types.Identifier.Fieldinfo fieldinfo = new org.tiaa.esb.powerimage.types.Identifier.Fieldinfo();
				fieldinfo.setFldnbr(childNameValue.getDsplSqncNbr().intValue());
				fieldinfo.setFieldname(childNameValue.getName());

				/*
				 * If planname is passed cut it off to 45 character for the
				 * successful task creation
				 */
				if ("PLANNAME".equalsIgnoreCase(childNameValue.getName()) && ((childNameValue.getDsplSqncNbr() != null) && (childNameValue.getValue().length() > 45)))
					fieldinfo.setFieldvalue(childNameValue.getValue().substring(0, 45));
				else
					fieldinfo.setFieldvalue(childNameValue.getValue());

				// Add each fieldinfo to the expag identifier after parsing
				expagIdentifier.getFieldinfos().add(fieldinfo);
			}

			expagIdentifiers.add(expagIdentifier);
		}

		return expagIdentifiers;
	}

	public org.tiaa.esb.powerimage.types.CreateDocumentInfo cmsRelatedTaskDescriptionToExpagNote(String description) {

		org.tiaa.esb.powerimage.types.CreateDocumentInfo noteDocument = new org.tiaa.esb.powerimage.types.CreateDocumentInfo();
		org.tiaa.esb.powerimage.types.CreateDocumentInfo.Mailinfo mailInfo = new org.tiaa.esb.powerimage.types.CreateDocumentInfo.Mailinfo();
		org.tiaa.esb.powerimage.types.CreateDocumentInfo.Internalinfo internalinfo = new org.tiaa.esb.powerimage.types.CreateDocumentInfo.Internalinfo();

		org.tiaa.esb.powerimage.types.DocumentContentInfo docContInfo = new org.tiaa.esb.powerimage.types.DocumentContentInfo();

		// Add the supplied description as a document of type note while
		// creating the task
		internalinfo.setText(description);
		mailInfo.setMaildesc(EXPAG_MAIL_DESC_WEB);
		mailInfo.setMailid(EXPAG_MAIL_ID_WEB);

		// set the not details
		noteDocument.setInternalinfo(internalinfo);
		noteDocument.setMailinfo(mailInfo);
		noteDocument.setStorage(EXPAG_STORAGE_INTERNAL);
		noteDocument.setScanfix(SCANFIX_MODE_S);
		noteDocument.setWrkstnid(EXPAG_WORKSTATION_TIAAPI);
		noteDocument.setTotalpages(BigInteger.valueOf(1));
		noteDocument.setFiletype(EXPAG_FILETYPE_ACSII);
		noteDocument.setPidoctype(EXPAG_PIDOCTYPE_NOTE);

		docContInfo.setContentdesc(NOTE);
		docContInfo.setTaskonlyflg(EXPAG_ADD_DOCUMENT_TASK);
		docContInfo.setStartpage(BigInteger.valueOf(1));
		docContInfo.setEndpage(BigInteger.valueOf(1));

		noteDocument.getDocumentContentInfos().add(docContInfo);

		return noteDocument;
	}

	public org.tiaa.esb.powerimage.types.AddTasksToPacket cmsTasktoExpagRelatedTask(String userId, String caseId, List<Process> processList) {

		org.tiaa.esb.powerimage.types.AddTasksToPacket expagTasksPacket = new org.tiaa.esb.powerimage.types.AddTasksToPacket();

		org.tiaa.esb.powerimage.types.WorkFlow expagWork = new org.tiaa.esb.powerimage.types.WorkFlow();

		for (int i = 1; i < processList.size(); i++) {
			Process process = processList.get(i);
			Task cmsTask = process.getTasks().getTasks().get(0);
			org.tiaa.esb.powerimage.types.CreateTask expagRelatedTask = new org.tiaa.esb.powerimage.types.CreateTask();

			// Overrided the action step if passed
			if (null != (cmsTask.getAction()) && !(cmsTask.getAction().getItems().isEmpty()))
				expagWork.setActiondesc(cmsTask.getAction().getItems().get(0));
			else
				expagWork.setActiondesc(ACTIONDESC_PROCESS);

			// Override vip indicator if passed
			if (StringUtils.isNotBlank(cmsTask.getVIPIndicator()))
				expagWork.setVip(cmsTask.getVIPIndicator());
			else
				expagWork.setVip(DEFAULT_VIP_INDICATOR);

			// Override priority if passed
			if (StringUtils.isNotBlank(cmsTask.getPriority()))
				expagWork.setPriority(Integer.parseInt(cmsTask.getPriority()));
			else
				expagWork.setPriority(EXPAG_DEFAULT_PRIORITY);

			// Override Scan mode if passed
			if (StringUtils.isNotBlank(cmsTask.getScanMode()))
				expagWork.setScanmode(cmsTask.getScanMode());
			else
				expagWork.setScanmode(SCAN_MODE_R);

			if (StringUtils.isNotBlank(cmsTask.getDepartment()))
				expagWork.setDepartment(cmsTask.getDepartment());

			if (StringUtils.isNotBlank(cmsTask.getAssignedTo()))
				expagWork.setWrkbskt(cmsTask.getAssignedTo());

			expagWork.setTasktype(cmsTask.getType());

			if ((cmsTask.getCreateDate() != null) && (cmsTask.getCreateTime() != null)) {
				expagWork.setDatereceived(cmsTask.getCreateDate());
				expagWork.setTimereceived(cmsTask.getCreateTime());
			} else if ((cmsTask.getReceivedDate() != null) && (cmsTask.getReceivedTime() != null)) {
				expagWork.setDatereceived(cmsTask.getReceivedDate());
				expagWork.setTimereceived(cmsTask.getReceivedTime());
			} else {
				expagWork.setDatereceived(DateUtil.currentDate());
				expagWork.setTimereceived(DateUtil.currentTime());
			}

			expagWork.setBypassarchiveident(TRUE);
			expagWork.setCreateoper(userId);

			if (cmsTask.getComments() != null && null != cmsTask.getComments().getComments() && !cmsTask.getComments().getComments().isEmpty())
				if (StringUtils.isNotBlank(cmsTask.getComments().getComments().get(0).getMessage())) { // StringUtils.isNotBlank(cmsTask.getNotes())
					org.tiaa.esb.powerimage.types.CreateDocumentInfo notes = cmsRelatedTaskDescriptionToExpagNote(cmsTask.getComments().getComments().get(0).getMessage());
					expagRelatedTask.getCreateDocumentInfos().add(notes);
				}

			List<org.tiaa.esb.powerimage.types.Identifier> expagIdentifiers = cmsPropertiesToexpagIdentifiers(cmsTask.getTaskProperties());

			// Add the identifiers list
			expagRelatedTask.getIdentifiers().addAll(expagIdentifiers);
			expagRelatedTask.setWorkFlow(expagWork);
			expagTasksPacket.getCreateTasks().add(expagRelatedTask);
		}

		// set workpacket details
		expagTasksPacket.setLckoper(userId);
		expagTasksPacket.setPktid(caseId);

		return expagTasksPacket;
	}

	public org.tiaa.esb.powerimage.types.AddTasksToPacket cmsTasktoExpagRelatedTask(String userId, String caseId, Task cmsTask,String type) {

		org.tiaa.esb.powerimage.types.AddTasksToPacket expagTasksPacket = new org.tiaa.esb.powerimage.types.AddTasksToPacket();
		org.tiaa.esb.powerimage.types.CreateTask expagRelatedTask = new org.tiaa.esb.powerimage.types.CreateTask();
		org.tiaa.esb.powerimage.types.WorkFlow expagWork = new org.tiaa.esb.powerimage.types.WorkFlow();

		//copy task condition...
		if(null != type && type.equalsIgnoreCase(TASK)) {
			if ((null != cmsTask.getAction()) && !(cmsTask.getAction().getItems().isEmpty()))
					expagWork.setActiondesc(cmsTask.getAction().getItems().get(0));
				else
					expagWork.setActiondesc(ACTIONDESC_PROCESS);
		}else { //add related task case...
			if(StringUtils.isNotBlank(cmsTask.getType()))
			{
				expagWork.setActiondesc(expagDAO.getFirstActionStepForTask(cmsTask.getType()));
			}
		}
		
		if (StringUtils.isNotBlank(cmsTask.getVIPIndicator()))
			expagWork.setVip(cmsTask.getVIPIndicator());
		else
			expagWork.setVip(DEFAULT_VIP_INDICATOR);

		// Override priority if passed
		if (StringUtils.isNotBlank(cmsTask.getPriority()))
			expagWork.setPriority(Integer.parseInt(cmsTask.getPriority()));
		else
			expagWork.setPriority(EXPAG_DEFAULT_PRIORITY);

		// Override Scan mode if passed
		if (StringUtils.isNotBlank(cmsTask.getScanMode()))
			expagWork.setScanmode(cmsTask.getScanMode());
		else
			expagWork.setScanmode(SCAN_MODE_R);

		if (StringUtils.isNotBlank(cmsTask.getDepartment()))
			expagWork.setDepartment(cmsTask.getDepartment());

		if (StringUtils.isNotBlank(cmsTask.getAssignedTo()))
			expagWork.setWrkbskt(cmsTask.getAssignedTo());

		expagWork.setTasktype(cmsTask.getType());

		if ((cmsTask.getCreateDate() != null) && (cmsTask.getCreateTime() != null)) {
			expagWork.setDatereceived(cmsTask.getCreateDate());
			expagWork.setTimereceived(cmsTask.getCreateTime());
		} else if ((cmsTask.getReceivedDate() != null) && (cmsTask.getReceivedTime() != null)) {
			expagWork.setDatereceived(cmsTask.getReceivedDate());
			expagWork.setTimereceived(cmsTask.getReceivedTime());
		} else {
			expagWork.setDatereceived(DateUtil.currentDate());
			expagWork.setTimereceived(DateUtil.currentTime());
		}

		expagWork.setBypassarchiveident(TRUE);
		expagWork.setCreateoper(userId);

		// Add the description as a note
		if (StringUtils.isNotBlank(cmsTask.getDescription())) {

			org.tiaa.esb.powerimage.types.CreateDocumentInfo noteDocument = cmsRelatedTaskDescriptionToExpagNote(cmsTask.getDescription());
			expagRelatedTask.getCreateDocumentInfos().add(noteDocument);
		}

		if (null != cmsTask.getComments() && !(cmsTask.getComments().getComments().isEmpty()) && StringUtils.isNotBlank(cmsTask.getComments().getComments().get(0).getMessage())) { // StringUtils.isNotBlank(cmsTask.getNotes())
			org.tiaa.esb.powerimage.types.CreateDocumentInfo notes = cmsRelatedTaskDescriptionToExpagNote(cmsTask.getComments().getComments().get(0).getMessage());
			expagRelatedTask.getCreateDocumentInfos().add(notes);
		}

		List<org.tiaa.esb.powerimage.types.Identifier> expagIdentifiers = cmsPropertiesToexpagIdentifiers(cmsTask.getTaskProperties());

		// Add the identifiers list
		expagRelatedTask.getIdentifiers().addAll(expagIdentifiers);
		expagRelatedTask.setWorkFlow(expagWork);

		// set workpacket details
		expagTasksPacket.setLckoper(userId);
		expagTasksPacket.setPktid(caseId);
		expagTasksPacket.getCreateTasks().add(expagRelatedTask);
		

		return expagTasksPacket;
	}
	
	public org.tiaa.esb.powerimage.createtask.types.WorkPacket cmsTasktoExpagWork(String userId, Task cmsTask, Documents cmsDocuments) {

		org.tiaa.esb.powerimage.createtask.types.WorkPacket expagWorkPacket = new org.tiaa.esb.powerimage.createtask.types.WorkPacket();
		org.tiaa.esb.powerimage.createtask.types.CreateTask expagTask = new org.tiaa.esb.powerimage.createtask.types.CreateTask();
		org.tiaa.esb.powerimage.createtask.types.WorkFlow expagWork = new org.tiaa.esb.powerimage.createtask.types.WorkFlow();

		// Overrided the action step if passed
		/*
		 * if (StringUtils.isNotBlank(cmsTask.getActionStep())) {
		 * expagWork.setActiondesc(cmsTask.getActionStep()); } else {
		 * expagWork.setActiondesc(ACTIONDESC_PROCESS); }
		 */
		if ((cmsTask.getAction()) != null && !(cmsTask.getAction().getItems().isEmpty()))
			expagWork.setActiondesc(cmsTask.getAction().getItems().get(0));
		else
			expagWork.setActiondesc(ACTIONDESC_PROCESS);

		// Override vip indicator if passed
		if (StringUtils.isNotBlank(cmsTask.getVIPIndicator()))
			expagWork.setVip(cmsTask.getVIPIndicator());
		else
			expagWork.setVip(DEFAULT_VIP_INDICATOR);

		// Override priority if passed
		if (StringUtils.isNotBlank(cmsTask.getPriority()))
			expagWork.setPriority(Integer.parseInt(cmsTask.getPriority()));
		else
			expagWork.setPriority(EXPAG_DEFAULT_PRIORITY);

		// Override Scan mode if passed
		if (StringUtils.isNotBlank(cmsTask.getScanMode()))
			expagWork.setScanmode(cmsTask.getScanMode());
		else
			expagWork.setScanmode(SCAN_MODE_R);

		if (StringUtils.isNotBlank(cmsTask.getDepartment()))
			expagWork.setDepartment(cmsTask.getDepartment());

		if (StringUtils.isNotBlank(cmsTask.getAssignedTo()))
			expagWork.setWrkbskt(cmsTask.getAssignedTo());

		expagWork.setTasktype(cmsTask.getType());

		if ((cmsTask.getCreateDate() != null) && (cmsTask.getCreateTime() != null)) {
			expagWork.setDatereceived(cmsTask.getCreateDate());
			expagWork.setTimereceived(cmsTask.getCreateTime());
		} else if ((cmsTask.getReceivedDate() != null) && (cmsTask.getReceivedTime() != null)) {
			expagWork.setDatereceived(cmsTask.getReceivedDate());
			expagWork.setTimereceived(cmsTask.getReceivedTime());
		} else {
			expagWork.setDatereceived(DateUtil.currentDate());
			expagWork.setTimereceived(DateUtil.currentTime());
		}

		expagWork.setBypassarchiveident(TRUE);
		
		
		// Override createdBy if passed
		if (StringUtils.isNotBlank(cmsTask.getCreatedBy()))
			expagWork.setCreateoper(cmsTask.getCreatedBy());
		else
			expagWork.setCreateoper(userId);

		// Add the description as a note
		if (StringUtils.isNotBlank(cmsTask.getDescription())) {

			org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo noteDocument = cmsDescriptionToExpagNote(cmsTask.getDescription());
			expagTask.getCreateDocumentInfos().add(noteDocument);
		}

		if (cmsTask.getComments() != null && !cmsTask.getComments().getComments().isEmpty()) { // StringUtils.isNotBlank(cmsTask.getNotes())
			org.tiaa.esb.powerimage.createtask.types.CreateDocumentInfo notes = cmsDescriptionToExpagNote(cmsTask.getComments().getComments().get(0).getMessage());
			expagTask.getCreateDocumentInfos().add(notes);
		}
		//new changes begin/added
		List<CreateDocumentInfo> createExpagDocumentInfos= new ArrayList<CreateDocumentInfo>();
		
		try{
			createExpagDocumentInfos = expagDocumentHelper.createExpagDocumentInfosRequest(cmsTask,cmsDocuments);
		}catch(IOException ioException){
			LOGGER.error("createExpagDocumentInfos failed ");
		}
		expagTask.getCreateDocumentInfos().addAll(createExpagDocumentInfos);
		//new changes begin/added 
		
		List<org.tiaa.esb.powerimage.createtask.types.Identifier> expagIdentifiers = cmsPropertiesToexpagCreateTaskIdentifiers(cmsTask.getTaskProperties());

		// Add the identifiers list
		expagTask.getIdentifiers().addAll(expagIdentifiers);
		expagTask.setWorkFlow(expagWork);

		// set workpacket details
		expagWorkPacket.setLckoper(userId);
		expagWorkPacket.getCreateTasks().add(expagTask);

		return expagWorkPacket;
	}

	public SLADetail computeSLADetails(Task task, int suspendDuration) {

		SLADetail slaDetail = new SLADetail();

		Integer originalSLA = processDBDaoCache.getTaskTypeSla(task.getType());
		originalSLA = originalSLA == null ? 0 : originalSLA;
		Integer remainingSLA = originalSLA;
		Integer timeElapsed = 0;

		if ((originalSLA != 0) && (task.getReceivedDate() != null) && (task.getReceivedTime() != null)) {

			DateTimeFormatter dateFormatter = DateTimeFormat.forPattern("yyyy-MM-dd");
			DateTimeFormatter timeFormatter = DateTimeFormat.forPattern("HH:mm:ss");

			String expagReceivedDate = DateUtil.toFormat(task.getReceivedDate(), "yyyy-MM-dd");
			String expagReceivedTime = DateUtil.toFormat(task.getReceivedTime(), "HH:mm:ss");

			LocalDate receivedDate = dateFormatter.parseLocalDate(expagReceivedDate);
			LocalTime receivedTime = timeFormatter.parseLocalTime(expagReceivedTime);

			LocalDate currentDate = LocalDate.now(DateTimeZone.forID("America/New_York"));

			/*
			 * If the task is received after 4PM EST then Consider the received
			 * date to be a next day.
			 */
			if (receivedTime.getHourOfDay() > 15)
				receivedDate = receivedDate.plusDays(1);

			/*
			 * If the task is received on Saturday or Sunday then force it to
			 * next working day
			 */
			if (receivedDate.getDayOfWeek() == DateTimeConstants.SATURDAY)
				receivedDate = receivedDate.plusDays(2);
			else if (receivedDate.getDayOfWeek() == DateTimeConstants.SUNDAY)
				receivedDate = receivedDate.plusDays(1);

			LocalDate workingday = currentDate;

			if ((currentDate.getDayOfWeek() == DateTimeConstants.SATURDAY) || (currentDate.getDayOfWeek() == DateTimeConstants.SUNDAY))
				workingday = workingday.plusWeeks(1).withDayOfWeek(DateTimeConstants.MONDAY);

			if (workingday.isAfter(receivedDate))
				while (!workingday.isEqual(receivedDate)) {
					
					if(!holidaysCache.isHoliday(receivedDate.getYear(), receivedDate)){
						timeElapsed = timeElapsed + 1;
					}

					if (receivedDate.getDayOfWeek() == DateTimeConstants.FRIDAY)
						receivedDate = receivedDate.plusDays(3);
					else
						receivedDate = receivedDate.plusDays(1);

				}

			//Suspend Duration SLA
			timeElapsed -= suspendDuration;
			if (timeElapsed < 0) {
				//time elapsed should be >= 0
				timeElapsed = 0;
			}
			remainingSLA = originalSLA - timeElapsed;
		}
		
		Duration originalSLADuration = new Duration();
		originalSLADuration.setDays(BigInteger.valueOf(originalSLA));
		Duration remainingSLADuration = new Duration();
		remainingSLADuration.setDays(BigInteger.valueOf(remainingSLA));
		slaDetail.setOriginalSLA(originalSLADuration);
		slaDetail.setRemainingSLA(remainingSLADuration);
		slaDetail.setTimeElaspsed(String.valueOf(timeElapsed));

		return slaDetail;
	}

	// new method created for statuses history
	public Statuses computeTaskStatuses(org.tiaa.esb.powerimage.types.Task expagTask) {
		Statuses statuses = new Statuses();
		Status status = new Status();
		String cmsTaskStatus = TASK_STATUS_OPEN;
		//if task is in evalrulereq table, send status from that table 
		String evalRuleReqStatus = this.expagDAO.getEvalRuleReqStatus(expagTask.getTaskid());
		
		if(StringUtils.isNotBlank(evalRuleReqStatus)) {
			if(EXPAG_TASK_STATUS_EVAL_QUEUE.equalsIgnoreCase(evalRuleReqStatus)){
				cmsTaskStatus = EXPAG_TASK_STATUS_EVAL_QUEUE;
			} else if(EXPAG_TASK_STATUS_AWAIT_EVAL.equalsIgnoreCase(evalRuleReqStatus)){
				cmsTaskStatus = EXPAG_TASK_STATUS_AWAIT_EVAL;
			}
			status.setSts(cmsTaskStatus);
			statuses.getSts().add(status);
			return statuses;
		}
		
		if (StringUtils.isNotEmpty(expagTask.getLockoper()))
			cmsTaskStatus = TASK_STATUS_ACTIVE;
		else if (StringUtils.isNotBlank(expagTask.getSuspoper()))
			cmsTaskStatus = TASK_STATUS_SUSPENDED;
		else if (StringUtils.isNotBlank(expagTask.getCompleteoper()) || !(CommonUtil.isNull(expagTask.getCompletedate()) || CommonUtil.isNull(expagTask.getCompletetime()))) {

			String completedTaskSubStatus = this.expagDAO.getCompletedTaskSubStatus(expagTask.getTaskid());

			if ("C".equalsIgnoreCase(completedTaskSubStatus))
				cmsTaskStatus = TASK_STATUS_CANCELLED;
			else if ("J".equalsIgnoreCase(completedTaskSubStatus))
				cmsTaskStatus = TASK_STATUS_REJECTED;
			else
				cmsTaskStatus = TASK_STATUS_COMPLETED;
		}
		status.setSts(cmsTaskStatus);
		statuses.getSts().add(status);
		LOGGER.debug("CMS Task Status for the taskid " + expagTask.getTaskid() + " is : " + cmsTaskStatus);

		return statuses;
	}

	public Identifiers expagIdentifiersTocmsIdentifiers(List<org.tiaa.esb.powerimage.types.Identifier> expagIdentifiers) {

		Identifiers cmsIdentifiers = new Identifiers();

		for (org.tiaa.esb.powerimage.types.Identifier expagIdentifier : expagIdentifiers) {

			Identifier cmsIdentifier = new Identifier();
			SubFields subFields = new SubFields();

			// Set the primary identifier description
			cmsIdentifier.setDesc(expagIdentifier.getIddesc());

			for (Fieldinfo fieldinfo : expagIdentifier.getFieldinfos()) {

				SubField subField = new SubField();

				subField.setFieldNumber(fieldinfo.getFldnbr());
				subField.setFieldName(fieldinfo.getFieldname());
				subField.setFieldValue(fieldinfo.getFieldvalue());

				// Add each subfield to the identifier after parsing
				subFields.getSubFields().add(subField);
			}

			// Set all subfields for a identifier
			cmsIdentifier.setSubFields(subFields);

			// Finally add each identifier to the cmsidentifiers list
			cmsIdentifiers.getIdentifiers().add(cmsIdentifier);
		}

		return cmsIdentifiers;
	}

	public Properties expagIdentifiersTocmsProcessProperties(List<org.tiaa.esb.powerimage.types.Identifier> expagIdentifiers) {

		Properties properties = new Properties();
		for (org.tiaa.esb.powerimage.types.Identifier expagIdentifier : expagIdentifiers) {
			NameValue parentNameValue = new NameValue();
			parentNameValue.setDesc(expagIdentifier.getIddesc());
			parentNameValue.setID(expagIdentifier.getId().toString());
			for (Fieldinfo fieldinfo : expagIdentifier.getFieldinfos()) {
				NameValue childNameValue = createChildNameValue(fieldinfo.getFldnbr(), fieldinfo.getFieldname(), fieldinfo.getFieldvalue());
				parentNameValue.getChildrenNameValues().add(childNameValue);
			}
			properties.getProperties().add(parentNameValue);
		}
		return properties;
	}

	private NameValue createChildNameValue(long fldNbr, String fieldName, String fieldValue) {
		NameValue childNameValue = new NameValue();
		childNameValue.setDsplSqncNbr(BigInteger.valueOf(fldNbr));
		childNameValue.setName(fieldName);
		childNameValue.setValue(fieldValue);

		return childNameValue;
	}

	public Identifiers expagTaskSearchIdentifiersTocmsIdentifiers(List<org.tiaa.esb.powerimage.tasksearch.types.Identifier> expagIdentifiers) {

		Identifiers cmsIdentifiers = new Identifiers();

		for (org.tiaa.esb.powerimage.tasksearch.types.Identifier expagIdentifier : expagIdentifiers) {

			Identifier cmsIdentifier = new Identifier();
			SubFields subFields = new SubFields();

			// Set the primary identifier description
			cmsIdentifier.setDesc(expagIdentifier.getIddesc());

			for (org.tiaa.esb.powerimage.tasksearch.types.Identifier.Fieldinfo fieldinfo : expagIdentifier.getFieldinfos()) {

				SubField subField = new SubField();

				subField.setFieldNumber(fieldinfo.getFldnbr());
				subField.setFieldName(fieldinfo.getFieldname());
				subField.setFieldValue(fieldinfo.getFieldvalue());

				// Add each subfield to the identifier after parsing
				subFields.getSubFields().add(subField);
			}

			// Set all subfields for a identifier
			cmsIdentifier.setSubFields(subFields);

			// Finally add each identifier to the cmsidentifiers list
			cmsIdentifiers.getIdentifiers().add(cmsIdentifier);
		}

		return cmsIdentifiers;
	}

	public void expagTaskTocmsTask(org.tiaa.esb.powerimage.types.Task expagTask, Task cmsTask) {

		Properties properties = new Properties();

		// Populate task related items
		cmsTask.setID(expagTask.getTaskid());
		cmsTask.setType(expagTask.getTasktype());
		cmsTask.setDepartment(expagTask.getDepartment());
		cmsTask.setActionStep(expagTask.getActiondesc());
		cmsTask.setLastUpdatedDate(expagTask.getLasthistdate());
		cmsTask.setLastUpdatedTime(expagTask.getLasthisttime());
		cmsTask.setCreateDate(expagTask.getCreatedate());
		cmsTask.setCreateTime(expagTask.getCreatetime());
		cmsTask.setCompleteDate(expagTask.getCompletedate());
		cmsTask.setCompleteTime(expagTask.getCompletetime());
		cmsTask.setReceivedDate(expagTask.getDatereceived());
		cmsTask.setReceivedTime(expagTask.getTimereceived());
		cmsTask.setAssignedTo(expagTask.getWorkbasket());
		// cmsTask.setTaskStatus(computeTaskStatus(expagTask));
		cmsTask.setStatusHistory(computeTaskStatuses(expagTask));;

		if ((expagTask.getIdentifiers() != null) && (expagTask.getIdentifiers().getIdentifiers().size() > 0)) {
			properties = expagIdentifiersTocmsProcessProperties(expagTask.getIdentifiers().getIdentifiers());
		}
		
		cmsTask.setTaskProperties(properties);

	}
	
	
	/**
	 * This is a common method to add a property of task
	 * @param fldNbr -  field number
	 * @param fieldName -  field name
	 * @param fieldValue - field value
	 * @param propDesc - property description
	 * @return 	NameValue
	 */
	public NameValue addProperty(BigInteger fldNbr, String fieldName, Object fieldValue, String propDesc) {
		NameValue parentNameValue = new NameValue();
		NameValue childNameValue = new NameValue();		
		childNameValue.setDsplSqncNbr(fldNbr);
		childNameValue.setName(fieldName);
		if(fieldValue instanceof String){
			childNameValue.setValue(fieldValue.toString());
		}else if(fieldValue instanceof Boolean){
			Boolean boolVal = (Boolean) fieldValue;
			childNameValue.setBooleanValue(boolVal);
		}else if(fieldValue instanceof BigInteger){
			BigInteger bigIntVal = (BigInteger) fieldValue;
			childNameValue.setNumValue(bigIntVal);
		}else if(fieldValue instanceof XMLGregorianCalendar){
			XMLGregorianCalendar xmlGreCalVal = (XMLGregorianCalendar) fieldValue;
			childNameValue.setDateValue(xmlGreCalVal);
		}else if(fieldValue instanceof BigDecimal){
			BigDecimal bigDecimalVal = (BigDecimal) fieldValue;
			childNameValue.setDecimalValue(bigDecimalVal);
		}else if(fieldValue instanceof org.tiaa.esb.case_management_rs_v2.type.Clob){
			org.tiaa.esb.case_management_rs_v2.type.Clob clobVal = (org.tiaa.esb.case_management_rs_v2.type.Clob) fieldValue;
			childNameValue.setClob(clobVal);
		}
		parentNameValue.setDesc(propDesc);
		parentNameValue.getChildrenNameValues().add(childNameValue);
		return parentNameValue;
	}

	public Properties addOmniTransType( String taskType,String actionStep, Properties properties) {
		String omniTransType = expagDAO.getOmniTransType(taskType,actionStep);
		NameValue childValue= new NameValue();
		NameValue parentNameValue = new NameValue();
		parentNameValue.setDesc(OMNI_TRANS_TYPE);
		childValue=createChildNameValue(1, OMNI_TRANS_TYPE, omniTransType);
		parentNameValue.getChildrenNameValues().add(childValue);
		properties.getProperties().add(parentNameValue);
		return properties;
	}
	
	private Processes getProcessesFromExpagTasks(List<ExpagWorkItem> expagWorkItems) {

		Processes processes = new Processes();
		LOGGER.debug("getProcessesFromExpagTasks start:" + System.currentTimeMillis());
		
		List<ExpagStatusHistory> suspendedTasks = this.getTaskSuspendedHistory(expagWorkItems);
		Map<String, Integer> suspendedDuration = calculateSuspendedDuration(suspendedTasks);
		
		for (ExpagWorkItem expagTask : expagWorkItems) {
			Process process = new Process();
			Tasks tasks = new Tasks();
			if (expagTask != null) {
				Task cmsTask = new Task();
				process.setProcessId(expagTask.getPacketId());
				cmsTask.setID(expagTask.getTaskId());
				cmsTask.setType(expagTask.getTaskType());
				cmsTask.setDepartment(expagTask.getDepartment());
				org.tiaa.esb.case_management_rs_v2.type.List list = new org.tiaa.esb.case_management_rs_v2.type.List();
				list.getItems().add(expagTask.getActionStep());
				cmsTask.setAction(list);
				cmsTask.setActionStep(expagTask.getActionStep());
				cmsTask.setAssignedTo(expagTask.getAssignedTo());
				if (StringUtils.isNotBlank(expagTask.getCreateDateTime())) {
					String[] createDateTime = expagTask.getCreateDateTime().split("\\s", 2);
					String createDate = createDateTime[0];
					String createTime = createDateTime[1];
					cmsTask.setCreateDate(DateUtil.convertDate(createDate));
					cmsTask.setCreateTime(DateUtil.convertTime(createTime));
				}

				if (StringUtils.isNotBlank(expagTask.getReceivedDateTime())) {
					String[] receivedDateTime = expagTask.getReceivedDateTime().split("\\s", 2);
					String receivedDate = receivedDateTime[0];
					String receivedTime = receivedDateTime[1];
					cmsTask.setReceivedDate(DateUtil.convertDate(receivedDate));
					cmsTask.setReceivedTime(DateUtil.convertTime(receivedTime));
				}

				if (StringUtils.isNotBlank(expagTask.getUpdatedDateTime())) {
					String[] updatedDateTime = expagTask.getUpdatedDateTime().split("\\s", 2);
					String updatedDate = updatedDateTime[0];
					String updatedTime = updatedDateTime[1];
					cmsTask.setLastUpdatedDate(DateUtil.convertDate(updatedDate));
					cmsTask.setLastUpdatedTime(DateUtil.convertTime(updatedTime));
				}

				Statuses statuses = new Statuses();
				Status status = new Status();
				if (StringUtils.isNotBlank(expagTask.getAwakeDateTime())) {
					String[] awakeDateTime = expagTask.getAwakeDateTime().split("\\s", 2);
					String awakeDate = awakeDateTime[0];
					String awakeTime = awakeDateTime[1];
					cmsTask.setAwakeDate(DateUtil.convertDate(awakeDate));
					cmsTask.setAwakeTime(DateUtil.convertTime(awakeTime));

					status.setSts(TASK_STATUS_SUSPENDED);
					statuses.getSts().add(status);
				} else {

					if (StringUtils.isNotBlank(expagTask.getLockOper())) {
						status.setSts(TASK_STATUS_ACTIVE);
						// set operator name when the task status is
						// active/locked
						cmsTask.setLocked(true);
						cmsTask.setLockedBy(expagTask.getLockOperatorFullName());
					} else {
						status.setSts(TASK_STATUS_OPEN);
						cmsTask.setLocked(false);
					}
					statuses.getSts().add(status);
				}
				cmsTask.setStatusHistory(statuses);
				Properties processProperties = new Properties();

				if (StringUtils.isNotBlank(expagTask.getPlanId())) {
					NameValue parentNameValue = new NameValue();
					NameValue childNameValue = new NameValue();
					childNameValue.setName("PLAN");
					childNameValue.setDsplSqncNbr(BigInteger.ONE);
					childNameValue.setValue(expagTask.getPlanId());
					parentNameValue.setDesc("PLAN");
					parentNameValue.getChildrenNameValues().add(childNameValue);
					processProperties.getProperties().add(parentNameValue);
				}

				if (StringUtils.isNotBlank(expagTask.getPlanName())) {
					NameValue parentNameValue = new NameValue();
					NameValue childNameValue = new NameValue();
					childNameValue.setName("PLANNAME");
					childNameValue.setDsplSqncNbr(BigInteger.ONE);
					childNameValue.setValue(expagTask.getPlanName());
					parentNameValue.setDesc("PLAN NAME");
					parentNameValue.getChildrenNameValues().add(childNameValue);
					processProperties.getProperties().add(parentNameValue);
				}

				if (StringUtils.isNotBlank(expagTask.getPin())) {
					NameValue childNameValue = new NameValue();
					NameValue parentNameValue = new NameValue();
					childNameValue.setName("PIN");
					childNameValue.setDsplSqncNbr(BigInteger.ONE);
					childNameValue.setValue(expagTask.getPin());
					parentNameValue.setDesc("PIN");
					parentNameValue.getChildrenNameValues().add(childNameValue);
					processProperties.getProperties().add(parentNameValue);
				}

				if (StringUtils.isNotBlank(expagTask.getNpin())) {
					NameValue childNameValue = new NameValue();
					NameValue parentNameValue = new NameValue();
					childNameValue.setName("NPIN");
					childNameValue.setDsplSqncNbr(BigInteger.ONE);
					childNameValue.setValue(expagTask.getNpin());
					parentNameValue.setDesc("NPIN");
					parentNameValue.getChildrenNameValues().add(childNameValue);
					processProperties.getProperties().add(parentNameValue);
				}
				
				if (StringUtils.isNotBlank(expagTask.getTradeDate())) {
					NameValue childNameValue = new NameValue();
					NameValue parentNameValue = new NameValue();
					childNameValue.setName("TRADEDATE");
					childNameValue.setDsplSqncNbr(BigInteger.ONE);
					childNameValue.setValue(expagTask.getTradeDate());
					parentNameValue.setDesc("TRADE DATE");
					parentNameValue.getChildrenNameValues().add(childNameValue);
					processProperties.getProperties().add(parentNameValue);
				}
				if (StringUtils.isNotBlank(expagTask.getCheckAmount())){
					NameValue childNameValue = new NameValue();
					NameValue parentNameValue = new NameValue();
					childNameValue.setName("CHECKAMOUNT");
					childNameValue.setDsplSqncNbr(BigInteger.ONE);
					childNameValue.setValue(expagTask.getCheckAmount());
					parentNameValue.setDesc("CHECK AMOUNT");
					parentNameValue.getChildrenNameValues().add(childNameValue);
					processProperties.getProperties().add(parentNameValue);
				}
				process.setProcessProperties(processProperties);
				int suspDuration = suspendedDuration.get(cmsTask.getID()) != null ? suspendedDuration.get(cmsTask.getID()) : 0;
				org.tiaa.esb.case_management_rs_v2.type.SLADetail slaDetail = computeSLADetails(cmsTask, suspDuration);

				tasks.getTasks().add(cmsTask);
				process.setTasks(tasks);
				process.setSLADetail(slaDetail);
				process.setAppName(APP_EXPAG);
			}
			processes.getProcesses().add(process);
		}
		LOGGER.debug("getProcessesFromExpagTasks end" + System.currentTimeMillis());
		return processes;
	}
	
	/**
	 * List the Task History from Database
	 * @param expagWorkItems
	 * @return
	 */
	public List<ExpagStatusHistory> getTaskSuspendedHistory(List<ExpagWorkItem> expagWorkItems) {
		if (CollectionUtils.isEmpty(expagWorkItems)) {
			return Collections.emptyList();
		}
		Set<String> taskSet = new HashSet<String>();
		for (ExpagWorkItem expagTask : expagWorkItems) {
			taskSet.add(expagTask.getTaskId());
		}
		List<ExpagStatusHistory> taskHistorySuspendedDurationList = expagDAO.getExpagWorkItemSuspendedHistory(taskSet);
		return taskHistorySuspendedDurationList;
	}
	
	/**
	 * Calculate the Suspend duration and form a map of taskid = susp-duration
	 * @param taskHistorySuspendedDurationList
	 * @return
	 */
	public Map<String, Integer> calculateSuspendedDuration(List<ExpagStatusHistory> taskHistorySuspendedDurationList) {
		Map<String, Integer> taskSuspendedDaysMap = new HashMap<String, Integer>();
		
		if (CollectionUtils.isEmpty(taskHistorySuspendedDurationList)) {
			return taskSuspendedDaysMap;
		}
		Set<String> suspTaskSet = new HashSet<String>();
		String currentTskId = "";
		boolean isTaskSuspended = false;
		
		Date parsedDate;
		Integer totalSuspendedDuration = 0;
		DateTime suspTimeStartDateTime = new DateTime();
		DateTime suspTimeEndDateTime = new DateTime();
		
		for (ExpagStatusHistory suspTask : taskHistorySuspendedDurationList) {
			if (suspTaskSet.add(suspTask.getTaskId())) {
				if (isTaskSuspended) {
					suspTimeEndDateTime = new DateTime();
					totalSuspendedDuration += getTotalSuspendedDays(suspTimeStartDateTime, suspTimeEndDateTime);
				}
				if (!"".equalsIgnoreCase(currentTskId)) {
					taskSuspendedDaysMap.put(currentTskId, totalSuspendedDuration);
				}
				currentTskId = suspTask.getTaskId();
				isTaskSuspended = false;
				totalSuspendedDuration = 0;
			}
			if ("S".equalsIgnoreCase(suspTask.getStatus())) {
				isTaskSuspended = true;
				parsedDate = convertSuspendedDate(suspTask.getEnddatetime());
				suspTimeStartDateTime = new DateTime(parsedDate);
			}
			if ((isTaskSuspended && "N".equalsIgnoreCase(suspTask.getStatus()))
					|| (isTaskSuspended && "U".equalsIgnoreCase(suspTask.getStatus()))) {
				parsedDate = convertSuspendedDate(suspTask.getEnddatetime());
				suspTimeEndDateTime = new DateTime(parsedDate);
				totalSuspendedDuration += getTotalSuspendedDays(suspTimeStartDateTime, suspTimeEndDateTime);
				isTaskSuspended = false;
			}
			
		}
		//Calculation for last item
		//Check if the task is in Suspended status
		if (isTaskSuspended) {
			suspTimeEndDateTime = new DateTime();
			totalSuspendedDuration += getTotalSuspendedDays(suspTimeStartDateTime, suspTimeEndDateTime);
			isTaskSuspended = false;
		}
		if (!"".equalsIgnoreCase(currentTskId)) {
			taskSuspendedDaysMap.put(currentTskId, totalSuspendedDuration);
		}
		LOGGER.info("The list of Task Suspension Duration Map: " + taskSuspendedDaysMap);
		return taskSuspendedDaysMap;
	}
	
	private int getTotalSuspendedDays(DateTime suspTimeStartDateTime, DateTime suspTimeEndDateTime) {
		int totalSuspendedDays = 0;
		/**
		 * If both Suspended days and Awake days are within the same day
		 * don't consider it, unless, it is within whole Business Hours
		 * **/
		boolean sameDay = isSameDay(suspTimeStartDateTime, suspTimeEndDateTime);
		if (sameDay && !(suspTimeStartDateTime.getHourOfDay() < 1 && suspTimeStartDateTime.getMinuteOfDay() < 1)) {
			return totalSuspendedDays;
		}
		/**
		 * Calculate the total Suspended days duration
		 * Exclude the Weekends, or Holidays
		 */
		/**
		 * If suspension took place after 4 pm, it should be considered next day
		 * the best way forward is to reset the clocks to 4 pm on the corresponding day, or
		 * the previous Business day if current day is holiday
		 */
		if (isAfterBusinessHour(suspTimeStartDateTime) || isWeekendOrHoliday(suspTimeStartDateTime)) {
			//Reset the clock to 16:00:00 hours on that day
			suspTimeStartDateTime = suspTimeStartDateTime.withHourOfDay(16).withMinuteOfHour(0).withSecondOfMinute(0);
			suspTimeStartDateTime = advanceToPreviousBusinessEOD(suspTimeStartDateTime);
		}
		/**
		 * Special handling required if task is suspended at exact midnight (00:00 Hours)
		 * advance it to previous day EOD
		 */
		if (suspTimeStartDateTime.getHourOfDay() < 1 && suspTimeStartDateTime.getMinuteOfDay() < 1) {
			//Reset the clock to 16:00:00 hours on that day
			suspTimeStartDateTime = suspTimeStartDateTime.minusDays(1).withHourOfDay(16).withMinuteOfHour(0).withSecondOfMinute(0);
			suspTimeStartDateTime = advanceToPreviousBusinessEOD(suspTimeStartDateTime);
		}
		/**
		 * Same for Suspension End - if end time exceeds Business hour, reset it 
		 */
		if (isAfterBusinessHour(suspTimeEndDateTime)) {
			//Reset the clock to 16:00:00 hours on that day
			suspTimeEndDateTime = suspTimeEndDateTime.withHourOfDay(16).withMinuteOfHour(0).withSecondOfMinute(0);
		}
		//Loop
		while(suspTimeStartDateTime.toDate().getTime() < suspTimeEndDateTime.toDate().getTime()) {
			//Advance suspension start date
			suspTimeStartDateTime = suspTimeStartDateTime.plusDays(1);
			//If not weekend or holiday, advance count
			if (!isWeekendOrHoliday(suspTimeStartDateTime)) {
				//if suspension end date is reached, no need to iterate further
				if (isSameDay(suspTimeStartDateTime, suspTimeEndDateTime)) {
					/** Check that the task is suspended for 24 hours (give a 59 seconds relaxation)
					 ** */
					org.joda.time.Duration suspendDuration = new org.joda.time.Duration(suspTimeStartDateTime, suspTimeEndDateTime);
					if (suspendDuration.getStandardSeconds() > -59) {
						totalSuspendedDays++;
					}
					break;
				} else {
					//else, increase counter
					++totalSuspendedDays;
				}
			}
		} 
		return totalSuspendedDays;
	}
	
	private boolean isWeekendOrHoliday(DateTime dateTime) {
		return holidaysCache.isHoliday(dateTime.getYear(), dateTime.toLocalDate()) || dateTime.getDayOfWeek() == DateTimeConstants.SATURDAY || dateTime.getDayOfWeek() == DateTimeConstants.SUNDAY;
	}
	
	private boolean isAfterBusinessHour(DateTime dateTime) {
		return dateTime.get(DateTimeFieldType.clockhourOfDay()) >= 16 && dateTime.get(DateTimeFieldType.clockhourOfDay()) < 24;
	}
	
	private boolean isSameDay(DateTime suspTimeStartDateTime, DateTime suspTimeEndDateTime) {
		return (suspTimeStartDateTime.get(DateTimeFieldType.dayOfMonth()) == suspTimeEndDateTime.get(DateTimeFieldType.dayOfMonth()))
				&& (suspTimeStartDateTime.get(DateTimeFieldType.monthOfYear()) == suspTimeEndDateTime.get(DateTimeFieldType.monthOfYear()))
				&& suspTimeStartDateTime.get(DateTimeFieldType.year()) == suspTimeEndDateTime.get(DateTimeFieldType.year());
	}
	
	private DateTime advanceToPreviousBusinessEOD(DateTime suspTimeStartDateTime) {
		while (isWeekendOrHoliday(suspTimeStartDateTime)) {
			suspTimeStartDateTime = suspTimeStartDateTime.minusDays(1);
		}
		return suspTimeStartDateTime;
	}
	
	private Date convertSuspendedDate(String dateString) {
		try {
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date date = df.parse(dateString);
			return date;
		} catch (ParseException e) {
			//Do Nothing
		}
		return null;
	}

	public RelatedTasks getRelatedTasks(String taskId, WorkPacket workPacket) {

		RelatedTasks relatedTasks = new RelatedTasks();

		if ((workPacket != null) && (workPacket.getTasks().getCount() > 0))
			for (org.tiaa.esb.powerimage.types.Task expagTaskFromPacket : workPacket.getTasks().getTasks())
				if ((expagTaskFromPacket != null) && !taskId.equalsIgnoreCase(expagTaskFromPacket.getTaskid())) {

					Task cmsRelatedtask = new Task();

					expagTaskTocmsTask(expagTaskFromPacket, cmsRelatedtask);

					relatedTasks.getRelatedTasks().add(cmsRelatedtask);
				}
		return relatedTasks;
	}

	
	public Processes getWorkItemsfromDB(String userId, String department, String type, int start) {
		List<Callable<List<ExpagWorkItem>>> searchExpagTasks = new ArrayList<Callable<List<ExpagWorkItem>>>();
		List<ExpagWorkItem> allExpagWorkItems = new ArrayList<ExpagWorkItem>();
		ExecutorService executor = null;
		try {
			GetExpagWorkItems getExpagWorkItems = new GetExpagWorkItems(StringUtils.rightPad(userId, 8), type, department, start);
			searchExpagTasks.add(getExpagWorkItems);

			executor = Executors.newFixedThreadPool(searchExpagTasks.size());
			List<Future<List<ExpagWorkItem>>> results = executor.invokeAll(searchExpagTasks);
			for (Future<List<ExpagWorkItem>> future : results)
				allExpagWorkItems.addAll(future.get());

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (executor != null)
				executor.shutdown();
		}
		LOGGER.debug("getWorkItemsfromDB after executor:" + System.currentTimeMillis());
		Processes processes = getProcessesFromExpagTasks(allExpagWorkItems);
		LOGGER.debug("getWorkItemsfromDB after conversion:" + System.currentTimeMillis());
		return processes;
		
	}
	
	public boolean  triggerRoutingRule(String userId, String taskId, Task cmsTask, List<TaskIdentifiersValue> entites) {
        
		for (TaskIdentifiersValue entity : entites) {
    		if(cmsTask.getTaskProperties() != null && cmsTask.getTaskProperties().getProperties().size() > 0){
    			List<NameValue> properties = cmsTask.getTaskProperties().getProperties();
           			for(NameValue param : properties){
           				if(entity.getIdDesc().equals(param.getDesc())){
           					List<NameValue> childernValueList = param.getChildrenNameValues();
           					for(NameValue identifiers : childernValueList){
           						if (!(identifiers.getValue().equals(entity.getFieldValue()))) {
                       
           							this.expagDAO.getRoutingRuleAlgorithm(userId, taskId);
           							LOGGER.debug(entity.getIdDesc()+"Routing Rules applied for the taskID "+taskId);
           							return true;
            			   
           						}

           					}
               
           				}
           			}
    			}
    		}
    	return false;
	}
	
	public ConfigItem getExternalizationCache(String property) {
		ConfigItem configItem = new ConfigItem();
		configItem.setItemName(property);

		try {
			for (Map.Entry<Integer, Set<LocalDate>> entry : HolidaysCache
					.getHolidaysMap().entrySet()) {
				ConfigData configdata = new ConfigData();
				configdata.setShortDescription(entry.getKey().toString());
				
				SubFields subfields = new SubFields();
				Set<LocalDate> dateSet = (Set<LocalDate>) entry.getValue();
				for (LocalDate date : dateSet) {
					SubField subField = new SubField();
					subField.setFieldValue(date.toString());
					subfields.getSubFields().add(subField);
				}
				configdata.setSubFields(subfields);
				configItem.getDataPairs().add(configdata);
			}
		} catch (Exception e) {
			LOGGER.debug("Exception while getExternalizationCache for property:"
					+ property + ", Exception:" + e.getMessage());
		}

		return configItem;
	}
}
