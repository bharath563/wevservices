package org.tiaa.case_management_rs.integration.cth;

import static org.tiaa.case_management_rs.domain.TaskInfo.*;

import java.util.Date;
import java.util.List;

import javax.xml.transform.dom.DOMResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;

import org.tiaa.case_management_rs.constants.FileTypes;
import org.tiaa.case_management_rs.domain.Identifier;
import org.tiaa.case_management_rs.domain.TaskInfo;
import org.tiaa.case_management_rs.domain.TaskStatus;
import org.tiaa.case_management_rs.integration.exp_ag.DocumentCopier;
import org.tiaa.case_management_rs.utils.CommonUtil;
import org.tiaa.case_management_rs.utils.DateUtil;
import org.tiaa.esb.partyrequest.types.PartyRequestControlInfo;
import org.tiaa.esb.partyrequest.types.PayloadInfo;
import org.tiaa.esb.partyrequest.types.RequestInfo;
import org.tiaa.esb.partyrequest.types.UpdatePartyRequest;
import org.tiaa.esb.servicerequest_workflow.types.CaseDetailsType;
import org.tiaa.esb.servicerequest_workflow.types.CaseInfo;
import org.tiaa.esb.servicerequest_workflow.types.DocumentType;
import org.tiaa.esb.servicerequest_workflow.types.DocumentsType;
import org.tiaa.esb.servicerequest_workflow.types.IdentifiersType;
import org.tiaa.esb.servicerequest_workflow.types.NameValuePairType;
import org.tiaa.esb.servicerequest_workflow.types.TaskDetailType;
import org.tiaa.esb.servicerequest_workflow.types.TaskDetailsType;

public abstract class PayloadInfoBuilder {
	private static final Logger LOG = LoggerFactory.getLogger(PayloadInfoBuilder.class);
	protected Jaxb2Marshaller cthJaxb2WorkflowMarshaller;
	protected Jaxb2Marshaller servicerequestWorkflowJaxb2Marshaller;
	protected boolean setDocuments;
	private boolean mapIdentifiers;
	private String requestSchemaName = "";
	private String requestSchemaVersion = "";
	@Autowired
	protected DocumentCopier documentCopier;

	public PayloadInfoBuilder(String requestSchemaName, String requestSchemaVersion) {
		super();
		this.requestSchemaName = requestSchemaName;
		this.requestSchemaVersion = requestSchemaVersion;
	}

	public PayloadInfo build(CreateCTHContext context) {
		RequestInfo requestInfo = new RequestInfo();
		requestInfo.setAny(setRequestInfoAnyElement(context));
		//
		PayloadInfo payloadInfo = new PayloadInfo();
		payloadInfo.setRequestInfo(requestInfo);
		payloadInfo.setRequestSchemaName(requestSchemaName);
		payloadInfo.setRequestSchemaVersion(requestSchemaVersion);
		return payloadInfo;
	}

	public CaseInfo ensureValidCaseInfo(UpdateCTHContext context) {
		CaseInfo caseInfo = context.getCaseInfo();
		if (caseInfo == null) {
			caseInfo = new CaseInfo();
			context.setCaseInfo(caseInfo);
		}
		CaseDetailsType caseDetails = caseInfo.getCaseDetails();
		if (caseDetails == null) {
			caseDetails = new CaseDetailsType();
			caseInfo.setCaseDetails(caseDetails);
		}
		if (caseDetails.getIdentifiers() == null) {
			caseDetails.setIdentifiers(new IdentifiersType());
		}

		TaskDetailsType taskDetails = caseInfo.getTaskDetails();
		if (taskDetails == null) {
			taskDetails = new TaskDetailsType();
			caseInfo.setTaskDetails(taskDetails);
		}
		List<TaskDetailType> taskDetailsList = taskDetails.getTaskDetails();
		if (taskDetailsList.isEmpty()) {
			taskDetailsList.add(new TaskDetailType());
		}
		for (TaskDetailType taskDetailType : taskDetailsList) {
			if (taskDetailType.getIdentifiers() == null) {
				taskDetailType.setIdentifiers(new IdentifiersType());
			}
		}
		DocumentsType documents = caseInfo.getDocuments();
		if (documents == null) {
			documents = new DocumentsType();
			documentCopier.copyDocumentsFromEXPAGToMobius(context.getTaskInfo());
			caseInfo.setDocuments(documents);
		}
		return caseInfo;
	}

	public CaseInfo mapCaseInfo(CTHContext context) {
		TaskDetailType taskDetailType = new TaskDetailType();
		updateTaskDetails(context, taskDetailType);
		addTaskIdentifiers(context, taskDetailType);
		//
		TaskDetailsType taskDetailsType = new TaskDetailsType();
		taskDetailsType.getTaskDetails().add(taskDetailType);
		//
		CaseInfo caseInfo = new CaseInfo();
		caseInfo.setTaskDetails(taskDetailsType);
		caseInfo.setDocuments(mapDocuments(context));
		CaseDetailsType caseDetailsType = new CaseDetailsType();
		caseDetailsType.setIdentifiers(new IdentifiersType());
		updateCaseDetails(context, caseDetailsType);
		caseInfo.setCaseDetails(caseDetailsType);
		return caseInfo;
	}

	public boolean updateCTH(UpdateCTHContext context, String status) {
		CaseInfo caseInfo = ensureValidCaseInfo(context);
		TaskInfo taskInfo = context.getTaskInfo();
		final String cthStatus = getCthStatus(context, status);
		updateStatus(context, cthStatus);
		if (taskInfo.hasDocuments()) {
			LOG.debug("update document info");
			updateDocumentsType(context, caseInfo);
		}
		updateCaseDetails(context, caseInfo.getCaseDetails());
		for (TaskDetailType taskDetailType : caseInfo.getTaskDetails().getTaskDetails()) {
			updateTaskDetails(context, taskDetailType);
			addTaskIdentifiers(context, taskDetailType);
		}
		return true;
	}

	public void setCthJaxb2WorkflowMarshaller(Jaxb2Marshaller cthJaxb2WorkflowMarshaller) {
		this.cthJaxb2WorkflowMarshaller = cthJaxb2WorkflowMarshaller;
	}

	public void setServicerequestWorkflowJaxb2Marshaller(Jaxb2Marshaller servicerequestWorkflowJaxb2Marshaller) {
		this.servicerequestWorkflowJaxb2Marshaller = servicerequestWorkflowJaxb2Marshaller;
	}

	protected abstract Element setRequestInfoAnyElement(CreateCTHContext context);

	protected Element toElement(Object obj, Jaxb2Marshaller jaxb2Marshaller) {
		DOMResult domResult = new DOMResult();
		jaxb2Marshaller.marshal(obj, domResult);
		org.w3c.dom.Document node = (org.w3c.dom.Document) domResult.getNode();
		return node.getDocumentElement();
	}

	private void addTaskIdentifiers(CTHContext context, TaskDetailType taskDetailType) {
		IdentifiersType identifiersType = new IdentifiersType();
		taskDetailType.setIdentifiers(identifiersType);
		List<NameValuePairType> identifierType = identifiersType.getIdentifierTypes();
		List<Identifier> identifiers = context.getIdentifiers().getIdentifiers();
		for (Identifier identifier : identifiers) {
			String name = identifier.getName();
			if (!"SSN".equals(name)) {
				NameValuePairType nameValuePairType = new NameValuePairType();
				nameValuePairType.setName(name);
				nameValuePairType.setValue(identifier.getStringValue());
				identifierType.add(nameValuePairType);
			}
		}
	}

	private boolean foundDocument(DocumentType documentToFind, List<DocumentType> documentList) {
		for (DocumentType documentType : documentList) {
			String documentId = getDocumentId(documentType);
			if (documentId.equals(getDocumentId(documentToFind))) {
				LOG.debug("document already exists: {}", documentId);
				return true;
			}
			String originalDocumentID = documentType.getOriginalDocumentID();
			if (originalDocumentID != null && originalDocumentID.equals(documentToFind.getOriginalDocumentID())) {
				LOG.debug("original document already exists: {}", documentId);
				return true;
			}
		}
		return false;
	}

	public static DocumentType findDocument(DocumentType documentToFind, List<DocumentType> documentList) {
		for (DocumentType documentType : documentList) {
			String documentId = getDocumentId(documentType);
			if (documentId.equals(getDocumentId(documentToFind))) {
				LOG.debug("document already exists: {}", documentId);
				return documentType;
			}
			String originalDocumentID = documentType.getOriginalDocumentID();
			if (originalDocumentID != null && originalDocumentID.equals(documentToFind.getOriginalDocumentID())) {
				LOG.debug("original document already exists: {}", documentId);
				return documentType;
			}
		}
		return null;
	}

	private String getCthStatus(UpdateCTHContext context, String status) {
		TaskInfo taskInfo = context.getTaskInfo();
		if (taskInfo.updateTaskStatusInCTH(status)) {
			return taskInfo.getCthStatus();
		}
		if (taskInfo.isReopened(status)) {
			return TaskStatus.InProgress.getCthStatus();
		}
		return status;
	}

	private IdentifiersType mapCaseIdentifiers(CTHContext context) {
		IdentifiersType identifiersType = new IdentifiersType();
		List<NameValuePairType> identifierTypes = identifiersType.getIdentifierTypes();
		for (Identifier identifier : context.getIdentifiers().getIdentifiers()) {
			String name = identifier.getName();
			if (!"SSN".equals(name)) {
				NameValuePairType nameValuePairType = new NameValuePairType();
				nameValuePairType.setName(name);
				nameValuePairType.setValue(identifier.getStringValue());
				//
				identifierTypes.add(nameValuePairType);
			}
		}
		return identifiersType;
	}

	private org.tiaa.esb.servicerequest_workflow.types.DocumentsType mapDocuments(CTHContext context) {
		org.tiaa.esb.servicerequest_workflow.types.DocumentsType documentsType = new org.tiaa.esb.servicerequest_workflow.types.DocumentsType();
		List<DocumentType> documentList = documentsType.getDocuments();
		TaskInfo taskInfo = context.getTaskInfo();
		for (DocumentType documentType : taskInfo.getDocuments()) {
			DocumentType archivedDocument = documentCopier.copyDocumentFromEXPAGToMobius(taskInfo, documentType);
			LOG.debug("add document:" + ReflectionToStringBuilder.toString(archivedDocument));
			documentList.add(archivedDocument);
		}
		return documentsType;
	}

	private CaseDetailsType updateCaseDetails(CTHContext context, CaseDetailsType caseDetailsType) {
		TaskInfo taskInfo = context.getTaskInfo();
		caseDetailsType.setCaseId(taskInfo.getWorkpacketId());
		caseDetailsType.setCaseType(taskInfo.getTaskType());
		caseDetailsType.setCreateDate(DateUtil.toXMLGregorianCalendar(new Date()));
		if (mapIdentifiers) {
			caseDetailsType.setIdentifiers(mapCaseIdentifiers(context));
		}
		caseDetailsType.setStatus(taskInfo.getTaskStatusAsStr());
		return caseDetailsType;
	}

	private void updateDocumentsType(CTHContext context, CaseInfo caseInfo) {
		TaskInfo taskInfo = context.getTaskInfo();
		Boolean hasValidFileType = false;
		//
		List<DocumentType> documentList = caseInfo.getDocuments().getDocuments();
		for (DocumentType document : taskInfo.getDocuments()) {
			DocumentType foundDocument = findDocument(document, documentList);
			if (foundDocument == null) {
				DocumentType archivedDocument = documentCopier.copyDocumentFromEXPAGToMobius(taskInfo, document);
				LOG.debug("add document:" + ReflectionToStringBuilder.toString(archivedDocument));
				String documentType = archivedDocument.getDocumentType();
				String fileExtension = documentType == null ? null : documentType.substring(documentType.lastIndexOf(".") + 1);
				hasValidFileType = fileExtension == null ? false : FileTypes.isValid(fileExtension);

				if((CommonUtil.isNullOrEmpty(archivedDocument.getDocumentStatus()) || archivedDocument.getDocumentStatus().equals("REQUIRED"))
						&& ((archivedDocument.getDocumentCategoryType().equals("CORRESPONDENCE - INBOUND") || archivedDocument.getDocumentCategoryType().equals("CORRESPONDENCE - OUTBOUND")))
						&& taskInfo.isServiceRequest()  && hasValidFileType){
					archivedDocument.setDocumentRead(false);
					archivedDocument.setDocumentUploadedDateTime(archivedDocument.getBusinessDate());
				}
				documentList.add(archivedDocument);
			}
		}

		//If DocumentUploadedDateTime/DocumentRead are not available in CTH Response CLOB
		if(taskInfo.isServiceRequest()){
			for(DocumentType document : documentList){
				String documentType = document.getDocumentType();
				String fileExtension = documentType == null ? null : documentType.substring(documentType.lastIndexOf(".") + 1);
				hasValidFileType = fileExtension == null ? false : FileTypes.isValid(fileExtension);
				if((document.getDocumentUploadedDateTime() == null || document.isDocumentRead() == null) && document.getDocumentStatus().equals("REQUIRED")
						&& (document.getDocumentCategoryType().equals("CORRESPONDENCE - INBOUND") || document.getDocumentCategoryType().equals("CORRESPONDENCE - OUTBOUND")) && hasValidFileType){
					Date date = document.getBusinessDate().toGregorianCalendar().getTime();
					document.setDocumentUploadedDateTime(DateUtil.toXMLGregorianCalendar(date));
					document.setDocumentRead(true);
				}
			}
		}
	}

	private void updateStatus(UpdateCTHContext updateCTHContext, String status) {
		UpdatePartyRequest updatePartyRequest = updateCTHContext.getUpdatePartyRequest();
		PartyRequestControlInfo partyRequestControlInfo = updatePartyRequest.getPartyReqControlInfo();
		partyRequestControlInfo.setStatus(status);
	}

	private void updateTaskDetails(CTHContext context, TaskDetailType taskDetailType) {
		TaskInfo taskInfo = context.getTaskInfo();
		//
		LOG.debug("taskInfo:{}", taskInfo);
		taskDetailType.setActionStep(taskInfo.getActcode());
		taskDetailType.setAssignedTo(taskInfo.getOperatorId());
		taskDetailType.setCreateDate(DateUtil.toXMLGregorianCalendar(taskInfo.getRecievedDateTime()));
		taskDetailType.setDepartment(taskInfo.getDepartmentCode());
		taskDetailType.setPriority(taskInfo.getPriority());
		taskDetailType.setReceivedDate(DateUtil.toXMLGregorianCalendar(taskInfo.getRecievedDateTime()));
		taskDetailType.setStatus(taskInfo.getCthStatus());
		taskDetailType.setTaskId(taskInfo.getTaskId());
		taskDetailType.setTaskType(taskInfo.getTaskType());
		taskDetailType.setVIPIndicator(taskInfo.getVipIndicator());
		taskDetailType.setWorkbasket(taskInfo.getWorkBasket());
		if (taskInfo.isCompleted()) {
			taskDetailType.setCompleteDate(DateUtil.toXMLGregorianCalendar(taskInfo.getCompletedDateTime()));
		}
	}
}
