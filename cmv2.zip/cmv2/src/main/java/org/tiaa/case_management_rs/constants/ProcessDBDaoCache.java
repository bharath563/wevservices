package org.tiaa.case_management_rs.constants;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import org.tiaa.case_management_rs.dao.CMSTaskTypeSla;
import org.tiaa.case_management_rs.dao.ProcessDBDAO;


@Component
public class ProcessDBDaoCache {
	private static final Logger LOGGER = LoggerFactory.getLogger(ProcessDBDaoCache.class);

	public static Map<String, Integer> taskTypeSlaMap = Collections.synchronizedMap(new HashMap<String, Integer>());
	public static Map<String, Integer> getTaskTypeSlaMap() {
		return taskTypeSlaMap;
	}

	public static void setTaskTypeSlaMap(Map<String, Integer> taskTypeSlaMap) {
		ProcessDBDaoCache.taskTypeSlaMap = taskTypeSlaMap;
	}


	private ProcessDBDAO processDBDao;
	
	@Scheduled(cron = "${cache.refresh.cron}")
    public void refreshCacheData() {
    	if(taskTypeSlaMap.keySet().size() > 0){
    		refershUpdatedTaskTypeSla();
    	} else {
    		setAllTaskTypeSlaMap();
    	}
    }


	@Autowired
	@Inject
	public ProcessDBDaoCache(ProcessDBDAO processDBDao){
		this.processDBDao =processDBDao;
		setAllTaskTypeSlaMap();
	}

	/**
	 * This method fetches data for a specific task type from Cache, if it does not exist in Cache - it hits DB again.
	 * sla is set to null, when the tasktype is not found in DB OR tasktype sla value is null
	 * @param taskType
	 * @return
	 */
	public  Integer getTaskTypeSla(String taskType) {
		if(!taskTypeSlaMap.containsKey(taskType)){
			LOGGER.debug("Task type " +taskType +"is not in cache.");
			if(!taskTypeSlaMap.containsKey(taskType)){
				taskTypeSlaMap.put(taskType, null);
			}
		}
		return taskTypeSlaMap.get(taskType);
	}

	private  void setAllTaskTypeSlaMap() {
		List<CMSTaskTypeSla> cmsTaskTypeSlaList = this.processDBDao.getAllTaskSLA();
		for(CMSTaskTypeSla each:cmsTaskTypeSlaList){
			taskTypeSlaMap.put(each.getTaskType(),each.getSla());
		}

	}
    
    private void refershUpdatedTaskTypeSla() {
    	List<CMSTaskTypeSla> cmsTaskTypeSlaList = this.processDBDao.getUpdatedSLA();
		for (CMSTaskTypeSla each : cmsTaskTypeSlaList) {
			LOGGER.info("Refreshing SLA cache with task: "+ each.getTaskType() + " with SLA: "+each.getSla());
			taskTypeSlaMap.put(each.getTaskType(), each.getSla());
		}
	}

}
