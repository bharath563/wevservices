package org.tiaa.case_management_rs.validator.impl;

import static org.tiaa.case_management_rs.constants.CaseManagementConstants.*;

import org.apache.commons.lang3.StringUtils;

import org.tiaa.case_management_rs.common.Request;
import org.tiaa.esb.case_management_rs_v2.type.TaskRequest;

public class UpdateTaskValidator extends BaseValidatorImpl {

	@Override
	public void doValidate(Request request) {
		String userId = (String) request.getAttribute(USER_ID);
		String wobId = (String) request.getAttribute(WOB_ID);
		String queueName = null;
		String action = null;
		TaskRequest taskRequest = (TaskRequest) request
				.getAttribute(TASK_REQUEST);
		if (taskRequest.getTask() != null) {

			action = taskRequest.getTask()
					.getAction().getItems().get(0);

			if (taskRequest.getTask().getQueues() != null
					&& taskRequest.getTask().getQueues().getItems().get(0) != null) {
				queueName = taskRequest.getTask().getQueues().getItems().get(0);

			}

		}
		if (StringUtils.isBlank(userId)) {
			handleException(VALIDATION_USERID_IS_EMPTY);
		}
		
		String appName = (String) request.getAttribute(APP_NAME);
		if(!APP_ACTIVITI.equalsIgnoreCase(appName)){
			
			if (StringUtils.isBlank(queueName)) {
				handleException(VALIDATION_ICM_QUEUENAME_IS_EMPTY);
			}
			if (StringUtils.isBlank(action)) {
				handleException(VALIDATION_ICM_ACTION_IS_EMPTY);
			}

			if (StringUtils.isBlank(wobId)) {
				handleException(VALIDATION_ICM_WOBID_ISEMPTY);
			}
		}
		

	}

}
