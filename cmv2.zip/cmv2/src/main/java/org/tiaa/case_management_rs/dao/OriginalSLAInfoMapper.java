package org.tiaa.case_management_rs.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import org.tiaa.case_management_rs.integration.exp_ag.AbstractRowMapper;

public class OriginalSLAInfoMapper extends AbstractRowMapper<Integer>implements RowMapper<Integer> {

	@Override
	public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {

		Integer originalSLA = rs.getInt("sla");

		return originalSLA;
	}

}
