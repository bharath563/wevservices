package org.tiaa.case_management_rs.email;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.io.IOUtils;

import org.tiaa.case_management_rs.common.ConfigurationException;

public class EmailBuilder {
	private String emailTemplate;

	public EmailBuilder() {
		this("EmailTemplate.html");
	}

	public EmailBuilder(String resource) {
		super();
		InputStream is = this.getClass().getClassLoader().getResourceAsStream(resource);
		try {
			emailTemplate = IOUtils.toString(is);
		} catch (IOException e) {
			throw new ConfigurationException(e);
		}
	}

	public String executeTemplate(Map<String, Object> variables) {
		Set<Entry<String, Object>> entrySet = variables.entrySet();
		for (Entry<String, Object> entry : entrySet) {
			replace("$" + entry.getKey(), entry.getValue());
		}
		return emailTemplate;
	}

	private void replace(String key, Object value) {
		String val;
		if (value instanceof String) {
			val = (String) value;
		} else if (value != null) {
			val = value.toString();
		} else {
			val = "";
		}
		emailTemplate = emailTemplate.replace(key, val);
	}
}