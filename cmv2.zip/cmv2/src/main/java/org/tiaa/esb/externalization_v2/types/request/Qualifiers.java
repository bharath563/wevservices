/**
 * Qualifiers.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tiaa.esb.externalization_v2.types.request;

public class Qualifiers  implements java.io.Serializable {
    private org.tiaa.esb.externalization_v2.types.request.Qualifier[] qualifier;

    private java.lang.String qualifierType;

    public Qualifiers() {
    }

    public Qualifiers(
           org.tiaa.esb.externalization_v2.types.request.Qualifier[] qualifier,
           java.lang.String qualifierType) {
           this.qualifier = qualifier;
           this.qualifierType = qualifierType;
    }


    /**
     * Gets the qualifier value for this Qualifiers.
     * 
     * @return qualifier
     */
    public org.tiaa.esb.externalization_v2.types.request.Qualifier[] getQualifier() {
        return qualifier;
    }


    /**
     * Sets the qualifier value for this Qualifiers.
     * 
     * @param qualifier
     */
    public void setQualifier(org.tiaa.esb.externalization_v2.types.request.Qualifier[] qualifier) {
        this.qualifier = qualifier;
    }

    public org.tiaa.esb.externalization_v2.types.request.Qualifier getQualifier(int i) {
        return this.qualifier[i];
    }

    public void setQualifier(int i, org.tiaa.esb.externalization_v2.types.request.Qualifier _value) {
        this.qualifier[i] = _value;
    }


    /**
     * Gets the qualifierType value for this Qualifiers.
     * 
     * @return qualifierType
     */
    public java.lang.String getQualifierType() {
        return qualifierType;
    }


    /**
     * Sets the qualifierType value for this Qualifiers.
     * 
     * @param qualifierType
     */
    public void setQualifierType(java.lang.String qualifierType) {
        this.qualifierType = qualifierType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Qualifiers)) return false;
        Qualifiers other = (Qualifiers) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.qualifier==null && other.getQualifier()==null) || 
             (this.qualifier!=null &&
              java.util.Arrays.equals(this.qualifier, other.getQualifier()))) &&
            ((this.qualifierType==null && other.getQualifierType()==null) || 
             (this.qualifierType!=null &&
              this.qualifierType.equals(other.getQualifierType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getQualifier() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getQualifier());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getQualifier(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getQualifierType() != null) {
            _hashCode += getQualifierType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Qualifiers.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", ">Qualifiers"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("qualifier");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "Qualifier"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "Qualifier"));
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("qualifierType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "QualifierType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
