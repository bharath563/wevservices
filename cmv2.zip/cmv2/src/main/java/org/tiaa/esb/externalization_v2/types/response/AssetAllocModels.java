/**
 * AssetAllocModels.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tiaa.esb.externalization_v2.types.response;

public class AssetAllocModels  implements java.io.Serializable {
    private java.lang.String modelCd;

    private java.lang.String modelDesc;

    private java.lang.String tickerSymbol;

    private java.lang.String modelCategory;

    private java.lang.Double modelRepeatingSeq;

    private java.lang.Double percentage;

    private java.lang.Double equityPercentage;

    private java.lang.Double nonEquityPercentage;

    private java.lang.String modifiedBy;

    private java.util.Calendar modifiedDt;

    public AssetAllocModels() {
    }

    public AssetAllocModels(
           java.lang.String modelCd,
           java.lang.String modelDesc,
           java.lang.String tickerSymbol,
           java.lang.String modelCategory,
           java.lang.Double modelRepeatingSeq,
           java.lang.Double percentage,
           java.lang.Double equityPercentage,
           java.lang.Double nonEquityPercentage,
           java.lang.String modifiedBy,
           java.util.Calendar modifiedDt) {
           this.modelCd = modelCd;
           this.modelDesc = modelDesc;
           this.tickerSymbol = tickerSymbol;
           this.modelCategory = modelCategory;
           this.modelRepeatingSeq = modelRepeatingSeq;
           this.percentage = percentage;
           this.equityPercentage = equityPercentage;
           this.nonEquityPercentage = nonEquityPercentage;
           this.modifiedBy = modifiedBy;
           this.modifiedDt = modifiedDt;
    }


    /**
     * Gets the modelCd value for this AssetAllocModels.
     * 
     * @return modelCd
     */
    public java.lang.String getModelCd() {
        return modelCd;
    }


    /**
     * Sets the modelCd value for this AssetAllocModels.
     * 
     * @param modelCd
     */
    public void setModelCd(java.lang.String modelCd) {
        this.modelCd = modelCd;
    }


    /**
     * Gets the modelDesc value for this AssetAllocModels.
     * 
     * @return modelDesc
     */
    public java.lang.String getModelDesc() {
        return modelDesc;
    }


    /**
     * Sets the modelDesc value for this AssetAllocModels.
     * 
     * @param modelDesc
     */
    public void setModelDesc(java.lang.String modelDesc) {
        this.modelDesc = modelDesc;
    }


    /**
     * Gets the tickerSymbol value for this AssetAllocModels.
     * 
     * @return tickerSymbol
     */
    public java.lang.String getTickerSymbol() {
        return tickerSymbol;
    }


    /**
     * Sets the tickerSymbol value for this AssetAllocModels.
     * 
     * @param tickerSymbol
     */
    public void setTickerSymbol(java.lang.String tickerSymbol) {
        this.tickerSymbol = tickerSymbol;
    }


    /**
     * Gets the modelCategory value for this AssetAllocModels.
     * 
     * @return modelCategory
     */
    public java.lang.String getModelCategory() {
        return modelCategory;
    }


    /**
     * Sets the modelCategory value for this AssetAllocModels.
     * 
     * @param modelCategory
     */
    public void setModelCategory(java.lang.String modelCategory) {
        this.modelCategory = modelCategory;
    }


    /**
     * Gets the modelRepeatingSeq value for this AssetAllocModels.
     * 
     * @return modelRepeatingSeq
     */
    public java.lang.Double getModelRepeatingSeq() {
        return modelRepeatingSeq;
    }


    /**
     * Sets the modelRepeatingSeq value for this AssetAllocModels.
     * 
     * @param modelRepeatingSeq
     */
    public void setModelRepeatingSeq(java.lang.Double modelRepeatingSeq) {
        this.modelRepeatingSeq = modelRepeatingSeq;
    }


    /**
     * Gets the percentage value for this AssetAllocModels.
     * 
     * @return percentage
     */
    public java.lang.Double getPercentage() {
        return percentage;
    }


    /**
     * Sets the percentage value for this AssetAllocModels.
     * 
     * @param percentage
     */
    public void setPercentage(java.lang.Double percentage) {
        this.percentage = percentage;
    }


    /**
     * Gets the equityPercentage value for this AssetAllocModels.
     * 
     * @return equityPercentage
     */
    public java.lang.Double getEquityPercentage() {
        return equityPercentage;
    }


    /**
     * Sets the equityPercentage value for this AssetAllocModels.
     * 
     * @param equityPercentage
     */
    public void setEquityPercentage(java.lang.Double equityPercentage) {
        this.equityPercentage = equityPercentage;
    }


    /**
     * Gets the nonEquityPercentage value for this AssetAllocModels.
     * 
     * @return nonEquityPercentage
     */
    public java.lang.Double getNonEquityPercentage() {
        return nonEquityPercentage;
    }


    /**
     * Sets the nonEquityPercentage value for this AssetAllocModels.
     * 
     * @param nonEquityPercentage
     */
    public void setNonEquityPercentage(java.lang.Double nonEquityPercentage) {
        this.nonEquityPercentage = nonEquityPercentage;
    }


    /**
     * Gets the modifiedBy value for this AssetAllocModels.
     * 
     * @return modifiedBy
     */
    public java.lang.String getModifiedBy() {
        return modifiedBy;
    }


    /**
     * Sets the modifiedBy value for this AssetAllocModels.
     * 
     * @param modifiedBy
     */
    public void setModifiedBy(java.lang.String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }


    /**
     * Gets the modifiedDt value for this AssetAllocModels.
     * 
     * @return modifiedDt
     */
    public java.util.Calendar getModifiedDt() {
        return modifiedDt;
    }


    /**
     * Sets the modifiedDt value for this AssetAllocModels.
     * 
     * @param modifiedDt
     */
    public void setModifiedDt(java.util.Calendar modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AssetAllocModels)) return false;
        AssetAllocModels other = (AssetAllocModels) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.modelCd==null && other.getModelCd()==null) || 
             (this.modelCd!=null &&
              this.modelCd.equals(other.getModelCd()))) &&
            ((this.modelDesc==null && other.getModelDesc()==null) || 
             (this.modelDesc!=null &&
              this.modelDesc.equals(other.getModelDesc()))) &&
            ((this.tickerSymbol==null && other.getTickerSymbol()==null) || 
             (this.tickerSymbol!=null &&
              this.tickerSymbol.equals(other.getTickerSymbol()))) &&
            ((this.modelCategory==null && other.getModelCategory()==null) || 
             (this.modelCategory!=null &&
              this.modelCategory.equals(other.getModelCategory()))) &&
            ((this.modelRepeatingSeq==null && other.getModelRepeatingSeq()==null) || 
             (this.modelRepeatingSeq!=null &&
              this.modelRepeatingSeq.equals(other.getModelRepeatingSeq()))) &&
            ((this.percentage==null && other.getPercentage()==null) || 
             (this.percentage!=null &&
              this.percentage.equals(other.getPercentage()))) &&
            ((this.equityPercentage==null && other.getEquityPercentage()==null) || 
             (this.equityPercentage!=null &&
              this.equityPercentage.equals(other.getEquityPercentage()))) &&
            ((this.nonEquityPercentage==null && other.getNonEquityPercentage()==null) || 
             (this.nonEquityPercentage!=null &&
              this.nonEquityPercentage.equals(other.getNonEquityPercentage()))) &&
            ((this.modifiedBy==null && other.getModifiedBy()==null) || 
             (this.modifiedBy!=null &&
              this.modifiedBy.equals(other.getModifiedBy()))) &&
            ((this.modifiedDt==null && other.getModifiedDt()==null) || 
             (this.modifiedDt!=null &&
              this.modifiedDt.equals(other.getModifiedDt())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getModelCd() != null) {
            _hashCode += getModelCd().hashCode();
        }
        if (getModelDesc() != null) {
            _hashCode += getModelDesc().hashCode();
        }
        if (getTickerSymbol() != null) {
            _hashCode += getTickerSymbol().hashCode();
        }
        if (getModelCategory() != null) {
            _hashCode += getModelCategory().hashCode();
        }
        if (getModelRepeatingSeq() != null) {
            _hashCode += getModelRepeatingSeq().hashCode();
        }
        if (getPercentage() != null) {
            _hashCode += getPercentage().hashCode();
        }
        if (getEquityPercentage() != null) {
            _hashCode += getEquityPercentage().hashCode();
        }
        if (getNonEquityPercentage() != null) {
            _hashCode += getNonEquityPercentage().hashCode();
        }
        if (getModifiedBy() != null) {
            _hashCode += getModifiedBy().hashCode();
        }
        if (getModifiedDt() != null) {
            _hashCode += getModifiedDt().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AssetAllocModels.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", ">AssetAllocModels"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modelCd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "modelCd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modelDesc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "modelDesc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tickerSymbol");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "tickerSymbol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modelCategory");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "modelCategory"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modelRepeatingSeq");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "modelRepeatingSeq"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "percentage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("equityPercentage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "equityPercentage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nonEquityPercentage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "nonEquityPercentage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "modifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifiedDt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "modifiedDt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
