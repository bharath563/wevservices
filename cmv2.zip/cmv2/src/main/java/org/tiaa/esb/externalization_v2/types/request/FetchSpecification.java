/**
 * FetchSpecification.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tiaa.esb.externalization_v2.types.request;

public class FetchSpecification  implements java.io.Serializable {
    private java.lang.String table;

    private java.lang.String[] columns;

    private org.tiaa.esb.externalization_v2.types.request.Qualifiers qualifiers;

    private org.tiaa.esb.externalization_v2.types.request.SortOrdering[] sortOrdering;

    private java.lang.String[] groupBy;

    private java.lang.Integer fetchLimit;

    public FetchSpecification() {
    }

    public FetchSpecification(
           java.lang.String table,
           java.lang.String[] columns,
           org.tiaa.esb.externalization_v2.types.request.Qualifiers qualifiers,
           org.tiaa.esb.externalization_v2.types.request.SortOrdering[] sortOrdering,
           java.lang.String[] groupBy,
           java.lang.Integer fetchLimit) {
           this.table = table;
           this.columns = columns;
           this.qualifiers = qualifiers;
           this.sortOrdering = sortOrdering;
           this.groupBy = groupBy;
           this.fetchLimit = fetchLimit;
    }


    /**
     * Gets the table value for this FetchSpecification.
     * 
     * @return table
     */
    public java.lang.String getTable() {
        return table;
    }


    /**
     * Sets the table value for this FetchSpecification.
     * 
     * @param table
     */
    public void setTable(java.lang.String table) {
        this.table = table;
    }


    /**
     * Gets the columns value for this FetchSpecification.
     * 
     * @return columns
     */
    public java.lang.String[] getColumns() {
        return columns;
    }


    /**
     * Sets the columns value for this FetchSpecification.
     * 
     * @param columns
     */
    public void setColumns(java.lang.String[] columns) {
        this.columns = columns;
    }


    /**
     * Gets the qualifiers value for this FetchSpecification.
     * 
     * @return qualifiers
     */
    public org.tiaa.esb.externalization_v2.types.request.Qualifiers getQualifiers() {
        return qualifiers;
    }


    /**
     * Sets the qualifiers value for this FetchSpecification.
     * 
     * @param qualifiers
     */
    public void setQualifiers(org.tiaa.esb.externalization_v2.types.request.Qualifiers qualifiers) {
        this.qualifiers = qualifiers;
    }


    /**
     * Gets the sortOrdering value for this FetchSpecification.
     * 
     * @return sortOrdering
     */
    public org.tiaa.esb.externalization_v2.types.request.SortOrdering[] getSortOrdering() {
        return sortOrdering;
    }


    /**
     * Sets the sortOrdering value for this FetchSpecification.
     * 
     * @param sortOrdering
     */
    public void setSortOrdering(org.tiaa.esb.externalization_v2.types.request.SortOrdering[] sortOrdering) {
        this.sortOrdering = sortOrdering;
    }

    public org.tiaa.esb.externalization_v2.types.request.SortOrdering getSortOrdering(int i) {
        return this.sortOrdering[i];
    }

    public void setSortOrdering(int i, org.tiaa.esb.externalization_v2.types.request.SortOrdering _value) {
        this.sortOrdering[i] = _value;
    }


    /**
     * Gets the groupBy value for this FetchSpecification.
     * 
     * @return groupBy
     */
    public java.lang.String[] getGroupBy() {
        return groupBy;
    }


    /**
     * Sets the groupBy value for this FetchSpecification.
     * 
     * @param groupBy
     */
    public void setGroupBy(java.lang.String[] groupBy) {
        this.groupBy = groupBy;
    }


    /**
     * Gets the fetchLimit value for this FetchSpecification.
     * 
     * @return fetchLimit
     */
    public java.lang.Integer getFetchLimit() {
        return fetchLimit;
    }


    /**
     * Sets the fetchLimit value for this FetchSpecification.
     * 
     * @param fetchLimit
     */
    public void setFetchLimit(java.lang.Integer fetchLimit) {
        this.fetchLimit = fetchLimit;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof FetchSpecification)) return false;
        FetchSpecification other = (FetchSpecification) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.table==null && other.getTable()==null) || 
             (this.table!=null &&
              this.table.equals(other.getTable()))) &&
            ((this.columns==null && other.getColumns()==null) || 
             (this.columns!=null &&
              java.util.Arrays.equals(this.columns, other.getColumns()))) &&
            ((this.qualifiers==null && other.getQualifiers()==null) || 
             (this.qualifiers!=null &&
              this.qualifiers.equals(other.getQualifiers()))) &&
            ((this.sortOrdering==null && other.getSortOrdering()==null) || 
             (this.sortOrdering!=null &&
              java.util.Arrays.equals(this.sortOrdering, other.getSortOrdering()))) &&
            ((this.groupBy==null && other.getGroupBy()==null) || 
             (this.groupBy!=null &&
              java.util.Arrays.equals(this.groupBy, other.getGroupBy()))) &&
            ((this.fetchLimit==null && other.getFetchLimit()==null) || 
             (this.fetchLimit!=null &&
              this.fetchLimit.equals(other.getFetchLimit())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTable() != null) {
            _hashCode += getTable().hashCode();
        }
        if (getColumns() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getColumns());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getColumns(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getQualifiers() != null) {
            _hashCode += getQualifiers().hashCode();
        }
        if (getSortOrdering() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSortOrdering());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSortOrdering(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getGroupBy() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getGroupBy());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getGroupBy(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFetchLimit() != null) {
            _hashCode += getFetchLimit().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(FetchSpecification.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", ">FetchSpecification"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("table");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "table"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columns");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "columns"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "columns"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("qualifiers");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "Qualifiers"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", ">Qualifiers"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sortOrdering");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "SortOrdering"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "SortOrdering"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("groupBy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "groupBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "columns"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fetchLimit");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "fetchLimit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
