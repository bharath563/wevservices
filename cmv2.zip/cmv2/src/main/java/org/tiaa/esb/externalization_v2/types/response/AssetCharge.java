/**
 * AssetCharge.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tiaa.esb.externalization_v2.types.response;

public class AssetCharge  implements java.io.Serializable {
    private java.lang.String tickerSymbol;

    private java.util.Calendar basisPointsStartDt;

    private java.util.Calendar basisPointsEndDt;

    private java.lang.Double basisPoints;

    private java.lang.Double dailyCharge;

    private java.lang.String modifiedBy;

    private java.util.Calendar modifiedDt;

    public AssetCharge() {
    }

    public AssetCharge(
           java.lang.String tickerSymbol,
           java.util.Calendar basisPointsStartDt,
           java.util.Calendar basisPointsEndDt,
           java.lang.Double basisPoints,
           java.lang.Double dailyCharge,
           java.lang.String modifiedBy,
           java.util.Calendar modifiedDt) {
           this.tickerSymbol = tickerSymbol;
           this.basisPointsStartDt = basisPointsStartDt;
           this.basisPointsEndDt = basisPointsEndDt;
           this.basisPoints = basisPoints;
           this.dailyCharge = dailyCharge;
           this.modifiedBy = modifiedBy;
           this.modifiedDt = modifiedDt;
    }


    /**
     * Gets the tickerSymbol value for this AssetCharge.
     * 
     * @return tickerSymbol
     */
    public java.lang.String getTickerSymbol() {
        return tickerSymbol;
    }


    /**
     * Sets the tickerSymbol value for this AssetCharge.
     * 
     * @param tickerSymbol
     */
    public void setTickerSymbol(java.lang.String tickerSymbol) {
        this.tickerSymbol = tickerSymbol;
    }


    /**
     * Gets the basisPointsStartDt value for this AssetCharge.
     * 
     * @return basisPointsStartDt
     */
    public java.util.Calendar getBasisPointsStartDt() {
        return basisPointsStartDt;
    }


    /**
     * Sets the basisPointsStartDt value for this AssetCharge.
     * 
     * @param basisPointsStartDt
     */
    public void setBasisPointsStartDt(java.util.Calendar basisPointsStartDt) {
        this.basisPointsStartDt = basisPointsStartDt;
    }


    /**
     * Gets the basisPointsEndDt value for this AssetCharge.
     * 
     * @return basisPointsEndDt
     */
    public java.util.Calendar getBasisPointsEndDt() {
        return basisPointsEndDt;
    }


    /**
     * Sets the basisPointsEndDt value for this AssetCharge.
     * 
     * @param basisPointsEndDt
     */
    public void setBasisPointsEndDt(java.util.Calendar basisPointsEndDt) {
        this.basisPointsEndDt = basisPointsEndDt;
    }


    /**
     * Gets the basisPoints value for this AssetCharge.
     * 
     * @return basisPoints
     */
    public java.lang.Double getBasisPoints() {
        return basisPoints;
    }


    /**
     * Sets the basisPoints value for this AssetCharge.
     * 
     * @param basisPoints
     */
    public void setBasisPoints(java.lang.Double basisPoints) {
        this.basisPoints = basisPoints;
    }


    /**
     * Gets the dailyCharge value for this AssetCharge.
     * 
     * @return dailyCharge
     */
    public java.lang.Double getDailyCharge() {
        return dailyCharge;
    }


    /**
     * Sets the dailyCharge value for this AssetCharge.
     * 
     * @param dailyCharge
     */
    public void setDailyCharge(java.lang.Double dailyCharge) {
        this.dailyCharge = dailyCharge;
    }


    /**
     * Gets the modifiedBy value for this AssetCharge.
     * 
     * @return modifiedBy
     */
    public java.lang.String getModifiedBy() {
        return modifiedBy;
    }


    /**
     * Sets the modifiedBy value for this AssetCharge.
     * 
     * @param modifiedBy
     */
    public void setModifiedBy(java.lang.String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }


    /**
     * Gets the modifiedDt value for this AssetCharge.
     * 
     * @return modifiedDt
     */
    public java.util.Calendar getModifiedDt() {
        return modifiedDt;
    }


    /**
     * Sets the modifiedDt value for this AssetCharge.
     * 
     * @param modifiedDt
     */
    public void setModifiedDt(java.util.Calendar modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AssetCharge)) return false;
        AssetCharge other = (AssetCharge) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.tickerSymbol==null && other.getTickerSymbol()==null) || 
             (this.tickerSymbol!=null &&
              this.tickerSymbol.equals(other.getTickerSymbol()))) &&
            ((this.basisPointsStartDt==null && other.getBasisPointsStartDt()==null) || 
             (this.basisPointsStartDt!=null &&
              this.basisPointsStartDt.equals(other.getBasisPointsStartDt()))) &&
            ((this.basisPointsEndDt==null && other.getBasisPointsEndDt()==null) || 
             (this.basisPointsEndDt!=null &&
              this.basisPointsEndDt.equals(other.getBasisPointsEndDt()))) &&
            ((this.basisPoints==null && other.getBasisPoints()==null) || 
             (this.basisPoints!=null &&
              this.basisPoints.equals(other.getBasisPoints()))) &&
            ((this.dailyCharge==null && other.getDailyCharge()==null) || 
             (this.dailyCharge!=null &&
              this.dailyCharge.equals(other.getDailyCharge()))) &&
            ((this.modifiedBy==null && other.getModifiedBy()==null) || 
             (this.modifiedBy!=null &&
              this.modifiedBy.equals(other.getModifiedBy()))) &&
            ((this.modifiedDt==null && other.getModifiedDt()==null) || 
             (this.modifiedDt!=null &&
              this.modifiedDt.equals(other.getModifiedDt())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTickerSymbol() != null) {
            _hashCode += getTickerSymbol().hashCode();
        }
        if (getBasisPointsStartDt() != null) {
            _hashCode += getBasisPointsStartDt().hashCode();
        }
        if (getBasisPointsEndDt() != null) {
            _hashCode += getBasisPointsEndDt().hashCode();
        }
        if (getBasisPoints() != null) {
            _hashCode += getBasisPoints().hashCode();
        }
        if (getDailyCharge() != null) {
            _hashCode += getDailyCharge().hashCode();
        }
        if (getModifiedBy() != null) {
            _hashCode += getModifiedBy().hashCode();
        }
        if (getModifiedDt() != null) {
            _hashCode += getModifiedDt().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AssetCharge.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", ">AssetCharge"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tickerSymbol");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "tickerSymbol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("basisPointsStartDt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "basisPointsStartDt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("basisPointsEndDt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "basisPointsEndDt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("basisPoints");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "basisPoints"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dailyCharge");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "dailyCharge"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "modifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifiedDt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "modifiedDt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
