/**
 * GetFundsInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tiaa.esb.externalization_v2.types.request;

public class GetFundsInfo  implements java.io.Serializable {
    private java.lang.String PPGCode;

    private java.lang.Integer rule;

    private java.lang.Integer planKeyCode;

    private java.lang.String ticker;

    private int productCode;

    private int sortInstruction;

    public GetFundsInfo() {
    }

    public GetFundsInfo(
           java.lang.String PPGCode,
           java.lang.Integer rule,
           java.lang.Integer planKeyCode,
           java.lang.String ticker,
           int productCode,
           int sortInstruction) {
           this.PPGCode = PPGCode;
           this.rule = rule;
           this.planKeyCode = planKeyCode;
           this.ticker = ticker;
           this.productCode = productCode;
           this.sortInstruction = sortInstruction;
    }


    /**
     * Gets the PPGCode value for this GetFundsInfo.
     * 
     * @return PPGCode
     */
    public java.lang.String getPPGCode() {
        return PPGCode;
    }


    /**
     * Sets the PPGCode value for this GetFundsInfo.
     * 
     * @param PPGCode
     */
    public void setPPGCode(java.lang.String PPGCode) {
        this.PPGCode = PPGCode;
    }


    /**
     * Gets the rule value for this GetFundsInfo.
     * 
     * @return rule
     */
    public java.lang.Integer getRule() {
        return rule;
    }


    /**
     * Sets the rule value for this GetFundsInfo.
     * 
     * @param rule
     */
    public void setRule(java.lang.Integer rule) {
        this.rule = rule;
    }


    /**
     * Gets the planKeyCode value for this GetFundsInfo.
     * 
     * @return planKeyCode
     */
    public java.lang.Integer getPlanKeyCode() {
        return planKeyCode;
    }


    /**
     * Sets the planKeyCode value for this GetFundsInfo.
     * 
     * @param planKeyCode
     */
    public void setPlanKeyCode(java.lang.Integer planKeyCode) {
        this.planKeyCode = planKeyCode;
    }


    /**
     * Gets the ticker value for this GetFundsInfo.
     * 
     * @return ticker
     */
    public java.lang.String getTicker() {
        return ticker;
    }


    /**
     * Sets the ticker value for this GetFundsInfo.
     * 
     * @param ticker
     */
    public void setTicker(java.lang.String ticker) {
        this.ticker = ticker;
    }


    /**
     * Gets the productCode value for this GetFundsInfo.
     * 
     * @return productCode
     */
    public int getProductCode() {
        return productCode;
    }


    /**
     * Sets the productCode value for this GetFundsInfo.
     * 
     * @param productCode
     */
    public void setProductCode(int productCode) {
        this.productCode = productCode;
    }


    /**
     * Gets the sortInstruction value for this GetFundsInfo.
     * 
     * @return sortInstruction
     */
    public int getSortInstruction() {
        return sortInstruction;
    }


    /**
     * Sets the sortInstruction value for this GetFundsInfo.
     * 
     * @param sortInstruction
     */
    public void setSortInstruction(int sortInstruction) {
        this.sortInstruction = sortInstruction;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetFundsInfo)) return false;
        GetFundsInfo other = (GetFundsInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.PPGCode==null && other.getPPGCode()==null) || 
             (this.PPGCode!=null &&
              this.PPGCode.equals(other.getPPGCode()))) &&
            ((this.rule==null && other.getRule()==null) || 
             (this.rule!=null &&
              this.rule.equals(other.getRule()))) &&
            ((this.planKeyCode==null && other.getPlanKeyCode()==null) || 
             (this.planKeyCode!=null &&
              this.planKeyCode.equals(other.getPlanKeyCode()))) &&
            ((this.ticker==null && other.getTicker()==null) || 
             (this.ticker!=null &&
              this.ticker.equals(other.getTicker()))) &&
            this.productCode == other.getProductCode() &&
            this.sortInstruction == other.getSortInstruction();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPPGCode() != null) {
            _hashCode += getPPGCode().hashCode();
        }
        if (getRule() != null) {
            _hashCode += getRule().hashCode();
        }
        if (getPlanKeyCode() != null) {
            _hashCode += getPlanKeyCode().hashCode();
        }
        if (getTicker() != null) {
            _hashCode += getTicker().hashCode();
        }
        _hashCode += getProductCode();
        _hashCode += getSortInstruction();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetFundsInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", ">getFundsInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PPGCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "PPGCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("rule");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "rule"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("planKeyCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "planKeyCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ticker");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "ticker"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("productCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "productCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sortInstruction");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/request", "sortInstruction"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
