/**
 * AccountInfo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tiaa.esb.externalization_v2.types.response;

public class AccountInfo  implements java.io.Serializable {
    private java.lang.String fromAccount;

    private java.lang.String toAccount;

    private java.lang.String companyCode;

    private java.lang.String productCode;

    private java.lang.String tickerSymbol;

    private java.lang.String fundFamilyCode;

    private java.lang.String fundStyle;

    private java.lang.String fundSize;

    private java.lang.String fundName;

    private java.lang.String alphaFundCode;

    private java.lang.String numFundCode;

    private java.lang.String ffundFamilyCode;

    private java.lang.String ffundFamilyName;

    private java.lang.String fsfundStyle;

    private java.lang.String fsfundSize;

    private java.lang.String fundStatus;

    public AccountInfo() {
    }

    public AccountInfo(
           java.lang.String fromAccount,
           java.lang.String toAccount,
           java.lang.String companyCode,
           java.lang.String productCode,
           java.lang.String tickerSymbol,
           java.lang.String fundFamilyCode,
           java.lang.String fundStyle,
           java.lang.String fundSize,
           java.lang.String fundName,
           java.lang.String alphaFundCode,
           java.lang.String numFundCode,
           java.lang.String ffundFamilyCode,
           java.lang.String ffundFamilyName,
           java.lang.String fsfundStyle,
           java.lang.String fsfundSize,
           java.lang.String fundStatus) {
           this.fromAccount = fromAccount;
           this.toAccount = toAccount;
           this.companyCode = companyCode;
           this.productCode = productCode;
           this.tickerSymbol = tickerSymbol;
           this.fundFamilyCode = fundFamilyCode;
           this.fundStyle = fundStyle;
           this.fundSize = fundSize;
           this.fundName = fundName;
           this.alphaFundCode = alphaFundCode;
           this.numFundCode = numFundCode;
           this.ffundFamilyCode = ffundFamilyCode;
           this.ffundFamilyName = ffundFamilyName;
           this.fsfundStyle = fsfundStyle;
           this.fsfundSize = fsfundSize;
           this.fundStatus = fundStatus;
    }


    /**
     * Gets the fromAccount value for this AccountInfo.
     * 
     * @return fromAccount
     */
    public java.lang.String getFromAccount() {
        return fromAccount;
    }


    /**
     * Sets the fromAccount value for this AccountInfo.
     * 
     * @param fromAccount
     */
    public void setFromAccount(java.lang.String fromAccount) {
        this.fromAccount = fromAccount;
    }


    /**
     * Gets the toAccount value for this AccountInfo.
     * 
     * @return toAccount
     */
    public java.lang.String getToAccount() {
        return toAccount;
    }


    /**
     * Sets the toAccount value for this AccountInfo.
     * 
     * @param toAccount
     */
    public void setToAccount(java.lang.String toAccount) {
        this.toAccount = toAccount;
    }


    /**
     * Gets the companyCode value for this AccountInfo.
     * 
     * @return companyCode
     */
    public java.lang.String getCompanyCode() {
        return companyCode;
    }


    /**
     * Sets the companyCode value for this AccountInfo.
     * 
     * @param companyCode
     */
    public void setCompanyCode(java.lang.String companyCode) {
        this.companyCode = companyCode;
    }


    /**
     * Gets the productCode value for this AccountInfo.
     * 
     * @return productCode
     */
    public java.lang.String getProductCode() {
        return productCode;
    }


    /**
     * Sets the productCode value for this AccountInfo.
     * 
     * @param productCode
     */
    public void setProductCode(java.lang.String productCode) {
        this.productCode = productCode;
    }


    /**
     * Gets the tickerSymbol value for this AccountInfo.
     * 
     * @return tickerSymbol
     */
    public java.lang.String getTickerSymbol() {
        return tickerSymbol;
    }


    /**
     * Sets the tickerSymbol value for this AccountInfo.
     * 
     * @param tickerSymbol
     */
    public void setTickerSymbol(java.lang.String tickerSymbol) {
        this.tickerSymbol = tickerSymbol;
    }


    /**
     * Gets the fundFamilyCode value for this AccountInfo.
     * 
     * @return fundFamilyCode
     */
    public java.lang.String getFundFamilyCode() {
        return fundFamilyCode;
    }


    /**
     * Sets the fundFamilyCode value for this AccountInfo.
     * 
     * @param fundFamilyCode
     */
    public void setFundFamilyCode(java.lang.String fundFamilyCode) {
        this.fundFamilyCode = fundFamilyCode;
    }


    /**
     * Gets the fundStyle value for this AccountInfo.
     * 
     * @return fundStyle
     */
    public java.lang.String getFundStyle() {
        return fundStyle;
    }


    /**
     * Sets the fundStyle value for this AccountInfo.
     * 
     * @param fundStyle
     */
    public void setFundStyle(java.lang.String fundStyle) {
        this.fundStyle = fundStyle;
    }


    /**
     * Gets the fundSize value for this AccountInfo.
     * 
     * @return fundSize
     */
    public java.lang.String getFundSize() {
        return fundSize;
    }


    /**
     * Sets the fundSize value for this AccountInfo.
     * 
     * @param fundSize
     */
    public void setFundSize(java.lang.String fundSize) {
        this.fundSize = fundSize;
    }


    /**
     * Gets the fundName value for this AccountInfo.
     * 
     * @return fundName
     */
    public java.lang.String getFundName() {
        return fundName;
    }


    /**
     * Sets the fundName value for this AccountInfo.
     * 
     * @param fundName
     */
    public void setFundName(java.lang.String fundName) {
        this.fundName = fundName;
    }


    /**
     * Gets the alphaFundCode value for this AccountInfo.
     * 
     * @return alphaFundCode
     */
    public java.lang.String getAlphaFundCode() {
        return alphaFundCode;
    }


    /**
     * Sets the alphaFundCode value for this AccountInfo.
     * 
     * @param alphaFundCode
     */
    public void setAlphaFundCode(java.lang.String alphaFundCode) {
        this.alphaFundCode = alphaFundCode;
    }


    /**
     * Gets the numFundCode value for this AccountInfo.
     * 
     * @return numFundCode
     */
    public java.lang.String getNumFundCode() {
        return numFundCode;
    }


    /**
     * Sets the numFundCode value for this AccountInfo.
     * 
     * @param numFundCode
     */
    public void setNumFundCode(java.lang.String numFundCode) {
        this.numFundCode = numFundCode;
    }


    /**
     * Gets the ffundFamilyCode value for this AccountInfo.
     * 
     * @return ffundFamilyCode
     */
    public java.lang.String getFfundFamilyCode() {
        return ffundFamilyCode;
    }


    /**
     * Sets the ffundFamilyCode value for this AccountInfo.
     * 
     * @param ffundFamilyCode
     */
    public void setFfundFamilyCode(java.lang.String ffundFamilyCode) {
        this.ffundFamilyCode = ffundFamilyCode;
    }


    /**
     * Gets the ffundFamilyName value for this AccountInfo.
     * 
     * @return ffundFamilyName
     */
    public java.lang.String getFfundFamilyName() {
        return ffundFamilyName;
    }


    /**
     * Sets the ffundFamilyName value for this AccountInfo.
     * 
     * @param ffundFamilyName
     */
    public void setFfundFamilyName(java.lang.String ffundFamilyName) {
        this.ffundFamilyName = ffundFamilyName;
    }


    /**
     * Gets the fsfundStyle value for this AccountInfo.
     * 
     * @return fsfundStyle
     */
    public java.lang.String getFsfundStyle() {
        return fsfundStyle;
    }


    /**
     * Sets the fsfundStyle value for this AccountInfo.
     * 
     * @param fsfundStyle
     */
    public void setFsfundStyle(java.lang.String fsfundStyle) {
        this.fsfundStyle = fsfundStyle;
    }


    /**
     * Gets the fsfundSize value for this AccountInfo.
     * 
     * @return fsfundSize
     */
    public java.lang.String getFsfundSize() {
        return fsfundSize;
    }


    /**
     * Sets the fsfundSize value for this AccountInfo.
     * 
     * @param fsfundSize
     */
    public void setFsfundSize(java.lang.String fsfundSize) {
        this.fsfundSize = fsfundSize;
    }


    /**
     * Gets the fundStatus value for this AccountInfo.
     * 
     * @return fundStatus
     */
    public java.lang.String getFundStatus() {
        return fundStatus;
    }


    /**
     * Sets the fundStatus value for this AccountInfo.
     * 
     * @param fundStatus
     */
    public void setFundStatus(java.lang.String fundStatus) {
        this.fundStatus = fundStatus;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AccountInfo)) return false;
        AccountInfo other = (AccountInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.fromAccount==null && other.getFromAccount()==null) || 
             (this.fromAccount!=null &&
              this.fromAccount.equals(other.getFromAccount()))) &&
            ((this.toAccount==null && other.getToAccount()==null) || 
             (this.toAccount!=null &&
              this.toAccount.equals(other.getToAccount()))) &&
            ((this.companyCode==null && other.getCompanyCode()==null) || 
             (this.companyCode!=null &&
              this.companyCode.equals(other.getCompanyCode()))) &&
            ((this.productCode==null && other.getProductCode()==null) || 
             (this.productCode!=null &&
              this.productCode.equals(other.getProductCode()))) &&
            ((this.tickerSymbol==null && other.getTickerSymbol()==null) || 
             (this.tickerSymbol!=null &&
              this.tickerSymbol.equals(other.getTickerSymbol()))) &&
            ((this.fundFamilyCode==null && other.getFundFamilyCode()==null) || 
             (this.fundFamilyCode!=null &&
              this.fundFamilyCode.equals(other.getFundFamilyCode()))) &&
            ((this.fundStyle==null && other.getFundStyle()==null) || 
             (this.fundStyle!=null &&
              this.fundStyle.equals(other.getFundStyle()))) &&
            ((this.fundSize==null && other.getFundSize()==null) || 
             (this.fundSize!=null &&
              this.fundSize.equals(other.getFundSize()))) &&
            ((this.fundName==null && other.getFundName()==null) || 
             (this.fundName!=null &&
              this.fundName.equals(other.getFundName()))) &&
            ((this.alphaFundCode==null && other.getAlphaFundCode()==null) || 
             (this.alphaFundCode!=null &&
              this.alphaFundCode.equals(other.getAlphaFundCode()))) &&
            ((this.numFundCode==null && other.getNumFundCode()==null) || 
             (this.numFundCode!=null &&
              this.numFundCode.equals(other.getNumFundCode()))) &&
            ((this.ffundFamilyCode==null && other.getFfundFamilyCode()==null) || 
             (this.ffundFamilyCode!=null &&
              this.ffundFamilyCode.equals(other.getFfundFamilyCode()))) &&
            ((this.ffundFamilyName==null && other.getFfundFamilyName()==null) || 
             (this.ffundFamilyName!=null &&
              this.ffundFamilyName.equals(other.getFfundFamilyName()))) &&
            ((this.fsfundStyle==null && other.getFsfundStyle()==null) || 
             (this.fsfundStyle!=null &&
              this.fsfundStyle.equals(other.getFsfundStyle()))) &&
            ((this.fsfundSize==null && other.getFsfundSize()==null) || 
             (this.fsfundSize!=null &&
              this.fsfundSize.equals(other.getFsfundSize()))) &&
            ((this.fundStatus==null && other.getFundStatus()==null) || 
             (this.fundStatus!=null &&
              this.fundStatus.equals(other.getFundStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFromAccount() != null) {
            _hashCode += getFromAccount().hashCode();
        }
        if (getToAccount() != null) {
            _hashCode += getToAccount().hashCode();
        }
        if (getCompanyCode() != null) {
            _hashCode += getCompanyCode().hashCode();
        }
        if (getProductCode() != null) {
            _hashCode += getProductCode().hashCode();
        }
        if (getTickerSymbol() != null) {
            _hashCode += getTickerSymbol().hashCode();
        }
        if (getFundFamilyCode() != null) {
            _hashCode += getFundFamilyCode().hashCode();
        }
        if (getFundStyle() != null) {
            _hashCode += getFundStyle().hashCode();
        }
        if (getFundSize() != null) {
            _hashCode += getFundSize().hashCode();
        }
        if (getFundName() != null) {
            _hashCode += getFundName().hashCode();
        }
        if (getAlphaFundCode() != null) {
            _hashCode += getAlphaFundCode().hashCode();
        }
        if (getNumFundCode() != null) {
            _hashCode += getNumFundCode().hashCode();
        }
        if (getFfundFamilyCode() != null) {
            _hashCode += getFfundFamilyCode().hashCode();
        }
        if (getFfundFamilyName() != null) {
            _hashCode += getFfundFamilyName().hashCode();
        }
        if (getFsfundStyle() != null) {
            _hashCode += getFsfundStyle().hashCode();
        }
        if (getFsfundSize() != null) {
            _hashCode += getFsfundSize().hashCode();
        }
        if (getFundStatus() != null) {
            _hashCode += getFundStatus().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AccountInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", ">AccountInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromAccount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "fromAccount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("toAccount");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "toAccount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("companyCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "companyCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("productCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "productCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tickerSymbol");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "tickerSymbol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fundFamilyCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "fundFamilyCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fundStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "fundStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fundSize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "fundSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fundName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "fundName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("alphaFundCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "alphaFundCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numFundCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "numFundCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ffundFamilyCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "ffundFamilyCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ffundFamilyName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "ffundFamilyName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fsfundStyle");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "fsfundStyle"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fsfundSize");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "fsfundSize"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fundStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "fundStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
