/**
 * AnnuityOption.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tiaa.esb.externalization_v2.types.response;

public class AnnuityOption  implements java.io.Serializable {
    private java.lang.String annuityOptionCd;

    private java.lang.String annuityOptionDesc;

    private java.lang.String modifiedBy;

    private java.util.Calendar modifiedDt;

    public AnnuityOption() {
    }

    public AnnuityOption(
           java.lang.String annuityOptionCd,
           java.lang.String annuityOptionDesc,
           java.lang.String modifiedBy,
           java.util.Calendar modifiedDt) {
           this.annuityOptionCd = annuityOptionCd;
           this.annuityOptionDesc = annuityOptionDesc;
           this.modifiedBy = modifiedBy;
           this.modifiedDt = modifiedDt;
    }


    /**
     * Gets the annuityOptionCd value for this AnnuityOption.
     * 
     * @return annuityOptionCd
     */
    public java.lang.String getAnnuityOptionCd() {
        return annuityOptionCd;
    }


    /**
     * Sets the annuityOptionCd value for this AnnuityOption.
     * 
     * @param annuityOptionCd
     */
    public void setAnnuityOptionCd(java.lang.String annuityOptionCd) {
        this.annuityOptionCd = annuityOptionCd;
    }


    /**
     * Gets the annuityOptionDesc value for this AnnuityOption.
     * 
     * @return annuityOptionDesc
     */
    public java.lang.String getAnnuityOptionDesc() {
        return annuityOptionDesc;
    }


    /**
     * Sets the annuityOptionDesc value for this AnnuityOption.
     * 
     * @param annuityOptionDesc
     */
    public void setAnnuityOptionDesc(java.lang.String annuityOptionDesc) {
        this.annuityOptionDesc = annuityOptionDesc;
    }


    /**
     * Gets the modifiedBy value for this AnnuityOption.
     * 
     * @return modifiedBy
     */
    public java.lang.String getModifiedBy() {
        return modifiedBy;
    }


    /**
     * Sets the modifiedBy value for this AnnuityOption.
     * 
     * @param modifiedBy
     */
    public void setModifiedBy(java.lang.String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }


    /**
     * Gets the modifiedDt value for this AnnuityOption.
     * 
     * @return modifiedDt
     */
    public java.util.Calendar getModifiedDt() {
        return modifiedDt;
    }


    /**
     * Sets the modifiedDt value for this AnnuityOption.
     * 
     * @param modifiedDt
     */
    public void setModifiedDt(java.util.Calendar modifiedDt) {
        this.modifiedDt = modifiedDt;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AnnuityOption)) return false;
        AnnuityOption other = (AnnuityOption) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.annuityOptionCd==null && other.getAnnuityOptionCd()==null) || 
             (this.annuityOptionCd!=null &&
              this.annuityOptionCd.equals(other.getAnnuityOptionCd()))) &&
            ((this.annuityOptionDesc==null && other.getAnnuityOptionDesc()==null) || 
             (this.annuityOptionDesc!=null &&
              this.annuityOptionDesc.equals(other.getAnnuityOptionDesc()))) &&
            ((this.modifiedBy==null && other.getModifiedBy()==null) || 
             (this.modifiedBy!=null &&
              this.modifiedBy.equals(other.getModifiedBy()))) &&
            ((this.modifiedDt==null && other.getModifiedDt()==null) || 
             (this.modifiedDt!=null &&
              this.modifiedDt.equals(other.getModifiedDt())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAnnuityOptionCd() != null) {
            _hashCode += getAnnuityOptionCd().hashCode();
        }
        if (getAnnuityOptionDesc() != null) {
            _hashCode += getAnnuityOptionDesc().hashCode();
        }
        if (getModifiedBy() != null) {
            _hashCode += getModifiedBy().hashCode();
        }
        if (getModifiedDt() != null) {
            _hashCode += getModifiedDt().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AnnuityOption.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", ">AnnuityOption"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("annuityOptionCd");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "annuityOptionCd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("annuityOptionDesc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "annuityOptionDesc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "modifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifiedDt");
        elemField.setXmlName(new javax.xml.namespace.QName("http://esb.tiaa.org/externalization-v2/types/response", "modifiedDt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
