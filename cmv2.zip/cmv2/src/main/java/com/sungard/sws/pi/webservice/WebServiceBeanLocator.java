/**
 * WebServiceBeanLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sungard.sws.pi.webservice;

public class WebServiceBeanLocator extends org.apache.axis.client.Service implements com.sungard.sws.pi.webservice.WebServiceBean {

    // Use to get a proxy class for WebServiceBeanPort
    private final java.lang.String webServiceBeanPortAddress = "http://preprod:80/PowerImageWebService/WebServiceBean";

    public java.lang.String getWebServiceBeanPortAddress() {
        return webServiceBeanPortAddress;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String WebServiceBeanPortWSDDServiceName = "WebServiceBeanPort";

    public java.lang.String getWebServiceBeanPortWSDDServiceName() {
        return WebServiceBeanPortWSDDServiceName;
    }

    public void setWebServiceBeanPortWSDDServiceName(java.lang.String name) {
        WebServiceBeanPortWSDDServiceName = name;
    }

    public com.sungard.sws.pi.webservice.WebServiceBeanPort getWebServiceBeanPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(webServiceBeanPortAddress);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getWebServiceBeanPort(endpoint);
    }

    public com.sungard.sws.pi.webservice.WebServiceBeanPort getWebServiceBeanPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.sungard.sws.pi.webservice.WebServiceBeanPortStub _stub = new com.sungard.sws.pi.webservice.WebServiceBeanPortStub(portAddress, this);
            _stub.setPortName(getWebServiceBeanPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    @SuppressWarnings("rawtypes")
	public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.sungard.sws.pi.webservice.WebServiceBeanPort.class.isAssignableFrom(serviceEndpointInterface)) {
                com.sungard.sws.pi.webservice.WebServiceBeanPortStub stub = new com.sungard.sws.pi.webservice.WebServiceBeanPortStub(new java.net.URL(webServiceBeanPortAddress), this);
                stub.setPortName(getWebServiceBeanPortWSDDServiceName());
                return stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    @SuppressWarnings("rawtypes")
	public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        String inputPortName = portName.getLocalPart();
        if ("WebServiceBeanPort".equals(inputPortName)) {
            return getWebServiceBeanPort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://webservice.pi.sws.sungard.com", "WebServiceBean");
    }

    @SuppressWarnings("rawtypes")
	private java.util.HashSet ports = null;

    @SuppressWarnings({ "rawtypes", "unchecked" })
	public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("WebServiceBeanPort"));
        }
        return ports.iterator();
    }

}
