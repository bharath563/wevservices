/**
 * WebServiceBeanPort.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package com.sungard.sws.pi.webservice;

public interface WebServiceBeanPort extends java.rmi.Remote {
    public boolean addComment(java.lang.String taskId, java.lang.String userId, java.lang.String addHistFlg, java.lang.String commentTxt) throws java.rmi.RemoteException;
    public boolean addXMLData(java.lang.String userId, java.lang.String taskId, java.lang.String createOper, java.lang.String xsltFile, java.lang.String xml) throws java.rmi.RemoteException;
    public boolean unLockTask(java.lang.String userId, java.lang.String taskId, java.util.Calendar start) throws java.rmi.RemoteException;
    public boolean cancelTask(java.lang.String userId, java.lang.String taskId) throws java.rmi.RemoteException;
    public boolean cancelTaskEx(java.lang.String userId, java.lang.String taskId, java.lang.String useCommentsNotes, java.lang.String commentsNotes) throws java.rmi.RemoteException;
    public java.lang.String getCaseDetails(java.lang.String userId, java.lang.String caseDesc, java.lang.String caseId) throws java.rmi.RemoteException;
    public java.lang.String getDocumentActivities(java.lang.String userId, java.lang.String docId) throws java.rmi.RemoteException;
    public java.lang.String getDocumentDetails(java.lang.String userId, java.lang.String docId) throws java.rmi.RemoteException;
    public java.lang.String getDocument(java.lang.String userId, java.lang.String docId) throws java.rmi.RemoteException;
    public java.lang.String getTaskActivities(java.lang.String userId, java.lang.String taskId) throws java.rmi.RemoteException;
    public java.lang.String getTaskDetails(java.lang.String userId, java.lang.String taskId) throws java.rmi.RemoteException;
    public java.lang.String getWorkItem(java.lang.String userId, java.lang.String taskId, java.util.Calendar lastHist) throws java.rmi.RemoteException;
    public java.lang.String getWorkItems(java.lang.String userId, int count, java.lang.String lockItems) throws java.rmi.RemoteException;
    public java.lang.String getWorkPacketDetails(java.lang.String userId, java.lang.String pktId) throws java.rmi.RemoteException;
    public java.lang.String getXmlData(java.lang.String userId, java.lang.String taskId, java.util.Calendar created) throws java.rmi.RemoteException;
    public java.lang.String processTask(java.lang.String userId, java.lang.String taskId, java.lang.String packetId, java.util.Calendar receiveDate, java.lang.String department, java.lang.String taskType, java.lang.String actionDesc, java.lang.String workBasket, java.lang.String vip, int priority, java.lang.String caseDesc, java.lang.String caseId, java.lang.String status, java.lang.String commentsnotes, java.lang.String usecommentsnotes, java.lang.String wakeOperId, java.util.Calendar wakeDate, java.lang.String reviewOperId, java.util.Calendar startDate, int cdReason1, int cdReason2, int cdReason3, int cdReason4, int cdReason5, java.lang.String updatedXml) throws java.rmi.RemoteException;
    public java.lang.String searchCases(java.lang.String userId, java.lang.String caseId, java.lang.String caseType, java.util.Calendar beginDate, java.util.Calendar endDate, java.lang.String firstName, java.lang.String middleName, java.lang.String lastName, java.util.Calendar wakeDate) throws java.rmi.RemoteException;
    public java.lang.String searchDocuments(java.lang.String userId, java.lang.String docId, java.util.Calendar beginDate, java.util.Calendar endDate, java.lang.String mailType, java.lang.String mailId) throws java.rmi.RemoteException;
    public java.lang.String searchFax(java.lang.String userId, java.util.Calendar beginDate, java.util.Calendar endDate, java.lang.String faxNumber, java.lang.String faxServer, java.lang.String operId, java.lang.String status) throws java.rmi.RemoteException;
    public java.lang.String searchTaskItems(java.lang.String userId, java.util.Calendar beginDate, java.util.Calendar endDate, java.lang.String taskstatus, java.lang.String taskid, java.lang.String deptdesc, java.lang.String tasktype, java.lang.String actdesc, java.lang.String workbasket, int rowcount, boolean usecreatedate, boolean emptyworkbasket, java.lang.String iddesc1, java.lang.String field11, java.lang.String field12, java.lang.String field13, java.lang.String field14, java.lang.String iddesc2, java.lang.String field21, java.lang.String field22, java.lang.String field23, java.lang.String field24, java.lang.String iddesc3, java.lang.String field31, java.lang.String field32, java.lang.String field33, java.lang.String field34) throws java.rmi.RemoteException;
    public java.lang.String quickSearchByIdent(java.lang.String userId, java.util.Calendar beginDate, java.util.Calendar endDate, java.lang.String taskstatus, int rowcount, boolean usecreatedate, java.lang.String iddesc1, java.lang.String field11, java.lang.String field12, java.lang.String field13, java.lang.String field14) throws java.rmi.RemoteException;
    public java.lang.String viewComments(java.lang.String taskId, java.lang.String userId, java.util.Calendar begin, java.util.Calendar end) throws java.rmi.RemoteException;
    public java.lang.String createWorkEx(java.lang.String userId, java.lang.String createWorkXml) throws java.rmi.RemoteException;
    public java.lang.String addTasksToPacket(java.lang.String userId, java.lang.String addTaskToPktXml) throws java.rmi.RemoteException;
    public java.lang.String createWork(java.lang.String userId, java.lang.String department, java.lang.String taskType, java.lang.String actionStep, java.lang.String createOper, java.util.Calendar receivedDate, java.lang.String vip, java.lang.String workBasket, int priority, java.lang.String scanMode, boolean byPassArcIdent, java.lang.String comments, java.lang.String wrkStationId, java.lang.String idDesc, java.lang.String field1, java.lang.String field2, java.lang.String field3, java.lang.String field4, java.lang.String storage, java.lang.String extDocKey, java.lang.String extSysName, java.lang.String urlDocPath, java.lang.String notes, int pageTotal, java.lang.String mailDesc, java.lang.String mailId, java.lang.String archBox, java.lang.String magFldName, float fileSize, java.lang.String fileType, java.lang.String piDocType, java.lang.String faxNumber) throws java.rmi.RemoteException;
    public boolean addDocument(java.lang.String userId, java.lang.String taskId, java.lang.String packetId, java.lang.String storage, java.lang.String extDocKey, java.lang.String extSysName, java.lang.String urlDocPath, java.lang.String notes, java.lang.String wrkStationId, int pageTotal, java.lang.String mailDesc, java.lang.String mailId, java.lang.String archBox, java.lang.String magFldName, float fileSize, java.lang.String fileType, java.lang.String piDocType, java.lang.String faxNumber) throws java.rmi.RemoteException;
    public boolean addDocumentEx(java.lang.String userId, java.lang.String taskId, java.lang.String packetId, java.lang.String storage, java.lang.String extDocKey, java.lang.String extSysName, java.lang.String urlDocPath, java.lang.String notes, java.lang.String wrkStationId, int pageTotal, java.lang.String mailDesc, java.lang.String mailId, java.lang.String archBox, java.lang.String magFldName, float fileSize, java.lang.String fileType, java.lang.String piDocType, java.lang.String faxNumber, java.lang.String contType, int startPage, int endPage, boolean taskOnlyFlag) throws java.rmi.RemoteException;
    public java.lang.String processTaskEx(java.lang.String userId, java.lang.String updateTaskXML) throws java.rmi.RemoteException;
    public java.lang.String releaseTask(java.lang.String userId, java.lang.String taskId, boolean lockTask) throws java.rmi.RemoteException;
}
