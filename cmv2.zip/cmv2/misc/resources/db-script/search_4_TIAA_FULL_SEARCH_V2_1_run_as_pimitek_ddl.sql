create or replace PROCEDURE tiaa_full_search_v2_1
(


beginDate           date,
endDate             date,
taskStatus          char,
iddesc1             char,  /*as does identifier code*/
fieldvalue11      char,
fieldvalue12      char,
fieldvalue13      char,
fieldvalue14      char,
dptdesc             char, /*department code must be converted*/
tskdesc             char, /*task code needs to be converted*/
actdesc             char, /*action code also needs to be converted*/
taskId              char,
workBasket          char,
/* end PISearchInfo */
iddesc2             char,  /*as does identifier code*/
fieldvalue21      char,
fieldvalue22      char,
fieldvalue23      char,
fieldvalue24      char,
iddesc3             char,  /*as does identifier code*/
fieldvalue31      char,
fieldvalue32      char,
fieldvalue33      char,
fieldvalue34      char,
operId              char,
ruleBasedEngine     char, /* this is a YN field from the site table */
searchmaxrowcount   in int,
dateCode            int,
orderby             char,
descending          char,
retcode             in out int,  /* not used at this point */
totalcount          in out int,
search_recordset  OUT SYS_REFCURSOR
)
/* local variables */
AS

/*the following are integer codes the search EXP AG search engine uses, we'll translate to them from the strings passed into this function.*/


identifier1         char(75);


identifier2         char(75);


identifier3         char(75);

strfieldvalue1      char(50);
strfieldvalue2      char(50);
strfieldvalue3      char(50);
strfieldvalue4      char(50);
npinValues          char(500);


pdptdesc             char(10);
ptskdesc             char(10);
pactdesc             char(10);

sortingValue      char(4);

orderByValue      char(55);

sqlStatement                varchar2(32767);

pdptcode             int;
ptskcode             int;
pactcode             int;


beginDateInt        int;
beginTimeInt        int;
endDateInt          int;
endTimeInt          int;

counter             int;

/* Identifier variables for determining what identifier attributes to use.*/

pidcode    number;
pnbrfields number;
pfldnbr    number;
pfldsize   number;


pidcode1     number;
pnbrfields1  number;

pfldnbr11    number;
pfldnbr12    number;
pfldnbr13    number;
pfldnbr14    number;

pfldsize11   number;
pfldsize12   number;
pfldsize13   number;
pfldsize14   number;


pidcode2     number;
pnbrfields2  number;

pfldnbr21    number;
pfldnbr22    number;
pfldnbr23    number;
pfldnbr24    number;

pfldsize21   number;
pfldsize22   number;
pfldsize23   number;
pfldsize24   number;

pidcode3     number;
pnbrfields3  number;

pfldnbr31    number;
pfldnbr32    number;
pfldnbr33    number;
pfldnbr34    number;

pfldsize31   number;
pfldsize32   number;
pfldsize33   number;
pfldsize34   number;

appenddiff    int;

id_cursor       sys_refcursor;
descendingOrder          boolean;

BEGIN

if upper(trim(iddesc1)) = 'NPIN' then
npinValues := '''' || trim(fieldvalue11) || '''';
end if;

if upper(trim(iddesc2)) = 'NPIN' then
if length(npinValues) > 0 then
npinValues := trim(npinValues) || ',' || '''' || trim(fieldvalue21) || '''';
else
npinValues := '''' || trim(fieldvalue21) || '''';
end if;
end if;

if upper(trim(iddesc3)) = 'NPIN' then
if length(npinValues) > 0 then
npinValues := trim(npinValues) || ',' || '''' || trim(fieldvalue31) || '''';
else
npinValues := '''' || trim(fieldvalue31) || '''';
end if;
end if;

if length(npinValues) > 0 then        
npinValues := '(' || trim(npinValues) || ')';
else
npinValues := null;
end if;
--npinValues := '(''''M2VHR2V'''',''''PFRRJPQ'''')';
DBMS_OUTPUT.PUT_LINE('Npin values obtained ' || npinValues);

DBMS_OUTPUT.PUT_LINE('Starting search conversion');
pdptdesc := TRIM(dptdesc);
ptskdesc := TRIM(tskdesc);
pactdesc := TRIM(actdesc);

if pdptdesc is not null and pdptdesc <> ' ' then
declare
begin
select dpt.dptcode INTO pdptcode from dpt where TRIM(dpt.dptdesc) = TRIM(pdptdesc);
exception
WHEN NO_DATA_FOUND THEN 
pdptcode := 0; 
end;
else 
pdptcode := 0; 
end if;


if ptskdesc is not null and ptskdesc <> ' ' then
declare
begin
select tsktype.tskcode INTO  ptskcode from tsktype where TRIM(tsktype.tskdesc) = TRIM(ptskdesc);          
exception
WHEN NO_DATA_FOUND THEN 
ptskcode := 0; 
end;
else 
ptskcode := 0; 
end if;

if pactdesc is not null and pactdesc <> ' ' then
declare
begin
select acttype.actcode INTO  pactcode from acttype where TRIM(acttype.actdesc) = TRIM(pactdesc);
exception
WHEN NO_DATA_FOUND THEN 
pactcode := 0; 
end;
else 
pactcode := 0; 
end if;

--if the provided task description is invalid, we abort search
if (ptskdesc is not null and ptskcode <> 0) or ptskdesc is null then

DBMS_OUTPUT.PUT_LINE('Department: ' ||  pdptcode || ' Task: ' ||  ptskcode || ' Action Desc: ' ||  pactcode);




/*converting the dates to an Integer format*/
beginDateInt := to_number(to_char(beginDate, 'yyyymmdd'));
beginTimeInt := to_number(TO_CHAR(beginDate, 'HH24MI') || TO_CHAR(beginDate, 'MI') || '00');

endDateInt := to_number(to_char(endDate, 'yyyymmdd'));
endTimeInt := to_number(TO_CHAR(endDate, 'HH24MI') || TO_CHAR(endDate, 'MI') || '00');
DBMS_OUTPUT.PUT_LINE('Begin date ' || beginDateInt || ' Begin time ' || beginTimeInt );
DBMS_OUTPUT.PUT_LINE('End date ' || endDateInt || ' End time ' || endTimeInt );


counter := 0;


if iddesc1 is not null and iddesc1 <> ' ' then

open id_cursor for
select  idt.idcode,
idt.NBRFLDS,
idf.FLDNBR,
idf.FLDSIZE
from  idtype idt, idfield idf
where  TRIM(idt.iddesc) = TRIM(iddesc1)
AND  idf.idcode=idt.idcode
order by 3;



LOOP
FETCH id_cursor
INTO  pidcode, pnbrfields, pfldnbr, pfldsize;
EXIT WHEN id_cursor%NOTFOUND;
counter := counter + 1;
if counter = 1 THEN
pfldnbr11 := pfldnbr;
pfldsize11 := pfldsize;
pidcode1 := pidcode;
pnbrfields1 := pnbrfields;
DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode1 || ' | ' || pnbrfields1 || ' | ' || pfldnbr11 || ' | ' || pfldsize11);
elsif counter = 2 THEN
pfldnbr12 := pfldnbr;
pfldsize12 := pfldsize;
DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode1 || ' | ' || pnbrfields1 || ' | ' || pfldnbr12 || ' | ' || pfldsize12);
elsif counter = 3 THEN
pfldnbr13 := pfldnbr;
pfldsize13 := pfldsize;
DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode1 || ' | ' || pnbrfields1 || ' | ' || pfldnbr13 || ' | ' || pfldsize13);
elsif counter = 4 THEN
pfldnbr14 := pfldnbr;
pfldsize14 := pfldsize;
DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode1 || ' | ' || pnbrfields1 || ' | ' || pfldnbr14 || ' | ' || pfldsize14);
else
DBMS_OUTPUT.PUT_LINE('counter exceeds 4');
end if;
END LOOP;
CLOSE id_cursor;

counter := 0;
end if;

if iddesc2 is not null and iddesc2 <> ' ' then
open id_cursor for
select  idt.idcode,
idt.NBRFLDS,
idf.FLDNBR,
idf.FLDSIZE
from  idtype idt, idfield idf
where  TRIM(idt.iddesc) = TRIM(iddesc2)
AND  idf.idcode=idt.idcode
order by 3;



LOOP
FETCH id_cursor
INTO  pidcode, pnbrfields, pfldnbr, pfldsize;
EXIT WHEN id_cursor%NOTFOUND;
counter := counter + 1;
if counter = 1 THEN
pfldnbr21 := pfldnbr;
pfldsize21 := pfldsize;
pidcode2 := pidcode;
pnbrfields2 := pnbrfields;
DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode2 || ' | ' || pnbrfields2 || ' | ' || pfldnbr21 || ' | ' || pfldsize21);
elsif counter = 2 THEN
pfldnbr22 := pfldnbr;
pfldsize22 := pfldsize;
DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode2 || ' | ' || pnbrfields2 || ' | ' || pfldnbr22 || ' | ' || pfldsize22);
elsif counter = 3 THEN
pfldnbr23 := pfldnbr;
pfldsize23 := pfldsize;
DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode2 || ' | ' || pnbrfields2 || ' | ' || pfldnbr23 || ' | ' || pfldsize23);
elsif counter = 4 THEN
pfldnbr24 := pfldnbr;
pfldsize24 := pfldsize;
DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode2 || ' | ' || pnbrfields2 || ' | ' || pfldnbr24 || ' | ' || pfldsize24);
else
DBMS_OUTPUT.PUT_LINE('counter exceeds 4');
end if;
END LOOP;
CLOSE id_cursor;


counter := 0;
end if;
if iddesc3 is not null and iddesc3 <> ' ' then

open id_cursor for
select  idt.idcode,
idt.NBRFLDS,
idf.FLDNBR,
idf.FLDSIZE
from  idtype idt, idfield idf
where  TRIM(idt.iddesc) = TRIM(iddesc3)
AND  idf.idcode=idt.idcode
order by 3;



LOOP
FETCH id_cursor
INTO  pidcode, pnbrfields, pfldnbr, pfldsize;
EXIT WHEN id_cursor%NOTFOUND;
counter := counter + 1;
if counter = 1 THEN
pfldnbr31 := pfldnbr;
pfldsize31 := pfldsize;
pidcode3 := pidcode;
pnbrfields3 := pnbrfields;
DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode3 || ' | ' || pnbrfields3 || ' | ' || pfldnbr31 || ' | ' || pfldsize31);
elsif counter = 2 THEN
pfldnbr32 := pfldnbr;
pfldsize32 := pfldsize;
DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode3 || ' | ' || pnbrfields3 || ' | ' || pfldnbr32 || ' | ' || pfldsize32);
elsif counter = 3 THEN
pfldnbr33 := pfldnbr;
pfldsize33 := pfldsize;
DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode3 || ' | ' || pnbrfields3 || ' | ' || pfldnbr33 || ' | ' || pfldsize33);
elsif counter = 4 THEN
pfldnbr34 := pfldnbr;
pfldsize34 := pfldsize;
DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode3 || ' | ' || pnbrfields3 || ' | ' || pfldnbr34 || ' | ' || pfldsize34);
else
DBMS_OUTPUT.PUT_LINE('counter exceeds 4');
end if;
END LOOP;
CLOSE id_cursor;

end if;


if pidcode1 is not null and pidcode1 <> 0 then
if fieldvalue11 is null then
strfieldvalue1 := ' ';
else
strfieldvalue1 := trim(fieldvalue11);
end if;
DBMS_OUTPUT.PUT_LINE('field1 value: |' || rpad('', 4) || '|');
if fieldvalue12 is null then
strfieldvalue2 := ' ';
else
strfieldvalue2 := trim(fieldvalue12);
end if;
DBMS_OUTPUT.PUT_LINE('field2 value: |' || strfieldvalue2 || '|');
if fieldvalue13 is null then
strfieldvalue3 := ' ';
else
strfieldvalue3 := trim(fieldvalue13);
end if;
DBMS_OUTPUT.PUT_LINE('field3 value: |' || strfieldvalue3 || '|');
if fieldvalue14 is null then
strfieldvalue4 := ' ';
else
strfieldvalue4 := trim(fieldvalue14);
end if;
DBMS_OUTPUT.PUT_LINE('field4 value: |' || strfieldvalue4 || '|');
identifier1 := rpad(strfieldvalue1, pfldsize11 + 1) || rpad(strfieldvalue2, pfldsize12 + 1) || rpad(strfieldvalue3, pfldsize13 + 1) || rpad(strfieldvalue4, pfldsize14 + 1);
DBMS_OUTPUT.PUT_LINE('Identifier1 has the following value |' || identifier1 || '|');
end if;

if pidcode2 is not null and pidcode2 <> 0 then
if fieldvalue21 is null then
strfieldvalue1 := ' ';
else
strfieldvalue1 := trim(fieldvalue21);
end if;
DBMS_OUTPUT.PUT_LINE('field1 value: |' || rpad('', 4) || '|');
if fieldvalue22 is null then
strfieldvalue2 := ' ';
else
strfieldvalue2 := trim(fieldvalue22);
end if;
DBMS_OUTPUT.PUT_LINE('field2 value: |' || strfieldvalue2 || '|');
if fieldvalue23 is null then
strfieldvalue3 := ' ';
else
strfieldvalue3 := trim(fieldvalue23);
end if;
DBMS_OUTPUT.PUT_LINE('field3 value: |' || strfieldvalue3 || '|');
if fieldvalue24 is null then
strfieldvalue4 := ' ';
else
strfieldvalue4 := trim(fieldvalue24);
end if;
DBMS_OUTPUT.PUT_LINE('field4 value: |' || strfieldvalue4 || '|');
identifier2 := rpad(strfieldvalue1, pfldsize21 + 1) || rpad(strfieldvalue2, pfldsize22 + 1) || rpad(strfieldvalue3, pfldsize23 + 1) || rpad(strfieldvalue4, pfldsize24 + 1);
DBMS_OUTPUT.PUT_LINE('Identifier1 has the following value |' || identifier2 || '|');
end if;

if pidcode3 is not null and pidcode3 <> 0 then
if fieldvalue31 is null then
strfieldvalue1 := ' ';
else
strfieldvalue1 := trim(fieldvalue31);
end if;
DBMS_OUTPUT.PUT_LINE('field1 value: |' || rpad('', 4) || '|');
if fieldvalue32 is null then
strfieldvalue2 := ' ';
else
strfieldvalue2 := trim(fieldvalue32);
end if;
DBMS_OUTPUT.PUT_LINE('field2 value: |' || strfieldvalue2 || '|');
if fieldvalue33 is null then
strfieldvalue3 := ' ';
else
strfieldvalue3 := trim(fieldvalue33);
end if;
DBMS_OUTPUT.PUT_LINE('field3 value: |' || strfieldvalue3 || '|');
if fieldvalue34 is null then
strfieldvalue4 := ' ';
else
strfieldvalue4 := trim(fieldvalue34);
end if;
DBMS_OUTPUT.PUT_LINE('field4 value: |' || strfieldvalue4 || '|');
identifier3 := rpad(strfieldvalue1, pfldsize31 + 1) || rpad(strfieldvalue2, pfldsize32 + 1) || rpad(strfieldvalue3, pfldsize33 + 1) || rpad(strfieldvalue4, pfldsize34 + 1);
DBMS_OUTPUT.PUT_LINE('Identifier3 has the following value |' || identifier3 || '|');
end if;


DBMS_OUTPUT.PUT_LINE('Begin Date: ' || beginDateInt || ' Begin TIme: ' || beginTimeInt || ' End Date: ' || endDateInt || ' End Time: ' || endTimeInt || ' Task Status: ' || taskStatus || ' ID Code 1 ' || pidcode1
|| ' identifier1: ' || identifier1 || ' DepartmentCode: ' || pdptcode || ' Task Code: ' || ptskcode || ' Action Code: ' || pactcode || ' Task Id: ' || taskId || ' Workbasket: ' || workBasket || ' ID Code 2: ' || pidcode2
|| ' identifier2: ' || identifier2 || ' ID Code 3: ' || pidcode3 || ' Identifier3: ' || identifier3 || ' OperID: ' || operId || ' ruleBasedEngine: ' || ruleBasedEngine || ' searchmaxrowcount: ' || searchmaxrowcount);

IF descending IS NOT NULL AND descending <> 'F' THEN
  descendingOrder := TRUE;
ELSIF descending IS NOT NULL AND descending = 'F' THEN
    descendingOrder := FALSE;
END IF;



tiaaenhancedtasksearchv2_1 (
beginDateInt,
beginTimeInt,
endDateInt,
endTimeInt,
taskStatus,
pidcode1,
identifier1,
pdptcode,
ptskcode,
pactcode,
TRIM(taskId),
workBasket,
pidcode2,
identifier2,
pidcode3,
identifier3,
operId,
ruleBasedEngine,
searchmaxrowcount,
dateCode,
retcode,
totalcount,
descendingOrder);

else
execute immediate 'TRUNCATE TABLE pimitek.tiaa_task_id_cache';
end if;

if orderby is not null and orderby <> ' ' then

orderByValue := 'pn1.' || orderby;
DBMS_OUTPUT.PUT_LINE('Order by value ' || orderByValue);

DBMS_OUTPUT.PUT_LINE('descending value ' || descending);

if descending is null or (descending <> ' ' and descending <> 'F') then

if npinValues is not null then
DBMS_OUTPUT.PUT_LINE('Npin search; order in query desc');

open search_recordset for
Select *
from (
SELECT ROW_NUMBER() OVER (ORDER BY CASE ORDERBY WHEN 'STATUS' THEN pitable
WHEN 'CREATEDATE' THEN to_char(pn1.createdate) || to_char(pn1.createtime)
WHEN 'TASKID' THEN pn1.tskid 
WHEN 'DATERCVD' THEN to_char(pn1.datercvd) || to_char(pn1.TIMERCVD) 
WHEN 'PLAN' THEN planid  
WHEN 'CLIENTID' THEN clientid
WHEN 'PLANNAME' THEN planname 
WHEN 'CHANNEL' THEN channel 
WHEN 'PIN' THEN pin
WHEN 'NPIN' THEN npin
WHEN 'ASSIGNEDTO' THEN assignedto 
WHEN 'ACTIONSTEP' THEN actionstep 
WHEN 'CREATEOPER' THEN createoper 
WHEN 'LOCKOPER' THEN lockoper 
WHEN 'SUSPOPER' THEN suspoper 
WHEN 'DEPARTMENT' THEN department 
WHEN 'DEPARTMENTDESC' THEN departmentdescription 
WHEN 'TASKTYPE' THEN tasktype 
WHEN 'TASKDESC' THEN taskdescription 
WHEN 'LASTMODIFIED' THEN lastmodified || lastmodifiedtime 
WHEN 'WAKEDATE' THEN wakedate || waketime 
END desc) as RN, pn1.*
FROM (
SELECT
'open' as pitable,
t.tskid,
t.createdate,
t.createtime,
t.datercvd,
t.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
t.WRKBSKT as assignedto,  --blank or number returned then not assigned
a.actdesc AS actionstep,
t.createoper AS createoper,
t.lckoper as lockoper,
'' as suspoper,
'' AS excoper,
t.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM tskreq t
left outer join tskident ci on ci.tskid = t.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = t.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = t.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = t.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = t.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = t.tskid
left outer join tsktype tt on tt.tskcode = t.tskcode
left outer join dpt d on  t.dptcode = d.dptcode
left outer join acttype a on t.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = t.tskid
WHERE
t.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'suspend' as pitable,
s.tskid,
s.createdate,
s.createtime,
s.datercvd,
s.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
s.WRKBSKT as assignedto,
a.actdesc AS actionstep,
s.createoper AS createoper,
'' as lockoper,
s.suspoperid as suspoper,
'' AS excoper,
s.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
to_char(s.wakedate) AS wakedate,
to_char(s.waketime) AS waketime
FROM SUSPTSKREQ s
left outer join tskident ci on ci.tskid = s.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = s.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = s.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = s.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = s.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = s.tskid
left outer join tsktype tt on tt.tskcode = s.tskcode
left outer join dpt d on  s.dptcode = d.dptcode
left outer join acttype a on s.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = s.tskid
WHERE
s.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'qa wait' as pitable,
q.tskid,
q.createdate,
q.createtime,
q.datercvd,
q.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
q.WRKBSKT as assignedto,
'QA' AS actionstep,
q.createoper AS createoper,
'' as lockoper,
'' as suspoper,
q.excoper AS excoper,
q.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM QATSKREQ  q
left outer join tskident ci on ci.tskid = q.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = q.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = q.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = q.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = q.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = q.tskid
left outer join tsktype tt on tt.tskcode = q.tskcode
left outer join dpt d on  q.dptcode = d.dptcode
left outer join acttype a on q.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = q.tskid
WHERE
q.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
e.STATUS as pitable,
e.tskid,
e.createdate,
e.createtime,
e.datercvd,
e.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
e.WRKBSKT as assignedto,
'AWAIT EVAL' AS actionstep,
e.createoper AS createoper,
'' as lockoper,
'' as suspoper,
e.excoper AS excoper,
e.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM evalrulereq  e
left outer join tskident ci on ci.tskid = e.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = e.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = e.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = e.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = e.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = e.tskid
left outer join tsktype tt on tt.tskcode = e.tskcode
left outer join dpt d on  e.dptcode = d.dptcode
left outer join acttype a on e.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = e.tskid
WHERE
e.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'complete' as pitable,
c.tskid,
c.createdate,
c.createtime,
c.datercvd,
c.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
'' as assignedto,
'COMPLETED' AS actionstep,
c.createoper AS createoper,
--c.lockoper as lockoper,
'' as lockoper,
'' as suspoper,
'' AS excoper,
c.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM comptsk c
left outer join COMPTSKIDENT ci on ci.tskid = c.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join COMPTSKIDENT cii on cii.tskid = c.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join COMPTSKIDENT ciii on ciii.tskid = c.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join COMPTSKIDENT ciiii on ciiii.tskid = c.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join COMPTSKIDENT ciiiii on ciiiii.tskid = c.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from COMPTSKIDENT ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = c.tskid
left outer join tsktype tt on tt.tskcode = c.tskcode
left outer join dpt d on  c.dptcode = d.dptcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = c.tskid
WHERE
c.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
) pn1
);
--WHERE RN BETWEEN 1 AND 100;
else
DBMS_OUTPUT.PUT_LINE('Non-npin search; order in query desc');

open search_recordset for
Select *
from (
SELECT ROW_NUMBER() OVER (ORDER BY CASE ORDERBY WHEN 'STATUS' THEN pitable
WHEN 'CREATEDATE' THEN to_char(pn1.createdate) || to_char(pn1.createtime)
WHEN 'TASKID' THEN pn1.tskid 
WHEN 'DATERCVD' THEN to_char(pn1.datercvd) || to_char(pn1.TIMERCVD) 
WHEN 'PLAN' THEN planid  
WHEN 'CLIENTID' THEN clientid
WHEN 'PLANNAME' THEN planname 
WHEN 'CHANNEL' THEN channel 
WHEN 'PIN' THEN pin
WHEN 'NPIN' THEN npin
WHEN 'ASSIGNEDTO' THEN assignedto 
WHEN 'ACTIONSTEP' THEN actionstep 
WHEN 'CREATEOPER' THEN createoper 
WHEN 'LOCKOPER' THEN lockoper 
WHEN 'SUSPOPER' THEN suspoper 
WHEN 'DEPARTMENT' THEN department 
WHEN 'DEPARTMENTDESC' THEN departmentdescription 
WHEN 'TASKTYPE' THEN tasktype 
WHEN 'TASKDESC' THEN taskdescription 
WHEN 'LASTMODIFIED' THEN lastmodified || lastmodifiedtime 
WHEN 'WAKEDATE' THEN wakedate || waketime 
END desc) as RN, pn1.*
FROM (
SELECT
'open' as pitable,
t.tskid,
t.createdate,
t.createtime,
t.datercvd,
t.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
t.WRKBSKT as assignedto,  --blank or number returned then not assigned
a.actdesc AS actionstep,
t.createoper AS createoper,
t.lckoper as lockoper,
'' as suspoper,
'' AS excoper,
t.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM tskreq t
left outer join tskident ci on ci.tskid = t.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = t.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = t.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = t.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = t.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = t.tskid
left outer join tsktype tt on tt.tskcode = t.tskcode
left outer join dpt d on  t.dptcode = d.dptcode
left outer join acttype a on t.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = t.tskid
WHERE
t.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'suspend' as pitable,
s.tskid,
s.createdate,
s.createtime,
s.datercvd,
s.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
s.WRKBSKT as assignedto,
a.actdesc AS actionstep,
s.createoper AS createoper,
'' as lockoper,
s.suspoperid as suspoper,
'' AS excoper,
s.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
to_char(s.wakedate) AS wakedate,
to_char(s.waketime) AS waketime
FROM SUSPTSKREQ s
left outer join tskident ci on ci.tskid = s.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = s.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = s.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = s.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = s.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = s.tskid
left outer join tsktype tt on tt.tskcode = s.tskcode
left outer join dpt d on  s.dptcode = d.dptcode
left outer join acttype a on s.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = s.tskid
WHERE
s.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache) 
UNION
SELECT
'suspend' as pitable,
q.tskid,
q.createdate,
q.createtime,
q.datercvd,
q.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
q.WRKBSKT as assignedto,
'QA' AS actionstep,
q.createoper AS createoper,
'' as lockoper,
'' as suspoper,
q.excoper AS excoper,
q.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM QATSKREQ  q
left outer join tskident ci on ci.tskid = q.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = q.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = q.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = q.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = q.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = q.tskid
left outer join tsktype tt on tt.tskcode = q.tskcode
left outer join dpt d on  q.dptcode = d.dptcode
left outer join acttype a on q.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = q.tskid
WHERE
q.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
e.STATUS as pitable,
e.tskid,
e.createdate,
e.createtime,
e.datercvd,
e.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
e.WRKBSKT as assignedto,
'AWAIT EVAL' AS actionstep,
e.createoper AS createoper,
'' as lockoper,
'' as suspoper,
e.excoper AS excoper,
e.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM evalrulereq  e
left outer join tskident ci on ci.tskid = e.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = e.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = e.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = e.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = e.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = e.tskid
left outer join tsktype tt on tt.tskcode = e.tskcode
left outer join dpt d on  e.dptcode = d.dptcode
left outer join acttype a on e.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = e.tskid
WHERE
e.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'complete' as pitable,
c.tskid,
c.createdate,
c.createtime,
c.datercvd,
c.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
'' as assignedto,
'COMPLETED' AS actionstep,
c.createoper AS createoper,
--c.lockoper as lockoper,
'' as lockoper,
'' as suspoper,
'' AS excoper,
c.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM comptsk c
left outer join COMPTSKIDENT ci on ci.tskid = c.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join COMPTSKIDENT cii on cii.tskid = c.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join COMPTSKIDENT ciii on ciii.tskid = c.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join COMPTSKIDENT ciiii on ciiii.tskid = c.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join COMPTSKIDENT ciiiii on ciiiii.tskid = c.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from COMPTSKIDENT ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = c.tskid
left outer join tsktype tt on tt.tskcode = c.tskcode
left outer join dpt d on  c.dptcode = d.dptcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = c.tskid
WHERE
c.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
) pn1
);
--WHERE RN BETWEEN 1 AND 100;

end if;

else

if npinValues is not null then  
DBMS_OUTPUT.PUT_LINE('Npin search; order in query asc');

open search_recordset for
Select *
from (
SELECT ROW_NUMBER() OVER (ORDER BY CASE ORDERBY WHEN 'STATUS' THEN pitable
WHEN 'CREATEDATE' THEN to_char(pn1.createdate) || to_char(pn1.createtime)
WHEN 'TASKID' THEN pn1.tskid 
WHEN 'DATERCVD' THEN to_char(pn1.datercvd) || to_char(pn1.TIMERCVD) 
WHEN 'PLAN' THEN planid  
WHEN 'CLIENTID' THEN clientid
WHEN 'PLANNAME' THEN planname 
WHEN 'CHANNEL' THEN channel 
WHEN 'PIN' THEN pin
WHEN 'NPIN' THEN npin
WHEN 'ASSIGNEDTO' THEN assignedto 
WHEN 'ACTIONSTEP' THEN actionstep 
WHEN 'CREATEOPER' THEN createoper 
WHEN 'LOCKOPER' THEN lockoper 
WHEN 'SUSPOPER' THEN suspoper 
WHEN 'DEPARTMENT' THEN department 
WHEN 'DEPARTMENTDESC' THEN departmentdescription 
WHEN 'TASKTYPE' THEN tasktype 
WHEN 'TASKDESC' THEN taskdescription 
WHEN 'LASTMODIFIED' THEN lastmodified || lastmodifiedtime  
WHEN 'WAKEDATE' THEN wakedate || waketime 
END asc) as RN, pn1.*
FROM (
SELECT
'open' as pitable,
t.tskid,
t.createdate,
t.createtime,
t.datercvd,
t.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
t.WRKBSKT as assignedto,  --blank or number returned then not assigned
a.actdesc AS actionstep,
t.createoper AS createoper,
t.lckoper as lockoper,
'' as suspoper,
'' AS excoper,
t.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM tskreq t
left outer join tskident ci on ci.tskid = t.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = t.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = t.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = t.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = t.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = t.tskid
left outer join tsktype tt on tt.tskcode = t.tskcode
left outer join dpt d on  t.dptcode = d.dptcode
left outer join acttype a on t.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = t.tskid
WHERE
t.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'suspend' as pitable,
s.tskid,
s.createdate,
s.createtime,
s.datercvd,
s.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
s.WRKBSKT as assignedto,
a.actdesc AS actionstep,
s.createoper AS createoper,
'' as lockoper,
s.suspoperid as suspoper,
'' AS excoper,
s.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
to_char(s.wakedate) AS wakedate,
to_char(s.waketime) AS waketime
FROM SUSPTSKREQ s
left outer join tskident ci on ci.tskid = s.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = s.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = s.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = s.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = s.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = s.tskid
left outer join tsktype tt on tt.tskcode = s.tskcode
left outer join dpt d on  s.dptcode = d.dptcode
left outer join acttype a on s.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = s.tskid
WHERE
s.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'suspend' as pitable,
q.tskid,
q.createdate,
q.createtime,
q.datercvd,
q.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
q.WRKBSKT as assignedto,
'QA' AS actionstep,
q.createoper AS createoper,
'' as lockoper,
'' as suspoper,
q.excoper AS excoper,
q.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM QATSKREQ  q
left outer join tskident ci on ci.tskid = q.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = q.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = q.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = q.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = q.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = q.tskid
left outer join tsktype tt on tt.tskcode = q.tskcode
left outer join dpt d on  q.dptcode = d.dptcode
left outer join acttype a on q.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = q.tskid
WHERE
q.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
e.STATUS as pitable,
e.tskid,
e.createdate,
e.createtime,
e.datercvd,
e.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
e.WRKBSKT as assignedto,
'AWAIT EVAL' AS actionstep,
e.createoper AS createoper,
'' as lockoper,
'' as suspoper,
e.excoper AS excoper,
e.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM evalrulereq  e
left outer join tskident ci on ci.tskid = e.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = e.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = e.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = e.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = e.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = e.tskid
left outer join tsktype tt on tt.tskcode = e.tskcode
left outer join dpt d on  e.dptcode = d.dptcode
left outer join acttype a on e.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = e.tskid
WHERE
e.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'complete' as pitable,
c.tskid,
c.createdate,
c.createtime,
c.datercvd,
c.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
'' as assignedto,
'COMPLETED' AS actionstep,
c.createoper AS createoper,
--c.lockoper as lockoper,
'' as lockoper,
'' as suspoper,
'' AS excoper,
c.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM comptsk c
left outer join COMPTSKIDENT ci on ci.tskid = c.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join COMPTSKIDENT cii on cii.tskid = c.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join COMPTSKIDENT ciii on ciii.tskid = c.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join COMPTSKIDENT ciiii on ciiii.tskid = c.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join COMPTSKIDENT ciiiii on ciiiii.tskid = c.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from COMPTSKIDENT ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = c.tskid
left outer join tsktype tt on tt.tskcode = c.tskcode
left outer join dpt d on  c.dptcode = d.dptcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = c.tskid
WHERE
c.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
) pn1
);
--WHERE RN BETWEEN 1 AND 100;
else
DBMS_OUTPUT.PUT_LINE('Non-npin search; order in query asc');

open search_recordset for
Select *
from (
SELECT ROW_NUMBER() OVER (ORDER BY CASE ORDERBY WHEN 'STATUS' THEN pitable
WHEN 'CREATEDATE' THEN to_char(pn1.createdate) || to_char(pn1.createtime)
WHEN 'TASKID' THEN pn1.tskid 
WHEN 'DATERCVD' THEN to_char(pn1.datercvd) || to_char(pn1.TIMERCVD) 
WHEN 'PLAN' THEN planid  
WHEN 'CLIENTID' THEN clientid
WHEN 'PLANNAME' THEN planname 
WHEN 'CHANNEL' THEN channel 
WHEN 'PIN' THEN pin
WHEN 'NPIN' THEN npin
WHEN 'ASSIGNEDTO' THEN assignedto 
WHEN 'ACTIONSTEP' THEN actionstep 
WHEN 'CREATEOPER' THEN createoper 
WHEN 'LOCKOPER' THEN lockoper 
WHEN 'SUSPOPER' THEN suspoper 
WHEN 'DEPARTMENT' THEN department 
WHEN 'DEPARTMENTDESC' THEN departmentdescription 
WHEN 'TASKTYPE' THEN tasktype 
WHEN 'TASKDESC' THEN taskdescription 
WHEN 'LASTMODIFIED' THEN lastmodified || lastmodifiedtime  
WHEN 'WAKEDATE' THEN wakedate || waketime 
END asc) as RN, pn1.*
FROM (
SELECT
'open' as pitable,
t.tskid,
t.createdate,
t.createtime,
t.datercvd,
t.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
t.WRKBSKT as assignedto,  --blank or number returned then not assigned
a.actdesc AS actionstep,
t.createoper AS createoper,
t.lckoper as lockoper,
'' as suspoper,
'' AS excoper,
t.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM tskreq t
left outer join tskident ci on ci.tskid = t.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = t.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = t.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = t.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = t.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = t.tskid
left outer join tsktype tt on tt.tskcode = t.tskcode
left outer join dpt d on  t.dptcode = d.dptcode
left outer join acttype a on t.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = t.tskid
WHERE
t.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'suspend' as pitable,
s.tskid,
s.createdate,
s.createtime,
s.datercvd,
s.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
s.WRKBSKT as assignedto,
a.actdesc AS actionstep,
s.createoper AS createoper,
'' as lockoper,
s.suspoperid as suspoper,
'' AS excoper,
s.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
to_char(s.wakedate) AS wakedate,
to_char(s.waketime) AS waketime
FROM SUSPTSKREQ s
left outer join tskident ci on ci.tskid = s.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = s.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = s.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = s.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = s.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = s.tskid
left outer join tsktype tt on tt.tskcode = s.tskcode
left outer join dpt d on  s.dptcode = d.dptcode
left outer join acttype a on s.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = s.tskid
WHERE
s.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache) 
UNION
SELECT
'suspend' as pitable,
q.tskid,
q.createdate,
q.createtime,
q.datercvd,
q.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
q.WRKBSKT as assignedto,
'QA' AS actionstep,
q.createoper AS createoper,
'' as lockoper,
'' as suspoper,
q.excoper AS excoper,
q.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM QATSKREQ  q
left outer join tskident ci on ci.tskid = q.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = q.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = q.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = q.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = q.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = q.tskid
left outer join tsktype tt on tt.tskcode = q.tskcode
left outer join dpt d on  q.dptcode = d.dptcode
left outer join acttype a on q.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = q.tskid
WHERE
q.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
e.STATUS as pitable,
e.tskid,
e.createdate,
e.createtime,
e.datercvd,
e.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
e.WRKBSKT as assignedto,
'AWAIT EVAL' AS actionstep,
e.createoper AS createoper,
'' as lockoper,
'' as suspoper,
e.excoper AS excoper,
e.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM evalrulereq  e
left outer join tskident ci on ci.tskid = e.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = e.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = e.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = e.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = e.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = e.tskid
left outer join tsktype tt on tt.tskcode = e.tskcode
left outer join dpt d on  e.dptcode = d.dptcode
left outer join acttype a on e.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = e.tskid
WHERE
e.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'complete' as pitable,
c.tskid,
c.createdate,
c.createtime,
c.datercvd,
c.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
'' as assignedto,
'COMPLETED' AS actionstep,
c.createoper AS createoper,
--c.lockoper as lockoper,
'' as lockoper,
'' as suspoper,
'' AS excoper,
c.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM comptsk c
left outer join COMPTSKIDENT ci on ci.tskid = c.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join COMPTSKIDENT cii on cii.tskid = c.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join COMPTSKIDENT ciii on ciii.tskid = c.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join COMPTSKIDENT ciiii on ciiii.tskid = c.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join COMPTSKIDENT ciiiii on ciiiii.tskid = c.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from COMPTSKIDENT ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = c.tskid
left outer join tsktype tt on tt.tskcode = c.tskcode
left outer join dpt d on  c.dptcode = d.dptcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = c.tskid
WHERE
c.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
) pn1
);
--WHERE RN BETWEEN 1 AND 100;

end if;





end if;





else

DBMS_OUTPUT.PUT_LINE('Default behavior branch');

if descending is null or (descending <> ' ' and descending <> 'F') then

if npinValues is not null then
DBMS_OUTPUT.PUT_LINE('Npin search; Descending');

open search_recordset for
Select *
from (
SELECT ROW_NUMBER() OVER (ORDER BY pn1.createdate desc, pn1.createtime desc) as RN, pn1.*
FROM (
SELECT
'open' as pitable,
t.tskid,
t.createdate,
t.createtime,
t.datercvd,
t.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
t.WRKBSKT as assignedto,  --blank or number returned then not assigned
a.actdesc AS actionstep,
t.createoper AS createoper,
t.lckoper as lockoper,
'' as suspoper,
'' AS excoper,
t.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM tskreq t
left outer join tskident ci on ci.tskid = t.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = t.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = t.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = t.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = t.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = t.tskid
left outer join tsktype tt on tt.tskcode = t.tskcode
left outer join dpt d on  t.dptcode = d.dptcode
left outer join acttype a on t.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = t.tskid
WHERE
t.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache) 
UNION
SELECT
'suspend' as pitable,
s.tskid,
s.createdate,
s.createtime,
s.datercvd,
s.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
s.WRKBSKT as assignedto,
a.actdesc AS actionstep,
s.createoper AS createoper,
'' as lockoper,
s.suspoperid as suspoper,
'' AS excoper,
s.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
to_char(s.wakedate) AS wakedate,
to_char(s.waketime) AS waketime
FROM SUSPTSKREQ s
left outer join tskident ci on ci.tskid = s.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = s.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = s.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = s.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = s.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = s.tskid
left outer join tsktype tt on tt.tskcode = s.tskcode
left outer join dpt d on  s.dptcode = d.dptcode
left outer join acttype a on s.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = s.tskid
WHERE
s.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache) 
UNION
SELECT
'suspend' as pitable,
q.tskid,
q.createdate,
q.createtime,
q.datercvd,
q.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
q.WRKBSKT as assignedto,
'QA' AS actionstep,
q.createoper AS createoper,
'' as lockoper,
'' as suspoper,
q.excoper AS excoper,
q.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM QATSKREQ  q
left outer join tskident ci on ci.tskid = q.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = q.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = q.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = q.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = q.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = q.tskid
left outer join tsktype tt on tt.tskcode = q.tskcode
left outer join dpt d on  q.dptcode = d.dptcode
left outer join acttype a on q.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = q.tskid
WHERE
q.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
e.STATUS as pitable,
e.tskid,
e.createdate,
e.createtime,
e.datercvd,
e.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
e.WRKBSKT as assignedto,
'AWAIT EVAL' AS actionstep,
e.createoper AS createoper,
'' as lockoper,
'' as suspoper,
e.excoper AS excoper,
e.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM evalrulereq  e
left outer join tskident ci on ci.tskid = e.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = e.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = e.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = e.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = e.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = e.tskid
left outer join tsktype tt on tt.tskcode = e.tskcode
left outer join dpt d on  e.dptcode = d.dptcode
left outer join acttype a on e.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = e.tskid
WHERE
e.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'complete' as pitable,
c.tskid,
c.createdate,
c.createtime,
c.datercvd,
c.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
'' as assignedto,
'COMPLETED' AS actionstep,
c.createoper AS createoper,
--c.lockoper as lockoper,
'' as lockoper,
'' as suspoper,
'' AS excoper,
c.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM comptsk c
left outer join COMPTSKIDENT ci on ci.tskid = c.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join COMPTSKIDENT cii on cii.tskid = c.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join COMPTSKIDENT ciii on ciii.tskid = c.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join COMPTSKIDENT ciiii on ciiii.tskid = c.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join COMPTSKIDENT ciiiii on ciiiii.tskid = c.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from COMPTSKIDENT ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = c.tskid
left outer join tsktype tt on tt.tskcode = c.tskcode
left outer join dpt d on  c.dptcode = d.dptcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = c.tskid
WHERE
c.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache) 
) pn1
);
--WHERE RN BETWEEN 1 AND 100;
else
DBMS_OUTPUT.PUT_LINE('Non npin search; Descending');

open search_recordset for
Select *
from (
SELECT ROW_NUMBER() OVER (ORDER BY pn1.createdate desc, pn1.createtime desc) as RN, pn1.*
FROM (
SELECT
'open' as pitable,
t.tskid,
t.createdate,
t.createtime,
t.datercvd,
t.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
t.WRKBSKT as assignedto,  --blank or number returned then not assigned
a.actdesc AS actionstep,
t.createoper AS createoper,
t.lckoper as lockoper,
'' as suspoper,
'' AS excoper,
t.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM tskreq t
left outer join tskident ci on ci.tskid = t.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = t.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = t.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = t.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = t.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = t.tskid
left outer join tsktype tt on tt.tskcode = t.tskcode
left outer join dpt d on  t.dptcode = d.dptcode
left outer join acttype a on t.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = t.tskid
WHERE
t.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache) 
UNION
SELECT
'suspend' as pitable,
s.tskid,
s.createdate,
s.createtime,
s.datercvd,
s.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
s.WRKBSKT as assignedto,
a.actdesc AS actionstep,
s.createoper AS createoper,
'' as lockoper,
s.suspoperid as suspoper,
'' AS excoper,
s.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
to_char(s.wakedate) AS wakedate,
to_char(s.waketime) AS waketime
FROM SUSPTSKREQ s
left outer join tskident ci on ci.tskid = s.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = s.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = s.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = s.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = s.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = s.tskid
left outer join tsktype tt on tt.tskcode = s.tskcode
left outer join dpt d on  s.dptcode = d.dptcode
left outer join acttype a on s.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = s.tskid
WHERE
s.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache) 
UNION
SELECT
'suspend' as pitable,
q.tskid,
q.createdate,
q.createtime,
q.datercvd,
q.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
q.WRKBSKT as assignedto,
'QA' AS actionstep,
q.createoper AS createoper,
'' as lockoper,
'' as suspoper,
q.excoper AS excoper,
q.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM QATSKREQ  q
left outer join tskident ci on ci.tskid = q.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = q.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = q.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = q.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = q.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = q.tskid
left outer join tsktype tt on tt.tskcode = q.tskcode
left outer join dpt d on  q.dptcode = d.dptcode
left outer join acttype a on q.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = q.tskid
WHERE
q.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
e.STATUS as pitable,
e.tskid,
e.createdate,
e.createtime,
e.datercvd,
e.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
e.WRKBSKT as assignedto,
'AWAIT EVAL' AS actionstep,
e.createoper AS createoper,
'' as lockoper,
'' as suspoper,
e.excoper AS excoper,
e.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM evalrulereq  e
left outer join tskident ci on ci.tskid = e.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = e.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = e.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = e.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = e.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = e.tskid
left outer join tsktype tt on tt.tskcode = e.tskcode
left outer join dpt d on  e.dptcode = d.dptcode
left outer join acttype a on e.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = e.tskid
WHERE
e.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'complete' as pitable,
c.tskid,
c.createdate,
c.createtime,
c.datercvd,
c.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
'' as assignedto,
'COMPLETED' AS actionstep,
c.createoper AS createoper,
--c.lockoper as lockoper,
'' as lockoper,
'' as suspoper,
'' AS excoper,
c.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM comptsk c
left outer join COMPTSKIDENT ci on ci.tskid = c.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join COMPTSKIDENT cii on cii.tskid = c.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join COMPTSKIDENT ciii on ciii.tskid = c.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join COMPTSKIDENT ciiii on ciiii.tskid = c.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join COMPTSKIDENT ciiiii on ciiiii.tskid = c.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from COMPTSKIDENT ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = c.tskid
left outer join tsktype tt on tt.tskcode = c.tskcode
left outer join dpt d on  c.dptcode = d.dptcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = c.tskid
WHERE
c.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache) 
) pn1
);
--WHERE RN BETWEEN 1 AND 100;

end if;

else

if npinValues is not null then
DBMS_OUTPUT.PUT_LINE('Npin Search; Ascending');

open search_recordset for
Select *
from (
SELECT ROW_NUMBER() OVER (ORDER BY pn1.createdate asc, pn1.createtime asc) as RN, pn1.*
FROM (
SELECT
'open' as pitable,
t.tskid,
t.createdate,
t.createtime,
t.datercvd,
t.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
t.WRKBSKT as assignedto,  --blank or number returned then not assigned
a.actdesc AS actionstep,
t.createoper AS createoper,
t.lckoper as lockoper,
'' as suspoper,
'' AS excoper,
t.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM tskreq t
left outer join tskident ci on ci.tskid = t.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = t.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = t.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = t.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = t.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = t.tskid
left outer join tsktype tt on tt.tskcode = t.tskcode
left outer join dpt d on  t.dptcode = d.dptcode
left outer join acttype a on t.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = t.tskid
WHERE
t.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'suspend' as pitable,
s.tskid,
s.createdate,
s.createtime,
s.datercvd,
s.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
s.WRKBSKT as assignedto,
a.actdesc AS actionstep,
s.createoper AS createoper,
'' as lockoper,
s.suspoperid as suspoper,
'' AS excoper,
s.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
to_char(s.wakedate) AS wakedate,
to_char(s.waketime) AS waketime
FROM SUSPTSKREQ s
left outer join tskident ci on ci.tskid = s.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = s.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = s.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = s.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = s.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = s.tskid
left outer join tsktype tt on tt.tskcode = s.tskcode
left outer join dpt d on  s.dptcode = d.dptcode
left outer join acttype a on s.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = s.tskid
WHERE
s.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'suspend' as pitable,
q.tskid,
q.createdate,
q.createtime,
q.datercvd,
q.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
q.WRKBSKT as assignedto,
'QA' AS actionstep,
q.createoper AS createoper,
'' as lockoper,
'' as suspoper,
q.excoper AS excoper,
q.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM QATSKREQ  q
left outer join tskident ci on ci.tskid = q.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = q.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = q.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = q.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = q.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = q.tskid
left outer join tsktype tt on tt.tskcode = q.tskcode
left outer join dpt d on  q.dptcode = d.dptcode
left outer join acttype a on q.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = q.tskid
WHERE
q.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
e.STATUS as pitable,
e.tskid,
e.createdate,
e.createtime,
e.datercvd,
e.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
e.WRKBSKT as assignedto,
'AWAIT EVAL' AS actionstep,
e.createoper AS createoper,
'' as lockoper,
'' as suspoper,
e.excoper AS excoper,
e.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM evalrulereq  e
left outer join tskident ci on ci.tskid = e.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = e.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = e.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = e.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = e.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = e.tskid
left outer join tsktype tt on tt.tskcode = e.tskcode
left outer join dpt d on  e.dptcode = d.dptcode
left outer join acttype a on e.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = e.tskid
WHERE
e.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'complete' as pitable,
c.tskid,
c.createdate,
c.createtime,
c.datercvd,
c.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
'' as assignedto,
'COMPLETED' AS actionstep,
c.createoper AS createoper,
--c.lockoper as lockoper,
'' as lockoper,
'' as suspoper,
'' AS excoper,
c.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM comptsk c
left outer join COMPTSKIDENT ci on ci.tskid = c.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join COMPTSKIDENT cii on cii.tskid = c.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join COMPTSKIDENT ciii on ciii.tskid = c.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join COMPTSKIDENT ciiii on ciiii.tskid = c.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join COMPTSKIDENT ciiiii on ciiiii.tskid = c.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from COMPTSKIDENT ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = c.tskid
left outer join tsktype tt on tt.tskcode = c.tskcode
left outer join dpt d on  c.dptcode = d.dptcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = c.tskid
WHERE
c.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
) pn1
);
--WHERE RN BETWEEN 1 AND 100;
else
DBMS_OUTPUT.PUT_LINE('Non npin Search; Ascending');

open search_recordset for
Select *
from (
SELECT ROW_NUMBER() OVER (ORDER BY pn1.createdate asc, pn1.createtime asc) as RN, pn1.*
FROM (
SELECT
'open' as pitable,
t.tskid,
t.createdate,
t.createtime,
t.datercvd,
t.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
t.WRKBSKT as assignedto,  --blank or number returned then not assigned
a.actdesc AS actionstep,
t.createoper AS createoper,
t.lckoper as lockoper,
'' as suspoper,
'' AS excoper,
t.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM tskreq t
left outer join tskident ci on ci.tskid = t.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = t.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = t.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = t.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = t.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = t.tskid
left outer join tsktype tt on tt.tskcode = t.tskcode
left outer join dpt d on  t.dptcode = d.dptcode
left outer join acttype a on t.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = t.tskid
WHERE
t.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'suspend' as pitable,
s.tskid,
s.createdate,
s.createtime,
s.datercvd,
s.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
s.WRKBSKT as assignedto,
a.actdesc AS actionstep,
s.createoper AS createoper,
'' as lockoper,
s.suspoperid as suspoper,
'' AS excoper,
s.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
to_char(s.wakedate) AS wakedate,
to_char(s.waketime) AS waketime
FROM SUSPTSKREQ s
left outer join tskident ci on ci.tskid = s.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = s.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = s.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = s.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = s.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = s.tskid
left outer join tsktype tt on tt.tskcode = s.tskcode
left outer join dpt d on  s.dptcode = d.dptcode
left outer join acttype a on s.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = s.tskid
WHERE
s.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'suspend' as pitable,
q.tskid,
q.createdate,
q.createtime,
q.datercvd,
q.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
q.WRKBSKT as assignedto,
'QA' AS actionstep,
q.createoper AS createoper,
'' as lockoper,
'' as suspoper,
q.excoper AS excoper,
q.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM QATSKREQ  q
left outer join tskident ci on ci.tskid = q.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = q.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = q.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = q.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = q.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = q.tskid
left outer join tsktype tt on tt.tskcode = q.tskcode
left outer join dpt d on  q.dptcode = d.dptcode
left outer join acttype a on q.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = q.tskid
WHERE
q.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
e.STATUS as pitable,
e.tskid,
e.createdate,
e.createtime,
e.datercvd,
e.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
e.WRKBSKT as assignedto,
'AWAIT EVAL' AS actionstep,
e.createoper AS createoper,
'' as lockoper,
'' as suspoper,
e.excoper AS excoper,
e.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM evalrulereq  e
left outer join tskident ci on ci.tskid = e.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join tskident cii on cii.tskid = e.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join tskident ciii on ciii.tskid = e.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join tskident ciiii on ciiii.tskid = e.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join tskident ciiiii on ciiiii.tskid = e.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from tskident ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and (npinValues is null or instr(npinValues,trim(fieldvalue)) > 0)) ciiiiii on ciiiiii.tskid = e.tskid
left outer join tsktype tt on tt.tskcode = e.tskcode
left outer join dpt d on  e.dptcode = d.dptcode
left outer join acttype a on e.actcode = a.actcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = e.tskid
WHERE
e.tskid  IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
SELECT
'complete' as pitable,
c.tskid,
c.createdate,
c.createtime,
c.datercvd,
c.TIMERCVD,
ci.fieldvalue AS planid,
cii.fieldvalue AS clientid,
ciii.fieldvalue AS planname,
ciiii.fieldvalue AS channel,
ciiiii.fieldvalue AS pin,
ciiiiii.fieldvalue AS npin,
'' as assignedto,
'COMPLETED' AS actionstep,
c.createoper AS createoper,
--c.lockoper as lockoper,
'' as lockoper,
'' as suspoper,
'' AS excoper,
c.pktid,
d.dptdesc    AS department,
d.dptlngname AS departmentdescription,
tt.tskdesc    AS tasktype,
tt.tsklngname AS taskdescription,
to_char(hist.lastmodifieddate) AS lastmodified,
to_char(hist.lastmodifiedtime) AS lastmodifiedtime,
'' AS wakedate,
'' AS waketime
FROM comptsk c
left outer join COMPTSKIDENT ci on ci.tskid = c.tskid and ci.idcode = 17 and ci.fieldnbr = 1
left outer join COMPTSKIDENT cii on cii.tskid = c.tskid and cii.idcode = 55 and cii.fieldnbr = 1
left outer join COMPTSKIDENT ciii on ciii.tskid = c.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
left outer join COMPTSKIDENT ciiii on ciiii.tskid = c.tskid and ciiii.idcode = 75 and ciiii.fieldnbr = 1
left outer join COMPTSKIDENT ciiiii on ciiiii.tskid = c.tskid and ciiiii.idcode = 7 and ciiiii.fieldnbr = 1
left outer join (select ti.tskid, ti.fieldvalue from COMPTSKIDENT ti, TIAA_Task_ID_Cache tc where ti.tskid=tc.tskid and ti.idcode=8 and ti.fieldnbr= 1 and instr(npinValues,trim(fieldvalue)) > 0) ciiiiii on ciiiiii.tskid = c.tskid
left outer join tsktype tt on tt.tskcode = c.tskcode
left outer join dpt d on  c.dptcode = d.dptcode
left outer join (select h.tskid, max(pidate) as lastmodifieddate, max(endtime) as lastmodifiedtime from tskhist h, TIAA_Task_ID_Cache tc where h.tskid = tc.tskid group by h.tskid) hist on hist.tskid = c.tskid
WHERE
c.tskid IN (SELECT DISTINCT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
) pn1
);
--WHERE RN BETWEEN 1 AND 100;

end if;

end if;
end if;




end;