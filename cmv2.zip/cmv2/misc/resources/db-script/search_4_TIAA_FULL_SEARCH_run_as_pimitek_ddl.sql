create or replace PROCEDURE tiaa_full_search
                (


                    beginDate           date,
                    endDate             date,
                    taskStatus          char,
                    iddesc1             char,  /*as does identifier code*/
                    fieldvalue11   		char,
                    fieldvalue12   		char,
                    fieldvalue13   		char,
                    fieldvalue14   		char,
                    dptdesc             char, /*department code must be converted*/
                    tskdesc             char, /*task code needs to be converted*/
                    actdesc             char, /*action code also needs to be converted*/
                    taskId              char,
                    workBasket          char,
                    /* end PISearchInfo */
                    iddesc2             char,  /*as does identifier code*/
                    fieldvalue21   		char,
                    fieldvalue22   		char,
                    fieldvalue23   		char,
                    fieldvalue24   		char,
                    iddesc3             char,  /*as does identifier code*/
                    fieldvalue31   		char,
                    fieldvalue32   		char,
                    fieldvalue33   		char,
                    fieldvalue34   		char,
                    operId              char,
                    ruleBasedEngine     char, /* this is a YN field from the site table */
                    searchmaxrowcount   in int,
                    dateCode            int,
                    retcode             in out int,  /* not used at this point */
                    totalcount          in out int,
					search_recordset 	OUT SYS_REFCURSOR
                    )
                    /* local variables */
AS

/*the following are integer codes the search EXP AG search engine uses, we'll translate to them from the strings passed into this function.*/


        identifier1         char(50);


        identifier2         char(50);


        identifier3         char(50);


        pdptdesc             char(10);
        ptskdesc             char(10);
        pactdesc             char(10);

        pdptcode             int;
        ptskcode             int;
        pactcode             int;


        beginDateInt        int;
        beginTimeInt        int;
        endDateInt          int;
        endTimeInt          int;

        counter             int;

		/* Identifier variables for determining what identifier attributes to use.*/

       pidcode    number;
        pnbrfields number;
        pfldnbr    number;
        pfldsize   number;


        pidcode1     number;
        pnbrfields1  number;

        pfldnbr11    number;
        pfldnbr12    number;
        pfldnbr13    number;
        pfldnbr14    number;

        pfldsize11   number;
        pfldsize12   number;
        pfldsize13   number;
        pfldsize14   number;


        pidcode2     number;
        pnbrfields2  number;

        pfldnbr21    number;
        pfldnbr22    number;
        pfldnbr23    number;
        pfldnbr24    number;

        pfldsize21   number;
        pfldsize22   number;
        pfldsize23   number;
        pfldsize24   number;

        pidcode3     number;
        pnbrfields3  number;

        pfldnbr31    number;
        pfldnbr32    number;
        pfldnbr33    number;
        pfldnbr34    number;

        pfldsize31   number;
        pfldsize32   number;
        pfldsize33   number;
        pfldsize34   number;

        appenddiff    int;

        id_cursor       sys_refcursor;


        BEGIN

        DBMS_OUTPUT.PUT_LINE('Starting search conversion');
        pdptdesc := TRIM(dptdesc);
        ptskdesc := TRIM(tskdesc);
        pactdesc := TRIM(actdesc);

        if pdptdesc is not null and pdptdesc <> ' ' then
          select dpt.dptcode INTO pdptcode from dpt where TRIM(dpt.dptdesc) = TRIM(pdptdesc);
        else --jay debug
          pdptcode := 0; --jay debug
        end if;

        if ptskdesc is not null and ptskdesc <> ' ' then
          select tsktype.tskcode INTO  ptskcode from tsktype where TRIM(tsktype.tskdesc) = TRIM(ptskdesc);
          else --jay debug
            ptskcode := 0; --jay debug
        end if;

        if pactdesc is not null and pactdesc <> ' ' then
          select acttype.actcode INTO  pactcode from acttype where TRIM(acttype.actdesc) = TRIM(pactdesc);
        else --jay debug
          pactcode := 0; --jay debug
        end if;


        DBMS_OUTPUT.PUT_LINE('Department: ' ||  pdptcode || ' Task: ' ||  ptskcode || ' Action Desc: ' ||  pactcode);




        /*converting the dates to an Integer format*/
        beginDateInt := to_number(to_char(beginDate, 'yyyymmdd'));
        beginTimeInt := to_number(TO_CHAR(beginDate, 'HH24MI') || TO_CHAR(beginDate, 'MI') || '00');

        endDateInt := to_number(to_char(endDate, 'yyyymmdd'));
        endTimeInt := to_number(TO_CHAR(endDate, 'HH24MI') || TO_CHAR(endDate, 'MI') || '00');
        DBMS_OUTPUT.PUT_LINE('Begin date ' || beginDateInt || ' Begin time ' || beginTimeInt );
        DBMS_OUTPUT.PUT_LINE('End date ' || endDateInt || ' End time ' || endTimeInt );


        counter := 0;




      open id_cursor for
        select  idt.idcode,
         idt.NBRFLDS,
         idf.FLDNBR,
         idf.FLDSIZE
        from  idtype idt, idfield idf
        where  TRIM(idt.iddesc) = TRIM(iddesc1)
        AND  idf.idcode=idt.idcode
        order by 3;



        LOOP
            FETCH id_cursor
            INTO  pidcode, pnbrfields, pfldnbr, pfldsize;
            EXIT WHEN id_cursor%NOTFOUND;
            counter := counter + 1;
            if counter = 1 THEN
              pfldnbr11 := pfldnbr;
              pfldsize11 := pfldsize;
              pidcode1 := pidcode;
              pnbrfields1 := pnbrfields;
              DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode1 || ' | ' || pnbrfields1 || ' | ' || pfldnbr11 || ' | ' || pfldsize11);
            elsif counter = 2 THEN
              pfldnbr12 := pfldnbr;
              pfldsize12 := pfldsize;
              DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode1 || ' | ' || pnbrfields1 || ' | ' || pfldnbr12 || ' | ' || pfldsize12);
            elsif counter = 3 THEN
              pfldnbr13 := pfldnbr;
              pfldsize13 := pfldsize;
              DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode1 || ' | ' || pnbrfields1 || ' | ' || pfldnbr13 || ' | ' || pfldsize13);
            elsif counter = 4 THEN
              pfldnbr14 := pfldnbr;
              pfldsize14 := pfldsize;
              DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode1 || ' | ' || pnbrfields1 || ' | ' || pfldnbr14 || ' | ' || pfldsize14);
            else
              DBMS_OUTPUT.PUT_LINE('counter exceeds 4');
            end if;
        END LOOP;
        CLOSE id_cursor;

        counter := 0;

        open id_cursor for
        select  idt.idcode,
         idt.NBRFLDS,
         idf.FLDNBR,
         idf.FLDSIZE
        from  idtype idt, idfield idf
        where  TRIM(idt.iddesc) = TRIM(iddesc2)
        AND  idf.idcode=idt.idcode
        order by 3;



        LOOP
            FETCH id_cursor
            INTO  pidcode, pnbrfields, pfldnbr, pfldsize;
            EXIT WHEN id_cursor%NOTFOUND;
            counter := counter + 1;
            if counter = 1 THEN
              pfldnbr21 := pfldnbr;
              pfldsize21 := pfldsize;
              pidcode2 := pidcode;
              pnbrfields2 := pnbrfields;
              DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode2 || ' | ' || pnbrfields2 || ' | ' || pfldnbr21 || ' | ' || pfldsize21);
            elsif counter = 2 THEN
              pfldnbr22 := pfldnbr;
              pfldsize22 := pfldsize;
              DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode2 || ' | ' || pnbrfields2 || ' | ' || pfldnbr22 || ' | ' || pfldsize22);
            elsif counter = 3 THEN
              pfldnbr23 := pfldnbr;
              pfldsize23 := pfldsize;
              DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode2 || ' | ' || pnbrfields2 || ' | ' || pfldnbr23 || ' | ' || pfldsize23);
            elsif counter = 4 THEN
              pfldnbr24 := pfldnbr;
              pfldsize24 := pfldsize;
              DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode2 || ' | ' || pnbrfields2 || ' | ' || pfldnbr24 || ' | ' || pfldsize24);
            else
              DBMS_OUTPUT.PUT_LINE('counter exceeds 4');
            end if;
        END LOOP;
        CLOSE id_cursor;


        counter := 0;

        open id_cursor for
        select  idt.idcode,
         idt.NBRFLDS,
         idf.FLDNBR,
         idf.FLDSIZE
        from  idtype idt, idfield idf
        where  TRIM(idt.iddesc) = TRIM(iddesc3)
        AND  idf.idcode=idt.idcode
        order by 3;



        LOOP
            FETCH id_cursor
            INTO  pidcode, pnbrfields, pfldnbr, pfldsize;
            EXIT WHEN id_cursor%NOTFOUND;
            counter := counter + 1;
            if counter = 1 THEN
              pfldnbr31 := pfldnbr;
              pfldsize31 := pfldsize;
              pidcode3 := pidcode;
              pnbrfields3 := pnbrfields;
              DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode3 || ' | ' || pnbrfields3 || ' | ' || pfldnbr31 || ' | ' || pfldsize31);
            elsif counter = 2 THEN
              pfldnbr32 := pfldnbr;
              pfldsize32 := pfldsize;
              DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode3 || ' | ' || pnbrfields3 || ' | ' || pfldnbr32 || ' | ' || pfldsize32);
            elsif counter = 3 THEN
              pfldnbr33 := pfldnbr;
              pfldsize33 := pfldsize;
              DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode3 || ' | ' || pnbrfields3 || ' | ' || pfldnbr33 || ' | ' || pfldsize33);
            elsif counter = 4 THEN
              pfldnbr34 := pfldnbr;
              pfldsize34 := pfldsize;
              DBMS_OUTPUT.PUT_LINE('counter: ' || counter || ' id code: ' || pidcode3 || ' | ' || pnbrfields3 || ' | ' || pfldnbr34 || ' | ' || pfldsize34);
            else
              DBMS_OUTPUT.PUT_LINE('counter exceeds 4');
            end if;
        END LOOP;
        CLOSE id_cursor;




        if pidcode1 is not null and pidcode1 <> 0 then
          identifier1 := rpad(trim(fieldvalue11), pfldsize11) || rpad(trim(fieldvalue12), pfldsize12) || rpad(trim(fieldvalue13), pfldsize13) || rpad(trim(fieldvalue14), pfldsize14);
          DBMS_OUTPUT.PUT_LINE('Identifier1 has the following value |' || identifier1 || '|');
        end if;

        if pidcode2 is not null and pidcode2 <> 0 then
          identifier2 := rpad(trim(fieldvalue21), pfldsize21) || rpad(trim(fieldvalue22), pfldsize22) || rpad(trim(fieldvalue23), pfldsize23) || rpad(trim(fieldvalue24), pfldsize24);
          DBMS_OUTPUT.PUT_LINE('Identifier2 has the following value |' || identifier2 || '|');
        end if;

        if pidcode3 is not null and pidcode3 <> 0 then
          identifier3 := rpad(trim(fieldvalue31), pfldsize31) || rpad(trim(fieldvalue32), pfldsize32) || rpad(trim(fieldvalue33), pfldsize33) || rpad(trim(fieldvalue34), pfldsize34);
          DBMS_OUTPUT.PUT_LINE('Identifier3 has the following value |' || identifier3 || '|');
        end if;


         DBMS_OUTPUT.PUT_LINE('Begin Date: ' || beginDateInt || ' Begin TIme: ' || beginTimeInt || ' End Date: ' || endDateInt || ' End Time: ' || endTimeInt || ' Task Status: ' || taskStatus || ' ID Code 1 ' || pidcode1
         || ' identifier1: ' || identifier1 || ' DepartmentCode: ' || pdptcode || ' Task Code: ' || ptskcode || ' Action Code: ' || pactcode || ' Task Id: ' || taskId || ' Workbasket: ' || workBasket || ' ID Code 2: ' || pidcode2
         || ' identifier2: ' || identifier2 || ' ID Code 3: ' || pidcode3 || ' Identifier3: ' || identifier3 || ' OperID: ' || operId || ' ruleBasedEngine: ' || ruleBasedEngine || ' searchmaxrowcount: ' || searchmaxrowcount);





        tiaaenhancedtasksearch (
beginDateInt,
beginTimeInt,
endDateInt,
endTimeInt,
taskStatus,
pidcode1,
identifier1,
pdptcode,
ptskcode,
pactcode,
TRIM(taskId),
workBasket,
pidcode2,
identifier2,
pidcode3,
identifier3,
operId,
ruleBasedEngine,
searchmaxrowcount,
dateCode,
retcode,
totalcount);


open search_recordset for
Select *
from (
SELECT ROW_NUMBER() OVER (ORDER BY pn1.createdate desc, pn1.createtime desc) as RN, pn1.*
  FROM (
    SELECT
      'open' as "pitable",
      t.tskid,
      t.createdate,
      t.createtime,
      t.datercvd,
      t.TIMERCVD,
      ci.fieldvalue AS "planid",
      cii.fieldvalue AS "clientid",
      ciii.fieldvalue AS "planname",
      ciiii.fieldvalue AS "channel",
      t.WRKBSKT as "assignedto",  --blank or number returned then not assigned
      a.actdesc AS "actionstep",
      t.createoper AS "createoper",
      t.lckoper as "lockoper",
      '' as "suspoper",
      d.dptdesc    AS "department",
      d.dptlngname AS "departmentdescription",
      tt.tskdesc    AS "tasktype",
      tt.tsklngname AS "taskdescription"
    FROM tskreq t
      left outer join tskident ci on ci.tskid = t.tskid and ci.idcode = 17 and ci.fieldnbr = 1
      left outer join tskident cii on cii.tskid = t.tskid and cii.idcode = 55 and cii.fieldnbr = 1
      left outer join tskident ciii on ciii.tskid = t.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
      left outer join tskident ciiii on ciiii.tskid = t.tskid and ciiii.idcode = 76 and ciiii.fieldnbr = 1
      left outer join tsktype tt on tt.tskcode = t.tskcode
      left outer join dpt d on  t.dptcode = d.dptcode
      left outer join acttype a on t.actcode = a.actcode
    WHERE
    t.tskid IN (SELECT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
UNION
    SELECT
      'suspend' as "pitable",
      s.tskid,
      s.createdate,
      s.createtime,
      s.datercvd,
      s.TIMERCVD,
      ci.fieldvalue AS "planid",
      cii.fieldvalue AS "clientid",
      ciii.fieldvalue AS "planname",
      ciiii.fieldvalue AS "channel",
      s.WRKBSKT as "assignedto",
      a.actdesc AS "actionstep",
      s.createoper AS "createoper",
      '' as "lockoper",
      s.suspoperid as "suspoper",
      d.dptdesc    AS "department",
      d.dptlngname AS "departmentdescription",
      tt.tskdesc    AS "tasktype",
      tt.tsklngname AS "taskdescription"
    FROM SUSPTSKREQ s
      left outer join tskident ci on ci.tskid = s.tskid and ci.idcode = 17 and ci.fieldnbr = 1
      left outer join tskident cii on cii.tskid = s.tskid and cii.idcode = 55 and cii.fieldnbr = 1
      left outer join tskident ciii on ciii.tskid = s.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
      left outer join tskident ciiii on ciiii.tskid = s.tskid and ciiii.idcode = 76 and ciiii.fieldnbr = 1
      left outer join tsktype tt on tt.tskcode = s.tskcode
      left outer join dpt d on  s.dptcode = d.dptcode
      left outer join acttype a on s.actcode = a.actcode
    WHERE
    s.tskid  IN (SELECT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
  UNION
  SELECT
      'complete' as "pitable",
      c.tskid,
      c.createdate,
      c.createtime,
      c.datercvd,
      c.TIMERCVD,
      ci.fieldvalue AS "planid",
      cii.fieldvalue AS "clientid",
      ciii.fieldvalue AS "planname",
      ciiii.fieldvalue AS "channel",
      '' as "assignedto",
      'COMPLETED' AS "actionstep",
      c.createoper AS "createoper",
      --c.lockoper as "lockoper",
      '' as "lockoper",
      '' as "suspoper",
      d.dptdesc    AS "department",
      d.dptlngname AS "departmentdescription",
      tt.tskdesc    AS "tasktype",
      tt.tsklngname AS "taskdescription"
    FROM comptsk c
      left outer join COMPTSKIDENT ci on ci.tskid = c.tskid and ci.idcode = 17 and ci.fieldnbr = 1
      left outer join COMPTSKIDENT cii on cii.tskid = c.tskid and cii.idcode = 55 and cii.fieldnbr = 1
      left outer join COMPTSKIDENT ciii on ciii.tskid = c.tskid and ciii.idcode = 27 and ciii.fieldnbr = 1
      left outer join COMPTSKIDENT ciiii on ciiii.tskid = c.tskid and ciiii.idcode = 76 and ciiii.fieldnbr = 1
      left outer join tsktype tt on tt.tskcode = c.tskcode
      left outer join dpt d on  c.dptcode = d.dptcode
    WHERE
    c.tskid IN (SELECT taskcache.tskid FROM TIAA_Task_ID_Cache taskcache)
  ) pn1
  );
--WHERE RN BETWEEN 1 AND 100;





end;