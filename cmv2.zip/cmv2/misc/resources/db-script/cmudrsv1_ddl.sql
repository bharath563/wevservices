CREATE SEQUENCE CMREPORTING.CMS_POLLER_LOG_SEQ;
CREATE SEQUENCE CMREPORTING.CMS_AUDIT_SEQ;
CREATE SEQUENCE CMREPORTING.CMS_AUDIT_HISTORY_SEQ;
CREATE SEQUENCE CMREPORTING.CMS_TASK_TYPE_SEQ;
CREATE SEQUENCE CMREPORTING.CMS_IMAGECGI_IMG_ID_SEQ;
CREATE SEQUENCE CMREPORTING.CMS_MIRROR_EIV_IMG_ID_SEQ;

CREATE TABLE CMREPORTING.CMS_TASK_TYPE
(
  cms_task_type_id 			NUMBER NOT NULL,
  active           			NUMBER(1,0) NOT NULL,
  created_by       			VARCHAR(30),
  created_date_ts  			TIMESTAMP,
  task_type        			VARCHAR(30),
  updated_by       			VARCHAR(30),
  updated_date_ts  			TIMESTAMP,
  sla						NUMBER(5,0),
  captiva_routing_code		VARCHAR2(20),
  cth_request_schema_name	VARCHAR2(30),
  create_cth_record			NUMBER(1,0),
  PLAN_MODIFICATION_REQUEST_TASK 	NUMBER(1,0) DEFAULT 0,
  PRIMARY KEY (cms_task_type_id)
);

CREATE INDEX CMS_TASK_TYPE_TASK_TYPE
  ON CMS_TASK_TYPE (TASK_TYPE);

CREATE TABLE CMREPORTING.CMS_AUDIT
(
  cms_audit_id          NUMBER NOT NULL,
  case_id               VARCHAR(50),
  created_date_ts       TIMESTAMP,
  cth_orchestration_id  VARCHAR(20),
  cth_request_id        VARCHAR(20),
  last_updated_ts       TIMESTAMP,
  system                VARCHAR(20),
  task_id               VARCHAR(50),
  update_cth_request_id NUMBER(1,0) NOT NULL,
  task_type				VARCHAR(30),
  SEND_EMAIL			NUMBER(1,0) DEFAULT 0, 
  EMAIL_SENT 			NUMBER(1,0) DEFAULT 0, 
  PRIMARY KEY (cms_audit_id)
);

CREATE INDEX CMS_AUDIT_TASK_ID
  ON CMS_AUDIT (TASK_ID);
  
CREATE INDEX CMS_AUDIT_CTH_ORCHESTRATION_ID
  ON CMS_AUDIT (CTH_ORCHESTRATION_ID);  

CREATE TABLE CMREPORTING.CMS_AUDIT_HISTORY
(
  cms_audit_history_id NUMBER NOT NULL,
  created_date_ts      TIMESTAMP,
  cth_request_status   VARCHAR(30),
  last_updated_ts      TIMESTAMP,
  retry_attempt        NUMBER(5,0) NOT NULL,
  status               VARCHAR(30),
  task_status          VARCHAR(30),
  task_id	       VARCHAR2(50),
  start_date	       NUMBER(8,0),
  start_time	       NUMBER(10,0),
  cms_audit            NUMBER,
  comments             VARCHAR(3000),
  error_message        VARCHAR(3000),
  cth_event            NUMBER(5,0) NOT NULL,
  EVENT_NAME			VARCHAR(30),
  PRIMARY KEY (cms_audit_history_id)
);

CREATE INDEX CMS_AUDIT_HISTORY_TASK_ID
  ON CMS_AUDIT_HISTORY (TASK_ID);
  
CREATE INDEX CMS_AUDIT_HISTORY_STATUS
  ON CMS_AUDIT_HISTORY (STATUS);  
  
CREATE TABLE CMREPORTING.CMS_ACTIVE_POLLER
(
    owner           VARCHAR2(50),
    name            VARCHAR2(30),
    last_updated_ts TIMESTAMP (6)
);

CREATE TABLE CMREPORTING.CMS_POLLER_LOG
(
  id                       NUMBER NOT NULL,
  last_processed_ts 	   TIMESTAMP,
  workflow_system          VARCHAR(50),
  host_name		   VARCHAR2(40),
  node_name		   VARCHAR2(30),
  active		   NUMBER(1,0),
  PRIMARY KEY (id)
);

ALTER TABLE CMREPORTING.CMS_AUDIT_HISTORY ADD CONSTRAINT FK_CMS_AUDIT_ID_1 FOREIGN KEY
(
CMS_AUDIT
)
REFERENCES CMREPORTING.CMS_AUDIT;

CREATE TABLE CMREPORTING.CMS_MIRROR_EIV_IMG 
(
	cms_mirror_eiv_img_id 	NUMBER PRIMARY KEY,
	PLATTER      		VARCHAR2(20) NOT NULL,
	VOLUME      		VARCHAR2(20) NOT NULL,
	FILEADDRESS     	VARCHAR2(20) NOT NULL
);

CREATE TABLE CMREPORTING.CMS_IMAGECGI_IMG (
	cms_imagecgi_img_id 	NUMBER PRIMARY KEY,
	Volume      		VARCHAR2(20) NOT NULL,
	Volumecode 		VARCHAR2(20) NOT NULL,
	Volumepath 		VARCHAR2(100) NOT NULL,
	dr      		CHAR(1) NOT NULL,
	nfs_share 		VARCHAR2(150)
);