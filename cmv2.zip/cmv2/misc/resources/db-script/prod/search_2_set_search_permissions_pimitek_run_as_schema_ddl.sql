GRANT EXECUTE ON pisyst.GETSITEINFO TO pimitek;
GRANT EXECUTE ON pisyst.GETIDENTIFIERFIELDS TO pimitek;
grant select on pisyst.site to pimitek; 
grant select on pisyst.qatskreq to pimitek; 
grant select on pisyst.ocrtskreq to pimitek; 
grant select on pisyst.IDTYPE to pimitek; 
grant select on pisyst.IDFIELD to pimitek; 