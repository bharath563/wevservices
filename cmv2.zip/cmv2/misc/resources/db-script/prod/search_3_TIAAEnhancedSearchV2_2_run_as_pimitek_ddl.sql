create or replace PROCEDURE TIAAEnhancedTaskSearchV2_2
                (
                    /* PISearchInfo from apistrct.h */
                    beginDate           int,
                    beginTime           int,
                    endDate             int,
                    endTime             int,
                    taskStatus          char,
                    idcode              int,
                    identifier          char,
                    dptcode             int,
                    tskcode             int,
                    actcode             int,
                    taskId              char,
                    workBasket          char,
                    /* end PISearchInfo */
                    idcode2             int,
                    identifier2         char,
                    idcode3             int,
                    identifier3         char,
                    operId              char,
                    ruleBasedEngine     char, /* this is a YN field from the site table */
                    searchmaxrowcount   in int,
                    dateCode            int,
                    retcode             in out int,  /* not used at this point */
                     totalcount          in out int,
                     descending         boolean
                    )
/* local variables */
AS
msg                         char(100);
tskIdCount                  int;
tskidTmp                    char(11);
sqlStatement                varchar2(32767);
dateTimeWhereClause         varchar2(32767);
WorkBasketWhereClause       varchar2(32767);
DepartmentWhereClause       varchar2(32767);
TaskTypeWhereClause         varchar2(32767);
ActionWhereClause           varchar2(32767);
IdentifierWhereClause       varchar2(32767);
CompIdentifierWhereClause   varchar2(32767);
RowNumWhereClause           varchar2(32767);
WhereClause                 varchar2(32767);
l_SecurityWhereClause       varchar2(32767);
isSecurityOn                int;
l_operId                    char(8);
rescode                     int;
TmpIdentifierStr            varchar2(50);
TmpWorkBasketStr            char(8);
siteValueStr                char(1);
tskidList1                  char(50);
tskIdCount1                 int;
l_wrkbskt                   CHAR(8);
tmpChar                     char(1);
tableCount                  int;
tmpCount                    int;
field1                      char(50);
field2                      char(50);
field3                      char(50);
field4                      char(50);
field21                     char(50);
field22                     char(50);
field23                     char(50);
field24                     char(50);
field31                     char(50);
field32                     char(50);
field33                     char(50);
field34                     char(50);
fieldnbr                    int;
comptskidentSqlStatement    varchar2(32767);
tskidentSqlStatement        varchar2(32767);
susptskidentSqlStatement    varchar2(32767);
qatskidentSqlStatement      varchar2(32767);
tmpTskIdFrom                char(11);
tmpTskIdEnd                 char(11);
l_searchmaxrowcount         int;
l_totalcount                int;
l_workBasket                CHAR(8);
l_notauthorized             PLS_INTEGER := 0;
l_tskfound                  PLS_INTEGER := 0;
tmpStr                      varchar2(50);
tmpStr1                     varchar2(50);
maxtaskidCount              int;
/* the following local variables are used to control the order we search the task tables */
comptskTableSearchOrder     int;
tskreqTableSearchOrder      int;
qatskreqTableSearchOrder    int;
ocrtskreqTableSearchOrder   int;
susptskreqTableSearchOrder  int;
evalrulereqTableSearchOrder int;
bEmptyWorkBasket            int;
parenthesiscnt              int;
l_dptcode                   int;
l_miscflags                 int;
l_miscdptcode               int;
l_dptoper                   char(8);
l_dptcount                  int;
/* */
/* bind variables locals */
bDateBnd    int;
bTimeBnd    int;
eDateBnd    int;
eTimeBnd    int;
idcodeBnd   int;
dptBnd      int;
tskBnd      int;
actBnd      int;
idcodeBnd2  int;
idcodeBnd3  int;
searchMaxCountBnd int;
searchMaxCountBnd1 int;
/* end PISearchInfo */
cur         INTEGER;
rows_inserted INTEGER;
tmp_tskid   char(11);
CURSOR  site_cur is
    SELECT  substr(pifield,0,1)
    FROM    piprod.site
    WHERE   pikey = 'elikeoperatorsearch';
BEGIN
execute immediate 'TRUNCATE TABLE pimitek.tiaa_task_id_cache';
DBMS_OUTPUT.PUT_LINE('Enchanced Search Procedure Execute begins.');
maxtaskidCount := 1500;
l_workBasket := workBasket;
IF l_workBasket IS NULL THEN
  l_workBasket := ' ';
END IF;
    /* clean up the where clauses */
    sqlStatement            := '';
    dateTimeWhereClause     := '';
    WorkBasketWhereClause   := '';
    DepartmentWhereClause   := '';
    TaskTypeWhereClause     := '';
    ActionWhereClause       := '';
    IdentifierWhereClause   := '';
    RowNumWhereClause       := '';
    WhereClause             := '';
    TmpIdentifierStr        := substr(identifier,0,50);
    TmpWorkBasketStr        := substr(NVL(l_workBasket,' '),0,8);
    l_operId                := substr(operID,0,8);
    l_dptcode               := dptcode;
    bDateBnd    := beginDate;
    bTimeBnd    := beginTime;
    eDateBnd    := endDate;
    eTimeBnd    := endTime;
    idcodeBnd   := idcode;
    dptBnd      := dptcode;
    tskBnd      := tskcode;
    actBnd      := actcode;
    idcodeBnd2  := idcode2;
    idcodeBnd3  := idcode3;
    searchMaxCountBnd := searchmaxrowcount;
    bEmptyWorkBasket := 0;
    parenthesiscnt := 1;
    field1    := '';
    field2    := '';
    field3    := '';
    field4    := '';
    field21   := '';
    field22   := '';
    field23   := '';
    field24   := '';
    field31   := '';
    field32   := '';
    field33   := '';
    field34   := '';
    fieldnbr  := 1;
    tskidentSqlStatement     := '';
    comptskidentSqlStatement := '';
    susptskidentSqlStatement := '';
    qatskidentSqlStatement   := '';
    tskidTmp   := '';
    retcode    := 1;/* assume sucess */
    /* reset the result count */
    tskIdCount  :=0;
    tskIdCount1 :=0;
    totalcount  :=0;
    l_totalcount :=0;
    /* setup the order we search the task tables starting from 0 */
    comptskTableSearchOrder     := 0;
    tskreqTableSearchOrder      := 1;
    qatskreqTableSearchOrder    := 2;
    ocrtskreqTableSearchOrder   := 3;
    susptskreqTableSearchOrder  := 4;
    evalrulereqTableSearchOrder := 5;
    /* code added for security checking */
    l_SecurityWhereClause := ' ';
    isSecurityOn := 0;
    IF l_operId  != 'PIBCSCAN' THEN
       piprod.GetSiteInfo('dptsecurity', 'Y', isSecurityOn);
    END IF;
        IF searchmaxrowcount > 0 THEN
       searchMaxCountBnd := searchmaxrowcount;
       l_searchmaxrowcount := searchmaxrowcount;
        ELSIF searchmaxrowcount < 0 THEN
           l_searchmaxrowcount := 1500;
        ELSE
       BEGIN
          SELECT RTRIM(pifield) INTO l_searchmaxrowcount
          FROM piprod.site
          WHERE pikey ='searchmaxrowcount';
          searchMaxCountBnd := l_searchmaxrowcount;
          IF (l_searchmaxrowcount = 0) OR (TRIM(l_searchmaxrowcount) IS NULL ) THEN
             l_searchmaxrowcount := 1500;
          END IF;
       EXCEPTION
           WHEN NO_DATA_FOUND THEN
              l_searchmaxrowcount := 1500;
       END;
    END IF;
        searchMaxCountBnd := l_searchmaxrowcount;
        IF l_searchmaxrowcount > 0 THEN
           l_searchmaxrowcount := l_searchmaxrowcount + 1;
        END IF;
    /* the search is divided in 1 major criteria. If we pass a tskid          */
    /* then we do not worry about the other parameters. The tskIdCount should */
    /* be 1 or 0. Of course there is a possibility of a db inconsistency, but */
    /* we do not wont to sacrifice execution time finding this inconsistency  */
    /* so in other words, if a tskid is passed then:                          */
    /* 1. Do not set the search count                                         */
    /* 2. Start searching in this order tskreq,comptsk,susptskreq,qatskreq,ocrtskreq */
    /* SEARCH IS BASED ON A TASKID */
    IF taskId <> ' ' THEN
        tskidTmp := taskId;
        /* assume found */
        tskidList1 :=taskId;
        /* tskreq first */
        SELECT COUNT(*) INTO tskIdCount FROM tskreq WHERE tskid =  tskidTmp;
        totalcount := tskIdCount;
        IF tskIdCount > 0
        THEN
    DBMS_OUTPUT.PUT_LINE('Inserting ' || taskId || ' into cache');
    INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (taskId);
    COMMIT;
         SELECT wrkbskt INTO l_wrkbskt FROM tskreq WHERE tskid = tskidTmp;
          IF TRIM(l_wrkbskt) != TRIM(l_operid) THEN
            -- if any tasks were found then try the secured tasks
            IF isSecurityOn = 1
            THEN
                 SELECT  COUNT(*) INTO tskIdCount
                 FROM tskreq t, authdpt au,dpt d
                 WHERE t.tskid     = tskidTmp
                 and   t.dptcode   = au.dptcode
                 AND   t.dptcode   = d.dptcode
                 AND   ((au.operid   = l_operId AND   d.miscflags = 1) OR ( d.miscflags = 0 ))
                 AND rownum = 1;
              ELSE
                NULL;
              END IF;
                totalcount := tskIdCount;
                IF tskIdCount > 0
                THEN
                    RETURN;
                ELSE
                    raise_application_error(-20001, 'Operator is not authorized to view the task.');
                END IF;
            ELSE
              RETURN;
            END IF;
    END IF;
        /* comptsk */
        SELECT COUNT(*) INTO tskIdCount FROM comptsk WHERE tskid =  tskidTmp;
        totalcount := tskIdCount;
        IF tskIdCount > 0
        THEN
    DBMS_OUTPUT.PUT_LINE('Inserting ' || taskId || ' into cache');
    INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (taskId);
    COMMIT;
            -- if any tasks were found then try the secured tasks
            IF isSecurityOn = 1
            THEN
                 SELECT  COUNT(*) INTO tskIdCount
                 FROM comptsk t, authdpt au,dpt d
                 WHERE t.tskid     = tskidTmp
                 and   t.dptcode   = au.dptcode
                 AND   t.dptcode   = d.dptcode
                 AND   ((au.operid   = l_operId AND   d.miscflags = 1) OR ( d.miscflags = 0 ))
                 AND rownum = 1;
                totalcount := tskIdCount;
                IF tskIdCount > 0
                THEN
                    RETURN;
                ELSE
                 raise_application_error(-20001, 'Operator is not authorized to view the task.');
               END IF;
            ELSE
              RETURN;
            END IF;

        END IF;
        /* susptskreq */
        SELECT COUNT(*) INTO tskIdCount FROM susptskreq WHERE tskid =  tskidTmp;

        totalcount := tskIdCount;
        IF tskIdCount > 0
        THEN

    DBMS_OUTPUT.PUT_LINE('Inserting ' || taskId || ' into cache');
    INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (taskId);
    COMMIT;

        SELECT wrkbskt INTO l_wrkbskt FROM susptskreq WHERE tskid = tskidTmp;
           IF TRIM(l_wrkbskt) != TRIM(l_operid) THEN
            -- if any tasks were found then try the secured tasks
            IF isSecurityOn = 1
            THEN
                 SELECT  COUNT(*) INTO tskIdCount
                 FROM susptskreq t, authdpt au,dpt d
                 WHERE t.tskid     = tskidTmp
                 and   t.dptcode   = au.dptcode
                 AND   t.dptcode   = d.dptcode
                 AND   ((au.operid   = l_operId AND   d.miscflags = 1) OR ( d.miscflags = 0 ))
                 AND rownum = 1;
                   ELSE
                      NULL;
                   END IF;
                totalcount := tskIdCount;
                IF tskIdCount > 0
                THEN
                    RETURN;
                ELSE
                    raise_application_error(-20001, 'Operator is not authorized to view the task.');
                        END IF;
            ELSE
              RETURN;
            END IF;
        END IF;
        /* qatskreq */
        SELECT COUNT(*) INTO tskIdCount FROM piprod.qatskreq WHERE tskid =  tskidTmp;
        totalcount := tskIdCount;
        IF tskIdCount > 0
        THEN
        
        DBMS_OUTPUT.PUT_LINE('Inserting ' || taskId || ' into cache');
    INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (taskId);
    COMMIT;
        
        
           SELECT wrkbskt INTO l_wrkbskt FROM piprod.qatskreq WHERE tskid = tskidTmp;
           IF TRIM(l_wrkbskt) != TRIM(l_operid) THEN
            -- if any tasks were found then try the secured tasks
            IF isSecurityOn = 1
            THEN
                 SELECT  COUNT(*) INTO tskIdCount
                 FROM piprod.qatskreq t, piprod.authdpt au,dpt d
                 WHERE t.tskid     = tskidTmp
                 and   t.dptcode   = au.dptcode
                 AND   t.dptcode   = d.dptcode
                 AND   ((au.operid   = l_operId AND   d.miscflags = 1) OR ( d.miscflags = 0 ))
                 AND rownum = 1;
                   ELSE
                      NULL;
                   END IF;
                        totalcount := tskIdCount;
                        IF tskIdCount > 0
                THEN
                     RETURN;
                ELSE
                    raise_application_error(-20001, 'Operator is not authorized to view the task.');
                END IF;
            ELSE
              RETURN;
            END IF;
        END IF;
        /* evalrulereq */
        SELECT COUNT(*) INTO tskIdCount FROM piprod.evalrulereq WHERE tskid =  tskidTmp;
        totalcount := tskIdCount;
        IF tskIdCount > 0
        THEN
        
        DBMS_OUTPUT.PUT_LINE('Inserting ' || taskId || ' into cache');
    INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (taskId);
    COMMIT;
        
           SELECT wrkbskt INTO l_wrkbskt FROM piprod.evalrulereq WHERE tskid = tskidTmp;
           IF TRIM(l_wrkbskt) != TRIM(l_operid) THEN
            -- if any tasks were found then try the secured tasks
            IF isSecurityOn = 1
            THEN
                 SELECT  COUNT(*) INTO tskIdCount
                 FROM piprod.evalrulereq t, piprod.authdpt au,dpt d
                 WHERE t.tskid     = tskidTmp
                 and   t.dptcode   = au.dptcode
                 AND   t.dptcode   = d.dptcode
                 AND   ((au.operid   = l_operId AND   d.miscflags = 1) OR ( d.miscflags = 0 ))
                 AND rownum = 1;
                   ELSE
                      NULL;
                   END IF;
                        totalcount := tskIdCount;
                        IF tskIdCount > 0
                THEN
                     RETURN;
                ELSE
                    raise_application_error(-20001, 'Operator is not authorized to view the task.');
                END IF;
            ELSE
              RETURN;
            END IF;
        END IF;

        /* ocrtskreq */
        SELECT COUNT(*) INTO tskIdCount FROM piprod.ocrtskreq WHERE tskid =  tskidTmp;
        totalcount := tskIdCount;
        IF tskIdCount > 0
        THEN
           SELECT wrkbskt INTO l_wrkbskt FROM piprod.ocrtskreq WHERE tskid = tskidTmp;
           IF TRIM(l_wrkbskt) != TRIM(l_operid) THEN
            -- if any tasks were found then try the secured tasks
            IF isSecurityOn = 1
            THEN
                 SELECT  COUNT(*) INTO tskIdCount
                 FROM piprod.ocrtskreq t, authdpt au,dpt d
                 WHERE t.tskid     = tskidTmp
                 and   t.dptcode   = au.dptcode
                 AND   t.dptcode   = d.dptcode
                 AND   ((au.operid   = l_operId AND   d.miscflags = 1) OR ( d.miscflags = 0 ))
                 AND rownum = 1;
                   ELSE
                      NULL;
                   END IF;
                totalcount := tskIdCount;
                IF tskIdCount > 0
                THEN
                    RETURN;
                ELSE
                    raise_application_error(-20001, 'Operator is not authorized to view the task.');

                END IF;
            ELSE
              RETURN;
            END IF;
        END IF;
        /* at this point it is not found.... clear my parameters and exit */
        tskidList1 := '';
        RETURN;
    END IF; /* if taskId <> ' ' then */
    /* END SEARCH BASED ON A TASKID */

    /* At this point find out if we pass an identifier and if it starts with a _ or %           */
    /* if true then, because the like operator eliminates the use of the identifier index in    */
    /* the tskident table, we eliminate the search from the task tables to speed the search     */
    /* This feature can be globally turned off from the site table at runtime when              */
    /* they change the 'elikeoperatorsearch' to 'N'                                             */
    IF idcode > 0 AND taskStatus <> 'S' AND taskStatus <> 'R' AND
       dptcode = 0 AND tskcode = 0 AND l_workBasket IS NULL AND
       dateCode = 0 AND isSecurityOn = 0
    THEN
        /* Please note that I check buffered conditions first , to avoid going into the db */
        tmpChar := substr(TmpIdentifierStr,0,1);
        /* at this point i need to search based on the tskident only                 */
        /* get identifier fields */
        piprod.GetIdentifierFields( idcode, TmpIdentifierStr, field1, field2, field3, field4, retcode);
        IF  retcode <> 1
        THEN
            raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
            retcode := 0;
            return;
        END IF;

        /* Set CURSOR sqlStatement */
        field1 := RTRIM(field1);
        field2 := RTRIM(field2);
        field3 := RTRIM(field3);
        field4 := RTRIM(field4);
        IF field1 <> ' '
        THEN
            IF INSTR( field1,'_') = 0
            THEN
               tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr1 AND fieldvalue = :bFieldvalue1 ';
               comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr1 AND fieldvalue = :bFieldvalue1 ';
            ELSE
               tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr1 AND fieldvalue LIKE :bFieldvalue1 ';
               comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr1 AND fieldvalue LIKE :bFieldvalue1 ';
            END IF;
        END IF;

        IF field2 <> ' '
        THEN
           IF tskidentSqlStatement <> ' '
           THEN
               fieldnbr := fieldnbr + 1;
               parenthesiscnt := parenthesiscnt + 1;

               tskidentSqlStatement := tskidentSqlStatement || 'AND (tskid IN ( SELECT tskid FROM tskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr2 AND fieldvalue ';
               comptskidentSqlStatement := comptskidentSqlStatement || 'AND (tskid IN ( SELECT tskid FROM comptskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr2 AND fieldvalue ';
               IF INSTR( field2,'_') = 0
               THEN
                   tskidentSqlStatement := tskidentSqlStatement || '= :bFieldvalue2 ';
                   comptskidentSqlStatement := comptskidentSqlStatement || '= :bFieldvalue2 ';
                   tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                   comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
               ELSE
                   tskidentSqlStatement := tskidentSqlStatement || 'LIKE :bFieldvalue2 ';
                   comptskidentSqlStatement := comptskidentSqlStatement || 'LIKE :bFieldvalue2 ';
                   tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                   comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
               END IF;
            ELSE
               IF INSTR( field2,'_') = 0
               THEN
                   tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr2 AND fieldvalue = :bFieldvalue2 ';
                   comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr2 AND fieldvalue = :bFieldvalue2 ';
               ELSE
                   tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr2 AND fieldvalue LIKE :bFieldvalue2 ';
                   comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti  WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr2 AND fieldvalue LIKE :bFieldvalue2 ';
               END IF;
            END IF;
        END IF;

        IF field3 <> ' '
        THEN
           IF tskidentSqlStatement <> ' '
           THEN
               fieldnbr := fieldnbr + 1;
               parenthesiscnt := parenthesiscnt + 1;

               tskidentSqlStatement := tskidentSqlStatement || 'AND (tskid IN ( SELECT tskid FROM tskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr3 AND fieldvalue ';
               comptskidentSqlStatement := comptskidentSqlStatement || 'AND (tskid IN ( SELECT tskid FROM comptskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr3 AND fieldvalue ';
               IF INSTR( field3,'_') = 0
               THEN
                   tskidentSqlStatement := tskidentSqlStatement || '= :bFieldvalue3 ';
                   comptskidentSqlStatement := comptskidentSqlStatement || '= :bFieldvalue3 ';
                   tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                   comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
               ELSE
                   tskidentSqlStatement := tskidentSqlStatement || 'LIKE :bFieldvalue3 ';
                   comptskidentSqlStatement := comptskidentSqlStatement || 'LIKE :bFieldvalue3 ';
                   tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                   comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
               END IF;
            ELSE
               IF INSTR( field3,'_') = 0
               THEN
                   tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr3 AND fieldvalue = :bFieldvalue3 ';
                   comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr3 AND fieldvalue = :bFieldvalue3 ';
               ELSE
                   tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr3 AND fieldvalue LIKE :bFieldvalue3 ';
                   comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr3 AND fieldvalue LIKE :bFieldvalue3 ';
               END IF;
            END IF;
        END IF;

        IF field4 <> ' '
        THEN
           IF tskidentSqlStatement <> ' '
           THEN
               fieldnbr := fieldnbr + 1;
               parenthesiscnt := parenthesiscnt + 1;

               tskidentSqlStatement := tskidentSqlStatement || 'AND (tskid IN ( SELECT tskid FROM tskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr4 AND fieldvalue ';
               comptskidentSqlStatement := comptskidentSqlStatement || 'AND (tskid IN ( SELECT tskid FROM comptskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr4 AND fieldvalue ';
               IF INSTR( field4,'_') = 0
               THEN
                   tskidentSqlStatement := tskidentSqlStatement || '= :bFieldvalue4 ';
                   comptskidentSqlStatement := comptskidentSqlStatement || '= :bFieldvalue4 ';
                   tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                   comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
               ELSE
                   tskidentSqlStatement := tskidentSqlStatement || 'LIKE :bFieldvalue4 ';
                   comptskidentSqlStatement := comptskidentSqlStatement || 'LIKE :bFieldvalue4 ';
                   tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                   comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
               END IF;
           ELSE
              IF INSTR( field4,'_') = 0
               THEN
                   tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr4 AND fieldvalue = :bFieldvalue4 ';
                   comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr4 AND fieldvalue = :bFieldvalue4 ';
               ELSE
                   tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr4 AND fieldvalue LIKE :bFieldvalue3 ';
                   comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode AND fieldnbr = :bFieldnbr4 AND fieldvalue LIKE :bFieldvalue4 ';
               END IF;
           END IF;
        END IF; /*field4*/

        /* second identifier*/
        IF idcode2 > 0
        THEN
            fieldnbr := 1;
            TmpIdentifierStr        := substr(identifier2,0,50);
            piprod.GetIdentifierFields( idcode2, TmpIdentifierStr, field21, field22, field23, field24, retcode);
                IF  retcode <> 1
                THEN
                    raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                    retcode := 0;
                    return;
                END IF;


                /* Set cursor sqlStatement */
                field21 := RTRIM(field21);
                field22 := RTRIM(field22);
                field23 := RTRIM(field23);
                field24 := RTRIM(field24);
                IF field21 <> ' '
                THEN
                   IF tskidentSqlStatement <> ' '
                   THEN
                       parenthesiscnt := parenthesiscnt + 1;

                       tskidentSqlStatement := tskidentSqlStatement || 'OR (tskid IN ( SELECT tskid FROM tskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr21 AND fieldvalue ';
                       comptskidentSqlStatement := comptskidentSqlStatement || 'OR (tskid IN ( SELECT tskid FROM comptskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr21 AND fieldvalue ';
                       IF INSTR( field21,'_') = 0
                       THEN
                           tskidentSqlStatement := tskidentSqlStatement || '= :bFieldvalue21 ';
                           comptskidentSqlStatement := comptskidentSqlStatement || '= :bFieldvalue21 ';
                           IF idcode = idcode2 THEN
                              tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                              comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
                           END IF;
                       ELSE
                           tskidentSqlStatement := tskidentSqlStatement || 'LIKE :bFieldvalue21 ';
                           comptskidentSqlStatement := comptskidentSqlStatement || 'LIKE :bFieldvalue21 ';
                           IF idcode = idcode2 THEN
                              tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                              comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
                           END IF;
                       END IF;
                    ELSE
                        IF INSTR( field21,'_') = 0
                        THEN
                           tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr21 AND fieldvalue = :bFieldvalue21 ';
                           comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr21 AND fieldvalue = :bFieldvalue21 ';
                        ELSE
                           tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr21 AND fieldvalue LIKE :bFieldvalue21 ';
                           comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr21 AND fieldvalue LIKE :bFieldvalue21 ';
                        END IF;
                    END IF;
                END IF;

                IF field22 <> ' '
                THEN
                   IF tskidentSqlStatement <> ' '
                   THEN
                       fieldnbr := fieldnbr + 1;
                       parenthesiscnt := parenthesiscnt + 1;

                       tskidentSqlStatement := tskidentSqlStatement || 'AND (tskid IN ( SELECT tskid FROM tskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr22 AND fieldvalue ';
                       comptskidentSqlStatement := comptskidentSqlStatement || 'OR (tskid IN ( SELECT tskid FROM comptskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr22 AND fieldvalue ';
                       IF INSTR( field22,'_') = 0
                       THEN
                           tskidentSqlStatement := tskidentSqlStatement || '= :bFieldvalue22 ';
                           comptskidentSqlStatement := comptskidentSqlStatement || '= :bFieldvalue22 ';
                           IF idcode = idcode2 THEN
                              tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                              comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
                           END IF;
                       ELSE
                           tskidentSqlStatement := tskidentSqlStatement || 'LIKE :bFieldvalue22 ';
                           comptskidentSqlStatement := comptskidentSqlStatement || 'LIKE :bFieldvalue22 ';
                           IF idcode = idcode2 THEN
                              tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                              comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
                           END IF;
                       END IF;
                    ELSE
                       IF INSTR( field22,'_') = 0
                       THEN
                           tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr22 AND fieldvalue = :bFieldvalue22 ';
                           comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr22 AND fieldvalue = :bFieldvalue22 ';
                       ELSE
                           tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr22 AND fieldvalue LIKE :bFieldvalue22 ';
                           comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr22 AND fieldvalue LIKE :bFieldvalue22 ';
                       END IF;
                    END IF;
                END IF;

                IF field23 <> ' '
                THEN
                   IF tskidentSqlStatement <> ' '
                   THEN
                       fieldnbr := fieldnbr + 1;
                       parenthesiscnt := parenthesiscnt + 1;

                       tskidentSqlStatement := tskidentSqlStatement || 'AND (tskid IN ( SELECT tskid FROM tskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr23 AND fieldvalue ';
                       comptskidentSqlStatement := comptskidentSqlStatement || 'OR (tskid IN ( SELECT tskid FROM comptskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr23 AND fieldvalue ';
                       IF INSTR( field23,'_') = 0
                       THEN
                           tskidentSqlStatement := tskidentSqlStatement || '= :bFieldvalue23 ';
                           comptskidentSqlStatement := comptskidentSqlStatement || '= :bFieldvalue23 ';
                           IF idcode = idcode2 THEN
                              tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                              comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
                           END IF;
                       ELSE
                           tskidentSqlStatement := tskidentSqlStatement || 'LIKE :bFieldvalue23 ';
                           comptskidentSqlStatement := comptskidentSqlStatement || 'LIKE :bFieldvalue23 ';
                           IF idcode = idcode2 THEN
                              tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                              comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
                           END IF;
                       END IF;
                    ELSE
                       IF INSTR( field23,'_') = 0
                       THEN
                           tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr23 AND fieldvalue = :bFieldvalue23 ';
                           comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr23 AND fieldvalue = :bFieldvalue23 ';
                       ELSE
                           tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr23 AND fieldvalue LIKE :bFieldvalue23 ';
                           comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr23 AND fieldvalue LIKE :bFieldvalue23 ';
                       END IF;
                    END IF;
                END IF;

                IF field24 <> ' '
                THEN
                   IF tskidentSqlStatement <> ' '
                   THEN
                       fieldnbr := fieldnbr + 1;
                       parenthesiscnt := parenthesiscnt + 1;

                       tskidentSqlStatement := tskidentSqlStatement || 'AND (tskid IN ( SELECT tskid FROM tskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr24 AND fieldvalue ';
                       comptskidentSqlStatement := comptskidentSqlStatement || 'OR (tskid IN ( SELECT tskid FROM comptskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr24 AND fieldvalue ';
                       IF INSTR( field24,'_') = 0
                       THEN
                           tskidentSqlStatement := tskidentSqlStatement || '= :bFieldvalue24 ';
                           comptskidentSqlStatement := comptskidentSqlStatement || '= :bFieldvalue24 ';
                           IF idcode = idcode2 THEN
                              tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                              comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
                           END IF;
                       ELSE
                           tskidentSqlStatement := tskidentSqlStatement || 'LIKE :bFieldvalue24 ';
                           comptskidentSqlStatement := comptskidentSqlStatement || 'LIKE :bFieldvalue24 ';
                           IF idcode = idcode2 THEN
                              tskidentSqlStatement := tskidentSqlStatement ||' AND (nbrseq = ti.nbrseq) ';
                              comptskidentSqlStatement := comptskidentSqlStatement || ' AND (nbrseq = ti.nbrseq) ';
                           END IF;
                       END IF;
                   ELSE
                      IF INSTR( field24,'_') = 0
                       THEN
                           tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr24 AND fieldvalue = :bFieldvalue24 ';
                           comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr24 AND fieldvalue = :bFieldvalue24 ';
                       ELSE
                           tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr24 AND fieldvalue LIKE :bFieldvalue24 ';
                           comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode2 AND fieldnbr = :bFieldnbr24 AND fieldvalue LIKE :bFieldvalue24 ';
                       END IF;
                   END IF;
                END IF; /*field24*/
        END IF; /* second identifier*/
        /* third identifier*/
        IF idcode3 > 0
        THEN
            fieldnbr := 1;
            TmpIdentifierStr        := substr(identifier3,0,50);
            piprod.GetIdentifierFields( idcode3, TmpIdentifierStr, field31, field32, field33, field34, retcode);
            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            END IF;

            /* Set cursor sqlStatement */
            field31 := RTRIM(field31);
            field32 := RTRIM(field32);
            field33 := RTRIM(field33);
            field34 := RTRIM(field34);
            IF field31 <> ' '
            THEN
               IF tskidentSqlStatement <> ' '
               THEN
                   parenthesiscnt := parenthesiscnt + 1;

                   tskidentSqlStatement := tskidentSqlStatement || 'OR (tskid IN ( SELECT tskid FROM tskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr31 AND fieldvalue ';
                   comptskidentSqlStatement := comptskidentSqlStatement || 'OR (tskid IN ( SELECT tskid FROM comptskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr31 AND fieldvalue ';
                   IF INSTR( field31,'_') = 0
                   THEN
                       tskidentSqlStatement := tskidentSqlStatement || '= :bFieldvalue31 ';
                       comptskidentSqlStatement := comptskidentSqlStatement || '= :bFieldvalue31 ';

                       IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                          IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                          CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                       END IF;
                   ELSE
                       tskidentSqlStatement := tskidentSqlStatement || 'LIKE :bFieldvalue31 ';
                       comptskidentSqlStatement := comptskidentSqlStatement || 'LIKE :bFieldvalue31 ';

                       IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                          IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                          CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                       END IF;

                   END IF;
               ELSE
                   IF INSTR( field31,'_') = 0
                   THEN
                       tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr31 AND fieldvalue = :bFieldvalue31 ';
                       comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr31 AND fieldvalue = :bFieldvalue31 ';
                   ELSE
                       tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr31 AND fieldvalue LIKE :bFieldvalue31 ';
                       comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr31 AND fieldvalue LIKE :bFieldvalue31 ';
                   END IF;
               END IF;
            END IF;

            IF field32 <> ' '
            THEN
               IF tskidentSqlStatement <> ' '
               THEN
                   fieldnbr := fieldnbr + 1;
                   parenthesiscnt := parenthesiscnt + 1;

                   tskidentSqlStatement := tskidentSqlStatement || 'AND (tskid IN ( SELECT tskid FROM tskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr32 AND fieldvalue ';
                   comptskidentSqlStatement := comptskidentSqlStatement || 'OR (tskid IN ( SELECT tskid FROM comptskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr32 AND fieldvalue ';
                   IF INSTR( field32,'_') = 0
                   THEN
                       tskidentSqlStatement := tskidentSqlStatement || '= :bFieldvalue32 ';
                       comptskidentSqlStatement := comptskidentSqlStatement || '= :bFieldvalue32 ';

                       IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                          IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                          CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                       END IF;
                   ELSE
                       tskidentSqlStatement := tskidentSqlStatement || 'LIKE :bFieldvalue32 ';
                       comptskidentSqlStatement := comptskidentSqlStatement || 'LIKE :bFieldvalue32 ';

                       IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                          IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                          CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                       END IF;
                   END IF;
                ELSE
                   IF INSTR( field32,'_') = 0
                   THEN
                       tskidentSqlStatement := 'SELECT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr32 AND fieldvalue = :bFieldvalue32 ';
                       comptskidentSqlStatement := 'SELECT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr32 AND fieldvalue = :bFieldvalue32 ';
                   ELSE
                       tskidentSqlStatement := 'SELECT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr32 AND fieldvalue LIKE :bFieldvalue32 ';
                       comptskidentSqlStatement := 'SELECT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr32 AND fieldvalue LIKE :bFieldvalue32 ';
                   END IF;
                END IF;
            END IF;

            IF field33 <> ' '
            THEN
               IF tskidentSqlStatement <> ' '
               THEN
                   fieldnbr := fieldnbr + 1;
                   parenthesiscnt := parenthesiscnt + 1;

                   tskidentSqlStatement := tskidentSqlStatement || 'AND (tskid IN ( SELECT tskid FROM tskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr33 AND fieldvalue ';
                   comptskidentSqlStatement := comptskidentSqlStatement || 'OR (tskid IN ( SELECT tskid FROM comptskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr33 AND fieldvalue ';
                   IF INSTR( field33,'_') = 0
                   THEN
                       tskidentSqlStatement := tskidentSqlStatement || '= :bFieldvalue33 ';
                       comptskidentSqlStatement := comptskidentSqlStatement || '= :bFieldvalue33 ';

                       IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                          IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                          CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                       END IF;
                   ELSE
                       tskidentSqlStatement := tskidentSqlStatement || 'LIKE :bFieldvalue33 ';
                       comptskidentSqlStatement := comptskidentSqlStatement || 'LIKE :bFieldvalue33 ';

                       IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                          IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                          CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                       END IF;
                   END IF;
                ELSE
                   IF INSTR( field33,'_') = 0
                   THEN
                       tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr33 AND fieldvalue = :bFieldvalue33 ';
                       comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr33 AND fieldvalue = :bFieldvalue33 ';
                   ELSE
                       tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr33 AND fieldvalue LIKE :bFieldvalue33 ';
                       comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr33 AND fieldvalue LIKE :bFieldvalue33 ';
                   END IF;
                END IF;
            END IF;

            IF field34 <> ' '
            THEN
               IF tskidentSqlStatement <> ' '
               THEN
                   fieldnbr := fieldnbr + 1;
                   parenthesiscnt := parenthesiscnt + 1;

                   tskidentSqlStatement := tskidentSqlStatement || 'AND (tskid IN ( SELECT tskid FROM tskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr34 AND fieldvalue ';
                   comptskidentSqlStatement := comptskidentSqlStatement || 'OR (tskid IN ( SELECT tskid FROM comptskident WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr34 AND fieldvalue ';
                   IF INSTR( field34,'_') = 0
                   THEN
                       tskidentSqlStatement := tskidentSqlStatement || '= :bFieldvalue34 ';
                       comptskidentSqlStatement := comptskidentSqlStatement || '= :bFieldvalue34 ';

                       IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                          IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                          CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                       END IF;

                   ELSE
                       tskidentSqlStatement := tskidentSqlStatement || 'LIKE :bFieldvalue34 ';
                       comptskidentSqlStatement := comptskidentSqlStatement || 'LIKE :bFieldvalue34 ';

                       IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                          IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                          CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                       END IF;


                   END IF;
               ELSE
                  IF INSTR( field34,'_') = 0
                   THEN
                       tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr34 AND fieldvalue = :bFieldvalue34 ';
                       comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr34 AND fieldvalue = :bFieldvalue34 ';
                   ELSE
                       tskidentSqlStatement := 'SELECT DISTINCT tskid FROM tskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr34 AND fieldvalue LIKE :bFieldvalue34 ';
                       comptskidentSqlStatement := 'SELECT DISTINCT tskid FROM comptskident ti WHERE tskid  > :l_bTskidFrom AND tskid  < :l_bTskidEnd AND idcode = :bIdcode3 AND fieldnbr = :bFieldnbr34 AND fieldvalue LIKE :bFieldvalue34 ';
                   END IF;
               END IF;
            END IF; /*field34*/
        END IF; /* Third identifier*/

        WHILE (parenthesiscnt > 1)
        LOOP
            tskidentSqlStatement := tskidentSqlStatement || '))';
            comptskidentSqlStatement := comptskidentSqlStatement || '))';
            parenthesiscnt  := parenthesiscnt  - 1;
        END LOOP;

        tskidentSqlStatement := tskidentSqlStatement || ' AND rownum <= :searchMaxCountBnd ';
        comptskidentSqlStatement := comptskidentSqlStatement || ' AND rownum <= :searchMaxCountBnd ';

        /* find out if we are mixing 2 centuries. If true then we need to            */
        /* to split the statement in 2 , having each statement reference one century */
        /* Please note that the Begin Date is Always smaller than the EndDate        */
        tmpStr          := to_char(beginDate);
        tmpTskIdFrom    := 't'||substr(tmpStr,3,7)||'0000';
        tmpStr          := to_char(endDate);
        tmpTskIdEnd     := 't'||substr(tmpStr,3,7)||'zzzz';
        tmpStr          := '';

        /* mixing 2 centuries */
        IF beginDate <= 19991231 and endDate >= 20000101
        THEN
            /* CASE I: taskStatus = O or A */
            IF taskStatus = 'O' or taskStatus = 'A' or taskStatus = 'U'
            THEN
                sqlStatement := tskidentSqlStatement;
                
                IF descending IS NOT NULL AND descending = TRUE THEN
                  sqlStatement := sqlStatement || ' ORDER BY createdate, createtime desc';
                ELSIF descending IS NOT NULL AND descending = FALSE THEN
                  sqlStatement := sqlStatement || ' ORDER BY createdate, createtime asc';
                ELSE
                  sqlStatement := sqlStatement || ' ORDER BY tskid';
                END IF;

                DBMS_OUTPUT.PUT_LINE('Enchanced Search Query is: ' || sqlStatement);

                cur := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE(cur,rtrim(sqlStatement), DBMS_SQL.NATIVE);
                /* binding necessary variables */
                DBMS_SQL.BIND_VARIABLE(cur, 'l_bTskidFrom', tmpTskIdFrom);
                DBMS_SQL.BIND_VARIABLE(cur, 'l_bTskidEnd', 't991231zzzz');
                DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode', idcodeBnd);

                IF idcode2 > 0
                THEN
                    DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode2',  idcodeBnd2);
                END IF;

                IF idcode3 > 0
                THEN
                    DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode3',  idcodeBnd3);
                END IF;

                IF field1 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr1', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue1', field1);
                END IF;

                IF field2 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr2', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue2', field2);
                END IF;

                IF field3 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr3', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue3', field3);
                END IF;

                IF field4 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr4', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue4', field4);
                END IF;

                IF field21 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr21', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue21', field21);
                END IF;

                IF field22 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr22', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue22', field22);
                END IF;

                IF field23 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr23', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue23', field23);
                END IF;

                IF field24 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr24', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue24', field24);
                END IF;

                IF field31 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr31', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue31', field31);
                END IF;

                IF field32 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr32', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue32', field32);
                END IF;

                IF field33 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr33', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue33', field33);
                END IF;

                IF field34 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr34', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue34', field34);
                END IF;

                DBMS_SQL.BIND_VARIABLE(cur, 'searchMaxCountBnd', searchMaxCountBnd);
                /* end binding necessary variables */

                DBMS_SQL.DEFINE_COLUMN (cur, 1, tmp_tskid, 11);
                rows_inserted  := DBMS_SQL.EXECUTE (cur);

                WHILE DBMS_SQL.FETCH_ROWS (cur) <> 0
                LOOP
                    DBMS_SQL.COLUMN_VALUE (cur, 1, tmp_tskid);

                    INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (substr(tmp_tskid,0,11));
          COMMIT;

                    tskIdCount1 := tskIdCount+1;
                    --IF maxtaskidCount <> 0 and tskIdCount > maxtaskidCount
                    --THEN
                    --    DBMS_SQL.CLOSE_CURSOR(cur);
                    --    raise_application_error(-20001, 'Too many tasks returned (' || maxtaskidCount || '). Please create a smaller search criteria.');
                    --    return;
                    --END IF;
                END LOOP; /* while DBMS_SQL.FETCH_ROWS (cur) <> 0 */
                DBMS_SQL.CLOSE_CURSOR(cur);
                totalcount := tskIdCount1;
            END IF; /* end if taskStatus = O or A */

            /* CASE II: taskStatus = C or A */
            IF taskStatus = 'C' or taskStatus = 'A'
            THEN
                sqlStatement := comptskidentSqlStatement;
                IF descending IS NOT NULL AND descending = TRUE THEN
                  sqlStatement := sqlStatement || ' ORDER BY createdate, createtime desc';
                ELSIF descending IS NOT NULL AND descending = FALSE THEN
                  sqlStatement := sqlStatement || ' ORDER BY createdate, createtime asc';
                ELSE
                  sqlStatement := sqlStatement || ' ORDER BY tskid';
                END IF;

                DBMS_OUTPUT.PUT_LINE('Enchanced Search Query is: ' || sqlStatement);

                cur := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE(cur,rtrim(sqlStatement), DBMS_SQL.NATIVE);

                /* binding necessary variables */
                DBMS_SQL.BIND_VARIABLE(cur, 'l_bTskidFrom', tmpTskIdFrom);
                DBMS_SQL.BIND_VARIABLE(cur, 'l_bTskidEnd', 't991231zzzz');
                DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode', idcodeBnd);

                IF idcode2 > 0
                THEN
                    DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode2',  idcodeBnd2);
                END IF;

                IF idcode3 > 0
                THEN
                    DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode3',  idcodeBnd3);
                END IF;

                IF field1 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr1', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue1', field1);
                END IF;

                IF field2 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr2', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue2', field2);
                END IF;

                IF field3 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr3', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue3', field3);
                END IF;

                IF field4 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr4', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue4', field4);
                END IF;

                IF field21 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr21', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue21', field21);
                END IF;

                IF field22 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr22', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue22', field22);
                END IF;

                IF field23 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr23', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue23', field23);
                END IF;

                IF field24 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr24', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue24', field24);
                END IF;

                IF field31 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr31', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue31', field31);
                END IF;

                IF field32 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr32', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue32', field32);
                END IF;

                IF field33 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr33', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue33', field33);
                END IF;

                IF field34 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr34', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue34', field34);
                END IF;

                DBMS_SQL.BIND_VARIABLE(cur, 'searchMaxCountBnd', searchMaxCountBnd);
                /* end binding necessary variables */

                DBMS_SQL.DEFINE_COLUMN (cur, 1, tmp_tskid, 11);
                rows_inserted  := DBMS_SQL.EXECUTE (cur);

                WHILE DBMS_SQL.FETCH_ROWS (cur) <> 0
                LOOP
                    DBMS_SQL.COLUMN_VALUE (cur, 1, tmp_tskid);


                    INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (tmp_tskid);
          COMMIT;
                    tskIdCount1 := tskIdCount+1;
                    --IF maxtaskidCount <> 0 and tskIdCount > maxtaskidCount
                    --THEN
                    --    DBMS_SQL.CLOSE_CURSOR(cur);
                    --    raise_application_error(-20001, 'Too many tasks returned (' || maxtaskidCount ||'). Please create a smaller search criteria.');
                    --    return;
                    --END IF;
                END LOOP; /* while DBMS_SQL.FETCH_ROWS (cur) <> 0 */
                DBMS_SQL.CLOSE_CURSOR(cur);
                totalcount := tskIdCount1;
            END IF; /* end if taskStatus = C or A */

            IF taskStatus = 'O' or taskStatus = 'A' or taskStatus = 'U'
            THEN
                sqlStatement := tskidentSqlStatement;
                IF descending IS NOT NULL AND descending = TRUE THEN
                  sqlStatement := sqlStatement || ' ORDER BY createdate, createtime desc';
                ELSIF descending IS NOT NULL AND descending = FALSE THEN
                  sqlStatement := sqlStatement || ' ORDER BY createdate, createtime asc';
                ELSE
                  sqlStatement := sqlStatement || ' ORDER BY tskid';
                END IF;

                DBMS_OUTPUT.PUT_LINE('Enchanced Search Query is: ' || sqlStatement);

                cur := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE(cur,rtrim(sqlStatement), DBMS_SQL.NATIVE);

                sqlStatement := tskidentSqlStatement;
                IF descending IS NOT NULL AND descending = TRUE THEN
                  sqlStatement := sqlStatement || ' ORDER BY createdate, createtime desc';
                ELSIF descending IS NOT NULL AND descending = FALSE THEN
                  sqlStatement := sqlStatement || ' ORDER BY createdate, createtime asc';
                ELSE
                  sqlStatement := sqlStatement || ' ORDER BY tskid';
                END IF;

                cur := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE(cur,rtrim(sqlStatement), DBMS_SQL.NATIVE);

                /* binding necessary variables */
                DBMS_SQL.BIND_VARIABLE(cur, 'l_bTskidFrom', 't0001010000');
                DBMS_SQL.BIND_VARIABLE(cur, 'l_bTskidEnd', tmpTskIdEnd);
                DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode', idcodeBnd);

                IF idcode2 > 0
                THEN
                    DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode2',  idcodeBnd2);
                END IF;

                IF idcode3 > 0
                THEN
                    DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode3',  idcodeBnd3);
                END IF;

                IF field1 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr1', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue1', field1);
                END IF;

                IF field2 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr2', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue2', field2);
                END IF;

                IF field3 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr3', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue3', field3);
                END IF;

                IF field4 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr4', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue4', field4);
                END IF;

                IF field21 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr21', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue21', field21);
                END IF;

                IF field22 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr22', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue22', field22);
                END IF;

                IF field23 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr23', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue23', field23);
                END IF;

                IF field24 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr24', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue24', field24);
                END IF;

                IF field31 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr31', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue31', field31);
                END IF;

                IF field32 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr32', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue32', field32);
                END IF;

                IF field33 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr33', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue33', field33);
                END IF;

                IF field34 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr34', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue34', field34);
                END IF;

                DBMS_SQL.BIND_VARIABLE(cur, 'searchMaxCountBnd', searchMaxCountBnd);
                /* end binding necessary variables */

                DBMS_SQL.DEFINE_COLUMN (cur, 1, tmp_tskid, 11);
                rows_inserted  := DBMS_SQL.EXECUTE (cur);

                WHILE DBMS_SQL.FETCH_ROWS (cur) <> 0
                LOOP
                    DBMS_SQL.COLUMN_VALUE (cur, 1, tmp_tskid);


                    INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (tmp_tskid);
          COMMIT;
                    tskIdCount1 := tskIdCount+1;
                    --IF maxtaskidCount <> 0 and tskIdCount > maxtaskidCount
                    --THEN
                    --    DBMS_SQL.CLOSE_CURSOR(cur);
                    --    raise_application_error(-20001, 'Too many tasks returned (' || maxtaskidCount || '). Please create a smaller search criteria.');
                    --    return;
                    --END IF;
                END LOOP; /* while DBMS_SQL.FETCH_ROWS (cur) <> 0 */
                DBMS_SQL.CLOSE_CURSOR(cur);
                totalcount := tskIdCount1;
            END IF; /* end if taskStatus O or A */

            IF taskStatus = 'C' or taskStatus = 'A'
            THEN
                sqlStatement := comptskidentSqlStatement;
                IF descending IS NOT NULL AND descending = TRUE THEN
                  sqlStatement := sqlStatement || ' ORDER BY createdate, createtime desc';
                ELSIF descending IS NOT NULL AND descending = FALSE THEN
                  sqlStatement := sqlStatement || ' ORDER BY createdate, createtime asc';
                ELSE
                  sqlStatement := sqlStatement || ' ORDER BY tskid';
                END IF;

                DBMS_OUTPUT.PUT_LINE('Enchanced Search Query is: ' || sqlStatement);

                cur := DBMS_SQL.OPEN_CURSOR;
                DBMS_SQL.PARSE(cur,rtrim(sqlStatement), DBMS_SQL.NATIVE);

                /* binding necessary variables */
                DBMS_SQL.BIND_VARIABLE(cur, 'l_bTskidFrom', 't0001010000');
                DBMS_SQL.BIND_VARIABLE(cur, 'l_bTskidEnd', tmpTskIdEnd);
                DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode', idcodeBnd);

                IF idcode2 > 0
                THEN
                    DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode2',  idcodeBnd2);
                END IF;

                IF idcode3 > 0
                THEN
                    DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode3',  idcodeBnd3);
                END IF;

                IF field1 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr1', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue1', field1);
                END IF;

                IF field2 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr2', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue2', field2);
                END IF;

                IF field3 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr3', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue3', field3);
                END IF;

                IF field4 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr4', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue4', field4);
                END IF;

                IF field21 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr21', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue21', field21);
                END IF;

                IF field22 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr22', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue22', field22);
                END IF;

                IF field23 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr23', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue23', field23);
                END IF;

                IF field24 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr24', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue24', field24);
                END IF;

                IF field31 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr31', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue31', field31);
                END IF;

                IF field32 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr32', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue32', field32);
                END IF;

                IF field33 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr33', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue33', field33);
                END IF;

                IF field34 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr34', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue34', field34);
                END IF;

                DBMS_SQL.BIND_VARIABLE(cur, 'searchMaxCountBnd', searchMaxCountBnd);
                /* end binding necessary variables */

                DBMS_SQL.DEFINE_COLUMN (cur, 1, tmp_tskid, 11);
                rows_inserted  := DBMS_SQL.EXECUTE (cur);

                WHILE DBMS_SQL.FETCH_ROWS (cur) <> 0
                LOOP
                    DBMS_SQL.COLUMN_VALUE (cur, 1, tmp_tskid);


                    INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (tmp_tskid);
            COMMIT;

                    tskIdCount1 := tskIdCount+1;
                    --IF maxtaskidCount <> 0 and tskIdCount > maxtaskidCount
                    --THEN
                    --    DBMS_SQL.CLOSE_CURSOR(cur);
                    --    raise_application_error(-20001, 'Too many tasks returned (' || maxtaskidCount || '). Please create a smaller search criteria.');
                    --    return;
                    --END IF;
                END LOOP; /* while DBMS_SQL.FETCH_ROWS (cur) <> 0 */
                DBMS_SQL.CLOSE_CURSOR(cur);
            END IF; /* end if taskStatus O or A */
            totalcount := tskIdCount1;
            goto Totaltskidcount;
        END IF;/*end if mixing 2 centuries : beginDate <= 19991231 and endDate >=20000101*/

        /* at this point the search does not include 2 centuries... search as usual */

        /* if taskStatus 'O' or 'A'*/
        IF taskStatus = 'O' or taskStatus = 'A' or taskStatus = 'U'
        THEN
            sqlStatement := tskidentSqlStatement;
            IF descending IS NOT NULL AND descending = TRUE THEN
              sqlStatement := sqlStatement || ' ORDER BY createdate, createtime desc';
            ELSIF descending IS NOT NULL AND descending = FALSE THEN
              sqlStatement := sqlStatement || ' ORDER BY createdate, createtime asc';
            ELSE
              sqlStatement := sqlStatement || ' ORDER BY tskid';
            END IF;

            DBMS_OUTPUT.PUT_LINE('Enchanced Search Query is: ' || sqlStatement);

            cur := DBMS_SQL.OPEN_CURSOR;
            DBMS_SQL.PARSE(cur,rtrim(sqlStatement), DBMS_SQL.NATIVE);
            /* binding necessary variables */
            DBMS_SQL.BIND_VARIABLE(cur, 'l_bTskidFrom', tmpTskIdFrom);
            DBMS_SQL.BIND_VARIABLE(cur, 'l_bTskidEnd', tmpTskIdEnd);
            DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode', idcodeBnd);

            IF idcode2 > 0
            THEN
                DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode2',  idcodeBnd2);
            END IF;

            IF idcode3 > 0
            THEN
                DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode3',  idcodeBnd3);
            END IF;

            IF field1 <> ' '
            THEN
                fieldnbr := 1;
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr1', fieldnbr);
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue1', field1);
            END IF;

            IF field2 <> ' '
            THEN
               fieldnbr := 2;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr2', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue2', field2);
            END IF;

            IF field3 <> ' '
            THEN
               fieldnbr := 3;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr3', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue3', field3);
            END IF;

            IF field4 <> ' '
            THEN
               fieldnbr := 4;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr4', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue4', field4);
            END IF;

            IF field21 <> ' '
            THEN
               fieldnbr := 1;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr21', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue21', field21);
            END IF;

            IF field22 <> ' '
            THEN
               fieldnbr := 2;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr22', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue22', field22);
            END IF;

            IF field23 <> ' '
            THEN
               fieldnbr := 3;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr23', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue23', field23);
            END IF;

            IF field24 <> ' '
            THEN
               fieldnbr := 4;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr24', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue24', field24);
            END IF;

            IF field31 <> ' '
            THEN
                fieldnbr := 1;
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr31', fieldnbr);
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue31', field31);
            END IF;

            IF field32 <> ' '
            THEN
               fieldnbr := 2;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr32', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue32', field32);
            END IF;

            IF field33 <> ' '
            THEN
               fieldnbr := 3;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr33', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue33', field33);
            END IF;

            IF field34 <> ' '
            THEN
               fieldnbr := 4;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr34', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue34', field34);
            END IF;

            DBMS_SQL.BIND_VARIABLE(cur, 'searchMaxCountBnd', searchMaxCountBnd);
            /* end binding necessary variables */

            DBMS_SQL.DEFINE_COLUMN (cur, 1, tmp_tskid, 11);
            rows_inserted  := DBMS_SQL.EXECUTE (cur);


            WHILE DBMS_SQL.FETCH_ROWS (cur) <> 0
            --AND cur <= searchmaxrowcount
            LOOP
                DBMS_SQL.COLUMN_VALUE (cur, 1, tmp_tskid);


                INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (tmp_tskid);
            COMMIT;
                tskIdCount := tskIdCount+1;
                IF tskidcount = searchmaxrowcount THEN
                goto Totaltskidcount;
                --ELSIF tskIdCount > maxtaskidCount
                --THEN
                --    DBMS_SQL.CLOSE_CURSOR(cur);
                --    raise_application_error(-20001, 'Too many tasks returned (' || maxtaskidCount || '). Please create a smaller search criteria.');
                --    return;
                END IF;
              END LOOP; /* while DBMS_SQL.FETCH_ROWS (cur) <> 0 */
            DBMS_SQL.CLOSE_CURSOR(cur);
            --goto donelabel;
         END IF; /* end if taskStatus = 'O' or 'A'*/

        /* taskStatus = 'C' or 'A'*/
        IF taskStatus = 'C' or taskStatus = 'A'
        THEN
            sqlStatement := comptskidentSqlStatement;
            IF descending IS NOT NULL AND descending = TRUE THEN
              sqlStatement := sqlStatement || ' ORDER BY createdate, createtime desc';
            ELSIF descending IS NOT NULL AND descending = FALSE THEN
              sqlStatement := sqlStatement || ' ORDER BY createdate, createtime asc';
            ELSE
              sqlStatement := sqlStatement || ' ORDER BY tskid';
            END IF;

            DBMS_OUTPUT.PUT_LINE('Enchanced Search Query is: ' || sqlStatement);

            cur := DBMS_SQL.OPEN_CURSOR;
            DBMS_SQL.PARSE(cur,rtrim(sqlStatement), DBMS_SQL.NATIVE);
            /* binding necessary variables */
            DBMS_SQL.BIND_VARIABLE(cur, 'l_bTskidFrom', tmpTskIdFrom);
            DBMS_SQL.BIND_VARIABLE(cur, 'l_bTskidEnd', tmpTskIdEnd);
            DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode', idcodeBnd);

            IF idcode2 > 0
            THEN
                DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode2',  idcodeBnd2);
            END IF;

            IF idcode3 > 0
            THEN
                DBMS_SQL.BIND_VARIABLE(cur, 'bIdcode3',  idcodeBnd3);
            END IF;

            IF field1 <> ' '
            THEN
                fieldnbr := 1;
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr1', fieldnbr);
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue1', field1);
            END IF;

            IF field2 <> ' '
            THEN
               fieldnbr := 2;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr2', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue2', field2);
            END IF;

            IF field3 <> ' '
            THEN
               fieldnbr := 3;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr3', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue3', field3);
            END IF;

            IF field4 <> ' '
            THEN
               fieldnbr := 4;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr4', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue4', field4);
            END IF;

            IF field21 <> ' '
            THEN
                fieldnbr := 1;
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr21', fieldnbr);
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue21', field21);
            END IF;

            IF field22 <> ' '
            THEN
               fieldnbr := 2;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr22', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue22', field22);
            END IF;

            IF field23 <> ' '
            THEN
               fieldnbr := 3;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr23', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue23', field23);
            END IF;

            IF field24 <> ' '
            THEN
               fieldnbr := 4;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr24', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue24', field24);
            END IF;

            IF field31 <> ' '
            THEN
                fieldnbr := 1;
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr31', fieldnbr);
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue31', field31);
            END IF;

            IF field32 <> ' '
            THEN
               fieldnbr := 2;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr32', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue32', field32);
            END IF;

            IF field33 <> ' '
            THEN
               fieldnbr := 3;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr33', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue33', field33);
            END IF;

            IF field34 <> ' '
            THEN
               fieldnbr := 4;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr34', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue34', field34);
            END IF;

            DBMS_SQL.BIND_VARIABLE(cur, 'searchMaxCountBnd', searchMaxCountBnd);
            /* end binding necessary variables */

            DBMS_SQL.DEFINE_COLUMN (cur, 1, tmp_tskid, 11);
            rows_inserted  := DBMS_SQL.EXECUTE (cur);

            WHILE DBMS_SQL.FETCH_ROWS (cur) <> 0
            --AND cur <= searchmaxrowcount
            LOOP
                DBMS_SQL.COLUMN_VALUE (cur, 1, tmp_tskid);


                INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (tmp_tskid);
            COMMIT;
                tskIdCount := tskIdCount+1;
                IF tskidcount = searchmaxrowcount THEN
                goto Totaltskidcount;
                --ELSIF maxtaskidCount <> 0 and tskIdCount > maxtaskidCount
                --THEN
                --    DBMS_SQL.CLOSE_CURSOR(cur);
                --    raise_application_error(-20001, 'Too many tasks returned (' || maxtaskidCount || '). Please create a smaller search criteria.');
                --    return;
                END IF;
              END LOOP; /* while DBMS_SQL.FETCH_ROWS (cur) <> 0 */
            DBMS_SQL.CLOSE_CURSOR(cur);
        END IF; /*end if taskStatus = 'C' or 'A'*/

        /* at this point im done exit */
        goto Totaltskidcount;
        /*END IF;/*tmpChar = '_' or tmpChar = '_'*/
    END IF; /* idcode > 0*/



    /* build the where clauses */
    /* date and time where clause are always necessary */

   IF beginDate = endDate THEN
        IF dateCode = 1 THEN
            dateTimeWhereClause := ' WHERE ((tr.datercvd = :bDateBnd ) and (tr.timercvd >= :bTimeBnd ) and (tr.timercvd <= :eTimeBnd ))';
        ELSE
            dateTimeWhereClause := ' WHERE ((tr.createdate = :bDateBnd ) and (tr.createtime >= :bTimeBnd ) and (tr.createtime <= :eTimeBnd ))';
        END IF;
    ELSE
        IF dateCode = 1 THEN
            dateTimeWhereClause := ' WHERE (((tr.datercvd > :bDateBnd ) and (tr.datercvd < :eDateBnd )) or ((tr.datercvd = :bDateBnd ) and (tr.timercvd >= :bTimeBnd )) or ((tr.datercvd = :eDateBnd ) and (tr.timercvd <= :eTimeBnd )))';
        ELSE
            dateTimeWhereClause := ' WHERE (((tr.createdate > :bDateBnd ) AND (tr.createdate < :eDateBnd )) OR ((tr.createdate = :bDateBnd ) AND (tr.createtime >= :bTimeBnd )) OR ((tr.createdate = :eDateBnd ) AND (tr.createtime <= :eTimeBnd )))';
        END IF;
    END IF; /* IF beginDate = endDate then */

    /* l_workBasket */
    IF l_workBasket <> ' ' THEN
        IF substr(TmpWorkBasketStr,0,1)='^' THEN
            /* empty workbasket is checked */
            bEmptyWorkBasket := 1;
            WorkBasketWhereClause := ' AND (SUBSTR(tr.wrkbskt,0,1) IN ('||chr(39)||chr(39)||','||chr(39)||' '||chr(39)||',';
            FOR tmpcount IN 0..8 LOOP
                WorkBasketWhereClause := WorkBasketWhereClause||chr(39)||TO_CHAR(tmpcount)||chr(39)||',';
            END LOOP;

            WorkBasketWhereClause := WorkBasketWhereClause||chr(39)||'9'||chr(39)||'))';
        ELSE
            WorkBasketWhereClause :=' AND (tr.wrkbskt = :TmpWorkBasketStr)';
        END IF;
    END IF; /* if workBasket <>' ' then */

    /* dptcode */
    IF dptcode > 0 THEN
        IF ruleBasedEngine = 'Y' THEN
           DepartmentWhereClause := ' AND (tr.dptcode+0 = :dptBnd)';
        ELSE
           DepartmentWhereClause := ' AND (tr.dptcode = :dptBnd)';
        END IF;
    END IF; /* if dptcode > 0 then */

    /* tskcode */
    IF tskcode > 0 THEN
        IF ruleBasedEngine = 'Y' THEN
            TaskTypeWhereClause := ' AND (tr.tskcode+0 = :tskBnd)';
        ELSE
            TaskTypeWhereClause := ' AND (tr.tskcode = :tskBnd)';
        END IF;
    END IF; /* if tskcode > 0 then */

    /* actcode */
    IF actcode > 0 THEN
        IF ruleBasedEngine = 'Y' THEN
            ActionWhereClause := ' AND (tr.actcode+0 = :actBnd)';
        ELSE
            ActionWhereClause := ' AND (tr.actcode = :actBnd)';
        END IF;
    END IF; /* if actcode > 0 then */

    parenthesiscnt := 1;

    IF (idcode > 0 AND idcode2 > 0 AND idcode = idcode2 and (idcode = 7 or idcode = 8 or idcode = 40))
    THEN
        IF (idcode3 > 0)
        THEN
            DBMS_OUTPUT.PUT_LINE('Idcode1 and Idcode2 match, Idcode3 populated. Idcode values idcode: ' || idcode || ' idcode2 ' || idcode2 || ' idcode3 ' || idcode3);

            /* get identifier fields */
            TmpIdentifierStr        := substr(identifier,0,50);
            piprod.GetIdentifierFields( idcode, TmpIdentifierStr, field1, field2, field3, field4, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            end IF;

            field1 := RTRIM(field1);
            field2 := RTRIM(field2);
            field3 := RTRIM(field3);
            field4 := RTRIM(field4);

            TmpIdentifierStr        := substr(identifier2,0,50);
            piprod.GetIdentifierFields( idcode2, TmpIdentifierStr, field21, field22, field23, field24, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            end IF;

            field21 := RTRIM(field21);
            field22 := RTRIM(field22);
            field23 := RTRIM(field23);
            field24 := RTRIM(field24);

            TmpIdentifierStr        := substr(identifier3,0,50);
            piprod.GetIdentifierFields( idcode3, TmpIdentifierStr, field31, field32, field33, field34, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            end IF;

            field31 := RTRIM(field31);
            field32 := RTRIM(field32);
            field33 := RTRIM(field33);
            field34 := RTRIM(field34);



            IF ruleBasedEngine = 'Y' THEN
                IdentifierWhereClause := ' and (((((tr.tskid in ( SELECT tskid FROM tskident WHERE  (idcode+0 = :idcodeBnd3) and (fieldnbr = :bFieldnbr31) and (fieldvalue = :bFieldvalue31) )))) and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd2) and (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr1) and (fieldnbr = :bFieldnbr21) and (fieldvalue in (:bFieldvalue1,:bFieldvalue21))))';
                CompIdentifierWhereClause := ' and (((((tr.tskid in ( SELECT tskid FROM comptskident WHERE  (idcode+0 = :idcodeBnd3) and (fieldnbr = :bFieldnbr31) and (fieldvalue = :bFieldvalue31) )))) and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd2) and (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr1) and (fieldnbr = :bFieldnbr21) and (fieldvalue in (:bFieldvalue1,:bFieldvalue21))))';
            ELSE
                IdentifierWhereClause := ' and (((((tr.tskid in ( SELECT tskid FROM tskident WHERE  (idcode = :idcodeBnd3) and (fieldnbr = :bFieldnbr31) and (fieldvalue = :bFieldvalue31) )))) and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd2) and (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr1) and (fieldnbr = :bFieldnbr21) and (fieldvalue in (:bFieldvalue1,:bFieldvalue21))))';
                CompIdentifierWhereClause := ' and (((((tr.tskid in ( SELECT tskid FROM comptskident WHERE  (idcode = :idcodeBnd3) and (fieldnbr = :bFieldnbr31) and (fieldvalue = :bFieldvalue31) )))) and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd2) and (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr1) and (fieldnbr = :bFieldnbr21) and (fieldvalue in (:bFieldvalue1,:bFieldvalue21))))';
            END IF;


            DBMS_OUTPUT.PUT_LINE('Idcode1 and Idcode2 match, Idcode3 populated. Idcode values idcode: ' || idcode || ' idcode2 ' || idcode2 || ' idcode3 ' || idcode3);
        ELSE
            DBMS_OUTPUT.PUT_LINE('Idcode1 and Idcode2 match, Idcode3 not populated. Idcode values idcode: ' || idcode || ' idcode2 ' || idcode2 || ' idcode3 ' || idcode3);

            /* First Identifier */
            /* rule based engine */
            IF ruleBasedEngine = 'Y' THEN
                IdentifierWhereClause := ' and ((tr.tskid = ti.tskid) and (idcode+0 = :idcodeBnd) and (idcode+0 = :idcodeBnd2)';
                CompIdentifierWhereClause := ' and ((tr.tskid = ti.tskid) and (idcode+0 = :idcodeBnd) and (idcode+0 = :idcodeBnd2)';
            ELSE
                IdentifierWhereClause := ' and ((tr.tskid = ti.tskid) and (idcode = :idcodeBnd) and (idcode = :idcodeBnd2)';
                CompIdentifierWhereClause := ' and ((tr.tskid = ti.tskid) and (idcode = :idcodeBnd) and (idcode = :idcodeBnd2)';
            END IF;

            /* get identifier fields */
            TmpIdentifierStr        := substr(identifier,0,50);
            piprod.GetIdentifierFields( idcode, TmpIdentifierStr, field1, field2, field3, field4, retcode);

            TmpIdentifierStr        := substr(identifier2,0,50);
            piprod.GetIdentifierFields( idcode2, TmpIdentifierStr, field21, field22, field23, field24, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            end IF;

            field1 := RTRIM(field1);
            field2 := RTRIM(field2);
            field3 := RTRIM(field3);
            field4 := RTRIM(field4);

            field21 := RTRIM(field21);
            field22 := RTRIM(field22);
            field23 := RTRIM(field23);
            field24 := RTRIM(field24);

            fieldnbr := 0;

            IF field1 <> ' '
            THEN
                fieldnbr := fieldnbr + 1;
                IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr1) and (fieldnbr = :bFieldnbr21) and (fieldvalue ';
                CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr1) and (fieldnbr = :bFieldnbr21) and (fieldvalue ';

                IF INSTR( field1,'_') = 0
                THEN
                   IdentifierWhereClause := IdentifierWhereClause || 'IN (:bFieldvalue1, :bFieldvalue21)) ';

                   IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'IN (:bFieldvalue1, :bFieldvalue21)) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'IN (:bFieldvalue1, :bFieldvalue21)) ';
                   IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'IN (:bFieldvalue1, :bFieldvalue21)) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                END IF;
            END IF;

            
        

             /* Closing out the parentheses for the identifier grouping */
            IdentifierWhereClause := IdentifierWhereClause || ')';
            CompIdentifierWhereClause := CompIdentifierWhereClause || ')';

            
        
            


        END IF;

    ELSIF (idcode > 0 AND idcode3 > 0 AND idcode = idcode3 and (idcode = 7 or idcode = 8 or idcode = 40))
    THEN
        IF (idcode2 > 0)
        THEN
            DBMS_OUTPUT.PUT_LINE('Idcode1 and Idcode3 match, Idcode2 populated. Idcode values idcode: ' || idcode || ' idcode2 ' || idcode2 || ' idcode3 ' || idcode3);


             /* get identifier fields */
            TmpIdentifierStr        := substr(identifier,0,50);
            piprod.GetIdentifierFields( idcode, TmpIdentifierStr, field1, field2, field3, field4, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            end IF;

            field1 := RTRIM(field1);
            field2 := RTRIM(field2);
            field3 := RTRIM(field3);
            field4 := RTRIM(field4);

            TmpIdentifierStr        := substr(identifier2,0,50);
            piprod.GetIdentifierFields( idcode2, TmpIdentifierStr, field21, field22, field23, field24, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            end IF;

            field21 := RTRIM(field21);
            field22 := RTRIM(field22);
            field23 := RTRIM(field23);
            field24 := RTRIM(field24);

            TmpIdentifierStr        := substr(identifier3,0,50);
            piprod.GetIdentifierFields( idcode3, TmpIdentifierStr, field31, field32, field33, field34, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            end IF;

            field31 := RTRIM(field31);
            field32 := RTRIM(field32);
            field33 := RTRIM(field33);
            field34 := RTRIM(field34);



            IF ruleBasedEngine = 'Y' THEN
                IdentifierWhereClause := ' and (((((tr.tskid in ( SELECT tskid FROM tskident WHERE  (idcode+0 = :idcodeBnd2) and (fieldnbr = :bFieldnbr21) and (fieldvalue = :bFieldvalue21) )))) and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd3) and (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr1) and (fieldnbr = :bFieldnbr31) and (fieldvalue in (:bFieldvalue1,:bFieldvalue31))))';
                CompIdentifierWhereClause := ' and (((((tr.tskid in ( SELECT tskid FROM comptskident WHERE  (idcode+0 = :idcodeBnd2) and (fieldnbr = :bFieldnbr21) and (fieldvalue = :bFieldvalue21) )))) and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd3) and (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr1) and (fieldnbr = :bFieldnbr31) and (fieldvalue in (:bFieldvalue1,:bFieldvalue31))))';
            ELSE
                IdentifierWhereClause := ' and (((((tr.tskid in ( SELECT tskid FROM tskident WHERE  (idcode = :idcodeBnd2) and (fieldnbr = :bFieldnbr21) and (fieldvalue = :bFieldvalue21) )))) and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd3) and (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr1) and (fieldnbr = :bFieldnbr31) and (fieldvalue in (:bFieldvalue1,:bFieldvalue31))))';
                CompIdentifierWhereClause := ' and (((((tr.tskid in ( SELECT tskid FROM comptskident WHERE  (idcode = :idcodeBnd2) and (fieldnbr = :bFieldnbr21) and (fieldvalue = :bFieldvalue21) )))) and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd3) and (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr1) and (fieldnbr = :bFieldnbr31) and (fieldvalue in (:bFieldvalue1,:bFieldvalue31))))';
            END IF;

            

        ELSE
            DBMS_OUTPUT.PUT_LINE('Idcode1 and Idcode3 match, Idcode2 not populated. Idcode values idcode: ' || idcode || ' idcode2 ' || idcode2 || ' idcode3 ' || idcode3);


            /* This branch works- however this condition should likely never occur; EXPAG doesn't support gaps in it's identifier list normally;
            so for instance there shouldn't be an identifier3 if there's not an identifier 2.*/

            /* First Identifier */
            /* rule based engine */
            IF ruleBasedEngine = 'Y' THEN
                IdentifierWhereClause := ' and ((tr.tskid = ti.tskid) and (idcode+0 = :idcodeBnd) and (idcode+0 = :idcodeBnd3)';
                CompIdentifierWhereClause := ' and ((tr.tskid = ti.tskid) and (idcode+0 = :idcodeBnd) and (idcode+0 = :idcodeBnd3)';
            ELSE
                IdentifierWhereClause := ' and ((tr.tskid = ti.tskid) and (idcode = :idcodeBnd) and (idcode = :idcodeBnd3)';
                CompIdentifierWhereClause := ' and ((tr.tskid = ti.tskid) and (idcode = :idcodeBnd) and (idcode = :idcodeBnd3)';
            END IF;

            /* get identifier fields */
            TmpIdentifierStr        := substr(identifier,0,50);
            piprod.GetIdentifierFields( idcode, TmpIdentifierStr, field1, field2, field3, field4, retcode);

            TmpIdentifierStr        := substr(identifier3,0,50);
            piprod.GetIdentifierFields( idcode3, TmpIdentifierStr, field31, field32, field33, field34, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            end IF;

            field1 := RTRIM(field1);
            field2 := RTRIM(field2);
            field3 := RTRIM(field3);
            field4 := RTRIM(field4);

            field31 := RTRIM(field31);
            field32 := RTRIM(field32);
            field33 := RTRIM(field33);
            field34 := RTRIM(field34);

            fieldnbr := 0;

            IF field1 <> ' '
            THEN
                fieldnbr := fieldnbr + 1;
                IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr1) and (fieldnbr = :bFieldnbr31) and (fieldvalue ';
                CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr1) and (fieldnbr = :bFieldnbr31) and (fieldvalue ';

                IF INSTR( field1,'_') = 0
                THEN
                   IdentifierWhereClause := IdentifierWhereClause || 'IN (:bFieldvalue1, :bFieldvalue31)) ';

                   IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'IN (:bFieldvalue1, :bFieldvalue31)) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'IN (:bFieldvalue1, :bFieldvalue31)) ';
                   IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'IN (:bFieldvalue1, :bFieldvalue31)) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                END IF;
            END IF;

            
        

             /* Closing out the parentheses for the identifier grouping */
            IdentifierWhereClause := IdentifierWhereClause || ')';
            CompIdentifierWhereClause := CompIdentifierWhereClause || ')';

        END IF;
    ELSIF (idcode2 > 0 AND idcode3 > 0 AND idcode2 = idcode3 and (idcode2 = 7 or idcode2 = 8 or idcode2 = 40))
    THEN
        IF (idcode > 0)
        THEN
            DBMS_OUTPUT.PUT_LINE('Idcode2 and Idcode3 match, Idcode1 populated. Idcode values idcode: ' || idcode || ' idcode2 ' || idcode2 || ' idcode3 ' || idcode3);
           
           /* get identifier fields */
            TmpIdentifierStr        := substr(identifier,0,50);
            piprod.GetIdentifierFields( idcode, TmpIdentifierStr, field1, field2, field3, field4, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            end IF;

            field1 := RTRIM(field1);
            field2 := RTRIM(field2);
            field3 := RTRIM(field3);
            field4 := RTRIM(field4);

            TmpIdentifierStr        := substr(identifier2,0,50);
            piprod.GetIdentifierFields( idcode2, TmpIdentifierStr, field21, field22, field23, field24, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            end IF;

            field21 := RTRIM(field21);
            field22 := RTRIM(field22);
            field23 := RTRIM(field23);
            field24 := RTRIM(field24);

            TmpIdentifierStr        := substr(identifier3,0,50);
            piprod.GetIdentifierFields( idcode3, TmpIdentifierStr, field31, field32, field33, field34, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            end IF;

            field31 := RTRIM(field31);
            field32 := RTRIM(field32);
            field33 := RTRIM(field33);
            field34 := RTRIM(field34);



            IF ruleBasedEngine = 'Y' THEN
                IdentifierWhereClause := ' and (((((tr.tskid in ( SELECT tskid FROM tskident WHERE  (idcode+0 = :idcodeBnd) and (fieldnbr = :bFieldnbr1) and (fieldvalue = :bFieldvalue1) )))) and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd2) and (idcode = :idcodeBnd3) and (fieldnbr = :bFieldnbr31) and (fieldnbr = :bFieldnbr21) and (fieldvalue in (:bFieldvalue31,:bFieldvalue21))))';
                CompIdentifierWhereClause := ' and (((((tr.tskid in ( SELECT tskid FROM comptskident WHERE  (idcode+0 = :idcodeBnd) and (fieldnbr = :bFieldnbr1) and (fieldvalue = :bFieldvalue1) )))) and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd2) and (idcode = :idcodeBnd3) and (fieldnbr = :bFieldnbr31) and (fieldnbr = :bFieldnbr21) and (fieldvalue in (:bFieldvalue31,:bFieldvalue21))))';
            ELSE
                IdentifierWhereClause := ' and (((((tr.tskid in ( SELECT tskid FROM tskident WHERE  (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr1) and (fieldvalue = :bFieldvalue1) )))) and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd2) and (idcode = :idcodeBnd3) and (fieldnbr = :bFieldnbr31) and (fieldnbr = :bFieldnbr21) and (fieldvalue in (:bFieldvalue31,:bFieldvalue21))))';
                CompIdentifierWhereClause := ' and (((((tr.tskid in ( SELECT tskid FROM comptskident WHERE  (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr1) and (fieldvalue = :bFieldvalue1) )))) and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd2) and (idcode = :idcodeBnd3) and (fieldnbr = :bFieldnbr31) and (fieldnbr = :bFieldnbr21) and (fieldvalue in (:bFieldvalue31,:bFieldvalue21))))';
            END IF;





            




        ELSE
            DBMS_OUTPUT.PUT_LINE('Idcode2 and Idcode3 match, Idcode1 not populated. Idcode values idcode: ' || idcode || ' idcode2 ' || idcode2 || ' idcode3 ' || idcode3);

            /*This condition should never occur- an empty first identifier while others are populated is simply not supported by EXPAG */

            

        END IF;
    ELSE

        IF idcode > 0
        THEN
            /* rule based engine */
            IF ruleBasedEngine = 'Y' THEN
                IdentifierWhereClause := ' and (tr.tskid = ti.tskid) and (idcode+0 = :idcodeBnd)';
                CompIdentifierWhereClause := ' and (tr.tskid = ti.tskid) and (idcode+0 = :idcodeBnd)';
            ELSE
                IdentifierWhereClause := ' and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd)';
                CompIdentifierWhereClause := ' and (tr.tskid = ti.tskid) and (idcode = :idcodeBnd)';
            END IF;

            /* get identifier fields */
            TmpIdentifierStr        := substr(identifier,0,50);
            piprod.GetIdentifierFields( idcode, TmpIdentifierStr, field1, field2, field3, field4, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            end IF;

            field1 := RTRIM(field1);
            field2 := RTRIM(field2);
            field3 := RTRIM(field3);
            field4 := RTRIM(field4);

            fieldnbr := 0;

            IF field1 <> ' '
            THEN
                fieldnbr := fieldnbr + 1;
                IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr1) and (fieldvalue ';
                CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr1) and (fieldvalue ';

                IF INSTR( field1,'_') = 0
                THEN
                   IdentifierWhereClause := IdentifierWhereClause || '= :bFieldvalue1) ';

                   IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || '= :bFieldvalue1) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'like :bFieldvalue1) ';
                   IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'like :bFieldvalue1) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                END IF;
            END IF;

            IF field2 <> ' '
            THEN
               IF fieldnbr <> 0
               THEN
                   parenthesiscnt := parenthesiscnt + 1;
                   IdentifierWhereClause := IdentifierWhereClause || 'and (ti.tskid in ( SELECT tskid FROM tskident WHERE (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr2) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'and (ti.tskid in ( SELECT tskid FROM comptskident WHERE (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr2) and (fieldvalue ';
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr2) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr2) and (fieldvalue ';
               END IF;
               IF INSTR( field2,'_') = 0
               THEN
                   IdentifierWhereClause := IdentifierWhereClause || '= :bFieldvalue2) ';
                   IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || '= :bFieldvalue2) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'like :bFieldvalue2) ';
                   IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'like :bFieldvalue2) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
               END IF;
               fieldnbr := fieldnbr + 1;
            END IF;

            IF field3 <> ' '
            THEN
               IF fieldnbr <> 0
               THEN
                   parenthesiscnt := parenthesiscnt + 1;
                   IdentifierWhereClause := IdentifierWhereClause || 'and (ti.tskid in ( SELECT tskid FROM tskident WHERE (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr3) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'and (ti.tskid in ( SELECT tskid FROM comptskident WHERE (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr3) and (fieldvalue ';
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr3) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr3) and (fieldvalue ';
               END IF;
               IF INSTR( field3,'_') = 0
               THEN
                   IdentifierWhereClause := IdentifierWhereClause || '= :bFieldvalue3) ';
                   IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || '= :bFieldvalue3) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'like :bFieldvalue3) ';
                   IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'like :bFieldvalue3) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
               END IF;
               fieldnbr := fieldnbr + 1;
            END IF;

            IF field4 <> ' '
            THEN
               IF fieldnbr <> 0
               THEN
                   parenthesiscnt := parenthesiscnt + 1;
                   IdentifierWhereClause := IdentifierWhereClause || 'and (ti.tskid in ( SELECT tskid FROM tskident WHERE (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr4) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'and (ti.tskid in ( SELECT tskid FROM comptskident WHERE (idcode = :idcodeBnd) and (fieldnbr = :bFieldnbr4) and (fieldvalue ';
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr4) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr4) and (fieldvalue ';
               END IF;
               IF INSTR( field4,'_') = 0
               THEN
                   IdentifierWhereClause := IdentifierWhereClause || '= :bFieldvalue4) ';
                   IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || '= :bFieldvalue4) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'LIKE :bFieldvalue4) ';
                   IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'LIKE :bFieldvalue4) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
               END IF;
               fieldnbr := fieldnbr + 1;
            END IF;
        END IF; /* we have an identifier criteria... */

        IF idcode2 > 0
        THEN
            /* rule based engine */
            IF ruleBasedEngine = 'Y' THEN
                IdentifierWhereClause := IdentifierWhereClause || ' and (ti.tskid in ( SELECT tskid FROM tskident WHERE (idcode+0 = :idcodeBnd2)';
                CompIdentifierWhereClause := CompIdentifierWhereClause || ' and (ti.tskid in ( SELECT tskid FROM comptskident WHERE (idcode+0 = :idcodeBnd2)';
            ELSE
                IdentifierWhereClause := IdentifierWhereClause || ' and (ti.tskid in ( SELECT tskid FROM tskident WHERE (idcode = :idcodeBnd2)';
                CompIdentifierWhereClause := CompIdentifierWhereClause || ' and (ti.tskid in ( SELECT tskid FROM comptskident WHERE  (idcode = :idcodeBnd2)';
            END IF;

            TmpIdentifierStr        := substr(identifier2,0,50);
            /* get identifier fields */
            piprod.GetIdentifierFields( idcode2, TmpIdentifierStr, field21, field22, field23, field24, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            END IF;

            field21 := RTRIM(field21);
            field22 := RTRIM(field22);
            field23 := RTRIM(field23);
            field24 := RTRIM(field24);

            fieldnbr := 0;

            IF field21 <> ' '
            THEN
                fieldnbr := fieldnbr + 1;
                parenthesiscnt := parenthesiscnt + 1;
                IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr21) and (fieldvalue ';
                CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr21) and (fieldvalue ';

                IF INSTR( field21,'_') = 0
                THEN
                   IdentifierWhereClause := IdentifierWhereClause || '= :bFieldvalue21) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || '= :bFieldvalue21) ';
                   IF idcode = idcode2 THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
                ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'like :bFieldvalue21) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'like :bFieldvalue21) ';
                   IF idcode = idcode2 THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
                END IF;
            END IF;

            IF field22 <> ' '
            THEN
               IF fieldnbr <> 0
               THEN
                   IdentifierWhereClause := IdentifierWhereClause || 'and (ti.tskid in ( SELECT tskid FROM tskident WHERE (idcode = :idcodeBnd2) and (fieldnbr = :bFieldnbr22) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'and (ti.tskid in ( SELECT tskid FROM comptskident WHERE (idcode = :idcodeBnd2) and (fieldnbr = :bFieldnbr22) and (fieldvalue ';
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr22) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr22) and (fieldvalue ';
               END IF;
               IF INSTR( field22,'_') = 0
               THEN
                   IdentifierWhereClause := IdentifierWhereClause || '= :bFieldvalue22) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || '= :bFieldvalue22) ';
                   IF idcode = idcode2 THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'like :bFieldvalue22) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'like :bFieldvalue22) ';
                   IF idcode = idcode2 THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
               END IF;
               parenthesiscnt := parenthesiscnt + 1;
               fieldnbr := fieldnbr + 1;
            END IF;

            IF field23 <> ' '
            THEN
               IF fieldnbr <> 0
               THEN
                   IdentifierWhereClause := IdentifierWhereClause || 'and (ti.tskid in ( SELECT tskid FROM tskident WHERE (idcode = :idcodeBnd2) and (fieldnbr = :bFieldnbr23) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'and (ti.tskid in ( SELECT tskid FROM comptskident WHERE (idcode = :idcodeBnd2) and (fieldnbr = :bFieldnbr23) and (fieldvalue ';
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr23) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr23) and (fieldvalue ';
               END IF;
               IF INSTR( field23,'_') = 0
               THEN
                  IdentifierWhereClause := IdentifierWhereClause || '= :bFieldvalue23) ';
                  CompIdentifierWhereClause := CompIdentifierWhereClause || '= :bFieldvalue23) ';
                  IF idcode = idcode2 THEN
                     IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                     CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                  END IF;
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'like :bFieldvalue23) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'like :bFieldvalue23) ';
                   IF idcode = idcode2 THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
               END IF;
               fieldnbr := fieldnbr + 1;
               parenthesiscnt := parenthesiscnt + 1;
            END IF;

            IF field24 <> ' '
            THEN
               IF fieldnbr <> 0
               THEN
                   IdentifierWhereClause := IdentifierWhereClause || 'and (ti.tskid in ( SELECT tskid FROM tskident WHERE (idcode = :idcodeBnd2) and (fieldnbr = :bFieldnbr24) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'and (ti.tskid in ( SELECT tskid FROM comptskident WHERE (idcode = :idcodeBnd2) and (fieldnbr = :bFieldnbr24) and (fieldvalue ';
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr24) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr24) and (fieldvalue ';
               END IF;
               IF INSTR( field24,'_') = 0
               THEN
                   IdentifierWhereClause := IdentifierWhereClause || '= :bFieldvalue24) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || '= :bFieldvalue24) ';
                   IF idcode = idcode2 THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'LIKE :bFieldvalue24) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'LIKE :bFieldvalue24) ';
                   IF idcode = idcode2 THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
               END IF;
               fieldnbr := fieldnbr + 1;
               parenthesiscnt := parenthesiscnt + 1;
            END IF;
        END IF; /* we have second identifier criteria... */

        IF idcode3 > 0
        THEN
            /* rule based engine */
            IF ruleBasedEngine = 'Y' THEN
                IdentifierWhereClause := IdentifierWhereClause || ' and (ti.tskid in ( SELECT tskid FROM tskident WHERE (idcode+0 = :idcodeBnd3)';
                CompIdentifierWhereClause := CompIdentifierWhereClause || ' and (ti.tskid in ( SELECT tskid FROM comptskident WHERE (idcode+0 = :idcodeBnd3)';
            ELSE
                IdentifierWhereClause := IdentifierWhereClause || ' and (ti.tskid in ( SELECT tskid FROM tskident WHERE (idcode = :idcodeBnd3)';
                CompIdentifierWhereClause := CompIdentifierWhereClause || ' and (ti.tskid in ( SELECT tskid FROM comptskident WHERE  (idcode = :idcodeBnd3)';
            END IF;

             TmpIdentifierStr        := substr(identifier3,0,50);
            /* get identifier fields */
            piprod.GetIdentifierFields( idcode3, TmpIdentifierStr, field31, field32, field33, field34, retcode);

            IF  retcode <> 1
            THEN
                raise_application_error(-20001, 'Cannot GetIdentifierFields. Please check the identifier.');
                retcode := 0;
                return;
            END IF;

            field31 := RTRIM(field31);
            field32 := RTRIM(field32);
            field33 := RTRIM(field33);
            field34 := RTRIM(field34);

            fieldnbr := 0;

            IF field31 <> ' '
            THEN
                fieldnbr := fieldnbr + 1;
                parenthesiscnt := parenthesiscnt + 1;
                IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr31) and (fieldvalue ';
                CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr31) and (fieldvalue ';

                IF INSTR( field31,'_') = 0
                THEN
                   IdentifierWhereClause := IdentifierWhereClause || '= :bFieldvalue31) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || '= :bFieldvalue31) ';
                   IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
                ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'like :bFieldvalue31) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'like :bFieldvalue31) ';
                   IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
                END IF;
            END IF;

            IF field32 <> ' '
            THEN
               IF fieldnbr <> 0
               THEN
                   IdentifierWhereClause := IdentifierWhereClause || ' and (ti.tskid in ( SELECT tskid FROM tskident WHERE (idcode = :idcodeBnd3) and (fieldnbr = :bFieldnbr32) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'and (ti.tskid in ( SELECT tskid FROM comptskident WHERE (idcode = :idcodeBnd3) and (fieldnbr = :bFieldnbr32) and (fieldvalue ';
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr32) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr32) and (fieldvalue ';
               END IF;
               IF INSTR( field32,'_') = 0
               THEN
                  IdentifierWhereClause := IdentifierWhereClause || '= :bFieldvalue32) ';
                  CompIdentifierWhereClause := CompIdentifierWhereClause || '= :bFieldvalue32) ';
                  IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                     IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                     CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                  END IF;
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'like :bFieldvalue32) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'like :bFieldvalue32) ';
                  IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
               END IF;
               fieldnbr := fieldnbr + 1;
               parenthesiscnt := parenthesiscnt + 1;
            END IF;

            IF field33 <> ' '
            THEN
               IF fieldnbr <> 0
               THEN
                   IdentifierWhereClause := IdentifierWhereClause || ' and (ti.tskid in ( SELECT tskid FROM tskident WHERE (idcode = :idcodeBnd3) and (fieldnbr = :bFieldnbr33) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || ' and (ti.tskid in ( SELECT tskid FROM comptskident WHERE (idcode = :idcodeBnd3) and (fieldnbr = :bFieldnbr33) and (fieldvalue ';

               ELSE
                   IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr33) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr33) and (fieldvalue ';
               END IF;
               IF INSTR( field33,'_') = 0
               THEN
                   IdentifierWhereClause := IdentifierWhereClause || '= :bFieldvalue33) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || '= :bFieldvalue33) ';
                   IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'like :bFieldvalue33) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'like :bFieldvalue33) ';
                   IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
               END IF;
               fieldnbr := fieldnbr + 1;
               parenthesiscnt := parenthesiscnt + 1;
            END IF;

            IF field34 <> ' '
            THEN
               IF fieldnbr <> 0
               THEN
                   IdentifierWhereClause := IdentifierWhereClause || ' and (ti.tskid in ( SELECT tskid FROM tskident WHERE (idcode = :idcodeBnd3) and (fieldnbr = :bFieldnbr34) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || ' and (ti.tskid in ( SELECT tskid FROM comptskident WHERE (idcode = :idcodeBnd3) and (fieldnbr = :bFieldnbr34) and (fieldvalue ';

               ELSE
                   IdentifierWhereClause := IdentifierWhereClause ||' and (fieldnbr = :bFieldnbr34) and (fieldvalue ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause||' and (fieldnbr = :bFieldnbr34) and (fieldvalue ';
               END IF;

               IF INSTR( field34,'_') = 0
               THEN
                   IdentifierWhereClause := IdentifierWhereClause || '= :bFieldvalue34) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || '= :bFieldvalue34) ';
                   IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
               ELSE
                   IdentifierWhereClause := IdentifierWhereClause || 'LIKE :bFieldvalue34) ';
                   CompIdentifierWhereClause := CompIdentifierWhereClause || 'LIKE :bFieldvalue34) ';
                   IF (idcode = idcode3) OR (idcode2 = idcode3) THEN
                      IdentifierWhereClause := IdentifierWhereClause ||' AND (nbrseq = ti.nbrseq) ';
                      CompIdentifierWhereClause := CompIdentifierWhereClause || ' AND (nbrseq = ti.nbrseq) ';
                   END IF;
               END IF;
               fieldnbr := fieldnbr + 1;
               parenthesiscnt := parenthesiscnt + 1;
            END IF;
        END IF; /* we have third identifier criteria... */
    END IF;

    WHILE (parenthesiscnt > 1)
    LOOP
        IdentifierWhereClause := IdentifierWhereClause || '))';
        CompIdentifierWhereClause := CompIdentifierWhereClause || '))';
        parenthesiscnt := parenthesiscnt - 1;
    END LOOP;

    RowNumWhereClause := ' AND ROWNUM <= :searchMaxCountBnd';

    /* MAIN LOOP, Loops 5 times one for each task table , tskreq, qatskreq, comptsk,susptsk, ocrtskreq */
    /* go through all the 5 tables in this order and find the tasks */
    tableCount := 0;
    tmpStr := '';
    WHILE tableCount <= 5
    LOOP
        WhereClause := '';
        sqlStatement:= '';

        /* note that dateTimeWhereClause , RowNumWhereClause is always valid the rest may be blank */
        WhereClause := dateTimeWhereClause;

        IF ((taskStatus = 'O' or taskStatus = 'A' or taskStatus = 'U') and tableCount = tskreqTableSearchOrder ) THEN
            /* tskreq */
            IF idcode > 0 THEN
                IF descending IS NOT NULL THEN
                  sqlStatement := 'SELECT DISTINCT (tr.tskid), tr.createdate, tr.createtime FROM tskreq tr, tskident ti ';
                ELSE
                  sqlStatement := 'SELECT DISTINCT (tr.tskid) FROM tskreq tr, tskident ti ';
                END IF;
            ELSE
                sqlStatement := 'SELECT tskid FROM tskreq tr ';
            END IF;
        ELSIF ((taskStatus = 'O' or taskStatus = 'A' or taskStatus = 'U') AND tableCount = qatskreqTableSearchOrder ) THEN
            /* qatskreq */
            IF idcode > 0 THEN
              IF descending IS NOT NULL THEN
                sqlStatement := 'SELECT DISTINCT (tr.tskid), tr.createdate, tr.createtime FROM qatskreq tr, tskident ti ';
              ELSE
                sqlStatement := 'SELECT DISTINCT (tr.tskid) FROM qatskreq tr, tskident ti ';
              END IF;
            ELSE
                sqlStatement := 'SELECT tskid FROM qatskreq tr ';
            END IF;
        ELSIF ((taskStatus = 'C' OR taskStatus = 'A') AND actcode = 0 AND  tableCount = comptskTableSearchOrder ) THEN
            /* comptsk */
            IF TmpWorkBasketStr <> ' ' THEN
                GOTO skipTableLabel;
            END IF;
            IF idcode > 0 THEN
              IF descending IS NOT NULL THEN
                sqlStatement := 'SELECT DISTINCT (tr.tskid), tr.createdate, tr.createtime FROM comptsk tr, comptskident ti ';
              ELSE
                sqlStatement := 'SELECT DISTINCT (tr.tskid) FROM comptsk tr, comptskident ti ';
              END IF;
            ELSE
                sqlStatement := 'SELECT tskid FROM comptsk tr ';
            END IF;
        ELSIF ((taskStatus = 'S' OR taskStatus = 'A' or taskStatus = 'U') AND tableCount = susptskreqTableSearchOrder ) THEN
            /* susptskreq */
            IF idcode > 0 THEN
              IF descending IS NOT NULL THEN
                sqlStatement := 'SELECT DISTINCT (tr.tskid), tr.createdate, tr.createtime FROM susptskreq tr, tskident ti ';
              ELSE
                sqlStatement := 'SELECT DISTINCT (tr.tskid) FROM susptskreq tr, tskident ti ';
              END IF;
            ELSE
                sqlStatement := 'SELECT tskid FROM susptskreq tr ';
            END IF;
        ELSIF ((taskStatus = 'R' OR taskStatus = 'A' OR taskStatus = 'O' or taskStatus = 'U') AND tableCount = ocrtskreqTableSearchOrder) THEN
            /* ocrtskreq */
            IF idcode > 0 THEN
              IF descending IS NOT NULL THEN
                sqlStatement := 'SELECT DISTINCT (tr.tskid), tr.createdate, tr.createtime FROM ocrtskreq tr, tskident ti ';
              ELSE
                sqlStatement := 'SELECT DISTINCT (tr.tskid) FROM ocrtskreq tr, tskident ti ';
              END IF;
            ELSE
                sqlStatement := 'SELECT tskid FROM ocrtskreq tr ';
            END IF;
        ELSIF ((taskStatus = 'E' OR taskStatus = 'A' OR taskStatus = 'O' or taskStatus = 'U') AND tableCount = evalrulereqTableSearchOrder) THEN
           /* evalrulereq */
       IF idcode > 0 THEN
        IF descending IS NOT NULL THEN
          sqlStatement := 'SELECT DISTINCT (tr.tskid), tr.createdate, tr.createtime FROM evalrulereq tr, tskident ti ';
        ELSE
          sqlStatement := 'SELECT DISTINCT (tr.tskid) FROM evalrulereq tr, tskident ti ';
        END IF;
       ELSE
          sqlStatement := 'SELECT tskid FROM evalrulereq tr ';
           END IF;
        ELSE
            /* no search for this table check the next table */
            goto skipTableLabel;
        END IF;

--        IF isSecurityOn = 1
--        THEN
--            sqlStatement := sqlStatement || ', authdpt ';
--            WhereClause := WhereClause || ' and (tr.dptcode = authdpt.dptcode and authdpt.operid = :l_operId)';
--          SELECT miscflags
--          INTO l_miscflags
--    FROM dpt WHERE dptcode = l_dptcode;
--         IF l_miscflags=0 THEN
--              sqlStatement := sqlStatement;
--              WhereClause := WhereClause;
--         ELSE
              --sqlStatement := sqlStatement || ', (select d.dptcode ,d.miscflags from authdpt au,dpt d where au.dptcode=d.dptcode and au.operid= :l_operId and d.miscflags in (1,0)) d';
              --WhereClause := WhereClause || ' and ((tr.dptcode = d.dptcode  and  d.miscflags=1) OR d.miscflags=0)';
--              sqlStatement := sqlStatement || ', (select d.dptcode from authdpt au,dpt d where au.dptcode=d.dptcode and au.operid= :l_operId) d';
--              WhereClause := WhereClause || ' and (tr.dptcode = d.dptcode)';
--         END IF;
--        ELSE
--           sqlStatement := sqlStatement;
--           WhereClause := WhereClause;
--        END IF;

        if tableCount <> comptskTableSearchOrder then
            WhereClause := WhereClause||WorkBasketWhereClause;
            WhereClause := WhereClause||DepartmentWhereClause;
            WhereClause := WhereClause||TaskTypeWhereClause;
            WhereClause := WhereClause||ActionWhereClause;
            WhereClause := WhereClause||IdentifierWhereClause;
        else
            WhereClause := WhereClause||DepartmentWhereClause;
            WhereClause := WhereClause||TaskTypeWhereClause;
            WhereClause := WhereClause||CompIdentifierWhereClause;
        end if;

        WhereClause := WhereClause||RowNumWhereClause;

        sqlStatement := sqlStatement||WhereClause;
        IF descending IS NOT NULL AND descending = TRUE THEN
          sqlStatement := sqlStatement || ' ORDER BY createdate, createtime desc';
        ELSIF descending IS NOT NULL AND descending = FALSE THEN  
          sqlStatement := sqlStatement || ' ORDER BY createdate, createtime asc';
        ELSE
          sqlStatement := sqlStatement || ' ORDER BY tskid';
        END IF;

        DBMS_OUTPUT.PUT_LINE('Enchanced Search Query is: ' || sqlStatement);

        cur := DBMS_SQL.OPEN_CURSOR;
        DBMS_SQL.PARSE(cur,rtrim(sqlStatement), DBMS_SQL.NATIVE);

        /* at this point I need to bind the parameters... */
        /* date bind and row num is always necessary     */
        DBMS_SQL.BIND_VARIABLE(cur, 'bDateBnd', bDateBnd);
        DBMS_SQL.BIND_VARIABLE(cur, 'bTimeBnd', bTimeBnd);
        IF beginDate <> endDate THEN
            DBMS_SQL.BIND_VARIABLE(cur, 'eDateBnd', eDateBnd);
        END IF;
        DBMS_SQL.BIND_VARIABLE(cur, 'eTimeBnd', eTimeBnd);

        DBMS_SQL.BIND_VARIABLE(cur, 'searchMaxCountBnd', searchMaxCountBnd);

--        IF isSecurityOn = 1 THEN
--          --IF l_miscflags <> 0 THEN
--            DBMS_SQL.BIND_VARIABLE(cur, 'l_operId', l_operId);
--          --END IF;
--        END IF;

        if l_workBasket <>' ' and tableCount <> comptskTableSearchOrder and bEmptyWorkBasket = 0 then
            DBMS_SQL.BIND_VARIABLE(cur, 'TmpWorkBasketStr', TmpWorkBasketStr);
        end if;
        if dptcode > 0 then
            DBMS_SQL.BIND_VARIABLE(cur, 'dptBnd', dptBnd);
        end if;
        if tskcode > 0 then
            DBMS_SQL.BIND_VARIABLE(cur, 'tskBnd', tskBnd);
        end if;
        if actcode > 0 and tableCount <> comptskTableSearchOrder then
            DBMS_SQL.BIND_VARIABLE(cur, 'actBnd', actBnd);
        end if;

        IF idcode > 0
        THEN
            DBMS_OUTPUT.PUT_LINE('Binding idcodeBnd ' || idcodeBnd);
            DBMS_SQL.BIND_VARIABLE(cur, 'idcodeBnd', idcodeBnd);

            IF field1 <> ' '
            THEN
                fieldnbr := 1;
                DBMS_OUTPUT.PUT_LINE('Binding bFieldnbr1 ' || fieldnbr);
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr1', fieldnbr);
                DBMS_OUTPUT.PUT_LINE('Binding bFieldvalue1 ' || field1);
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue1', field1);
            END IF;

            IF field2 <> ' '
            THEN
               fieldnbr := 2;
               DBMS_OUTPUT.PUT_LINE('Binding bFieldnbr2 ' || fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr2', fieldnbr);
               DBMS_OUTPUT.PUT_LINE('Binding bFieldvalue2 ' || field2);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue2', field2);
            END IF;

            IF field3 <> ' '
            THEN
               fieldnbr := 3;
               DBMS_OUTPUT.PUT_LINE('Binding bFieldnbr3 ' || fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr3', fieldnbr);
               DBMS_OUTPUT.PUT_LINE('Binding bFieldvalue3 ' || field3);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue3', field3);
            END IF;

            IF field4 <> ' '
            THEN
               fieldnbr := 4;
               DBMS_OUTPUT.PUT_LINE('Binding bFieldnbr4 ' || fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr4', fieldnbr);
               DBMS_OUTPUT.PUT_LINE('Binding bFieldvalue4 ' || field4);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue4', field4);
            END IF;
        END IF;
        /* end binding necessary variables */

        IF idcode2 > 0
        THEN
            DBMS_OUTPUT.PUT_LINE('Binding idcodeBnd2 ' || idcodeBnd2);
            DBMS_SQL.BIND_VARIABLE(cur, 'idcodeBnd2', idcodeBnd2);

            DBMS_OUTPUT.PUT_LINE('Field21 value ' || field21);
            IF field21 <> ' '
            THEN
                fieldnbr := 1;
                DBMS_OUTPUT.PUT_LINE('Binding bFieldnbr21 ' || fieldnbr);
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr21', fieldnbr);
                DBMS_OUTPUT.PUT_LINE('Binding bFieldvalue21 ' || field21);
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue21', field21);
            END IF;

            IF field22 <> ' '
            THEN
               fieldnbr := 2;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr22', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue22', field22);
            END IF;

            IF field23 <> ' '
            THEN
               fieldnbr := 3;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr23', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue23', field23);
            END IF;

            IF field24 <> ' '
            THEN
               fieldnbr := 4;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr24', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue24', field24);
            END IF;
        END IF;
        /* end binding necessary variables */

        IF idcode3 > 0
        THEN
            DBMS_OUTPUT.PUT_LINE('Binding idcodeBnd3 ' || idcodeBnd3);
            DBMS_SQL.BIND_VARIABLE(cur, 'idcodeBnd3', idcodeBnd3);

            DBMS_OUTPUT.PUT_LINE('Field31 ' || field31);
            IF field31 <> ' '
            THEN
                fieldnbr := 1;
                DBMS_OUTPUT.PUT_LINE('Binding bFieldnbr31 ' || fieldnbr);
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr31', fieldnbr);
                DBMS_OUTPUT.PUT_LINE('Binding bFieldvalue31 ' || field31);
                DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue31', field31);
            END IF;

            IF field32 <> ' '
            THEN
               fieldnbr := 2;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr32', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue32', field32);
            END IF;

            IF field33 <> ' '
            THEN
               fieldnbr := 3;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr33', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue33', field33);
            END IF;

            IF field34 <> ' '
            THEN
               fieldnbr := 4;
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr34', fieldnbr);
               DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue34', field34);
            END IF;
        END IF;
        /* end binding necessary variables */

        DBMS_SQL.DEFINE_COLUMN (cur, 1, tmp_tskid, 11);
        rows_inserted  := DBMS_SQL.EXECUTE (cur);

        WHILE DBMS_SQL.FETCH_ROWS (cur) <> 0
        --AND cur <= searchmaxrowcount
        LOOP
            DBMS_SQL.COLUMN_VALUE (cur, 1, tmp_tskid);
            tskIdCount := tskIdCount+1;
            --IF maxtaskidCount <> 0 and tskIdCount > maxtaskidCount THEN
            --    raise_application_error(-20001, 'Too many tasks returned (' || maxtaskidCount || '). Please create a smaller search criteria.');
            --END IF;
            IF(tskIdCount > searchmaxCountBnd) THEN
                DBMS_SQL.CLOSE_CURSOR(cur);
                --searchMaxCountBnd := tskIdCount+1;
                goto Totaltskidcount;
            END IF;
            /**************************************************************************/
            -- dpt security check
              IF isSecurityOn = 1 THEN
                 SELECT dptcode,wrkbskt INTO l_miscdptcode,l_wrkbskt
                 FROM
                 (
                  SELECT dptcode,wrkbskt FROM tskreq      WHERE tskid = tmp_tskid
              UNION ALL
              SELECT dptcode,wrkbskt FROM qatskreq    WHERE tskid = tmp_tskid
              UNION ALL
              SELECT dptcode,wrkbskt FROM susptskreq  WHERE tskid = tmp_tskid
              UNION ALL
              SELECT dptcode,wrkbskt FROM ocrtskreq   WHERE tskid = tmp_tskid
              UNION ALL
              SELECT dptcode,wrkbskt FROM evalrulereq   WHERE tskid = tmp_tskid
              UNION ALL
              SELECT dptcode,' '     FROM comptsk     WHERE tskid = tmp_tskid
             );

                  l_dptcount := 0;
               IF l_wrkbskt != l_operid THEN

                  SELECT miscflags INTO l_miscflags FROM dpt WHERE
                  dptcode =l_miscdptcode;

                  IF l_miscflags = 0 THEN

                       INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (substr(tmp_tskid,0,11));
              COMMIT;
                  END IF;
                  IF l_miscflags = 1 THEN
                     BEGIN
             SELECT 1 INTO l_dptcount
             FROM authdpt au,dpt d
             WHERE au.dptcode = d.dptcode
             AND   au.dptcode=l_miscdptcode
             AND   au.operid= RPAD(l_operid,8,' ')
             AND   d.active = 'Y';
                         EXCEPTION
                            WHEN NO_DATA_FOUND THEN
                                  l_notauthorized := l_notauthorized + 1;
                            WHEN OTHERS THEN
                 RAISE_APPLICATION_ERROR(-20002, 'There are too many rows found in authdpt table.');
                     END;
                  END IF;

                  IF l_dptcount = 1 THEN

                    l_tskfound := l_tskfound + 1;
                    INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (substr(tmp_tskid,0,11));
            COMMIT;
                  ELSE
                    l_tskfound := l_tskfound+1;
                  END IF;
               ELSE      -----IF l_wrkbskt != l_operid THEN

                  l_tskfound := l_tskfound + 1;
                  INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (substr(tmp_tskid,0,11));
          COMMIT;
               END IF;
           ELSE    ---  IF isSecurityOn = 1 THEN

                l_tskfound := l_tskfound + 1;
                INSERT INTO pimitek.tiaa_task_id_cache
                        (tskid)
                        VALUES
                        (substr(tmp_tskid,0,11));
            COMMIT;
       END IF;


            /**************************************************************************/
            --tmpStr :=  tmpStr||','||substr(tmp_tskid,0,11);

        END LOOP; /* while DBMS_SQL.FETCH_ROWS (cur) <> 0 */
        DBMS_SQL.CLOSE_CURSOR(cur);
        <<skipTableLabel>>
        tableCount  := tableCount + 1;
        END LOOP; /* while tableCount < 5 */

       ----------------------------------------------
       IF (l_notauthorized !=0) AND (l_tskfound !=0) AND (l_notauthorized = l_tskfound)  THEN
          RAISE_APPLICATION_ERROR(-20001, 'Operator is not authorized to view the task.');
       END IF;


            <<Totaltskidcount>>
            searchMaxCountBnd1 := tskIdCount;
            tableCount := 0;
        tmpStr1 := '';
        WHILE tableCount <= 5
        LOOP
            WhereClause := '';
            sqlStatement:= '';

            /* note that dateTimeWhereClause , RowNumWhereClause is always valid the rest may be blank */
            WhereClause := dateTimeWhereClause;

            IF ((taskStatus = 'O' or taskStatus = 'A' or taskStatus = 'U') and tableCount = tskreqTableSearchOrder ) THEN
                /* tskreq */
                IF idcode > 0 THEN
                  IF descending IS NOT NULL THEN
                    sqlStatement := 'SELECT DISTINCT (tr.tskid), tr.createdate, tr.createtime FROM tskreq tr, tskident ti ';
                  ELSE
                    sqlStatement := 'SELECT DISTINCT (tr.tskid) FROM tskreq tr, tskident ti ';
                  END IF;
                ELSE
                    sqlStatement := 'SELECT tskid FROM tskreq tr ';
                END IF;
            ELSIF ((taskStatus = 'O' or taskStatus = 'A' or taskStatus = 'U') AND tableCount = qatskreqTableSearchOrder ) THEN
                /* qatskreq */
                IF idcode > 0 THEN
                  IF descending IS NOT NULL THEN
                    sqlStatement := 'SELECT DISTINCT (tr.tskid), tr.createdate, tr.createtime FROM qatskreq tr, tskident ti ';
                  ELSE
                    sqlStatement := 'SELECT DISTINCT (tr.tskid) FROM qatskreq tr, tskident ti ';
                  END IF;
                ELSE
                    sqlStatement := 'SELECT tskid FROM qatskreq tr ';
                END IF;
            ELSIF ((taskStatus = 'C' OR taskStatus = 'A') AND actcode = 0 AND  tableCount = comptskTableSearchOrder ) THEN
                /* comptsk */
                IF TmpWorkBasketStr <> ' ' THEN
                    GOTO skipTableLabel;
                END IF;
                IF idcode > 0 THEN
                  IF descending IS NOT NULL THEN
                    sqlStatement := 'SELECT DISTINCT (tr.tskid), tr.createdate, tr.createtime FROM comptsk tr, comptskident ti ';
                  ELSE
                    sqlStatement := 'SELECT DISTINCT (tr.tskid) FROM comptsk tr, comptskident ti ';
                  END IF;
                ELSE
                    sqlStatement := 'SELECT tskid FROM comptsk tr ';
                END IF;
            ELSIF ((taskStatus = 'S' OR taskStatus = 'A' or taskStatus = 'U') AND tableCount = susptskreqTableSearchOrder ) THEN
                /* susptskreq */
                IF idcode > 0 THEN
                  IF descending IS NOT NULL THEN
                    sqlStatement := 'SELECT DISTINCT (tr.tskid), tr.createdate, tr.createtime FROM susptskreq tr, tskident ti ';
                  ELSE
                    sqlStatement := 'SELECT DISTINCT (tr.tskid) FROM susptskreq tr, tskident ti ';
                  END IF;
                ELSE
                    sqlStatement := 'SELECT tskid FROM susptskreq tr ';
                END IF;
            ELSIF ((taskStatus = 'R' OR taskStatus = 'A' OR taskStatus = 'O' or taskStatus = 'U') AND tableCount = ocrtskreqTableSearchOrder) THEN
                /* ocrtskreq */
                IF idcode > 0 THEN
                  IF descending IS NOT NULL THEN
                    sqlStatement := 'SELECT DISTINCT (tr.tskid), tr.createdate, tr.createtime FROM ocrtskreq tr, tskident ti ';
                  ELSE
                    sqlStatement := 'SELECT DISTINCT (tr.tskid) FROM ocrtskreq tr, tskident ti ';
                  END IF;
                ELSE
                    sqlStatement := 'SELECT tskid FROM ocrtskreq tr ';
                END IF;
            ELSIF ((taskStatus = 'E' OR taskStatus = 'A' OR taskStatus = 'O' or taskStatus = 'U') AND tableCount = evalrulereqTableSearchOrder) THEN
                    /* evalrulereq */
                IF idcode > 0 THEN
                  IF descending IS NOT NULL THEN
                    sqlStatement := 'SELECT DISTINCT (tr.tskid), tr.createdate, tr.createtime FROM evalrulereq tr, tskident ti ';
                  ELSE
                    sqlStatement := 'SELECT DISTINCT (tr.tskid) FROM evalrulereq tr, tskident ti ';
                  END IF;
                ELSE
                   sqlStatement := 'SELECT tskid FROM evalrulereq tr ';
                    END IF;
            ELSE
                /* no search for this table check the next table */
                goto skipTableLabel;
            END IF;

--          IF isSecurityOn = 1
--      THEN
--                  sqlStatement := sqlStatement || ', authdpt ';
--                  WhereClause := WhereClause || ' and (tr.dptcode = authdpt.dptcode and authdpt.operid = :l_operId)';
        --          SELECT miscflags
        --          INTO l_miscflags
        --    FROM dpt WHERE dptcode = l_dptcode;
        --         IF l_miscflags=0 THEN
        --              sqlStatement := sqlStatement;
        --              WhereClause := WhereClause;
        --         ELSE
                      --sqlStatement := sqlStatement || ', (select d.dptcode ,d.miscflags from authdpt au,dpt d where au.dptcode=d.dptcode and au.operid= :l_operId and d.miscflags in (1,0)) d';
                      --WhereClause := WhereClause || ' and ((tr.dptcode = d.dptcode  and  d.miscflags=1) OR d.miscflags=0)';
        --sqlStatement := sqlStatement || ', (select d.dptcode from authdpt au,dpt d where au.dptcode=d.dptcode and au.operid= :l_operId) d';
        --WhereClause := WhereClause || ' and (tr.dptcode = d.dptcode)';
--      ELSE
--         sqlStatement := sqlStatement;
--         WhereClause := WhereClause;
--      END IF;
                --END IF;
            if tableCount <> comptskTableSearchOrder then
                WhereClause := WhereClause||WorkBasketWhereClause;
                WhereClause := WhereClause||DepartmentWhereClause;
                WhereClause := WhereClause||TaskTypeWhereClause;
                WhereClause := WhereClause||ActionWhereClause;
                WhereClause := WhereClause||IdentifierWhereClause;
            else
                WhereClause := WhereClause||DepartmentWhereClause;
                WhereClause := WhereClause||TaskTypeWhereClause;
                WhereClause := WhereClause||CompIdentifierWhereClause;
            end if;

            WhereClause := WhereClause||RowNumWhereClause;

            sqlStatement := sqlStatement||WhereClause;
            IF descending IS NOT NULL AND descending = TRUE THEN
              sqlStatement := sqlStatement || ' ORDER BY createdate, createtime desc';
            ELSIF descending IS NOT NULL AND descending = FALSE THEN
              sqlStatement := sqlStatement || ' ORDER BY createdate, createtime desc';
            ELSE
              sqlStatement := sqlStatement || ' ORDER BY tskid';
            END IF;
            DBMS_OUTPUT.PUT_LINE('Enchanced Search Query is: ' || sqlStatement);

        ----Code added on 01/18/2006 START----------------------------------------------------------------
        --getting the rowcount value
           cur := DBMS_SQL.OPEN_CURSOR;
           DBMS_SQL.PARSE(cur,rtrim(sqlStatement), DBMS_SQL.NATIVE);
          
           DBMS_OUTPUT.PUT_LINE('Enchanced Search Query is: ' || sqlStatement);

            --binding the variables.
            DBMS_SQL.BIND_VARIABLE(cur, 'bDateBnd', bDateBnd);
            DBMS_SQL.BIND_VARIABLE(cur, 'bTimeBnd', bTimeBnd);
            IF beginDate <> endDate THEN
                DBMS_SQL.BIND_VARIABLE(cur, 'eDateBnd', eDateBnd);
            END IF;
            DBMS_SQL.BIND_VARIABLE(cur, 'eTimeBnd', eTimeBnd);

            DBMS_SQL.BIND_VARIABLE(cur, 'searchMaxCountBnd', searchMaxCountBnd1);

--          IF isSecurityOn = 1 THEN
--            --IF l_miscflags <>0 THEN
--              DBMS_SQL.BIND_VARIABLE(cur, 'l_operId', l_operId);
--            --END IF;
--          END IF;

            if l_workBasket <>' ' and tableCount <> comptskTableSearchOrder and bEmptyWorkBasket = 0 then
                DBMS_SQL.BIND_VARIABLE(cur, 'TmpWorkBasketStr', TmpWorkBasketStr);
            end if;
            if dptcode > 0 then
                DBMS_SQL.BIND_VARIABLE(cur, 'dptBnd', dptBnd);
            end if;
            if tskcode > 0 then
                DBMS_SQL.BIND_VARIABLE(cur, 'tskBnd', tskBnd);
            end if;
            if actcode > 0 and tableCount <> comptskTableSearchOrder then
                DBMS_SQL.BIND_VARIABLE(cur, 'actBnd', actBnd);
            end if;

            IF idcode > 0
            THEN
                DBMS_SQL.BIND_VARIABLE(cur, 'idcodeBnd', idcodeBnd);

                IF field1 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr1', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue1', field1);
                END IF;

                IF field2 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr2', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue2', field2);
                END IF;

                IF field3 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr3', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue3', field3);
                END IF;

                IF field4 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr4', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue4', field4);
                END IF;
            END IF;
            /* end binding necessary variables */

            IF idcode2 > 0
            THEN
                DBMS_SQL.BIND_VARIABLE(cur, 'idcodeBnd2', idcodeBnd2);

                IF field21 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr21', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue21', field21);
                END IF;

                IF field22 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr22', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue22', field22);
                END IF;

                IF field23 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr23', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue23', field23);
                END IF;

                IF field24 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr24', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue24', field24);
                END IF;
            END IF;
            /* end binding necessary variables */

            IF idcode3 > 0
            THEN
                DBMS_SQL.BIND_VARIABLE(cur, 'idcodeBnd3', idcodeBnd3);

                IF field31 <> ' '
                THEN
                    fieldnbr := 1;
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr31', fieldnbr);
                    DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue31', field31);
                END IF;

                IF field32 <> ' '
                THEN
                   fieldnbr := 2;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr32', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue32', field32);
                END IF;

                IF field33 <> ' '
                THEN
                   fieldnbr := 3;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr33', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue33', field33);
                END IF;

                IF field34 <> ' '
                THEN
                   fieldnbr := 4;
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldnbr34', fieldnbr);
                   DBMS_SQL.BIND_VARIABLE(cur, 'bFieldvalue34', field34);
                END IF;
            END IF;
            /* end binding necessary variables */

            DBMS_SQL.DEFINE_COLUMN (cur, 1, tmp_tskid, 11);
            rows_inserted  := DBMS_SQL.EXECUTE (cur);

            WHILE DBMS_SQL.FETCH_ROWS (cur) <> 0
            --AND cur <= searchmaxrowcount
            LOOP
                DBMS_SQL.COLUMN_VALUE (cur, 1, tmp_tskid);
                --tskIdCount1 := tskIdCount1+1;

               /**************************************************************************/
                        -- dpt security check
                          IF isSecurityOn = 1 THEN
                             SELECT dptcode,wrkbskt INTO l_miscdptcode,l_wrkbskt
                             FROM
                             (
                              SELECT dptcode,wrkbskt FROM tskreq      WHERE tskid = tmp_tskid
                          UNION ALL
                          SELECT dptcode,wrkbskt FROM qatskreq    WHERE tskid = tmp_tskid
                          UNION ALL
                          SELECT dptcode,wrkbskt FROM susptskreq  WHERE tskid = tmp_tskid
                          UNION ALL
                          SELECT dptcode,wrkbskt FROM ocrtskreq   WHERE tskid = tmp_tskid
                          UNION ALL
                          SELECT dptcode,wrkbskt FROM evalrulereq   WHERE tskid = tmp_tskid
                          UNION ALL
                          SELECT dptcode,' '     FROM comptsk     WHERE tskid = tmp_tskid
                         );

                           l_dptcount := 0;
                       IF l_wrkbskt != l_operid THEN
                              SELECT miscflags INTO l_miscflags
                              FROM dpt
                              WHERE dptcode =l_miscdptcode;


                              IF l_miscflags = 0 THEN
                                 tskIdCount1 := tskIdCount1+1;
                              ELSIF l_miscflags = 1 THEN
                         BEGIN
                         SELECT 1 INTO l_dptcount
                         FROM authdpt au,dpt d
                         WHERE au.dptcode = d.dptcode
                         AND   au.dptcode=l_miscdptcode
                         AND   au.operid= RPAD(l_operid,8,' ')
                         AND   d.active = 'Y';
                         EXCEPTION
                            WHEN NO_DATA_FOUND THEN
                              NULL;
                            WHEN OTHERS THEN
                             RAISE_APPLICATION_ERROR(-20002, 'There are too many rows found in authdpt table.');
                         END;
                              END IF;

                            IF l_dptcount = 1 THEN
                                 tskIdCount1 := tskIdCount1+1;
                            END IF;

                          ELSE ----IF l_wrkbskt != l_operid THEN
                              tskIdCount1 := tskIdCount1+1;
                          END IF;
                        ELSE
                          tskIdCount1 := tskIdCount1+1;
            END IF;

                /****************************************************************/

                IF tskIdCount1 = searchMaxCountBnd1 THEN
                 --l_totalcount := tskIdCount1;
                 DBMS_SQL.CLOSE_CURSOR(cur);
                 goto donelabel;
                END IF;
            END LOOP; /* while DBMS_SQL.FETCH_ROWS (cur) <> 0 */
            DBMS_SQL.CLOSE_CURSOR(cur);
            --goto DoneLabel;
        <<skipTableLabel>>
        tableCount  := tableCount + 1;
        END LOOP; /* while tableCount < 5 */
        --searchMaxCountBnd := tskIdCount+1;
        goto DoneLabel;

<<doneLabel>>



        totalcount := tskIdCount1;

EXCEPTION
    WHEN OTHERS THEN
    BEGIN
        IF DBMS_SQL.IS_OPEN(cur) THEN
            DBMS_SQL.CLOSE_CURSOR(cur);
        END IF;
        IF site_cur%ISOPEN THEN close site_cur; end IF;
        RAISE;
    END;

END; /* end of TIAAEnhancedTaskSearchV2_2 */