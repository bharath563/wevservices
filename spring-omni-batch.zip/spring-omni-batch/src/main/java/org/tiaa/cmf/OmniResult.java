package org.tiaa.cmf;

public class OmniResult {
	private String batchId;
	private String orchId;
	private String omniResult;
	private String omniMessage;	

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public String getOrchId() {
		return orchId;
	}

	public void setOrchId(String orchId) {
		this.orchId = orchId;
	}

	public String getOmniResult() {
		return omniResult;
	}

	public void setOmniResult(String omniResult) {
		this.omniResult = omniResult;
	}

	public String getOmniMessage() {
		return omniMessage;
	}

	public void setOmniMessage(String omniMessage) {
		this.omniMessage = omniMessage;
	}

}
